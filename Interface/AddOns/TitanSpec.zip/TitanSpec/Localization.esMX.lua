local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","esMX",false)

if L then

L["TITAN_SPEC_ACCEPT"] = "Aceptar"
L["TITAN_SPEC_CANCEL"] = "Cancelar"
L["TITAN_SPEC_HIDE_SPAM"] = "Ocultar mensaje de hechizo aprendido" -- Needs review
-- L["TITAN_SPEC_HINT"] = ""
L["TITAN_SPEC_HYBRID"] = "Hibrido"
L["TITAN_SPEC_MENU_TEXT"] = "Talentos"
L["TITAN_SPEC_NONE"] = "Ninguno"
-- L["TITAN_SPEC_PRIMARY_SPEC"] = ""
L["TITAN_SPEC_RENAME"] = "Renombrar"
-- L["TITAN_SPEC_RENAME_TEXT"] = ""
-- L["TITAN_SPEC_RESET"] = ""
-- L["TITAN_SPEC_SECONDARY_SPEC"] = ""
-- L["TITAN_SPEC_SHOW_BUILD"] = ""
-- L["TITAN_SPEC_SHOW_COLOURS"] = ""
-- L["TITAN_SPEC_SPEC"] = ""
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Informacion de Talentos"

end
