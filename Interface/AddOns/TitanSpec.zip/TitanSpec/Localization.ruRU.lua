﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","ruRU",false)
-- Пичинег @ EU-Термоштепсель

if L then

L["TITAN_SPEC_ACCEPT"] = "Принять"
L["TITAN_SPEC_CANCEL"] = "Отмена"
L["TITAN_SPEC_HIDE_SPAM"] = "Не показывать сообщения о получении способностей"
L["TITAN_SPEC_HINT"] = "Совет: нажмите ЛКМ для смены набора талантов."
L["TITAN_SPEC_HYBRID"] = "Гибрид"
L["TITAN_SPEC_MENU_TEXT"] = "Таланты"
L["TITAN_SPEC_NONE"] = "Нет данных"
L["TITAN_SPEC_PRIMARY_SPEC"] = "Первый набор: "
L["TITAN_SPEC_RENAME"] = "Переименовать текущий набор"
L["TITAN_SPEC_RENAME_TEXT"] = "Введите новое имя:"
L["TITAN_SPEC_RESET"] = "Сброс"
L["TITAN_SPEC_SECONDARY_SPEC"] = "Второй набор: "
L["TITAN_SPEC_SHOW_BUILD"] = "Подробно отображать набор в ярлыке"
L["TITAN_SPEC_SHOW_COLOURS"] = "Цветной текст подсказки"
L["TITAN_SPEC_SPEC"] = "Набор"
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Информация о талантах"

end
