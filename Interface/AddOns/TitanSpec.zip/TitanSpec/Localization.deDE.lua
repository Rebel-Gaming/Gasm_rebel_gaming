local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","deDE",false)
-- Translated by Gomntep
if L then

L["TITAN_SPEC_ACCEPT"] = "Best�tigen"
L["TITAN_SPEC_CANCEL"] = "Abbrechen"
L["TITAN_SPEC_HIDE_SPAM"] = "\"Spruch gelernt\" Nachricht verstecken"
L["TITAN_SPEC_HINT"] = "Tipp: Links-Click um aktive Talente zu wechseln"
L["TITAN_SPEC_HYBRID"] = "Hybrid"
L["TITAN_SPEC_MENU_TEXT"] = "Talente"
L["TITAN_SPEC_NONE"] = "Keiner"
L["TITAN_SPEC_PRIMARY_SPEC"] = "Erste Skillung"
L["TITAN_SPEC_RENAME"] = "Umbennen"
L["TITAN_SPEC_RENAME_TEXT"] = "Aktuelle Talente umbenennen"
L["TITAN_SPEC_RESET"] = "Zur�cksetzen" -- Needs review
L["TITAN_SPEC_SECONDARY_SPEC"] = "Zweite Skillung"
L["TITAN_SPEC_SHOW_BUILD"] = "Talentauswahl im Button zeigen"
L["TITAN_SPEC_SHOW_COLOURS"] = "Zeige Tooltip Farben"
L["TITAN_SPEC_SPEC"] = "Skillung"
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Talente Info"

end
