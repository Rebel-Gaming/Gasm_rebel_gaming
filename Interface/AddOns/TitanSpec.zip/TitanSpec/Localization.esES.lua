local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","esES",false)

if L then

L["TITAN_SPEC_ACCEPT"] = "Aceptar"
L["TITAN_SPEC_CANCEL"] = "Cancelar"
L["TITAN_SPEC_HIDE"] = "Ocultar"
L["TITAN_SPEC_HIDE_SPAM"] = "Ocultar mensajes de hechizos aprendidos"
L["TITAN_SPEC_HINT"] = "Pista: Clic izquierdo para cambiar la especializaci�n actual"
L["TITAN_SPEC_HYBRID"] = "H�brido"
L["TITAN_SPEC_MENU_TEXT"] = "Talentos"
L["TITAN_SPEC_NONE"] = "Ninguno"
L["TITAN_SPEC_PRIMARY_SPEC"] = "Especializaci�n primaria:"
L["TITAN_SPEC_RENAME"] = "Renombrar"
L["TITAN_SPEC_RENAME_TEXT"] = "Renombrar especializaci�n actual:"
L["TITAN_SPEC_RESET"] = "Restaurar"
L["TITAN_SPEC_SECONDARY_SPEC"] = "Especializaci�n secundaria:"
L["TITAN_SPEC_SHOW_BUILD"] = "Mostrar la rama en el bot�n"
L["TITAN_SPEC_SHOW_COLOURS"] = "Mostrar colores de ayuda"
L["TITAN_SPEC_SPEC"] = "Especializaci�n"
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Informaci�n de talentos"

end
