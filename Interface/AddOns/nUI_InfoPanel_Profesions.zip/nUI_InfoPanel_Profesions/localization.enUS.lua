
nUI_InfoPanel_Profesions_L = {};
nUI_InfoPanel_Profesions_Locale = GetLocale();

nUI_InfoPanel_Profesions_L["Info Panel Text"]            		= "Info Panel: Profesions";
nUI_InfoPanel_Profesions_L["Info Panel Label"]           		= "Profs";

nUI_InfoPanel_Profesions_L["UNKNOWN"]					= "Not Known";
nUI_InfoPanel_Profesions_L["AVAILABLE"]					= "Available";
nUI_InfoPanel_Profesions_L["OUT_OF_REAGENTS"]				= "Out of Reagents";
nUI_InfoPanel_Profesions_L["ON_COOLDOWN"]				= "On Cooldown";

nUI_InfoPanel_Profesions_L["ALLIANCE"]					= "alliance";
nUI_InfoPanel_Profesions_L["HORDE"]					= "horde";

nUI_InfoPanel_Profesions_L["RAID_TELEPORT"]				= "MagePorts: Using Teleport Spell while in a Raid.";
nUI_InfoPanel_Profesions_L["PARTY_TELEPORT"]				= "MagePorts: Using Teleport Spell while in a Party.";
nUI_InfoPanel_Profesions_L["SOLO_PORTAL"]				= "MagePorts: Using Portal Spell while solo.";

nUI_InfoPanel_Profesions_L["PORTALS"]					= "Portals";
nUI_InfoPanel_Profesions_L["TELEPORTS"]					= "Teleports";
nUI_InfoPanel_Profesions_L["RESTOCK_REAGENTS"]				= "MagePorts: Restock reagents?";
nUI_InfoPanel_Profesions_L["YES"]					= "Yes";
nUI_InfoPanel_Profesions_L["NO"]						= "No";
