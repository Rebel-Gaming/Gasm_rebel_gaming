
----------------------------------------------------------------
-- [v1.01.00] Localized Functions and Tables to speed things up
----------------------------------------------------------------
local _L = nUI_InfoPanel_Profesions_L;

---------------------------------------------------
-- [v1.01.00] Initialise Variables
-- [v1.01.00] Alpha and FontSize Values made global
-- [v1.02.00] topButtons and bottomButtons made global
-- [v1.02.01] Added option to not display text in top window
---------------------------------------------------
Profesions_Defaults = {};
Profesions_Defaults.UpdateInterval = 30;
Profesions_Defaults.FontSize = 14;
Profesions_Defaults.NotAvailableAlpha = 0.1;
Profesions_Defaults.NotIdealAlpha = 0.25;
Profesions_Defaults.AvailableAlpha = 1.0;
Profesions_Defaults.DisplayText = true;

Profesions = {};
Profesions.Class = nil;
Profesions.Frame = nil;
Profesions.LastUpdate = 0;
Profesions.topButtons = {};
Profesions.middleButtons = {};
Profesions.bottomButtons = {};
local topDB = {};
local middleDB = {};
local bottomDB = {};

---------------------------------------------------
-- [v1.01.00] Initialise top Spell Database
---------------------------------------------------
local function Profesions_InittopDB()
	topDB = {};
	table.insert(topDB, { quest = false, spell =  7411, faction = _L["ALLIANCE"] } );
	table.insert(topDB, { quest = false, spell = 45359, faction = _L["ALLIANCE"] } );
	table.insert(topDB, { quest = false, spell = 31252, faction = _L["ALLIANCE"] } );
	table.insert(topDB, { quest = false, spell =  3908, faction = _L["ALLIANCE"] } );
	table.insert(topDB, { quest = false, spell =  4036, faction = _L["ALLIANCE"] } );
	table.insert(topDB, { quest = false, spell =  2259, faction = _L["ALLIANCE"] } );
	table.insert(topDB, { quest = false, spell =  7411, faction = _L["HORDE"] } );
	table.insert(topDB, { quest = false, spell = 45359, faction = _L["HORDE"] } );
	table.insert(topDB, { quest = false, spell = 31252, faction = _L["HORDE"] } );
	table.insert(topDB, { quest = false, spell =  3908, faction = _L["HORDE"] } );
	table.insert(topDB, { quest = false, spell =  4036, faction = _L["HORDE"] } );
	table.insert(topDB, { quest = false, spell =  2259, faction = _L["HORDE"] } );
end
---------------------------------------------------
-- [v1.01.00] Initialise bottom Spell Deatabase
---------------------------------------------------
local function Profesions_InitmiddleDB()	
	middleDB = {};
	table.insert(middleDB, { quest = false, spell = 13262, faction = _L["ALLIANCE"] } );
	table.insert(middleDB, { quest = false, spell = 51005, faction = _L["ALLIANCE"] } );
	table.insert(middleDB, { quest = false, spell =  2656, faction = _L["ALLIANCE"] } );
	table.insert(middleDB, { quest = false, spell =  2108, faction = _L["ALLIANCE"] } );
	table.insert(middleDB, { quest = false, spell =  3538, faction = _L["ALLIANCE"] } );
	table.insert(middleDB, { quest = false, spell = 25229, faction = _L["ALLIANCE"] } );
	table.insert(middleDB, { quest = false, spell = 13262, faction = _L["HORDE"] } );
	table.insert(middleDB, { quest = false, spell = 51005, faction = _L["HORDE"] } );
	table.insert(middleDB, { quest = false, spell =  2656, faction = _L["HORDE"] } );
	table.insert(middleDB, { quest = false, spell =  2108, faction = _L["HORDE"] } );
	table.insert(middleDB, { quest = false, spell =  3538, faction = _L["HORDE"] } );
	table.insert(middleDB, { quest = false, spell = 25229, faction = _L["HORDE"] } );
end

local function Profesions_InitbottomDB()	
	bottomDB = {};
	table.insert(bottomDB, { quest = false, spell =  2550, faction = _L["ALLIANCE"] } );
	table.insert(bottomDB, { quest = false, spell =  3273, faction = _L["ALLIANCE"] } );
	table.insert(bottomDB, { quest = false, spell = 51294, faction = _L["ALLIANCE"] } );
	table.insert(bottomDB, { quest = false, spell =   818, faction = _L["ALLIANCE"] } );
	table.insert(bottomDB, { quest = false, spell = 53428, faction = _L["ALLIANCE"] } );
	table.insert(bottomDB, { quest = false, spell =  1804, faction = _L["ALLIANCE"] } );
	table.insert(bottomDB, { quest = false, spell =  2550, faction = _L["HORDE"] } );
	table.insert(bottomDB, { quest = false, spell =  3273, faction = _L["HORDE"] } );
	table.insert(bottomDB, { quest = false, spell = 51294, faction = _L["HORDE"] } );
	table.insert(bottomDB, { quest = false, spell =   818, faction = _L["HORDE"] } );
	table.insert(bottomDB, { quest = false, spell = 53428, faction = _L["HORDE"] } );
	table.insert(bottomDB, { quest = false, spell =  1804, faction = _L["HORDE"] } );
end
------------------------------------
-- [v1.01.00] Create a Secure Button
-- [v1.01.01] Only update cooldown if one exists
-- [v1.01.01] Validate Reagent Test before Cooldown Test for availability tooltip.
-- [v1.02.00] Removed cooldown count from tooltip
------------------------------------
local function Profesions_CreateSecureSpellButton(spellID, reagentID, level, quest)
	local SpellName, _, SpellIcon = GetSpellInfo(spellID);
	local Available = ( GetSpellInfo(SpellName) ~= nil );
	local ButtonName = "P_" .. spellID;
	local TextureName = ButtonName .. "_Texture";
	
	-- Show a tooltip for the button
	local function ShowTooltip(self)
		local Available = ( GetSpellInfo(SpellName) ~= nil );
		local TimeNow = GetTime();
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR");
		GameTooltip:SetText(SpellName, 1.0, 1.0, 0.0 );
		if ( quest ) then GameTooltip:AddLine(_L["ATTAINED_VIA_QUEST"], 1.0,1.0,1.0); end
		if ( not Available ) then
			GameTooltip:AddLine(_L["UNKNOWN"],1.0,1.0,1.0);
		end
		GameTooltip:Show();		
	end
	
	-- Hide the buttons tooltip
	local function HideTooltip(self)
		GameTooltip:Hide();
	end
	
	-- Update the cooldown counter
	local function UpdateCooldown(self)
		local TimeNow = GetTime();
		local CooldownStart, CooldownDuration, CooldownEnabled = GetSpellCooldown(SpellName);
		if ( not CooldownEnabled ) then return; end
		if ( CooldownDuration == 0 ) then return; end	
		local DiffTime = TimeNow - CooldownStart;
		local CooldownCounter = CooldownDuration - DiffTime;
		CooldownCounter = math.floor(CooldownCounter);
		if ( CooldownCounter > 0 ) then	
			self.Text:SetText(CooldownCounter);	
		else
			self.Text:SetText("");	
		end
	end
	
	-- Create the button and its children and attributes
	local Button = CreateFrame("Button", ButtonName, UIParent,"ActionButtonTemplate,SecureActionButtonTemplate");			
	Button:SetWidth(20);
	Button:SetHeight(20);			
	local texture = Button:CreateTexture(TextureName,"OVERLAY");
	texture:SetAllPoints(Button);
	texture:SetTexture(SpellIcon);
	Button:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2");
	Button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", add);
	Button:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress");
	if ( not Available ) then 
		Button:SetAlpha(Profesions_Defaults.NotIdealAlpha); 
	else
		Button:SetAlpha(Profesions_Defaults.AvailableAlpha);
	end
	Button:SetAttribute("type","spell");
	Button:SetAttribute("spell",SpellName);
	Button:SetScript("OnEnter",ShowTooltip);
	Button:SetScript("OnLeave",HideTooltip);
	
	-- Create the Cooldown frame to display the Cooldown Counter
	Button.Cooldown = CreateFrame("Frame", ButtonName.."_Cooldown", Button);
	Button.Cooldown:SetAllPoints(Button);
	Button.Cooldown.Text = Button.Cooldown:CreateFontString(ButtonName.."_Cooldown_Text", 'ARTWORK', "GameFontNormal");
	local Path, Size, Flags = Button.Cooldown.Text:GetFont()
	Button.Cooldown.Text:SetFont(Path,Profesions_Defaults.FontSize,Flags);
	Button.Cooldown.Text:SetAllPoints(Button.Cooldown);
	Button.Cooldown.Text:SetJustifyH( "CENTER" );
	Button.Cooldown.Text:SetJustifyV( "MIDDLE" );
	Button.Cooldown.Text:SetTextColor( 1, 1, 0, 1 );
	Button.Cooldown.Text:SetText("");  
	Button.Cooldown:SetScript("OnUpdate",UpdateCooldown);
		
	return Button;
end

---------------------------------------------------
-- [v1.01.00] Initialise the Buttons
---------------------------------------------------
local function Profesions_InitButtons(parent)
	Profesions.topButtons = {};
	Profesions.middleButtons = {};
	Profesions.bottomButtons = {};
	local Faction = string.lower(UnitFactionGroup("player"));

	-- First the tops
	for i,v in pairs(topDB) do
		if ( string.find(v.faction,Faction) ) then
			local Button = Profesions_CreateSecureSpellButton(v.spell,17032, v.level, v.quest);
			Button:SetParent(parent);
			table.insert(Profesions.topButtons,Button);
		end
	end
	for i,v in pairs(middleDB) do
		if ( string.find(v.faction,Faction) ) then
			local Button = Profesions_CreateSecureSpellButton(v.spell,17032, v.level, v.quest);
			Button:SetParent(parent);
			table.insert(Profesions.middleButtons,Button);
		end
	end
	-- Now the bottoms
	for i,v in pairs(bottomDB) do
		if ( string.find(v.faction,Faction) ) then
			local Button = Profesions_CreateSecureSpellButton(v.spell,17031, v.level, v.quest);
			Button:SetParent(parent);
			table.insert(Profesions.bottomButtons,Button);
		end
	end
end

---------------------------------------------------------------------------
-- [v1.01.00] Validate the Spell in case you cast the wrong one by mistake
-- [v1.01.02] Take into account casts that do not have spell names, links and ids
---------------------------------------------------------------------------
local function Profesions_ValidateSpell(StartStop, Caster, SpellName, SpellRank)

	-- Not the player so don't proceed		
	if ( Caster ~= "player" ) then return false; end
	
	-- Not a spell then don't proceed
	if ( not SpellName ) then return false; end
	
	local SpellID = nil;
	local SpellLink = GetSpellLink(SpellName,"");

	-- No spell link to discern ID from so not a true spell
	if ( not SpellLink ) then return false; end	
	
	local Found, _, SpellString = string.find(SpellLink, "^|c%x+|H(.+)|h%[.*%]");
	if ( Found ) then _, SpellID = strsplit(":", SpellString); end
	SpellID = tonumber(SpellID);
	
	-- SpellID cannot be found so unable to validate spell
	if ( not SpellID ) then return false; end

	local topSpell = false;
	local middleSpell = false;
	local bottomSpell = false;
	for i,v in pairs(topDB) do
		v.spell = tonumber(v.spell);
		if ( v.spell == SpellID ) then topSpell = true; break; end
	end
	for i,v in pairs(middleDB) do
		v.spell = tonumber(v.spell);
		if ( v.spell == SpellID ) then middleSpell = true; break; end
	end	
	for i,v in pairs(bottomDB) do
		v.spell = tonumber(v.spell);
		if ( v.spell == SpellID ) then bottomSpell = true; break; end
	end	
	
	if ( StartStop == "STOP" ) then 
		if (topSpell or middlespell or bottomSpell) then return true; end
		return false;
	end
	
	if (topSpell or middlespell or bottomSpell) then return true; end
	return false;
end

---------------------------------------------------
-- [v1.01.00] Update the Frame with current information
-- [v1.02.00] Use Not Available alpha if no more reagents
-- [v1.02.01] Added option to not display text in top window
-- [v1.02.02] Added ReagentName variable for those that don't know about it yet
---------------------------------------------------
local function Profesions_UpdateFrame(ForceUpdate)

	-- We may want to force the update so only test interval if we are using OnUpdate function
	local TimeNow = GetTime();
	if ( not ForceUpdate ) then
		if TimeNow < ( Profesions.LastUpdate + Profesions_Defaults.UpdateInterval ) then return; 	end
	end
	Profesions.LastUpdate = TimeNow;

	local Solo = false;
	local IsInRaid = false;
	local IsInParty = false;
	if ( GetNumRaidMembers() > 0) then 
		IsInRaid = true; 
	elseif ( GetNumPartyMembers() > 0 ) then 
		IsInParty = true; 
	else
		Solo = true;
	end
	
	-- First the top Buttons	
	for i,v in pairs(Profesions.topButtons) do
		local spellName = v:GetAttribute("spell");
		local Available = ( GetSpellInfo(spellName) ~= nil );
		if ( not Available or reagentCount == 0 ) then 
			v:SetAlpha(Profesions_Defaults.NotIdealAlpha); 
		else
			if (Solo) then 
				v:SetAlpha(Profesions_Defaults.AvailableAlpha);
			end
		end
		
	    local Path, Size, Flags = v.Cooldown.Text:GetFont()
		v.Cooldown.Text:SetFont(Path,Profesions_Defaults.FontSize,Flags);
		v.Cooldown.Text:SetAlpha(1.0);
	end

	for i,v in pairs(Profesions.middleButtons) do
		local spellName = v:GetAttribute("spell");
		local Available = ( GetSpellInfo(spellName) ~= nil );
		if ( not Available or reagentCount == 0 ) then 
			v:SetAlpha(Profesions_Defaults.NotIdealAlpha); 
		else
			if (Solo) then 
				v:SetAlpha(Profesions_Defaults.AvailableAlpha);
			end
		end
		
	    local Path, Size, Flags = v.Cooldown.Text:GetFont()
		v.Cooldown.Text:SetFont(Path,Profesions_Defaults.FontSize,Flags);
		v.Cooldown.Text:SetAlpha(1.0);
	end
	-- Then the bottom Buttons
	for i,v in pairs(Profesions.bottomButtons) do
		local spellName = v:GetAttribute("spell");
		local Available = ( GetSpellInfo(spellName) ~= nil );
		if ( not Available or reagentCount == 0 ) then 
			v:SetAlpha(Profesions_Defaults.NotIdealAlpha); 
		else
			if (Solo) then 
				v:SetAlpha(Profesions_Defaults.AvailableAlpha);
			end
		end
	    local Path, Size, Flags = v.Cooldown.Text:GetFont()
		v.Cooldown.Text:SetFont(Path,Profesions_Defaults.FontSize,Flags);
		v.Cooldown.Text:SetAlpha(1.0);
	end
	
end

---------------------------------------------------
-- [v1.01.00] Initialise the whole Frame
-- [v1.02.00] Removed Anchoring here while in nUI panel
-- [v1.02.01] Added option to not display text in top window
---------------------------------------------------
local function Profesions_InitFrame()

	-- Create the Frame itself
	local frame = CreateFrame("Frame","Profesions_Frame",UIParent);
    frame:SetWidth(250);        
    frame:SetHeight(100);
    frame:SetAlpha(1.0);        
    frame:SetClampedToScreen(true);
	frame:SetPoint("CENTER",UIParent,"CENTER",0,0);
    
	
	-- Create the Buttons Table based on player faction
	Profesions_InitButtons(frame);

	-- Assign the OnUpdate Routine to keep the Frame updated every second
	frame:SetScript("OnUpdate",Profesions_UpdateFrame);
	
	-- Return this frame for use by the addon
	return frame;

end

-----------------------------------------------------------------------
-- [v1.01.00] OnEvent function for this addon
-----------------------------------------------------------------------
local function Profesions_OnEvent()
	if event == "LEARNED_SPELL_IN_TAB" then
		Profesions_UpdateFrame(true);
	elseif event == "PLAYER_ENTERING_WORLD" then
		Profesions_UpdateFrame(true);
	elseif event == "UNIT_SPELLCAST_START" then		
		if ( Profesions_ValidateSpell("START", arg1, arg2, arg3) ) then 
			Profesions_UpdateFrame(true);
		end
	elseif event == "UNIT_SPELLCAST_STOP" then
		if ( Profesions_ValidateSpell("STOP", arg1, arg2, arg3) ) then
			Profesions_UpdateFrame(true);
		end
	end
end

-----------------------------------------------------------------------------
-- [v1.02.00] Set Up Slash Commands
-----------------------------------------------------------------------------
local function Profesions_SetUpSlashCommands()
	SLASH_ProfesionsCmd1 = '/Profesions';
	SLASH_ProfesionsCmd2 = '/mp';
	SlashCmdList['ProfesionsCmd'] = Profesions_SlashCommands;
end
-----------------------------------------------------------------------------

-----------------------------------------------------------------------
-- [v1.01.00] Create Frame Function called from outside to use this addon
-- [v1.02.00] Added Slash Command functionality
-----------------------------------------------------------------------
function Profesions_CreateFrame()
	local playerClass, englishClass = UnitClass("player");
	Profesions.Frame = nil;
	if ( englishClass == "MAGE" ) then
		Profesions_InittopDB();
		Profesions_InitmiddleDB();
		Profesions_InitbottomDB();
		Profesions.Frame = Profesions_InitFrame();
		Profesions.Frame:SetScript( "OnEvent", Profesions_OnEvent );
		Profesions.Frame:RegisterEvent( "LEARNED_SPELL_IN_TAB" );
		Profesions.Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_START" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_STOP" );
	elseif ( englishClass == "HUNTER" ) then
		Profesions_InittopDB();
		Profesions_InitmiddleDB();
		Profesions_InitbottomDB();
		Profesions.Frame = Profesions_InitFrame();
		Profesions.Frame:SetScript( "OnEvent", Profesions_OnEvent );
		Profesions.Frame:RegisterEvent( "LEARNED_SPELL_IN_TAB" );
		Profesions.Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_START" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_STOP" );
	elseif ( englishClass == "DEATHKNIGHT" ) then
		Profesions_InittopDB();
		Profesions_InitmiddleDB();
		Profesions_InitbottomDB();
		Profesions.Frame = Profesions_InitFrame();
		Profesions.Frame:SetScript( "OnEvent", Profesions_OnEvent );
		Profesions.Frame:RegisterEvent( "LEARNED_SPELL_IN_TAB" );
		Profesions.Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_START" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_STOP" );
	elseif ( englishClass == "DRUID" ) then
		Profesions_InittopDB();
		Profesions_InitmiddleDB();
		Profesions_InitbottomDB();
		Profesions.Frame = Profesions_InitFrame();
		Profesions.Frame:SetScript( "OnEvent", Profesions_OnEvent );
		Profesions.Frame:RegisterEvent( "LEARNED_SPELL_IN_TAB" );
		Profesions.Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_START" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_STOP" );
	elseif ( englishClass == "PALADIN" ) then
		Profesions_InittopDB();
		Profesions_InitmiddleDB();
		Profesions_InitbottomDB();
		Profesions.Frame = Profesions_InitFrame();
		Profesions.Frame:SetScript( "OnEvent", Profesions_OnEvent );
		Profesions.Frame:RegisterEvent( "LEARNED_SPELL_IN_TAB" );
		Profesions.Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_START" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_STOP" );
	elseif ( englishClass == "SHAMAN" ) then
		Profesions_InittopDB();
		Profesions_InitmiddleDB();
		Profesions_InitbottomDB();
		Profesions.Frame = Profesions_InitFrame();
		Profesions.Frame:SetScript( "OnEvent", Profesions_OnEvent );
		Profesions.Frame:RegisterEvent( "LEARNED_SPELL_IN_TAB" );
		Profesions.Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_START" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_STOP" );
	elseif ( englishClass == "WARLOCK" ) then
		Profesions_InittopDB();
		Profesions_InitmiddleDB();
		Profesions_InitbottomDB();
		Profesions.Frame = Profesions_InitFrame();
		Profesions.Frame:SetScript( "OnEvent", Profesions_OnEvent );
		Profesions.Frame:RegisterEvent( "LEARNED_SPELL_IN_TAB" );
		Profesions.Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_START" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_STOP" );
	elseif ( englishClass == "ROGUE" ) then
		Profesions_InittopDB();
		Profesions_InitmiddleDB();
		Profesions_InitbottomDB();
		Profesions.Frame = Profesions_InitFrame();
		Profesions.Frame:SetScript( "OnEvent", Profesions_OnEvent );
		Profesions.Frame:RegisterEvent( "LEARNED_SPELL_IN_TAB" );
		Profesions.Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_START" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_STOP" );
	elseif ( englishClass == "PRIEST" ) then
		Profesions_InittopDB();
		Profesions_InitmiddleDB();
		Profesions_InitbottomDB();
		Profesions.Frame = Profesions_InitFrame();
		Profesions.Frame:SetScript( "OnEvent", Profesions_OnEvent );
		Profesions.Frame:RegisterEvent( "LEARNED_SPELL_IN_TAB" );
		Profesions.Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_START" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_STOP" );
	elseif ( englishClass == "WARRIOR" ) then
		Profesions_InittopDB();
		Profesions_InitmiddleDB();
		Profesions_InitbottomDB();
		Profesions.Frame = Profesions_InitFrame();
		Profesions.Frame:SetScript( "OnEvent", Profesions_OnEvent );
		Profesions.Frame:RegisterEvent( "LEARNED_SPELL_IN_TAB" );
		Profesions.Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_START" );
		Profesions.Frame:RegisterEvent( "UNIT_SPELLCAST_STOP" );
		if ( Profesions.Frame ) then
			Profesions_SetUpSlashCommands();
		end	
	end
end


