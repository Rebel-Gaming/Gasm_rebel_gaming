---------------------------------------------------
-- [v1.01.00] Make sure we have nUI tables
---------------------------------------------------
if not nUI_InfoPanels then nUI_InfoPanels = {}; end

----------------------------------------------------------------
-- [v1.01.00] Localized Functions and Tables to speed things up
----------------------------------------------------------------
local _L = nUI_InfoPanel_Profesions_L;

---------------------------------------------------
-- [v1.01.00] Allocation of the Window ID (unique)
---------------------------------------------------
nUI_INFOMODE_Profesions  = 40;
nUI_INFOPANEL_Profesions = "nUI_InfoPanel_Profesions";

---------------------------------------------------
-- [v1.01.00] Set the Default values for the Infopanel
---------------------------------------------------
nUI_InfoPanels[nUI_INFOPANEL_Profesions ] =
{	
	enabled   = true,
	desc      = _L["Info Panel Text"],             -- player friendly name/description of the panel
	label     = _L["Info Panel Label"],	       -- label to use on the panel selection button face
	rotation  = nUI_INFOMODE_Profesions,            -- index or position this panel appears on/in when clicking the selector button
	full_size = true;                              -- this plugin requires the entire info panel port without the button bag
	
	options  =
	{
		enabled  = true,
	},
};

---------------------------------------------------
-- [v1.01.00] Set Plugin Values
---------------------------------------------------
local plugin    = CreateFrame( "Frame", nUI_INFOPANEL_Profesions, nUI_Dashboard.Anchor );
plugin.active   = true;

---------------------------------------------------
-- [v1.01.00] Validate Addon is loaded
---------------------------------------------------
local function onProfesionsEvent()
	if event == "VARIABLES_LOADED" then
		Profesions_CreateFrame();
		if ( not Profesions.Frame ) then
			plugin.active = false;
		end
	end	
end

plugin:SetScript( "OnEvent", onProfesionsEvent );
plugin:RegisterEvent( "VARIABLES_LOADED" );

---------------------------------------------------
-- [v1.01.00] initPanel routine
---------------------------------------------------
plugin.initPanel = function( container, options )
	plugin.container = container;
	plugin.options   = options;
	if options and options.enabled then
		plugin.setEnabled( true );
	end
end

---------------------------------------------------
-- [v1.01.00] sizeChanged routine
-- [v1.01.03] Changed name of addon frame so as not to clash
-- [v1.02.00] Resize and Reposition according to scale
---------------------------------------------------
plugin.sizeChanged = function( scale, height, width )
	local options  = plugin.options;
	plugin.scale = scale;

	-- Grab addon information and unlock frame for movement
	local ProfesionsFrame   = plugin.Profesions;
	nUI_Movers:lockFrame( ProfesionsFrame, false, nil );
	
	-- Resize and Reposition according to scale and size of new container
	ProfesionsFrame:SetWidth( width ); 
	ProfesionsFrame:SetHeight( height ); 
	
	-- Center Buttons across the container
	local cellCount = #Profesions.topButtons;
    local cellWidth = ( width / cellCount );
    local btnSize = cellWidth * 0.7;
    local btnGap = cellWidth * 0.2;
    local verticalOffsettop = height / 3; 
    local verticalOffsetmiddle = height / 50;
    local verticalOffsetbottom = height / 3;

    for i=1,cellCount do
        Profesions.topButtons[i]:SetWidth( btnSize );
        Profesions.topButtons[i]:SetHeight( btnSize );
        Profesions.middleButtons[i]:SetWidth( btnSize );
        Profesions.middleButtons[i]:SetHeight( btnSize );
        Profesions.bottomButtons[i]:SetWidth( btnSize );
        Profesions.bottomButtons[i]:SetHeight( btnSize );
    end
    
    local odd = ( cellCount % 2 ) == 1;
    local midwayLeft = nil;
    local midwayRight = nil;
    if ( odd ) then 
		midwayLeft = math.ceil( cellCount / 2 );
	else
		midwayLeft = math.floor( cellCount / 2 );
		midwayRight = midwayLeft + 1;
	end

	-- Reposition top Buttons and Fontstrings
	if ( not midwayRight ) then
		Profesions.topButtons[midwayLeft]:SetPoint( "CENTER", plugin.container, "CENTER", btnGap/2, verticalOffsettop);
		Profesions.middleButtons[midwayLeft]:SetPoint( "CENTER", plugin.container, "CENTER", btnGap/2, verticalOffsetmiddle);
		Profesions.bottomButtons[midwayLeft]:SetPoint( "CENTER", plugin.container, "CENTER", btnGap/2, -verticalOffsetbottom);
	else
	    	Profesions.topButtons[midwayLeft]:SetPoint( "RIGHT", plugin.container, "CENTER", -btnGap/2, verticalOffsettop );
		Profesions.topButtons[midwayRight]:SetPoint( "LEFT", plugin.container, "CENTER", btnGap/2, verticalOffsettop );
	    	Profesions.middleButtons[midwayLeft]:SetPoint( "RIGHT", plugin.container, "CENTER", -btnGap/2, verticalOffsetmiddle );
		Profesions.middleButtons[midwayRight]:SetPoint( "LEFT", plugin.container, "CENTER", btnGap/2, verticalOffsetmiddle );
	    	Profesions.bottomButtons[midwayLeft]:SetPoint( "RIGHT", plugin.container, "CENTER", -btnGap/2, -verticalOffsetbottom );
		Profesions.bottomButtons[midwayRight]:SetPoint( "LEFT", plugin.container, "CENTER", btnGap/2, -verticalOffsetbottom );
	end
	for i = 1, midwayLeft - 1 do	
		Profesions.topButtons[i]:SetPoint( "RIGHT", Profesions.topButtons[i+1], "LEFT", -btnGap, 0 );
		Profesions.middleButtons[i]:SetPoint( "RIGHT", Profesions.middleButtons[i+1], "LEFT", -btnGap, 0 );
		Profesions.bottomButtons[i]:SetPoint( "RIGHT", Profesions.bottomButtons[i+1], "LEFT", -btnGap, 0 );
	end
	for i = midwayLeft + 1, cellCount do	
		Profesions.topButtons[i]:SetPoint( "LEFT", Profesions.topButtons[i-1], "RIGHT", btnGap, 0 );
		Profesions.middleButtons[i]:SetPoint( "LEFT", Profesions.middleButtons[i-1], "RIGHT", btnGap, 0 );
		Profesions.bottomButtons[i]:SetPoint( "LEFT", Profesions.bottomButtons[i-1], "RIGHT", btnGap, 0 );
	end	
	
	-- Lock addon frame for movement
	nUI_Movers:lockFrame( ProfesionsFrame, true, nil );
end
---------------------------------------------------
-- [v1.01.00] Validate Enable Status
---------------------------------------------------
plugin.setEnabled = function( enabled )
	if plugin.enabled ~= enabled then
		plugin.enabled = enabled;
		if not enabled then
			local Profesions = plugin.Profesions;
			if Profesions.saved_parent then
				nUI_Movers:lockFrame( Profesions, false, nil );
				Profesions:SetParent( Profesions.saved_parent );
				Profesions:SetBackdropBorderColor( Profesions.border_color );
				Profesions:SetBackdropColor( Profesions.backdrop_color );
			end
		else
			local Profesions = Profesions.Frame;
			plugin.Profesions = Profesions;
			if not Profesions.saved_parent then
				Profesions.saved_parent   = Profesions:GetParent();
				Profesions.border_color   = Profesions:GetBackdropBorderColor();
				Profesions.backdrop_color = Profesions:GetBackdropColor();
			end
			Profesions:SetParent( plugin.container );
			Profesions:SetPoint( "TOPLEFT", plugin.container, "TOPLEFT", 10, 10 );
			Profesions:SetPoint( "BOTTOMRIGHT", plugin.container, "BOTTOMRIGHT", 0, 0 );
			Profesions:SetFrameStrata( plugin.container:GetFrameStrata() );
			Profesions:SetFrameLevel( plugin.container:GetFrameLevel()+1 );
			Profesions:SetBackdropBorderColor( 0, 0, 0, 0 );
			Profesions:SetBackdropColor( 0, 0, 0, 0 );
			
			nUI_Movers:lockFrame( Profesions, true, nil );
		end				
	end			
end

---------------------------------------------------
-- [v1.01.00] setSelected routine
---------------------------------------------------
plugin.setSelected = function( selected )
	if selected ~= plugin.selected then
		plugin.selected = selected;
		if selected then
		else
		end
	end
end
