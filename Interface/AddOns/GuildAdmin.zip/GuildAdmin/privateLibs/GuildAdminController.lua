-- $LastChangedRevision: 79 $ / $LastChangedDate: 2009-10-13 22:50:01 +0000 (Tue, 13 Oct 2009) $ / $LastChangedBy $
--- Provides the logic layer
-- Basically decision stuff
--
-- @class file
-- @name privateLibs/GuildAdminController

-- ##############################################################################
-- Guild logic section
-- ##############################################################################

--- Returns the counts for guild members
-- GuildRoster should have been called before getting new values
--
-- @usage local on, off, total = GuildAdmin:getGuildMemberCounts() 
--
-- @return GuildMembersOnline, GuildMembersOffline, GuildMembersTotal
function GuildAdmin:getGuildMemberCounts()
    
    if IsInGuild()
    then
        -- depending on RosterShowOffline the numbers change, but flag reset can't be done in this function
        -- as it causes problems when displaying the guild frame from Blizzard
        
        -- not reliable so we get the total, sort guild roster and then find out the count of who's really online
        local total = GetNumGuildMembers(true)
        local onlineTotal = 0
        local offlineTotal = 0
        for i = 1, total 
        do 
            -- get info
            local name, rank, rankIndex, level, class, zone, note, officernote, online, onlineText, status, classFileName = GuildAdmin:getGuildMemberInfo(i)
            if online
            then
                onlineTotal = onlineTotal + 1
            else
                offlineTotal = offlineTotal + 1
            end
        end
        return onlineTotal, offlineTotal, total
    else
        return 0, 0, 0
    end               
end
-- ==============================================================================

-- ##############################################################################
-- Recruiting section
-- ##############################################################################

--- This will implicitly fire the WHO_LIST_UPDATE
-- Sets the filter criteria and does a SendWho
function GuildAdmin:FireWhoList()

    local filter = ""
    -- prepare filter as defined
    if GuildAdmin.RecruitCurZone
    then
        filter = filter.."z-"..'"'..GetZoneText()..'" '
    end    
     
    if (GuildAdmin.RecruitClassDefault ~= "ALLCLASSES")
    then
        filter = filter.."c-"..'"'..GuildAdmin.RecruitClasses[GuildAdmin.RecruitClassDefault]..'" ' 
    end

    if ((GuildAdmin.RecruitMinLvl > 0) or
        (GuildAdmin.RecruitMaxLvl < GuildAdmin:getMaxLevel())
       )
    then    
        filter = filter..tostring(GuildAdmin.RecruitMinLvl).."-"..tostring(GuildAdmin.RecruitMaxLvl)
    end

    -- get current data
    local numWhos, totalCount = GetNumWhoResults()
    
    -- check sort and fire sort if necessary
    if GuildAdmin.CurWhoNeedsGuildSort
    then
        GuildAdmin.CurWhoNeedsGuildSort = false
        GuildAdmin.CurWhoListRdy = GuildAdmin.CurWhoListRdy + 1   
        SortWho("Guild")
    end    

    -- mark it as our request
    GuildAdmin.CurWhoListRdy = GuildAdmin.CurWhoListRdy + 1   
    -- send request 
    SetWhoToUI(true)
    SendWho(filter)
    
end
-- ==============================================================================

--- checks if the RecruitCurWho entry is valid
-- and gives a sound and warning on the chat frame
--
-- @return IsValid  Boolean - true if valid, false if not
function GuildAdmin:IsCurWhoValid()

    local isValid = true
    if ((GuildAdmin.CurWho == nil) or
        (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers) or
        (string.len(GuildAdmin.CurWho) < 1)
       ) 
    then
        PlaySound("ReadyCheck")
        DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("no player selected"), "RED"))
        isValid = false
    end
    return isValid

end
-- ==============================================================================

--- checks if the RecruitCurWho is now a guild member
--
function GuildAdmin:IsCurWhoGuild()

    local isValid = true
    if (not GuildAdmin:IsCurWhoValid()) 
    then
        isValid = false
        return
    end         

    GuildRoster()
    local member, dbKey, rank = GuildAdmin:GetGuildMembersDb(GuildAdmin.CurWho, "rank")
    -- selected curwho not in guild - no name available    
    if ( rank == nil)
    then
        isValid = false
    end
    GuildAdmin.RecruitCurInvited = GuildAdmin.CurWho
    return isValid    
    
end
-- ==============================================================================

--- checks if the RecruitText entry to inspect is valid
-- and gives a sound and warning on the chat frame
--
-- @param text      String - the recruiting text to validate
-- @param warning   String - the locale string for the warning to add to chatframe
-- @return IsValid  Boolean - true if valid, false if not
function GuildAdmin:IsRecruitTextValid(text, warning)

    local isValid = true
    if ((text == nil) or
        (string.len(text) == 0)
       )
    then
        PlaySound("ReadyCheck")
        DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale(warning), "RED"))
        isValid = false
    end
    return isValid

end
-- ==============================================================================

--- checks if the player can invite other players to guild
-- and gives a sound and warning on the chat frame
--
-- @param warning   String - the locale string for the warning to add to chatframe
-- @return IsValid  Boolean - true if able to invite, false if not
function GuildAdmin:CanInvite(warning)

    local isValid = true
    if (not CanGuildInvite())
    then
        PlaySound("ReadyCheck")
        DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale(warning), "RED"))
        isValid = false
    end
    return isValid

end
-- ==============================================================================

--- checks if a recruit text is longer than the given length
-- and gives a sound and warning on the chat frame if too long
--
-- @param  text      String - the text to check
-- @param  length    Integer - the max length which is allowed for the given text
-- @param  warning   String - the locale string for the warning to add to chatframe
-- @return newText   String - the original text shortened to given length
function GuildAdmin:CheckText(text, length, warning)

    local newText = text
    if (string.len(text) > length)
    then
        PlaySound("ReadyCheck")
        DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale(warning), "RED"))
        newText = string.sub(text, 1, length)
    end
    return newText

end
-- ==============================================================================

--- Checks if who list is sorted by guild in the correct order
-- As there is the chance that no one without guild is online
-- this check is not 100% proofed. It looks, if first who entry has 
-- a guild name, and if so, returns true
-- @return Boolean - true, if the first entry in who list is member of a guild otherwise false
function GuildAdmin:NeedWhoListSort()

    local needSort = false
    local numWhos, totalCount = GetNumWhoResults()

    if (totalCount > 0)
    then
        local name, guildname, level, race, class, zone, classFileName = GetWhoInfo(1)
        needSort = ((guildname ~= nil) or (string.len(guildname) > 0))
    end
    
    return needSort

end
-- ##############################################################################
-- Generic section
-- ##############################################################################

--- Guarantee that string is returned
-- Returns a string no matter what type the variable is (also nil handling)
-- @param var Any type of variable
-- @return string The string produced out of the variable or text from locale "Not Available"
function GuildAdmin:getValidString(var)

    if (var and (string.len(tostring(var)) > 0))
    then
        return tostring(var)
    else
        return GuildAdmin:myLocale("Not Available")
    end     

end
-- ==============================================================================

--- Split money into gold, silver and copper
-- 
-- @param copper Integer - the amount of money in copper (positive number - otherwise returns nil)
-- @return gold Integer - the amount of gold contained in money
-- @return silver Integer - the amount of silver remained in money after discounting gold
-- @return rest Integer - the amount of copper remained in money after discounting gold and silver
function GuildAdmin:splitMoney(copper)

    if (copper >= 0) then
        local gold   = floor(copper / (SILVER_PER_GOLD * COPPER_PER_SILVER))
        local silver = floor((copper - (gold * SILVER_PER_GOLD * COPPER_PER_SILVER)) / COPPER_PER_SILVER)
        local rest   = mod(copper, COPPER_PER_SILVER);
        return gold, silver, rest;
     end
end
-- ==============================================================================

--- compares the saved login times and checks if it is time to reset invited
-- doesn't handle logout at 24:00 and login shortly after
function GuildAdmin:TimeToReset()
    if (GuildAdmin.db.char.GameOptions.loginTime.year > GuildAdmin.db.char.GameOptions.lastLogoffTime.year)
    then
        return true
    end
    if (GuildAdmin.db.char.GameOptions.loginTime.month > GuildAdmin.db.char.GameOptions.lastLogoffTime.month)
    then
        return true
    end
    if (GuildAdmin.db.char.GameOptions.loginTime.day > GuildAdmin.db.char.GameOptions.lastLogoffTime.day)
    then
        return true    
    end   
    if (GuildAdmin.db.char.GameOptions.loginTime.hour > (GuildAdmin.db.char.GameOptions.lastLogoffTime.hour + GuildAdmin.WaitHourInviteReset))
    then
        return true    
    end
    return false
end        