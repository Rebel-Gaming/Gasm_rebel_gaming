-- $LastChangedRevision: 63 $ / $LastChangedDate: 2009-10-12 16:03:59 +0000 (Mon, 12 Oct 2009) $ / $LastChangedBy $

--- Provides the presentation layer
-- Mainly contains function to do or format things for output on the screen
-- @class file
-- @name privateLibs/GuildAdminView

-- ##############################################################################
-- Tooltip section
-- ##############################################################################

--- Formats the text to be displayed on the broker object
-- The color display changes on the amount of active 
-- guild members or if player is in a guild.
--
-- If player is not in a guild than the text is displayed in WHITE.
-- If only one member (typical bank guild), the text is displayed 
-- in GREY.
-- 
-- If equal to or more than 50% of guild members are online, online count
-- is displayed in GREEN and offline count in WHITE.
-- Otherwise online count is shown in WHITE and offline count
-- is shown in RED.
function GuildAdmin:getBrokerText()
    
    -- update quild information
    GuildAdmin:updateGuildInfo()

    -- should be overwritten otherwise a real error occured 
    local displaytext = "Error"
    
    if (GuildAdmin.guildMembersTotal == 0)
    then
        -- no guild
        displaytext = GuildAdmin:getColoredText(GuildAdmin:myLocale("No guild"), "WHITE")

    elseif (GuildAdmin.guildMembersTotal == 1)
    then
        -- a bank guild - only one member
        displaytext = GuildAdmin:getColoredText("1/1/1", "GREY")       

    else
        if (GuildAdmin.guildMembersOn >= GuildAdmin.guildMembersOff)
        then
            displaytext = GuildAdmin:getColoredText(GuildAdmin.guildMembersOn, "GREEN").."/"..GuildAdmin:getColoredText(GuildAdmin.guildMembersOff, "WHITE").."/"..GuildAdmin:getColoredText(GuildAdmin.guildMembersTotal, "GOLD")            
        else
            displaytext = GuildAdmin:getColoredText(GuildAdmin.guildMembersOn, "WHITE").."/"..GuildAdmin:getColoredText(GuildAdmin.guildMembersOff, "RED").."/"..GuildAdmin:getColoredText(GuildAdmin.guildMembersTotal, "GOLD")            
        end
    end    
    
    return displaytext 
    
end
-- ==============================================================================

--- Set the tooltip button text to display
-- Sets LDB_obj.text = guild member counts online/offline/total
--
-- @param broker Table - the LDB object to use
function GuildAdmin:setTooltipText(broker)
    broker.text = GuildAdmin:getBrokerText()
end
-- ==============================================================================

--- Responsible for displaying the tooltip header
-- @param GuildAdminTooltip Table - the object containing a GameTooltip object
function GuildAdmin:getTooltipHeader(GuildAdminTooltip)
    -- only execute if GuildAdminTooltip is valid
    if (GuildAdminTooltip == nil) then return end

    if (IsInGuild())
    then
        -- fill only 2 cells - info text and guild name put to cols 2 and 4 to avoid excessive spacing by guild name
        GuildAdminTooltip:AddLine(" ",
                                  GuildAdmin:getColoredText(GuildAdmin:myLocale("Guild")..":", "GOLD"),
                                  " ",
                                  " ",
                                  GuildAdmin:getColoredText(GetGuildInfo("player"), "GREEN")
                                 )
        GuildAdminTooltip:AddLine()                         
        -- list titles                          
        GuildAdminTooltip:AddLine(GuildAdmin:getColoredText(GuildAdmin:myLocale("Level"),"WHITE"),
                                  GuildAdmin:getColoredText(GuildAdmin:myLocale("Name"),"WHITE"),
                                  GuildAdmin:getColoredText(GuildAdmin:myLocale("Class"),"WHITE"),
                                  GuildAdmin:getColoredText(GuildAdmin:myLocale("Rank"),"WHITE"),
                                  GuildAdmin:getColoredText(GuildAdmin:myLocale("Zone"),"WHITE"),
                                  GuildAdmin:getColoredText(GuildAdmin:myLocale("Note"),"WHITE"),
                                  GuildAdmin:getColoredText(GuildAdmin:myLocale("Officer Note"),"WHITE"),
                                  GuildAdmin:getColoredText(GuildAdmin:myLocale("Online Status"),"WHITE"),
                                  GuildAdmin:getColoredText(GuildAdmin:myLocale("Player Status"),"WHITE")
                                 )               
    else
        -- no guild info to display
        GuildAdminTooltip:AddLine(GuildAdmin:getColoredText(GuildAdmin:myLocale("No Guild Info"), "GREY"))
    end
end
-- ==============================================================================
    
--- Responsible to display the tooltip guild members list
-- Does formatting and executing AddLine on the tooltip object
-- Shows guild members in respect of the choosen flag in the guild tab (show online/offline)
--
-- @param tooltip Table - the tooltip object itself
function GuildAdmin:getToolTipDisplayList(tooltip)

    -- only execute, if guild is available
    if (not IsInGuild()) then return end
    -- only execute if tooltip is available
    if (tooltip == nil) then return end

    local txtClass, txtOnline, txtOffNote, txtStatus 
    local name, rank, rankIndex, level, class, zone, note, officernote, online, onlineText, status, classFileName
    local classTextColor
    
    -- update counts in existing variables in case they are not initialized yet
    GuildAdmin.guildMembersOn, GuildAdmin.guildMembersOff, GuildAdmin.guildMembersTotal = GuildAdmin:getGuildMemberCounts()
    
    -- create all the lines in the tooltip
    for i = 1, GuildAdmin.guildMembersTotal 
    do 
        -- get info
        name, rank, rankIndex, level, class, zone, note, officernote, online, onlineText, status, classFileName = GuildAdmin:getGuildMemberInfo(i)

        -- sync the display with tHE setting of showing online/offline members
        if GetGuildRosterShowOffline()
        then
            -- don't care - show everything
            
            -- prepare display strings
            -- do coloring on class
            if ( classFileName ~= GuildAdmin:myLocale("Not Available")) 
            then
                txtClass = GuildAdmin:getColoredText(class, classFileName)
            else
                txtClass = GuildAdmin:getColoredText(class, "GREY")
            end
    
            if online
            then
                txtOnline = GuildAdmin:getColoredText(onlineText, "GREEN")
            else
                txtOnline = GuildAdmin:getColoredText(onlineText, "GREY")
            end
    
            -- add line depending on rights        
            if CanViewOfficerNote()
            then
                txtOffNote = GuildAdmin:getColoredText(officernote, "GOLD")
            else
                txtOffNote = GuildAdmin:myLocale("Not Available")
            end
            
            if (status == GuildAdmin:myLocale("Not Available"))
            then
                if online
                then 
                   txtStatus = GuildAdmin:getColoredText(GuildAdmin:myLocale("Active"), "TEAL")
                else
                   txtStatus = GuildAdmin:getColoredText(status, "GREY")
                end    
            else    
                txtStatus = GuildAdmin:getColoredText(status, "TEAL")
            end
                
            tooltip:AddLine(GuildAdmin:getColoredText(("["..level.."]"), "ORANGE"),
                            GuildAdmin:getColoredText(name, "GREEN"),
                            txtClass,
                            GuildAdmin:getColoredText(rank, "GREEN"),
                            GuildAdmin:getColoredText(zone, "BEIGE"),
                            GuildAdmin:getColoredText(("("..note..")"), "WHITE"),
                            txtOffNote,
                            txtOnline,
                            txtStatus
                           ) 
        else
            -- show only online members
            if online
            then
                -- prepare display strings
                -- do coloring on class
                if ( classFileName ~= GuildAdmin:myLocale("Not Available")) 
                then
                    txtClass = GuildAdmin:getColoredText(class, classFileName)
                else
                    txtClass = GuildAdmin:getColoredText(class, "GREY")
                end
        
                if online
                then
                    txtOnline = GuildAdmin:getColoredText(onlineText, "GREEN")
                else
                    txtOnline = GuildAdmin:getColoredText(onlineText, "GREY")
                end
        
                -- add line depending on rights        
                if CanViewOfficerNote()
                then
                    txtOffNote = GuildAdmin:getColoredText(officernote, "GOLD")
                else
                    txtOffNote = GuildAdmin:myLocale("Not Available")
                end
                
                if (status == GuildAdmin:myLocale("Not Available"))
                then 
                    txtStatus = GuildAdmin:getColoredText(GuildAdmin:myLocale("Active"), "TEAL")
                else    
                    txtStatus = GuildAdmin:getColoredText(status, "TEAL")
                end
                    
                tooltip:AddLine(GuildAdmin:getColoredText(("["..level.."]"), "ORANGE"),
                                GuildAdmin:getColoredText(name, "GREEN"),
                                txtClass,
                                GuildAdmin:getColoredText(rank, "GREEN"),
                                GuildAdmin:getColoredText(zone, "BEIGE"),
                                GuildAdmin:getColoredText(("("..note..")"), "WHITE"),
                                txtOffNote,
                                txtOnline,
                                txtStatus
                               ) 
            end
        end                
    end
end
-- ==============================================================================

--- This function displays the guild info and changes on system start
-- It checks if guild info has been shown already (default at start is false)
-- and shows the info, if configured and not shown yet
function GuildAdmin:ShowGuildInfo()

    local dummy, dummy2, show = GuildAdmin:GetCharDb("GameOptions", "showGuildInfo")

    if ((not GuildAdmin.GuildInfoShown) and show)
    then    
        GuildInfo()
        GuildAdmin.GuildInfoShown = true
        GuildAdmin:ShowGuildChanges()
    end    
end
-- ==============================================================================

--- Fetches the guild changes and displays it in the chat frame
function GuildAdmin:ShowGuildChanges()

    -- get changes
    local changes, gone, newbies, numGone, numNew, levelCur, levelOld, numLevelUp, rankCur, rankOld, numRankNew, brandNew = GuildAdmin:GetGuildChanges()

    -- display them
    if brandNew
    then
        -- only total for registered players
        DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("Application Short Name")..": ","YELLOW")..GuildAdmin:getColoredText(GuildAdmin:myLocale("members registered")..tostring(numNew), "GREEN"))
    else
        
        if changes
        then
            if (numGone > 0)
            then
            
                DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("Application Short Name")..": ","YELLOW")..GuildAdmin:getColoredText(GuildAdmin:myLocale("members gone")..tostring(numGone),"RED"))
                for dummy, name in pairs(gone) 
                do
                    DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("Application Short Name")..": ","YELLOW")..GuildAdmin:getColoredText(name.." "..GuildAdmin:myLocale("has left the guild"), "RED"))
                end
                
            end
    
            if (numNew > 0)
            then
        
                DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("Application Short Name")..": ","YELLOW")..GuildAdmin:getColoredText(GuildAdmin:myLocale("new members")..tostring(numNew),"GREEN"))
    
                for dummy, name in pairs(newbies) 
                do
                    DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("Application Short Name")..": ","YELLOW")..GuildAdmin:getColoredText(name.." "..GuildAdmin:myLocale("has joined the guild"), "GREEN"))
                end
    
            end
            
            if (numLevelUp > 0)
            then
            
                DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("Application Short Name")..": ","YELLOW")..GuildAdmin:getColoredText(GuildAdmin:myLocale("level changes")..tostring(numLevelUp),"GREEN"))
                for name, level in pairs(levelCur) 
                do
                    DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("Application Short Name")..": ","YELLOW")..GuildAdmin:getColoredText(GuildAdmin:myLocale("level change").." "..name..": "..tostring(level).." ("..tostring(levelOld[name])..")", "GREEN"))
                end
                
            end
            
            if (numRankNew > 0)
            then
                
                DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("Application Short Name")..": ","YELLOW")..GuildAdmin:getColoredText(GuildAdmin:myLocale("rank changes")..tostring(numRankNew),"TEAL"))
                for name, rank in pairs(rankCur) 
                do
                    DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("Application Short Name")..": ","YELLOW")..GuildAdmin:getColoredText(GuildAdmin:myLocale("rank change").." "..name..": "..rank.." ("..rankOld[name]..")", "TEAL"))
                end
                
            end
        
        else
        
            DEFAULT_CHAT_FRAME:AddMessage(GuildAdmin:getColoredText(GuildAdmin:myLocale("Application Short Name")..": ","YELLOW")..GuildAdmin:getColoredText(GuildAdmin:myLocale("No changes"),"GREY"))
        
        end
    end
end
-- ==============================================================================

--- Give out text from relations console on selected channel
--
-- @param text      String the text to send to the chat channel
-- @param type      String the type index of the chat channel 
-- @param player    String the name of the selected player or nil
function GuildAdmin:Say(text, type, player)

    if (text ~= nil)
    then
        local chatMsg = text 
        -- format string, if player is given
        
        if (player ~= nil)
        then
            chatMsg = string.format(chatMsg, player)
        end    
        SendChatMessage(chatMsg, type, nil, player)
    end    
end
-- ==============================================================================
