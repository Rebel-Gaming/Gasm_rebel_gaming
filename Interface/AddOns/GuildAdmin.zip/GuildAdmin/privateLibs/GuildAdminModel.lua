-- $LastChangedRevision: 84 $ / $LastChangedDate: 2009-10-14 19:44:53 +0000 (Wed, 14 Oct 2009) $ / $LastChangedBy $

--- Provides the data layer.
-- You will find here a plenty amount of getter/setter functions which
-- mainly are intended to give better maintainability in case the WOW API
-- changes
--
-- @class file
-- @name privateLibs/GuildAdminModel

-- ##############################################################################
-- Guild data section
-- ##############################################################################

--- Updates all stored guild infos
function GuildAdmin:updateGuildInfo()

    -- depending on RosterShowOffline the numbers change, but flag reset can't be done in this function
    -- as it causes problems when displaying the guild frame from Blizzard
    
    -- update counters
    GuildAdmin.guildMembersOn, GuildAdmin.guildMembersOff, GuildAdmin.guildMembersTotal = GuildAdmin:getGuildMemberCounts()
    
    -- update database
        
end
-- ==============================================================================

--- Return and update guild member information
--
-- Returns the guild information for all members
-- and stores or updates the database informations on guild members.
--
-- @usage name, rank, rankIndex, level, class, zone, note, officernote, online, onlineText, status, classFileName = GuildAdmin:getGuildMemberInfo(index)
--
-- @param index The index in the member list as given by GetNumGuildMembers(true)
-- @return name String - The name of one member of the guild 
-- @return rank String - The member's rank in the guild ( Guild Master, Member ...) 
-- @return rankIndex Number - The number corresponding to the guild's rank. The Rank Index starts at 0, add 1 to correspond with the index used in GuildControlGetRankName(index) 
-- @return level Number - The level of the player. 
-- @return class String - The class (Mage, Warrior, etc) of the player. 
-- @return zone String - The position of the player ( or the last if he is off line ) 
-- @return note String - Returns the character's public note if one exists, returns "" if there is no note or the current player does not have access to the public notes 
-- @return officernote String - Returns the character's officer note if one exists, returns "" if there is no note or the current player does not have access to the officer notes 
-- @return online Return 1 if the player is online, else it's nil 
-- @return onlineText Returns the existing locale representation of online/offline 
-- @return status The availability of the player; may be "<AFK>", "<DND>", or "" for no special status. (Introduced in patch 1.9) 
-- @return classFileName Upper-case English classname - localisation independant. 
function GuildAdmin:getGuildMemberInfo(index)

    local onlineText

    local name, rank, rankIndex, level, class, zone, note, officernote, online, status, classFileName = GetGuildRosterInfo(index);

    if online
    then
        onlineText = GuildAdmin:myLocale("Online")
    else
        onlineText = GuildAdmin:myLocale("Offline")
    end    
        
    return GuildAdmin:getValidString(name), 
           GuildAdmin:getValidString(rank), 
           rankIndex, 
           GuildAdmin:getValidString(level), 
           GuildAdmin:getValidString(class), 
           GuildAdmin:getValidString(zone), 
           GuildAdmin:getValidString(note), 
           GuildAdmin:getValidString(officernote), 
           online, 
           GuildAdmin:getValidString(onlineText), 
           GuildAdmin:getValidString(status), 
           GuildAdmin:getValidString(classFileName)

end
-- ==============================================================================

---Set basic variables for this addon.
-- Vars are directly attached to GuildAdmin
function GuildAdmin:SetVars()

    GuildAdmin:SetPlayerName(GuildAdmin:GetPlayerName())
    GuildAdmin:SetRealm(GuildAdmin:GetRealmName())
    GuildAdmin:SetFaction(GuildAdmin:GetFactionName())
    GuildAdmin:SetLocalizedFaction(GuildAdmin:GetLocalizedFactionName())
    GuildAdmin:SetGuildMoney(GuildAdmin:GetGuildMoney())  
    GuildAdmin.db.char.GameOptions.loginTime = date("*t")
    if (GuildAdmin.db.char.GameOptions.lastLogoffTime == nil)
    then
        GuildAdmin.db.char.GameOptions.lastLogoffTime = GuildAdmin.db.char.GameOptions.loginTime
    end
end
-- ==============================================================================

---Set basic guild variables for this addon.
-- Vars are directly attached to GuildAdmin. Do not run before addon is fully initialized
function GuildAdmin:SetGuildVars()

    local dummy, dummy2
    
    -- run update of data structure if necessary
    GuildAdmin:Update3bto3c()
    GuildAdmin:Update3eto3f()
    
    -- get current default value
    dummy, dummy2, GuildAdmin.RecruitShowContacted = GuildAdmin:GetGuildDb("Recruiting", "IncludeContacted")
    dummy, dummy2, GuildAdmin.RecruitSetIntroDefault = GuildAdmin:GetGuildDb("Recruiting", "SetIntroDefault")
    dummy, dummy2, GuildAdmin.RecruitSetDetailsDefault = GuildAdmin:GetGuildDb("Recruiting", "SetDetailsDefault")
    dummy, dummy2, GuildAdmin.RecruitSetByeDefault = GuildAdmin:GetGuildDb("Recruiting", "SetByeDefault")
    dummy, dummy2, GuildAdmin.RecruitSetWelcomeDefault = GuildAdmin:GetGuildDb("Recruiting", "SetWelcomeDefault") 
    dummy, dummy2, GuildAdmin.RecruitSetWelcomeDetailsDefault = GuildAdmin:GetGuildDb("Recruiting", "SetWelcomeDetailsDefault")
    dummy, dummy2, GuildAdmin.RecruitShowRefused = GuildAdmin:GetGuildDb("Recruiting", "IncludeRefused")
    dummy, dummy2, GuildAdmin.RelationsCurTalkType = GuildAdmin:GetGuildDb("Recruiting", "RelationsTalkType")
    dummy, dummy2, GuildAdmin.RelationsSetTalkDefault = GuildAdmin:GetGuildDb("Recruiting", "SetTalkDefault")

    -- reset old invited flags on relog
    if GuildAdmin:TimeToReset()
    then
        GuildAdmin:ResetInvited()   
    end
end
-- ==============================================================================

--- Updates the guild database in the global section. 
-- Do not execute this function before GuildAdmin:IsGuildInfoAvailable() == true
-- currently event handling should take care about this
-- 
-- @param charMode  Boolean - if true or set it updates also the char section with guild information
function GuildAdmin:UpdateGuildsDatabase(charMode)
 
    local updateChar = false
    if charMode
    then
        updateChar = true
    end
        
    local name, rank, rankIndex, level, class, zone, note, officernote, online, onlineText, status, classFileName
    local dummy, dummy2, rankContacted
    local curGuildMembers, gone = {}, {}

    -- this is a common variable which should be set in SetVars, but due to late 
    -- loading of guild information by Wow it has to remain here, so the value
    -- returns something reasonable
    GuildAdmin:SetGuildName(GuildAdmin:GetCurrentGuildName())
    
    if IsInGuild()
    then
        -- update guild data
        GuildAdmin:SetGuildsDb("guildmoney", GuildAdmin:GetGuildMoney())
        GuildAdmin:SetGuildsDb("faction", GuildAdmin:GetLocalizedFactionName())
        
        local dbKey, maxMembers, key1, key2 = GuildAdmin:SetGuildsDb("membersTotal", GuildAdmin:GetGuildMembersTotal())
        
        if updateChar
        then
            -- update char data
            GuildAdmin:SetCharDb("Guild", "membersTotal", maxMembers)
            GuildAdmin:SetCharDb("Guild", "guildmoney", GuildAdmin:GetGuildMoney())
        end
        
        --now loop through guild members
        for i = 1, maxMembers 
        do 
            -- get info
            name, rank, rankIndex, level, class, zone, note, officerNote, online, onlineText, status, classFileName = GuildAdmin:getGuildMemberInfo(i)

            -- update curGuildMembers table to identify members left
            curGuildMembers[name] = true
            
            -- check if new member and in Contacted list
            dummy, dummy2, rankContacted = GuildAdmin:GetGuildMembersDb(name, "rank")
            -- selected name not in guild list - no rank available    
            if ( rankContacted == nil)
            then
                -- update joinedGuild flag
                GuildAdmin:SetContactedDb(name, "joinedGuild", true)    
            end
            
            -- add  0 or set value if not initialized yet
            GuildAdmin:SetGuildMembersAddDb("guildBankGet", 0, name)
            GuildAdmin:SetGuildMembersAddDb("guildBankPut", 0, name)

            -- set retrieved information
            GuildAdmin:SetGuildMembersDb("rank", rank, name)
            GuildAdmin:SetGuildMembersDb("rankIndex", rankIndex, name)
            GuildAdmin:SetGuildMembersDb("note", note, name)

            -- update only, if this char is able to see the officer note for the guild
            if CanViewOfficerNote()
            then
                GuildAdmin:SetGuildMembersDb("officerNote", officerNote, name)
            end        

            -- update global.Relations[Relam::Faction].Chars section with values from guild list
            GuildAdmin:SetGuildCharsDb("level", level, name)
            GuildAdmin:SetGuildCharsDb("class", class, name)
            GuildAdmin:SetGuildCharsDb("classFileName", classFileName, name)
            
            if updateChar
            then
                -- update players guild data for delta
                GuildAdmin:SetCharGuildDb("rank", rank, name)
                GuildAdmin:SetCharGuildDb("rankIndex", rankIndex, name)
                GuildAdmin:SetCharGuildDb("note", note, name)
                GuildAdmin:SetCharGuildDb("level", level, name)
            end
                        
        end        
        
        -- guild dependend alt settings
        GuildAdmin:SetAltsDb("guildName", GuildAdmin:GetCurrentGuildName(), GuildAdmin:GetPlayerName())
        GuildAdmin:SetAltsDb("canViewOfficerNote", canViewOfficerNote, GuildAdmin:GetPlayerName())    
    end      

    -- now check for members left
    for name, value in pairs(GuildAdmin.db.global.Guilds[GuildAdmin:GetCurrentGuildsKey()].guild[GuildAdmin:GetCurrentGuildName()].members)
    do
        if (curGuildMembers[name] == nil)
        then
            table.insert(gone, name)
            -- update leftGuild flag
            GuildAdmin:SetContactedDb(name, "leftGuild", true)    
            GuildAdmin:SetContactedDb(name, "guildLeft", GuildAdmin:GetCurrentGuildName())
        end    
    end
    -- delete names from GuildAdmin.db.global.Guilds[GuildAdmin:GetCurrentGuildsKey()].guild[GuildAdmin:GetCurrentGuildName()].members
    for dummy, name in pairs(gone)
    do
        GuildAdmin.db.global.Guilds[GuildAdmin:GetCurrentGuildsKey()].guild[GuildAdmin:GetCurrentGuildName()].members[name] = nil
    end

    -- update public note
    GuildAdmin:SetPublicNote()
    
    -- update generic data of alt in global.Alts section
    GuildAdmin:SetAltsDb("level", GuildAdmin:getLevel(UnitId), GuildAdmin:GetPlayerName())
    GuildAdmin:SetAltsDb("class", GuildAdmin:getClass(), GuildAdmin:GetPlayerName())
    GuildAdmin:SetAltsDb("classFileName", GuildAdmin:getClass(nil, true), GuildAdmin:GetPlayerName())
end
-- ==============================================================================

--- Updates friends database
function GuildAdmin:UpdateFriendsDatabase()

    -- get old friends and mark them as no friends anymore
    for friend, value in pairs(GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Friends)
    do
        GuildAdmin:SetFriendsDb(friend, false, "isStillFriend")
    end

    local name, level, class, area, connected, status, note
    
    for i = 1, GetNumFriends()
    do
        name, level, class, area, connected, status, note = GetFriendInfo(i)
        if (note ~= nil)
        then
            GuildAdmin:SetFriendsDb(name, note, "friendsNote")
        end
        -- still friends, so mark it
        GuildAdmin:SetFriendsDb(name, true, "isStillFriend")
        
        if connected
        then
           -- update char details
            GuildAdmin:SetGuildCharsDb("level", level, name)
            GuildAdmin:SetGuildCharsDb("class", class, name)
        end    
    end
    
end
-- ==============================================================================

-- ##############################################################################
-- Setter section
-- ##############################################################################
---This will set the GuildAdmin CurrentChar variable
-- with player name
--
-- @param name String - the name of the player to set
-- @return name String - the name of the player that has been set
--              This value is provided to pass the action to another setter 
function GuildAdmin:SetPlayerName(name)
    GuildAdmin.CurrentChar = name
    return name
end
-- ==============================================================================

---This will set the GuildAdmin CurrentRealm variable
-- with realm name
--
-- @param realm String - the name of the realm to set
-- @return realm String - the name of the realm that has been set
--               This value is provided to pass the action to another setter 
function GuildAdmin:SetRealm(realm)
    GuildAdmin.CurrentRealm = realm
    return realm
end
-- ==============================================================================

---This will set the GuildAdmin CurrentFaction variable
-- with english faction name
--
-- @param faction String - the name of the english faction to set
-- @return faction String - the name of the english faction that has been set
--                 This value is provided to pass the action to another setter 
function GuildAdmin:SetFaction(faction)
    GuildAdmin.CurrentFaction = faction
    return faction
end
-- ==============================================================================

---This will set the GuildAdmin CurrentLozalizedFaction variable
-- with the localized faction name if available
--
-- @param faction String - the name of the localized faction to set
-- @return faction String - the name of the localized faction that has been set
--                 This value is provided to pass the action to another setter 
function GuildAdmin:SetLocalizedFaction(faction)
    GuildAdmin.CurrentLozalizedFaction = faction
    return faction
end
-- ==============================================================================

---This will set the GuildAdmin CurrentGuildMoney variable
-- with the guild bank money amount in copper currently known
--
-- @param guildMoney Integer - the amount of money to set as known guild bank money
-- @return guildMoney Integer - the amount of money that has been set as known guild bank money
--                    This value is provided to pass the action to another setter 
function GuildAdmin:SetGuildMoney(amount)
    GuildAdmin.CurrentGuildMoney = amount
    return amount
end
-- ==============================================================================

---This will set the GuildAdmin CurrentGuild variable
--
-- @param guildName     String - the guild name to set
-- @return guilName     String - the guild name that has been set
--                      This value is provided to pass the action to another setter 
function GuildAdmin:SetGuildName(guildName)
    GuildAdmin.CurrentGuild = guildName
    return amount
end
-- ==============================================================================

---This will set any global.Guilds[GuildName][dbKey] variable
--
-- @param dbKey   String   - the db variable name in the Guilds section to use
-- @param value   Any type - the new value to set for the given db variable name in Guilds section
-- @param key1    String   - the Guilds key to use for the database access, if nil, GuildAdmin:GetCurrentGuildsKey() is called
-- @param key2    String   - the guild key to use for the database access, if nil, GuildAdmin:GetCurrentGuildName() is called
-- @return dbKey  String   - the db variable name in the Guilds section that has been used
-- @return value  Any type - the value that has been set for the given db variable name in Guilds section
-- @return key1   String   - the Guilds key used
-- @return key2   String   - the guild key used
--                This values are provided to pass the action to another setter 
function GuildAdmin:SetGuildsDb(dbKey, value, key1, key2)

    local GuildsKey = key1
    local guildKey  = key2

    if (not key1)
    then
        -- get current values to build key
        GuildsKey = GuildAdmin:GetCurrentGuildsKey()
    end

    if (not key2)
    then
        -- get current values to build key
        guildKey = GuildAdmin:GetCurrentGuildName()
    end
    
    GuildAdmin.db.global.Guilds[GuildsKey].guild[guildKey][dbKey] = value
 
    return dbKey, value, GuildsKey, guildKey
end            
-- ==============================================================================

---This will set any global.Guilds[GuildName].members[GuildMember][dbKey] variable.
-- If this is not set yet, the amount passed is set. If already set, the amount is added 
-- Consider that this feature depends on banklog scans thus the char should visit the guild bank
-- periodically, otherwise the data are not reliable
--
-- @param dbKey   String   - the db variable name in the Guilds.members section to use
-- @param value   Integer  - the new value to add to the given db variable name in Guilds.members section
-- @param key     String   - the members key to use for the database access
-- @param key1    String   - the Guilds key to use for the database access, if nil, GuildAdmin:GetCurrentGuildsKey() is called
-- @param key2    String   - the guild key to use for the database access, if nil, GuildAdmin:GetCurrentGuildName() is called
-- @return dbKey  String   - the db variable name in the Guilds section that has been used
-- @return value  Integer  - the value that has been added to the given db variable name in Guilds.members section
-- @return key    String   - the members key used
-- @return key1   String   - the Guilds key used
-- @return key2   String   - the guild key used
--                This values are provided to pass the action to another setter 
function GuildAdmin:SetGuildMembersAddDb(dbKey, value, key, key1, key2)

    local GuildsKey = key1
    local guildKey  = key2

    if (not key1)
    then
        -- get current values to build key
        GuildsKey = GuildAdmin:GetCurrentGuildsKey()
    end

    if (not key2)
    then
        -- get current values to build key
        guildKey = GuildAdmin:GetCurrentGuildName()
    end

    if (GuildAdmin.db.global.Guilds[GuildsKey].guild[guildKey].members[key][dbKey] == nil)
    then
        GuildAdmin.db.global.Guilds[GuildsKey].guild[guildKey].members[key][dbKey] = value
    else
        GuildAdmin.db.global.Guilds[GuildsKey].guild[guildKey].members[key][dbKey] = value + GuildAdmin.db.global.Guilds[GuildsKey].guild[guildKey].members[key][dbKey]
    end
    
    return dbKey, value, key, GuildsKey, guildKey
 
end            
-- ==============================================================================

---This will set any global.Guilds[GuildName].members[GuildMember][dbKey] variable
--
-- @param dbKey   String   - the db variable name in the Guilds.members section to use
-- @param value   Any type - the new value to set for the given db variable name in Guilds.members section
-- @param key     String   - the members key to use for the database access
-- @param key1    String   - the Guilds key to use for the database access, if nil, GuildAdmin:GetCurrentGuildsKey() is called
-- @param key2    String   - the guild key to use for the database access, if nil, GuildAdmin:GetCurrentGuildName() is called
-- @return dbKey  String   - the db variable name in the Guilds section that has been used
-- @return value  Any type - the value that has been set for the given db variable name in Guilds.members section
-- @return key    String   - the members key used
-- @return key1   String   - the Guilds key used
-- @return key2   String   - the guild key used
--                This values are provided to pass the action to another setter 
function GuildAdmin:SetGuildMembersDb(dbKey, value, key, key1, key2)

    local GuildsKey = key1
    local guildKey  = key2

    if (not key1)
    then
        -- get current values to build key
        GuildsKey = GuildAdmin:GetCurrentGuildsKey()
    end

    if (not key2)
    then
        -- get current values to build key
        guildKey = GuildAdmin:GetCurrentGuildName()
    end

    GuildAdmin.db.global.Guilds[GuildsKey].guild[guildKey].members[key][dbKey] = value
    
    return dbKey, value, key, GuildsKey, guildKey
 
end            
-- ==============================================================================

---This will set any global.Relations[Realm::Faction].Chars[CharName][dbKey] variable
--
-- @param dbKey   String   - the db variable name in the Chars section to use
-- @param value   Any type - the new value to set for the given db variable name in Chars section
-- @param key     String   - the Chars key to use for the database access
-- @return dbKey  String   - the db variable name in the Chars section that has been used
-- @return value  Any type - the value that has been set for the given db variable name in Chars section
-- @return key    String   - the Chars key used
--                This values are provided to pass the action to another setter 
function GuildAdmin:SetGuildCharsDb(dbKey, value, key)

    GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Chars[key][dbKey] = value
    return dbKey, value, key
 
end            
-- ==============================================================================

---This will set any global.Relations[Realm::Faction].Alts[CharName][dBKey] variable
--
-- @param dbKey      String   - the db variable name in the Alts section to use
-- @param value      Any type - the new value to set for the given db variable name in Alts section
-- @param key        String   - the Alts key to use for the database access
-- @return dbKey     String   - the db variable name in the Alts section that has been used
-- @return value     Any type - the value that has been set for the given db variable name in Alts section
-- @return key       String  - the Alts key used
--                   This values are provided to pass the action to another setter 
function GuildAdmin:SetAltsDb(dbKey, value, key)

    GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Alts[key][dbKey] = value
    return dbKey, value, key
 
end            
-- ==============================================================================

---This will set any global.Relations[Realm::Faction].Friends[CharName][dBKey] variable
--
-- @param dbKey      String   - the db variable name in the Friends section to use
-- @param value      Any type - the new value to set for the given db variable name in Friends section
-- @param key        String   - the Friends key to use for the database access
-- @return dbKey     String   - the db variable name in the Friends section that has been used
-- @return value     Any type - the value that has been set for the given db variable name in Friends section
-- @return key       String  - the Friends key used
--                   This values are provided to pass the action to another setter 
function GuildAdmin:SetFriendsDb(dbKey, value, key)

    GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Friends[key][dbKey] = value
    return dbKey, value, key
 
end            
-- ==============================================================================

---This will set any global.TooltipOptions[dBKey] variable
--
-- @param dbKey      String   - the db variable name in the TooltipOptions section to use
-- @param value      Any type - the new value to set for the given db variable name in TooltipOptions section
-- @return dbKey     String   - the db variable name in the TooltipOptions section that has been used
-- @return value     Any type - the value that has been set for the given db variable name in TooltipOptions section
--                   This values are provided to pass the action to another setter 
function GuildAdmin:SetTooltipOptionsDb(dbKey, value)

    GuildAdmin.db.global.TooltipOptions[dbKey] = value
    return dbKey, value
 
end            
-- ==============================================================================

---This will set any char[Player - Realm].[dBKey].[optionsKey] variable
--
-- @param dbKey       String   - the db variable name in the char section to use
-- @param optionsKey  String   - the db variable name in the char.[dbKey] section to use
-- @param value       Any type - the new value to set for the given db variable name in char.[dbKey].[optionsKey] section
-- @return dbKey      String   - the db variable name in the char section that has been used
-- @return optionsKey String   - the db variable name in the char.[dbKey] section that has been used
-- @return value      Any type - the value that has been set for the given db variable name in char.[dbKey].[optionsKey] section
--                    This values are provided to pass the action to another setter 
function GuildAdmin:SetCharDb(dbKey, optionsKey, value)

    GuildAdmin.db.char[dbKey][optionsKey] = value
    return dbKey, optionsKey, value
 
end            
-- ==============================================================================

--- This will set char[Player - Realm].Guild.members[index][dbKey] variable
--
-- @param dbKey       String   - the db variable name in the char.Guild.members section to use
-- @param value       Any type - the new value to set for the given db variable name in char.Guild.members[index][dbKey] section
-- @param index       String   - the db index in the char.Guild.members section to use
-- @return dbKey      String   - the db variable name in the char.Guild.members section that has been used
-- @return value      Any type - the value that has been set for the given db variable name in char.Guild.members[index][dbKey] section
-- @return index      String   - the db index in the char.Guild.members section that has been used
--                    This values are provided to pass the action to another setter 
function GuildAdmin:SetCharGuildDb(dbKey, value, index)

    GuildAdmin.db.char.Guild.members[index][dbKey] = value
    return dbKey, value, index
end
-- ==============================================================================

---This will set any char[Player - Realm].global.Guilds[Realm::Faction].guild[currentGuild][dbKey][index] variable
--
-- @param dbKey       String   - the db variable name in the global guild section to use
-- @param index       String   - the db index in the global guild[dbKey] section to use
-- @param value       Any type - the new value to set for the given db variable name in guild[currentGuild][dbKey][index] section
-- @return dbKey      String   - the db variable name in the global guild section that has been used
-- @return index      String   - the db index in the global guild[dbKey] section that has been used
-- @return value      Any type - the value of the given db variable name in guild[dbKey][index] section
--                    This values are provided to pass the action to another setter 
function GuildAdmin:SetGuildDb(dbKey, index, value)

    GuildAdmin.db.global.Guilds[GuildAdmin:GetCurrentGuildsKey()].guild[GuildAdmin:GetCurrentGuildName()][dbKey][index] = value
    return dbKey, index, value
 
 end            
-- ==============================================================================

--- This sets the public note for the current player to contain skill data
-- Requires that the member can edit his public note
-- Max length of public note seems currently 31
function GuildAdmin:SetPublicNote()
    
    local dummy, dummy2, setPublicNote = GuildAdmin:GetCharDb("GameOptions", "setPublicNote")
    
    if (CanEditPublicNote() and
        (not FriendsFrame:IsVisible()) and
        setPublicNote    
       ) 
    then
        
        local skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable 
        local stepCost, rankCost, minLevel, skillCostType, skillDescription, publicSkillNote, shortName
        local name, iconTexture, pointsSpent, background, skilledTalent
        local maxPoints = 0
        local tradeSkillHeader = false
        
        -- we have to loop through the current guild roster
        -- to find the players index
        for i = 1, GuildAdmin.guildMembersTotal 
        do 
            -- get info
            name, rank, rankIndex, level, class, zone, note, officernote, online, onlineText, status, classFileName = GuildAdmin:getGuildMemberInfo(i)
            if (name == GuildAdmin:GetPlayerName())
            then
                -- get skills
                
                for skillIndex = 1, GetNumSkillLines() 
                do
                    skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(skillIndex)
                    if isHeader 
                    then
                        if (skillName == TRADE_SKILLS)
                        then
                            tradeSkillHeader = true
                        else
                            -- header changes
                            tradeSkillHeader = false
                        end                         
                    else
                        if tradeSkillHeader
                        then
                        
                            if (string.len(skillName) > 5)
                            then
                                shortName = string.sub(skillName, 1, 5)
                            else
                                shortName = skillName
                            end
                                    
                            if not publicSkillNote
                            then
                                publicSkillNote = shortName.." "..tostring(skillRank)
                            else
                                publicSkillNote = publicSkillNote.."/"..shortName.." "..tostring(skillRank)
                            end     
                        end
                    end
                end
                
                -- get talent with max points
                for talentIndex = 1, GetNumTalentTabs()
                do
                    name, iconTexture, pointsSpent, background = GetTalentTabInfo(talentIndex)
                    
                    if (pointsSpent > maxPoints)
                    then
                        maxPoints = pointsSpent

                        if (string.len(name) > 11)
                        then
                            skilledTalent = string.sub(name, 1, 11)
                        else    
                            skilledTalent = name
                        end    
                    end    
                end                
                
                if skilledTalent
                then
                    publicSkillNote = publicSkillNote.."/"..skilledTalent
                end    
                
                if not publicSkillNote
                then
                    publicSkillNote = GuildAdmin:myLocale("Not Available")
                end    
                -- set note GetNumTalents
                GuildRosterSetPublicNote(i, publicSkillNote)
                -- end of task
                return
            end    
        end
    end
end
-- ==============================================================================

--- Sets the default recruiting text
--
-- @param text      String - the recruitment text to set
-- @param type      String - the type as section in the GuildAdmin.db
function GuildAdmin:SetDefaultRecruitingText(text, type)

    if ((text ~= nil) or
        (string.len(text) > 0)
       )
    then
        GuildAdmin:SetGuildDb("Recruiting", type, text)
    end

end
-- ==============================================================================

--- Adds or sets the contacted person to the GuildAdmin.db.global.Relations.Contacted table.
-- If name already exists, the contactedBy field is updated and contacts is
-- set to contacts + 1
-- Updates also the char details available 
--
-- @param name      String - the player name to set or add
function GuildAdmin:SetContacted(name)

    if (name ~= nil)
    then
        GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].contactedBy = GuildAdmin:GetPlayerName()
        GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].contacts = GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].contacts + 1
        
        if (GuildAdmin.CurWhoDetails[name] ~= nil)
        then
            GuildAdmin:SetGuildCharsDb("level", GuildAdmin.CurWhoDetails[name].level, name)
            GuildAdmin:SetGuildCharsDb("class", GuildAdmin.CurWhoDetails[name].class, name)
            GuildAdmin:SetGuildCharsDb("classFileName", GuildAdmin.CurWhoDetails[name].classFileName, name)
            GuildAdmin:SetGuildCharsDb("guildKey", GuildAdmin.CurWhoDetails[name].guildname, name)
        end
    end
end
-- ==============================================================================

--- Adds or sets the contacted key for a person in the GuildAdmin.db.global.Relations.Contacted table
--
-- @param name      String - the player name to set or add
-- @param key       String - the key to use in the Contacted table
-- @param value     Any type - the value to set or add for the given key
-- @return name     String - the player name to set or add
-- @return key      String - the key to use in the Contacted table
-- @return value    Any type - the value to set or add for the given key
--                  This values are provided to pass the action to another setter 
function GuildAdmin:SetContactedDb(name, key, value)

    if ((name ~= nil) and (key ~= nil))
    then
        GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name][key] = value
    end
    return name, key, value
end
-- ==============================================================================

--- Adds or sets the contacted key for a person in the GuildAdmin.db.global.Relations.Contacted.refusedGuild table
-- 
-- @param name          String - the player name to set or add
-- @param refusedKey    String - the key to use in the Contacted.refusedGuild table
-- @param key           String - the key to use in the Contacted.refusedGuild[refusedKey] table
-- @param value         Any type - the value to set or add for the given key
-- @return name         String - the player name to set or add
-- @return refusedKey   String - the key to use in the Contacted.refusedGuild table
-- @return key          String - the key to use in the Contacted.refusedGuild[refusedKey] table
-- @return value        Any type - the value to set or add for the given key
--                      This values are provided to pass the action to another setter 
function GuildAdmin:SetContactedRefusedDb(name, refusedKey, key, value)

    if ((name ~= nil) and (key ~= nil) and (refusedKey ~= nil))
    then
        GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].refusedGuild[refusedKey][key] = value
    end
    return name, refusedKey, key, value
end
-- ==============================================================================

--- Resets the contacted persons invited flag
-- 
function GuildAdmin:ResetInvited()

    for key, value in pairs(GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted)
    do
        GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[key].invited = false
    end
end
-- ==============================================================================

--- Sets the global rank flag variables
-- 
function GuildAdmin:SetCurRankFlags()

    if (GuildControlGetRankFlags() ~= nil)
    then
        -- results are at the moment unpredictable 
        local v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17 = GuildControlGetRankFlags()
    
        GuildAdmin.GuildChatListen = (v1 ~= nil) 
        GuildAdmin.GuildChatSpeak = (v2 ~= nil) 
        GuildAdmin.OfficerChatListen = (v3 ~= nil) 
        GuildAdmin.OfficerChatSpeak = (v4 ~= nil) 
        GuildAdmin.Promote = (v5 ~= nil)
        GuildAdmin.Demote = (v6 ~= nil)
        GuildAdmin.Invite = (v7 ~= nil)
        GuildAdmin.Remove = (v8 ~= nil)
        GuildAdmin.SetMotd = (v9 ~= nil)
        GuildAdmin.EditPublicNote = (v10 ~= nil) 
        GuildAdmin.ViewOfficerNote = (v11 ~= nil) 
        GuildAdmin.EditOfficerNote = (v12 ~= nil)
        GuildAdmin.ModifyGuildInfo = (v13 ~= nil)
        GuildAdmin.WithdrawRepair = (v15 ~= nil) 
        GuildAdmin.WithdrawGold = (v16 ~= nil)
        GuildAdmin.CreateGuildEvent = (v10 ~= nil)
        
        if IsInGuild()
        then
            --optimistic settings as long as rank flags are not reliable
            GuildAdmin.GuildChatSpeak = true
            GuildAdmin.OfficerChatSpeak = true 
        end
        GuildRoster()
    else
        GuildRoster()
    end
end
-- ==============================================================================
     
--- Sets the global rank flag variables
-- 
function GuildAdmin:SetTalkTypes()

    -- set TalkTypes according rights
    if GuildAdmin.OfficerChatSpeak
    then
        GuildAdmin.RelationsTalkTypes = { ["WHISPER"] = GuildAdmin:myLocale("whisper"),
                                          ["GUILD"] = GuildAdmin:myLocale("guild chat"),
                                          ["OFFICER"] = GuildAdmin:myLocale("officer chat"),
                                        }
    elseif GuildAdmin.GuildChatSpeak
    then
        GuildAdmin.RelationsTalkTypes = { ["WHISPER"] = GuildAdmin:myLocale("whisper"),
                                          ["GUILD"] = GuildAdmin:myLocale("guild chat"),
                                        }
    else
        GuildAdmin.RelationsTalkTypes = { ["WHISPER"] = GuildAdmin:myLocale("whisper"),
                                        }
    end

end
-- ==============================================================================
                              
-- ##############################################################################
-- Getter section
-- ##############################################################################

--- This will retrieve the player name.
-- If already set, it will return the saved CurrentChar from GuildAdmin
-- otherwise it uses the function
--
-- @return player String - The player name
function GuildAdmin:GetPlayerName()
    if GuildAdmin.CurrentChar
    then
        return GuildAdmin.CurrentChar
    else    
        local CurrentChar, dummy = UnitName("player")
        return CurrentChar 
    end
end
-- ==============================================================================

--- This will retrieve the realm name.
-- If already set, it will return the saved CurrentRealm from GuildAdmin
-- otherwise it uses the function
--
-- @return realm String - The realm name
function GuildAdmin:GetRealmName()
    local realm
    
    if GuildAdmin.CurrentRealm
    then
        realm = GuildAdmin.CurrentRealm
    else    
        realm = GetRealmName()
    end
    return realm
end
-- ==============================================================================

--- This will retrieve the guild name.
-- If already set, it will return the saved CurrentGuild from GuildAdmin
-- otherwise it uses the function or the locale for "No guild"
--
-- @return guild String - The guild name or the locale for "No Guild"
function GuildAdmin:GetCurrentGuildName()

    local guild, dummy, dummy2
        
    if IsInGuild()
    then
        -- always return function as the laoding process of Wow
        -- is not reliable in case of guild info
        guild = GetGuildInfo("player")
    else
        guild = GuildAdmin:myLocale("No guild")    
    end

    return guild
end
-- ==============================================================================

--- This will retrieve the english faction name.
-- If already set, it will return the saved CurrentFaction from GuildAdmin
-- otherwise it uses the function
--
-- @return faction String - The english faction name
function GuildAdmin:GetFactionName()

    local faction, dummy
    
    if GuildAdmin.CurrentFaction
    then
        faction = GuildAdmin.CurrentFaction
    else    
        faction, dummy = UnitFactionGroup("player")
    end

    return faction
end
-- ==============================================================================

--- This will retrieve the localized faction name, if available.
-- If already set, it will return the saved CurrentLozalizedFaction from GuildAdmin
-- otherwise it uses the function
--
-- @return localizedFaction String - The localized faction name if available otherwise nil
function GuildAdmin:GetLocalizedFactionName()
    if GuildAdmin.CurrentLocalizedFaction
    then
        return GuildAdmin.CurrentLocalizedFaction
    else    
        local dummy, CurrentLocalizedFaction = UnitFactionGroup("player")
        return CurrentLocalizedFaction 
    end
end
-- ==============================================================================

--- This will retrieve the guild bank money in copper.
-- If will always return the value provided by the function, as it may change
-- not like player or realm
--
-- @return guildMoney Integer - The guild bank money in copper\\
--                    If not in a guild it will return 0
function GuildAdmin:GetGuildMoney()
    if IsInGuild()
    then
        return GetGuildBankMoney()
    else
        return 0
    end        
end
-- ==============================================================================

--- This will retrieve the total of all guild members (online and offline).
-- If will always return the value provided by the function, as it may change
-- not like player or realm
--
-- @return guildMembersTotal Integer - The total of all guild members\\
--                           If not in a guild it will return 0
function GuildAdmin:GetGuildMembersTotal()
    if IsInGuild()
    then
        local dummy, dummy2, guildMembersTotal = GuildAdmin:getGuildMemberCounts()
        return guildMembersTotal 
    else
        return 0
    end    
end
-- ==============================================================================

--- This will retrieve a key for the current char to the Guilds table.
-- This table is maintained in the global section of the database. For faction, 
-- the english faction is used
--
-- @return key String - A string of the format Realm.Faction.Guildname to be used\\
--                      This can be used to access the guild section of the current\\
--                      char. If no guild, key defaults to nil
function GuildAdmin:GetCurrentGuildsKey()

    return string.format(GuildAdmin.key2format, GuildAdmin:GetRealmName(), GuildAdmin:GetFactionName())
    
end
-- ==============================================================================
--- This will retrieve a key for the current char to the Relations table.
-- This table is maintained in the global section of the database. For faction, 
-- the english faction is used
--
-- @return key String - A string of the format Realm::Faction to be used\\
--                      This can be used to access the guild section of the current\\
--                      char. If no guild, key defaults to nil
function GuildAdmin:GetCurrentRelationsKey()

    local key = nil

    key = string.format(GuildAdmin.key2format, GuildAdmin:GetRealmName(), GuildAdmin:GetFactionName())

    return key
    
end
-- ==============================================================================

--- Checks if guild name from GetGuildInfo is available.
-- If IsInGuild is true, GuildInfo should return a valid value but during initialization
-- it returns nil. If player is in no guild it returns true in any case.
--
-- @return status Boolean - true, if GetGuildInfo returns a valid name or player is in no guild
function GuildAdmin:IsGuildInfoAvailable()

    local status = false

    if IsInGuild()
    then
        local test = GetGuildInfo("player")
        local dummy, dummy2, guildMembersTotal = GuildAdmin:getGuildMemberCounts()
        if ((test ~= nil) and
            (guildMembersTotal > 0)
           ) 
        then
            status = true 
        end
    end

    if not status
    then
        -- try to force update
        GuildRoster()
    end
            
    return status

end
-- ==============================================================================

--- Wrapper for CanViewOfficerNote.
-- Checks, if any of the alts has the rights for a given guild to show the 
-- officer note. In this case any alt can view the officer note
--
-- @return Boolean - True if one of the alts is able to see the officer note for guilds
--                   that are about to be displayed
function GuildAdmin:CanViewOfficerNote()
    -- scanning the database is still to be implemented 
    return CanViewOfficerNote()
end
-- ==============================================================================

--- Wrapper for UnitLevel.
-- Get the level for a given target. If no target is given, "player" is assumed
--
-- @param UnitId String - the UnitId like "target". If nil, player is assumed
-- @return Level Integer - the level of the given target
function GuildAdmin:getLevel(UnitId)
    local unit = UnitId
    if (not unit)
    then
        unit = "player"
    end    
    return UnitLevel(unit)
end
-- ==============================================================================

--- Wrapper for UnitClass.
-- Get the class for a given target. If no target is given, "player" is assumed
--
-- @param UnitId  - String  - the UnitId like "target". If nil, "player is assumed
-- @param english - Boolean - if true returns the englishClass, otherwise the localized class
-- @return class - String - the class of the given target
function GuildAdmin:getClass(UnitId, english)
    local class 
    local unit = UnitId
    if (not unit)
    then
        unit = "player"
    end
    
    local localizedClass, englishClass = UnitClass(unit)
    
    if english
    then
        class = englishClass
    else
        class = localizedClass
    end            
    return class
end
-- ==============================================================================

---This will get any char[Player - Realm].global.Guilds[Realm::Faction].guild[currentGuild].members[member] variable
--
-- @param member      String   - the db index in the global guild.members section to use
-- @param dbKey       String   - the db variable name in the global guild.members section to use
-- @return member     String   - the db index in the global guild section that has been used
-- @return dbKey      String   - the db variable name in the global guild.members section that has been used
-- @return value      Any type - the value of the given db variable name in members[member][dbKey] section
--                    This values are provided to pass the action to another setter 
function GuildAdmin:GetGuildMembersDb(member, dbKey)

    return member, dbKey, GuildAdmin.db.global.Guilds[GuildAdmin:GetCurrentGuildsKey()].guild[GuildAdmin:GetCurrentGuildName()].members[member][dbKey]
 
 end            
-- ==============================================================================

---This will get any char[Player - Realm].global.Guilds[Realm::Faction].guild[currentGuild][dbKey][index] variable
--
-- @param dbKey       String   - the db variable name in the global guild section to use
-- @param index       String   - the db index in the global guild[dbKey] section to use
-- @return dbKey      String   - the db variable name in the global guild section that has been used
-- @return index      String   - the db index in the global guild[dbKey] section that has been used
-- @return value      Any type - the value of the given db variable name in guild[dbKey][index] section
--                    This values are provided to pass the action to another setter 
function GuildAdmin:GetGuildDb(dbKey, index)

    return dbKey, index, GuildAdmin.db.global.Guilds[GuildAdmin:GetCurrentGuildsKey()].guild[GuildAdmin:GetCurrentGuildName()][dbKey][index]
 
 end            
-- ==============================================================================

---This will get any char[Player - Realm].[dBKey].[optionsKey] variable
--
-- @param dbKey       String   - the db variable name in the char section to use
-- @param optionsKey  String   - the db variable name in the char.[dbKey] section to use
-- @return dbKey      String   - the db variable name in the char section that has been used
-- @return optionsKey String   - the db variable name in the char.[dbKey] section that has been used
-- @return value      Any type - the value of the given db variable name in char.[dbKey].[optionsKey] section
--                    This values are provided to pass the action to another setter 
function GuildAdmin:GetCharDb(dbKey, optionsKey)

    return dbKey, optionsKey, GuildAdmin.db.char[dbKey][optionsKey]
 
 end            
-- ==============================================================================

--- This will get any char[Player - Realm].Guild.members[index][dbKey] variable
--
-- @param dbKey       String   - the db variable name in the char.Guild.members section to use
-- @param index       String   - the db index in the char.Guild.members section to use
-- @return dbKey      String   - the db variable name in the char.Guild.members section that has been used
-- @return index      String   - the db index in the char.Guild.members section that has been used
-- @return value      Any type - the value for the given db variable name in char.Guild.members[index][dbKey] section
--                    This values are provided to pass the action to another setter 
function GuildAdmin:GetCharGuildDb(dbKey, index)

    return dbKey, index, GuildAdmin.db.char.Guild.members[index][dbKey]

end
-- ==============================================================================

--- This will get all guild changes since last login.
-- Therefore it compares the saved data for the current char and compares it with the
-- current guild infos
-- @return changes      Boolean - false if not changes, otherwise true
-- @return gone         Table   - a table containing all names of guild members that have left the guild
-- @return newbies      Table   - a table containing all names of new guild members
-- @return numGone      Integer - the number of guild members that have left the guild
-- @return numNew       Integer - the number of guild members that have joined the guild
-- @return levelCur     Table   - a table in form of [name].[newLevel] containing all chars with level changes and their current level
-- @return levelOld     Table   - a table in form of [name].[oldLevel] containing all chars with level changes and their former level
-- @return numLevelUp   Integer - the number of guild members that have changed their level since the last login
-- @return rankCur      Table   - a table in form of [name].[newRank] containing all chars with rank changes and their current rank
-- @return rankOld      Table   - a table in form of [name].[oldRank] containing all chars with rank changes and their former rank
-- @return numRankNew   Integer - the number of guild members that have changed their rank since the last login
-- @return brandNew     Boolean - true if database is used for the first time
function GuildAdmin:GetGuildChanges()

    local changes, new, brandNew = false, false, false
    local numGone, numNew, numLevelUp, numRankNew = 0, 0, 0, 0
    local gone, newbies, levelCur, levelOld, rankCur, rankOld = {}, {}, {}, {}, {}, {}
    local name, rank, rankIndex, level, class, zone, note, officernote, online, onlineText, status, classFileName, dummy, dummy2
    local curGuildNames = {}
    
    -- first run - check who has joined
    for i = 1, GuildAdmin.guildMembersTotal 
    do 
        -- get info
        name, rank, rankIndex, level, class, zone, note, officernote, online, onlineText, status, classFileName = GuildAdmin:getGuildMemberInfo(i)
        new = false
        
        -- safe for inspection who has left
        curGuildNames[name] = "exists"
        
        -- is name in existing char guild list? 
        if GuildAdmin.db.char.Guild.members[name]
        then
            -- exists, do we have any changes?
            -- check level
            dummy, dummy2, levelOld[name] = GuildAdmin:GetCharGuildDb("level", name)
            if (levelOld[name] ~= level)
            then
                changes = true
                
                -- handle empty database
                if (levelOld[name] == nil)
                then
                    levelOld[name] = GuildAdmin:myLocale("new")
                    new = true
                else
                    -- only count if not a new member    
                    levelCur[name] = level
                    numLevelUp     = numLevelUp + 1
                end    
            end
            
            -- check rank
            dummy, dummy2, rankOld[name] = GuildAdmin:GetCharGuildDb("rank", name)
            if (rankOld[name] ~= rank)
            then
                changes = true

                -- handle empty database
                if (rankOld[name] == nil)
                then
                    rankOld[name] = GuildAdmin:myLocale("new")
                    new = true
                else
                    -- only count if not a new member    
                    rankCur[name] = rank
                    numRankNew    = numRankNew + 1
                end    
            end
                        
            if new
            then
                -- new char, so add him to the newbies
                table.insert(newbies, name)
                GuildAdmin:SetContactedDb(name, "joinedGuild", true)
                numNew  = numNew + 1
                changes = true
            end     
        end    
    
    end

    -- second run - check who has left
    for name, dummy in pairs(GuildAdmin.db.char.Guild.members) 
    do
        -- old member also in current list?
        if (curGuildNames[name] == nil)
        then
            -- add to the people left
            table.insert(gone, name)       
            GuildAdmin:SetContactedDb(name, "leftGuild", true)
            GuildAdmin:SetContactedDb(name, "guildLeft", GuildAdmin:GetCurrentGuildName())
            numGone = numGone + 1
            changes = true
        end
    end

    -- delete names gone from GuildAdmin.db.char.Guild.members
    for dummy, name in pairs(gone)
    do
         GuildAdmin.db.char.Guild.members[name] = nil
    end

    -- check if new database by comparing numNew to total guild members
    -- in all cases except no guild, total guild members should be > 0
    brandNew = (numNew == GuildAdmin.guildMembersTotal)

    return changes, gone, newbies, numGone, numNew, levelCur, levelOld, numLevelUp, rankCur, rankOld, numRankNew, brandNew
    
end
-- ==============================================================================

--- This will get a select list with all classes and an additional ALLCLASSES=localized text entry
--
-- @return classList  Table - contains the class list in form englishClassName = localized name and 
--                    an additional entry ALLCLASSES=localized text
function GuildAdmin:GetClassSelection()

    if (not GuildAdmin.RecruitClassesLoaded)
    then
        for key, value in pairs(LOCALIZED_CLASS_NAMES_MALE)
        do
            GuildAdmin.RecruitClasses[key]=value
        end
        GuildAdmin.RecruitClassesLoaded = true
    end

    return GuildAdmin.RecruitClasses

end
-- ==============================================================================
--- This will get the relations list, including who list, if options set accordingly.
--  The status is shortened by symbols:
--      ! (yellow) invited  
--      + (green) joined guild
--      - (red) left guild
--      ? (blue) later
--      X (red) refused
--      W (green) welcomed
--      D (green) details
-- @return whoList   Table - the who list in form [PlayerName]="PlayerInfos as name, level, class, last contact, guild joined/left, invited/refused, welcomed, details, contactedBy, contacts"
function GuildAdmin:GetRelationsWhoList() 

    local charname, guildname, level, race, class, zone, classFileName, numWhos, totalCount, info, charGuild, charDetails
    local name, contactedBy, contacts, invited, leftGuild, guildLeft, joinedGuild, welcome, details, refusedGuild, later, lastContact, conClass, conLevel
    local zoneOK, classOK, welcomedOK, levelOK, whoListSet, invitedOK, includeRefused, isThisGuild, hasDetails = true, true, true, true, false, true, true, false, false
    local curWhoList = {}
    local counter = 0

    -- if all, get data from db.global.Contacted and don't care about
    if GuildAdmin.RelationsShowAll
    then
        for charname, contact in pairs(GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted)
        do
            
            info = ""
            -- test, if contact is in guild, alt and/or friend
            charGuild = GuildAdmin.db.char.Guild.members[charname]
            isThisGuild = (charGuild.level ~= nil)
            charDetails = GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Chars[charname]
            hasDetails = (charDetails.level ~= nil)

            if isThisGuild
            then
                -- get more accurate level
                info = GuildAdmin:getColoredText("["..tostring(charGuild.level).."] ", "ORANGE")

            elseif ((GuildAdmin:myLocale("Not Available") == contact.level) and hasDetails)
            then
                info = GuildAdmin:getColoredText("["..tostring(charDetails.level).."] ", "ORANGE")

            elseif (GuildAdmin:myLocale("Not Available") ~= contact.level)
            then                
                info = GuildAdmin:getColoredText("["..tostring(contact.level).."] ", "ORANGE")
            end
            
            info = info..GuildAdmin:getColoredText(charname, "GOLD").." "
            
            if (charDetails.classFileName ~= nil)
            then
                info = info..GuildAdmin:getColoredText(charDetails.class, charDetails.classFileName).." "
            
            elseif (GuildAdmin:myLocale("Not Available") ~= contact.class)
            then
                info = info..GuildAdmin:getColoredText(contact.class, "GREEN").." "
            end
            
            name, refusedKey, key, hasRefused = GuildAdmin:GetContactedRefusedDb(charname, GuildAdmin:GetCurrentGuildName(), "refused")
            
            -- if left or refused this guild overwrites other states
            if (contact.leftGuild or hasRefused)
            then
                if (contact.lastContact ~= nil)
                then
                    info = info..GuildAdmin:getColoredText(" ("..tostring(contact.lastContact["year"]).."/"..tostring(contact.lastContact["month"]).."/"..tostring(contact.lastContact["day"])..") ", "GREY")
                end            
                if contact.leftGuild
                then
                    info = info..GuildAdmin:getColoredText(" - ", "RED")
                end
                if hasRefused
                then
                    info = info..GuildAdmin:getColoredText(" X ", "RED")
                end
            else
                if (contact.lastContact ~= nil)
                then
                    info = info..GuildAdmin:getColoredText(" ("..tostring(contact.lastContact["year"]).."/"..tostring(contact.lastContact["month"]).."/"..tostring(contact.lastContact["day"])..") ", "GREY")
                end
                if isThisGuild
                then
                    info = info..GuildAdmin:getColoredText(" + ","GREEN")
                end
                if contact.invited
                then
                    info = info..GuildAdmin:getColoredText(" ! ","YELLOW")
                end
                if contact.later
                then
                    info = info..GuildAdmin:getColoredText(" ? ","BLUE")
                end
                if contact.welcome
                then
                    info = info..GuildAdmin:getColoredText(" W ","GREEN")
                end
                if contact.details
                then
                    info = info..GuildAdmin:getColoredText(" D ","GREEN")
                end
            end
            
            if (contact.contacts > 0)
            then
                info = info..GuildAdmin:getColoredText("("..tostring(contact.contactedBy).." "..tostring(contact.contacts)..")", "GREY")
                curWhoList[charname] = info
                counter = counter + 1
            end
        end
        if (counter > 0)
        then            
            whoListSet = true        
        end
    else
        -- get data
        numWhos, totalCount = GetNumWhoResults()
               
        -- set CurWho to first player, if not set yet
        if (GuildAdmin.CurWho == nil)
        then
            GuildAdmin.CurWho, guildname, level, race, class, zone, classFileName = GetWhoInfo(1)
        end
        
        for i = 1, totalCount
        do
            zoneOK, classOK, levelOK, invitedOK, welcomedOK = true, true, true, true, true
            
            charname, guildname, level, race, class, zone, classFileName = GetWhoInfo(i)
            info = GuildAdmin:getColoredText("["..tostring(level).."] ", "ORANGE")..GuildAdmin:getColoredText(charname, "GOLD").." "
    
            -- no class selected - show classes also
            if (GuildAdmin.RecruitClassDefault == "ALLCLASSES")
            then
                info = info..GuildAdmin:getColoredText(class, classFileName).." "
            else
                -- check class
                classOK = (classFileName == GuildAdmin.RecruitClassDefault)
            end
            
            -- show guild name in this list (not limited)            
            if (string.len(guildname) > 0)
            then
                info = info..GuildAdmin:getColoredText("["..guildname.."] ", "TEAL")
            end

            -- no zone selected - show zone also        
            if (not GuildAdmin.RecruitCurZone)
            then
                info = info..GuildAdmin:getColoredText(zone.." ", "GREEN")
            else
                -- check zone
                zoneOK = (zone == GetZoneText())
            end

            --check level if selected
            if ((GuildAdmin.RecruitMinLvl > 0) or
                (GuildAdmin.RecruitMaxLvl < GuildAdmin:getMaxLevel())
               )
            then    
                levelOK = ((level >= GuildAdmin.RecruitMinLvl) and (level <= GuildAdmin.RecruitMaxLvl))
            end        
            
            -- check if already contacted and should be displayed
            name, contactedBy, contacts, invited, leftGuild, guildLeft, joinedGuild, welcome, details, refusedGuild, later, lastContact, conClass, conLevel = GuildAdmin:GetContacted(charname)
            
            hasDetails = (name ~= nil)
            -- update char info that probably has changed
            if hasDetails
            then
                GuildAdmin:SetContactedDb(name, "class", class)
                GuildAdmin:SetContactedDb(name, "level", level)
            end
                                
            if GuildAdmin.RelationsInvited
            then
                invitedOK = ((name ~= nil) and invited)
            end
            
            if GuildAdmin.RelationsWelcomed
            then
                welcomedOK = ((name ~= nil) and welcome)
            end
            
            name, refusedKey, key, hasRefused = GuildAdmin:GetContactedRefusedDb(charname, GuildAdmin:GetCurrentGuildName(), "refused")
            -- if not refused for current guild then show
            includeRefused = (not hasRefused)
            
            if hasDetails
            then
                -- if left or refused this guild overwrites other states
                if (leftGuild or hasRefused)
                then
                    if (lastContact ~= nil)
                    then
                        info = info..GuildAdmin:getColoredText(" ("..tostring(lastContact["year"]).."/"..tostring(lastContact["month"]).."/"..tostring(lastContact["day"])..") ", "GREY")
                    end            
                    if leftGuild
                    then
                        info = info..GuildAdmin:getColoredText(" - ", "RED")
                    end
                    if hasRefused
                    then
                        info = info..GuildAdmin:getColoredText(" X ", "RED")
                    end
                else
                    if (lastContact ~= nil)
                    then
                        info = info..GuildAdmin:getColoredText(" ("..tostring(lastContact["year"]).."/"..tostring(lastContact["month"]).."/"..tostring(lastContact["day"])..") ", "GREY")
                    end
                    if isThisGuild
                    then
                        info = info..GuildAdmin:getColoredText(" + ","GREEN")
                    end
                    if invited
                    then
                        info = info..GuildAdmin:getColoredText(" ! ","YELLOW")
                    end
                    if later
                    then
                        info = info..GuildAdmin:getColoredText(" ? ","BLUE")
                    end
                    if welcome
                    then
                        info = info..GuildAdmin:getColoredText(" W ","GREEN")
                    end
                    if details
                    then
                        info = info..GuildAdmin:getColoredText(" D ","GREEN")
                    end
                end
                info = info..GuildAdmin:getColoredText(" ("..tostring(contactedBy).." "..tostring(contacts)..")", "GREY")
            end
                                    
            if (zoneOK and classOK and levelOK and invitedOK and welcomedOK and includeRefused)
            then
                curWhoList[charname]=info
                -- avoid 
                if (not FriendsFrame:IsShown())
                then
                    whoListSet = true
                end
            end                 

            -- add the recently invited persons to the list
            for name, contact in pairs(GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted)
            do
                if contact.invited
                then
                    curWhoList[name] = GuildAdmin:getColoredText(name.." ", "GOLD")..GuildAdmin:getColoredText("(invited by "..contact.contactedBy..")", "GREEN")
                end
            end
            
        end

    end
        
    if (not whoListSet)
    then
        GuildAdmin.CurWho = GuildAdmin.RecruitNoPlayers
        curWhoList[GuildAdmin.RecruitNoPlayers]=GuildAdmin:getColoredText(GuildAdmin:myLocale(GuildAdmin.RecruitNoPlayers), "RED")
    end
    
    return curWhoList

end
-- ==============================================================================

--- This will get the content of the current who list for recruiting console
-- as defined by the Recruit variables
-- Sets the public variable GuildAdmin.CurWhoList to contain a table with all entries found
-- 
-- @return whoList   Table - the who list in form [PlayerName]="PlayerInfos as name, level, class or zone"
function GuildAdmin:GetRecruitWhoList()

    local charname, guildname, level, race, class, zone, classFileName, numWhos, totalCount, info
    local name, contactedBy, contacts, invited, leftGuild, guildLeft, joinedGuild, welcome, details, refusedGuild, later, lastContact, conClass, conLevel
    local zoneOK, classOK, levelOK, noGuildOK, whoListSet, includeContacted, includeRefused = true, true, true, true, false, true, true
    local curWhoList = {}
    -- reset temporary curWhoDetails
    GuildAdmin.CurWhoDetails = nil
    GuildAdmin.CurWhoDetails = {}

    -- get data
    numWhos, totalCount = GetNumWhoResults()
           
    -- set CurWho to first player, if not set yet
    if (GuildAdmin.CurWho == nil)
    then
        GuildAdmin.CurWho, guildname, level, race, class, zone, classFileName = GetWhoInfo(1)
    end
    
    for i = 1, totalCount
    do
        zoneOK, classOK, levelOK, noGuildOK, includeContacted, includeRefused = true, true, true, true, true, true
        
        charname, guildname, level, race, class, zone, classFileName = GetWhoInfo(i)
        -- set curWhoDetails
        GuildAdmin.CurWhoDetails[charname] = {}
        GuildAdmin.CurWhoDetails[charname].guildname     = guildname
        GuildAdmin.CurWhoDetails[charname].level         = level
        GuildAdmin.CurWhoDetails[charname].race          = race
        GuildAdmin.CurWhoDetails[charname].class         = class
        GuildAdmin.CurWhoDetails[charname].classFileName = classFileName
        
        info = GuildAdmin:getColoredText("["..tostring(level).."] ", "ORANGE")..GuildAdmin:getColoredText(charname, "GOLD").." "

        -- no class selected - show classes also
        if (GuildAdmin.RecruitClassDefault == "ALLCLASSES")
        then
            info = info..GuildAdmin:getColoredText(class, classFileName).." "
        else
            -- check class
            classOK = (classFileName == GuildAdmin.RecruitClassDefault)
        end
        -- no zone selected - show zone also        
        if (not GuildAdmin.RecruitCurZone)
        then
            info = info..GuildAdmin:getColoredText("- "..zone, "GREEN")
        else
            -- check zone
            zoneOK = (zone == GetZoneText())
        end
        --check level if selected
        if ((GuildAdmin.RecruitMinLvl > 0) or
            (GuildAdmin.RecruitMaxLvl < GuildAdmin:getMaxLevel())
           )
        then    
            levelOK = ((level >= GuildAdmin.RecruitMinLvl) and (level <= GuildAdmin.RecruitMaxLvl))
        end        

        -- check if already contacted and should be displayed
        name, contactedBy, contacts, invited, leftGuild, guildLeft, joinedGuild, welcome, details, refusedGuild, later, lastContact, conClass, conLevel = GuildAdmin:GetContacted(charname)

        -- update char info
        if (name ~= nil)
        then
            GuildAdmin:SetContactedDb(name, "class", class)
            GuildAdmin:SetContactedDb(name, "level", level)
        end
                            
        if GuildAdmin.RecruitShowContacted
        then
            -- enhance info, if contacted or left the guild
            if leftGuild
            then
                info = info..info..GuildAdmin:getColoredText(" ("..GuildAdmin:myLocale("left guild")..guildLeft..")", "RED")
            else    
                if (contacts > 0)
                then
                    info = info..GuildAdmin:getColoredText(" ("..contactedBy..": "..tostring(contacts)..") ", "GREY")
                end
            end
        else
            -- if no contacts then show
            includeContacted = (contacts == 0)             
        end
        
        name, refusedKey, key, hasRefused = GuildAdmin:GetContactedRefusedDb(charname, GuildAdmin:GetCurrentGuildName(), "refused")
        if GuildAdmin.RecruitShowRefused
        then
            -- enhance info
            if hasRefused
            then 
                info = info..GuildAdmin:getColoredText(GuildAdmin:myLocale("refused"), "RED")
            end            
        else
            -- if not refused for current guild then show
            includeRefused = (not hasRefused)
        end
        
        noGuildOK = (string.len(guildname) == 0)
        if (zoneOK and classOK and levelOK and noGuildOK and includeContacted and includeRefused)
        then
            curWhoList[charname]=info
            -- avoid 
            if (not FriendsFrame:IsShown())
            then
                whoListSet = true
            end
        end                 
        
    end
    
    if (not whoListSet)
    then
        GuildAdmin.CurWho = GuildAdmin.RecruitNoPlayers
        curWhoList[GuildAdmin.RecruitNoPlayers]=GuildAdmin:getColoredText(GuildAdmin:myLocale(GuildAdmin.RecruitNoPlayers), "RED")
    end
    
    -- add the recently invited persons to the list
    for name, contact in pairs(GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted)
    do
        if contact.invited
        then
            curWhoList[name] = GuildAdmin:getColoredText(name.." ", "GOLD")..GuildAdmin:getColoredText("(invited by "..contact.contactedBy..")", "GREEN")
        end
    end
    
    return curWhoList
end  
-- ==============================================================================

--- This will get the first index of the given who list.
-- If who is not empty, it will check, if who is contained in list  
--
-- @param list      Table - the table with the who list
-- @param checkWho  String - the available CurWho
-- @return who  String - the first who list index, if checkWho was nil or checkWho  
function GuildAdmin:GetWho(list, checkWho)
    
    local curWho = checkWho
    if (curWho ~= nil)
    then
        -- check if value is contained in the given list
        if (list[curWho] == nil)
        then
            -- reset curWho
            curWho = nil
        end    
    end
    if ((list ~= nil) and
        (curWho == nil)
       )
    then
        for key, value in pairs(list)
        do
            curWho = key
            break
        end
    end        
    return curWho
end  
-- ==============================================================================

--- Gets default recruiting text if given text is empty
--
-- @param text      String - the recruitment text to check
-- @param type      String - the type as section in the GuildAdmin.db
-- @return newText  String - the original text or the default text, if original text was empty
function GuildAdmin:GetDefaultRecruitingText(text, type)
    local dummy, dummy2
    local newText = text
    if ((text == nil) or
        (string.len(text) == 0)
       )
    then
        dummy, dummy2, newText = GuildAdmin:GetGuildDb("Recruiting", type)
    end
    return newText   

end
-- ==============================================================================

--- Gets the contacted person from the GuildAdmin.db.global.Relations[Realm::Faction].Contacted table
-- 
-- @param name          String - the player name to get
-- @return contact      String - the name of the contacted person if exists, otherwise nil
-- @return contactedBy  String - the player name, who contacted the person, if exists, otherwise nil
-- @return contacts     Integer - the amount of contacts by using the recruiting console or 0
-- @return invited      Boolean - true if contact has been invited
-- @return leftGuild    Boolean - true if contact left the guild otherwise false
-- @return guildLeft    String - the name of the guild the player has left
-- @return joinedGuild  Boolean - true if contact joined the guild otherwise false
-- @return welcome      Boolean - true if contact has been welcomed with recruiting console
-- @return details      Boolean - true if contact has been told details with recruiting console
-- @return refusedGuild Table - contains the guilds the player refused to join
-- @return later        Boolean - true if contact wished to be contacted later
-- @return lastContact  Table - table as returned by date("*t")
-- @return class        String - localized class information, if available
-- @return level        Integer - last known level of contacted player
function GuildAdmin:GetContacted(name)
    
    if (GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].contacts == 0)
    then
        return nil, nil, 0, false, false, nil, false, false, false, nil, false, nil, nil
    end    
    return name, 
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].contactedBy, 
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].contacts, 
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].invited,
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].leftGuild, 
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].guildLeft,
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].joinedGuild,
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].welcome,
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].details,
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].refusedGuild,
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].later,
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].lastContact,
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].class,
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].level

end
-- ==============================================================================

--- Gets the contacted key for a person in the GuildAdmin.db.global.Relations.Contacted.refusedGuild table
-- 
-- @param name          String - the player name to set or add
-- @param refusedKey    String - the key to use in the Contacted.refusedGuild table
-- @param key           String - the key to use in the Contacted.refusedGuild[refusedKey] table
-- @return name         String - the player name to set or add
-- @return refusedKey   String - the key to use in the Contacted.refusedGuild table
-- @return key          String - the key to use in the Contacted.refusedGuild[refusedKey] table
-- @return value        Any type - the value of the given key or false
--                      This values are provided to pass the action to another setter 
function GuildAdmin:GetContactedRefusedDb(name, refusedKey, key)

    if (GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].contacts == 0)
    then
        return nil, nil, nil, false
    end    
    return name, 
           refusedKey, 
           key, 
           GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentRelationsKey()].Contacted[name].refusedGuild[refusedKey][key]
end
-- ==============================================================================


--- updates data structure changes from 0.0.0.3b to 0.0.0.3c
function GuildAdmin:Update3bto3c()

    if (GuildAdmin.db.global.Recruiting ~= nil)
    then
        if (GuildAdmin.db.global.Recruiting.Intro ~= nil)
        then
            GuildAdmin:SetGuildDb("Recruiting", "Intro", GuildAdmin.db.global.Recruiting.Intro)
        end
        if (GuildAdmin.db.global.Recruiting.Details ~= nil)
        then
            GuildAdmin:SetGuildDb("Recruiting", "Details", GuildAdmin.db.global.Recruiting.Details)
        end
        if (GuildAdmin.db.global.Recruiting.Bye ~= nil)
        then
            GuildAdmin:SetGuildDb("Recruiting", "Bye", GuildAdmin.db.global.Recruiting.Bye)
        end
        if (GuildAdmin.db.global.Recruiting.Welcome ~= nil)
        then
            GuildAdmin:SetGuildDb("Recruiting", "Welcome", GuildAdmin.db.global.Recruiting.Welcome)
        end
        if (GuildAdmin.db.global.Recruiting.WelcomeDetails ~= nil)
        then
            GuildAdmin:SetGuildDb("Recruiting", "WelcomeDetails", GuildAdmin.db.global.Recruiting.WelcomeDetails)
        end
        -- delete old var
        GuildAdmin.db.global.Recruiting = nil
    end
    
end

--- updates data structure changes from 0.0.0.3e to 0.0.0.3f
function GuildAdmin:Update3eto3f()
    local counter = 0
    local oldContacted = GuildAdmin.db.global.Contacted
    
    -- move contacted to new location
    -- only for the current char, leave all others untouched
    if (oldContacted ~= nil)
    then
        for contact, value in pairs(oldContacted)
        do
            counter = counter + 1
            -- do only for current char
            if (GuildAdmin.db.global.Contacted[contact].contactedBy == GuildAdmin:GetPlayerName())
            then
                GuildAdmin:SetContactedDb(contact, "contactedBy", GuildAdmin.db.global.Contacted[contact].contactedBy)
                GuildAdmin:SetContactedDb(contact, "contacts", GuildAdmin.db.global.Contacted[contact].contacts)
                if (GuildAdmin.db.global.Contacted[contact].invited ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "invited", GuildAdmin.db.global.Contacted[contact].invited)
                end
                if (GuildAdmin.db.global.Contacted[contact].leftGuild ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "leftGuild", GuildAdmin.db.global.Contacted[contact].leftGuild)
                end
                if (GuildAdmin.db.global.Contacted[contact].guildLeft ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "guildLeft", GuildAdmin.db.global.Contacted[contact].guildLeft)
                end
                if (GuildAdmin.db.global.Contacted[contact].joinedGuild ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "joinedGuild", GuildAdmin.db.global.Contacted[contact].joinedGuild)
                end
                if (GuildAdmin.db.global.Contacted[contact].welcome ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "welcome", GuildAdmin.db.global.Contacted[contact].welcome)
                end
                if (GuildAdmin.db.global.Contacted[contact].details ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "details", GuildAdmin.db.global.Contacted[contact].details)
                end
                if (GuildAdmin.db.global.Contacted[contact].refused ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "refused", GuildAdmin.db.global.Contacted[contact].refused)
                end
                if (GuildAdmin.db.global.Contacted[contact].later ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "later", GuildAdmin.db.global.Contacted[contact].later)
                end
                if (GuildAdmin.db.global.Contacted[contact].lastContact ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "lastContact", GuildAdmin.db.global.Contacted[contact].lastContact)
                end
                if (GuildAdmin.db.global.Contacted[contact].class ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "class", GuildAdmin.db.global.Contacted[contact].class)
                end
                if (GuildAdmin.db.global.Contacted[contact].level ~= nil)
                then
                    GuildAdmin:SetContactedDb(contact, "level", GuildAdmin.db.global.Contacted[contact].level)
                end
                -- delete old contact from global.Contacted
                GuildAdmin.db.global.Contacted[contact] = nil
            else
                -- not contacted by another char
                if (GuildAdmin.db.global.Contacted[contact].contactedBy == nil)
                then
                    -- get the ones that left a guild - rest will be deleted (joined guild etc.)
                    if (GuildAdmin.db.global.Contacted[contact].guildLeft ~= nil)
                    then
                        if (GuildAdmin.db.global.Contacted[contact].guildLeft == GuildAdmin:GetCurrentGuildName())
                        then
                            GuildAdmin:SetContactedDb(contact, "guildLeft", GuildAdmin.db.global.Contacted[contact].guildLeft)
                            GuildAdmin:SetContactedDb(contact, "leftGuild", GuildAdmin.db.global.Contacted[contact].leftGuild)
                            -- delete old contact
                            GuildAdmin.db.global.Contacted[contact] = nil
                        end
                    else
                        -- forget about it, we can't find a place where to store as realm, faction information is missing
                        GuildAdmin.db.global.Contacted[contact] = nil
                    end
                end
            end                                
        end
        
        if (counter == 0)
        then
           -- we can delete the old Char tree
           GuildAdmin.db.global.Contacted = nil 
        end      
    end

    -- remove old Chars section - will be automatically rebuild
    if (GuildAdmin.db.global.Chars ~= nil)
    then
        GuildAdmin.db.global.Chars = nil
    end    
    -- remove old Alts section - will be automatically rebuild
    if (GuildAdmin.db.global.Alts ~= nil)
    then
        GuildAdmin.db.global.Alts = nil
    end  
    
    -- reset GuildAdmin.db.char.GameOptions.lastLoginTime - now named lastLogoffTime
    GuildAdmin.db.char.GameOptions.lastLoginTime = nil
    
end
 