-- $LastChangedRevision: 79 $ / $LastChangedDate: 2009-10-13 22:50:01 +0000 (Tue, 13 Oct 2009) $ / $LastChangedBy $

--- This is the core section which is loaded first. 
-- For all variables defined here, that maybe needed somewhere else, a getter function is provided.
--
-- This module contains mostly private API wrapper functions for better maintainability on library changes.
--
-- It also loads the addon via AceAddon.
--
-- The GuildAdminCore.lua is meant as the only script file, apart from localization files, which contains hardcoded stuff.
-- Load GuildAdminCore.lua before all other private script files
--
-- Documentation of wrapper parameter is taken from original source documentation where possible.
-- Thanks & credits for that go to Ace and LibDataBroker team.
--
-- See http://www.wowace.com/addons/ace3/pages/ and http://wiki.github.com/tekkub/libdatabroker-1-1
--
-- @class file
-- @name privateLibs/GuildAdminCore

-- ##############################################################################
-- Constants section
-- ##############################################################################

-- ########### basic constants ###########
-- application name - made public for to be used by localized files
local GUILDADMIN_APPNAME  = "GuildAdmin"

-- relative path to the icon
local GUILDADMIN_ICON     = "Interface\\FriendsFrame\\FriendsFrameScrollIcon.blp"

-- LDB type, either "launcher" or "data source"
local GUILDADMIN_LDB_TYPE = "data source"

-- database name as defined in .toc file: ## SavedVariables: Broker_GuildManagerDB 
local GUILDADMIN_DB       = "GuildAdminDb"

-- slash commands to register
local GUILDADMIN_SLASH    = "/guildadmin"

-- constant for ACE libs, to easily replace them in one place by newer versions
local ACE_LOCALE            = "AceLocale-3.0"
local ACE_CONFIG            = "AceConfig-3.0"
local ACE_CONFIGDIALOG      = "AceConfigDialog-3.0"
local ACE_CONFIG_REGISTRY   = "AceConfigRegistry-3.0"
local ACE_ADDON             = "AceAddon-3.0"
local ACE_CONSOLE           = "AceConsole-3.0"
local ACE_EVENT             = "AceEvent-3.0"
local ACE_DB                = "AceDB-3.0"

local LIBQTIP               = "LibQTip-1.0"

-- constant for Lib DataBroker
local LIB_DATABROKER        = "LibDataBroker-1.1" 

-- game constants not found yet provided in game
local FRIENDS_TAB_NR    = 1
local WHO_TAB_NR        = 2
local GUILD_TAB_NR      = 3
local RAID_TAB_NR       = 4
local MAX_LEVEL         = 80

-- ##############################################################################
-- addon load section 
-- ##############################################################################

-- Ace addon registry
GuildAdmin = LibStub(ACE_ADDON):NewAddon(GUILDADMIN_APPNAME)

-- current locale settings
local L = LibStub(ACE_LOCALE):GetLocale(GUILDADMIN_APPNAME, true)

-- current tooltip handler
local LibToolTip = LibStub(LIBQTIP)          

-- basic vars declaration
GuildAdmin.key2format = "%s::%s"
GuildAdmin.key3format = "%s::%s::%s"
GuildAdmin.CurrentChar = nil
GuildAdmin.CurrentRealm = nil
GuildAdmin.CurrentGuild = nil
GuildAdmin.CurrentFaction = nil
GuildAdmin.EnteredWorld = false
GuildAdmin.CurrentLocalizedFaction = nil
GuildAdmin.CurrentGuildMoney = 0
GuildAdmin.guildMembersOn = 0
GuildAdmin.guildMembersOff = 0 
GuildAdmin.guildMembersTotal = 0
GuildAdmin.GuildInfoShown = false
GuildAdmin.GuildChatListen = false
GuildAdmin.GuildChatSpeak = false
GuildAdmin.OfficerChatListen = false
GuildAdmin.OfficerChatSpeak = false 
GuildAdmin.Promote = false
GuildAdmin.Demote = false
GuildAdmin.Invite = false
GuildAdmin.Remove = false
GuildAdmin.SetMotd = false
GuildAdmin.EditPublicNote = false
GuildAdmin.ViewOfficerNote = false 
GuildAdmin.EditOfficerNote = false
GuildAdmin.ModifyGuildInfo = false
GuildAdmin.WithdrawRepair = false
GuildAdmin.WithdrawGold = false 
GuildAdmin.CreateGuildEvent = false
GuildAdmin.CurWho = nil
GuildAdmin.CurWhoListRdy = 0
GuildAdmin.CurWhoDetails = {}
GuildAdmin.CurWhoNeedsGuildSort = false
GuildAdmin.RecruitMinLvl = 0
GuildAdmin.RecruitMaxLvl = MAX_LEVEL
GuildAdmin.RecruitClassDefault = "ALLCLASSES"
GuildAdmin.RecruitClasses = {["ALLCLASSES"]=L["all"]}
GuildAdmin.RecruitClassesLoaded = false
GuildAdmin.RecruitCurZone = false
GuildAdmin.RecruitCurWhoList = {}
GuildAdmin.RecruitNewSearch = false
GuildAdmin.RecruitNoPlayers = "No players"
GuildAdmin.RecruitShowContacted = true 
GuildAdmin.RecruitShowRefused = false
GuildAdmin.RecruitSetIntroDefault = true
GuildAdmin.RecruitSetDetailsDefault = true
GuildAdmin.RecruitSetByeDefault = true
GuildAdmin.RecruitSetWelcomeDefault = true
GuildAdmin.RecruitSetWelcomeDetailsDefault = true
GuildAdmin.RecruitCurInvited = "."
GuildAdmin.WaitHourInviteReset = 2
GuildAdmin.ContactMinLvl = 0
GuildAdmin.ContactMaxLvl = MAX_LEVEL
GuildAdmin.RelationsClassDefault = "ALLCLASSES"
GuildAdmin.RelationsInvited = false
GuildAdmin.RelationsWelcomed = false
GuildAdmin.RelationsShowAll = false
GuildAdmin.RelationsTalkTypes = { ["WHISPER"] = L["whisper"],
                                  ["GUILD"] = L["guild chat"],
                                  ["OFFICER"] = L["officer chat"],
                                }
GuildAdmin.RelationsCurTalkType = "WHISPER"
GuildAdmin.RelationsSetTalkDefault = false
GuildAdmin.RelationsNewSearch = false
GuildAdmin.RelationsCurWhoList = {}

-- ##############################################################################
-- Color and meta data handling
-- due to load processing of config dialog options in GuildAdminCore
-- ##############################################################################

--- A getter function for addon meta data
--
-- @usage myVersion = GuildAdmin:getMeta("Version")
-- 
-- @param index   A string that defines the metadata string, e.g. "Author" or "Version"
-- @return A string containing the required information or L["Not Available"] text
function GuildAdmin:getMeta(index)

    return tostring(GetAddOnMetadata(GUILDADMIN_APPNAME, index)) or L["Not Available"]

end 
-- ==============================================================================

-- define table to hold colors only once
local ColorTable  = {
    WHITE       = "|cFFFFFFFF",
    RED         = "|cFFFF0000",
    GREEN       = "|cFF00FF00",
    YELLOW      = "|cFFFFFF00",
    ORANGE      = "|cFFFF7F00",
    TEAL        = "|cFF00FF9A",
    GOLD        = "|cFFFFD700",
    BLUE        = "|CFF8EC3E6",
    DARKBLUE    = "|CFF6A92AC",
    SALMON      = "|CFFFE8460",
    GREY        = "|CFF909090",
    BEIGE       = "|CFFE0DEC8",
    MAGE        = "|cFF69CCF0",
    WARRIOR     = "|cFFC79C6E",
    HUNTER      = "|cFFABD473",
    ROGUE       = "|cFFFFF569",
    WARLOCK     = "|cFF9482CA", 
    DRUID       = "|cFFFF7D0A", 
    SHAMAN      = "|cFF2459FF",
    PALADIN     = "|cFFF58CBA", 
    PRIEST      = "|cFFFFFFFF",
    DEATHKNIGHT = "|cFFC41F3B",
}


--- Returns a text string with embedded color codes.
-- If values are passed, they are converted into strings 
-- 
-- @param value The value or text to apply the color sequences
-- @param color The color string.
--              Supported are RED, WHITE, GREEN, YELLOW, ORANGE, TEAL
--                            GOLD, BLUE, DARKBLUE, SALMON, GREY, BEIGE
--              as well as english class names as returned by WOW Api functions
--
-- @return A formatted text string with applied |c |r color escape sequences, invalid colors do not change the string
function GuildAdmin:getColoredText(value, color)

    -- define the basic return string
    local color_string = tostring(value)

    -- check if we have a valid color
    if (ColorTable[color] ~= nil)
    then
        -- if so, set the color, otherwise original string is returned
        color_string = ColorTable[color]..color_string.."|r"
    end     

    return color_string

end
-- ==============================================================================

-- ##############################################################################
-- Table section
-- ##############################################################################

--- This table defines the option list for sort options in the config menu
local GuildAdminSortOptions = { ["online"]=L["online"],
                                ["name"]=L["Name"],
                                ["note"]=L["Note"],
                                ["zone"]=L["Zone"],
                                ["level"]=L["Level"],
                                ["class"]=L["Class"],
                              }

--- This table defines the defaults for the GuildManager database
-- @class table
-- @name GuildAdminDbDefaults
-- @field GuildAdminDbDefaults Table - this table defines the defaults for the GuildManager database as per Ace 3
-- @field global Table - A table that contains all data that can be accessed from all characters of this account
-- @field global.Guilds Table - A table that contains information about all guilds the account is subscribed to. Indexed by realm and faction e.g. ["Realm::Faction"]
--                              Use GuildAdmin.key2format formatted string together with string.format to create a valid key expression
-- @field global.Guilds.guild Table - A table that contains concrete information for a specific guild. Indexed by guild name, e.g. ["MyGuild"]
-- @field global.Guilds.guild.guildmoney Integer - The money the guild has on the guild bank
-- @field global.Guilds.guild.faction String - The localized faction name, the guild belongs to
-- @field global.Guilds.guild.mailAddress String - The virtual mail address for mailing to the whole guild
-- @field global.Guilds.guild.membersTotal Integer - The total amount of existing guild members
-- @field global.Guilds.guild.members Table - A table that contains detail information for every guild member indexed by players name, e.g. ["Player"]
--                                    Only guild relevant data are stored here, The rest of the character info is stored in Chars
-- @field global.Guilds.guild.members.guildBankGet Integer - A total in gold of items/gold received from the guild bank
-- @field global.Guilds.guild.members.guildBankPut Integer - A total in gold of items/gold put into the guild bank
-- @field global.Guilds.guild.members.rank String - the localized rank name
-- @field global.Guilds.guild.members.rankIndex Integer - the rank index from guild roster
-- @field global.Guilds.guild.members.note String - the note that has been set for this char
-- @field global.Guilds.guild.members.officerNote String - the officer note for this char - can only be viewed, if one if the alts has this
--                                                right for a guild, when member details are displayed  
-- @field global.Guilds.guild.Recruiting Table - contains the default recruiting text templates and settings
-- @field global.Guilds.guild.Recruiting.Intro String - the default intro text
-- @field global.Guilds.guild.Recruiting.Details String - the default details text
-- @field global.Guilds.guild.Recruiting.Bye String - the default goodbye text
-- @field global.Guilds.guild.Recruiting.Welcome String - the default welcome text
-- @field global.Guilds.guild.Recruiting.WelcomeDetails String - the default guild details text
-- @field global.Guilds.guild.Recruiting.IncludeContacted Boolean - the global default value for this setting
-- @field global.Guilds.guild.Recruiting.IncludeRefused Boolean - the global default value for this setting
-- @field global.Guilds.guild.Recruiting.SetIntroDefault Boolean - the global default value for this setting
-- @field global.Guilds.guild.Recruiting.SetDetailsDefault Boolean - the global default value for this setting
-- @field global.Guilds.guild.Recruiting.SetByeDefault Boolean - the global default value for this setting
-- @field global.Guilds.guild.Recruiting.SetWelcomeDefault Boolean - the global default value for this setting
-- @field global.Guilds.guild.Recruiting.SetWelcomeDetailsDefault Boolean - the global default value for this setting
-- @field global.Guilds.guild.Recruiting.SetTalkDefault Boolean - the global default value for this setting
-- @field global.Guilds.guild.Recruiting.RelationsTalkType String - the global default value (WHISPER) for talk types, e.g. chat cannels
-- @field global.Guilds.guild.Recruiting.Talk String - the default talk text
-- @field global.Relations Table - A table that contains information about all relations the account has. Indexed by realm and faction e.g. ["Realm::Faction"]
--                                 Use GuildAdmin.key2format formatted string together with string.format to create a valid key expression
-- @field global.Relations.Friends Table - A table that contains friends notes. Indexed by realm and friends name, e.g. ["FriendName"]
-- @field global.Relations.Friends.friendsNote String - the current note that is set for this friend
-- @field global.Relations.Friends.guildAdminNote String - an additional note for this friend, that is maintained by GuildAdmin (Not stored in game! Depends on addon)
-- @field global.Relations.Friends.isStillFriend Boolean - set to true, if still in friends list otherwise false
-- @field global.Relations.Greetz Table - A table that contains all greeting types and settings indexed by realm, faction and greeting type name, e.g. ["Realm.Faction.GreetingTypeName"]
-- @field global.Relations.Greetz.greetDelay Integer - The delay in minutes to wait before greeting the player again, default is 10 minutes
-- @field global.Relations.Greetz.first Table - A table that contains all the possible text strings for primary greeting of the day. Index is a sequence number given as string
-- @field global.Relations.Greetz.first.text String - the text string to greet with if player relogs on the same day. Players variable has to be coded as %s
-- @field global.Relations.Greetz.next Table - A table that contains all the possible text strings for continuous greetings on the same day. Index is a sequence number given as string
-- @field global.Relations.Greetz.next.text String - the text string to greet with if player relogs on the same day. Players variable has to be coded as %s
-- @field global.Relations.Chars Table - a table that contains all data for known characters indexed by name, e.g. ["CharName"]
-- @field global.Relations.Chars.level Integer - the current level of the char
-- @field global.Relations.Chars.class String - the localized class name
-- @field global.Relations.Chars.classFileName String - the english class name
-- @field global.Relations.Chars.profession1 String - a link to the first profession
-- @field global.Relations.Chars.profession2 String - a link to the second profession
-- @field global.Relations.Chars.cooking String - a link to the cooking profession
-- @field global.Relations.Chars.fishing String - a link to the fishing profession
-- @field global.Relations.Chars.firstAid String - a link to the first aid profession
-- @field global.Relations.Chars.skilled1 String - a link to the main skill of the player
-- @field global.Relations.Chars.skilled2 String - a link to the second talent main skill of the player if available
-- @field global.Relations.Chars.greetingType String - a link to the greeting type to use
-- @field global.Relations.Chars.lastGreeting String - the index of the last greeting used, e.g. ["1"]
-- @field global.Relations.Chars.mailInclude Boolean - True if member should be included in guild mailing list otherwise false
-- @field global.Relations.Chars.automatedGreeting Boolean - False, if no automated greeting should be used for this guild member otherwise true (overwrites the char setting)
-- @field global.Relations.Chars.todayGreetz Boolean - False, if no automated greeting happened today for this character
-- @field global.Relations.Chars.friendKeys Table - a table of all friend names known by this char
-- @field global.Relations.Chars.guildKey String - the guild name this char is registered to
-- @field global.Relations.Chars.instanceTimers A table for instance timers to avoid addon actions during raids and dungeon
-- @field global.Relations.Chars.greetzTimers A table for greeting timers to decide if first or next greeting is to be used
-- @field global.Relations.Alts Table - a table that contains all data for account characters indexed by name, e.g. ["CharName"]
-- @field global.Relations.Alts.level Integer - the current level of the char
-- @field global.Relations.Alts.class String - the localized class name
-- @field global.Relations.Alts.classFileName String - the english class name
-- @field global.Relations.Alts.canViewOfficerNote Boolean - True, if this alt can view the officer note for the guild registered with this alt
-- @field global.Relations.Alts.profession1 String - a link to the first profession
-- @field global.Relations.Alts.profession2 String - a link to the second profession
-- @field global.Relations.Alts.cooking String - a link to the cooking profession
-- @field global.Relations.Alts.fishing String - a link to the fishing profession
-- @field global.Relations.Alts.firstAid String - a link to the first aid profession
-- @field global.Relations.Alts.skilled1 String - a link to the main skill of the player
-- @field global.Relations.Alts.skilled2 String - a link to the second talent main skill of the player if available
-- @field global.Relations.Alts.mailInclude Boolean - True if member should be included in guild mailing list otherwise false
-- @field global.Relations.Alts.friendKeys Table - a table of all friend names known by this char
-- @field global.Relations.Alts.guildKey String - the guild name this char is registered to
-- @field global.Relations.Alts.instanceTimers A table for instance timers to avoid addon actions during raids and dungeon
-- @field global.Relations.Contacted Table - a table that contains all data for contacted characters indexed by name, e.g. ["CharName"]
-- @field global.Relations.Contacted.contactedBy String - the name of the char which has contacted this player
-- @field global.Relations.Contacted.contacts Integer - the contact count for this player
-- @field global.Relations.Contacted.invited Boolean - true, if already invited otherwise false
-- @field global.Relations.Contacted.leftGuild Boolean - true, if left any of the guilds your account is subscribed to
-- @field global.Relations.Contacted.guildLeft String - the name of the guild the contact has left
-- @field global.Relations.Contacted.joinedGuild Boolean - true, if joined any of the guilds your account is subscribed to
-- @field global.Relations.Contacted.welcome Boolean - true, if welcome text has been posted for this char by the recruiting console
-- @field global.Relations.Contacted.details Boolean - true, if details text has been posted for this char by the recruiting console
-- @field global.Relations.Contacted.refusedGuild Table - contains all guilds this contact has refused to join, index is guild name e.g. ["MyGuild"]
-- @field global.Relations.Contacted.refusedGuild.refused Boolean - true, if the player has refused to join the given guild in the refusedGuild index 
-- @field global.Relations.Contacted.later Boolean - true, if player didn't know yet and asked to contact him later (or has been marked as to be contacted later)
-- @field global.Relations.Contacted.lastContact Table - contains a table as returned by date("*t") with fields .year, .month, .day, .hour, .min, .sec, .wday, .yday, .isdst
-- @field global.Relations.Contacted.class String - the name of the class for this contact or L["Not Available"]
-- @field global.Relations.Contacted.level Integer - the level for this contact or L["Not Available"]
-- @field global.TooltipOptions Table - a table containing all configurable tooltip options 
-- @field global.TooltipOptions.showOffline Boolean - True, if amount of offline guild members should be shown in tooltip otherwise false
-- @field global.TooltipOptions.showTotal Boolean True - if amount of all guild members should be shown in tooltip otherwise false 
-- @field char Table - a table for all character dependent settings
-- @field char.GameOptions Table - a table containing all configurable game options 
-- @field char.GameOptions.showGuildInfo Boolean - true if guild info (delta) should be shown at startup
-- @field char.GameOptions.setPublicNote Boolean - true if GuildAdmin should automatically maintain the public guild note (save skills and talent)
-- @field char.GameOptions.loginTime Table - the current login time as a table delivered from date("*t") with fields .year, .month, .day, .hour, .min, .sec, .wday, .yday, .isdst
-- @field char.GameOptions.lastLogoffTime Table - the last logoff time as a table delivered from date("*t") with fields .year, .month, .day, .hour, .min, .sec, .wday, .yday, .isdst
-- @field char.Guild Table - a table that contains the current guild details for this char
-- @field char.Guild.guildmoney Integer - The money the guild has on the guild bank
-- @field char.Guild.membersTotal Integer - The total amount of existing guild members
-- @field char.Guild.members Table - A table that contains detail information for every guild member indexed by players name, e.g. ["Player"]
--                           Only guild relevant data are stored here, The rest of the character info is stored in Chars
-- @field char.Guild.members.level Integer - the level known from guild roster
-- @field char.Guild.members.rank String - the localized rank name
-- @field char.Guild.members.rankIndex Integer - the rank index from guild roster
-- @field char.Guild.members.note String - the note that has been set for this char
-- @field char.Guild.members.officerNote String - the officer note for this char - can only be viewed, if one if the alts has this
--                                                right for a guild, when member details are displayed  
-- @field char.Recruiting Table - a table that contains the current recruiting default texts for this char
-- @field char.Recruiting.Intro String - the default intro text
-- @field char.Recruiting.Details String - the default details text
-- @field char.Recruiting.Bye String - the default goodbye text
-- @field char.Recruiting.Welcome String - the default welcome text
-- @field char.Recruiting.WelcomeDetails String - the default guild details text
-- @field char.Recruiting.Talk String - the default talk text for relations console
local GuildAdminDbDefaults = {
    global = {  Guilds =    { ['**'] = { guild = { ['**'] = { guildmoney   = 0,
                                                              faction      = nil,
                                                              mailAddress  = nil,
                                                              membersTotal = 0,
                                                              members = { ['**'] = { guildBankGet = nil,
                                                                                     guildBankPut = nil,
                                                                                     rank         = nil,
                                                                                     rankIndex    = nil,
                                                                                     note         = nil,
                                                                                     officerNote  = nil,
                                                                                   },
                                                                            },
                                                               Recruiting = { Intro = L["intro default"],
                                                                              Details = L["details default"],
                                                                              Bye = L["bye default"],
                                                                              Welcome = L["welcome default"],
                                                                              WelcomeDetails = L["welcome details default"],
                                                                              IncludeContacted = true,
                                                                              IncludeRefused = false,
                                                                              SetIntroDefault = true,
                                                                              SetDetailsDefault = true,
                                                                              SetByeDefault = true,
                                                                              SetWelcomeDefault = true,
                                                                              SetWelcomeDetailsDefault = true,
                                                                              SetTalkDefault = false,
                                                                              RelationsTalkType = "WHISPER",
                                                                              Talk = L["intro default"],
                                                                            },
                                                            },
                                                },
                                       },
                            },                    
                Relations = { ['**'] = {Friends =   { ['**'] = { friendsNote    = nil,
                                                                 guildAdminNote = nil,
                                                                 isStillFriend  = false,
                                                               },
                                                    },
                                        Greetz =    { ['**'] = { greetDelay = 10,
                                                                 first = { ['**'] = { text = "Hi %p", } },
                                                                 next  = { ['**'] = { text = "wb %p", } },
                                                               },
                                                    },
                                        Chars =     { ['**'] = { level              = nil,
                                                                 class              = nil,
                                                                 classFileName      = nil,
                                                                 profession1        = nil,
                                                                 profession2        = nil,
                                                                 cooking            = nil,
                                                                 fishing            = nil,
                                                                 firstAid           = nil,
                                                                 skilled1           = nil,
                                                                 skilled2           = nil,
                                                                 greetingType       = nil,
                                                                 lastGreeting       = nil,
                                                                 mailInclude        = true,
                                                                 automatedGreeting  = false,
                                                                 todayGreetz        = false,
                                                                 friendKeys         = {},
                                                                 guildKey           = nil,
                                                                 instanceTimers     = {},
                                                                 greetzTimers       = {},
                                                               },
                                                    },
                                        Alts =      { ['**'] = { level              = nil,
                                                                 class              = nil,
                                                                 classFileName      = nil,
                                                                 canViewOfficerNote = false,
                                                                 profession1        = nil,
                                                                 profession2        = nil,
                                                                 cooking            = nil,
                                                                 fishing            = nil,
                                                                 firstAid           = nil,
                                                                 skilled1           = nil,
                                                                 skilled2           = nil,
                                                                 mailInclude        = false,
                                                                 friendKeys         = {},
                                                                 guildKey           = nil,
                                                                 instanceTimers     = {},
                                                               },
                                                    },
                                       Contacted =  { ['**'] = { contactedBy = nil,
                                                                 contacts = 0,
                                                                 invited = false,
                                                                 leftGuild = false,
                                                                 guildLeft = nil,
                                                                 joinedGuild = false,
                                                                 welcome = false,
                                                                 details = false,
                                                                 refusedGuild = { ["**"] = { refused = false, 
                                                                                           },
                                                                                },
                                                                 later = false,
                                                                 lastContact = nil,
                                                                 class = L["Not Available"],
                                                                 level = L["Not Available"],
                                                               },
                                                    },
                                       },
                                 },                   
                TooltipOptions = { showOffline = true,
                                   showTotal   = true,
                                 },
             },
    char =   { GameOptions = { showGuildInfo = true,
                               setPublicNote = true,
                               loginTime = nil,
                               lastLogoffTime = nil,
                             },   
               Guild = { guildmoney   = 0,
                         membersTotal = 0,
                         members = { ['**'] = { level        = nil,
                                                rank         = nil,
                                                rankIndex    = nil,
                                                note         = nil,
                                                officerNote  = nil,
                                              },
                                   },
                       },
               Recruiting = { Intro = L["intro default"],
                              Details = L["details default"],
                              Bye = L["bye default"],
                              Welcome = L["welcome default"],
                              WelcomeDetails = L["welcome details default"],
                              Talk = L["intro default"],
                            },
             },            
}
-- ==============================================================================

--- This table defines the options for LibDataBroker.
--
-- This table is configured as "data source", configuration for quick launcher
-- would require other fields.
--
-- @class table
-- @name LdbOptions
-- @field type Fixed to "data source" for this layout
-- @field icon The path to the application icon
-- @field label The application name to display in the panel
-- @field text The information to display in the panel
local LdbOptions = {type = GUILDADMIN_LDB_TYPE,
                    icon = GUILDADMIN_ICON, 
                    label = L["Application Short Name"],
                    text = L["Loading"],
}
-- ==============================================================================

--- This table defines the options for LibDataBroker - config menu ACE3.
-- @class table
-- @name ConfigOptions
-- @field ConfigOptions Table - for config menu. For information on fields and structure see http://www.wowace.com/addons/ace3/pages/ for details. Defines an option menu as per Ace 3 standard 
local ConfigOptions = {
    name = GUILDADMIN_APPNAME,
    type = "group",
    args = {
        confdesc = {
            order = 1,
            type = "description",
            name = L["description text"],
            cmdHidden = true,
        },
        confinfodesc = {
            name = L["About"],
            order = 2,
            type = "group", 
            inline = true,
            args = {
                confversiondesc = {
                    order = 1,
                    type = "description",           
                    name = GuildAdmin:getColoredText(L["Version"], "GOLD")..": "..GuildAdmin:getColoredText(GuildAdmin:getMeta("Version"), "GREEN"),
                    cmdHidden = true,
                },
                confauthordesc = {
                    order = 2,
                    type = "description",
                    name = GuildAdmin:getColoredText(L["Author"], "GOLD")..": "..GuildAdmin:getColoredText(GuildAdmin:getMeta("Author"), "TEAL"),
                    cmdHidden = true,
                },
                confcreditsdesc = {
                    order = 3,
                    type = "description",
                    name = GuildAdmin:getColoredText(L["Credits"], "GOLD")..": "..GuildAdmin:getColoredText(GuildAdmin:getMeta("X-Credits"), "WHITE"),
                    cmdHidden = true,
                },
                confcatdesc = {
                    order = 4,
                    type = "description",
                    name = GuildAdmin:getColoredText(L["Category"], "GOLD")..": "..GuildAdmin:getColoredText(GuildAdmin:getMeta("X-Category"), "GREEN"),
                    cmdHidden = true,
                },
                confemaildesc = {
                    order = 5,
                    type = "description",
                    name = GuildAdmin:getColoredText(L["Email"], "GOLD")..": "..GuildAdmin:getColoredText(GuildAdmin:getMeta("X-Email"), "GREEN"),
                    cmdHidden = true,
                },
                confwebsitedesc = {
                    order = 6,
                    type = "description",
                    name = GuildAdmin:getColoredText(L["Website"], "GOLD")..": "..GuildAdmin:getColoredText(GuildAdmin:getMeta("X-Website"), "GREEN"),
                    cmdHidden = true,
                },
                conflicensedesc = {
                    order = 7,
                    type = "description",
                    name = GuildAdmin:getColoredText(L["License"], "GOLD")..": "..GuildAdmin:getColoredText(GuildAdmin:getMeta("X-License"), "ORANGE"),
                    cmdHidden = true,
                },
           }
        },
        confsortopts = {
            name = L["Options"],
            order = 3,
            type = "group", 
            inline = true,
            args = {
                confshowguildinfo = {
                    order = 1,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["Show guild info"], "GOLD"),
                    desc = L["Shows the guild info on startup"],
                    width = "full",
                    get = function()
                            local dummy, dummy2, value = GuildAdmin:GetCharDb("GameOptions", "showGuildInfo")
                            return value
                          end,
                    set = function(index, value)
                            GuildAdmin:SetCharDb("GameOptions", "showGuildInfo", value)
                          end,
                    cmdHidden = true,
                },
                confsetpublicnote = {
                    order = 2,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["Set public note"], "GOLD"),
                    desc = L["Publish the skills in the public note"],
                    width = "full",
                    get = function()
                            local dummy, dummy2, value = GuildAdmin:GetCharDb("GameOptions", "setPublicNote")
                            return value
                          end,
                    set = function(index, value)
                            GuildAdmin:SetCharDb("GameOptions", "setPublicNote", value)
                          end,
                    cmdHidden = true,
                },
                confsorttooltip = {
                    order = 3,
                    name = GuildAdmin:getColoredText(L["Sort here"], "GOLD"),
                    desc = L["Sort tooltip in guild panel"],
                    type = "execute",
                    width = "full",
                    func = function()
                            ToggleFriendsFrame(GuildAdmin:getGuildTabNr())
                          end,
                    cmdHidden = true,
                },
                confsortdesc = {
                    order = 4,
                    type = "description",
                    name = GuildAdmin:getColoredText(L["Use guild panel to sort tooltip display"], "ORANGE"),
                    cmdHidden = true,
                },
           }
        },
    }
}
-- ==============================================================================

--- This table defines the recruiting options for LibDataBroker - recruiting menu ACE3.
-- 
-- This table defines the config dialog features and contents as per Ace 3 standard.
-- See http://www.wowace.com/addons/ace3/pages/ for details
-- @class table
-- @name ConfigRecruit
-- @field ConfigRecruit Table - recruiting console. For information on fields and structure see http://www.wowace.com/addons/ace3/pages/ for details. Defines an option menu as per Ace 3 standard
local ConfigRecruit = {
    name = L["Recruiting"],
    type = "group",
    args = {
        recdesc = {
            order = 1,
            type = "description",
            name = GuildAdmin:getColoredText(L["description recruiting"], "GREEN"),
            cmdHidden = true,
        },
        recwhodesc = {
            name = L["Search candidates"],
            order = 2,
            type = "group",
            inline = true,
            args = {
                recwhosearch = {
                    order = 1,
                    type = "execute",
                    width = "full",
                    name = GuildAdmin:getColoredText(L["Search"], "GOLD"),
                    desc = L["Search desc"],      
                    func = function()
                                -- check who sort
                                GuildAdmin.CurWhoNeedsGuildSort = GuildAdmin:NeedWhoListSort()
                                -- get the who list with correct filter
                                GuildAdmin:FireWhoList()
                                GuildAdmin:NotifyConfig()
                                GuildAdmin.RecruitNewSearch = true
                             end,    
                    cmdHidden = true,
                },
                recwholist = {
                    order = 2,
                    type = "select",
                    width = "full",
                    style = "dropdown",
                    name = GuildAdmin:getColoredText(L["players without guild"], "GOLD"),
                    desc = L["players without guild desc"],
                    values = function()
                                GuildAdmin.RecruitCurWhoList = GuildAdmin:GetRecruitWhoList()
                                return GuildAdmin.RecruitCurWhoList
                             end,    
                    get = function()
                                if GuildAdmin.RecruitNewSearch
                                then
                                    GuildAdmin.RecruitNewSearch = false
                                end    
                                -- get first char of current list
                                GuildAdmin.CurWho = GuildAdmin:GetWho(GuildAdmin.RecruitCurWhoList, GuildAdmin.CurWho)
                                return GuildAdmin.CurWho
                          end,
                    set = function(index, value)
                                -- reset CurInvited
                                GuildAdmin.RecruitCurInvited = "."
                                GuildAdmin.CurWho = value
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recmsgintro = {
                    order = 3,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["whisper intro"], "GOLD"),
                    desc = L["whisper intro desc"],
                    disabled = function()
                                    return ((GuildAdmin.CurWho == nil) or
                                            (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers) or
                                            (string.len(GuildAdmin.CurWho) < 1)
                                           )
                               end,
                    func = function()
                                local dummy, dummy2, intro = GuildAdmin:GetCharDb("Recruiting", "Intro")
                                if (GuildAdmin:IsCurWhoValid() and GuildAdmin:IsRecruitTextValid(intro, "no intro"))
                                then
                                    SendChatMessage(intro,"WHISPER", nil, GuildAdmin.CurWho)
                                    GuildAdmin:SetContacted(GuildAdmin.CurWho)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                end    
                           end,    
                      cmdHidden = true,
                },
                recmsgdetails = {
                    order = 4,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["whisper details"], "GOLD"),
                    desc = L["whisper details desc"],
                    disabled = function()
                                    return ((GuildAdmin.CurWho == nil) or
                                            (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers) or
                                            (string.len(GuildAdmin.CurWho) < 1)
                                           )
                               end,
                    func = function()
                                local dummy, dummy2, details = GuildAdmin:GetCharDb("Recruiting", "Details")
                                if (GuildAdmin:IsCurWhoValid() and GuildAdmin:IsRecruitTextValid(details, "no details"))
                                then
                                    SendChatMessage(details,"WHISPER", nil, GuildAdmin.CurWho)
                                    GuildAdmin:SetContacted(GuildAdmin.CurWho)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                end    
                           end,    
                      cmdHidden = true,
                },
                recmsgbye = {
                    order = 5,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["whisper bye"], "GOLD"),
                    desc = L["whisper bye desc"],
                    disabled = function()
                                    return ((GuildAdmin.CurWho == nil) or
                                            (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers) or
                                            (string.len(GuildAdmin.CurWho) < 1)
                                           )
                               end,
                    func = function()
                                local dummy, dummy2, bye = GuildAdmin:GetCharDb("Recruiting", "Bye")
                                if (GuildAdmin:IsCurWhoValid() and GuildAdmin:IsRecruitTextValid(bye, "no bye"))
                                then
                                    SendChatMessage(bye,"WHISPER", nil, GuildAdmin.CurWho)
                                    GuildAdmin:SetContacted(GuildAdmin.CurWho)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                end    
                           end,    
                      cmdHidden = true,
                },
                recmsginvite = {
                    order = 6,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["invite"], "GREEN"),
                    desc = L["invite desc"],
                    disabled = function()
                                    return ((GuildAdmin.CurWho == nil) or
                                            (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers) or
                                            (string.len(GuildAdmin.CurWho) < 1) or
                                            (not CanGuildInvite())
                                           )
                               end,
                    func = function()
                                if (GuildAdmin:IsCurWhoValid() and GuildAdmin:CanInvite("no rights to invite"))
                                then
                                    --try to invite
                                    GuildInvite(GuildAdmin.CurWho)
                                    GuildAdmin:SetContacted(GuildAdmin.CurWho)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "invited", true)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                    GuildAdmin.RecruitCurInvited = GuildAdmin.CurWho
                                end    
                           end,    
                      cmdHidden = true,
                },
                recmsgwelcome = {
                    order = 7,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["welcome"], "GREEN"),
                    desc = L["welcome desc"],
                    disabled = function()
                                    return (not IsInGuild())
                               end,
                    func = function()
                                local dummy, dummy2, welcome = GuildAdmin:GetCharDb("Recruiting", "Welcome")
                                if (GuildAdmin:IsCurWhoGuild() and GuildAdmin:IsRecruitTextValid(welcome, "no welcome"))
                                then
                                    SendChatMessage(string.format(welcome, GuildAdmin.RecruitCurInvited),"GUILD")
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "welcome", true)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                elseif GuildAdmin:IsRecruitTextValid(welcome, "no welcome")
                                then
                                    -- don't know the name
                                    SendChatMessage(string.format(welcome, GuildAdmin.RecruitCurInvited),"GUILD")
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "welcome", true)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                end    
                           end,    
                      cmdHidden = true,
                },
                recmsgwelcomedetails = {
                    order = 8,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["welcome details"], "GREEN"),
                    desc = L["welcome details desc"],
                    disabled = function()
                                    return (not IsInGuild())
                               end,
                    func = function()
                                local dummy, dummy2, details = GuildAdmin:GetCharDb("Recruiting", "WelcomeDetails")
                                if (GuildAdmin:IsCurWhoGuild() and GuildAdmin:IsRecruitTextValid(details, "no welcome details"))
                                then
                                    SendChatMessage(string.format(details, GuildAdmin.RecruitCurInvited),"GUILD")
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "details", true)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                elseif GuildAdmin:IsRecruitTextValid(details, "no welcome details")
                                then
                                    -- don't know the name
                                    SendChatMessage(string.format(details, GuildAdmin.RecruitCurInvited),"GUILD")
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "details", true)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                end    
                           end,    
                      cmdHidden = true,
                },
                recmsgrefused = {
                    order = 9,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["refused"], "ORANGE"),
                    desc = L["refused desc"],
                    disabled = function()
                                    return ((GuildAdmin.CurWho == nil) or
                                            (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers) or
                                            (string.len(GuildAdmin.CurWho) < 1)
                                           )
                               end,
                    func = function()
                                if (GuildAdmin:IsCurWhoValid())
                                then
                                    GuildAdmin:SetContacted(GuildAdmin.CurWho)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "refused", true)
                                    GuildAdmin:SetContactedRefusedDb(GuildAdmin.CurWho, GuildAdmin:GetCurrentGuildName(), "refused", true)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                end    
                           end,    
                      cmdHidden = true,
                },
                recmsglater = {
                    order = 10,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["later"], "GREY"),
                    desc = L["later desc"],
                    disabled = function()
                                    return ((GuildAdmin.CurWho == nil) or
                                            (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers) or
                                            (string.len(GuildAdmin.CurWho) < 1)
                                           )
                               end,
                    func = function()
                                if (GuildAdmin:IsCurWhoValid())
                                then
                                    GuildAdmin:SetContacted(GuildAdmin.CurWho)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "later", true)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                end    
                           end,    
                      cmdHidden = true,
                },
                recwholvlmin = {
                    order = 11,
                    type = "range",
                    min = 1,
                    max = MAX_LEVEL,
                    step = 1,
                    name = GuildAdmin:getColoredText(L["min level"], "GOLD"),
                    get = function()
                            return GuildAdmin.RecruitMinLvl
                          end,
                    set = function(index, value)
                            GuildAdmin.RecruitMinLvl = value
                          end,
                    cmdHidden = true,
                },
                recwholvlmax = {
                    order = 12,
                    type = "range",
                    min = 1,
                    max = MAX_LEVEL,
                    step = 1,
                    name = GuildAdmin:getColoredText(L["max level"], "GOLD"),
                    get = function()
                            if (GuildAdmin.RecruitMinLvl > GuildAdmin.RecruitMaxLvl)
                            then
                                GuildAdmin.RecruitMaxLvl = GuildAdmin.RecruitMinLvl
                            end    
                            return GuildAdmin.RecruitMaxLvl 
                          end,
                    set = function(index, value)
                            GuildAdmin.RecruitMaxLvl = value
                          end,
                    cmdHidden = true,
                },
                recwhoclass = {
                    order = 13,
                    type = "select",
                    name = GuildAdmin:getColoredText(L["class"], "GOLD"),
                    style = "dropdown",
                    values = function()
                                return GuildAdmin:GetClassSelection()
                             end,
                    get = function()
                            return GuildAdmin.RecruitClassDefault 
                          end,
                    set = function(index, value)
                            GuildAdmin.RecruitClassDefault = value
                            GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recwhozone = {
                    order = 14,
                    type = "toggle",
                    width = "full",
                    name = function()
                               return GuildAdmin:getColoredText(L["limit to current zone"].."("..GetZoneText()..")", "GOLD")
                           end,
                    desc = L["limit to current zone desc"],       
                    get = function()
                               return GuildAdmin.RecruitCurZone 
                          end,
                    set = function(index, value)
                                GuildAdmin.RecruitCurZone = value
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recwhocontacted = {
                    order = 15,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["include contacted"], "GOLD"),
                    desc = L["include contacted desc"],       
                    get = function()
                               return GuildAdmin.RecruitShowContacted 
                          end,
                    set = function(index, value)
                                GuildAdmin.RecruitShowContacted = value
                                -- set also default value
                                GuildAdmin:SetGuildDb("Recruiting", "IncludeContacted", value)
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recwhorefused = {
                    order = 16,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["include refused"], "GOLD"),
                    desc = L["include refused desc"],       
                    get = function()
                               return GuildAdmin.RecruitShowRefused 
                          end,
                    set = function(index, value)
                                GuildAdmin.RecruitShowRefused = value
                                -- set also default value
                                GuildAdmin:SetGuildDb("Recruiting", "IncludeRefused", value)
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
            },
        },        
    },
}
-- ==============================================================================

--- This table defines the recruting text options for LibDataBroker - recruiting menu ACE3.
-- 
-- This table defines the config dialog features and contents as per Ace 3 standard
-- See http://www.wowace.com/addons/ace3/pages/ for details
-- @class table
-- @name ConfigRecruitText
-- @find ConfigRecruitText Table - the config menu for recruiting texts. For information on fields and structure see http://www.wowace.com/addons/ace3/pages/ for details. Defines an option menu as per Ace 3 standard
local ConfigRecruitText = {
    name = L["Recruiting text"],
    type = "group",
    args = {
        rectxtdesc = {
            order = 1,
            type = "description",
            name = GuildAdmin:getColoredText(L["description recruiting text"], "GREEN"),
            cmdHidden = true,
        },
        rectxtdefdesc = {
            name = L["Define templates"],
            order = 2,
            type = "group", 
            inline = true,
            args = {
                rectxtdefintro = {
                    order = 1,
                    type = "input",
                    name = GuildAdmin:getColoredText(L["whisper intro"], "GOLD"),
                    desc = L["whisper intro conf desc"],
                    multiline = true,
                    width = "full",
                    get = function()
                                local dummy, dummy2, intro = GuildAdmin:GetCharDb("Recruiting", "Intro")
                                return GuildAdmin:GetDefaultRecruitingText(intro, "Intro")
                          end,
                    set = function(index, value)
                                local text = GuildAdmin:CheckText(value, 255, "Text 255 too long")
                                GuildAdmin:SetCharDb("Recruiting", "Intro", GuildAdmin:GetDefaultRecruitingText(text, "Intro"))
                                if GuildAdmin.RecruitSetIntroDefault
                                then
                                    GuildAdmin:SetGuildDb("Recruiting", "Intro", GuildAdmin:GetDefaultRecruitingText(text, "Intro"))
                                end
                          end,
                    cmdHidden = true,
                },
                rectxtdefintrodefault = {
                    order = 2,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["set intro default"], "GOLD"),
                    desc = L["set intro default desc"],       
                    width = "full",
                    get = function()
                               return GuildAdmin.RecruitSetIntroDefault 
                          end,
                    set = function(index, value)
                                GuildAdmin.RecruitSetIntroDefault = value
                                -- set also default value
                                GuildAdmin:SetGuildDb("Recruiting", "SetIntroDefault", value)
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                rectxtdefdetails = {
                    order = 3,
                    type = "input",
                    name = GuildAdmin:getColoredText(L["whisper details"], "GOLD"),
                    desc = L["whisper details conf desc"],
                    multiline = true,
                    width = "full",
                    get = function()
                                local dummy, dummy2, details = GuildAdmin:GetCharDb("Recruiting", "Details")
                                return GuildAdmin:GetDefaultRecruitingText(details, "Details")
                          end,
                    set = function(index, value)
                                local text = GuildAdmin:CheckText(value, 255, "Text 255 too long")
                                GuildAdmin:SetCharDb("Recruiting", "Details", GuildAdmin:GetDefaultRecruitingText(text, "Details"))
                                if GuildAdmin.RecruitSetDetailsDefault
                                then
                                    GuildAdmin:SetGuildDb("Recruiting", "Details", GuildAdmin:GetDefaultRecruitingText(text, "Details"))
                                end
                          end,
                    cmdHidden = true,
                },
                rectxtdefdetailsdefault = {
                    order = 4,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["set details default"], "GOLD"),
                    desc = L["set details default desc"],       
                    width = "full",
                    get = function()
                               return GuildAdmin.RecruitSetDetailsDefault 
                          end,
                    set = function(index, value)
                                GuildAdmin.RecruitSetDetailsDefault = value
                                -- set also default value
                                GuildAdmin:SetGuildDb("Recruiting", "SetDetailsDefault", value)
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                rectxtdefbye = {
                    order = 5,
                    type = "input",
                    name = GuildAdmin:getColoredText(L["whisper bye"], "GOLD"),
                    desc = L["whisper bye conf desc"],
                    multiline = true,
                    width = "full",
                    get = function()
                                local dummy, dummy2, bye = GuildAdmin:GetCharDb("Recruiting", "Bye")
                                return GuildAdmin:GetDefaultRecruitingText(bye, "Bye")
                          end,
                    set = function(index, value)
                                local text = GuildAdmin:CheckText(value, 255, "Text 255 too long")
                                GuildAdmin:SetCharDb("Recruiting", "Bye", GuildAdmin:GetDefaultRecruitingText(text, "Bye"))
                                if GuildAdmin.RecruitSetByeDefault
                                then
                                    GuildAdmin:SetGuildDb("Recruiting", "Bye", GuildAdmin:GetDefaultRecruitingText(text, "Bye"))
                                end
                          end,
                    cmdHidden = true,
                },
                rectxtdefbyedefault = {
                    order = 6,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["set bye default"], "GOLD"),
                    desc = L["set bye default desc"],       
                    width = "full",
                    get = function()
                               return GuildAdmin.RecruitSetByeDefault 
                          end,
                    set = function(index, value)
                                GuildAdmin.RecruitSetByeDefault = value
                                -- set also default value
                                GuildAdmin:SetGuildDb("Recruiting", "SetByeDefault", value)
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                rectxtdefwelcome = {
                    order = 7,
                    type = "input",
                    name = GuildAdmin:getColoredText(L["welcome"], "GOLD"),
                    desc = L["welcome conf desc"],
                    multiline = true,
                    width = "full",
                    get = function()
                                local dummy, dummy2, welcome = GuildAdmin:GetCharDb("Recruiting", "Welcome")
                                return GuildAdmin:GetDefaultRecruitingText(welcome, "Welcome")
                          end,
                    set = function(index, value)
                                local text = GuildAdmin:CheckText(value, 255, "Text 255 too long")
                                GuildAdmin:SetCharDb("Recruiting", "Welcome", GuildAdmin:GetDefaultRecruitingText(text, "Welcome"))
                                if GuildAdmin.RecruitSetWelcomeDefault
                                then
                                    GuildAdmin:SetGuildDb("Recruiting", "Welcome", GuildAdmin:GetDefaultRecruitingText(text, "Welcome"))
                                end
                          end,
                    cmdHidden = true,
                },
                rectxtdefwelcomedefault = {
                    order = 8,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["set welcome default"], "GOLD"),
                    desc = L["set welcome default desc"],       
                    width = "full",
                    get = function()
                               return GuildAdmin.RecruitSetWelcomeDefault 
                          end,
                    set = function(index, value)
                                GuildAdmin.RecruitSetWelcomeDefault = value
                                -- set also default value
                                GuildAdmin:SetGuildDb("Recruiting", "SetWelcomeDefault", value)
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                rectxtdefwelcomedetails = {
                    order = 9,
                    type = "input",
                    name = GuildAdmin:getColoredText(L["welcome details"], "GOLD"),
                    desc = L["welcome details conf desc"],
                    multiline = true,
                    width = "full",
                    get = function()
                                local dummy, dummy2, welcomedetails = GuildAdmin:GetCharDb("Recruiting", "WelcomeDetails")
                                return GuildAdmin:GetDefaultRecruitingText(welcomedetails, "WelcomeDetails")
                          end,
                    set = function(index, value)
                                local text = GuildAdmin:CheckText(value, 255, "Text 255 too long")
                                GuildAdmin:SetCharDb("Recruiting", "WelcomeDetails", GuildAdmin:GetDefaultRecruitingText(text, "WelcomeDetails"))
                                if GuildAdmin.RecruitSetWelcomeDetailsDefault
                                then
                                    GuildAdmin:SetGuildDb("Recruiting", "WelcomeDetails", GuildAdmin:GetDefaultRecruitingText(text, "WelcomeDetails"))
                                end
                          end,
                    cmdHidden = true,
                },
                rectxtdefwelcomedetailsdefault = {
                    order = 10,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["set welcome details default"], "GOLD"),
                    desc = L["set welcome details default desc"],       
                    width = "full",
                    get = function()
                               return GuildAdmin.RecruitSetWelcomeDetailsDefault 
                          end,
                    set = function(index, value)
                                GuildAdmin.RecruitSetWelcomeDetailsDefault = value
                                -- set also default value
                                GuildAdmin:SetGuildDb("Recruiting", "SetWelcomeDetailsDefault", value)
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
            },
        },
    },
}
-- ==============================================================================

--- This table defines the relationship options for LibDataBroker - recruiting menu ACE3.
-- 
-- This table defines the config dialog features and contents as per Ace 3 standard.
-- See http://www.wowace.com/addons/ace3/pages/ for details
-- @class table
-- @name ConfigRelations
-- @field ConfigRelations - relations console. For information on fields and structure see http://www.wowace.com/addons/ace3/pages/ for details. Defines an option menu as per Ace 3 standard
local ConfigRelations = {
    name = L["Relations"],
    type = "group",
    args = {
        recdesc = {
            order = 1,
            type = "description",
            name = GuildAdmin:getColoredText(L["description relations"], "GREEN"),
            cmdHidden = true,
        },
        recreldesc = {
            name = L["Search contacts"],
            order = 2,
            type = "group", 
            inline = true,
            args = {
                recrelsearch = {
                    order = 1,
                    type = "execute",
                    width = "full",
                    name = GuildAdmin:getColoredText(L["Search"], "GOLD"),
                    desc = L["Search desc"],      
                    func = function()
                                -- check who sort
                                GuildAdmin.CurWhoNeedsGuildSort = GuildAdmin:NeedWhoListSort()
                                -- get the who list with correct filter
                                GuildAdmin:FireWhoList()
                                GuildAdmin:NotifyConfig()
                                GuildAdmin.RelationsNewSearch = true
                             end,    
                    cmdHidden = true,
                },
                recrellist = {
                    order = 2,
                    type = "select",
                    width = "full",
                    style = "dropdown",
                    name = GuildAdmin:getColoredText(L["known players"], "GOLD"),
                    desc = L["known players desc"],
                    values = function()
                                GuildAdmin.RelationsCurWhoList = GuildAdmin:GetRelationsWhoList()
                                return GuildAdmin.RelationsCurWhoList
                             end,    
                    get = function()
                                if GuildAdmin.RelationsNewSearch
                                then
                                    GuildAdmin.RelationsNewSearch = false
                                end    
                                -- get first char in current list
                                GuildAdmin.CurWho = GuildAdmin:GetWho(GuildAdmin.RelationsCurWhoList, GuildAdmin.CurWho)
                                return GuildAdmin.CurWho
                          end,
                    set = function(index, value)
                                GuildAdmin.CurWho = value
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recreltalktype = {
                    order = 3,
                    type = "select",
                    width = "full",
                    style = "dropdown",
                    name = GuildAdmin:getColoredText(L["talk type"], "GOLD"),
                    desc = L["talk type desc"],
                    values = function()
                                return GuildAdmin.RelationsTalkTypes
                             end,    
                    get = function()
                                return GuildAdmin.RelationsCurTalkType
                          end,
                    set = function(index, value)
                                GuildAdmin.RelationsCurTalkType = value
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recreltalktext = {
                    order = 4,
                    type = "input",
                    name = GuildAdmin:getColoredText(L["talk text"], "GOLD"),
                    desc = L["talk text desc"],
                    multiline = true,
                    width = "full",
                    get = function()
                                local dummy, dummy2, talk = GuildAdmin:GetCharDb("Recruiting", "Talk")
                                return GuildAdmin:GetDefaultRecruitingText(talk, "Talk")
                          end,
                    set = function(index, value)
                                local text = GuildAdmin:CheckText(value, 255, "Text 255 too long")
                                GuildAdmin:SetCharDb("Recruiting", "Talk", GuildAdmin:GetDefaultRecruitingText(text, "Talk"))
                                if GuildAdmin.RelationsSetTalkDefault
                                then
                                    GuildAdmin:SetGuildDb("Recruiting", "Talk", GuildAdmin:GetDefaultRecruitingText(text, "Talk"))
                                end
                          end,
                    cmdHidden = true,
                },
                recreltalk = {
                    order = 5,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["talk"], "GOLD"),
                    disabled = function()
                                    return (((GuildAdmin.CurWho == nil) or (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers)) and 
                                            (GuildAdmin.RelationsCurTalkType == "WHISPER")
                                           )
                               end,     
                    func = function()
                                local dummy, dummy2, talk = GuildAdmin:GetCharDb("Recruiting", "Talk")
                                GuildAdmin:Say(talk, GuildAdmin.RelationsCurTalkType, GuildAdmin.CurWho)
                                if (GuildAdmin.RelationsCurTalkType == "WHISPER")
                                then
                                    -- update infos
                                    GuildAdmin:SetContacted(GuildAdmin.CurWho)
                                end
                             end,    
                    cmdHidden = true,
                },
                recreldelete = {
                    order = 6,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["delete"], "ORANGE"),
                    desc = L["delete desc"],      
                    disabled = function()
                                    return ((GuildAdmin.CurWho == nil) or 
                                            (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers) or 
                                            (GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentGuildsKey()].Chars[GuildAdmin.CurWho].level == nil)
                                           ) 
                               end,     
                    func = function()
                                GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentGuildsKey()].Chars[GuildAdmin.CurWho] = nil
                                GuildAdmin.db.global.Relations[GuildAdmin:GetCurrentGuildsKey()].Contacted[GuildAdmin.CurWho] = nil
                                GuildAdmin:NotifyConfig()
                           end,    
                    cmdHidden = true,
                },
                recrelrefuse = {
                    order = 7,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["refused"], "ORANGE"),
                    desc = L["refused desc"],
                    disabled = function()
                                    return ((GuildAdmin.CurWho == nil) or
                                            (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers) or
                                            (string.len(GuildAdmin.CurWho) < 1)
                                           )
                               end,
                    func = function()
                                if (GuildAdmin:IsCurWhoValid())
                                then
                                    GuildAdmin:SetContacted(GuildAdmin.CurWho)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "refused", true)
                                    GuildAdmin:SetContactedRefusedDb(GuildAdmin.CurWho, GuildAdmin:GetCurrentGuildName(), "refused", true)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                end    
                           end,    
                      cmdHidden = true,
                },
                recrellater = {
                    order = 8,
                    type = "execute",
                    name = GuildAdmin:getColoredText(L["later"], "GREY"),
                    desc = L["later desc"],
                    disabled = function()
                                    return ((GuildAdmin.CurWho == nil) or
                                            (GuildAdmin.CurWho == GuildAdmin.RecruitNoPlayers) or
                                            (string.len(GuildAdmin.CurWho) < 1)
                                           )
                               end,
                    func = function()
                                if (GuildAdmin:IsCurWhoValid())
                                then
                                    GuildAdmin:SetContacted(GuildAdmin.CurWho)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "later", true)
                                    GuildAdmin:SetContactedDb(GuildAdmin.CurWho, "lastContact", date("*t"))
                                end    
                           end,    
                      cmdHidden = true,
                },
                recreltalkdefault = {
                    order = 9,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["set talk default"], "GOLD"),
                    desc = L["set talk default desc"],       
                    width = "full",
                    get = function()
                               return GuildAdmin.RelationsSetTalkDefault 
                          end,
                    set = function(index, value)
                                GuildAdmin.RelationsSetTalkDefault = value
                                -- set also default value
                                GuildAdmin:SetGuildDb("Recruiting", "SetTalkDefault", value)
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recrellvlmin = {
                    order = 10,
                    type = "range",
                    min = 1,
                    max = MAX_LEVEL,
                    step = 1,
                    name = GuildAdmin:getColoredText(L["min level"], "GOLD"),
                    get = function()
                            return GuildAdmin.RecruitMinLvl
                          end,
                    set = function(index, value)
                            GuildAdmin.RecruitMinLvl = value
                          end,
                    cmdHidden = true,
                },
                recrellvlmax = {
                    order = 11,
                    type = "range",
                    min = 1,
                    max = MAX_LEVEL,
                    step = 1,
                    name = GuildAdmin:getColoredText(L["max level"], "GOLD"),
                    get = function()
                            if (GuildAdmin.RecruitMinLvl > GuildAdmin.RecruitMaxLvl)
                            then
                                GuildAdmin.RecruitMaxLvl = GuildAdmin.RecruitMinLvl
                            end    
                            return GuildAdmin.RecruitMaxLvl 
                          end,
                    set = function(index, value)
                            GuildAdmin.RecruitMaxLvl = value
                          end,
                    cmdHidden = true,
                },
                recrelclass = {
                    order = 12,
                    type = "select",
                    name = GuildAdmin:getColoredText(L["class"], "GOLD"),
                    style = "dropdown",
                    values = function()
                                return GuildAdmin:GetClassSelection()
                             end,
                    get = function()
                            return GuildAdmin.RecruitClassDefault 
                          end,
                    set = function(index, value)
                            GuildAdmin.RecruitClassDefault = value
                            GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recrelzone = {
                    order = 13,
                    type = "toggle",
                    width = "full",
                    name = function()
                               return GuildAdmin:getColoredText(L["limit to current zone"].."("..GetZoneText()..")", "GOLD")
                           end,
                    desc = L["limit to current zone desc"],       
                    get = function()
                               return GuildAdmin.RecruitCurZone 
                          end,
                    set = function(index, value)
                                GuildAdmin.RecruitCurZone = value
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recrelinvited = {
                    order = 14,
                    type = "toggle",
                    width = "full",
                    name = GuildAdmin:getColoredText(L["limit to invited"], "GOLD"),
                    desc = L["limit to invited desc"],       
                    get = function()
                               return GuildAdmin.RelationsInvited
                          end,
                    set = function(index, value)
                                GuildAdmin.RelationsInvited = value
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recrelwelcome = {
                    order = 15,
                    type = "toggle",
                    width = "full",
                    name = GuildAdmin:getColoredText(L["limit to welcomed"], "GOLD"),
                    desc = L["limit to welcomed desc"],       
                    get = function()
                               return GuildAdmin.RelationsWelcomed
                          end,
                    set = function(index, value)
                                GuildAdmin.RelationsWelcomed = value
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recrelrefused = {
                    order = 16,
                    type = "toggle",
                    name = GuildAdmin:getColoredText(L["include refused"], "GOLD"),
                    desc = L["include refused desc"],       
                    get = function()
                               return GuildAdmin.RecruitShowRefused 
                          end,
                    set = function(index, value)
                                GuildAdmin.RecruitShowRefused = value
                                -- set also default value
                                GuildAdmin:SetGuildDb("Recruiting", "IncludeRefused", value)
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
                recrelshowall = {
                    order = 17,
                    type = "toggle",
                    width = "full",
                    name = GuildAdmin:getColoredText(L["show all contacts"], "GOLD"),
                    desc = L["show all contacts desc"],       
                    get = function()
                               return GuildAdmin.RelationsShowAll
                          end,
                    set = function(index, value)
                                GuildAdmin.RelationsShowAll = value
                                GuildAdmin:NotifyConfig()
                          end,
                    cmdHidden = true,
                },
            },
        },
    },
}
-- ==============================================================================


-- ##############################################################################
-- Basic private API section
-- ##############################################################################
--- Private API wrapper to Ace Locale.
-- Returns a pointer to the current optional locale settings to use. Second param of original function
-- is made constantly true. If true, the locale is optional, silently return nil if it's not found.
-- 
-- The application mustn't know how locale is retrieved
--
-- @usage local L = GuildAdmin:myLocale("MyIndex")
--
-- @param locale_index The index string of the required locale
-- @return A value with appropriate localization
function GuildAdmin:myLocale(locale_index)

    return L[locale_index]       

end 
-- ==============================================================================

--- Private API wrapper for AceDB.
-- Returns an empty database object for SavedVariables file
--
-- The application itself mustn't know how the database object is created.
--
-- @usage MyApp.db = GuildAdmin:getNewDB()
--
-- @return The empty database object
function GuildAdmin:getNewDB()
    return LibStub(ACE_DB):New(GUILDADMIN_DB, GuildAdminDbDefaults)
end
-- ==============================================================================

GuildAdmin.Ldb = LibStub:GetLibrary(LIB_DATABROKER):NewDataObject(GUILDADMIN_APPNAME, LdbOptions)

--- Private API wrapper for LibDataBroker. 
-- Initializes the LDB support for the addon and returns the LDB object. If necessary, it creates 
-- the object otherwise it gets it from LDB
-- 
-- The application itself mustn't know how the broker object is created
-- @usage local broker = GuildAdmin:getBroker() 
-- @return The new or existing broker object for this application
function GuildAdmin:getBroker()

    return GuildAdmin.Ldb

end
-- ==============================================================================

--- Private API wrapper to Ace Config and ConfigDialog.
-- Registers menu and tooltip options
-- Options table is defined in table section
--
-- @usage GuildAdmin:registerMyOptions()
--
-- @return The reference to the frame registered into the Interface Options. 
function GuildAdmin:registerMyOptions()
    local frame
    
    LibStub(ACE_CONFIG):RegisterOptionsTable(GUILDADMIN_APPNAME, ConfigOptions, GUILDADMIN_SLASH)
    LibStub(ACE_CONFIG):RegisterOptionsTable(GUILDADMIN_APPNAME.." "..L["Recruiting"], ConfigRecruit)
    LibStub(ACE_CONFIG):RegisterOptionsTable(GUILDADMIN_APPNAME.." "..L["Recruiting text"], ConfigRecruitText)
    LibStub(ACE_CONFIG):RegisterOptionsTable(GUILDADMIN_APPNAME.." "..L["Relations"], ConfigRelations)
    frame = LibStub(ACE_CONFIGDIALOG):AddToBlizOptions(GUILDADMIN_APPNAME)
    LibStub(ACE_CONFIGDIALOG):AddToBlizOptions(GUILDADMIN_APPNAME.." "..L["Recruiting"], L["Recruiting"], GUILDADMIN_APPNAME)
    LibStub(ACE_CONFIGDIALOG):AddToBlizOptions(GUILDADMIN_APPNAME.." "..L["Recruiting text"], L["Recruiting text"], GUILDADMIN_APPNAME)
    LibStub(ACE_CONFIGDIALOG):AddToBlizOptions(GUILDADMIN_APPNAME.." "..L["Relations"], L["Relations"], GUILDADMIN_APPNAME)
    return frame
end 
-- ==============================================================================

--- Notifies options about changes from outside.
-- Use only in Setter functions or functions/handler which provide data for a config object
function GuildAdmin:NotifyConfig()

    LibStub(ACE_CONFIG_REGISTRY):NotifyChange(GUILDADMIN_APPNAME)
    
end 
-- ==============================================================================

--- Private API wrapper to LibQTip.
-- Provides enhanced tooltip options. Sets up the tooltip with a defined number 
-- of columns. This is hardcoded in this file.
--
-- @return The reference to the created tooltip object 
function GuildAdmin:getTooltip()

    return LibToolTip:Acquire("GuildAdminTooltipFrame", 9, "LEFT", "LEFT", "LEFT", "LEFT", "LEFT", "LEFT", "LEFT", "RIGHT", "RIGHT")

end 
-- ==============================================================================

--- Private API wrapper to LibQTip.
-- Provides the release call to the tooltip  
-- of columns. This is hardcoded in this file.
-- @param curTooltip Table - the tooltip object to release
function GuildAdmin:ReleaseTooltip(curTooltip)
    
    if (curTooltip ~= nil)
    then
        LibToolTip:Release(curTooltip)
    end
end 
-- ==============================================================================

--- Ace Hook to ease addon loading.
-- Will initialize the basic functionality by creating the database, loading 
-- broker support and registering for events. 
function GuildAdmin:OnInitialize() 

    --GuildAdmin:Enable()
    -- get database
    GuildAdmin.db = GuildAdmin:getNewDB()
    
    -- direct load to help other addons register GuildAdmin correctly
    LibStub(ACE_CONFIG):RegisterOptionsTable(GUILDADMIN_APPNAME, ConfigOptions, GUILDADMIN_SLASH)
    LibStub(ACE_CONFIG):RegisterOptionsTable(GUILDADMIN_APPNAME.." "..L["Recruiting"], ConfigRecruit)
    LibStub(ACE_CONFIG):RegisterOptionsTable(GUILDADMIN_APPNAME.." "..L["Recruiting text"], ConfigRecruitText)
    LibStub(ACE_CONFIG):RegisterOptionsTable(GUILDADMIN_APPNAME.." "..L["Relations"], ConfigRelations)

    LibStub(ACE_CONFIGDIALOG):AddToBlizOptions(GUILDADMIN_APPNAME)
    LibStub(ACE_CONFIGDIALOG):AddToBlizOptions(GUILDADMIN_APPNAME.." "..L["Recruiting"], L["Recruiting"], GUILDADMIN_APPNAME)
    LibStub(ACE_CONFIGDIALOG):AddToBlizOptions(GUILDADMIN_APPNAME.." "..L["Recruiting text"], L["Recruiting text"], GUILDADMIN_APPNAME)
    LibStub(ACE_CONFIGDIALOG):AddToBlizOptions(GUILDADMIN_APPNAME.." "..L["Relations"], L["Relations"], GUILDADMIN_APPNAME)


--    DEFAULT_CHAT_FRAME:AddMessage("OnInitialize done - guild addon fully initialized");
end 
-- ==============================================================================


-- ##############################################################################
-- Getter section
-- ##############################################################################

--- Getter for constant GUILDADMIN_APPNAME
-- @usage local myAppName = GuildAdmin:getAppName()
--
-- @return The hardcoded application name 
function GuildAdmin:getAppName()
    return GUILDADMIN_APPNAME
end 
-- ==============================================================================

--- Getter for constant GUILD_TAB_NR
-- @usage ToggleFriendsFrame(GuildAdmin:getGuildTabNr())
--
-- @return The hardcoded guild tab number in the friends frame 
function GuildAdmin:getGuildTabNr()
    return GUILD_TAB_NR
end 
-- ==============================================================================

--- Getter for table GuildAdminSortOptions
-- @usage local SortOptions = GuildAdmin:getSortOptions()
--
-- @return The table GuildAdminSortOptions
function GuildAdmin:getSortOptions()
    return GuildAdminSortOptions
end 
-- ==============================================================================

--- Getter for MAX_LEVEL
-- @usage local maxLevel = GuildAdmin:getMaxLevel()
--
-- @return Integer The MAX_LEVEL set
function GuildAdmin:getMaxLevel()
    return MAX_LEVEL
end 
-- ==============================================================================


