-- $LastChangedRevision: 79 $ / $LastChangedDate: 2009-10-13 22:50:01 +0000 (Tue, 13 Oct 2009) $ / $LastChangedBy $

--- Main class for GuildAdmin
-- This addon is intended to manage guild tasks within a LDB compatible panel
-- addon like Titan, nUI and others. 
-- Functionality:
-- * show online and offline guild members in panel tooltip
-- * sort online and offline guild members by defined criteria
-- * show differences on login (who left/added, rank & level updates) for every char or only first char who logged in 
-- * add automatically class and skill infos from guild members to member display
-- * recruiting console to search for new members, inform, invite and welcome them.
-- * easy guild invite 
-- * definable text templates for recruiting
-- * relations console to maintain all existing contacts, delete them, talk to them or to guild channel
-- * guild console for daily guild tasks
-- 
-- Programming Concept
-- The basic concept of the private libs is to distinguish between the presentation layer, the logic layer and the data layer (MVC)
-- However there exists a GuildAdminCore.lua which contains all necessary hardcoded stuff and the functions in there belong probably 
-- to different layers. This is due to the restrictions, as far as I understand, how addons are loaded and working.
-- All wrapper scripts are only meant to give better maintainability on WOW updates and ongoing library updates, interfacing used foreign
-- libraries to avoid bothering the pure application with unnecessary dependency stuff
-- 
-- The current use of global variables is not OO at all, but that's what I have at the moment. Probably the next versions
-- will get more OO style 
--
-- Loading of script files is all done through XML, thus the .toc file doesn't contain any .lua file explicitly. 
-- Credits go to all those incredible genius programmers which have written tools like Ace, LibDataBroker, Altoholic, QuestHelper and so many others, 
-- that the list would be to long to name tham all and which inspired me on providing this addon.
--
-- @class file
-- @name GuildManager

-- ##############################################################################
-- Basic declarations
-- ##############################################################################
local ldb_broker  = GuildAdmin:getBroker()
local event_frame = CreateFrame("Frame", GuildAdmin:getAppName(), UIParent)
local GuildAdminTooltip = nil

-- ##############################################################################
-- Event functions Guild Admin
-- ##############################################################################

--- Reactions to the OnEnable event
-- registering events - this runs first in the initialization process
function GuildAdmin:OnEnable() 
    
    -- register events we handle

    -- generic updates
    event_frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    event_frame:RegisterEvent("PLAYER_LOGOUT")
    

    -- guild events
    event_frame:RegisterEvent("GUILD_ROSTER_UPDATE")
    event_frame:RegisterEvent("PLAYER_GUILD_UPDATE")
    event_frame:RegisterEvent("GUILD_ROSTER_SHOW")
    event_frame:RegisterEvent("GUILD_REGISTRAR_SHOW")
    event_frame:RegisterEvent("GUILD_REGISTRAR_CLOSED")
    
    -- recruiting events
    event_frame:RegisterEvent("WHO_LIST_UPDATE")

    -- friends events
    event_frame:RegisterEvent("FRIENDLIST_UPDATE")


--    DEFAULT_CHAT_FRAME:AddMessage("Events registered")

end 
-- ==============================================================================

--- Reactions to the OnDisable event
-- unregistering events
function GuildAdmin:OnDisable() 

    -- unregister events we handle
    -- generic updates
    event_frame:UnregisterEvent("PLAYER_ENTERING_WORLD")
    event_frame:UnregisterEvent("PLAYER_LOGOUT")

    -- guild events
    event_frame:UnregisterEvent("GUILD_ROSTER_UPDATE")
    event_frame:UnregisterEvent("PLAYER_GUILD_UPDATE")
    event_frame:UnregisterEvent("GUILD_ROSTER_SHOW")
    event_frame:UnregisterEvent("GUILD_REGISTRAR_SHOW")
    event_frame:UnregisterEvent("GUILD_REGISTRAR_CLOSED")

    -- recruiting events
    event_frame:UnregisterEvent("WHO_LIST_UPDATE")

    -- friends events
    event_frame:UnregisterEvent("FRIENDLIST_UPDATE")
    
end
-- ==============================================================================

--- Toggles the display of the UI frame
function GuildAdmin:ToggleUI()
    if (GuildAdminFrame:IsVisible()) then
        GuildAdminFrame:Hide()
    else
        GuildAdminFrame:Show()
    end
end
-- ==============================================================================

-- ##############################################################################
-- Event functions LDB Broker
-- ##############################################################################

--- Prepares the display list for the tooltip
function GuildAdmin.Ldb:OnTooltipShow()
    
    -- update guild roster
    GuildRoster()
    
    -- header
    GuildAdmin:getTooltipHeader(GuildAdminTooltip)

    -- prepare the display list    
    GuildAdmin:getToolTipDisplayList(GuildAdminTooltip)

end
-- ==============================================================================

--- Lib Databroker initialization
function GuildAdmin.Ldb:OnEnter()
    
    GuildAdminTooltip = GuildAdmin:getTooltip()
    GuildAdminTooltip:Clear()
    -- Use smart anchoring code to anchor the tooltip to our frame
    GuildAdminTooltip:SmartAnchorTo(self)
    GuildAdmin.Ldb.tooltip = GuildAdminTooltip

    GuildAdminTooltip:SetScript("OnEnter", function(self) GuildAdmin.Ldb:OnEnter() end)
    GuildAdminTooltip:SetScript("OnLeave", function(self) GuildAdmin.Ldb:OnLeave() end)
    
    GuildAdminTooltip:SetScale(0.8)

    GuildAdmin.Ldb.OnTooltipShow(GuildAdminTooltip)

    GuildAdminTooltip:Show()

end
-- ==============================================================================

--- Event when leavin the tooltip, handled by LDB object
function GuildAdmin.Ldb:OnLeave()

    if (GuildAdminTooltip ~= nil)
    then
        GuildAdmin:ReleaseTooltip(GuildAdminTooltip)
        GuildAdminTooltip = nil
    end
--    UpdateAddOnMemoryUsage()
--    DEFAULT_CHAT_FRAME:AddMessage("Memory: "..tostring(GetAddOnMemoryUsage(GuildAdmin:getAppName()))) 

end
-- ============================================================================== 

--- Defines the current actions if button in panel is clicked
-- @param button String - the button name clicked, e.g. "LeftButton" or "RightButton"
function GuildAdmin.Ldb:OnClick(button)

    -- toggle display if button left
    if button == "LeftButton" 
    then
        ToggleFriendsFrame(GuildAdmin:getGuildTabNr())
    end

    -- open config menu if button right
    if button == "RightButton" 
    then
        InterfaceOptionsFrame_OpenToCategory(GuildAdmin:getAppName())
    end

end
-- ==============================================================================

-- ##############################################################################
-- Event functions event frame
-- ##############################################################################

--- The event handling for GuildAdmin events that are not explicitly handled
-- Deals with all events, we handle in GuildAdmin
event_frame:SetScript("OnEvent", function(self, event, ...) 
--    DEFAULT_CHAT_FRAME:AddMessage("Generic event handling entered: "..event)

    if (event == "PLAYER_ENTERING_WORLD") 
    then
        GuildAdmin.EnteredWorld = true
        GuildAdmin:SetVars()
        if (not IsInGuild())
        then
            -- update broker text only ontime
            -- update LDB broker display
            GuildAdmin:setTooltipText(GuildAdmin.Ldb)
            -- run updates for those who are not in a guild
            GuildAdmin:Update3bto3c()
            GuildAdmin:Update3eto3f()
            -- update available TalkTypes
            GuildAdmin:SetTalkTypes()
        else
            -- set optimistic setting for talk types as refresh comes quite late if ever
            GuildAdmin.GuildChatSpeak = true
            GuildAdmin.OfficerChatSpeak = true 
            -- initialize popup from FriendsFrame as this is related to guild values and correct
            -- opening of guild frame windows
            GuildControlPopupFrame_Initialize()
            
        end
        
    elseif (event == "GUILD_ROSTER_UPDATE" or 
            event == "PLAYER_GUILD_UPDATE"
           )
    then
        
        if GuildAdmin:IsGuildInfoAvailable()
        then
            -- first time (reload or login)
            if GuildAdmin.EnteredWorld
            then
                GuildAdmin:SetGuildVars()
                GuildAdmin.EnteredWorld = false
            end        
            -- database update
            GuildAdmin:UpdateGuildsDatabase(GuildAdmin.GuildInfoShown)
            
            -- update guild info
            GuildAdmin:updateGuildInfo()
            
            -- update rank flags
            GuildAdmin:SetCurRankFlags()
            
            -- update available TalkTypes
            GuildAdmin:SetTalkTypes()
    
            -- update LDB broker display
            GuildAdmin:setTooltipText(GuildAdmin.Ldb)

            -- show guild info only once, if configured (function takes care!!)
            -- this is to display the info delayed and to have the possibility to 
            -- see the info without need for scrolling back as well as being sure 
            -- that correct guild infos are available
            GuildAdmin:ShowGuildInfo()

        end
        -- force refresh(??) in any case like seen in FriendsFrame.lua        
        GuildRoster()
             
    elseif (event == "PLAYER_LOGOUT")
    then 
        -- update char related database - if earlier a delta wouldn't be possible
        GuildAdmin:UpdateGuildsDatabase(true)
        -- save last login time
        GuildAdmin.db.char.GameOptions.lastLogoffTime = date("*t")
        
    elseif (event == "GUILD_REGISTRAR_CLOSED" or 
            event == "GUILD_REGISTRAR_SHOW" or
            event == "GUILD_ROSTER_SHOW"
           ) 
    then

        local dummy = true
  
    elseif (event == "WHO_LIST_UPDATE")
    then
        
        -- one of our get data events has happened      
        if (GuildAdmin.CurWhoListRdy > 0)
        then
            -- hide UI panel
            if ( FriendsFrame:IsShown() ) 
            then
                HideUIPanel(FriendsFrame)
            end
            
            GuildAdmin.CurWhoListRdy = GuildAdmin.CurWhoListRdy - 1    
            if GuildAdmin.RecruitNewSearch
            then
                GuildAdmin.RecruitCurWhoList = GuildAdmin:GetRecruitWhoList()
            end
            if GuildAdmin.RelationsNewSearch
            then
                GuildAdmin.RelationsCurWhoList = GuildAdmin:GetRelationsWhoList()
            end
        end

    elseif (event == "FRIENDLIST_UPDATE")
    then
        if GuildAdmin:IsGuildInfoAvailable()
        then
            GuildAdmin:UpdateFriendsDatabase()
        end        
    end
    
    if self[event] 
    then 
        return self[event](self, event, ...) 
    end 
end)
-- ==============================================================================
