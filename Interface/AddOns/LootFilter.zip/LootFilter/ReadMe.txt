For the latest information, change log, documentation and releases visit:

http://www.lootfilter.com

or

http://wow.curse.com/downloads/wow-addons/details/loot-filter.aspx