local skins =
{
    [1] = nUI_HUDSKIN_HEALTHPOWER_TARGET,
    [2] = nUI_HUDSKIN_PLAYERTARGET_TARGET,
};

local myLevelBlock =
{
        anchor =
        {
            anchor_pt   = "TOPLEFT",
            relative_to = "$parent_Power",
            xOfs        = 60,
            yOfs        = 0,
        },		
        options =
        {
            enabled = true,
            size    = 35,
            inset   = 0,
            strata  = nil,
            level   = 2,
            
            label =
            {
                enabled     = true,
                fontsize    = 16,
                justifyH    = "RIGHT",
                justifyV    = "MIDDLE",
                anchor_pt   = "RIGHT",
                xOfs        = 0,
                yOfs        = 1,					
                color       = { r = 0, g = 0.83, b = 0, a = 1 },
            },
        },
};

local frame = CreateFrame( "Frame", "nUI_HUDLevel", UIParent );

local function onEvent()
    for i in pairs(skins) do
        local skinName = skins[i];

		if nUI_UnitSkins[skinName] then
			nUI_UnitSkins[skinName].elements["Level"] = myLevelBlock;
        end
    end
end

frame:SetScript( "OnEvent", onEvent );
frame:RegisterEvent( "ADDON_LOADED" );
