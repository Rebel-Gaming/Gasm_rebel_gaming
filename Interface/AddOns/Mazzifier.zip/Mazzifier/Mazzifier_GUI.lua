-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

local Mazzifier_ButtonMenuMapping = { currentMenuNum = {}, globalIndexNum = {}}
local Mazzifier_SkinMenuMapping = { currentMenuNum = {}, globalIndexNum = {}}
local BClass = AceLibrary("Babble-Class-2.2")

function Mazzifier:GUI_GoNextPage()
    local currentFrame = PanelTemplates_GetSelectedTab(Mazzifier_Frame) 
    if (currentFrame < 8) then 
        Mazzifier:GUI_TabSelect(nil,currentFrame+1)
    else
        Mazzifier:GUI_TabSelect(nil,1)
        Mazzifier_Button:Show()
        Mazzifier_Mazzlegasm:Show()
        Mazzifier_NextButton:Hide()
        Mazzifier:ScheduleRepeatingEvent("Mazzifier_ReloadColorTimer",self.ReloadChangeColor, 0.1, self)
    end
end

function Mazzifier:ReloadChangeColor()
    Mazzifier_ReloadUIButton:SetTextColor(random(),random(),random())
    Mazzifier_MazzlegasmTitle:SetTextColor(random(),random(),random())
end

function Mazzifier:GUI_MazzlegasmDropDown_OnLoad()
	UIDropDownMenu_Initialize(Mazzifier_MazzlegasmDropDown, self.GUI_MazzlegasmDropDown_Initialize);
	Mazzifier_MazzlegasmDropDown.tooltip = "";
	UIDropDownMenu_SetWidth(300, Mazzifier_MazzlegasmDropDown);
	UIDropDownMenu_JustifyText("CENTER", Mazzifier_MazzlegasmDropDown)
end

function Mazzifier:GUI_MazzlegasmDropDown_Initialize()
	local info = {func = Mazzifier.MazzlegasmDropDown_OnClick,}
	info.text = "Scream my ecstacy from the highest mountain!"; info.value = 1;
	if ( Mazzifier_CurrentInstallOptions.Mazzlegasm == 1) then 
	    info.checked = 1; 
	else info.checked = nil; end
	UIDropDownMenu_AddButton(info);

	info.text = "Let those closest to me know how I feel!"; info.value = 2;
	if ( Mazzifier_CurrentInstallOptions.Mazzlegasm == 2) then 
	    info.checked = 2; 
	else info.checked = nil; end
	UIDropDownMenu_AddButton(info);

	info.text = "Bite my lip and keep it in.  I am too shy!"; info.value = 3;
	if ( Mazzifier_CurrentInstallOptions.Mazzlegasm == 3) then 
	    info.checked = 3; 
	else info.checked = nil; end
	UIDropDownMenu_AddButton(info);

    	UIDropDownMenu_SetSelectedID(Mazzifier_MazzlegasmDropDown, Mazzifier_CurrentInstallOptions.Mazzlegasm);
--    	UIDropDownMenu_SetText(info.text)
    UIDropDownMenu_SetSelectedValue(Mazzifier_MazzlegasmDropDown, Mazzifier_CurrentInstallOptions.Mazzlegasm);
end

function Mazzifier:MazzlegasmDropDown_OnClick()
	UIDropDownMenu_SetSelectedValue(Mazzifier_MazzlegasmDropDown, this.value);
	Mazzifier_CurrentInstallOptions.Mazzlegasm = this.value;
end

function Mazzifier:GUI_ButtonDropDown_OnLoad()
	UIDropDownMenu_Initialize(this, self.GUI_ButtonDropDown_Initialize);
	Mazzifier_ButtonDropDown.tooltip = "Various layouts designed by Mazzlefizz or submitted by the beta-testers";
	UIDropDownMenu_SetWidth(300, Mazzifier_ButtonDropDown);
	UIDropDownMenu_JustifyText("CENTER", Mazzifier_ButtonDropDown)
end

function Mazzifier:GUI_ButtonDropDown_Initialize()
	local selectedValue = UIDropDownMenu_GetSelectedValue(Mazzifier_ButtonDropDown);
	local info;
    local valcnt = 0
    for index,value in pairs(Mazzifier_ButtonInfo) do
        if ((Mazzifier_ButtonInfo[index].classes == "All") or (Mazzifier_ButtonInfo[index].classes == Mazzifier:Capitalize(BClass:GetReverseTranslation(UnitClass("player"))))) then
            valcnt = valcnt + 1
        	info = {};
        	info.text = Mazzifier_ButtonInfo[index].name;
        	info.func = Mazzifier.GUI_ButtonDropDown_OnClick;
        	info.value = valcnt
        	if ( info.value == selectedValue ) then
        		info.checked = 1;
        	end
        	UIDropDownMenu_AddButton(info);
        	Mazzifier_ButtonMenuMapping.globalIndexNum[valcnt] = index
        	Mazzifier_ButtonMenuMapping.currentMenuNum[index] = valcnt
        end
    end
end

function Mazzifier:GUI_SetLayoutDefault()
    local defaultLayoutNum = nil
    if (Mazzifier_C_InstalledVersionDB and Mazzifier_C_InstalledVersionDB.ButtonLayout) then
        for i=1, table.getn(Mazzifier_ButtonInfo), 1 do
            if (Mazzifier_C_InstalledVersionDB.ButtonLayout.name == Mazzifier_ButtonInfo[i].devname) then
                defaultLayoutNum = i
            end
        end
    end
    if (not defaultLayoutNum) then
        for i=1, table.getn(Mazzifier_ButtonInfo), 1 do
            if (Mazzifier_DefaultLayout[BClass:GetReverseTranslation(UnitClass("player"))] == Mazzifier_ButtonInfo[i].devname) then
                defaultLayoutNum = i
            end
        end
    end
    local currNum = Mazzifier_ButtonMenuMapping.currentMenuNum[defaultLayoutNum] or 1
        
	UIDropDownMenu_SetSelectedID(Mazzifier_ButtonDropDown, currNum);
	Mazzifier:GUI_SetLayoutChosen(defaultLayoutNum)
	UIDropDownMenu_SetText(Mazzifier_ButtonInfo[defaultLayoutNum].name, Mazzifier_ButtonDropDown)
end

function Mazzifier:GUI_SetLayoutChosen(layoutNumber)
    MazzleLayoutPict:SetTexture("Interface\\AddOns\\Mazzifier\\images\\"..Mazzifier_ButtonInfo[layoutNumber].image)
    Mazzifier_Tab4DescriptionText:SetText(Mazzifier_ButtonInfo[layoutNumber].description)
    Mazzifier_CurrentInstallOptions.ButtonLayout.name = Mazzifier_ButtonInfo[layoutNumber].devname
    Mazzifier_CurrentInstallOptions.ButtonLayout.version = Mazzifier_ButtonInfo[layoutNumber].lastUpdate
end

function Mazzifier:GUI_ButtonDropDown_OnClick()
	UIDropDownMenu_SetSelectedValue(Mazzifier_ButtonDropDown, this.value);
	Mazzifier:GUI_SetLayoutChosen(Mazzifier_ButtonMenuMapping.globalIndexNum[this.value])
end

function Mazzifier:GUI_SkinDropDown_OnLoad()
	UIDropDownMenu_Initialize(this, self.GUI_SkinDropDown_Initialize);
	Mazzifier_SkinDropDown.tooltip = "Various skins to change the artwork and layout of MazzleUI";
	UIDropDownMenu_SetWidth(300, Mazzifier_SkinDropDown);
	UIDropDownMenu_JustifyText("CENTER", Mazzifier_SkinDropDown)
end

function Mazzifier:GUI_SkinDropDown_Initialize()
	local selectedValue = UIDropDownMenu_GetSelectedValue(Mazzifier_SkinDropDown);
    local name, title, notes, enabled, loadable, reason, security
	local info;
    local valcnt = 0
    for index,value in pairs(Mazzifier_SkinInfo) do
        name, title, notes, enabled, loadable, reason, security = GetAddOnInfo(Mazzifier_SkinInfo[index].lodName)
        if (reason ~= "MISSING" ) then
            valcnt = valcnt + 1
        	info = {};
        	info.text = Mazzifier_SkinInfo[index].name;
        	info.func = Mazzifier.GUI_SkinDropDown_OnClick;
        	info.value = valcnt
        	if ( info.value == selectedValue ) then
        		info.checked = 1;
        	end
        	UIDropDownMenu_AddButton(info);
        	Mazzifier_SkinMenuMapping.globalIndexNum[valcnt] = index
        	Mazzifier_SkinMenuMapping.currentMenuNum[index] = valcnt
        end
    end
end

function Mazzifier:GUI_SetSkinDefault()
    local defaultLayoutNum = nil
    if (Mazzifier_CurrentInstallOptions and Mazzifier_CurrentInstallOptions.Skin) then
        for i=1, table.getn(Mazzifier_SkinInfo), 1 do
            if (Mazzifier_CurrentInstallOptions.Skin == Mazzifier_SkinInfo[i].devname) then
                defaultLayoutNum = i
            end
        end
    end
    if (not defaultLayoutNum) then
        for i=1, table.getn(Mazzifier_SkinInfo), 1 do
            if ( Mazzifier_SkinInfo[i].devname == "default") then
                defaultLayoutNum = i
            end
        end
    end
    local currNum = Mazzifier_SkinMenuMapping.currentMenuNum[defaultLayoutNum] or 1
        
	UIDropDownMenu_SetSelectedID(Mazzifier_SkinDropDown, currNum);
	Mazzifier:GUI_SetSkinChosen(defaultLayoutNum)
	UIDropDownMenu_SetText(Mazzifier_SkinInfo[defaultLayoutNum].name, Mazzifier_SkinDropDown)
end

function Mazzifier:GUI_SetSkinChosen(layoutNumber)
    MazzleSkinPict:SetTexture("Interface\\AddOns\\Mazzifier\\images\\"..Mazzifier_SkinInfo[layoutNumber].image)
    Mazzifier_Tab5DescriptionText:SetText(Mazzifier_SkinInfo[layoutNumber].description)
    Mazzifier_CurrentInstallOptions.Skin = Mazzifier_SkinInfo[layoutNumber].devname
    Mazzifier_CurrentInstallOptions.SkinLOD = Mazzifier_SkinInfo[layoutNumber].lodName
end

function Mazzifier:GUI_SkinDropDown_OnClick()
	UIDropDownMenu_SetSelectedValue(Mazzifier_SkinDropDown, this.value);
	Mazzifier:GUI_SetSkinChosen(Mazzifier_SkinMenuMapping.globalIndexNum[this.value])
end

function Mazzifier:GUI_HideTabContents(allBut)
    for i=1, 5, 1 do getglobal("Mazzifier_Tab"..i):Hide(); end
    getglobal("Mazzifier_Tab"..allBut):Show(); 
end

function Mazzifier:GUI_TabSelect(tabName, tabNum)
    self:GUI_SaveScrollPosition()
	PanelTemplates_Tab_OnClick(Mazzifier_Frame);
    if ((tabName == "Mazzifier_FrameTab1") or (tabNum == 1)) then
        PanelTemplates_SetTab(Mazzifier_Frame, 1)
        self:GUI_HideTabContents(1)
    elseif ((tabName == "Mazzifier_FrameTab2") or (tabNum == 2)) then
        PanelTemplates_SetTab(Mazzifier_Frame, 2)
        self:GUI_HideTabContents(2)
    elseif ((tabName == "Mazzifier_FrameTab3") or (tabNum == 3)) then
        PanelTemplates_SetTab(Mazzifier_Frame, 3)
        self:GUI_HideTabContents(3)
        Mazzifier:GUI_ASLayoutWidgets(3)
        Mazzifier:GUI_AbleAddonselection(Mazzifier_CurrentInstallOptions.AddonSelection)
    elseif ((tabName == "Mazzifier_FrameTab4") or (tabNum == 4)) then
        PanelTemplates_SetTab(Mazzifier_Frame, 4)
        self:GUI_HideTabContents(3)
        Mazzifier:GUI_ASLayoutWidgets(4)
        Mazzifier:GUI_AbleAddonselection(Mazzifier_CurrentInstallOptions.AddonSelection)
    elseif ((tabName == "Mazzifier_FrameTab5") or (tabNum == 5)) then
        PanelTemplates_SetTab(Mazzifier_Frame, 5)
        self:GUI_HideTabContents(3)
        Mazzifier:GUI_ASLayoutWidgets(5)
        Mazzifier:GUI_AbleAddonselection(Mazzifier_CurrentInstallOptions.AddonSelection)
    elseif ((tabName == "Mazzifier_FrameTab6") or (tabNum == 6)) then
        PanelTemplates_SetTab(Mazzifier_Frame, 6)
        self:GUI_HideTabContents(3)
        Mazzifier:GUI_ASLayoutWidgets(6)
        Mazzifier:GUI_AbleAddonselection(Mazzifier_CurrentInstallOptions.Addons)
        if (Mazzifier_CurrentInstallOptions.Addons) then Mazzifier:GUI_AbleAddonLoaded(); end
    elseif ((tabName == "Mazzifier_FrameTab7") or (tabNum == 7)) then
        PanelTemplates_SetTab(Mazzifier_Frame, 7)
        self:GUI_HideTabContents(4)
    elseif ((tabName == "Mazzifier_FrameTab8") or (tabNum == 8)) then
        PanelTemplates_SetTab(Mazzifier_Frame, 8)
        self:GUI_HideTabContents(5)
    end        
    self:GUI_RestoreScrollPosition()
end

function Mazzifier:GUI_Initialize()

    Mazzifier:GUI_SetupInitialValues()
    Mazzifier:GUI_MazzlegasmDropDown_OnLoad();
    Mazzifier_Tab4DescriptionTitle:SetText("Description:");
    PanelTemplates_SetNumTabs(Mazzifier_Frame, 8);
    Mazzifier_Frame.selectedTab=1;
    PanelTemplates_UpdateTabs(Mazzifier_Frame);
    
	local button, string, checked;
	for index, value in pairs(Mazzifier_FrameCheckButtons) do
		button = getglobal("Mazzifier_FrameCheckButton"..value.index);
		string = getglobal("Mazzifier_FrameCheckButton"..value.index.."Text");
		checked = nil;
		button.disabled = nil;
		button:SetID(value.index);
		if ( value.func ) then
			checked = value.func();
		end
		OptionsFrame_EnableCheckBox(button);
		button:SetChecked(checked);
		string:SetText(TEXT(value.labelText));
		if (value.labelText == "") then
		    button:Hide()
		end
		button.tooltipText = value.tooltipText;
	end

    Mazzifier:GUI_InitUpdateMode()
    if (Mazzifier:GUI_DoAddonsNeedUpdate()) then
        Mazzifier_FrameCheckButton4Text:SetText(Mazzifier_FrameCheckButton4Text:GetText().." |CFFFF8000(Needs Update)")
    end
    if (Mazzifier_CurrentPartVersions.Layout > Mazzifier_C_InstalledVersionDB.Layout) then
        Mazzifier_FrameCheckButton5Text:SetText(Mazzifier_FrameCheckButton5Text:GetText().." |CFFFF8000(Needs Update)")
    end
    if (Mazzifier_CurrentPartVersions.AddonSelection > Mazzifier_C_InstalledVersionDB.AddonSelection) then
        Mazzifier_FrameCheckButton75Text:SetText(Mazzifier_FrameCheckButton75Text:GetText().." |CFFFF8000(Needs Update)")
    end
    if (Mazzifier_CurrentPartVersions.Bindings > Mazzifier_C_InstalledVersionDB.Bindings) then
        Mazzifier_FrameCheckButton76Text:SetText(Mazzifier_FrameCheckButton76Text:GetText().." |CFFFF8000(Needs Update)")
    end
    if (Mazzifier:GUI_DoButtonsNeedUpdate()) then
        Mazzifier_FrameCheckButton6Text:SetText(Mazzifier_FrameCheckButton6Text:GetText().." |CFFFF8000(Needs Update)")
    end

    Mazzifier:GUI_SetupASInfo()
    Mazzifier:GUI_SetLayoutDefault()
    Mazzifier:GUI_SetSkinDefault()
    Mazzifier:GUI_TabSelect(nil,1)
end

function Mazzifier:GUI_GetUpdateMode()
	if ((Mazzifier_LastInstalledVersion == 0.0) and Mazzifier_G_InstalledVersionDB.firstInstall) then
	    return 1
	end
    if ((Mazzifier_CurrentPartVersions.Addons > Mazzifier_C_InstalledVersionDB.AddonSet) or
        (Mazzifier_CurrentPartVersions.Layout > Mazzifier_C_InstalledVersionDB.Layout) or
        (Mazzifier_CurrentPartVersions.AddonSelection > Mazzifier_C_InstalledVersionDB.AddonSelection) or
        (Mazzifier_CurrentPartVersions.Bindings > Mazzifier_C_InstalledVersionDB.Bindings) or
        (Mazzifier:GUI_DoButtonsNeedUpdate()) or
        (MazzleUI_LastAspect ~= Mazzifier_CurrentInstallOptions.Aspect)) then
        return 2
    end
    for addonIndexName, addonInfo in pairs(Mazzifier_AddOnInfo) do
        if ((addonInfo.name ~= "") and (Mazzifier:Get_InstalledVersionNumber(addonIndexName) < addonInfo.lastUpdate)) then
           return 2
        end
    end
    -- Add version check for installed button layout
    return 3
end

    
function Mazzifier:GUI_SetupInitialValues()
    local Mazzifier_InstallOptionsDefault = {
        FontSize = 1,
        Buttons = 1,
        SAS = 1,
        Addons = 1,
        Layout = 1,
        AddonSelection = 1,
        Bindings = 1,
        Mazzlegasm = 1,
        Skin = "noobblack",
        AddonExtras = {
            class = true,
            pvp = true,
            raiding = true,
            gatherer = false,
            timerbars = true,
            onebag = false,
            circlebuttons = false,
            auctions = true,
            recap = false,
            sws = false,
            klh = false,
            omen = false,
            recount = false,
            threatmeter = false,
            damageheal = false,
            raidextras = true,
            bigwigs = true,
            dbm = false,
            xrs = false,
            decursive = true,
            corepackage = "full",
            mapnotes = true,
            mapnodes = true, 
            mapquests = true, 
            mapfish = false, 
            maptreasures = true,
            mapvendors = true,
            alts = true,
            data = true,
            namenone = false,
            nametags = false,
            nameplates = true,
            wowhead = true,
            quartz = true,
            incubator = false,
        },
        ButtonLayout = {},
    }
    local Mazzifier_G_InstallVersionsDefault = {
        firstInstall = true,
        lastInstall = 0,
        Addons = {},
    }    
    local Mazzifier_C_InstallVersionsDefault = {
        Layout = 0.0,
        ButtonLayout = {},
        AddonSet = 0.0,
        AddonSelection = 0.0,
        Bindings = 0.0,
        Addons = {},
    }    

    Mazzifier_LastInstalledVersion = Mazzifier_LastInstalledVersion or 0.0
    if (not Mazzifier_C_InstalledVersionDB) then Mazzifier_C_InstalledVersionDB = {} end
    if (not Mazzifier_G_InstalledVersionDB) then Mazzifier_G_InstalledVersionDB = {} end
    Mazzifier_G_InstalledVersionDB = MazzleUI:VerifyDefaults(Mazzifier_G_InstalledVersionDB, Mazzifier_G_InstallVersionsDefault)
    Mazzifier_C_InstalledVersionDB = MazzleUI:VerifyDefaults(Mazzifier_C_InstalledVersionDB, Mazzifier_C_InstallVersionsDefault)
    for theAddOn in pairs(Mazzifier_AddOnInfo) do
        if (Mazzifier_AddOnInfo[theAddOn].name ~= "") then
            if (Mazzifier:Get_InstalledVersionNumber(theAddOn) == 0.0) then
                Mazzifier:Set_InstalledVersionNumber(theAddOn, 0.0)
            end
        end
    end

    if (not Mazzifier_CurrentInstallOptions) then Mazzifier_CurrentInstallOptions = {} end
    Mazzifier_CurrentInstallOptions = MazzleUI:VerifyDefaults(Mazzifier_CurrentInstallOptions, Mazzifier_InstallOptionsDefault)

    Mazzifier_CurrentInstallOptions.Aspect = MazzleUI:GetAspect()
end

function Mazzifier:GUI_InitUpdateMode()
    local theUpdateMode = Mazzifier:GUI_GetUpdateMode()
    if (theUpdateMode == 1) then 
        Mazzifier:GUI_EnterFullMode()
    elseif (theUpdateMode == 2) then 
        Mazzifier:GUI_EnterUpdateMode()
    else
        Mazzifier:GUI_EnterCustomMode()
    end
end

-- Example of legacy code making things truly retarded.  Check out these ids
function Mazzifier:GUI_HandleCheckbutton(theButton)
    local buttonID = theButton:GetID()
    if ((buttonID > 0) and (buttonID <= 3)) then
        Mazzifier:GUI_CheckmarkClick_Aspect(this, buttonID)
    elseif (((buttonID >= 4) and (buttonID <= 7)) or (buttonID == 75) or (buttonID == 76)) then
        Mazzifier:GUI_CheckmarkClick_Parts(this, buttonID)
    elseif ((buttonID >= 8) and (buttonID <= 10)) then
        Mazzifier:GUI_CheckmarkClick_Fonts(this, buttonID)
    elseif (buttonID == 74) then
        Mazzifier:GUI_CheckmarkClick_SAS(this, buttonID)
    elseif ((buttonID >= 13) and (buttonID <= 15)) then
        Mazzifier:GUI_CheckmarkClick_Upgrade(this, buttonID)
    else
        Mazzifier:Print("Mazzifier Error:  Illegal button press ", buttonID)
    end
    --pOptions()
end

function Mazzifier:GUI_GetAddonIndexName(buttonID)
    for theAddonIndex,theAddonInfo in pairs(Mazzifier_AddOnInfo) do
        if (theAddonInfo.index == buttonID) then
            return theAddonIndex
        end
    end
    Mazzifier:Print("Mazzifier Error!  Button ID does not correspond to a valid add-on!")
    return nil
end

function Mazzifier:GUI_AbleButtons(isEnabled)
    if (isEnabled) then
        UIDropDownMenu_EnableDropDown(Mazzifier_ButtonDropDown)
        Mazzifier:GUI_EnableCheckbutton(Mazzifier_FrameCheckButton74)
    else
        UIDropDownMenu_DisableDropDown(Mazzifier_ButtonDropDown)
        OptionsFrame_DisableCheckBox(Mazzifier_FrameCheckButton74, Mazzifier_FrameCheckButton74:GetChecked())
    end
end

function Mazzifier:GUI_AbleSkins(isEnabled)
    if (isEnabled) then
        UIDropDownMenu_EnableDropDown(Mazzifier_SkinDropDown)
    else
        UIDropDownMenu_DisableDropDown(Mazzifier_SkinDropDown)
    end
end

function Mazzifier:GUI_CheckLoadedAddons()
    for theAddonIndex,theAddonInfo in pairs(Mazzifier_AddOnInfo) do
        if (not theAddonInfo.noRequirement) then
            _, _, _, _, loadable, _, _= GetAddOnInfo(theAddonIndex)
            if (loadable) then
                Mazzifier_AddOnInfo[theAddonIndex].loaded = true
            else
                Mazzifier_AddOnInfo[theAddonIndex].loaded = false
            end
        else
            Mazzifier_AddOnInfo[theAddonIndex].loaded = true
        end
    end
end

function Mazzifier:GUI_EnableCheckbutton(theButton)
    local isChecked = theButton:GetChecked()
    OptionsFrame_EnableCheckBox(theButton, isChecked)
    theButton:SetChecked(isChecked)
end
    
function Mazzifier:GUI_CheckmarkClick_Addon(theButton, buttonID)
    local theAddonIndex = Mazzifier:GUI_GetAddonIndexName(buttonID)
    if (Mazzifier_CurrentInstallOptions.AddOnList[theAddonIndex]) then
        if (theButton:GetChecked()) then
            theButton:SetChecked(1)
            return
        else
            Mazzifier_CurrentInstallOptions.AddOnList[theAddonIndex] = nil
            Mazzifier:GUI_EnterModifiedMode()
            return
        end
    else
        if (theButton:GetChecked()) then
            Mazzifier_CurrentInstallOptions.AddOnList[theAddonIndex] = 1
            Mazzifier:GUI_EnterModifiedMode()
            return
        end
    end
end

function Mazzifier:GUI_CheckmarkClick_Aspect(theButton, buttonID)
    if (Mazzifier_CurrentInstallOptions.Aspect ~= buttonID) then 
        Mazzifier_CurrentInstallOptions.Aspect = buttonID
        if (buttonID ~= 1) then Mazzifier_FrameCheckButton1:SetChecked(0) end
        if (buttonID ~= 2) then Mazzifier_FrameCheckButton2:SetChecked(0) end
        if (buttonID ~= 3) then Mazzifier_FrameCheckButton3:SetChecked(0) end
        Mazzifier:GUI_InitUpdateMode();
        Mazzifier:GUI_SetupASInfo();
    else
		getglobal("Mazzifier_FrameCheckButton"..buttonID):SetChecked(1)
    end
end

function Mazzifier:IsDirtyAspect()
    return (Mazzifier_CurrentInstallOptions.Aspect ~= MazzleUI_LastAspect)
end

function Mazzifier:GUI_CheckmarkClick_Fonts(theButton, buttonID)
    if (Mazzifier_CurrentInstallOptions.FontSize ~= (buttonID-7)) then 
        Mazzifier_CurrentInstallOptions.FontSize = buttonID - 7
        if (buttonID ~= 8) then Mazzifier_FrameCheckButton8:SetChecked(0) end
        if (buttonID ~= 9) then Mazzifier_FrameCheckButton9:SetChecked(0) end
        if (buttonID ~= 10) then Mazzifier_FrameCheckButton10:SetChecked(0) end
    else
		getglobal("Mazzifier_FrameCheckButton"..buttonID):SetChecked(1)
    end
end


function Mazzifier:GUI_CheckmarkClick_Parts(theButton, buttonID)
    if (buttonID == 75) then
        Mazzifier_CurrentInstallOptions.AddonSelection = theButton:GetChecked()
    elseif (buttonID == 4) then
        Mazzifier_CurrentInstallOptions.Addons = theButton:GetChecked()
    elseif (buttonID == 5) then
        Mazzifier_CurrentInstallOptions.Layout = theButton:GetChecked()
        Mazzifier:GUI_AbleSkins(Mazzifier_CurrentInstallOptions.Layout)
    elseif (buttonID == 6) then
        Mazzifier_CurrentInstallOptions.Buttons = theButton:GetChecked()
        Mazzifier:GUI_AbleButtons(Mazzifier_CurrentInstallOptions.Buttons)
    elseif (buttonID == 76) then
        Mazzifier_CurrentInstallOptions.Bindings= theButton:GetChecked()
    end
    Mazzifier:GUI_EnterModifiedMode()
end

function Mazzifier:GUI_CheckmarkClick_Upgrade(theButton, buttonID)
    if ((Mazzifier_CurrentInstallOptions.updateMode=="full") and (buttonID == 13)) then 
        Mazzifier_FrameCheckButton13:SetChecked(1)
    elseif ((Mazzifier_CurrentInstallOptions.updateMode=="upgrade") and (buttonID == 14)) then 
        Mazzifier_FrameCheckButton14:SetChecked(1)
    elseif ((Mazzifier_CurrentInstallOptions.updateMode=="custom") and (buttonID == 15)) then 
        Mazzifier_FrameCheckButton15:SetChecked(1)
    else
        if (buttonID == 13) then
            Mazzifier:GUI_EnterFullMode()
        elseif (buttonID == 14) then
            Mazzifier:GUI_EnterUpdateMode()
        elseif (buttonID == 15) then
            Mazzifier:GUI_EnterCustomMode()
        end
        if (buttonID ~= 13) then Mazzifier_FrameCheckButton13:SetChecked(0) end
        if (buttonID ~= 14) then Mazzifier_FrameCheckButton14:SetChecked(0) end
        if (buttonID ~= 15) then Mazzifier_FrameCheckButton15:SetChecked(0) end
    end
end

function Mazzifier:GUI_CheckmarkClick_SAS(theButton, buttonID)
    if (theButton:GetChecked()) then
        Mazzifier_CurrentInstallOptions.SAS = true
        theButton:SetChecked(1)
    else
        Mazzifier_CurrentInstallOptions.SAS = false
        theButton:SetChecked(0)
    end
end

function Mazzifier:GUI_DoButtonsNeedUpdate()
    if (Mazzifier_C_InstalledVersionDB and Mazzifier_C_InstalledVersionDB.ButtonLayout) then
        for i=1, table.getn(Mazzifier_ButtonInfo), 1 do
            if (Mazzifier_C_InstalledVersionDB.ButtonLayout.name == Mazzifier_ButtonInfo[i].devname) then
                return (Mazzifier_ButtonInfo[i].lastUpdate > Mazzifier_C_InstalledVersionDB.ButtonLayout.version)
            end
        end
    end
    return true
end

function Mazzifier:GUI_DoAddonsNeedUpdate()
    local function forThisClass(a)
        local modInfo = MazzleUI_AddOn_DB[a]
        if (modInfo and modInfo.classes and (not modInfo.classes[self:Capitalize(BClass:GetReverseTranslation(UnitClass("player")))])) then return false; else return true; end;
    end
    if (Mazzifier_C_InstalledVersionDB and Mazzifier_C_InstalledVersionDB.Addons and Mazzifier_G_InstalledVersionDB and Mazzifier_G_InstalledVersionDB.Addons) then
        for addonIndexName, addonInfo in pairs(Mazzifier_AddOnInfo) do
            if ((addonInfo.name ~= "") and (Mazzifier:Get_InstalledVersionNumber(addonIndexName) < addonInfo.lastUpdate) and forThisClass(addonIndexName)) then
                return true;
            end
        end
        return Mazzifier:IsDirtyAspect()
    end
    return (Mazzifier_CurrentPartVersions.Addons > Mazzifier_C_InstalledVersionDB.AddonSet)
end

function Mazzifier:GUI_EnterUpdateMode()
    Mazzifier_CurrentInstallOptions.updateMode = "upgrade"
    Mazzifier_CurrentInstallOptions.Buttons = (Mazzifier:GUI_DoButtonsNeedUpdate() or (MazzleUI_LastAspect ~= Mazzifier_CurrentInstallOptions.Aspect))
    Mazzifier_CurrentInstallOptions.Addons = Mazzifier:GUI_DoAddonsNeedUpdate()
    Mazzifier_CurrentInstallOptions.Layout = ((Mazzifier_CurrentPartVersions.Layout > Mazzifier_C_InstalledVersionDB.Layout) or (MazzleUI_LastAspect ~= Mazzifier_CurrentInstallOptions.Aspect))
    Mazzifier_CurrentInstallOptions.Bindings = (Mazzifier_CurrentPartVersions.Bindings > Mazzifier_C_InstalledVersionDB.Bindings)
    Mazzifier_CurrentInstallOptions.AddonSelection = (Mazzifier_CurrentPartVersions.AddonSelection > Mazzifier_C_InstalledVersionDB.AddonSelection)
    Mazzifier_CurrentInstallOptions.AddOnList = {}
    for addonIndexName, addonInfo in pairs(Mazzifier_AddOnInfo) do
        if (addonInfo.name ~= "") then
    		Mazzifier_CurrentInstallOptions.AddOnList[addonIndexName] = (addonInfo.lastUpdate > Mazzifier:Get_InstalledVersionNumber(addonIndexName))
        end
    end
    -- If a layout for this class has a version number then set the button menu to that item, otherwise set to default for that class
    Mazzifier_WelcomeFrameText:SetText(Mazzifier_UpgradeText..Mazzifier:WarnRemovedAddons())
    Mazzifier:GUI_InstantiateCurrentOptions()
end

function Mazzifier:GUI_EnterModifiedMode()
    Mazzifier_CurrentInstallOptions.updateMode = "custom"
    Mazzifier_FrameCheckButton13:SetChecked(0)
    Mazzifier_FrameCheckButton14:SetChecked(0)
    Mazzifier_FrameCheckButton15:SetChecked(1)
    Mazzifier_WelcomeFrameText:SetText(Mazzifier_UpgradeText..Mazzifier:WarnRemovedAddons())
end

function Mazzifier:GUI_EnterCustomMode()
    Mazzifier_CurrentInstallOptions.updateMode = "custom"
    Mazzifier_CurrentInstallOptions.Buttons = nil
    Mazzifier_CurrentInstallOptions.Addons = nil
    Mazzifier_CurrentInstallOptions.AddonSelection = nil
    Mazzifier_CurrentInstallOptions.Layout = nil
    Mazzifier_CurrentInstallOptions.Bindings = nil
    Mazzifier_CurrentInstallOptions.AddOnList = {}
    for addonIndexName, addonInfo in pairs(Mazzifier_AddOnInfo) do
        if (addonInfo.name ~= "") then
    		Mazzifier_CurrentInstallOptions.AddOnList[addonIndexName] = nil
        end
    end
    Mazzifier_WelcomeFrameText:SetText(Mazzifier_UpgradeText..Mazzifier:WarnRemovedAddons())
    Mazzifier:GUI_InstantiateCurrentOptions()
end

function Mazzifier:GUI_EnterFullMode()
    Mazzifier_CurrentInstallOptions.updateMode = "full"
    Mazzifier_CurrentInstallOptions.Buttons = 1
    Mazzifier_CurrentInstallOptions.Addons = 1
    Mazzifier_CurrentInstallOptions.Layout = 1
    Mazzifier_CurrentInstallOptions.AddonSelection = 1
    Mazzifier_CurrentInstallOptions.Bindings = 1
    Mazzifier_CurrentInstallOptions.AddOnList = {}
    for addonIndexName, addonInfo in pairs(Mazzifier_AddOnInfo) do
        if (addonInfo.name ~= "") then
    		Mazzifier_CurrentInstallOptions.AddOnList[addonIndexName] = 1
        end
    end
    Mazzifier_WelcomeFrameText:SetText(Mazzifier_WelcomeText..Mazzifier:WarnRemovedAddons())
            
    -- If a layout for this class has a version number then set the button menu to that item, otherwise set to default for that class
    Mazzifier:GUI_InstantiateCurrentOptions()
end

function Mazzifier:GUI_InstantiateCurrentOptions()
    if (Mazzifier_CurrentInstallOptions.Addons) then Mazzifier_FrameCheckButton4:SetChecked(1) else Mazzifier_FrameCheckButton4:SetChecked(0) end
    if (Mazzifier_CurrentInstallOptions.Layout) then Mazzifier_FrameCheckButton5:SetChecked(1) else Mazzifier_FrameCheckButton5:SetChecked(0) end
    Mazzifier:GUI_AbleSkins(Mazzifier_CurrentInstallOptions.Layout)
    if (Mazzifier_CurrentInstallOptions.Buttons) then Mazzifier_FrameCheckButton6:SetChecked(1) else Mazzifier_FrameCheckButton6:SetChecked(0) end
    Mazzifier:GUI_AbleButtons(Mazzifier_CurrentInstallOptions.Buttons)
    if (Mazzifier_CurrentInstallOptions.AddonSelection) then Mazzifier_FrameCheckButton75:SetChecked(1) else Mazzifier_FrameCheckButton75:SetChecked(0) end
    if (Mazzifier_CurrentInstallOptions.Bindings) then Mazzifier_FrameCheckButton76:SetChecked(1) else Mazzifier_FrameCheckButton76:SetChecked(0) end
    if (Mazzifier_CurrentInstallOptions.SAS) then Mazzifier_FrameCheckButton74:SetChecked(1) else Mazzifier_FrameCheckButton74:SetChecked(0) end

    getglobal("Mazzifier_FrameCheckButton"..Mazzifier_CurrentInstallOptions.Aspect):SetChecked(1)
    getglobal("Mazzifier_FrameCheckButton"..(Mazzifier_CurrentInstallOptions.FontSize+7)):SetChecked(1)
    if (Mazzifier_CurrentInstallOptions.updateMode == "full") then
        Mazzifier_FrameCheckButton13:SetChecked(1)
        Mazzifier_FrameCheckButton14:SetChecked(0)
        Mazzifier_FrameCheckButton15:SetChecked(0)
    elseif (Mazzifier_CurrentInstallOptions.updateMode == "upgrade") then
        Mazzifier_FrameCheckButton13:SetChecked(0)
        Mazzifier_FrameCheckButton14:SetChecked(1)
        Mazzifier_FrameCheckButton15:SetChecked(0)
    elseif (Mazzifier_CurrentInstallOptions.updateMode == "custom") then
        Mazzifier_FrameCheckButton13:SetChecked(0)
        Mazzifier_FrameCheckButton14:SetChecked(0)
        Mazzifier_FrameCheckButton15:SetChecked(1)
    end

    for addonIndexName, addonInfo in pairs(Mazzifier_AddOnInfo) do
        if (addonInfo.name ~= "") then
            if (not addonInfo.loaded) then
                Mazzifier_CurrentInstallOptions.AddOnList[addonIndexName] = nil
            end
        end
    end

end

function Mazzifier:Capitalize(str)
   returnstr = strlower(str)
   returnstr = strupper(returnstr.sub(returnstr,1,1))..returnstr.sub(returnstr, 2)
   return returnstr
end
