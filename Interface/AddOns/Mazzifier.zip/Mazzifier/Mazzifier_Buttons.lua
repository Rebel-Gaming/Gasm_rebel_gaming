-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--
local TranslationMap = {}
local lastLayoutNum, lastLayoutAspect = nil, nil
local closedList = {}
local BS = AceLibrary("Babble-Spell-2.2")


function Mazzifier:GetLayoutName(layoutNum, aspectRatio)
    if (not aspectRatio) then aspectRatio = Mazzifier_CurrentInstallOptions.Aspect; end;
    local aspectSuffix
    if (aspectRatio == 1) then aspectSuffix = "125";
    elseif (aspectRatio == 2) then aspectSuffix = "133";
    elseif (aspectRatio == 3) then aspectSuffix = "16"; end;

    return Mazzifier_ButtonInfo[layoutNum].devname.."_"..aspectSuffix, "setupFunc"..aspectSuffix
end

function Mazzifier:IsDruid(layoutNum)
    return ((Mazzifier_ButtonInfo[layoutNum].devname == "DruidMazzle") or (Mazzifier_ButtonInfo[layoutNum].devname == "DruidSimple"))
end

function Mazzifier:GetEffectiveLayoutAspect( layoutNum, aspectRatio)
    if (aspectRatio == 3) then return 3; end;
    if (aspectRatio == 2) then
        if (Mazzifier_ButtonInfo[layoutNum].setupFunc133 == Mazzifier_ButtonInfo[layoutNum].setupFunc16) then
            return 3; else return 2; 
        end;
    end
    if (aspectRatio == 1) then
        if (Mazzifier_ButtonInfo[layoutNum].setupFunc125 == Mazzifier_ButtonInfo[layoutNum].setupFunc133) then
            if (Mazzifier_ButtonInfo[layoutNum].setupFunc133 == Mazzifier_ButtonInfo[layoutNum].setupFunc16) then
                return 3; else return 2;
            end;
        else return 1; end;
    end
end

function Mazzifier:CompressBar(theBar)
    Mazzifier:ClosedListReset()
    local newBar, newActions = {}, {}
    local barSize = 0
    newBar = MazzleUI:CloneTable(theBar)
    for j=1, theBar.pages, 1 do
        newBar.contents["page_"..j] = {}
    end
    for i=1, theBar.numButtons, 1 do
        local shouldAdd = false
        for j=1, theBar.pages, 1 do
            if (self:ActionExists(theBar.contents["page_"..j][i].action, theBar.allowDuplicates)) then
                shouldAdd = true;
            end
        end
        if (i == theBar.numButtons) and (barSize == 0) then shouldAdd = true; end
        if (shouldAdd) then
            barSize = barSize + 1
            for j=1, theBar.pages, 1 do
                newBar.contents["page_"..j][barSize] = theBar.contents["page_"..j][i]
            end
        end
    end
    newBar.numButtons = barSize
    Mazzifier:ClosedListReset()
    return newBar
end

--function testCompress(layoutNum, barNum)
--    aspectRatio = Mazzifier:GetEffectiveLayoutAspect(layoutNum, 3)
--    local newLayoutName, setupFuncName = Mazzifier:GetLayoutName(layoutNum, aspectRatio)
--    Mazzifier:Print("Testing bar", barNum, " in layout ", newLayoutName)
--    local newBar
--    --Mazzifier:Print("Original bar has ", Mazzifier_Bongo_Layouts[newLayoutName][barNum].numButtons, "buttons")
--    newBar = Mazzifier:CompressBar(Mazzifier_Bongo_Layouts[newLayoutName][barNum])
--    --Mazzifier:Print("New bar has ", newBar.numButtons, "buttons")
--    Mazzifier:PrintLiteral("Old Bar: ", Mazzifier_Bongo_Layouts[newLayoutName][barNum])
--    Mazzifier:PrintLiteral("New Bar: ", newBar)
--end

function Mazzifier:Setup_Bongos(layoutNum, aspectRatio, dontPlaceSpells, dontUseCache)

    aspectRatio = Mazzifier:GetEffectiveLayoutAspect(layoutNum, aspectRatio)
    lastLayoutNum, lastLayoutAspect = layoutNum, aspectRatio
    
    local newLayoutName, setupFuncName = Mazzifier:GetLayoutName(layoutNum, aspectRatio)
    local isDruid = Mazzifier:IsDruid(layoutNum)
    
    self:Print("Setting up layout ", newLayoutName, " in Bongos.")

    MazzleUI:Execute("/bob reset")
    if (dontUseCache) then Mazzifier_Bongo_Layouts = Exported_Layouts; end
    
    local numBars = #(Mazzifier_Bongo_Layouts[newLayoutName])
    MazzleUI:CreateSet("BongosProfiles.MazzleUI", {})
    BongosProfiles.MazzleUI.BongosSets = {
			["locked"] = 1, ["dontReuse"] = 1, ["version"] = 61214, ["sticky"] = nil}
    BongosProfiles.MazzleUI["BActionSets.g"] = {
			["buttonsLocked"] = 1,
			["rightClickSelfCast"] = 1,
			["tooltips"] = 1,
			["colorOutOfRange"] = 1,
			["version"] = "6.12.14",
			["rangeColor"] = {
				["b"] = 0.5,
				["g"] = 0.5,
				["r"] = 1,
			},
			["quickMove"] = 2,
		}
    BongosProfiles.MazzleUI["BActionSets.g"].numActionBars = numBars
    local lastSize
    local thisBar = {}
    local globalShowGrid = false
    for i=1, numBars, 1 do
        --self:Print("Setting up bar ", i)
        BongosProfiles.MazzleUI["BActionSets."..i] = {}
        if (not Mazzifier_Bongo_Layouts[newLayoutName][i].hideEmpty) then
            BongosProfiles.MazzleUI["BActionSets."..i].showEmpty = true
            thisBar[i] = Mazzifier_Bongo_Layouts[newLayoutName][i]
        else
            thisBar[i] = self:CompressBar(Mazzifier_Bongo_Layouts[newLayoutName][i])
        end
        if (thisBar[i].numButtons == 0) then
			thisBar[i]["contents"] = {["page_1"] = {[1] = {},},}
			thisBar[i]["numButtons"] = 1
			thisBar[i]["pages"] = 1
			thisBar[i]["stances"] = nil
			thisBar[i]["buttonSize"] = 0
			thisBar[i]["spacing"] = 0
            BongosProfiles.MazzleUI["BActionSets."..i].vis = nil
        else                
            BongosProfiles.MazzleUI["BActionSets."..i].vis = 1
        end
        if (thisBar[i]["stances"] and isDruid) then thisBar[i]["stances"] = Mazzifier:GetDruidShapeshiftForms(); end;
        
        BongosProfiles.MazzleUI["BActionSets."..i].x = 0
        BongosProfiles.MazzleUI["BActionSets."..i].y = 0
        BongosProfiles.MazzleUI["BActionSets."..i].size = thisBar[i].numButtons
        if (thisBar[i].rows > 1) then
            BongosProfiles.MazzleUI["BActionSets."..i].cols = math.ceil(thisBar[i].numButtons/thisBar[i].rows)
        end

        if (lastSize) then
            if (math.abs(thisBar[i].buttonSize - lastSize) > 3) then
                lastSize = thisBar[i].buttonSize
            end
        else lastSize = thisBar[i].buttonSize; end;
        if (lastSize ~= 40) then
            BongosProfiles.MazzleUI["BActionSets."..i].scale = (lastSize / 40)
        end

        if (thisBar[i].pages > 1) then
            BongosProfiles.MazzleUI["BActionSets."..i].paging = 1
            BongosProfiles.MazzleUI["BActionSets."..i].numPages = thisBar[i].pages
        end
        if (thisBar[i].spacing) then
            BongosProfiles.MazzleUI["BActionSets."..i].space = thisBar[i].spacing
        end
        if (thisBar[i].showGridGlobally) then
            globalShowGrid = true
        end

        if (thisBar[i].stances) then
            BongosProfiles.MazzleUI["BActionSets."..i].stances = thisBar[i].stances
        end
    end
    thisBar.petbar = Mazzifier_Bongo_Layouts[newLayoutName].petbar
    thisBar.classbar = Mazzifier_Bongo_Layouts[newLayoutName].classbar
    thisBar.keybar = Mazzifier_Bongo_Layouts[newLayoutName].keybar
    thisBar.menubar = Mazzifier_Bongo_Layouts[newLayoutName].menubar
    thisBar.bagbar = Mazzifier_Bongo_Layouts[newLayoutName].bagbar
    
    BongosProfiles.MazzleUI["BActionSets.pet"] = {}
    BongosProfiles.MazzleUI["BActionSets.pet"].x = 0
    BongosProfiles.MazzleUI["BActionSets.pet"].y = 0
    BongosProfiles.MazzleUI["BActionSets.pet"].vis = 1
    BongosProfiles.MazzleUI["BActionSets.pet"].scale = thisBar.petbar.scale
    if (thisBar.petbar.layout == 4) then
        BongosProfiles.MazzleUI["BActionSets.pet"].rows = 5
        BongosProfiles.MazzleUI["BActionSets.pet"].space = thisBar.petbar.vspacing
    else
        BongosProfiles.MazzleUI["BActionSets.pet"].space = thisBar.petbar.hspacing
    end
    
    BongosProfiles.MazzleUI["BActionSets.class"] = {}
    BongosProfiles.MazzleUI["BActionSets.class"].x = 0
    BongosProfiles.MazzleUI["BActionSets.class"].y = 0
    BongosProfiles.MazzleUI["BActionSets.class"].vis = 1
    BongosProfiles.MazzleUI["BActionSets.class"].scale = thisBar.classbar.scale
    if (thisBar.classbar.layout == 4) then
        BongosProfiles.MazzleUI["BActionSets.class"].rows = 5
        BongosProfiles.MazzleUI["BActionSets.class"].space = thisBar.classbar.vspacing
    else
        BongosProfiles.MazzleUI["BActionSets.class"].space = thisBar.classbar.hspacing
    end

    BongosProfiles.MazzleUI["BActionSets.key"] = {["vis"] = nil,}
    BongosProfiles.MazzleUI["BActionSets.bags"] = {["vis"] = nil, ["space"] = 2, ["scale"] = 0.9800000190734863}
    BongosProfiles.MazzleUI["BActionSets.menu"] = {["vis"] = nil, ["scale"] = 0.9800000190734863}

    --self:Print("Loading new Bongos profile.")
    --MazzleUI:Execute("/bob reset")
    BProfile.Load("MazzleUI", true)
    self:Print("Assigning key bindings and placing spells in bar.")
    if (not dontPlaceSpells) then
        Mazzifier:ClearActions()
        Mazzifier:ClosedListReset()
    end
    local theBinding, theButton, theStart 
    for i=1, numBars, 1 do
        theStart = getglobal("BActionBar"..i):GetStart()
        for j=1, thisBar[i].numButtons, 1 do
            for k=1, thisBar[i].pages, 1 do
                --theKey = thisBar[i].contents[j].binding
                if (k == 1) then
                    theKey = thisBar[i].contents.page_1[j].binding
                    theButton = getglobal("BActionButton"..(theStart + j - 1))
                    if (theButton) then
            		    theBinding = 'CLICK ' .. theButton:GetName() .. ':LeftButton'
                		while GetBindingKey(theBinding) do
                			SetBinding(GetBindingKey(theBinding), nil)
                		end
                		SaveBindings(GetCurrentBindingSet())
                		if (theKey) then
                			SetBindingClick(theKey, theButton:GetName(), 'LeftButton')
                			SaveBindings(GetCurrentBindingSet())
                	    end
                	end
                end
        	    if (not dontPlaceSpells) then
            	    --self:ActionLoad((theStart + j - 1), thisBar[i].contents[j].action)
            	    self:ActionLoad((theStart + ((k - 1) * thisBar[i].numButtons) + j - 1), thisBar[i].contents["page_"..k][j].action, thisBar[i].allowDuplicates)
            	end
            end
        end
    end
    
    self:Print("Positioning bars.")
    MazzleUI_BarConfig = {}
    local referencePoints = {Minimap=1, ChatFrame1=1, ChatFrame6=1, ChatFrame7=1, UIParent=1}
    local numLeft = #(thisBar) + 5
    local circularDependency = false
    while (numLeft > 0) do
        if (circularDependency) then
            self:Print("Error!!!  Circular dependency in layout!!!")
            return
        end
        circularDependency = true
        for barIndex, barInfo in pairs(thisBar) do
            if (referencePoints[barInfo.anchor.frame] and (not referencePoints[barInfo.name])) then
                MazzleUI:MoveAndUserPlace( barInfo.name, barInfo.anchor.frame, barInfo.anchor.point, barInfo.anchor.to, barInfo.anchor.x, barInfo.anchor.y)
                --self:Print("Saving position for ", barIndex, barInfo.name, barInfo.anchor.frame, barInfo.anchor.point, barInfo.anchor.to, barInfo.anchor.x, barInfo.anchor.y)
                --MazzleUI_BarConfig[barInfo.name] = {location = barInfo.anchor, post = function() BBar.SavePosition(getglobal(barInfo.name)); end,}
                BBar.SavePosition(getglobal(barInfo.name))
                referencePoints[barInfo.name] = 1
                circularDependency = false
                numLeft = numLeft -1
                if (Mazzifier.createDFMAdjustments) then
                    self:DFM_Set_Position("_Bongos", barInfo.name, barInfo.anchor.point, barInfo.anchor.frame, barInfo.anchor.to, barInfo.anchor.x, barInfo.anchor.y, nil, true)
                end
            end
        end
    end
    if (not dontPlaceSpells) then
        local cmFunc
        if (Mazzifier_ButtonInfo[layoutNum].cmFunc) then
            cmFunc = Mazzifier[Mazzifier_ButtonInfo[layoutNum].cmFunc]
        else cmFunc = Mazzifier.ContextMenu_Generic; end
        for aid, aactions in pairs(cmFunc()) do
    	    self:ActionLoad((88+aid), aactions)
        end
        Mazzifier:ClosedListReset()
    end
    if (BongosOptions) then BongosOptions:Hide(); end;
    MazzleUI_BarConfig = thisBar
    BActionSets_SetShowGrid(globalShowGrid)
	Bongos_SetStickyBars(false)
    BProfile.Delete("MazzleUI", true)

end

function Mazzifier:TranslateAnchor(anchorName)
    local refNum
    if (string.find(anchorName, "DAB_ActionBar_")) then
        refNum = string.gsub(anchorName, "DAB_ActionBar_", "")
        return ("BActionBar"..TranslationMap[tonumber(refNum)])
    elseif (string.find(anchorName, "DAB_ActionButton_")) then
        refNum = string.gsub(anchorName, "DAB_ActionButton_", "")
        return ("BActionBar"..TranslationMap.floaters[tonumber(refNum)])
    elseif (string.find(anchorName, "DAB_OtherBar_Form")) then
        return "BClassBar"
    elseif (string.find(anchorName, "DAB_OtherBar_Pet")) then
        return "BPetBar"
    else
        return anchorName
    end
end

function Mazzifier:ResetChanges()
    Exported_Layouts = {}
end

function Mazzifier:DFM_Set_Position(DFM_Category, frameName, point, anchorFrame, anchorPoint, x, y, lock, dontUse)
    if (DFM_INITIALIZED and DFM_INDEX and MazzleUI:GetValue("DFM_Settings."..DFM_INDEX.."."..DFM_Category.."."..frameName)) then
        MazzleUI:SetValue("DFM_Settings."..DFM_INDEX.."."..DFM_Category.."."..frameName, {["Location"] = { ["to"] = anchorPoint, ["x"] = x, ["y"] = y, ["lock"] = lock, ["frame"] = anchorFrame, ["point"] = point, ["use"] = (not dontUse), }, ["name"] = frameName, })    
    end
end

function Mazzifier:UpdateChanges()
    self:Print("Updating layout ", lastLayoutNum, lastLayoutAspect)

    local newLayoutName, setupFuncName = Mazzifier:GetLayoutName(lastLayoutNum, lastLayoutAspect)
    Exported_Layouts[newLayoutName] = Mazzifier_Bongo_Layouts[newLayoutName]
    
    local adjustedPosition
    for i=1, 16, 1 do
        self:Print("Checking bar ", i, " for adjustments")
        adjustedPosition = DFM_Settings.MazzleUI["_Bongos"]["BActionBar"..i].Location
        if (adjustedPosition and adjustedPosition.use) then
            self:Print("...Saving.")
            Exported_Layouts[newLayoutName][i].anchor.point = adjustedPosition.point
            Exported_Layouts[newLayoutName][i].anchor.frame = adjustedPosition.frame
            Exported_Layouts[newLayoutName][i].anchor.to = adjustedPosition.to
            Exported_Layouts[newLayoutName][i].anchor.x = adjustedPosition.x
            Exported_Layouts[newLayoutName][i].anchor.y = adjustedPosition.y
        end
    end
    adjustedPosition = DFM_Settings.MazzleUI["_Bongos"]["BPetBar"].Location
    self:Print("Checking pet bar for adjustments")
    if (adjustedPosition and adjustedPosition.use) then
            self:Print("...Saving.")
        Exported_Layouts[newLayoutName].petbar.anchor.point = adjustedPosition.point
        Exported_Layouts[newLayoutName].petbar.anchor.frame = adjustedPosition.frame
        Exported_Layouts[newLayoutName].petbar.anchor.to = adjustedPosition.to
        Exported_Layouts[newLayoutName].petbar.anchor.x = adjustedPosition.x
        Exported_Layouts[newLayoutName].petbar.anchor.y = adjustedPosition.y
    end
    self:Print("Checking class bar for adjustments")
    adjustedPosition = DFM_Settings.MazzleUI["_Bongos"]["BClassBar"].Location
    if (adjustedPosition and adjustedPosition.use) then
            self:Print("...Saving.")
        Exported_Layouts[newLayoutName].classbar.anchor.point = adjustedPosition.point
        Exported_Layouts[newLayoutName].classbar.anchor.frame = adjustedPosition.frame
        Exported_Layouts[newLayoutName].classbar.anchor.to = adjustedPosition.to
        Exported_Layouts[newLayoutName].classbar.anchor.x = adjustedPosition.x
        Exported_Layouts[newLayoutName].classbar.anchor.y = adjustedPosition.y
    end
end

function Mazzifier:ResetDFM()
		DFM_Settings.MazzleUI["_Bongos"] = {
			["BPetBar"] = {
				["name"] = "BPetBar",
			},
			["BActionBar1"] = {
				["name"] = "BActionBar1",
			},
			["BActionBar2"] = {
				["name"] = "BActionBar2",
			},
			["BActionBar3"] = {
				["name"] = "BActionBar3",
			},
			["BActionBar4"] = {
				["name"] = "BActionBar4",
			},
			["BActionBar5"] = {
				["name"] = "BActionBar5",
			},
			["BActionBar6"] = {
				["name"] = "BActionBar6",
			},
			["BActionBar7"] = {
				["name"] = "BActionBar7",
			},
			["BActionBar8"] = {
				["name"] = "BActionBar8",
			},
			["BActionBar9"] = {
				["name"] = "BActionBar9",
			},
			["BActionBar10"] = {
				["name"] = "BActionBar10",
			},
			["BActionBar11"] = {
				["name"] = "BActionBar11",
			},
			["BActionBar12"] = {
				["name"] = "BActionBar12",
			},
			["BActionBar13"] = {
				["name"] = "BActionBar13",
			},
			["BActionBar14"] = {
				["name"] = "BActionBar14",
			},
			["BActionBar15"] = {
				["name"] = "BActionBar15",
			},
			["BActionBar16"] = {
				["name"] = "BActionBar16",
			},
			["BClassBar"] = {
				["name"] = "BClassBar",
			},
		}
end


function Mazzifier:CheckAll()
    for layoutNum, layoutInfo in pairs(Mazzifier_ButtonInfo) do
        local aspectRatio = Mazzifier:GetEffectiveLayoutAspect(layoutNum, 3)
        local newLayoutName, setupFuncName = Mazzifier:GetLayoutName(layoutNum, aspectRatio)
        Mazzifier:CheckLayout(newLayoutName)
        local aspectRatio = Mazzifier:GetEffectiveLayoutAspect(layoutNum, 2)
        local newLayoutName, setupFuncName = Mazzifier:GetLayoutName(layoutNum, aspectRatio)
        Mazzifier:CheckLayout(newLayoutName)
        local aspectRatio = Mazzifier:GetEffectiveLayoutAspect(layoutNum, 1)
        local newLayoutName, setupFuncName = Mazzifier:GetLayoutName(layoutNum, aspectRatio)
        Mazzifier:CheckLayout(newLayoutName)
    end
end

function Mazzifier:CheckLayout(newLayoutName)
    MazzleUI:Print("Checking ", newLayoutName)
    local numBars = #(Mazzifier_Bongo_Layouts[newLayoutName])
    local maxButtons = 0
    for i=1, numBars, 1 do
        if (Mazzifier_Bongo_Layouts[newLayoutName][i].numButtons > maxButtons) then
            maxButtons = Mazzifier_Bongo_Layouts[newLayoutName][i].numButtons
        end
    end
    MaxAdd(numBars, (maxButtons-1))
end

function Mazzifier:CollapseVirtualBars()
    Exported_Layouts = {}
    local numBars, lastRealBar, lastPage, barMappings
    local untranslated = {}
    for layoutName, layoutInfo in pairs(Mazzifier_Bongo_Layouts) do
        Exported_Layouts[layoutName] = {}
        barMappings = {}
        Exported_Layouts[layoutName].bagbar = layoutInfo.bagbar
        Exported_Layouts[layoutName].keybar = layoutInfo.keybar
        Exported_Layouts[layoutName].menubar = layoutInfo.menubar
        Exported_Layouts[layoutName].classbar = layoutInfo.classbar
        Exported_Layouts[layoutName].petbar = layoutInfo.petbar
        numBars = #layoutInfo
        self:Print("Translating ", layoutName, "(", numBars, " bars)")
        lastRealBar = 0
        for i=1, numBars, 1 do
            if (not layoutInfo[i].virtual) then
                self:Print("Creating real bar", i)
                lastRealBar = lastRealBar + 1
                lastPage = 1
                Exported_Layouts[layoutName][lastRealBar] = {}
                for fieldName, fieldInfo in pairs(layoutInfo[i]) do
                    if (fieldName ~= "virtual") then
                        Exported_Layouts[layoutName][lastRealBar][fieldName] = fieldInfo
                    end
                end
                Exported_Layouts[layoutName][lastRealBar].name = "BActionBar"..lastRealBar
                Exported_Layouts[layoutName][lastRealBar].contents = {}
                Exported_Layouts[layoutName][lastRealBar].contents.page_1 = layoutInfo[i].contents
                barMappings[layoutInfo[i].name] = "BActionBar"..lastRealBar
            else
                self:Print("Processing virtual bar", i)
                lastPage = lastPage + 1
                Exported_Layouts[layoutName][lastRealBar].contents["page_"..lastPage] = layoutInfo[i].contents
            end
        end
        numBars = #(Exported_Layouts[layoutName])
        self:Print("-->", numBars, " bars")
        for i=1, numBars, 1 do
            self:Print("Checking frame name tranlation for ", i)
            if (barMappings[Exported_Layouts[layoutName][i].anchor.frame]) then
                Exported_Layouts[layoutName][i].anchor.frame = barMappings[Exported_Layouts[layoutName][i].anchor.frame]
            else
                untranslated[Exported_Layouts[layoutName][i].anchor.frame] = true
            end
        end
    end
    self:PrintLiteral("Untranslated anchors: ", untranslated)
end

function Mazzifier:ClearActions()
	ClearCursor();
	for i = 0, 9 do
		for j = 1, 12 do
    		local id = j + i*12;
			MazzleUI:ClearSlot(id);
        end
    end
end

function Mazzifier:ClosedListReset()
    closedList = {}
end

function Mazzifier:ActionExists(theActions, ignoreClosedList)
    return self:ActionLoad(nil, theActions, ignoreClosedList, true);
end

-- The following function and a few support functions was based on code in SimpleActionSets, so some credit must
-- go to original author.  It's been completely rewritten though: (not because of shortcomings, just a different context)
    -- Removed most generalizations, including dealing with hypothetical items that the user may not have
    -- Removed anything dealing with macros and textures
    -- Removed checking of current button information to avoid action placement
    -- The main algorithm placement algorithm completely rewritten
    -- Uses a much simpler action specification data structure.
    -- Handles max level explicitly
    -- Uses a closed list to avoid duplicate action placement for bars that require it
    -- Added support for non-destructive placement (just to see what it would do given a character's currently items and spellbook)
    -- Uses BabbleLib for spell translations

function Mazzifier:ActionLoad(actionID, theActions, ignoreClosedList, doNotPlace)
	ClearCursor();
	local a, actionList = {}, {}
	local actionPlaced, spellID, theAction
	if (theActions) then
        if (type(theActions) == "table") then actionList = theActions; else actionList = {[1] = theActions}; end
        actionPlaced = false
        for i=1, #actionList, 1 do
            theAction = actionList[i]
            if (not actionPlaced) then
        		spellID = 0
                if (not string.find(theAction, "�")) then
                    if (BS:HasTranslation(theAction)) then
                        spellID = MazzleUI:GetMaxRank(BS[theAction]);
                    else
                        spellID = MazzleUI:GetMaxRank(theAction);
                    end
                else
                    a = {}
                	for v in string.gmatch( theAction, "(.-)�" ) do if (v == "") then tinsert(a, nil); else tinsert(a, v); end; end;
                    if (a[1] == "item") then
        				if (MazzleUI:PlaceItem(actionID, a[2], tonumber(a[3]), doNotPlace)) then actionPlaced = true; end
                    else
                        if (BS:HasTranslation(a[1])) then
                            spellID = MazzleUI:GetMaxRank(BS[a[1]], tonumber(a[2]));
                        else
                            spellID = MazzleUI:GetMaxRank(a[1], tonumber(a[2]));
                        end
                    end
                end
				if ( (spellID>0) and (ignoreClosedList or (not closedList[spellID]))) then
				    if (not doNotPlace) then
    					PickupSpell( spellID, BOOKTYPE_SPELL );
    					PlaceAction(actionID);
    					closedList[spellID] = true;
        			end
    			    actionPlaced = true
    			end
        		ClearCursor();
            end
        end
	end
	ClearCursor();
	return actionPlaced;
end

function Mazzifier:ContextMenu_AddUniversals(theSASArray, hearthIndex, tradeStart, skillStart)
    theSASArray[hearthIndex] = "item�Hearthstone�6948�"
    theSASArray[tradeStart] = {"Engineering", "Blacksmithing", "Enchanting", "Tailoring", "Alchemy", "Leatherworking","Smelting", "Jewelcrafting"}
    theSASArray[tradeStart+1] = {"Smelting", "Leatherworking", "Alchemy", "Tailoring", "Enchanting", "Blacksmithing","Engineering", "Jewelcrafting", "Disenchant", "Prospecting"}
    theSASArray[tradeStart+2] = {"Disenchant", "Prospecting"}
    theSASArray[skillStart] = "First Aid"
    theSASArray[skillStart+1] = "Cooking"    
    theSASArray[skillStart+2] = "Basic Campfire"
    theSASArray[skillStart+3] = "Fishing"
    return theSASArray;
end

function Mazzifier:ContextMenu_MageMazzle()
    local testSASInfo = {
        [1] = "Teleport: Ironforge",
        [2] = "Teleport: Stormwind",
        [3] = "Teleport: Darnassus",
        [4] = {"Teleport: Exodar", "Teleport: Silvermoon",},
        [5] = "Portal: Ironforge",
        [6] = "Portal: Stormwind",
        [7] = "Portal: Darnassus",
        [8] = {"Portal: Exodar", "Portal: Silvermoon",},
        [9] = {"Conjure Mana Ruby", "Conjure Mana Citrine", "Conjure Mana Jade", "Conjure Mana Agate",},
        [10] = "Teleport: Shattrath",
        [11] = "Portal: Shattrath",
        [12] = {"Molten Armor", "item�Hearthstone�6948�"},
        [13] = "Conjure Water",
        [14] = "Conjure Food",
        [15] = "Ice Armor",
        [16] = "Mage Armor",
        [17] = "Conjure Mana Citrine",
        [18] = "Conjure Mana Jade",
        [19] = "Conjure Mana Agate",
    }
    return Mazzifier:ContextMenu_AddUniversals(testSASInfo, 20, 25, 29)
end

function Mazzifier:ContextMenu_Generic()
    return Mazzifier:ContextMenu_AddUniversals({}, 4, 9, 13)
end

function Mazzifier:ContextMenu_HunterMazzle()
    return Mazzifier:ContextMenu_AddUniversals({[1] = "Beast Lore", [2] = "Beast Training",}, 4, 9, 13)
end

function Mazzifier:ContextMenu_WarlockMazzle()
    local testSASInfo = {
					[1] = "Create Healthstone (Major)",
					[2] = "Create Firestone (Major)",
					[3] = "Create Soulstone (Major)",
					[4] = "Create Spellstone (Major)",
					[9] = "Fel Domination",
					[12] = "Eye of Kilrogg",
					[13] = "Summon Imp",
					[14] = "Summon Voidwalker",
					[15] = "Summon Succubus",
					[16] = "Summon Felhunter",
			}
    return Mazzifier:ContextMenu_AddUniversals(testSASInfo, 8, 24, 28)
end

function Mazzifier:ContextMenu_DruidMazzle()
    return Mazzifier:ContextMenu_AddUniversals({[3] = "Teleport: Moonglade",}, 4, 9, 13)
end

function Mazzifier:ContextMenu_Shaman()
    return Mazzifier:ContextMenu_AddUniversals({[1] = "Far Sight", [3] = "Astral Recall",}, 4, 9, 13)
end

function Mazzifier:GetDruidShapeshiftForms()
    local it, cn, bn, stancesA
    for i=1, 6, 1 do
        it = GetShapeshiftFormInfo(i)
        if (it == "Interface\\Icons\\Ability_Racial_BearForm") then bn = i; end
        if (it == "Interface\\Icons\\Ability_Druid_CatForm") then cn = i; end
    end
    stancesA = {[7] = 1,}
    if (cn) then stancesA[cn] = 1; end
    if (bn) then stancesA[bn] = 2; end
    return stancesA;
end
