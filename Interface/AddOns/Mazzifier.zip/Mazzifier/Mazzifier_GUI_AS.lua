-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

local Mazzifier_WidgetPool = {}
Mazzifier_WidgetPool.YesNoPool = {}
Mazzifier_WidgetPool.CheckButtonPool = {}
Mazzifier_WidgetPool.MenuPool = {}
Mazzifier_WidgetPool.SliderPool = {}
Mazzifier_WidgetPool.ButtonPool = {}
Mazzifier_WidgetPool.TextboxPool = {}
Mazzifier_WidgetPool.PerformancePool = {}
local Mazzifier_PoolList = {"YesNoPool", "CheckButtonPool", "SliderPool", "MenuPool", "PerformancePool", "ButtonPool", "TextboxPool"}
local Mazzifier_ScrollPosition = {0, 0, 0, 0, 0, 0, 0, 0}
local Mazzifier_ASInfoAll, Mazzifier_ASInfo = {}, {}
local BClass = AceLibrary("Babble-Class-2.2")

function Mazzifier:GUI_SaveScrollPosition()
    Mazzifier_ScrollPosition[PanelTemplates_GetSelectedTab(Mazzifier_Frame)] = Mazzifier_Contents_ScrollFrame:GetVerticalScroll()
end

function Mazzifier:GUI_RestoreScrollPosition()
    if  (Mazzifier_ScrollPosition[PanelTemplates_GetSelectedTab(Mazzifier_Frame)]) then
        -- for some reason, scroll bar does not move though contents do.  Setting it on a timer as a quick workaround
        self:ScheduleEvent(function() Mazzifier_Contents_ScrollFrame:SetVerticalScroll(Mazzifier_ScrollPosition[PanelTemplates_GetSelectedTab(Mazzifier_Frame)]) end, 0.05)
    else
        Mazzifier_Contents_ScrollFrame:SetVerticalScroll(0)
    end
end

function Mazzifier:GUI_CreateWidget(requestedType, requestedAnchor, requestedParent, anchorType, xadjust, yadjust, widgetID)
    if (not xadjust) then
        xadjust = 0
    end
    if (not yadjust) then
        yadjust = 0
    end

    local newWidgetName

    local newWidgetType, newWidgetName, newWidgetTemplate, newWidgetList, newWidget
    if (requestedType == "YesNo") then
         newWidgetType = "Frame"
         newWidgetTemplate = "MazzifierAS_YesNoTemplate"
         newWidgetList = "YesNoPool"
    elseif (requestedType == "CheckButton") then
         newWidgetType = "CheckButton"
         newWidgetTemplate = "MazzifierAS_CheckButtonTemplate"
         newWidgetList = "CheckButtonPool"
         yadjust = yadjust + 12
    elseif (requestedType == "Slider") then
         newWidgetType = "Slider"
         newWidgetTemplate = "MazzifierAS_SliderTemplate"
         newWidgetList = "SliderPool"
    elseif (requestedType == "Menu") then
         newWidgetType = "Frame"
         newWidgetTemplate = "MazzifierAS_ButtonDropDownTemplate"
         newWidgetList = "MenuPool"
    elseif (requestedType == "Textbox") then
         newWidgetType = "Frame"
         newWidgetTemplate = "MazzifierAS_TextBoxTemplate"
         newWidgetList = "TextboxPool"
    elseif (requestedType == "Button") then
         newWidgetType = "Button"
         newWidgetTemplate = "MazzifierAS_ButtonTemplate"
         newWidgetList = "ButtonPool"
    end

    for i=1, table.getn(Mazzifier_WidgetPool[newWidgetList]), 1 do
        if (Mazzifier_WidgetPool[newWidgetList][i].isFree) then
            --self:Print ("--> Found an existing widget to reuse.")
            newWidget = Mazzifier_WidgetPool[newWidgetList][i]
            newWidgetName = Mazzifier_WidgetPool[newWidgetList][i].widgetName
        end
    end
    if (not newWidget) then
        newWidget = {}
        newWidget.widgetName = "Mazzifier_"..requestedType..(table.getn(Mazzifier_WidgetPool[newWidgetList])+1)
        newWidget.frame = CreateFrame(newWidgetType, newWidget.widgetName, requestedParent, newWidgetTemplate);
        table.insert(Mazzifier_WidgetPool[newWidgetList], newWidget)
    end
    newWidget.isFree = false
    newWidget.frame:SetParent(requestedParent)
	newWidget.frame:ClearAllPoints()
	if (anchorType == "top") then
        newWidget.frame:SetPoint("TOPLEFT", requestedAnchor, "TOPLEFT", (5 + xadjust), (-10 + yadjust));
	elseif (anchorType == "topright") then
        newWidget.frame:SetPoint("TOPRIGHT", requestedAnchor, "TOPRIGHT", (-30 + xadjust), (-20 + yadjust));
	elseif (anchorType == "middle") then
        newWidget.frame:SetPoint("TOPLEFT", requestedAnchor, "BOTTOMLEFT", xadjust, (-10 + yadjust));
	elseif (anchorType == "right") then
        newWidget.frame:SetPoint("TOPRIGHT", requestedAnchor, "BOTTOMRIGHT", xadjust, (0 + yadjust));
	elseif (anchorType == "aboveright") then
        newWidget.frame:SetPoint("BOTTOMRIGHT", requestedAnchor, "TOPRIGHT", xadjust, (0 + yadjust));
	elseif (anchorType == "center") then
        newWidget.frame:SetPoint("TOP", requestedAnchor, "BOTTOM", xadjust, (-20 + yadjust));
    end
    if (requestedType == "YesNo") then
        newWidget.labelName = newWidget.widgetName.."Title"
        newWidget.checkButtonYes = newWidget.widgetName.."_CheckButtonYes"
        newWidget.checkButtonNo = newWidget.widgetName.."_CheckButtonNo"
    elseif (requestedType == "CheckButton") then
        newWidget.labelName = newWidget.widgetName.."Text"
    elseif (requestedType == "Textbox") then
        newWidget.labelName = newWidget.widgetName.."_Text"
    elseif (requestedType == "Slider") then
        newWidget.labelName = newWidget.widgetName.."Text"
        newWidget.lowName = newWidget.widgetName.."Low"
        newWidget.highName = newWidget.widgetName.."High"
    elseif (requestedType == "Menu") then
        newWidget.labelName = newWidget.widgetName.."Label"
    elseif (requestedType == "Button") then
        newWidget.labelName = newWidget.widgetName.."Label"
    end
    newWidget.frame:Show()
    newWidget.frame:SetID(widgetID)
    return newWidget
end

function Mazzifier:GUI_ClearWidgets()
    local currentWidget
    -- Loop through different widget lists and put them as unused
    for _,poolList in pairs(Mazzifier_PoolList) do
        for i=1, table.getn(Mazzifier_WidgetPool[poolList]), 1 do
            currentWidget = Mazzifier_WidgetPool[poolList][i]
            currentWidget.isFree = true
            currentWidget.frame:SetParent(UIParent)
            currentWidget.frame:ClearAllPoints()
            currentWidget.frame:SetPoint("CENTER", UIParent)
            currentWidget.frame:SetID(0)
            currentWidget.frame:Hide()
        end
    end
end

function Mazzifier:GUI_CountWidgets()
    for _,poolList in pairs(Mazzifier_PoolList) do
        self:Print("Number of ", poolList, " widgets: ", table.getn(Mazzifier_WidgetPool[poolList]))
    end
end

	
function Mazzifier:GUI_YesNo_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:GUI_CreateWidget("YesNo", lastFrame, Mazzifier_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)
    getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.question))
    if ((currentWidgetInfo.parameter and MazzleUI:GetValue(currentWidgetInfo.parameter)) or
        (currentWidgetInfo.readOnlyParameter and MazzleUI:GetValue(currentWidgetInfo.readOnlyParameter)) or
        (currentWidgetInfo.readProc and currentWidgetInfo.readProc())) then
        getglobal(lastWidget.widgetName.."_CheckButtonYes"):SetChecked(1)
        getglobal(lastWidget.widgetName.."_CheckButtonNo"):SetChecked(nil)
    else
        getglobal(lastWidget.widgetName.."_CheckButtonYes"):SetChecked(nil)
        getglobal(lastWidget.widgetName.."_CheckButtonNo"):SetChecked(1)
    end
    if (currentWidgetInfo.yesText) then
        getglobal(lastWidget.widgetName.."_CheckButtonYesText"):SetText(TEXT(currentWidgetInfo.yesText))
    end
    if (currentWidgetInfo.noText) then
        getglobal(lastWidget.widgetName.."_CheckButtonNoText"):SetText(TEXT(currentWidgetInfo.noText))
    end
    return lastWidget
end

function Mazzifier:GUI_Menu_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:GUI_CreateWidget("Menu", lastFrame, Mazzifier_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)
    getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.name))
    if (currentWidgetInfo.menuItemsReadProc) then
        self:GUI_Menu_Initialize(lastWidget.frame, currentWidgetInfo.menuItemsReadProc())
    else
        self:GUI_Menu_Initialize(lastWidget.frame, currentWidgetInfo.menuItems)
    end
    if (currentWidgetInfo.width) then
        UIDropDownMenu_SetWidth( currentWidgetInfo.width, lastWidget.frame)
    end
    if (Mazzifier_EnabledStatus) then
        UIDropDownMenu_EnableDropDown(lastWidget.frame)
        local menuValue = nil
        if (currentWidgetInfo.parameter) then
            menuValue = MazzleUI:GetValue(currentWidgetInfo.parameter)
        elseif (currentWidgetInfo.readOnlyParameter) then
            menuValue = MazzleUI:GetValue(currentWidgetInfo.readOnlyParameter)
        end    
        if (currentWidgetInfo.readProc) then
             menuValue = currentWidgetInfo.readProc(menuValue)
        end
        UIDropDownMenu_SetSelectedValue(lastWidget.frame, menuValue)
    else
        OptionsFrame_DisableDropDown(lastWidget.frame)
    end
    return lastWidget
end

function Mazzifier:GUI_Menu_Initialize(theMenu, itemList)
	UIDropDownMenu_Initialize(theMenu, function() self:GUI_Menu_MakeButtons(theMenu, itemList) end);
	theMenu.tooltip = "";
	UIDropDownMenu_SetWidth(323, theMenu);
	UIDropDownMenu_JustifyText("CENTER", theMenu)
end

function Mazzifier:GUI_Menu_MakeButtons(theMenu, itemList)
	local selectedValue = UIDropDownMenu_GetSelectedValue(theMenu);
	local info;
    local valcnt = 0
    for index,value in pairs(itemList) do
        valcnt = valcnt + 1
    	info = {};
    	info.text = itemList[index];
    	info.func = function() self:GUI_Menu_SetValue(theMenu) end;
    	info.value = valcnt
    	if ( info.value == selectedValue ) then
    		info.checked = 1;
    	end
    	UIDropDownMenu_AddButton(info);
    end
end

function Mazzifier:GUI_Menu_SetValue(theMenu)
	UIDropDownMenu_SetSelectedValue(theMenu, this.value);
    if (Mazzifier_CurrentOptions[theMenu:GetID()].info.parameter) then
        MazzleUI:CreateSet( Mazzifier_CurrentOptions[theMenu:GetID()].info.parameter, this.value)
    end
    self:GUI_SetProc(theMenu:GetID(), this.value)
end

function Mazzifier:GUI_Button_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:GUI_CreateWidget("Button", lastFrame, Mazzifier_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)
    if (currentWidgetInfo.name) then
        lastWidget.frame:SetText(TEXT(currentWidgetInfo.name))
    end
    if (currentWidgetInfo.label) then
        getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.label))
    end
    if (Mazzifier_EnabledStatus) then
        lastWidget.frame:Enable()
    else
        lastWidget.frame:Disable()
    end
    return lastWidget
end

function Mazzifier:GUI_Button_SetValue(widgetID)
    self:GUI_SetProc(widgetID)
end

function Mazzifier:GUI_CheckButton_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:GUI_CreateWidget("CheckButton", lastFrame, Mazzifier_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)
    getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.name))
    if (Mazzifier_EnabledStatus) then
        OptionsFrame_EnableCheckBox(lastWidget.frame)
        local checkValue = nil
        if (currentWidgetInfo.parameter) then
            checkValue = MazzleUI:GetValue(currentWidgetInfo.parameter)
        elseif (currentWidgetInfo.readOnlyParameter) then
            checkValue = MazzleUI:GetValue(currentWidgetInfo.readOnlyParameter)
        end    
        if (currentWidgetInfo.readProc) then
             checkValue = currentWidgetInfo.readProc(checkValue)
        end
        lastWidget.frame:SetChecked(checkValue)
    else
        OptionsFrame_DisableCheckBox(lastWidget.frame)
    end
    return lastWidget
end

function Mazzifier:GUI_CheckButton_SetValue(widgetID, widgetValue)
    if (Mazzifier_CurrentOptions[widgetID].info.parameter) then
        MazzleUI:CreateSet( Mazzifier_CurrentOptions[widgetID].info.parameter, widgetValue)
    end
    self:GUI_SetProc(widgetID, widgetValue)
    if (Mazzifier_CurrentOptions[widgetID].widget.frame:GetObjectType() == "CheckButton") then
        Mazzifier_CurrentOptions[widgetID].widget.frame:SetChecked(widgetValue)
    end
end

function Mazzifier:GUI_Slider_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:GUI_CreateWidget("Slider", lastFrame, Mazzifier_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)

	getglobal(lastWidget.lowName):SetText(TEXT(self:GUI_Slider_Round(currentWidgetInfo.stepValue,currentWidgetInfo.minValue)))
	getglobal(lastWidget.highName):SetText(TEXT(self:GUI_Slider_Round(currentWidgetInfo.stepValue,currentWidgetInfo.maxValue)))
	lastWidget.frame:SetMinMaxValues(currentWidgetInfo.minValue, currentWidgetInfo.maxValue);
	lastWidget.frame:SetValueStep(currentWidgetInfo.stepValue);

    if (Mazzifier_EnabledStatus) then
        local paramValue
    	if (currentWidgetInfo.readOnlyParameter) then
            paramValue = MazzleUI:GetValue(currentWidgetInfo.readOnlyParameter) or 0;
        elseif (currentWidgetInfo.readFunc) then
            paramValue = currentWidgetInfo.readFunc();
        elseif (currentWidgetInfo.parameter) then
            paramValue = MazzleUI:GetValue(currentWidgetInfo.parameter) or 0
        end
        getglobal(lastWidget.labelName):SetText(
            currentWidgetInfo.name.." "..self:GUI_Slider_Round(currentWidgetInfo.stepValue,paramValue)..currentWidgetInfo.units)
        lastWidget.frame:SetValue(paramValue);
        OptionsFrame_EnableSlider(lastWidget.frame);
    else
        getglobal(lastWidget.labelName):SetText(currentWidgetInfo.name)
        OptionsFrame_DisableSlider(lastWidget.frame);
    end
	lastWidget.frame.tooltipText = currentWidgetInfo.tooltip or "";
    return lastWidget
end

function Mazzifier:GUI_Slider_Set(widgetID, widgetValue)
    widgetValue = self:GUI_Slider_Format(widgetID, widgetValue)
    MazzleUI:CreateSet( Mazzifier_CurrentOptions[widgetID].info.parameter, tonumber(widgetValue))
    getglobal(Mazzifier_CurrentOptions[widgetID].widget.labelName):SetText(
        Mazzifier_CurrentOptions[widgetID].info.name.." "..widgetValue..Mazzifier_CurrentOptions[widgetID].info.units)
    self:GUI_SetProc(widgetID, tonumber(widgetValue))
end

function Mazzifier:GUI_Slider_Format(widgetID, sliderValue)
    return self:GUI_Slider_Round(Mazzifier_CurrentOptions[widgetID].info.stepValue, sliderValue)
end

function Mazzifier:GUI_Slider_Round(stepValue, sliderValue)
    local formatString = "%i"
    if (stepValue < 1) then
        formatString = "%.2f"
    end
    if (sliderValue == nil) then return 0 else return string.format(formatString, sliderValue) end
end

function Mazzifier:GUI_Textbox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID, textOverride)
    local lastWidget = self:GUI_CreateWidget("Textbox", lastFrame, Mazzifier_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID, textOverride)
    
    local theTextString = currentWidgetInfo.text
    if (textOverride) then theTextString = textOverride; end
    
    local textWidget = getglobal(lastWidget.labelName)
    if (Mazzifier_EnabledStatus) then
        textWidget:SetTextColor(0, 1, 0);
        textWidget:SetText(TEXT(theTextString))
    else
        textWidget:SetText(TEXT(theTextString))
        textWidget:SetTextColor(0.5, 0.5, 0.5);
    end
    
    if (currentWidgetInfo.width == "full") then currentWidgetInfo.width = 500
    else currentWidgetInfo.width = currentWidgetInfo.width or (textWidget:GetStringWidth() + 32); end
    
    textWidget:ClearAllPoints()
    textWidget:SetPoint("TOPLEFT", lastWidget.frame, "TOPLEFT" , 0, 0);
    textWidget:SetWidth(currentWidgetInfo.width-20)
    lastWidget.frame:SetWidth(currentWidgetInfo.width)
    lastWidget.frame:SetHeight(textWidget:GetHeight()+20)
    textWidget:ClearAllPoints()
    textWidget:SetPoint("TOPLEFT", lastWidget.frame, "TOPLEFT" , 10, -10);
    textWidget:SetPoint("BOTTOMRIGHT", lastWidget.frame, "BOTTOMRIGHT" , -10, 10);
    
    if (not Mazzifier_TextboxBackdrop) then
        Mazzifier_TextboxBackdrop = lastWidget.frame:GetBackdrop()
    else
        lastWidget.frame:SetBackdrop(Mazzifier_TextboxBackdrop) 
        lastWidget.frame:SetBackdropBorderColor(0.4, 0.4, 0.4);
        lastWidget.frame:SetBackdropColor(0.05, 0.05, 0.05);
    end
    return lastWidget
end

    
function Mazzifier:GUI_Infobox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:GUI_Textbox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, (yadjust+16), widgetID)

    if (Mazzifier_EnabledStatus) then
		getglobal(lastWidget.labelName):SetTextColor(1, 1, 1);
        getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.text))
    else
        getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.text))
		getglobal(lastWidget.labelName):SetTextColor(0.5, 0.5, 0.5);
    end
    --lastWidget.frame:SetWidth(currentWidgetInfo.width or 500)
    return lastWidget
end

function Mazzifier:GUI_Notebox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)

    local noteText
    if (currentWidgetInfo.notetype  == "warning") then
        noteText = "|CFFFF0000Warning: |r"..currentWidgetInfo.text
    elseif (currentWidgetInfo.notetype  == "example") then
        noteText = "|CFFFF8000Example: |r"..currentWidgetInfo.text
    elseif (currentWidgetInfo.notetype  == "none") then
        noteText = currentWidgetInfo.text
    else
        noteText = "|CFFFF8000Note:  |r"..currentWidgetInfo.text
    end
    currentWidgetInfo.width = "full"
    
    local lastWidget = self:GUI_Textbox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust , widgetID, noteText)
    if (Mazzifier_EnabledStatus) then
		getglobal(lastWidget.labelName):SetTextColor(1, 1, 1);
        getglobal(lastWidget.labelName):SetText(TEXT(noteText))
    else
        getglobal(lastWidget.labelName):SetText(TEXT(noteText))
		getglobal(lastWidget.labelName):SetTextColor(0.5, 0.5, 0.5);
    end

    --lastWidget.frame:SetWidth(currentWidgetInfo.width or 500)
    lastWidget.frame:SetBackdrop(nil)
    return lastWidget
end

function Mazzifier:GUI_SetScrollingText(frameName, newText)
    getglobal(frameName.."_ScrollFrame__ScrollChildFrame_Text"):SetText(newText)
    getglobal(frameName.."_ScrollFrame__ScrollChildFrame_Text"):SetHeight(getglobal(frameName.."_ScrollFrame__ScrollChildFrame_Text"):GetHeight())
end

function Mazzifier:GUI_SetText(frameName, newText, newTextHeight, newTextWidth)
    getglobal(frameName.."_Text"):SetText(newText)
    getglobal(frameName.."_Text"):SetNonSpaceWrap(true)
    getglobal(frameName):SetHeight(newTextHeight)
    getglobal(frameName):SetWidth(newTextWidth)
    
end

function Mazzifier:GUI_SetProc(widgetID, widgetValue)
    if (Mazzifier_CurrentOptions[widgetID].info.setProc) then
        Mazzifier_CurrentOptions[widgetID].info.setProc(widgetID, widgetValue)
    end
end

function Mazzifier:GUI_ASLayoutWidgets(pageNum)

    self:GUI_ClearWidgets()
    Mazzifier_CurrentOptions = {}
    Mazzifier_CurrentOptions.widgetLookup = {}
    Mazzifier_EnabledStatus = true
    local lastWidget, currentJustification, xadjust, yadjust
    local Mazzifier_ASInfo = Mazzifier_ASInfoAll[pageNum]

    for i=1, table.getn(Mazzifier_ASInfo), 1 do
        Mazzifier_CurrentOptions[i] = {}
        Mazzifier_CurrentOptions[i].info = Mazzifier_ASInfo[i]
        xadjust = Mazzifier_CurrentOptions[i].info.xadjust or 0
        yadjust = Mazzifier_CurrentOptions[i].info.yadjust or 0
        if (i == 1) then
            currentJustification = "top"
        else
            currentJustification = Mazzifier_CurrentOptions[i].info.justification or "middle"
        end
        if (lastWidget) then lastFrame = lastWidget.frame else lastFrame = "Mazzifier_Content_ScrollChildFrame" end
        if (Mazzifier_CurrentOptions[i].info.type == "YesNo") then
            lastWidget = self:GUI_YesNo_Create(Mazzifier_CurrentOptions[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (Mazzifier_CurrentOptions[i].info.type == "Menu") then
            lastWidget = self:GUI_Menu_Create(Mazzifier_CurrentOptions[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (Mazzifier_CurrentOptions[i].info.type == "Button") then
            lastWidget = self:GUI_Button_Create(Mazzifier_CurrentOptions[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (Mazzifier_CurrentOptions[i].info.type == "CheckButton") then
            lastWidget = self:GUI_CheckButton_Create(Mazzifier_CurrentOptions[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (Mazzifier_CurrentOptions[i].info.type == "Slider") then
            lastWidget = self:GUI_Slider_Create(Mazzifier_CurrentOptions[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (Mazzifier_CurrentOptions[i].info.type == "Textbox") then
            lastWidget = self:GUI_Textbox_Create(Mazzifier_CurrentOptions[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (Mazzifier_CurrentOptions[i].info.type == "Infobox") then
            lastWidget = self:GUI_Infobox_Create(Mazzifier_CurrentOptions[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (Mazzifier_CurrentOptions[i].info.type == "Notebox") then
            lastWidget = self:GUI_Notebox_Create(Mazzifier_CurrentOptions[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        end
        Mazzifier_CurrentOptions[i].widget = lastWidget
        if (Mazzifier_CurrentOptions[i].info.idName) then
            Mazzifier_CurrentOptions.widgetLookup[Mazzifier_CurrentOptions[i].info.idName] = i
        end
    end
    Mazzifier_Contents_ScrollFrame:UpdateScrollChildRect()
end

function Mazzifier:GUI_AbleParts(whichPart, a, b)
    if (Mazzifier_CurrentOptions and Mazzifier_CurrentOptions.widgetLookup["full"]) then
        for _,corePart in pairs({"full", "loading", "cpu", "minimum", "mule"}) do
            if (whichPart ~= corePart) then
                Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup[corePart]].widget.frame:SetChecked(nil)
            else
                Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup[corePart]].widget.frame:SetChecked(1)
            end
        end
        Mazzifier_CurrentInstallOptions.AddonExtras.corepackage = whichPart
    end
end

function Mazzifier:GUI_AbleDM(a, b)
    if (Mazzifier_CurrentOptions and Mazzifier_CurrentOptions.widgetLookup["dmRecap"]) then
        self:AbleCheckbox("dmRecap", b)
        self:AbleCheckbox("dmSWS", b)
        self:AbleCheckbox("dmRecount", b)
    end
end

function Mazzifier:GUI_AbleTM(a, b)
    if (Mazzifier_CurrentOptions and Mazzifier_CurrentOptions.widgetLookup["tmKLH"]) then
        self:AbleCheckbox("tmKLH", b)
        self:AbleCheckbox("tmOmen", b)
    end
end

function Mazzifier:GUI_AbleRaid(a, b)
    if (Mazzifier_CurrentOptions and Mazzifier_CurrentOptions.widgetLookup["raidXRS"]) then
        self:AbleCheckbox("raidBigWigs", b)
        self:AbleCheckbox("raidDBM", b)
        self:AbleCheckbox("raidXRS", b)
        self:AbleCheckbox("raidIncubator", b)
        self:AbleCheckbox("raidDecursive", b)
    end
end

function Mazzifier:GUI_ValidateRBWarningMods(b, isBW)
    if (Mazzifier_CurrentOptions and Mazzifier_CurrentOptions.widgetLookup["raidDBM"]) then
        if (isBW and b) then Mazzifier:GUI_CheckButton_SetValue(Mazzifier_CurrentOptions.widgetLookup["raidDBM"], false)
        elseif ((not isBW) and b) then Mazzifier:GUI_CheckButton_SetValue(Mazzifier_CurrentOptions.widgetLookup["raidBigWigs"], false); end
    end
end

function Mazzifier:GUI_AbleNames(whichName)
    if (Mazzifier_CurrentOptions and Mazzifier_CurrentOptions.widgetLookup["nameTagsNone"]) then
        if (whichName == 1) then
            Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup["nameTagsNone"]].widget.frame:SetChecked(true)
            Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup["nameTagsNormal"]].widget.frame:SetChecked(false)
            Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup["nameTagsPlates"]].widget.frame:SetChecked(false)
            Mazzifier_CurrentInstallOptions.AddonExtras.namenone = true
            Mazzifier_CurrentInstallOptions.AddonExtras.nametags = false
            Mazzifier_CurrentInstallOptions.AddonExtras.nameplates = false
        elseif (whichName == 2) then
            Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup["nameTagsNone"]].widget.frame:SetChecked(false)
            Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup["nameTagsNormal"]].widget.frame:SetChecked(true)
            Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup["nameTagsPlates"]].widget.frame:SetChecked(false)
            Mazzifier_CurrentInstallOptions.AddonExtras.namenone = false
            Mazzifier_CurrentInstallOptions.AddonExtras.nametags = true
            Mazzifier_CurrentInstallOptions.AddonExtras.nameplates = false
        else
            Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup["nameTagsNone"]].widget.frame:SetChecked(false)
            Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup["nameTagsNormal"]].widget.frame:SetChecked(false)
            Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup["nameTagsPlates"]].widget.frame:SetChecked(true)
            Mazzifier_CurrentInstallOptions.AddonExtras.namenone = false
            Mazzifier_CurrentInstallOptions.AddonExtras.nametags = false
            Mazzifier_CurrentInstallOptions.AddonExtras.nameplates = true
        end
    end
end

function Mazzifier:AbleCheckbox(labelName, isEnabled)
    if (isEnabled) then
        OptionsFrame_EnableCheckBox(Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup[labelName]].widget.frame)
    else
        OptionsFrame_DisableCheckBox(Mazzifier_CurrentOptions[Mazzifier_CurrentOptions.widgetLookup[labelName]].widget.frame)
    end
end

function Mazzifier:GUI_AbleMap(a, b)
    if (Mazzifier_CurrentOptions and Mazzifier_CurrentOptions.widgetLookup["mapnotes1"]) then
        self:AbleCheckbox("mapnotes1",b)
        self:AbleCheckbox("mapnotes2",b)
        self:AbleCheckbox("mapnotes3",b)
        self:AbleCheckbox("mapnotes4",b)
        self:AbleCheckbox("mapnotes5",b)
    end
end

function Mazzifier:GUI_AbleAddonLoaded()
    for _, aInfo in pairs(Mazzifier_ASInfoAll[6]) do
        if (aInfo.type == "CheckButton") then
            Mazzifier:AbleCheckbox(aInfo.idName, Mazzifier_AddOnInfo[aInfo.idName].loaded)
        end
    end
end

function Mazzifier:GUI_AbleAddonselection(isEnabled)
    if (isEnabled) then
        for _,theButton in pairs(Mazzifier_WidgetPool.CheckButtonPool) do
            OptionsFrame_EnableCheckBox(theButton.frame)
        end
        for _,theButton in pairs(Mazzifier_WidgetPool.YesNoPool) do
            OptionsFrame_EnableCheckBox(getglobal(theButton.widgetName.."_CheckButtonYes"))
            OptionsFrame_EnableCheckBox(getglobal(theButton.widgetName.."_CheckButtonNo"))
        end
        self:GUI_AbleDM(nil, Mazzifier_CurrentInstallOptions.AddonExtras.damageheal)
        self:GUI_AbleTM(nil, Mazzifier_CurrentInstallOptions.AddonExtras.threatmeter)
        self:GUI_AbleRaid(nil, Mazzifier_CurrentInstallOptions.AddonExtras.raidextras)
        self:GUI_AbleMap(nil, Mazzifier_CurrentInstallOptions.AddonExtras.mapnotes)
    else
        for _,theButton in pairs(Mazzifier_WidgetPool.CheckButtonPool) do
            OptionsFrame_DisableCheckBox(theButton.frame)
        end
        for _,theButton in pairs(Mazzifier_WidgetPool.YesNoPool) do
            OptionsFrame_DisableCheckBox(getglobal(theButton.widgetName.."_CheckButtonYes"))
            OptionsFrame_DisableCheckBox(getglobal(theButton.widgetName.."_CheckButtonNo"))
        end
    end
end

function Mazzifier:CompileWarnList()
    local needsUpdate, installedVersion, modInfo, loadable
    local warningList = ""
    for addonIndexName, addonInfo in pairs(Mazzifier_AddOnInfo) do
        Mazzifier_AddOnInfo[addonIndexName].needsUpdate = true;
        installedVersion = Mazzifier:Get_InstalledVersionNumber(addonIndexName)
        modInfo = MazzleUI_AddOn_DB[addonIndexName]
        if ((addonInfo.name == "") or (installedVersion >= addonInfo.lastUpdate) or
            (modInfo and modInfo.classes and (not modInfo.classes[self:Capitalize(BClass:GetReverseTranslation(UnitClass("player")))]))) then
            if (not (addonInfo.posSettings and Mazzifier:IsDirtyAspect())) then Mazzifier_AddOnInfo[addonIndexName].needsUpdate = false; end;
        end
        if (not addonInfo.noRequirement) then
            _, _, _, _, loadable, _, _= GetAddOnInfo(addonIndexName)
            if (Mazzifier_AddOnInfo[addonIndexName].needsUpdate and (not loadable)) then
                if (warningList == "") then
                    warningList = addonInfo.name
                else
                    warningList = warningList..", "..addonInfo.name
                end
            end
        end
    end
    Mazzifier_ASInfoAll["warningList"] = warningList
end

        
function Mazzifier:GUI_SetupASInfo()
    MazzleUI:CreateSet("Mazzifier_CurrentInstallOptions.AddOnSelection", {})
    Mazzifier:CompileWarnList()
    
    for i=3, 6, 1 do Mazzifier_ASInfoAll[i] = {}; end
    Mazzifier:GUI_SetupASInfo_AS1(3)
    Mazzifier:GUI_SetupASInfo_AS2(4)
    Mazzifier:GUI_SetupASInfo_AS3(5)
    Mazzifier:GUI_SetupASInfo_AS4(6)

end
    
function Mazzifier:GUI_SetupASInfo_AS1(infoIndex)

    local tempItem = {}

    tempItem = {
        type = "Textbox", 
        text = "Core Add-Ons",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)
    
    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Full MazzleUI Install |CFFFF8000(recommended)",
        idName = "full",
        setProc = function(a,b) self:GUI_AbleParts("full",a,b); end,
        readProc = function() return (MazzleUI:GetValue("Mazzifier_CurrentInstallOptions.AddonExtras.corepackage") == "full"); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Less features, faster loading",
        idName = "loading",
        setProc = function(a,b) self:GUI_AbleParts("loading",a,b); end,
        readProc = function() return (MazzleUI:GetValue("Mazzifier_CurrentInstallOptions.AddonExtras.corepackage") == "loading"); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Less features, faster processing",
        idName = "cpu",
        setProc = function(a,b) self:GUI_AbleParts("cpu",a,b); end,
        readProc = function() return (MazzleUI:GetValue("Mazzifier_CurrentInstallOptions.AddonExtras.corepackage") == "cpu"); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Minimal features",
        idName = "minimum",
        setProc = function(a,b) self:GUI_AbleParts("minimum",a,b); end,
        readProc = function() return (MazzleUI:GetValue("Mazzifier_CurrentInstallOptions.AddonExtras.corepackage") == "minimum"); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Auction Mule",
        idName = "mule",
        setProc = function(a,b) self:GUI_AbleParts("mule",a,b); end,
        readProc = function() return (MazzleUI:GetValue("Mazzifier_CurrentInstallOptions.AddonExtras.corepackage") == "mule"); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "Notebox", yadjust = 15,
        text = "If you choose the 'auction mule' set, the Mazzifier will ignore the questions in the next few add-on selection pages.  The auction mule setup is a very minimal, fast-loading set with a few add-ons for mail, inventory and auction house functions.",
}
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to install class-specific add-ons for this character?",
        yesText = "Yes, I would like add-ons installed to help better utilize my class-specific skills.",
        noText = "No thanks.  The core MazzleUI add-ons are all I need.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.class",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "Textbox", 
        text = "Nametags and Nameplates",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -10,
        name = "No nametags or nameplates. Text does not float above the heads of people in the real world!",
        idName = "nameTagsNone",
        readProc = function() return MazzleUI:GetValue("Mazzifier_CurrentInstallOptions.AddonExtras.namenone") ; end,
        setProc = function(a,b) self:GUI_AbleNames(1); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Standard nametags above each person as Elune intended.",
        idName = "nameTagsNormal",
        readProc = function() return MazzleUI:GetValue("Mazzifier_CurrentInstallOptions.AddonExtras.nametags") ; end,
        setProc = function(a,b) self:GUI_AbleNames(2); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "I have seen the light!  Please give me super-powerful Aloft nameplates above each character.",
        idName = "nameTagsPlates",
        readProc = function() return MazzleUI:GetValue("Mazzifier_CurrentInstallOptions.AddonExtras.nameplates") ; end,
        setProc = function(a,b) self:GUI_AbleNames(3); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

end

function Mazzifier:GUI_SetupASInfo_AS2(infoIndex)

    local tempItem = {}

    tempItem = {
        type = "Textbox", 
        text = "Playstyle",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Will this character be PvP'ing?",
        yesText = "Umm..duh. Install all the PvP tools MazzleUI has to offer.  I have people to kill.",
        noText = "No, I don't PvP enough to make it worth installing PvP add-ons.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.pvp",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Does this character use the auction house?",
        yesText = "Of course!  Buy low, sell high! Invest in Loch Modan wild boar intestines!",
        noText = "No, the market makes me nervous.  I avoid it at all costs.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.auctions",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you play alts or are you a one-character player?",
        yesText = "Yes, like a God, I control the fate of many characters.  Allow me to be omniscient.",
        noText = "No, I live and breath this character.  I don't need addons that tell me about my alts.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.alts",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "Textbox", 
        text = "Raiding-related Tools",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to install some basic raiding add-ons for this character?",
        yesText = "Yes, please install replacement raid frames and oRA.",
        noText = "No, I almost never raid.  I'll stick with Blizzard's rudimentary raid interface.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.raiding",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want supplemental raiding tools?",
        yesText = "Yes, let's see what you can do to make me as hardcore as possible.  Veni, vidi, raidi!",
        noText = "No, I raid as Blizzard intended...with as little information as possible.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.raidextras",
        setProc = function(a,b) self:GUI_AbleRaid(a,b); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", xadjust = 15, yadjust = -10,
        name = "Install Big Wigs and Little Wigs timers and raid warnings",
        idName = "raidBigWigs",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs",
        setProc = function(a,b) self:GUI_ValidateRBWarningMods(b,true); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Install Deadly Boss Mods timers and raid warnings",
        idName = "raidDBM",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.dbm",
        setProc = function(a,b) self:GUI_ValidateRBWarningMods(b); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "Notebox", xadjust = -15, yadjust = 15,
        text = "Big Wigs and Deadly Boss mods are both excellent, full-featured boss encounter mods.  Deadly Boss mods offers several very cool notifications that BigWigs does not.  Big Wigs, on the other hand, may be slightly more efficient and offers warnings for 5-man instances.  In the end, you should probably choose the mod that most of your raid group uses.",
}
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", xadjust = 15, yadjust = -5,
        name = "Install Incubator (mob respawn timers)",
        idName = "raidIncubator",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.incubator",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Install XRaid Status (shows overall raid statistics like melee health, healer mana, etc.)",
        idName = "raidXRS",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.xrs",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Install Decursive (compact interface for removing debuffs)",
        idName = "raidDecursive",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.decursive",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "Textbox", xadjust = -15, 
        text = "Other Add-Ons",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you like to use an all-in-one bag that automatically organizes your stuff?",
        yesText = "Yes, I can't live without my big virtual sack!",
        noText = "No, the natural partitions of my bags is more than enough to organize my stuff.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.onebag",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you prefer square or circle buttons?",
        yesText = "Oh my god, look how cooky I am!  Circle buttons, please.",
        noText = "Square definitely.  I can barely see what the spells are with those weird shapes.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.circlebuttons",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

end

function Mazzifier:GUI_SetupASInfo_AS3(infoIndex)

    local tempItem = {}

    tempItem = {
        type = "Textbox", 
        text = "Extra Information",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you like to see timer bars for your cooldowns, spell effects and enemy casts?",
        yesText = "Yes, timers give me a lot of critical information I need!",
        noText = "OMG, information overload.  Don't install.  I get enough spam from gold farmers.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.timerbars",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you love having lots of statistical information about your character in the game?",
        yesText = "Yes.  If math were about +dmg, crit%, honor and where things drop, I'd get a PhD.",
        noText = "No.  My immersive nature measures things in cans of whoop-ass.  No other info is needed.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.data",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Would you like to have access to a large database of quest tips and information?",
        yesText = "Yes.  Fuel my questing with the power of the interwebs!",
        noText = "No.  You and Brady games can stuff it up your step-by-step corporate asses!",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.wowhead",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "Notebox", yadjust = 15,
        text = "This option installs an add-on called LightHeaded which contains a database of all user-submitted quest comments from the WoWHead web site.  According to the author Cladhaire, it uses approximately 2MB of memory in game.",
}
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want informative notes added to your map automatically?",
        yesText = "Yes, I love it when my UI scribbles useful stuff down for me!",
        noText = "No, I keep track of things the old-fashioned way, by writing them on my hand.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.mapnotes",
        setProc = function(a,b) self:GUI_AbleMap(a,b); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", xadjust = 15, yadjust = -10,
        name = "Record herb and mineral nodes I encounter",
        idName = "mapnotes1",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.mapnodes",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Record quest givers I talk to",
        idName = "mapnotes2",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.mapquests",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Record places where and what types of fish I catch",
        idName = "mapnotes3",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.mapfish",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Record places I find miscellaneous treasures like un'goro crystals, felwood plants, etc.",
        idName = "mapnotes4",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.maptreasures",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Record where trainers and vendors are?",
        idName = "mapnotes5",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.mapvendors",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", xadjust = -15, yadjust = -10,
        question = "What kind of castbar would you like with your fries?",
        yesText = "Extra fancy.  Give me a castbar with numbers, icons and a latency indicator!",
        noText = "I'm a traditionalist.  Give me a straight-up, re-skinned MazzleUI castbar.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.quartz",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you desire a damage/healing meter?",
        yesText = "Hells yeah!  I gotsta show these bitches who's the boss!",
        noText = "No, I am well-endowed IRL.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.damageheal",
        setProc = function(a,b) self:GUI_AbleDM(a,b); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", xadjust = 15, yadjust = -10,
        name = "Install Recap",
        idName = "dmRecap",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.recap",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Install SWStats",
        idName = "dmSWS",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.sws",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)
    
    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Install Recount",
        idName = "dmRecount",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.recount",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "Notebox", xadjust = -15, yadjust = 15,
        text = "Recap, SWStats, and Recount are syncable damage meters.  Recap has a very intuitive interface, offers better personal breakdowns and is more efficient because it only syncs data after the fights is over.  SWStats is capable of tracking a greater variety of special-use statistics and updates data while in combat, which, while potentially causing framerate loss when fighting, can be useful.  Recount calculates damage and healing done by characters in the party or raid group. It supports detailed information the form of pie charts, line graphs and real-time reports.  It breaks down the total damage and healing done into damage and healing done by each ability's name and percentage.  I recommend you choose the one that the majority of your raid group uses.",
}
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)
    
    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Does your raid group or party members use KLHThreatMeter or Omen?",
        yesText = "Yes, our warlocks like to know exactly when they're going to get aggro and die.",
        noText = "I have no idea what you are talking about.",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.threatmeter",
        setProc = function(a,b) self:GUI_AbleTM(a,b); end,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    tempItem = {
        type = "CheckButton", xadjust = 15, yadjust = -10,
        name = "Install KLHThreatMeter",
        idName = "tmKLH",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.klh",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)    
    
    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Install Omen",
        idName = "tmOmen",
        parameter = "Mazzifier_CurrentInstallOptions.AddonExtras.omen",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)    
    
    tempItem = {
        type = "Notebox", xadjust = -15, yadjust = 15,
        text = "Threat meters can make your raid or party far more effective by helping you keep aggro on the right people.  They can cause some framerate loss, though.",
}
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)
    
end

function Mazzifier:GUI_SetupASInfo_AS4(infoIndex)
    local tempItem, sortList = {}, {}
    local addonIndexName, addonInfo

    if (Mazzifier_ASInfoAll["warningList"]  ~= "") then
        tempItem = {
            type = "Notebox", notetype = "warning",
            text = "The Mazzifier will not be able to update the settings for certain add-ons that are currently disabled.  Those add-ons will be grayed-out in the list below.  If you plan to use any of the following add-ons on this character, you should click the button below to first enable them:|CFFF3E80C  "..Mazzifier_ASInfoAll["warningList"] ,
        }
        table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

        tempItem = {
            type = "Button", yadjust = -5,
            name = "Enable",
            label = "Click to enable add-ons that don't have the latest Mazzifications",
            setProc = function() Mazzifier:EnableNeededAddOns(); ConsoleExec("ReloadUI"); end}
        table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

        tempItem = {
            type = "Notebox", 
            text = "Pressing the button will also reload your UI.  Afterwards, you can then proceed to Mazzify normally.  Again, if you don't plan to use those disabled add-ons on this character, you can ignore this warning.",
        }
        table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)
    end
    
    tempItem = {
        type = "Textbox", 
        text = "Please check add-ons whose settings you want configured:",
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

    for addonIndexName, addonInfo in pairs(Mazzifier_AddOnInfo) do
        tempItem = { name = addonIndexName, index = addonInfo.index}
        table.insert(sortList, tempItem)
    end
    table.sort(sortList, function(a,b) return (a.index < b.index); end)

    for _, sortedInfo in pairs(sortList) do
        addonIndexName = sortedInfo.name
        addonInfo = Mazzifier_AddOnInfo[addonIndexName]
        tempItem = {
            type = "CheckButton", yadjust = -3,
            setProc = function() Mazzifier:GUI_EnterModifiedMode(); end,
        }

        tempItem.idName = addonIndexName
        tempItem.parameter =  "Mazzifier_CurrentInstallOptions.AddOnList."..addonIndexName
        if (Mazzifier_AddOnInfo[addonIndexName].needsUpdate) then
            tempItem.name = addonInfo.name.." |CFFFF8000(Needs Update)"
            tempItem.readProc = function() return true; end
            MazzleUI:SetValue("Mazzifier_CurrentInstallOptions.AddOnList."..addonIndexName, true)
        else
            tempItem.name = addonInfo.name
            tempItem.readProc = function() return false; end
            MazzleUI:SetValue("Mazzifier_CurrentInstallOptions.AddOnList."..addonIndexName, nil)
        end

        table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)
    end

    tempItem = {
        type = "Notebox", notetype = "warning",
        text = " Add-ons that are currently turned off will grayed-out in the list above.  Re-enable them if you'd like to mazzify their settings.  If all of them are grayed out, you'll need to check off the 'Add-On Settings' checkbox in the 'General Options' page of the Mazzifier." ,
    }
    table.insert(Mazzifier_ASInfoAll[infoIndex], tempItem)

end

function Mazzifier:Capitalize(str)
   returnstr = strlower(str)
   returnstr = strupper(returnstr.sub(returnstr,1,1))..returnstr.sub(returnstr, 2)
   return returnstr
end
