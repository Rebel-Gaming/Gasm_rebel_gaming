Mazzifier_Bongo_Layouts = {
	["Generic_125"] = {
		[1] = {
    		["showGridGlobally"] = true,
			["contents"] = {
				["page_3"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
				["page_4"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
				["page_1"] = {
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
					[10] = {
						["binding"] = "0",
					},
				},
				["page_2"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
			},
			["name"] = "BActionBar1",
			["buttonSize"] = 30,
			["anchor"] = {
				["y"] = 6,
				["x"] = 23,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["pages"] = 4,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "SHIFT-6",
					},
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[8] = {
						["binding"] = "SHIFT-8",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[9] = {
						["binding"] = "SHIFT-9",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[10] = {
						["binding"] = "SHIFT-0",
					},
				},
			},
			["name"] = "BActionBar2",
			["buttonSize"] = 30,
			["anchor"] = {
				["y"] = 6,
				["x"] = -23,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "CTRL-6",
					},
					[1] = {
						["binding"] = "CTRL-1",
					},
					[3] = {
						["binding"] = "CTRL-3",
					},
					[7] = {
						["binding"] = "CTRL-7",
					},
					[8] = {
						["binding"] = "CTRL-8",
					},
					[4] = {
						["binding"] = "CTRL-4",
					},
					[9] = {
						["binding"] = "CTRL-9",
					},
					[2] = {
						["binding"] = "CTRL-2",
					},
					[5] = {
						["binding"] = "CTRL-5",
					},
					[10] = {
						["binding"] = "CTRL-0",
					},
				},
			},
			["name"] = "BActionBar3",
			["buttonSize"] = 30,
			["anchor"] = {
				["y"] = 17,
				["x"] = -23,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
					[10] = {
						["binding"] = "ALT-0",
					},
				},
			},
			["name"] = "BActionBar4",
			["buttonSize"] = 30,
			["anchor"] = {
				["y"] = 17,
				["x"] = 23,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.9,
			["anchor"] = {
				["y"] = -8,
				["x"] = -41,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 0.82,
			["anchor"] = {
				["y"] = -8,
				["x"] = 63,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["WarriorSimple_16"] = {
		[1] = {
			["stances"] = {
				[2] = 1,
				[1] = 0,
				[3] = 2,
			},
    		["showGridGlobally"] = true,
			["contents"] = {
				["page_3"] = {
					[12] = {
					},
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[11] = {
					},
					[10] = {
					},
				},
				["page_1"] = {
					[12] = {
						["binding"] = "=",
					},
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
					[11] = {
						["binding"] = "-",
					},
					[10] = {
						["binding"] = "0",
					},
				},
				["page_2"] = {
					[12] = {
					},
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[11] = {
					},
					[10] = {
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 3,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["pages"] = 3,
			["numButtons"] = 12,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "F12",
					},
					[6] = {
						["binding"] = "F6",
					},
					[1] = {
						["binding"] = "F1",
					},
					[3] = {
						["binding"] = "F3",
					},
					[7] = {
						["binding"] = "F7",
					},
					[8] = {
						["binding"] = "F8",
					},
					[4] = {
						["binding"] = "F4",
					},
					[9] = {
						["binding"] = "F9",
					},
					[2] = {
						["binding"] = "F2",
					},
					[5] = {
						["binding"] = "F5",
					},
					[11] = {
						["binding"] = "F11",
					},
					[10] = {
						["binding"] = "F10",
					},
				},
			},
			["name"] = "BActionBar2",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 3,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 12,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "SHIFT-6",
					},
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[8] = {
						["binding"] = "SHIFT-8",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[9] = {
						["binding"] = "SHIFT-9",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[10] = {
						["binding"] = "SHIFT-0",
					},
				},
			},
			["name"] = "BActionBar3",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 0,
				["x"] = -14,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "BActionBar5",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "ALT-=",
					},
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
					[11] = {
						["binding"] = "ALT--",
					},
					[10] = {
						["binding"] = "ALT-0",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 11,
				["x"] = 22,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["pages"] = 1,
			["numButtons"] = 12,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "X",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 11,
				["x"] = -22,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 1,
			["anchor"] = {
				["y"] = -6,
				["x"] = -50,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1.15,
			["anchor"] = {
				["y"] = -3,
				["x"] = 42,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["MageMazzle_125"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "1",
						["action"] = {
							[1] = "Polymorph: Turtle",
							[2] = "Polymorph: Pig",
							[3] = "Polymorph",
						},
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Scorch",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Fireball",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Fire Blast",
					},
					[5] = {
						["binding"] = "5",
						["action"] = "Pyroblast",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = {
							[1] = "Polymorph: Turtle",
							[2] = "Polymorph: Pig",
							[3] = "Polymorph",
						},
					},
					[2] = {
						["action"] = "Arcane Missiles",
					},
					[3] = {
						["action"] = "Frostbolt",
					},
					[4] = {
						["action"] = "Blizzard",
					},
					[5] = {
						["action"] = "Flamestrike",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 0,
				["x"] = 10,
				["point"] = "LEFT",
				["frame"] = "BActionBar6",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 5,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Detect Magic",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Arcane Missiles",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Frostbolt",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Blizzard",
					},
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Flamestrike",
					},

				},
				["page_2"] = {
					[1] = {
						["action"] = "Detect Magic",
					},
					[2] = {
						["action"] = "Scorch",
					},
					[3] = {
						["action"] = "Fireball",
					},
					[4] = {
						["action"] = "Fire Blast",
					},
					[5] = {
						["action"] = "Pyroblast",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = -13,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 5,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "Z",
						["action"] = "Frost Nova�1",
					},
					[2] = {
						["binding"] = "V",
						["action"] = "Cone of Cold",
					},
					[3] = {
						["binding"] = "G",
						["action"] = "Arcane Explosion",
					},
					[4] = {
						["binding"] = "R",
						["action"] = "Blast Wave",
					},
					[5] = {
						["binding"] = "T",
						["action"] = "Dragon's Breath",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 3,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = -6,
				["x"] = 10,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[3] = {
						["binding"] = "Y",
						["action"] = "Cold Snap",
					},
					[4] = {
						["binding"] = "F2",
						["action"] = "Frost Ward",
					},
					[5] = {
						["binding"] = "F3",
						["action"] = "Mana Shield",
					},
					[6] = {
						["binding"] = "F4",
						["action"] = "Fire Ward",
					},
					[1] = {
						["binding"] = "ALT-X",
						["action"] = "Ice Barrier",
					},
					[2] = {
						["binding"] = "X",
						["action"] = "Ice Block",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 3,
				["x"] = -21,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["action"] = "Arcane Brilliance",
					},
					[1] = {
						["binding"] = ";",
						["action"] = "Slow Fall",
					},
					[2] = {
						["action"] = "Arcane Intellect",
					},
					[3] = {
						["action"] = "Dampen Magic",
					},
					[4] = {
						["action"] = "Amplify Magic",
					},
					[6] = {
						["binding"] = "ALT-D",
						["action"] = "Remove Lesser Curse",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = -13,
				["x"] = 0,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar4",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "`",
						["action"] = "Blink",
					},
					[2] = {
						["binding"] = "SHIFT-1",
						["action"] = "Counterspell",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 3,
				["x"] = 18,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "C",
						["action"] = {
							[1] = "Combustion",
							[2] = "Arcane Power",
						},
					},
					[2] = {
						["binding"] = "ALT-V",
						["action"] = "Presence of Mind",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = -13,
				["x"] = 0,
				["point"] = "TOP",
				["frame"] = "BActionBar6",
				["to"] = "BOTTOM",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-`",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 11,
				["x"] = 0,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "BActionBar1",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "'",
						["action"] = "Evocation",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar4",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = {
							[2] = "item�Brilliant Mana Oil�20748�",
							[1] = "item�Brilliant Wizard Oil�20749�",
							[3] = "item�Wizard Oil�20750�",
						},
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar5",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -13,
				["x"] = -45,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.73,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -13,
				["x"] = 53,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 0.8,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["HunterMazzle_16"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = "Multi-Shot",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Auto Shot",
					},
					[7] = {
						["binding"] = "T",
						["action"] = "Wyvern Sting",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Aimed Shot",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Concussive Shot",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Arcane Shot",
					},
					[6] = {
						["binding"] = "ALT-D",
						["action"] = "Distracting Shot",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Wing Clip",
					},
					[1] = {
						["action"] = "Attack",
					},
					[7] = {
						["action"] = "Counterattack",
					},
					[2] = {
						["action"] = "Raptor Strike",
					},
					[3] = {
						["action"] = "Mongoose Bite",
					},
					[4] = {
						["action"] = "Disengage",
					},
					[6] = {
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 0,
				["x"] = 15,
				["point"] = "LEFT",
				["frame"] = "BActionBar13",
				["to"] = "RIGHT",
			},
			["numButtons"] = 7,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-5",
						["action"] = "Aspect of the Pack",
					},
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Aspect of the Monkey",
					},
					[2] = {
						["binding"] = "SHIFT-2",
						["action"] = "Aspect of the Hawk",
					},
					[3] = {
						["binding"] = "SHIFT-3",
						["action"] = "Aspect of the Cheetah",
					},
					[4] = {
						["binding"] = "SHIFT-4",
						["action"] = "Aspect of the Beast",
					},
					[6] = {
						["binding"] = "SHIFT-6",
						["action"] = "Aspect of the Wild",
					},
				},
			},
			["buttonSize"] = 29,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = -24,
				["x"] = 79,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "X",
						["action"] = "Scorpid Sting",
					},
					[1] = {
						["binding"] = "Z",
						["action"] = "Serpent Sting",
					},
					[3] = {
						["binding"] = "C",
						["action"] = "Viper Sting",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 27,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "V",
						["action"] = "Volley",
					},
					[2] = {
						["binding"] = "SHIFT-V",
						["action"] = "Flare",
					},
					[3] = {
						["binding"] = "ALT-T",
						["action"] = "Tranquilizing Shot",
					},
					[4] = {
						["binding"] = "G",
						["action"] = "Scatter Shot",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 15,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F1",
						["action"] = "Explosive Trap",
					},
					[2] = {
						["binding"] = "F2",
						["action"] = "Immolation Trap",
					},
					[3] = {
						["binding"] = "F3",
						["action"] = "Frost Trap",
					},
					[4] = {
						["binding"] = "F4",
						["action"] = "Freezing Trap",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 27,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-X",
						["action"] = "Eyes of the Beast",
					},
					[2] = {
						["binding"] = "CTRL-X",
						["action"] = "Mend Pet",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 2,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["action"] = "Feed Pet",
					},
					[1] = {
						["action"] = "Call Pet",
					},
					[2] = {
						["action"] = "Dismiss Pet",
					},
					[3] = {
						["action"] = "Revive Pet",
					},
					[4] = {
						["action"] = "Tame Beast",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = -15,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-`",
						["action"] = "Intimidation",
					},
					[2] = {
						["binding"] = "ALT-B",
						["action"] = "Bestial Wrath",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = -15,
				["point"] = "RIGHT",
				["frame"] = "BActionBar7",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[9] = {
			["pages"] = 1,
			["name"] = "BActionBar9",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 0,
				["x"] = -15,
				["point"] = "RIGHT",
				["frame"] = "BActionBar5",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 5,
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-A",
						["action"] = "Trueshot Aura",
					},
					[1] = {
					},
					[2] = {
					},
					[3] = {
						["binding"] = "ALT-E",
						["action"] = "Eagle Eye",
					},
					[4] = {
						["binding"] = "SHIFT-D",
						["action"] = "Deterrence",
					},
				},
			},
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-G",
						["action"] = "Scare Beast",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = 6,
				["point"] = "LEFT",
				["frame"] = "BActionBar4",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[11] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F5",
						["action"] = "Feign Death",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar11",
			["anchor"] = {
				["y"] = 47,
				["x"] = -48,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[12] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar12",
			["anchor"] = {
				["y"] = 0,
				["x"] = 15,
				["point"] = "LEFT",
				["frame"] = "BActionBar10",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[13] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "H",
						["action"] = "Hunter's Mark",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar13",
			["anchor"] = {
				["y"] = 2,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[14] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = "Rapid Fire",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar14",
			["anchor"] = {
				["y"] = 0,
				["x"] = 15,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -8,
				["x"] = -94,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.91,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = 14,
				["x"] = -12,
				["to"] = "TOPLEFT",
				["frame"] = "ChatFrame6",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["HunterMazzle_125"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = "Multi-Shot",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Auto Shot",
					},
					[7] = {
						["binding"] = "T",
						["action"] = "Wyvern Sting",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Aimed Shot",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Concussive Shot",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Arcane Shot",
					},
					[6] = {
						["binding"] = "ALT-D",
						["action"] = "Distracting Shot",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Wing Clip",
					},
					[1] = {
						["action"] = "Attack",
					},
					[7] = {
						["action"] = "Counterattack",
					},
					[2] = {
						["action"] = "Raptor Strike",
					},
					[3] = {
						["action"] = "Mongoose Bite",
					},
					[4] = {
						["action"] = "Disengage",
					},
					[6] = {
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 0,
				["x"] = 12,
				["point"] = "LEFT",
				["frame"] = "BActionBar13",
				["to"] = "RIGHT",
			},
			["numButtons"] = 7,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-5",
						["action"] = "Aspect of the Pack",
					},
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Aspect of the Monkey",
					},
					[2] = {
						["binding"] = "SHIFT-2",
						["action"] = "Aspect of the Hawk",
					},
					[3] = {
						["binding"] = "SHIFT-3",
						["action"] = "Aspect of the Cheetah",
					},
					[4] = {
						["binding"] = "SHIFT-4",
						["action"] = "Aspect of the Beast",
					},
					[6] = {
						["binding"] = "SHIFT-6",
						["action"] = "Aspect of the Wild",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 51,
				["x"] = 52,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "X",
						["action"] = "Scorpid Sting",
					},
					[1] = {
						["binding"] = "Z",
						["action"] = "Serpent Sting",
					},
					[3] = {
						["binding"] = "C",
						["action"] = "Viper Sting",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 31,
				["x"] = 16,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "V",
						["action"] = "Volley",
					},
					[2] = {
						["binding"] = "SHIFT-V",
						["action"] = "Flare",
					},
					[3] = {
						["binding"] = "ALT-T",
						["action"] = "Tranquilizing Shot",
					},
					[4] = {
						["binding"] = "G",
						["action"] = "Scatter Shot",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 9,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F1",
						["action"] = "Explosive Trap",
					},
					[2] = {
						["binding"] = "F2",
						["action"] = "Immolation Trap",
					},
					[3] = {
						["binding"] = "F3",
						["action"] = "Frost Trap",
					},
					[4] = {
						["binding"] = "F4",
						["action"] = "Freezing Trap",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 31,
				["x"] = -16,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-X",
						["action"] = "Eyes of the Beast",
					},
					[2] = {
						["binding"] = "CTRL-X",
						["action"] = "Mend Pet",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 3,
				["x"] = -16,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["action"] = "Feed Pet",
					},
					[1] = {
						["action"] = "Call Pet",
					},
					[2] = {
						["action"] = "Dismiss Pet",
					},
					[3] = {
						["action"] = "Revive Pet",
					},
					[4] = {
						["action"] = "Tame Beast",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = -11,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-`",
						["action"] = "Intimidation",
					},
					[2] = {
						["binding"] = "ALT-B",
						["action"] = "Bestial Wrath",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = -11,
				["point"] = "RIGHT",
				["frame"] = "BActionBar7",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[9] = {
			["numButtons"] = 5,
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-A",
						["action"] = "Trueshot Aura",
					},
					[1] = {
					},
					[2] = {
					},
					[3] = {
						["binding"] = "ALT-E",
						["action"] = "Eagle Eye",
					},
					[4] = {
						["binding"] = "SHIFT-D",
						["action"] = "Deterrence",
					},
				},
			},
			["buttonSize"] = 33,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar5",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["name"] = "BActionBar9",
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-G",
						["action"] = "Scare Beast",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = 9,
				["point"] = "LEFT",
				["frame"] = "BActionBar4",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[11] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F5",
						["action"] = "Feign Death",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar11",
			["anchor"] = {
				["y"] = 51,
				["x"] = -42,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[12] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar12",
			["anchor"] = {
				["y"] = 0,
				["x"] = 9,
				["point"] = "LEFT",
				["frame"] = "BActionBar10",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[13] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "H",
						["action"] = "Hunter's Mark",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar13",
			["anchor"] = {
				["y"] = 3,
				["x"] = 16,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[14] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = "Rapid Fire",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar14",
			["anchor"] = {
				["y"] = 0,
				["x"] = 11,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -14,
				["x"] = -99,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.75,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = 6,
				["x"] = -5,
				["to"] = "TOPLEFT",
				["frame"] = "ChatFrame6",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["HunterMazzle_133"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = "Multi-Shot",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Auto Shot",
					},
					[7] = {
						["binding"] = "T",
						["action"] = "Wyvern Sting",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Aimed Shot",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Concussive Shot",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Arcane Shot",
					},
					[6] = {
						["binding"] = "ALT-D",
						["action"] = "Distracting Shot",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Wing Clip",
					},
					[1] = {
						["action"] = "Attack",
					},
					[7] = {
						["action"] = "Counterattack",
					},
					[2] = {
						["action"] = "Raptor Strike",
					},
					[3] = {
						["action"] = "Mongoose Bite",
					},
					[4] = {
						["action"] = "Disengage",
					},
					[6] = {
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar13",
				["to"] = "RIGHT",
			},
			["numButtons"] = 7,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-5",
						["action"] = "Aspect of the Pack",
					},
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Aspect of the Monkey",
					},
					[2] = {
						["binding"] = "SHIFT-2",
						["action"] = "Aspect of the Hawk",
					},
					[3] = {
						["binding"] = "SHIFT-3",
						["action"] = "Aspect of the Cheetah",
					},
					[4] = {
						["binding"] = "SHIFT-4",
						["action"] = "Aspect of the Beast",
					},
					[6] = {
						["binding"] = "SHIFT-6",
						["action"] = "Aspect of the Wild",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = -24,
				["x"] = 54,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "X",
						["action"] = "Scorpid Sting",
					},
					[1] = {
						["binding"] = "Z",
						["action"] = "Serpent Sting",
					},
					[3] = {
						["binding"] = "C",
						["action"] = "Viper Sting",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 28,
				["x"] = 19,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "V",
						["action"] = "Volley",
					},
					[2] = {
						["binding"] = "SHIFT-V",
						["action"] = "Flare",
					},
					[3] = {
						["binding"] = "ALT-T",
						["action"] = "Tranquilizing Shot",
					},
					[4] = {
						["binding"] = "G",
						["action"] = "Scatter Shot",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F1",
						["action"] = "Explosive Trap",
					},
					[2] = {
						["binding"] = "F2",
						["action"] = "Immolation Trap",
					},
					[3] = {
						["binding"] = "F3",
						["action"] = "Frost Trap",
					},
					[4] = {
						["binding"] = "F4",
						["action"] = "Freezing Trap",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 28,
				["x"] = -19,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-X",
						["action"] = "Eyes of the Beast",
					},
					[2] = {
						["binding"] = "CTRL-X",
						["action"] = "Mend Pet",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 2,
				["x"] = -19,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["action"] = "Feed Pet",
					},
					[1] = {
						["action"] = "Call Pet",
					},
					[2] = {
						["action"] = "Dismiss Pet",
					},
					[3] = {
						["action"] = "Revive Pet",
					},
					[4] = {
						["action"] = "Tame Beast",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-`",
						["action"] = "Intimidation",
					},
					[2] = {
						["binding"] = "ALT-B",
						["action"] = "Bestial Wrath",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar7",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[9] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-A",
						["action"] = "Trueshot Aura",
					},
					[1] = {
					},
					[2] = {
					},
					[3] = {
						["binding"] = "ALT-E",
						["action"] = "Eagle Eye",
					},
					[4] = {
						["binding"] = "SHIFT-D",
						["action"] = "Deterrence",
					},
				},
			},
			["name"] = "BActionBar9",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar5",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-G",
						["action"] = "Scare Beast",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar4",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[11] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F5",
						["action"] = "Feign Death",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar11",
			["anchor"] = {
				["y"] = 46,
				["x"] = -42,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[12] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar12",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar10",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[13] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "H",
						["action"] = "Hunter's Mark",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar13",
			["anchor"] = {
				["y"] = 2,
				["x"] = 19,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[14] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = "Rapid Fire",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar14",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.9,
			["anchor"] = {
				["y"] = -7,
				["x"] = -86,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 0.8,
			["anchor"] = {
				["y"] = 7,
				["x"] = -11,
				["to"] = "TOPLEFT",
				["frame"] = "ChatFrame6",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["RogueMazzle_133"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F1",
						["action"] = "Vanish",
					},
					[2] = {
						["binding"] = "F2",
						["action"] = "Feint",
					},
					[3] = {
						["binding"] = "F3",
						["action"] = "Kick",
					},
					[4] = {
						["binding"] = "F4",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = -9,
				["x"] = 107,
				["point"] = "TOPLEFT",
				["frame"] = "Minimap",
				["to"] = "TOPRIGHT",
			},
			["pages"] = 1,
			["numButtons"] = 4,
		},
		[2] = {
			["stances"] = {[1] = 1,},
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = {
							[1] = "Ghostly Strike",
							[2] = "Hemorrhage",
						},
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Sinister Strike",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Backstab",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Gouge",
					},
					[4] = {
						["binding"] = "4",
						["action"] = {
							[1] = "Riposte",
							[2] = "Ghostly Strike",
						},
					},
					[6] = {
						["binding"] = "6",
						["action"] = "Hemorrhage",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = {
							[1] = "Cheap Shot",
							[2] = "Ambush",
							[3] = "Garrote",
							[4] = "Sap",
						},
					},
					[2] = {
						["action"] = {
							[1] = "Ambush",
							[2] = "Garrote",
							[3] = "Sap",
							[4] = "Mutilate",
						},
					},
					[3] = {
						["action"] = {
							[1] = "Garrote",
							[2] = "Sap",
							[3] = "Mutilate",
						},
					},
					[4] = {
						["action"] = {
							[1] = "Sap",
							[2] = "Mutilate",
						},
					},
					[5] = {
						["action"] = "Mutilate",
					},
					[6] = {},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 1,
				["x"] = 23,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Rupture",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Eviscerate",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Slice and Dice",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Expose Armor",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Kidney Shot",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 11,
				["x"] = 23,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "C",
						["action"] = "Cold Blood",
					},
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Adrenaline Rush",
							[2] = "Premeditation",
						},
					},
					[3] = {
						["binding"] = "G",
						["action"] = "Preparation",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "F6",
						["action"] = "Pick Pocket",
					},
					[1] = {
						["binding"] = "F5",
						["action"] = "Distract",
					},
					[3] = {
						["binding"] = "F7",
						["action"] = "Disarm Trap",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar10",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[6] = {
			["name"] = "BActionBar6",
			["contents"] = {
				["page_1"] = {
					[5] = {
					},
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[6] = {
						["action"] = {
							[5] = "item�Coarse Sharpening Stone�",
							[1] = "item�Elemental Sharpening Stone�",
							[2] = "item�Dense Sharpening Stone�12404�",
							[3] = "item�Solid Sharpening Stone�",
							[4] = "item�Heavy Sharpening Stone�",
							[6] = "item�Rough Sharpening Stone�",
						},
					},
				},
			},
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 11,
				["x"] = -23,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 6,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "X",
						["action"] = "Blade Flurry",
					},
					[2] = {
						["binding"] = "V",
						["action"] = "Evasion",
					},
					[3] = {
						["binding"] = "T",
						["action"] = "Blind",
					},
					[4] = {
						["binding"] = "Z",
						["action"] = "Sprint",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar2",
				["to"] = "RIGHT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[8] = {
			["name"] = "BActionBar8",
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = "Poisons",
					},
				},
			},
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Shoot",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = -7,
				["x"] = -47,
				["point"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[9] = {
			["name"] = "BActionBar9",
			["contents"] = {
				["page_1"] = {
					[5] = {
					},
					[1] = {
					},
					[7] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[6] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 1,
				["x"] = -23,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 7,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.8,
			["anchor"] = {
				["y"] = -6,
				["x"] = 18,
				["to"] = "BOTTOMRIGHT",
				["frame"] = "ChatFrame1",
				["point"] = "BOTTOMLEFT",
			},
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1.1,
			["anchor"] = {
				["y"] = -7,
				["x"] = 41,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	
	},
	["RogueMazzle_125"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F1",
						["action"] = "Vanish",
					},
					[2] = {
						["binding"] = "F2",
						["action"] = "Feint",
					},
					[3] = {
						["binding"] = "F3",
						["action"] = "Kick",
					},
					[4] = {
						["binding"] = "F4",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = -7,
				["x"] = 106,
				["point"] = "TOPLEFT",
				["frame"] = "Minimap",
				["to"] = "TOPRIGHT",
			},
			["pages"] = 1,
			["numButtons"] = 4,
		},
		[2] = {
			["stances"] = {[1] = 1,},
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = {
							[1] = "Ghostly Strike",
							[2] = "Hemorrhage",
						},
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Sinister Strike",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Backstab",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Gouge",
					},
					[4] = {
						["binding"] = "4",
						["action"] = {
							[1] = "Riposte",
							[2] = "Ghostly Strike",
						},
					},
					[6] = {
						["binding"] = "6",
						["action"] = "Hemorrhage",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = {
							[1] = "Cheap Shot",
							[2] = "Ambush",
							[3] = "Garrote",
							[4] = "Sap",
						},
					},
					[2] = {
						["action"] = {
							[1] = "Ambush",
							[2] = "Garrote",
							[3] = "Sap",
							[4] = "Mutilate",
						},
					},
					[3] = {
						["action"] = {
							[1] = "Garrote",
							[2] = "Sap",
							[3] = "Mutilate",
						},
					},
					[4] = {
						["action"] = {
							[1] = "Sap",
							[2] = "Mutilate",
						},
					},
					[5] = {
						["action"] = "Mutilate",
					},
					[6] = {},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 2,
				["x"] = 18,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Rupture",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Eviscerate",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Slice and Dice",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Expose Armor",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Kidney Shot",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 11,
				["x"] = 18,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "C",
						["action"] = "Cold Blood",
					},
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Adrenaline Rush",
							[2] = "Premeditation",
						},
					},
					[3] = {
						["binding"] = "G",
						["action"] = "Preparation",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "F6",
						["action"] = "Pick Pocket",
					},
					[1] = {
						["binding"] = "F5",
						["action"] = "Distract",
					},
					[3] = {
						["binding"] = "F7",
						["action"] = "Disarm Trap",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar10",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[6] = {
			["numButtons"] = 6,
			["contents"] = {
				["page_1"] = {
					[5] = {
					},
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[6] = {
						["action"] = {
							[5] = "item�Coarse Sharpening Stone�",
							[1] = "item�Elemental Sharpening Stone�",
							[2] = "item�Dense Sharpening Stone�12404�",
							[3] = "item�Solid Sharpening Stone�",
							[4] = "item�Heavy Sharpening Stone�",
							[6] = "item�Rough Sharpening Stone�",
						},
					},
				},
			},
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 11,
				["x"] = -18,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["name"] = "BActionBar6",
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "X",
						["action"] = "Blade Flurry",
					},
					[2] = {
						["binding"] = "V",
						["action"] = "Evasion",
					},
					[3] = {
						["binding"] = "T",
						["action"] = "Blind",
					},
					[4] = {
						["binding"] = "Z",
						["action"] = "Sprint",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 2,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 3,
				["x"] = -12,
				["point"] = "TOPRIGHT",
				["frame"] = "ChatFrame6",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[8] = {
			["numButtons"] = 1,
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = "Poisons",
					},
				},
			},
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["name"] = "BActionBar8",
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Shoot",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = -8,
				["x"] = -41,
				["point"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[9] = {
			["numButtons"] = 7,
			["contents"] = {
				["page_1"] = {
					[5] = {
					},
					[1] = {
					},
					[7] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[6] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 2,
				["x"] = -18,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["name"] = "BActionBar9",
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -6,
				["x"] = 18,
				["to"] = "BOTTOMRIGHT",
				["frame"] = "ChatFrame1",
				["point"] = "BOTTOMLEFT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -4,
				["x"] = 42,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 1.1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["WarriorJoyluck_125"] = {
		[1] = {
			["stances"] = {
				[2] = 1,
				[1] = 0,
				[3] = 2,
			},
			["contents"] = {
				["page_3"] = {
					[1] = {
						["action"] = "Intercept",
					},
					[2] = {
						["action"] = "Berserker Rage",
					},
					[3] = {
						["action"] = "Hamstring",
					},
					[4] = {
						["action"] = "Sunder Armor",
					},
					[5] = {
						["action"] = "Pummel",
					},
					[6] = {
						["action"] = "Whirlwind",
					},
					[7] = {
						["action"] = "Slam",
					},
					[8] = {
						["action"] = "Concussion Blow",
					},
				},
				["page_1"] = {
					[1] = {
						["binding"] = "1",
						["action"] = "Charge",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Rend",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Hamstring",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Sunder Armor",
					},
					[5] = {
						["binding"] = "5",
						["action"] = "Shield Bash",
					},
					[6] = {
						["binding"] = "6",
						["action"] = "Thunder Clap",
					},
					[7] = {
						["binding"] = "7",
						["action"] = "Mocking Blow",
					},
					[8] = {
						["binding"] = "8",
						["action"] = "Concussion Blow",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = "Taunt",
					},
					[2] = {
						["action"] = "Rend",
					},
					[3] = {
						["action"] = "Revenge",
					},
					[4] = {
						["action"] = "Sunder Armor",
					},
					[5] = {
						["action"] = "Shield Bash",
					},
					[6] = {
						["action"] = "Shield Block",
					},
					[7] = {
						["action"] = "Disarm",
					},
					[8] = {
						["action"] = "Concussion Blow",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 4,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["pages"] = 3,
			["numButtons"] = 8,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-Q",
						["action"] = {
							[1] = "Mortal Strike",
							[2] = "Bloodthirst",
							[3] = "Devastate",
						},
					},
					[2] = {
						["binding"] = "SHIFT-E",
						["action"] = "Execute",
					},
					[3] = {
						["binding"] = "ALT-Q",
						["action"] = "Heroic Strike",
					},
					[4] = {
						["binding"] = "ALT-E",
						["action"] = "Overpower",
					},
					[5] = {
						["binding"] = "CTRL-Q",
						["action"] = "Cleave",
					},
					[6] = {
						["binding"] = "CTRL-E",
						["action"] = {
							[1] = "Sweeping Strikes",
							[2] = "Rampage",
							[3] = "Shield Slam",
						},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = -41,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "V",
						["action"] = {
							[1] = "Last Stand",
							[2] = "Death Wish",
						},
					},
					[1] = {
						["binding"] = "R",
						["action"] = "Bloodrage",
					},
					[3] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Death Wish",
							[2] = "Last Stand",
						},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 0,
				["x"] = 4,
				["point"] = "LEFT",
				["frame"] = "BActionBar2",
				["to"] = "RIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[4] = {
			["stances"] = {
				[2] = 1,
				[1] = 0,
				[3] = 2,
			},
			["contents"] = {
				["page_3"] = {
					[1] = {
						["action"] = "Recklessness",
					},
				},
				["page_1"] = {
					[1] = {
						["binding"] = "T",
						["action"] = "Retaliation",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = "Shield Wall",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 1,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BClassBar",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["pages"] = 3,
			["numButtons"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F1",
						["action"] = "Shoot",
					},
					[2] = {
						["binding"] = "`",
						["action"] = "Attack",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 4,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Piercing Howl",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Battle Shout",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Demoralizing Shout",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Intimidating Shout",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Challenging Shout",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar5",
				["to"] = "LEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[7] = {
			["name"] = "BActionBar7",
			["contents"] = {
				["page_1"] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
					[8] = {
						["binding"] = "G",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
				},
			},
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 11,
				["x"] = -22,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 8,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.9,
			["anchor"] = {
				["y"] = -8,
				["x"] = -41,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1,
			["anchor"] = {
				["y"] = -5,
				["x"] = 46,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["WarlockMazzle_125"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = "Conflagrate",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Shadow Bolt",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Immolate",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Corruption",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Searing Pain",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 2,
				["x"] = 20,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Curse of Shadow",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Curse of the Elements",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Curse of Recklessness",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Curse of Agony",
					},
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Curse of Doom",
					},
					[6] = {
						["binding"] = "ALT-6",
						["action"] = "Curse of Tongues",
					},
					[7] = {
						["binding"] = "ALT-7",
						["action"] = "Curse of Weakness",
					},
					[8] = {
						["binding"] = "ALT-8",
						["action"] = "Curse of Exhaustion",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 10,
				["x"] = 20,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 8,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F2",
						["action"] = "Drain Soul",
					},
					[2] = {
						["binding"] = "F3",
						["action"] = "Drain Life",
					},
					[3] = {
						["binding"] = "F4",
						["action"] = "Drain Mana",
					},
					[4] = {
						["binding"] = "F5",
						["action"] = "Siphon Life",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = -7,
				["x"] = 49,
				["point"] = "TOPLEFT",
				["frame"] = "Minimap",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "G",
						["action"] = "Hellfire",
					},
					[2] = {
						["binding"] = "V",
						["action"] = "Rain of Fire",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "6",
						["action"] = "Shadowburn",
					},
					[2] = {
						["binding"] = "7",
						["action"] = "Soul Fire",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "CTRL-5",
						["action"] = "Demonic Sacrifice",
					},
					[1] = {
						["binding"] = "CTRL-1",
						["action"] = {
							[1] = "Demon Armor",
							[2] = "Demon Skin",
						},
					},
					[7] = {
						["binding"] = "CTRL-7",
						["action"] = "Soul Link",
					},
					[2] = {
						["binding"] = "CTRL-2",
						["action"] = "Shadow Ward",
					},
					[3] = {
						["binding"] = "CTRL-3",
						["action"] = "Unending Breath",
					},
					[4] = {
						["binding"] = "CTRL-4",
						["action"] = "Detect Invisibility",
					},
					[6] = {
						["binding"] = "CTRL-6",
						["action"] = "Amplify Curse",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 10,
				["x"] = -20,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 7,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "X",
						["action"] = "Fear",
					},
					[1] = {
						["binding"] = "Z",
						["action"] = "Death Coil",
					},
					[3] = {
						["binding"] = "SHIFT-X",
						["action"] = "Howl of Terror",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 2,
				["x"] = -20,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-B",
						["action"] = "Enslave Demon",
					},
					[2] = {
						["binding"] = "ALT-B",
						["action"] = "Banish",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = -12,
				["point"] = "RIGHT",
				["frame"] = "BActionBar7",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[9] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "Y",
						["action"] = "Health Funnel",
					},
					[1] = {
						["binding"] = "T",
						["action"] = "Life Tap",
					},
					[3] = {
						["binding"] = "SHIFT-T",
						["action"] = "Dark Pact",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = 0,
				["x"] = -12,
				["point"] = "RIGHT",
				["frame"] = "BActionBar8",
				["to"] = "LEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-S",
						["action"] = "Ritual of Summoning",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = -12,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[11] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar11",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar5",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -9,
				["x"] = -41,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.9,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = 7,
				["x"] = -3,
				["to"] = "TOPLEFT",
				["frame"] = "ChatFrame6",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
	},
	["WarriorJoyluck_16"] = {
		[1] = {
			["stances"] = {
				[2] = 1,
				[1] = 0,
				[3] = 2,
			},
			["contents"] = {
				["page_3"] = {
					[1] = {
						["action"] = "Intercept",
					},
					[2] = {
						["action"] = "Berserker Rage",
					},
					[3] = {
						["action"] = "Hamstring",
					},
					[4] = {
						["action"] = "Sunder Armor",
					},
					[5] = {
						["action"] = "Pummel",
					},
					[6] = {
						["action"] = "Whirlwind",
					},
					[7] = {
						["action"] = "Slam",
					},
					[8] = {
						["action"] = "Concussion Blow",
					},
				},
				["page_1"] = {
					[1] = {
						["binding"] = "1",
						["action"] = "Charge",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Rend",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Hamstring",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Sunder Armor",
					},
					[5] = {
						["binding"] = "5",
						["action"] = "Shield Bash",
					},
					[6] = {
						["binding"] = "6",
						["action"] = "Thunder Clap",
					},
					[7] = {
						["binding"] = "7",
						["action"] = "Mocking Blow",
					},
					[8] = {
						["binding"] = "8",
						["action"] = "Concussion Blow",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = "Taunt",
					},
					[2] = {
						["action"] = "Rend",
					},
					[3] = {
						["action"] = "Revenge",
					},
					[4] = {
						["action"] = "Sunder Armor",
					},
					[5] = {
						["action"] = "Shield Bash",
					},
					[6] = {
						["action"] = "Shield Block",
					},
					[7] = {
						["action"] = "Disarm",
					},
					[8] = {
						["action"] = "Concussion Blow",
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 4,
				["x"] = 18,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["pages"] = 3,
			["numButtons"] = 8,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-Q",
						["action"] = {
							[1] = "Mortal Strike",
							[2] = "Bloodthirst",
							[3] = "Devastate",
						},
					},
					[2] = {
						["binding"] = "SHIFT-E",
						["action"] = "Execute",
					},
					[3] = {
						["binding"] = "ALT-Q",
						["action"] = "Heroic Strike",
					},
					[4] = {
						["binding"] = "ALT-E",
						["action"] = "Overpower",
					},
					[5] = {
						["binding"] = "CTRL-Q",
						["action"] = "Cleave",
					},
					[6] = {
						["binding"] = "CTRL-E",
						["action"] = {
							[1] = "Sweeping Strikes",
							[2] = "Rampage",
							[3] = "Shield Slam",
						},
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = -40,
				["x"] = 19,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "V",
						["action"] = {
							[1] = "Last Stand",
							[2] = "Death Wish",
						},
					},
					[1] = {
						["binding"] = "R",
						["action"] = "Bloodrage",
					},
					[3] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Death Wish",
							[2] = "Last Stand",
						},
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar2",
				["to"] = "RIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[4] = {
			["stances"] = {
				[2] = 1,
				[1] = 0,
				[3] = 2,
			},
			["contents"] = {
				["page_3"] = {
					[1] = {
						["action"] = "Recklessness",
					},
				},
				["page_1"] = {
					[1] = {
						["binding"] = "T",
						["action"] = "Retaliation",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = "Shield Wall",
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 11,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["pages"] = 3,
			["numButtons"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F1",
						["action"] = "Shoot",
					},
					[2] = {
						["binding"] = "`",
						["action"] = "Attack",
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 4,
				["x"] = -18,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Piercing Howl",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Battle Shout",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Demoralizing Shout",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Intimidating Shout",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Challenging Shout",
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar5",
				["to"] = "LEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[7] = {
			["numButtons"] = 8,
			["contents"] = {
				["page_1"] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
					[8] = {
						["binding"] = "G",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
				},
			},
			["buttonSize"] = 38,
			["anchor"] = {
				["y"] = -40,
				["x"] = -19,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["name"] = "BActionBar7",
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -5,
				["x"] = -50,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -5,
				["x"] = 49,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["ShamanMazzle_125"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "2",
						["action"] = "Lightning Bolt",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Attack",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Chain Lightning",
					},
				},
				["page_2"] = {
					[2] = {
						["action"] = "Lesser Healing Wave",
					},
					[1] = {
						["action"] = "Healing Wave",
					},
					[3] = {
						["action"] = "Chain Heal",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = -11,
				["x"] = 59,
				["point"] = "TOPLEFT",
				["frame"] = "Minimap",
				["to"] = "TOPRIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 3,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-7",
						["action"] = "Nature's Swiftness",
					},
					[1] = {
						["binding"] = "4",
						["action"] = "Earth Shock",
					},
					[2] = {
						["binding"] = "5",
						["action"] = "Flame Shock",
					},
					[3] = {
						["binding"] = "6",
						["action"] = "Frost Shock",
					},
					[4] = {
						["binding"] = "7",
						["action"] = {
							[1] = "Elemental Mastery",
							[2] = "Stormstrike",
						},
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = {
							[1] = "Elemental Mastery",
							[2] = "Stormstrike",
						},
					},
					[1] = {
						["action"] = "Cure Disease",
					},
					[2] = {
						["action"] = "Cure Poison",
					},
					[3] = {
						["action"] = "Ancestral Spirit",
					},
					[4] = {
						["action"] = "Nature's Swiftness",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 0,
				["x"] = 9,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 5,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Lesser Healing Wave",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Healing Wave",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Chain Heal",
					},
				},
				["page_2"] = {
					[2] = {
						["action"] = "Lightning Bolt",
					},
					[1] = {
						["action"] = "Attack",
					},
					[3] = {
						["action"] = "Chain Lightning",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = -11,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 3,
			["pages"] = 2,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "ALT-5",
						["action"] = "Cure Poison",
					},
					[1] = {
						["binding"] = "ALT-4",
						["action"] = "Cure Disease",
					},
					[3] = {
						["binding"] = "ALT-6",
						["action"] = "Ancestral Spirit",
					},
				},
				["page_2"] = {
					[2] = {
						["action"] = "Flame Shock",
					},
					[1] = {
						["action"] = "Earth Shock",
					},
					[3] = {
						["action"] = "Frost Shock",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 9,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 3,
			["pages"] = 2,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "Z",
						["action"] = "Ghost Wolf",
					},
					[2] = {
						["action"] = "Lightning Shield",
					},
					[3] = {
						["action"] = "Water Breathing",
					},
					[4] = {
						["action"] = "Water Walking",
					},
					[5] = {
						["action"] = "Flametongue Weapon",
					},
					[6] = {
						["action"] = "Frostbrand Weapon",
					},
					[7] = {
						["action"] = "Rockbiter Weapon",
					},
					[8] = {
						["action"] = "Windfury Weapon",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar9",
				["to"] = "RIGHT",
			},
			["numButtons"] = 8,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "T",
						["action"] = "Mana Tide Totem",
					},
					[1] = {
						["binding"] = "SHIFT-F1",
						["action"] = "Windwall Totem",
					},
					[3] = {
						["binding"] = "SHIFT-F3",
						["action"] = "Stoneskin Totem",
					},
					[7] = {
						["binding"] = "SHIFT-F6",
						["action"] = "Fire Resistance Totem",
					},
					[8] = {
						["binding"] = "SHIFT-F7",
						["action"] = "Nature Resistance Totem",
					},
					[4] = {
						["binding"] = "SHIFT-F4",
						["action"] = "Stoneclaw Totem",
					},
					[9] = {
						["binding"] = "SHIFT-F8",
						["action"] = "Frost Resistance Totem",
					},
					[2] = {
						["binding"] = "SHIFT-F2",
						["action"] = "Tranquil Air Totem",
					},
					[5] = {
						["binding"] = "SHIFT-F5",
						["action"] = "Sentry Totem",
					},
					[11] = {
						["binding"] = "SHIFT-F10",
						["action"] = "Strength of Earth Totem",
					},
					[10] = {
						["binding"] = "SHIFT-F9",
						["action"] = "Grace of Air Totem",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 2,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 14,
				["x"] = -14,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 11,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "CTRL-5",
						["action"] = "Searing Totem",
					},
					[1] = {
						["binding"] = "CTRL-1",
						["action"] = "Earthbind Totem",
					},
					[2] = {
						["binding"] = "CTRL-2",
						["action"] = "Flametongue Totem",
					},
					[3] = {
						["binding"] = "CTRL-3",
						["action"] = "Fire Nova Totem",
					},
					[4] = {
						["binding"] = "CTRL-4",
						["action"] = "Magma Totem",
					},
					[6] = {
						["binding"] = "CTRL-6",
						["action"] = "Windfury Totem",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 45,
				["x"] = -45,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-F",
						["action"] = "Tremor Totem",
					},
					[1] = {
						["binding"] = "G",
						["action"] = "Healing Stream Totem",
					},
					[2] = {
						["binding"] = "V",
						["action"] = "Mana Spring Totem",
					},
					[3] = {
						["binding"] = "ALT-C",
						["action"] = "Poison Cleansing Totem",
					},
					[4] = {
						["binding"] = "ALT-D",
						["action"] = "Disease Cleansing Totem",
					},
					[6] = {
						["binding"] = "X",
						["action"] = "Grounding Totem",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 2,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = -9,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = "Purge",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = 0,
				["to"] = "LEFT",
				["frame"] = "BActionBar7",
				["point"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = 10,
				["x"] = 17,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.8,
			["anchor"] = {
				["y"] = 500,
				["x"] = 20,
				["to"] = "BOTTOMLEFT",
				["frame"] = "UIParent",
				["point"] = "BOTTOMLEFT",
			},
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 0.8,
			["anchor"] = {
				["y"] = 550,
				["x"] = 20,
				["to"] = "BOTTOMLEFT",
				["frame"] = "UIParent",
				["point"] = "BOTTOMLEFT",
			},
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["GenericBig_125"] = {
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[1] = {
			["name"] = "BActionBar1",
    		["showGridGlobally"] = true,
			["contents"] = {
				["page_3"] = {
					[12] = {
					},
					[6] = {
					},
					[13] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[14] = {
					},
					[2] = {
					},
					[5] = {
					},
					[11] = {
					},
					[10] = {
					},
				},
				["page_4"] = {
					[12] = {
					},
					[6] = {
					},
					[13] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[10] = {
					},
					[5] = {
					},
					[11] = {
					},
					[14] = {
					},
				},
				["page_1"] = {
					[12] = {
						["binding"] = "ALT-5",
					},
					[6] = {
						["binding"] = "6",
					},
					[13] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "ALT-1",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "ALT-2",
					},
					[14] = {
						["binding"] = "ALT-7",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
					[11] = {
						["binding"] = "ALT-4",
					},
					[10] = {
						["binding"] = "ALT-3",
					},
				},
				["page_2"] = {
					[12] = {
					},
					[6] = {
					},
					[13] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[14] = {
					},
					[2] = {
					},
					[5] = {
					},
					[11] = {
					},
					[10] = {
					},
				},
			},
			["buttonSize"] = 42,
			["anchor"] = {
				["y"] = -15,
				["x"] = 20,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["rows"] = 2,
			["pages"] = 4,
			["numButtons"] = 14,
		},
		[2] = {
			["name"] = "BActionBar2",
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "CTRL-5",
					},
					[6] = {
						["binding"] = "SHIFT-6",
					},
					[13] = {
						["binding"] = "CTRL-6",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[8] = {
						["binding"] = "CTRL-1",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[9] = {
						["binding"] = "CTRL-2",
					},
					[14] = {
						["binding"] = "CTRL-7",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[11] = {
						["binding"] = "CTRL-4",
					},
					[10] = {
						["binding"] = "CTRL-3",
					},
				},
			},
			["buttonSize"] = 42,
			["anchor"] = {
				["y"] = -15,
				["x"] = -20,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 2,
			["pages"] = 1,
			["numButtons"] = 14,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.9,
			["anchor"] = {
				["y"] = -5,
				["x"] = -41,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 0.82,
			["anchor"] = {
				["y"] = -5,
				["x"] = 60,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["RogueSimple_133"] = {
		[1] = {
			["stances"] = {[1] = 1,},
    		["showGridGlobally"] = true,
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
					[10] = {
						["binding"] = "0",
					},
				},
				["page_2"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 3,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["pages"] = 2,
			["numButtons"] = 10,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "F6",
					},
					[1] = {
						["binding"] = "F1",
					},
					[3] = {
						["binding"] = "F3",
					},
					[7] = {
						["binding"] = "F7",
					},
					[8] = {
						["binding"] = "F8",
					},
					[4] = {
						["binding"] = "F4",
					},
					[9] = {
						["binding"] = "F9",
					},
					[2] = {
						["binding"] = "F2",
					},
					[5] = {
						["binding"] = "F5",
					},
					[10] = {
						["binding"] = "F10",
					},
				},
			},
			["name"] = "BActionBar2",
			["buttonSize"] = 34,
			["anchor"] = {
				["y"] = 3,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "CTRL-1",
					},
				},
			},
			["name"] = "BActionBar3",
			["buttonSize"] = 34,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar5",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
					[10] = {
						["binding"] = "ALT-0",
					},
				},
			},
			["name"] = "BActionBar4",
			["buttonSize"] = 34,
			["anchor"] = {
				["y"] = 12,
				["x"] = 22,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-F5",
					},
					[1] = {
						["binding"] = "SHIFT-F1",
					},
					[2] = {
						["binding"] = "SHIFT-F2",
					},
					[3] = {
						["binding"] = "SHIFT-F3",
					},
					[4] = {
						["binding"] = "SHIFT-F4",
					},
					[6] = {
						["binding"] = "SHIFT-F6",
						["action"] = {
							[5] = "item�Coarse Sharpening Stone�",
							[1] = "item�Elemental Sharpening Stone�",
							[2] = "item�Dense Sharpening Stone�12404�",
							[3] = "item�Solid Sharpening Stone�",
							[4] = "item�Heavy Sharpening Stone�",
							[6] = "item�Rough Sharpening Stone�",
						},
					},
				},
			},
			["name"] = "BActionBar5",
			["buttonSize"] = 34,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 6,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "X",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 12,
				["x"] = -22,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 1,
			["anchor"] = {
				["y"] = -7,
				["x"] = -50,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1.15,
			["anchor"] = {
				["y"] = -3,
				["x"] = 44,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["PaladinMazzle_125"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "1",
						["action"] = "Flash of Light",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Holy Light",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = "Attack",
					},
					[2] = {
						["action"] = "Hammer of Justice",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 5,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 2,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "7",
					},
					[1] = {
						["binding"] = "3",
						["action"] = "Cleanse",
					},
					[2] = {
						["binding"] = "4",
						["action"] = "Purify",
					},
					[3] = {
						["binding"] = "5",
						["action"] = "Lay on Hands",
					},
					[4] = {
						["binding"] = "6",
						["action"] = "Divine Intervention",
					},
					[6] = {
						["binding"] = "8",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Holy Wrath",
					},
					[1] = {
						["action"] = "Hammer of Wrath",
					},
					[2] = {
						["action"] = {
							[2] = "Holy Shock",
							[1] = "Consecration",
							[3] = "Repentance",
						},
					},
					[3] = {
						["action"] = {
							[1] = "Repentance",
							[2] = "Holy Shock",
						},
					},
					[4] = {
						["action"] = "Exorcism",
					},
					[6] = {
						["action"] = "Turn Undead",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = {
							[1] = "Repentance",
							[2] = "Holy Shock",
						},
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Attack",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Hammer of Justice",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Hammer of Wrath",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = {
							[2] = "Holy Shock",
							[1] = "Consecration",
							[3] = "Repentance",
						},
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Lay on Hands",
					},
					[1] = {
						["action"] = "Flash of Light",
					},
					[2] = {
						["action"] = "Holy Light",
					},
					[3] = {
						["action"] = "Cleanse",
					},
					[4] = {
						["action"] = "Purify",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = -43,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 5,
			["pages"] = 2,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "ALT-7",
						["action"] = "Holy Wrath",
					},
					[1] = {
						["binding"] = "ALT-6",
						["action"] = "Exorcism",
					},
					[3] = {
						["binding"] = "ALT-8",
						["action"] = "Turn Undead",
					},
				},
				["page_2"] = {
					[2] = {
					},
					[1] = {
						["action"] = "Divine Intervention",
					},
					[3] = {
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 3,
			["pages"] = 2,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-5",
						["action"] = "Seal of Light",
					},
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Seal of Righteousness",
					},
					[2] = {
						["binding"] = "SHIFT-2",
						["action"] = "Seal of the Crusader",
					},
					[3] = {
						["binding"] = "SHIFT-3",
						["action"] = "Seal of Justice",
					},
					[4] = {
						["binding"] = "SHIFT-4",
						["action"] = "Seal of Wisdom",
					},
					[6] = {
						["binding"] = "SHIFT-6",
						["action"] = "Seal of Command",
					},
				},
			},
			["buttonSize"] = 31,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = -9,
				["x"] = -46,
				["point"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "T",
					},
					[1] = {
						["binding"] = "Z",
						["action"] = "Divine Shield",
					},
					[2] = {
						["binding"] = "X",
						["action"] = "Divine Protection",
					},
					[3] = {
						["binding"] = "C",
						["action"] = "Righteous Fury",
					},
					[4] = {
						["binding"] = "V",
						["action"] = "Holy Shield",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 0,
				["x"] = -10,
				["point"] = "RIGHT",
				["frame"] = "BActionBar10",
				["to"] = "LEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_3"] = {
					[5] = {
					},
					[1] = {
						["action"] = "Blessing of Sanctuary",
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[6] = {
					},
				},
				["page_1"] = {
					[5] = {
						["binding"] = "CTRL-5",
						["action"] = "Blessing of Freedom",
					},
					[1] = {
						["binding"] = "CTRL-1",
						["action"] = "Blessing of Wisdom",
					},
					[2] = {
						["binding"] = "CTRL-2",
						["action"] = "Blessing of Salvation",
					},
					[3] = {
						["binding"] = "CTRL-3",
						["action"] = "Blessing of Might",
					},
					[4] = {
						["binding"] = "CTRL-4",
						["action"] = "Blessing of Kings",
					},
					[6] = {
						["binding"] = "CTRL-6",
						["action"] = "Blessing of Protection",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Blessing of Light",
					},
					[1] = {
						["action"] = "Greater Blessing of Wisdom",
					},
					[2] = {
						["action"] = "Greater Blessing of Salvation",
					},
					[3] = {
						["action"] = "Greater Blessing of Might",
					},
					[4] = {
						["action"] = "Greater Blessing of Kings",
					},
					[6] = {
						["action"] = "Greater Blessing of Light",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 3,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = -6,
				["x"] = -6,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 6,
			["pages"] = 3,
		},
		[8] = {
			["pages"] = 1,
			["name"] = "BActionBar8",
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 0,
				["x"] = -10,
				["point"] = "RIGHT",
				["frame"] = "BActionBar9",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 3,
			["contents"] = {
				["page_1"] = {
					[2] = {
					},
					[1] = {
					},
					[3] = {
					},
				},
			},
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "G",
						["action"] = "Judgement",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 5,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = "Redemption",
					},
					[2] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[3] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = -43,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = 14,
				["x"] = -1,
				["to"] = "TOPLEFT",
				["frame"] = "ChatFrame6",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -5,
				["x"] = 46,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["RogueMazzle_16"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F1",
						["action"] = "Vanish",
					},
					[2] = {
						["binding"] = "F2",
						["action"] = "Feint",
					},
					[3] = {
						["binding"] = "F3",
						["action"] = "Kick",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = -7,
				["x"] = 109,
				["point"] = "TOPLEFT",
				["frame"] = "Minimap",
				["to"] = "TOPRIGHT",
			},
			["pages"] = 1,
			["numButtons"] = 3,
		},
		[2] = {
			["stances"] = {[1] = 1,},
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = {
							[1] = "Ghostly Strike",
							[2] = "Hemorrhage",
						},
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Sinister Strike",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Backstab",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Gouge",
					},
					[4] = {
						["binding"] = "4",
						["action"] = {
							[1] = "Riposte",
							[2] = "Ghostly Strike",
						},
					},
					[6] = {
						["binding"] = "6",
						["action"] = "Hemorrhage",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = {
							[1] = "Cheap Shot",
							[2] = "Ambush",
							[3] = "Garrote",
							[4] = "Sap",
						},
					},
					[2] = {
						["action"] = {
							[1] = "Ambush",
							[2] = "Garrote",
							[3] = "Sap",
							[4] = "Mutilate",
						},
					},
					[3] = {
						["action"] = {
							[1] = "Garrote",
							[2] = "Sap",
							[3] = "Mutilate",
						},
					},
					[4] = {
						["action"] = {
							[1] = "Sap",
							[2] = "Mutilate",
						},
					},
					[5] = {
						["action"] = "Mutilate",
					},
					[6] = {},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 1,
				["x"] = 20,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Rupture",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Eviscerate",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Slice and Dice",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Expose Armor",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Kidney Shot",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 9,
				["x"] = 20,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "C",
						["action"] = "Cold Blood",
					},
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Adrenaline Rush",
							[2] = "Premeditation",
						},
					},
					[3] = {
						["binding"] = "G",
						["action"] = "Preparation",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 15,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "F6",
						["action"] = "Pick Pocket",
					},
					[1] = {
						["binding"] = "F5",
						["action"] = "Distract",
					},
					[3] = {
						["binding"] = "F7",
						["action"] = "Disarm Trap",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = -16,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar10",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[6] = {
			["name"] = "BActionBar6",
			["contents"] = {
				["page_1"] = {
					[5] = {
					},
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[6] = {
					},
				},
			},
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 9,
				["x"] = -20,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 6,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "X",
						["action"] = "Blade Flurry",
					},
					[2] = {
						["binding"] = "V",
						["action"] = "Evasion",
					},
					[3] = {
						["binding"] = "T",
						["action"] = "Blind",
					},
					[4] = {
						["binding"] = "Z",
						["action"] = "Sprint",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = 15,
				["point"] = "LEFT",
				["frame"] = "BActionBar2",
				["to"] = "RIGHT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[8] = {
			["name"] = "BActionBar8",
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = "Poisons",
					},
				},
			},
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 0,
				["x"] = -16,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Shoot",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = -6,
				["x"] = -55,
				["point"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[9] = {
			["name"] = "BActionBar9",
			["contents"] = {
				["page_1"] = {
					[5] = {
					},
					[1] = {
					},
					[7] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[6] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 1,
				["x"] = -20,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 7,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.8,
			["anchor"] = {
				["y"] = -6,
				["x"] = 18,
				["to"] = "BOTTOMRIGHT",
				["frame"] = "ChatFrame1",
				["point"] = "BOTTOMLEFT",
			},
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1.1,
			["anchor"] = {
				["y"] = -5,
				["x"] = 44,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["DruidSimple_16"] = {
		[1] = {
    		["stances"] = {[7] = 1, [1] = 2, [3] = 1,},
    		["showGridGlobally"] = true,
			["contents"] = {
				["page_3"] = {
					[12] = {
					},
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[11] = {
					},
					[10] = {
					},
				},
				["page_1"] = {
					[12] = {
						["binding"] = "=",
					},
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
					[11] = {
						["binding"] = "-",
					},
					[10] = {
						["binding"] = "0",
					},
				},
				["page_2"] = {
					[12] = {
					},
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[11] = {
					},
					[10] = {
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 3,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 12,
			["pages"] = 3,
		},
		[2] = {
			["name"] = "BActionBar2",
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "F12",
					},
					[6] = {
						["binding"] = "F6",
					},
					[1] = {
						["binding"] = "F1",
					},
					[3] = {
						["binding"] = "F3",
					},
					[7] = {
						["binding"] = "F7",
					},
					[8] = {
						["binding"] = "F8",
					},
					[4] = {
						["binding"] = "F4",
					},
					[9] = {
						["binding"] = "F9",
					},
					[2] = {
						["binding"] = "F2",
					},
					[5] = {
						["binding"] = "F5",
					},
					[11] = {
						["binding"] = "F11",
					},
					[10] = {
						["binding"] = "F10",
					},
				},
			},
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 3,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 12,
		},
		[3] = {
			["name"] = "BActionBar3",
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "SHIFT-6",
					},
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[8] = {
						["binding"] = "SHIFT-8",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[9] = {
						["binding"] = "SHIFT-9",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[10] = {
						["binding"] = "SHIFT-0",
					},
				},
			},
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 0,
				["x"] = -14,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "BActionBar5",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 10,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "ALT-=",
					},
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
					[11] = {
						["binding"] = "ALT--",
					},
					[10] = {
						["binding"] = "ALT-0",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 10,
				["x"] = 21,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 12,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "X",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 10,
				["x"] = -21,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 1,
			["anchor"] = {
				["y"] = -6,
				["x"] = -50,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1.15,
			["anchor"] = {
				["y"] = -3,
				["x"] = 42,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["GenericBig_133"] = {
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[1] = {
			["numButtons"] = 16,
    		["showGridGlobally"] = true,
			["contents"] = {
				["page_3"] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
				},
				["page_4"] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
				},
				["page_1"] = {
					[1] = {
						["binding"] = "1",
					},
					[2] = {
						["binding"] = "2",
					},
					[3] = {
						["binding"] = "3",
					},
					[4] = {
						["binding"] = "4",
					},
					[5] = {
						["binding"] = "5",
					},
					[6] = {
						["binding"] = "6",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[9] = {
						["binding"] = "ALT-1",
					},
					[10] = {
						["binding"] = "ALT-2",
					},
					[11] = {
						["binding"] = "ALT-3",
					},
					[12] = {
						["binding"] = "ALT-4",
					},
					[13] = {
						["binding"] = "ALT-5",
					},
					[14] = {
						["binding"] = "ALT-6",
					},
					[15] = {
						["binding"] = "ALT-7",
					},
					[16] = {
						["binding"] = "ALT-8",
					},
				},
				["page_2"] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
				},
			},
			["buttonSize"] = 42,
			["anchor"] = {
				["y"] = -14,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["rows"] = 2,
			["pages"] = 4,
			["name"] = "BActionBar1",
		},
		[2] = {
			["numButtons"] = 16,
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[5] = {
						["binding"] = "SHIFT-5",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
					[6] = {
						["binding"] = "SHIFT-6",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[8] = {
						["binding"] = "SHIFT-8",
					},
					[9] = {
						["binding"] = "CTRL-1",
					},
					[10] = {
						["binding"] = "CTRL-2",
					},
					[11] = {
						["binding"] = "CTRL-3",
					},
					[12] = {
						["binding"] = "CTRL-4",
					},
					[13] = {
						["binding"] = "CTRL-5",
					},
					[14] = {
						["binding"] = "CTRL-6",
					},
					[15] = {
						["binding"] = "CTRL-7",
					},
					[16] = {
						["binding"] = "CTRL-8",
					},
				},
			},
			["buttonSize"] = 42,
			["anchor"] = {
				["y"] = -14,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 2,
			["pages"] = 1,
			["name"] = "BActionBar2",
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -5,
				["x"] = -50,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.9,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -7,
				["x"] = 54,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 0.82,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},
	},
	["DruidMazzle_125"] = {
		[1] = {
    		["stances"] = {[7] = 1, [1] = 2, [3] = 1,},
			["contents"] = {
				["page_3"] = {
					[5] = {
						["action"] = "Demoralizing Roar",
					},
					[1] = {
						["action"] = "Swipe",
					},
					[2] = {
						["action"] = "Maul",
					},
					[3] = {
						["action"] = "Growl",
					},
					[4] = {
						["action"] = "Challenging Roar",
					},
				},
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = "Wrath",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Rejuvenation",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Regrowth",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Healing Touch",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Moonfire",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Pounce",
					},
					[1] = {
						["action"] = "Claw",
					},
					[2] = {
						["action"] = "Rake",
					},
					[3] = {
						["action"] = "Shred",
					},
					[4] = {
						["action"] = "Ravage",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 1,
				["x"] = 19,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["pages"] = 3,
			["numButtons"] = 5,
		},
		[2] = {
    		["stances"] = {[7] = 1, [1] = 2, [3] = 1,},
			["contents"] = {
				["page_3"] = {
					[5] = {
					},
					[1] = {
						["action"] = "Frenzied Regeneration",
					},
					[2] = {
						["action"] = "Enrage",
					},
					[3] = {
					},
					[4] = {
					},
				},
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Insect Swarm",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Attack",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Starfire",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Hurricane",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Tranquility",
					},
				},
				["page_2"] = {
					[5] = {
					},
					[1] = {
						["action"] = "Prowl",
					},
					[2] = {
						["action"] = "Dash",
					},
					[3] = {
						["action"] = "Tiger's Fury",
					},
					[4] = {
						["action"] = "Cower",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = -8,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["allowDuplicates"] = true,
			["pages"] = 3,
			["numButtons"] = 5,
		},
		[3] = {
    		["stances"] = {[7] = 1, [1] = 2, [3] = 1,},
			["contents"] = {
				["page_3"] = {
					[2] = {
						["action"] = "Feral Charge",
					},
					[1] = {
						["action"] = "Bash",
					},
					[3] = {
						["action"] = "Faerie Fire (Feral)",
					},
				},
				["page_1"] = {
					[2] = {
						["binding"] = "X",
						["action"] = "Swiftmend",
					},
					[1] = {
						["binding"] = "Z",
						["action"] = "Nature's Swiftness",
					},
					[3] = {
						["binding"] = "C",
						["action"] = "Faerie Fire",
					},
				},
				["page_2"] = {
					[2] = {
						["action"] = "Rip",
					},
					[1] = {
						["action"] = "Ferocious Bite",
					},
					[3] = {
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["pages"] = 3,
			["numButtons"] = 3,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "G",
						["action"] = "Hibernate",
					},
					[2] = {
						["binding"] = "ALT-G",
						["action"] = "Soothe Animal",
					},
					[3] = {
						["binding"] = "`",
						["action"] = "Entangling Roots",
					},
					[4] = {
						["binding"] = "ALT-`",
						["action"] = "Nature's Grasp",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 45,
				["x"] = -43,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "R",
						["action"] = "Remove Curse",
					},
					[1] = {
						["binding"] = "ALT-V",
						["action"] = "Rebirth",
					},
					[3] = {
						["binding"] = "T",
						["action"] = "Abolish Poison",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar4",
				["to"] = "LEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-C",
						["action"] = "Omen of Clarity",
					},
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Gift of the Wild",
					},
					[2] = {
						["binding"] = "SHIFT-2",
						["action"] = "Mark of the Wild",
					},
					[3] = {
						["binding"] = "SHIFT-3",
						["action"] = "Thorns",
					},
					[4] = {
						["binding"] = "SHIFT-4",
						["action"] = "Barkskin",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = -8,
				["x"] = 24,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar4",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "6",
						["action"] = "Healing Touch�4�",
					},
					[2] = {
						["binding"] = "7",
						["action"] = "Healing Touch�9�",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = 14,
				["point"] = "LEFT",
				["frame"] = "BActionBar2",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-Z",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
					[3] = {
						["binding"] = "ALT-X",
						["action"] = "Innervate",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},
		[9] = {
			["pages"] = 1,
			["name"] = "BActionBar9",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = -8,
				["x"] = 0,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar6",
				["to"] = "BOTTOMRIGHT",
			},
			["rows"] = 1,
			["numButtons"] = 8,
			["contents"] = {
				["page_1"] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
				},
			},
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = 14,
				["x"] = -1,
				["to"] = "TOPLEFT",
				["frame"] = "ChatFrame6",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = 39,
				["x"] = 41,
				["to"] = "RIGHT",
				["frame"] = "Minimap",
				["point"] = "LEFT",
			},
			["scale"] = 1.1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["GenericBig_16"] = {
		[1] = {
    		["showGridGlobally"] = true,
			["contents"] = {
				["page_3"] = {
					[12] = {
					},
					[6] = {
					},
					[13] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[14] = {
					},
					[10] = {
					},
					[5] = {
					},
					[11] = {
					},
					[2] = {
					},
				},
				["page_1"] = {
					[12] = {
						["binding"] = "ALT-5",
					},
					[6] = {
						["binding"] = "6",
					},
					[13] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "ALT-1",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "ALT-2",
					},
					[14] = {
						["binding"] = "ALT-7",
					},
					[10] = {
						["binding"] = "ALT-3",
					},
					[5] = {
						["binding"] = "5",
					},
					[11] = {
						["binding"] = "ALT-4",
					},
					[2] = {
						["binding"] = "2",
					},
				},
				["page_2"] = {
					[12] = {
					},
					[6] = {
					},
					[13] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[14] = {
					},
					[10] = {
					},
					[5] = {
					},
					[11] = {
					},
					[2] = {
					},
				},
			},
			["name"] = "BActionBar1",
			["buttonSize"] = 42,
			["anchor"] = {
				["y"] = -12,
				["x"] = 17,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["rows"] = 2,
			["numButtons"] = 14,
			["pages"] = 3,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "CTRL-5",
					},
					[6] = {
						["binding"] = "SHIFT-6",
					},
					[13] = {
						["binding"] = "CTRL-6",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[8] = {
						["binding"] = "CTRL-1",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[9] = {
						["binding"] = "CTRL-2",
					},
					[14] = {
						["binding"] = "CTRL-7",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[10] = {
						["binding"] = "CTRL-3",
					},
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[11] = {
						["binding"] = "CTRL-4",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
				},
			},
			["name"] = "BActionBar2",
			["buttonSize"] = 42,
			["anchor"] = {
				["y"] = -12,
				["x"] = -17,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 2,
			["numButtons"] = 14,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[12] = {
					},
					[6] = {
					},
					[13] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[15] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[14] = {
					},
					[10] = {
					},
					[5] = {
					},
					[11] = {
					},
					[2] = {
					},
				},
			},
			["name"] = "BActionBar3",
			["buttonSize"] = 41,
			["anchor"] = {
				["y"] = 13,
				["x"] = 18,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["rows"] = 3,
			["numButtons"] = 15,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[12] = {
					},
					[6] = {
					},
					[13] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[15] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[14] = {
					},
					[10] = {
					},
					[5] = {
					},
					[11] = {
					},
					[2] = {
					},
				},
			},
			["name"] = "BActionBar4",
			["buttonSize"] = 41,
			["anchor"] = {
				["y"] = 13,
				["x"] = -19,
				["point"] = "RIGHT",
				["frame"] = "BActionBar2",
				["to"] = "LEFT",
			},
			["rows"] = 3,
			["numButtons"] = 15,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.9,
			["anchor"] = {
				["y"] = -4,
				["x"] = -46,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		
		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 0.82,
			["anchor"] = {
				["y"] = -4,
				["x"] = 54,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["WarriorSimple_133"] = {
		[1] = {
    		["showGridGlobally"] = true,
			["stances"] = {
				[2] = 1,
				[1] = 0,
				[3] = 2,
			},
			["contents"] = {
				["page_3"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
				["page_1"] = {
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
					[10] = {
						["binding"] = "0",
					},
				},
				["page_2"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 6,
				["x"] = 17,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["pages"] = 3,
			["numButtons"] = 10,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "F6",
					},
					[1] = {
						["binding"] = "F1",
					},
					[3] = {
						["binding"] = "F3",
					},
					[7] = {
						["binding"] = "F7",
					},
					[8] = {
						["binding"] = "F8",
					},
					[4] = {
						["binding"] = "F4",
					},
					[9] = {
						["binding"] = "F9",
					},
					[2] = {
						["binding"] = "F2",
					},
					[5] = {
						["binding"] = "F5",
					},
					[10] = {
						["binding"] = "F10",
					},
				},
			},
			["name"] = "BActionBar2",
			["buttonSize"] = 34,
			["anchor"] = {
				["y"] = 5,
				["x"] = -17,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[6] = {
						["binding"] = "SHIFT-6",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[8] = {
						["binding"] = "SHIFT-8",
					},
				},
			},
			["name"] = "BActionBar3",
			["buttonSize"] = 34,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "BActionBar5",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["numButtons"] = 8,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
					[10] = {
						["binding"] = "ALT-0",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 14,
				["x"] = 17,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["pages"] = 1,
			["numButtons"] = 10,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "X",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 14,
				["x"] = -17,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 1,
			["anchor"] = {
				["y"] = -5,
				["x"] = -50,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1.15,
			["anchor"] = {
				["y"] = -2,
				["x"] = 41,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["DruidMazzle_16"] = {
		[1] = {
    		["stances"] = {[7] = 1, [1] = 2, [3] = 1,},
			["contents"] = {
				["page_3"] = {
					[5] = {
						["action"] = "Demoralizing Roar",
					},
					[1] = {
						["action"] = "Swipe",
					},
					[2] = {
						["action"] = "Maul",
					},
					[3] = {
						["action"] = "Growl",
					},
					[4] = {
						["action"] = "Challenging Roar",
					},
				},
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = "Wrath",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Rejuvenation",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Regrowth",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Healing Touch",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Moonfire",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Pounce",
					},
					[1] = {
						["action"] = "Claw",
					},
					[2] = {
						["action"] = "Rake",
					},
					[3] = {
						["action"] = "Shred",
					},
					[4] = {
						["action"] = "Ravage",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = -2,
				["x"] = 17,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["pages"] = 3,
			["numButtons"] = 5,
		},
		[2] = {
    		["stances"] = {[7] = 1, [1] = 2, [3] = 1,},
			["contents"] = {
				["page_3"] = {
					[5] = {
					},
					[1] = {
						["action"] = "Frenzied Regeneration",
					},
					[2] = {
						["action"] = "Enrage",
					},
					[3] = {
					},
					[4] = {
					},
				},
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Insect Swarm",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Attack",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Starfire",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Hurricane",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Tranquility",
					},
				},
				["page_2"] = {
					[5] = {
					},
					[1] = {
						["action"] = "Prowl",
					},
					[2] = {
						["action"] = "Dash",
					},
					[3] = {
						["action"] = "Tiger's Fury",
					},
					[4] = {
						["action"] = "Cower",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 8,
				["x"] = 17,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["allowDuplicates"] = true,
			["pages"] = 3,
			["numButtons"] = 5,
		},
		[3] = {
    		["stances"] = {[7] = 1, [1] = 2, [3] = 1,},
			["contents"] = {
				["page_3"] = {
					[2] = {
						["action"] = "Feral Charge",
					},
					[1] = {
						["action"] = "Bash",
					},
					[3] = {
						["action"] = "Faerie Fire (Feral)",
					},
				},
				["page_1"] = {
					[2] = {
						["binding"] = "X",
						["action"] = "Swiftmend",
					},
					[1] = {
						["binding"] = "Z",
						["action"] = "Nature's Swiftness",
					},
					[3] = {
						["binding"] = "C",
						["action"] = "Faerie Fire",
					},
				},
				["page_2"] = {
					[2] = {
						["action"] = "Rip",
					},
					[1] = {
						["action"] = "Ferocious Bite",
					},
					[3] = {
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 0,
				["x"] = 15,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["pages"] = 3,
			["numButtons"] = 3,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "G",
						["action"] = "Hibernate",
					},
					[2] = {
						["binding"] = "ALT-G",
						["action"] = "Soothe Animal",
					},
					[3] = {
						["binding"] = "`",
						["action"] = "Entangling Roots",
					},
					[4] = {
						["binding"] = "ALT-`",
						["action"] = "Nature's Grasp",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 44,
				["x"] = -45,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "R",
						["action"] = "Remove Curse",
					},
					[1] = {
						["binding"] = "ALT-V",
						["action"] = "Rebirth",
					},
					[3] = {
						["binding"] = "T",
						["action"] = "Abolish Poison",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = -15,
				["point"] = "RIGHT",
				["frame"] = "BActionBar4",
				["to"] = "LEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-C",
						["action"] = "Omen of Clarity",
					},
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Gift of the Wild",
					},
					[2] = {
						["binding"] = "SHIFT-2",
						["action"] = "Mark of the Wild",
					},
					[3] = {
						["binding"] = "SHIFT-3",
						["action"] = "Thorns",
					},
					[4] = {
						["binding"] = "SHIFT-4",
						["action"] = "Barkskin",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = -10,
				["x"] = 26,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar4",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "6",
						["action"] = "Healing Touch�4�",
					},
					[2] = {
						["binding"] = "7",
						["action"] = "Healing Touch�9�",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = 15,
				["point"] = "LEFT",
				["frame"] = "BActionBar2",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-Z",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
					[3] = {
						["binding"] = "ALT-X",
						["action"] = "Innervate",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = -15,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[9] = {
			["pages"] = 1,
			["name"] = "BActionBar9",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = -7,
				["x"] = 0,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar6",
				["to"] = "BOTTOMRIGHT",
			},
			["rows"] = 1,
			["numButtons"] = 8,
			["contents"] = {
				["page_1"] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
				},
			},
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = 14,
				["x"] = -1,
				["to"] = "TOPLEFT",
				["frame"] = "ChatFrame6",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = 38,
				["x"] = 41,
				["to"] = "RIGHT",
				["frame"] = "Minimap",
				["point"] = "LEFT",
			},
			["scale"] = 1.1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["DruidSimple_133"] = {
		[1] = {
    		["showGridGlobally"] = true,
    		["stances"] = {[7] = 1, [1] = 2, [3] = 1,},
			["contents"] = {
				["page_3"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
				["page_1"] = {
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
					[10] = {
						["binding"] = "0",
					},
				},
				["page_2"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 3,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 10,
			["pages"] = 3,
		},
		[2] = {
			["pages"] = 1,
			["name"] = "BActionBar2",
			["buttonSize"] = 34,
			["anchor"] = {
				["y"] = 3,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "F6",
					},
					[1] = {
						["binding"] = "F1",
					},
					[3] = {
						["binding"] = "F3",
					},
					[7] = {
						["binding"] = "F7",
					},
					[8] = {
						["binding"] = "F8",
					},
					[4] = {
						["binding"] = "F4",
					},
					[9] = {
						["binding"] = "F9",
					},
					[2] = {
						["binding"] = "F2",
					},
					[5] = {
						["binding"] = "F5",
					},
					[10] = {
						["binding"] = "F10",
					},
				},
			},
		},
		[3] = {
			["pages"] = 1,
			["name"] = "BActionBar3",
			["buttonSize"] = 34,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "BActionBar5",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["numButtons"] = 8,
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[6] = {
						["binding"] = "SHIFT-6",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[8] = {
						["binding"] = "SHIFT-8",
					},
				},
			},
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
					[10] = {
						["binding"] = "ALT-0",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 13,
				["x"] = 22,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 10,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "X",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 13,
				["x"] = -22,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -6,
				["x"] = -50,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -3,
				["x"] = 41,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 1.15,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["MageMazzle_16"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "1",
						["action"] = {
							[1] = "Polymorph: Turtle",
							[2] = "Polymorph: Pig",
							[3] = "Polymorph",
						},
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Scorch",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Fireball",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Fire Blast",
					},
					[5] = {
						["binding"] = "5",
						["action"] = "Pyroblast",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = {
							[1] = "Polymorph: Turtle",
							[2] = "Polymorph: Pig",
							[3] = "Polymorph",
						},
					},
					[2] = {
						["action"] = "Arcane Missiles",
					},
					[3] = {
						["action"] = "Frostbolt",
					},
					[4] = {
						["action"] = "Blizzard",
					},
					[5] = {
						["action"] = "Flamestrike",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 0,
				["x"] = 11,
				["point"] = "LEFT",
				["frame"] = "BActionBar6",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 5,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Detect Magic",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Arcane Missiles",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Frostbolt",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Blizzard",
					},
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Flamestrike",
					},

				},
				["page_2"] = {
					[1] = {
						["action"] = "Detect Magic",
					},
					[2] = {
						["action"] = "Scorch",
					},
					[3] = {
						["action"] = "Fireball",
					},
					[4] = {
						["action"] = "Fire Blast",
					},
					[5] = {
						["action"] = "Pyroblast",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = -9,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 5,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "Z",
						["action"] = "Frost Nova�1�",
					},
					[2] = {
						["binding"] = "V",
						["action"] = "Cone of Cold",
					},
					[3] = {
						["binding"] = "G",
						["action"] = "Arcane Explosion",
					},
					[4] = {
						["binding"] = "R",
						["action"] = "Blast Wave",
					},
					[5] = {
						["binding"] = "T",
						["action"] = "Dragon's Breath",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 2,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = -5,
				["x"] = 11,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[3] = {
						["binding"] = "Y",
						["action"] = "Cold Snap",
					},
					[4] = {
						["binding"] = "F2",
						["action"] = "Frost Ward",
					},
					[5] = {
						["binding"] = "F3",
						["action"] = "Mana Shield",
					},
					[6] = {
						["binding"] = "F4",
						["action"] = "Fire Ward",
					},
					[1] = {
						["binding"] = "ALT-X",
						["action"] = "Ice Barrier",
					},
					[2] = {
						["binding"] = "X",
						["action"] = "Ice Block",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 8,
				["x"] = -18,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["action"] = "Arcane Brilliance",
					},
					[1] = {
						["binding"] = ";",
						["action"] = "Slow Fall",
					},
					[2] = {
						["action"] = "Arcane Intellect",
					},
					[3] = {
						["action"] = "Dampen Magic",
					},
					[4] = {
						["action"] = "Amplify Magic",
					},
					[6] = {
						["binding"] = "ALT-D",
						["action"] = "Remove Lesser Curse",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = -9,
				["x"] = 0,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar4",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "`",
						["action"] = "Blink",
					},
					[2] = {
						["binding"] = "SHIFT-1",
						["action"] = "Counterspell",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 8,
				["x"] = 18,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "C",
						["action"] = {
							[1] = "Combustion",
							[2] = "Arcane Power",
						},
					},
					[2] = {
						["binding"] = "ALT-V",
						["action"] = "Presence of Mind",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = -9,
				["x"] = 0,
				["point"] = "TOP",
				["frame"] = "BActionBar6",
				["to"] = "BOTTOM",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[8] = {
			["pages"] = 1,
			["name"] = "BActionBar8",
			["buttonSize"] = 37,
			["anchor"] = {
				["y"] = 4,
				["x"] = -11,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "BActionBar5",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 2,
			["numButtons"] = 6,
			["contents"] = {
				["page_1"] = {
					[5] = {
					},
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[6] = {
					},
				},
			},
		},
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-`",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = -21,
				["x"] = 11,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar3",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = {
							[2] = "item�Brilliant Mana Oil�20748�",
							[1] = "item�Brilliant Wizard Oil�20749�",
							[3] = "item�Wizard Oil�20750�",
						},
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = -11,
				["point"] = "RIGHT",
				["frame"] = "BActionBar5",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[11] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "'",
						["action"] = "Evocation",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar11",
			["anchor"] = {
				["y"] = 0,
				["x"] = -11,
				["point"] = "RIGHT",
				["frame"] = "BActionBar4",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -3,
				["x"] = -46,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -7,
				["x"] = 53,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
	},
	["PriestMazzle_16"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = "Prayer of Healing",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Renew",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Flash Heal",
					},
					[3] = {
						["binding"] = "3",
						["action"] = {
							[1] = "Heal",
							[2] = "Lesser Heal",
						},
					},
					[4] = {
						["binding"] = "4",
						["action"] = {
							[1] = "Greater Heal",
							[2] = "Heal",
						},
					},
					[6] = {
						["binding"] = "6",
						["action"] = {
							[1] = "Desperate Prayer",
							[2] = "Hex of Weakness",
							[3] = "Starshards",
							[4] = "Devouring Plague",
						},
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Mind Flay",
					},
					[1] = {
						["action"] = "Shadow Word: Pain",
					},
					[2] = {
						["action"] = "Mind Blast",
					},
					[3] = {
						["action"] = "Smite",
					},
					[4] = {
						["action"] = "Mana Burn",
					},
					[6] = {
						["action"] = {
							[1] = "Desperate Prayer",
							[2] = "Hex of Weakness",
							[3] = "Starshards",
							[4] = "Devouring Plague",
						},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 5,
				["x"] = 23,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Mind Flay",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Shadow Word: Pain",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Mind Blast",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Smite",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Mana Burn",
					},
					[6] = {
						["binding"] = "G",
						["action"] = "Holy Nova",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Prayer of Healing",
					},
					[1] = {
						["action"] = "Renew",
					},
					[2] = {
						["action"] = "Flash Heal",
					},
					[3] = {
						["action"] = {
							[1] = "Heal",
							[2] = "Lesser Heal",
						},
					},
					[4] = {
						["action"] = {
							[1] = "Greater Heal",
							[2] = "Heal",
						},
					},
					[6] = {
						["action"] = "Holy Nova",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = -11,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "Z",
						["action"] = "Power Word: Shield",
					},
					[2] = {
						["binding"] = "SHIFT-Z",
						["action"] = {
							[5] = "Touch of Weakness",
							[1] = "Fear Ward",
							[2] = "Feedback",
							[3] = "Shadowguard",
							[4] = "Elune's Grace",
						},
					},
					[3] = {
						["binding"] = "CTRL-1",
						["action"] = "Divine Spirit",
					},
					[4] = {
						["binding"] = "CTRL-SHIFT-1",
						["action"] = "Prayer of Spirit",
					},
					[5] = {
						["binding"] = "CTRL-2",
						["action"] = "Shadow Protection",
					},
					[6] = {
						["binding"] = "CTRL-SHIFT-2",
						["action"] = "Prayer of Shadow Protection",
					},
					[7] = {
						["binding"] = "CTRL-3",
						["action"] = "Power Word: Fortitude",
					},
					[8] = {
						["binding"] = "CTRL-4",
						["action"] = "Prayer of Fortitude",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 5,
				["x"] = -23,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 8,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "V",
						["action"] = "Psychic Scream",
					},
					[1] = {
						["binding"] = "ALT-V",
						["action"] = "Shackle Undead",
					},
					[2] = {
						["binding"] = "SHIFT-V",
						["action"] = "Mind Control",
					},
					[3] = {
						["binding"] = "CTRL-V",
						["action"] = "Mind Vision",
					},
					[4] = {
						["binding"] = "ALT-S",
						["action"] = "Mind Soothe",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 11,
				["x"] = -23,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-D",
						["action"] = "Dispel Magic",
					},
					[2] = {
						["binding"] = "ALT-D",
						["action"] = {
							[1] = "Abolish Disease",
							[2] = "Cure Disease",
						},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar3",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = ";",
						["action"] = "Levitate",
					},
					[2] = {
						["binding"] = "ALT-C",
						["action"] = "Inner Fire",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar4",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "X",
						["action"] = "Fade",
					},
					[2] = {
						["binding"] = "`",
						["action"] = "Inner Focus",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "T",
						["action"] = "Vampiric Embrace",
					},
					[1] = {
						["binding"] = "R",
						["action"] = {
							[2] = "Power Infusion",
							[1] = "Shadowform",
							[3] = "Lightwell",
						},
					},
					[3] = {
						["binding"] = "SHIFT-1",
						["action"] = "Silence",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "BOTTOMLEFT",
				["frame"] = "BActionBar2",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar7",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "CTRL-R",
						["action"] = "Resurrection",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[11] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = {
							[2] = "item�Brilliant Mana Oil�20748�",
							[1] = "item�Brilliant Wizard Oil�20749�",
							[3] = "item�Wizard Oil�20750�",
						},
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar11",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar10",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -4,
				["x"] = -55,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -9,
				["x"] = 53,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["WarriorSimple_125"] = {
		[1] = {
    		["showGridGlobally"] = true,
			["stances"] = {
				[2] = 1,
				[1] = 0,
				[3] = 2,
			},
			["contents"] = {
				["page_3"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
				},
				["page_1"] = {
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
				},
				["page_2"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 3,
				["x"] = 20,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 9,
			["pages"] = 3,
		},
		[2] = {
			["name"] = "BActionBar2",
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "F6",
					},
					[1] = {
						["binding"] = "F1",
					},
					[3] = {
						["binding"] = "F3",
					},
					[7] = {
						["binding"] = "F7",
					},
					[8] = {
						["binding"] = "F8",
					},
					[4] = {
						["binding"] = "F4",
					},
					[9] = {
						["binding"] = "F9",
					},
					[2] = {
						["binding"] = "F2",
					},
					[5] = {
						["binding"] = "F5",
					},
				},
			},
			["buttonSize"] = 33,
			["anchor"] = {
				["y"] = 3,
				["x"] = -20,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 9,
		},
		[3] = {
			["name"] = "BActionBar3",
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[6] = {
						["binding"] = "SHIFT-6",
					},
				},
			},
			["buttonSize"] = 33,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "BActionBar5",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["numButtons"] = 7,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = -13,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 9,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "X",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 14,
				["x"] = -20,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.9,
			["anchor"] = {
				["y"] = -9,
				["x"] = -42,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1.15,
			["anchor"] = {
				["y"] = -4,
				["x"] = 40,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["Generic_133"] = {
		[1] = {
    		["showGridGlobally"] = true,
			["pages"] = 4,
			["name"] = "BActionBar1",
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 4,
				["x"] = 18,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["contents"] = {
				["page_3"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
				["page_4"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
				["page_1"] = {
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
					[10] = {
						["binding"] = "0",
					},
				},
				["page_2"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[10] = {
					},
				},
			},
		},
		[2] = {
			["pages"] = 1,
			["name"] = "BActionBar2",
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 4,
				["x"] = -18,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "SHIFT-6",
					},
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[8] = {
						["binding"] = "SHIFT-8",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[9] = {
						["binding"] = "SHIFT-9",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[10] = {
						["binding"] = "SHIFT-0",
					},
				},
			},
		},
		[3] = {
			["pages"] = 1,
			["name"] = "BActionBar3",
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 12,
				["x"] = -18,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "CTRL-6",
					},
					[1] = {
						["binding"] = "CTRL-1",
					},
					[3] = {
						["binding"] = "CTRL-3",
					},
					[7] = {
						["binding"] = "CTRL-7",
					},
					[8] = {
						["binding"] = "CTRL-8",
					},
					[4] = {
						["binding"] = "CTRL-4",
					},
					[9] = {
						["binding"] = "CTRL-9",
					},
					[2] = {
						["binding"] = "CTRL-2",
					},
					[5] = {
						["binding"] = "CTRL-5",
					},
					[10] = {
						["binding"] = "CTRL-0",
					},
				},
			},
		},
		[4] = {
			["pages"] = 1,
			["name"] = "BActionBar4",
			["buttonSize"] = 35,
			["anchor"] = {
				["y"] = 12,
				["x"] = 18,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["rows"] = 1,
			["numButtons"] = 10,
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
					[10] = {
						["binding"] = "ALT-0",
					},
				},
			},
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -36,
				["x"] = -52,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "BOTTOMRIGHT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -36,
				["x"] = 46,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "BOTTOMLEFT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["PriestMazzle_125"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = "Prayer of Healing",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Renew",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Flash Heal",
					},
					[3] = {
						["binding"] = "3",
						["action"] = {
							[1] = "Heal",
							[2] = "Lesser Heal",
						},
					},
					[4] = {
						["binding"] = "4",
						["action"] = {
							[1] = "Greater Heal",
							[2] = "Heal",
						},
					},
					[6] = {
						["binding"] = "6",
						["action"] = {
							[1] = "Desperate Prayer",
							[2] = "Hex of Weakness",
							[3] = "Starshards",
							[4] = "Devouring Plague",
						},
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Mind Flay",
					},
					[1] = {
						["action"] = "Shadow Word: Pain",
					},
					[2] = {
						["action"] = "Mind Blast",
					},
					[3] = {
						["action"] = "Smite",
					},
					[4] = {
						["action"] = "Mana Burn",
					},
					[6] = {
						["action"] = {
							[1] = "Desperate Prayer",
							[2] = "Hex of Weakness",
							[3] = "Starshards",
							[4] = "Devouring Plague",
						},
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 3,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Mind Flay",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Shadow Word: Pain",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Mind Blast",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Smite",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Mana Burn",
					},
					[6] = {
						["binding"] = "G",
						["action"] = "Holy Nova",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Prayer of Healing",
					},
					[1] = {
						["action"] = "Renew",
					},
					[2] = {
						["action"] = "Flash Heal",
					},
					[3] = {
						["action"] = {
							[1] = "Heal",
							[2] = "Lesser Heal",
						},
					},
					[4] = {
						["action"] = {
							[1] = "Greater Heal",
							[2] = "Heal",
						},
					},
					[6] = {
						["action"] = "Holy Nova",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = -13,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "Z",
						["action"] = "Power Word: Shield",
					},
					[2] = {
						["binding"] = "SHIFT-Z",
						["action"] = {
							[5] = "Touch of Weakness",
							[1] = "Fear Ward",
							[2] = "Feedback",
							[3] = "Shadowguard",
							[4] = "Elune's Grace",
						},
					},
					[3] = {
						["binding"] = "CTRL-1",
						["action"] = "Divine Spirit",
					},
					[4] = {
						["binding"] = "CTRL-SHIFT-1",
						["action"] = "Prayer of Spirit",
					},
					[5] = {
						["binding"] = "CTRL-2",
						["action"] = {
							[1] = "Prayer of Shadow Protection",
							[2] = "Shadow Protection",
						},
					},
					[6] = {
						["binding"] = "CTRL-3",
						["action"] = "Power Word: Fortitude",
					},
					[7] = {
						["binding"] = "CTRL-4",
						["action"] = "Prayer of Fortitude",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 3,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 7,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "V",
						["action"] = "Psychic Scream",
					},
					[1] = {
						["binding"] = "ALT-V",
						["action"] = "Shackle Undead",
					},
					[2] = {
						["binding"] = "SHIFT-V",
						["action"] = "Mind Control",
					},
					[3] = {
						["binding"] = "CTRL-V",
						["action"] = "Mind Vision",
					},
					[4] = {
						["binding"] = "ALT-S",
						["action"] = "Mind Soothe",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 14,
				["x"] = -22,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-D",
						["action"] = "Dispel Magic",
					},
					[2] = {
						["binding"] = "ALT-D",
						["action"] = {
							[1] = "Abolish Disease",
							[2] = "Cure Disease",
						},
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar3",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = ";",
						["action"] = "Levitate",
					},
					[2] = {
						["binding"] = "ALT-C",
						["action"] = "Inner Fire",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar4",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "X",
						["action"] = "Fade",
					},
					[2] = {
						["binding"] = "`",
						["action"] = "Inner Focus",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "T",
						["action"] = "Vampiric Embrace",
					},
					[1] = {
						["binding"] = "R",
						["action"] = {
							[2] = "Power Infusion",
							[1] = "Shadowform",
							[3] = "Lightwell",
						},
					},
					[3] = {
						["binding"] = "SHIFT-1",
						["action"] = "Silence",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "BOTTOMLEFT",
				["frame"] = "BActionBar2",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = 11,
				["x"] = 0,
				["point"] = "BOTTOMLEFT",
				["frame"] = "BActionBar7",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "CTRL-R",
						["action"] = "Resurrection",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[11] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = {
							[2] = "item�Brilliant Mana Oil�20748�",
							[1] = "item�Brilliant Wizard Oil�20749�",
							[3] = "item�Wizard Oil�20750�",
						},
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar11",
			["anchor"] = {
				["y"] = 0,
				["x"] = 10,
				["point"] = "LEFT",
				["frame"] = "BActionBar9",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -9,
				["x"] = -40,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.9,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -9,
				["x"] = 58,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 0.9,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["RogueSimple_125"] = {
		[1] = {
    		["showGridGlobally"] = true,
			["stances"] = {[1] = 1,},
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
				},
				["page_2"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 3,
				["x"] = 20,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["pages"] = 2,
			["numButtons"] = 9,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "F6",
					},
					[1] = {
						["binding"] = "F1",
					},
					[3] = {
						["binding"] = "F3",
					},
					[7] = {
						["binding"] = "F7",
					},
					[8] = {
						["binding"] = "F8",
					},
					[4] = {
						["binding"] = "F4",
					},
					[9] = {
						["binding"] = "F9",
					},
					[2] = {
						["binding"] = "F2",
					},
					[5] = {
						["binding"] = "F5",
					},
				},
			},
			["name"] = "BActionBar2",
			["buttonSize"] = 33,
			["anchor"] = {
				["y"] = 3,
				["x"] = -20,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 9,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
				},
			},
			["name"] = "BActionBar3",
			["buttonSize"] = 33,
			["anchor"] = {
				["y"] = -13,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["numButtons"] = 9,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-F5",
					},
					[1] = {
						["binding"] = "SHIFT-F1",
					},
					[2] = {
						["binding"] = "SHIFT-F2",
					},
					[3] = {
						["binding"] = "SHIFT-F3",
					},
					[4] = {
						["binding"] = "SHIFT-F4",
					},
					[6] = {
						["binding"] = "SHIFT-F6",
						["action"] = {
							[5] = "item�Coarse Sharpening Stone�",
							[1] = "item�Elemental Sharpening Stone�",
							[2] = "item�Dense Sharpening Stone�12404�",
							[3] = "item�Solid Sharpening Stone�",
							[4] = "item�Heavy Sharpening Stone�",
							[6] = "item�Rough Sharpening Stone�",
						},
					},
				},
			},
			["name"] = "BActionBar4",
			["buttonSize"] = 33,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar5",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "X",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 14,
				["x"] = -20,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.9,
			["anchor"] = {
				["y"] = -9,
				["x"] = -44,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1.15,
			["anchor"] = {
				["y"] = -3,
				["x"] = 40,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["Generic_16"] = {
		[1] = {
    		["showGridGlobally"] = true,
			["contents"] = {
				["page_3"] = {
					[12] = {
					},
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[11] = {
					},
					[10] = {
					},
				},
				["page_4"] = {
					[12] = {
					},
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[10] = {
					},
					[5] = {
					},
					[11] = {
					},
					[2] = {
					},
				},
				["page_1"] = {
					[12] = {
						["binding"] = "=",
					},
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
					[11] = {
						["binding"] = "-",
					},
					[10] = {
						["binding"] = "0",
					},
				},
				["page_2"] = {
					[12] = {
					},
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[11] = {
					},
					[10] = {
					},
				},
			},
			["name"] = "BActionBar1",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 8,
				["x"] = 20,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["rows"] = 1,
			["numButtons"] = 12,
			["pages"] = 4,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "SHIFT-=",
					},
					[6] = {
						["binding"] = "SHIFT-6",
					},
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[8] = {
						["binding"] = "SHIFT-8",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[9] = {
						["binding"] = "SHIFT-9",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[11] = {
						["binding"] = "SHIFT--",
					},
					[10] = {
						["binding"] = "SHIFT-0",
					},
				},
			},
			["name"] = "BActionBar2",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 8,
				["x"] = -21,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 12,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "CTRL-=",
					},
					[6] = {
						["binding"] = "CTRL-6",
					},
					[1] = {
						["binding"] = "CTRL-1",
					},
					[3] = {
						["binding"] = "CTRL-3",
					},
					[7] = {
						["binding"] = "CTRL-7",
					},
					[8] = {
						["binding"] = "CTRL-8",
					},
					[4] = {
						["binding"] = "CTRL-4",
					},
					[9] = {
						["binding"] = "CTRL-9",
					},
					[2] = {
						["binding"] = "CTRL-2",
					},
					[5] = {
						["binding"] = "CTRL-5",
					},
					[11] = {
						["binding"] = "CTRL--",
					},
					[10] = {
						["binding"] = "CTRL-0",
					},
				},
			},
			["name"] = "BActionBar3",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 9,
				["x"] = -21,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["numButtons"] = 12,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "ALT-=",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
					[11] = {
						["binding"] = "ALT--",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
					[10] = {
						["binding"] = "ALT-0",
					},
				},
			},
			["name"] = "BActionBar4",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 9,
				["x"] = 21,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["rows"] = 1,
			["numButtons"] = 12,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 1,
			["anchor"] = {
				["y"] = -34,
				["x"] = -52,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "BOTTOMRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1,
			["anchor"] = {
				["y"] = -3,
				["x"] = 52,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["WarlockMazzle_16"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = "Conflagrate",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Shadow Bolt",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Immolate",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Corruption",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Searing Pain",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 4,
				["x"] = 21,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Curse of Shadow",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Curse of the Elements",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Curse of Recklessness",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Curse of Agony",
					},
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Curse of Doom",
					},
					[6] = {
						["binding"] = "ALT-6",
						["action"] = "Curse of Tongues",
					},
					[7] = {
						["binding"] = "ALT-7",
						["action"] = "Curse of Weakness",
					},
					[8] = {
						["binding"] = "ALT-8",
						["action"] = "Curse of Exhaustion",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 10,
				["x"] = 25,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 8,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F2",
						["action"] = "Drain Soul",
					},
					[2] = {
						["binding"] = "F3",
						["action"] = "Drain Life",
					},
					[3] = {
						["binding"] = "F4",
						["action"] = "Drain Mana",
					},
					[4] = {
						["binding"] = "F5",
						["action"] = "Siphon Life",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = -5,
				["x"] = 52,
				["point"] = "TOPLEFT",
				["frame"] = "Minimap",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 4,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "G",
						["action"] = "Hellfire",
					},
					[2] = {
						["binding"] = "V",
						["action"] = "Rain of Fire",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "6",
						["action"] = "Shadowburn",
					},
					[2] = {
						["binding"] = "7",
						["action"] = "Soul Fire",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "CTRL-5",
						["action"] = "Demonic Sacrifice",
					},
					[1] = {
						["binding"] = "CTRL-1",
						["action"] = {
							[1] = "Demon Armor",
							[2] = "Demon Skin",
						},
					},
					[7] = {
						["binding"] = "CTRL-7",
						["action"] = "Soul Link",
					},
					[2] = {
						["binding"] = "CTRL-2",
						["action"] = "Shadow Ward",
					},
					[3] = {
						["binding"] = "CTRL-3",
						["action"] = "Unending Breath",
					},
					[4] = {
						["binding"] = "CTRL-4",
						["action"] = "Detect Invisibility",
					},
					[6] = {
						["binding"] = "CTRL-6",
						["action"] = "Amplify Curse",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 10,
				["x"] = -25,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 7,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "X",
						["action"] = "Fear",
					},
					[1] = {
						["binding"] = "Z",
						["action"] = "Death Coil",
					},
					[3] = {
						["binding"] = "SHIFT-X",
						["action"] = "Howl of Terror",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 4,
				["x"] = -21,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-B",
						["action"] = "Enslave Demon",
					},
					[2] = {
						["binding"] = "ALT-B",
						["action"] = "Banish",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = -12,
				["point"] = "RIGHT",
				["frame"] = "BActionBar7",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[9] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "Y",
						["action"] = "Health Funnel",
					},
					[1] = {
						["binding"] = "T",
						["action"] = "Life Tap",
					},
					[3] = {
						["binding"] = "SHIFT-T",
						["action"] = "Dark Pact",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = 0,
				["x"] = -12,
				["point"] = "RIGHT",
				["frame"] = "BActionBar8",
				["to"] = "LEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-S",
						["action"] = "Ritual of Summoning",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = -12,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[11] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar11",
			["anchor"] = {
				["y"] = 0,
				["x"] = 11,
				["to"] = "RIGHT",
				["frame"] = "BActionBar2",
				["point"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -5,
				["x"] = -45,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 2,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = 14,
				["x"] = -10,
				["to"] = "TOPLEFT",
				["frame"] = "ChatFrame6",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
	},
	["DruidSimple_125"] = {
		[1] = {
    		["showGridGlobally"] = true,
    		["stances"] = {[7] = 1, [1] = 2, [3] = 1,},
			["contents"] = {
				["page_3"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
				},
				["page_1"] = {
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
				},
				["page_2"] = {
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 4,
				["x"] = 20,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["pages"] = 3,
			["numButtons"] = 9,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "F6",
					},
					[1] = {
						["binding"] = "F1",
					},
					[3] = {
						["binding"] = "F3",
					},
					[7] = {
						["binding"] = "F7",
					},
					[8] = {
						["binding"] = "F8",
					},
					[4] = {
						["binding"] = "F4",
					},
					[9] = {
						["binding"] = "F9",
					},
					[2] = {
						["binding"] = "F2",
					},
					[5] = {
						["binding"] = "F5",
					},
				},
			},
			["name"] = "BActionBar2",
			["buttonSize"] = 33,
			["anchor"] = {
				["y"] = 4,
				["x"] = -20,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 9,
			["pages"] = 1,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-5",
					},
					[1] = {
						["binding"] = "SHIFT-1",
					},
					[7] = {
						["binding"] = "SHIFT-7",
					},
					[2] = {
						["binding"] = "SHIFT-2",
					},
					[3] = {
						["binding"] = "SHIFT-3",
					},
					[4] = {
						["binding"] = "SHIFT-4",
					},
					[6] = {
						["binding"] = "SHIFT-6",
					},
				},
			},
			["name"] = "BActionBar3",
			["buttonSize"] = 33,
			["anchor"] = {
				["y"] = 0,
				["x"] = -12,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "BActionBar5",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["numButtons"] = 7,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = -13,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["pages"] = 1,
			["numButtons"] = 9,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "X",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 33,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 14,
				["x"] = -20,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.9,
			["anchor"] = {
				["y"] = -8,
				["x"] = -44,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 1.15,
			["anchor"] = {
				["y"] = -3,
				["x"] = 40,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["RogueSimple_16"] = {
		[1] = {
    		["showGridGlobally"] = true,
			["stances"] = {[1] = 1,},
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "=",
					},
					[6] = {
						["binding"] = "6",
					},
					[1] = {
						["binding"] = "1",
					},
					[3] = {
						["binding"] = "3",
					},
					[7] = {
						["binding"] = "7",
					},
					[8] = {
						["binding"] = "8",
					},
					[4] = {
						["binding"] = "4",
					},
					[9] = {
						["binding"] = "9",
					},
					[2] = {
						["binding"] = "2",
					},
					[5] = {
						["binding"] = "5",
					},
					[11] = {
						["binding"] = "-",
					},
					[10] = {
						["binding"] = "0",
					},
				},
				["page_2"] = {
					[12] = {
					},
					[6] = {
					},
					[1] = {
					},
					[3] = {
					},
					[7] = {
					},
					[8] = {
					},
					[4] = {
					},
					[9] = {
					},
					[2] = {
					},
					[5] = {
					},
					[11] = {
					},
					[10] = {
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 5,
				["x"] = 21,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 12,
			["pages"] = 2,
		},
		[2] = {
			["pages"] = 1,
			["name"] = "BActionBar2",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 5,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 12,
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "F12",
					},
					[6] = {
						["binding"] = "F6",
					},
					[1] = {
						["binding"] = "F1",
					},
					[3] = {
						["binding"] = "F3",
					},
					[7] = {
						["binding"] = "F7",
					},
					[8] = {
						["binding"] = "F8",
					},
					[4] = {
						["binding"] = "F4",
					},
					[9] = {
						["binding"] = "F9",
					},
					[2] = {
						["binding"] = "F2",
					},
					[5] = {
						["binding"] = "F5",
					},
					[11] = {
						["binding"] = "F11",
					},
					[10] = {
						["binding"] = "F10",
					},
				},
			},
		},
		[3] = {
			["pages"] = 1,
			["name"] = "BActionBar3",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 0,
				["x"] = -15,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "BActionBar6",
				["to"] = "BOTTOMLEFT",
			},
			["rows"] = 1,
			["numButtons"] = 4,
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "CTRL-1",
					},
					[2] = {
						["binding"] = "CTRL-2",
					},
					[3] = {
						["binding"] = "CTRL-3",
					},
					[4] = {
						["binding"] = "CTRL-4",
					},
				},
			},
		},
		[4] = {
			["pages"] = 1,
			["name"] = "BActionBar4",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 11,
				["x"] = 21,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["rows"] = 1,
			["numButtons"] = 12,
			["contents"] = {
				["page_1"] = {
					[12] = {
						["binding"] = "ALT-=",
					},
					[6] = {
						["binding"] = "ALT-6",
					},
					[1] = {
						["binding"] = "ALT-1",
					},
					[3] = {
						["binding"] = "ALT-3",
					},
					[7] = {
						["binding"] = "ALT-7",
					},
					[8] = {
						["binding"] = "ALT-8",
					},
					[4] = {
						["binding"] = "ALT-4",
					},
					[9] = {
						["binding"] = "ALT-9",
					},
					[2] = {
						["binding"] = "ALT-2",
					},
					[5] = {
						["binding"] = "ALT-5",
					},
					[11] = {
						["binding"] = "ALT--",
					},
					[10] = {
						["binding"] = "ALT-0",
					},
				},
			},
		},
		[5] = {
			["pages"] = 1,
			["name"] = "BActionBar5",
			["buttonSize"] = 36,
			["anchor"] = {
				["y"] = 0,
				["x"] = -15,
				["point"] = "RIGHT",
				["frame"] = "BActionBar3",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["numButtons"] = 6,
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-F5",
					},
					[1] = {
						["binding"] = "SHIFT-F1",
					},
					[2] = {
						["binding"] = "SHIFT-F2",
					},
					[3] = {
						["binding"] = "SHIFT-F3",
					},
					[4] = {
						["binding"] = "SHIFT-F4",
					},
					[6] = {
						["binding"] = "SHIFT-F6",
						["action"] = {
							[5] = "item�Coarse Sharpening Stone�",
							[1] = "item�Elemental Sharpening Stone�",
							[2] = "item�Dense Sharpening Stone�12404�",
							[3] = "item�Solid Sharpening Stone�",
							[4] = "item�Heavy Sharpening Stone�",
							[6] = "item�Rough Sharpening Stone�",
						},
					},
				},
			},
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "X",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 11,
				["x"] = -21,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -5,
				["x"] = -50,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -2,
				["x"] = 41,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 1.15,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["ShamanDurzil_16"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "4",
						["action"] = "Frost Shock",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Attack",
					},
					[7] = {
						["binding"] = "6",
						["action"] = "Flame Shock",
					},
					[2] = {
						["binding"] = "2",
						["action"] = {
							[1] = "Elemental Mastery",
							[2] = "Stormstrike",
						},
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Chain Lightning",
					},
					[4] = {
						["action"] = "Lightning Bolt",
					},
					[6] = {
						["binding"] = "5",
						["action"] = "Earth Shock",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Cure Disease",
					},
					[1] = {
						["action"] = "Lesser Healing Wave",
					},
					[7] = {
						["action"] = "Ancestral Spirit",
					},
					[2] = {
						["action"] = "Healing Wave",
					},
					[3] = {
						["action"] = "Chain Heal",
					},
					[4] = {
					},
					[6] = {
						["action"] = "Cure Poison",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = -5,
				["x"] = 52,
				["point"] = "TOPLEFT",
				["frame"] = "Minimap",
				["to"] = "TOPRIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 7,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-4",
						["action"] = "Cure Disease",
					},
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Lesser Healing Wave",
					},
					[7] = {
						["binding"] = "SHIFT-6",
						["action"] = "Ancestral Spirit",
					},
					[2] = {
						["binding"] = "SHIFT-2",
						["action"] = "Healing Wave",
					},
					[3] = {
						["binding"] = "SHIFT-3",
						["action"] = "Chain Heal",
					},
					[4] = {
					},
					[6] = {
						["binding"] = "SHIFT-5",
						["action"] = "Cure Poison",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Frost Shock",
					},
					[1] = {
						["action"] = "Attack",
					},
					[7] = {
						["action"] = "Flame Shock",
					},
					[2] = {
						["action"] = {
							[1] = "Elemental Mastery",
							[2] = "Stormstrike",
						},
					},
					[3] = {
						["action"] = "Chain Lightning",
					},
					[4] = {
						["action"] = "Lightning Bolt",
					},
					[6] = {
						["action"] = "Earth Shock",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 0,
				["x"] = 8,
				["point"] = "LEFT",
				["frame"] = "BActionBar11",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 7,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = "Earthbind Totem",
					},
					[2] = {
						["action"] = "Fire Nova Totem",
					},
					[3] = {
						["action"] = "Magma Totem",
					},
					[4] = {
						["action"] = "Searing Totem",
					},
					[5] = {
						["action"] = "Flametongue Totem",
					},
					[6] = {
						["action"] = "Mana Tide Totem",
					},
					[7] = {
						["action"] = "Water Walking",
					},
					[8] = {
						["action"] = "Water Breathing",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 0,
				["x"] = 8,
				["point"] = "BOTTOMLEFT",
				["frame"] = "BActionBar8",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 8,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "CTRL-6",
						["action"] = "Tranquil Air Totem",
					},
					[1] = {
						["binding"] = "CTRL-0",
						["action"] = "Sentry Totem",
					},
					[2] = {
						["binding"] = "CTRL-9",
						["action"] = "Nature Resistance Totem",
					},
					[3] = {
						["binding"] = "CTRL-8",
						["action"] = "Frost Resistance Totem",
					},
					[4] = {
						["binding"] = "CTRL-7",
						["action"] = "Fire Resistance Totem",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 11,
				["x"] = -12,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "F2",
						["action"] = "Rockbiter Weapon",
					},
					[1] = {
						["action"] = "Nature's Swiftness",
					},
					[2] = {
					},
					[3] = {
						["binding"] = "F4",
						["action"] = "Flametongue Weapon",
					},
					[4] = {
						["binding"] = "F3",
						["action"] = "Frostbrand Weapon",
					},
					[6] = {
						["binding"] = "F1",
						["action"] = "Windfury Weapon",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 49,
				["x"] = -44,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "CTRL-1",
						["action"] = "Windfury Totem",
					},
					[1] = {
						["binding"] = "CTRL-5",
						["action"] = "Stoneclaw Totem",
					},
					[2] = {
						["binding"] = "CTRL-4",
						["action"] = "Stoneskin Totem",
					},
					[3] = {
						["binding"] = "CTRL-3",
						["action"] = "Strength of Earth Totem",
					},
					[4] = {
						["binding"] = "CTRL-2",
						["action"] = "Grace of Air Totem",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 4,
				["x"] = -12,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-6",
						["action"] = "Poison Cleansing Totem",
					},
					[1] = {
						["binding"] = "ALT-3",
						["action"] = "Healing Stream Totem",
					},
					[7] = {
						["binding"] = "ALT-4",
						["action"] = "Disease Cleansing Totem",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Mana Spring Totem",
					},
					[3] = {
						["binding"] = "ALT-1",
						["action"] = "Grounding Totem",
					},
					[4] = {
						["binding"] = "ALT-7",
					},
					[6] = {
						["binding"] = "ALT-5",
						["action"] = "Tremor Totem",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 2,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 6,
				["x"] = -15,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar6",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 7,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "Z",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
						["binding"] = "X",
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 11,
				["x"] = 12,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "`",
						["action"] = "Ghost Wolf",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = 0,
				["x"] = 7,
				["to"] = "RIGHT",
				["frame"] = "BActionBar2",
				["point"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "7",
						["action"] = "Purge",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = 8,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[11] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "F",
						["action"] = "Lightning Shield",
					},
				},
			},
			["buttonSize"] = 34,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar11",
			["anchor"] = {
				["y"] = 4,
				["x"] = 12,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["scale"] = 0.8,
			["anchor"] = {
				["y"] = 552,
				["x"] = 20,
				["to"] = "BOTTOMLEFT",
				["frame"] = "UIParent",
				["point"] = "BOTTOMLEFT",
			},
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["scale"] = 0.8,
			["anchor"] = {
				["y"] = 600,
				["x"] = 20,
				["to"] = "BOTTOMLEFT",
				["frame"] = "UIParent",
				["point"] = "BOTTOMLEFT",
			},
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
	},
	["PaladinMazzle_16"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "1",
						["action"] = "Flash of Light",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Holy Light",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = "Attack",
					},
					[2] = {
						["action"] = "Hammer of Justice",
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 5,
				["x"] = 20,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 2,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "7",
					},
					[1] = {
						["binding"] = "3",
						["action"] = "Cleanse",
					},
					[2] = {
						["binding"] = "4",
						["action"] = "Purify",
					},
					[3] = {
						["binding"] = "5",
						["action"] = "Lay on Hands",
					},
					[4] = {
						["binding"] = "6",
						["action"] = "Divine Intervention",
					},
					[6] = {
						["binding"] = "8",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Holy Wrath",
					},
					[1] = {
						["action"] = "Hammer of Wrath",
					},
					[2] = {
						["action"] = {
							[2] = "Holy Shock",
							[1] = "Consecration",
							[3] = "Repentance",
						},
					},
					[3] = {
						["action"] = {
							[1] = "Repentance",
							[2] = "Holy Shock",
						},
					},
					[4] = {
						["action"] = "Exorcism",
					},
					[6] = {
						["action"] = "Turn Undead",
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = {
							[1] = "Repentance",
							[2] = "Holy Shock",
						},
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Attack",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Hammer of Justice",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Hammer of Wrath",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = {
							[2] = "Holy Shock",
							[1] = "Consecration",
							[3] = "Repentance",
						},
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Lay on Hands",
					},
					[1] = {
						["action"] = "Flash of Light",
					},
					[2] = {
						["action"] = "Holy Light",
					},
					[3] = {
						["action"] = "Cleanse",
					},
					[4] = {
						["action"] = "Purify",
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = -40,
				["x"] = 20,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 5,
			["pages"] = 2,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "ALT-7",
						["action"] = "Holy Wrath",
					},
					[1] = {
						["binding"] = "ALT-6",
						["action"] = "Exorcism",
					},
					[3] = {
						["binding"] = "ALT-8",
						["action"] = "Turn Undead",
					},
				},
				["page_2"] = {
					[2] = {
					},
					[1] = {
						["action"] = "Divine Intervention",
					},
					[3] = {
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 3,
			["pages"] = 2,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "SHIFT-5",
						["action"] = "Seal of Light",
					},
					[1] = {
						["binding"] = "SHIFT-1",
						["action"] = "Seal of Righteousness",
					},
					[2] = {
						["binding"] = "SHIFT-2",
						["action"] = "Seal of the Crusader",
					},
					[3] = {
						["binding"] = "SHIFT-3",
						["action"] = "Seal of Justice",
					},
					[4] = {
						["binding"] = "SHIFT-4",
						["action"] = "Seal of Wisdom",
					},
					[6] = {
						["binding"] = "SHIFT-6",
						["action"] = "Seal of Command",
					},
				},
			},
			["buttonSize"] = 32,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = -7,
				["x"] = -50,
				["point"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "T",
					},
					[1] = {
						["binding"] = "Z",
						["action"] = "Divine Shield",
					},
					[2] = {
						["binding"] = "X",
						["action"] = "Divine Protection",
					},
					[3] = {
						["binding"] = "C",
						["action"] = "Righteous Fury",
					},
					[4] = {
						["binding"] = "V",
						["action"] = "Holy Shield",
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar10",
				["to"] = "LEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_3"] = {
					[5] = {
					},
					[1] = {
						["action"] = "Blessing of Sanctuary",
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[6] = {
					},
				},
				["page_1"] = {
					[5] = {
						["binding"] = "CTRL-5",
						["action"] = "Blessing of Freedom",
					},
					[1] = {
						["binding"] = "CTRL-1",
						["action"] = "Blessing of Wisdom",
					},
					[2] = {
						["binding"] = "CTRL-2",
						["action"] = "Blessing of Salvation",
					},
					[3] = {
						["binding"] = "CTRL-3",
						["action"] = "Blessing of Might",
					},
					[4] = {
						["binding"] = "CTRL-4",
						["action"] = "Blessing of Kings",
					},
					[6] = {
						["binding"] = "CTRL-6",
						["action"] = "Blessing of Protection",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Blessing of Light",
					},
					[1] = {
						["action"] = "Greater Blessing of Wisdom",
					},
					[2] = {
						["action"] = "Greater Blessing of Salvation",
					},
					[3] = {
						["action"] = "Greater Blessing of Might",
					},
					[4] = {
						["action"] = "Greater Blessing of Kings",
					},
					[6] = {
						["action"] = "Greater Blessing of Light",
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 3,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = -268,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 6,
			["pages"] = 3,
		},
		[8] = {
			["numButtons"] = 4,
			["contents"] = {
				["page_1"] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
				},
			},
			["buttonSize"] = 38,
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar9",
				["to"] = "LEFT",
			},
			["rows"] = 1,
			["pages"] = 1,
			["name"] = "BActionBar8",
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "G",
						["action"] = "Judgement",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 5,
				["x"] = -20,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = "Redemption",
					},
					[2] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[3] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 38,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = -40,
				["x"] = -20,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = 14,
				["x"] = -5,
				["to"] = "TOPLEFT",
				["frame"] = "ChatFrame6",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -4,
				["x"] = 43,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["ShamanMazzle_16"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "2",
						["action"] = "Lightning Bolt",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Attack",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Chain Lightning",
					},
				},
				["page_2"] = {
					[2] = {
						["action"] = "Lesser Healing Wave",
					},
					[1] = {
						["action"] = "Healing Wave",
					},
					[3] = {
						["action"] = "Chain Heal",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = -7,
				["x"] = 45,
				["point"] = "TOPLEFT",
				["frame"] = "Minimap",
				["to"] = "TOPRIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 3,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-7",
						["action"] = "Nature's Swiftness",
					},
					[1] = {
						["binding"] = "4",
						["action"] = "Earth Shock",
					},
					[2] = {
						["binding"] = "5",
						["action"] = "Flame Shock",
					},
					[3] = {
						["binding"] = "6",
						["action"] = "Frost Shock",
					},
					[4] = {
						["binding"] = "7",
						["action"] = {
							[1] = "Elemental Mastery",
							[2] = "Stormstrike",
						},
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = {
							[1] = "Elemental Mastery",
							[2] = "Stormstrike",
						},
					},
					[1] = {
						["action"] = "Cure Disease",
					},
					[2] = {
						["action"] = "Cure Poison",
					},
					[3] = {
						["action"] = "Ancestral Spirit",
					},
					[4] = {
						["action"] = "Nature's Swiftness",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 5,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Lesser Healing Wave",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Healing Wave",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Chain Heal",
					},
				},
				["page_2"] = {
					[2] = {
						["action"] = "Lightning Bolt",
					},
					[1] = {
						["action"] = "Attack",
					},
					[3] = {
						["action"] = "Chain Lightning",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = -9,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 3,
			["pages"] = 2,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "ALT-5",
						["action"] = "Cure Poison",
					},
					[1] = {
						["binding"] = "ALT-4",
						["action"] = "Cure Disease",
					},
					[3] = {
						["binding"] = "ALT-6",
						["action"] = "Ancestral Spirit",
					},
				},
				["page_2"] = {
					[2] = {
						["action"] = "Flame Shock",
					},
					[1] = {
						["action"] = "Earth Shock",
					},
					[3] = {
						["action"] = "Frost Shock",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar3",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 3,
			["pages"] = 2,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "Z",
						["action"] = "Ghost Wolf",
					},
					[2] = {
						["action"] = "Lightning Shield",
					},
					[3] = {
						["action"] = "Water Breathing",
					},
					[4] = {
						["action"] = "Water Walking",
					},
					[5] = {
						["action"] = "Flametongue Weapon",
					},
					[6] = {
						["action"] = "Frostbrand Weapon",
					},
					[7] = {
						["action"] = "Rockbiter Weapon",
					},
					[8] = {
						["action"] = "Windfury Weapon",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "BOTTOMLEFT",
				["frame"] = "BActionBar9",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 8,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[6] = {
						["binding"] = "T",
						["action"] = "Mana Tide Totem",
					},
					[1] = {
						["binding"] = "SHIFT-F1",
						["action"] = "Windwall Totem",
					},
					[3] = {
						["binding"] = "SHIFT-F3",
						["action"] = "Stoneskin Totem",
					},
					[7] = {
						["binding"] = "SHIFT-F6",
						["action"] = "Fire Resistance Totem",
					},
					[8] = {
						["binding"] = "SHIFT-F7",
						["action"] = "Nature Resistance Totem",
					},
					[4] = {
						["binding"] = "SHIFT-F4",
						["action"] = "Stoneclaw Totem",
					},
					[9] = {
						["binding"] = "SHIFT-F8",
						["action"] = "Frost Resistance Totem",
					},
					[2] = {
						["binding"] = "SHIFT-F2",
						["action"] = "Tranquil Air Totem",
					},
					[5] = {
						["binding"] = "SHIFT-F5",
						["action"] = "Sentry Totem",
					},
					[11] = {
						["binding"] = "SHIFT-F10",
						["action"] = "Strength of Earth Totem",
					},
					[10] = {
						["binding"] = "SHIFT-F9",
						["action"] = "Grace of Air Totem",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 2,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 13,
				["x"] = -17,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 11,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "CTRL-5",
						["action"] = "Searing Totem",
					},
					[1] = {
						["binding"] = "CTRL-1",
						["action"] = "Earthbind Totem",
					},
					[2] = {
						["binding"] = "CTRL-2",
						["action"] = "Flametongue Totem",
					},
					[3] = {
						["binding"] = "CTRL-3",
						["action"] = "Fire Nova Totem",
					},
					[4] = {
						["binding"] = "CTRL-4",
						["action"] = "Magma Totem",
					},
					[6] = {
						["binding"] = "CTRL-6",
						["action"] = "Windfury Totem",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = -7,
				["x"] = -50,
				["point"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-F",
						["action"] = "Tremor Totem",
					},
					[1] = {
						["binding"] = "G",
						["action"] = "Healing Stream Totem",
					},
					[2] = {
						["binding"] = "V",
						["action"] = "Mana Spring Totem",
					},
					[3] = {
						["binding"] = "ALT-C",
						["action"] = "Poison Cleansing Totem",
					},
					[4] = {
						["binding"] = "ALT-D",
						["action"] = "Disease Cleansing Totem",
					},
					[6] = {
						["binding"] = "X",
						["action"] = "Grounding Totem",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 2,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = -11,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar6",
				["to"] = "TOPLEFT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "R",
						["action"] = "Purge",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["to"] = "LEFT",
				["frame"] = "BActionBar7",
				["point"] = "RIGHT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-V",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = 8,
				["x"] = 17,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -6,
				["x"] = 18,
				["to"] = "BOTTOMRIGHT",
				["frame"] = "ChatFrame1",
				["point"] = "BOTTOMLEFT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = 14,
				["x"] = -5,
				["to"] = "TOPLEFT",
				["frame"] = "ChatFrame6",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
	["PriestMazzle_133"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "5",
						["action"] = "Prayer of Healing",
					},
					[1] = {
						["binding"] = "1",
						["action"] = "Renew",
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Flash Heal",
					},
					[3] = {
						["binding"] = "3",
						["action"] = {
							[1] = "Heal",
							[2] = "Lesser Heal",
						},
					},
					[4] = {
						["binding"] = "4",
						["action"] = {
							[1] = "Greater Heal",
							[2] = "Heal",
						},
					},
					[6] = {
						["binding"] = "6",
						["action"] = {
							[1] = "Desperate Prayer",
							[2] = "Hex of Weakness",
							[3] = "Starshards",
							[4] = "Devouring Plague",
						},
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Mind Flay",
					},
					[1] = {
						["action"] = "Shadow Word: Pain",
					},
					[2] = {
						["action"] = "Mind Blast",
					},
					[3] = {
						["action"] = "Smite",
					},
					[4] = {
						["action"] = "Mana Burn",
					},
					[6] = {
						["action"] = {
							[1] = "Desperate Prayer",
							[2] = "Hex of Weakness",
							[3] = "Starshards",
							[4] = "Devouring Plague",
						},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 5,
				["x"] = 15,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Mind Flay",
					},
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Shadow Word: Pain",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Mind Blast",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Smite",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Mana Burn",
					},
					[6] = {
						["binding"] = "G",
						["action"] = "Holy Nova",
					},
				},
				["page_2"] = {
					[5] = {
						["action"] = "Prayer of Healing",
					},
					[1] = {
						["action"] = "Renew",
					},
					[2] = {
						["action"] = "Flash Heal",
					},
					[3] = {
						["action"] = {
							[1] = "Heal",
							[2] = "Lesser Heal",
						},
					},
					[4] = {
						["action"] = {
							[1] = "Greater Heal",
							[2] = "Heal",
						},
					},
					[6] = {
						["action"] = "Holy Nova",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = 12,
				["x"] = 16,
				["point"] = "BOTTOMLEFT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMRIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 6,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "Z",
						["action"] = "Power Word: Shield",
					},
					[2] = {
						["binding"] = "SHIFT-Z",
						["action"] = {
							[5] = "Touch of Weakness",
							[1] = "Fear Ward",
							[2] = "Feedback",
							[3] = "Shadowguard",
							[4] = "Elune's Grace",
						},
					},
					[3] = {
						["binding"] = "CTRL-1",
						["action"] = "Divine Spirit",
					},
					[4] = {
						["binding"] = "CTRL-SHIFT-1",
						["action"] = "Prayer of Spirit",
					},
					[5] = {
						["binding"] = "CTRL-2",
						["action"] = "Shadow Protection",
					},
					[6] = {
						["binding"] = "CTRL-SHIFT-2",
						["action"] = "Prayer of Shadow Protection",
					},
					[7] = {
						["binding"] = "CTRL-3",
						["action"] = "Power Word: Fortitude",
					},
					[8] = {
						["binding"] = "CTRL-4",
						["action"] = "Prayer of Fortitude",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = 5,
				["x"] = -15,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 8,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["binding"] = "V",
						["action"] = "Psychic Scream",
					},
					[1] = {
						["binding"] = "ALT-V",
						["action"] = "Shackle Undead",
					},
					[2] = {
						["binding"] = "SHIFT-V",
						["action"] = "Mind Control",
					},
					[3] = {
						["binding"] = "CTRL-V",
						["action"] = "Mind Vision",
					},
					[4] = {
						["binding"] = "ALT-S",
						["action"] = "Mind Soothe",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 12,
				["x"] = -16,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "Minimap",
				["to"] = "BOTTOMLEFT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "SHIFT-D",
						["action"] = "Dispel Magic",
					},
					[2] = {
						["binding"] = "ALT-D",
						["action"] = {
							[1] = "Abolish Disease",
							[2] = "Cure Disease",
						},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar3",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = ";",
						["action"] = "Levitate",
					},
					[2] = {
						["binding"] = "ALT-C",
						["action"] = "Inner Fire",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 0,
				["x"] = -11,
				["point"] = "RIGHT",
				["frame"] = "BActionBar4",
				["to"] = "LEFT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "X",
						["action"] = "Fade",
					},
					[2] = {
						["binding"] = "`",
						["action"] = "Inner Focus",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = 0,
				["x"] = 7,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[2] = {
						["binding"] = "T",
						["action"] = "Vampiric Embrace",
					},
					[1] = {
						["binding"] = "R",
						["action"] = {
							[2] = "Power Infusion",
							[1] = "Shadowform",
							[3] = "Lightwell",
						},
					},
					[3] = {
						["binding"] = "SHIFT-1",
						["action"] = "Silence",
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "BOTTOMLEFT",
				["frame"] = "BActionBar2",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 3,
			["pages"] = 1,
		},
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = 0,
				["x"] = 6,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar7",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "CTRL-R",
						["action"] = "Resurrection",
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar6",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		[11] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = {
							[2] = "item�Brilliant Mana Oil�20748�",
							[1] = "item�Brilliant Wizard Oil�20749�",
							[3] = "item�Wizard Oil�20750�",
						},
					},
				},
			},
			["buttonSize"] = 35,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar11",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar10",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -5,
				["x"] = -50,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 1,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -10,
				["x"] = 57,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 0,
		},
	},
	["MageMazzle_133"] = {
		[1] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "1",
						["action"] = {
							[1] = "Polymorph: Turtle",
							[2] = "Polymorph: Pig",
							[3] = "Polymorph",
						},
					},
					[2] = {
						["binding"] = "2",
						["action"] = "Scorch",
					},
					[3] = {
						["binding"] = "3",
						["action"] = "Fireball",
					},
					[4] = {
						["binding"] = "4",
						["action"] = "Fire Blast",
					},
					[5] = {
						["binding"] = "5",
						["action"] = "Pyroblast",
					},
				},
				["page_2"] = {
					[1] = {
						["action"] = {
							[1] = "Polymorph: Turtle",
							[2] = "Polymorph: Pig",
							[3] = "Polymorph",
						},
					},
					[2] = {
						["action"] = "Arcane Missiles",
					},
					[3] = {
						["action"] = "Frostbolt",
					},
					[4] = {
						["action"] = "Blizzard",
					},
					[5] = {
						["action"] = "Flamestrike",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar1",
			["anchor"] = {
				["y"] = 0,
				["x"] = 13,
				["point"] = "LEFT",
				["frame"] = "BActionBar6",
				["to"] = "RIGHT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 5,
			["pages"] = 2,
		},
		[2] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-1",
						["action"] = "Detect Magic",
					},
					[2] = {
						["binding"] = "ALT-2",
						["action"] = "Arcane Missiles",
					},
					[3] = {
						["binding"] = "ALT-3",
						["action"] = "Frostbolt",
					},
					[4] = {
						["binding"] = "ALT-4",
						["action"] = "Blizzard",
					},
					[5] = {
						["binding"] = "ALT-5",
						["action"] = "Flamestrike",
					},

				},
				["page_2"] = {
					[1] = {
						["action"] = "Detect Magic",
					},
					[2] = {
						["action"] = "Scorch",
					},
					[3] = {
						["action"] = "Fireball",
					},
					[4] = {
						["action"] = "Fire Blast",
					},
					[5] = {
						["action"] = "Pyroblast",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar2",
			["anchor"] = {
				["y"] = -10,
				["x"] = 0,
				["point"] = "TOPLEFT",
				["frame"] = "BActionBar1",
				["to"] = "BOTTOMLEFT",
			},
			["allowDuplicates"] = true,
			["numButtons"] = 5,
			["pages"] = 2,
		},
		[3] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "Z",
						["action"] = "Frost Nova�1",
					},
					[2] = {
						["binding"] = "V",
						["action"] = "Cone of Cold",
					},
					[3] = {
						["binding"] = "G",
						["action"] = "Arcane Explosion",
					},
					[4] = {
						["binding"] = "R",
						["action"] = "Blast Wave",
					},
					[5] = {
						["binding"] = "T",
						["action"] = "Dragon's Breath",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 3,
			["hideEmpty"] = 1,
			["name"] = "BActionBar3",
			["anchor"] = {
				["y"] = -6,
				["x"] = 10,
				["point"] = "LEFT",
				["frame"] = "BActionBar1",
				["to"] = "RIGHT",
			},
			["numButtons"] = 5,
			["pages"] = 1,
		},
		[4] = {
			["contents"] = {
				["page_1"] = {
					[3] = {
						["binding"] = "Y",
						["action"] = "Cold Snap",
					},
					[4] = {
						["binding"] = "F2",
						["action"] = "Frost Ward",
					},
					[5] = {
						["binding"] = "F3",
						["action"] = "Mana Shield",
					},
					[6] = {
						["binding"] = "F4",
						["action"] = "Fire Ward",
					},
					[1] = {
						["binding"] = "ALT-X",
						["action"] = "Ice Barrier",
					},
					[2] = {
						["binding"] = "X",
						["action"] = "Ice Block",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar4",
			["anchor"] = {
				["y"] = 6,
				["x"] = -22,
				["point"] = "RIGHT",
				["frame"] = "Minimap",
				["to"] = "LEFT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[5] = {
			["contents"] = {
				["page_1"] = {
					[5] = {
						["action"] = "Arcane Brilliance",
					},
					[1] = {
						["binding"] = ";",
						["action"] = "Slow Fall",
					},
					[2] = {
						["action"] = "Arcane Intellect",
					},
					[3] = {
						["action"] = "Dampen Magic",
					},
					[4] = {
						["action"] = "Amplify Magic",
					},
					[6] = {
						["binding"] = "ALT-D",
						["action"] = "Remove Lesser Curse",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar5",
			["anchor"] = {
				["y"] = -10,
				["x"] = 0,
				["point"] = "TOPRIGHT",
				["frame"] = "BActionBar4",
				["to"] = "BOTTOMRIGHT",
			},
			["numButtons"] = 6,
			["pages"] = 1,
		},
		[6] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "`",
						["action"] = "Blink",
					},
					[2] = {
						["binding"] = "SHIFT-1",
						["action"] = "Counterspell",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar6",
			["anchor"] = {
				["y"] = 6,
				["x"] = 22,
				["point"] = "LEFT",
				["frame"] = "Minimap",
				["to"] = "RIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[7] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "C",
						["action"] = {
							[1] = "Combustion",
							[2] = "Arcane Power",
						},
					},
					[2] = {
						["binding"] = "ALT-V",
						["action"] = "Presence of Mind",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = 1,
			["name"] = "BActionBar7",
			["anchor"] = {
				["y"] = -10,
				["x"] = 0,
				["point"] = "TOP",
				["frame"] = "BActionBar6",
				["to"] = "BOTTOM",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[8] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "ALT-`",
						["action"] = {
							[1] = "Stoneform",
							[2] = "Escape Artist",
							[3] = "Shadowmeld",
							[4] = "Berserking",
							[5] = "Will of the Forsaken",
							[6] = "Blood Fury",
							[7] = "Perception",
							[8] = "War Stomp", 
							[9] = "Mana Tap", 
							[10] = "Gift of the Naaru",
						},
					},
					[2] = {
                    	["action"] = {
                    		[1] = "Cannibalize",
                    		[2] = "Arcane Torrent",
                    	},
					},
				},
			},
			["buttonSize"] = 36,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar8",
			["anchor"] = {
				["y"] = 6,
				["x"] = 0,
				["point"] = "BOTTOMRIGHT",
				["frame"] = "BActionBar1",
				["to"] = "TOPRIGHT",
			},
			["numButtons"] = 2,
			["pages"] = 1,
		},
		[10] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["binding"] = "'",
						["action"] = "Evocation",
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar10",
			["anchor"] = {
				["y"] = 1,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar4",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["keybar"] = {["anchor"] = {["y"] = 0,["x"] = -2,["point"] = "RIGHT",["frame"] = "BBagBar",["to"] = "LEFT",},["name"] = "BKeyBar",},		
		[9] = {
			["contents"] = {
				["page_1"] = {
					[1] = {
						["action"] = {
							[2] = "item�Brilliant Mana Oil�20748�",
							[1] = "item�Brilliant Wizard Oil�20749�",
							[3] = "item�Wizard Oil�20750�",
						},
					},
				},
			},
			["buttonSize"] = 37,
			["rows"] = 1,
			["hideEmpty"] = true,
			["name"] = "BActionBar9",
			["anchor"] = {
				["y"] = 0,
				["x"] = -13,
				["point"] = "RIGHT",
				["frame"] = "BActionBar5",
				["to"] = "LEFT",
			},
			["numButtons"] = 1,
			["pages"] = 1,
		},
		["menubar"] = { ["scale"] = 0.9800000190734863, ["anchor"] = { ["y"] = 237, ["x"] = -77, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT", }, ["name"] = "BMenuBar", },
		["petbar"] = {
			["name"] = "BPetBar",
			["anchor"] = {
				["y"] = -6,
				["x"] = -45,
				["to"] = "TOPLEFT",
				["frame"] = "Minimap",
				["point"] = "TOPRIGHT",
			},
			["scale"] = 0.94,
			["layout"] = 1,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["classbar"] = {
			["name"] = "BClassBar",
			["anchor"] = {
				["y"] = -10,
				["x"] = 60,
				["to"] = "TOPRIGHT",
				["frame"] = "Minimap",
				["point"] = "TOPLEFT",
			},
			["scale"] = 0.8,
			["layout"] = 4,
			["vspacing"] = 0,
			["hspacing"] = 4,
		},
		["bagbar"] = {["anchor"] = {["y"] = 0,["x"] = -4,["point"] = "BOTTOMRIGHT",["frame"] = "BMenuBar",["to"] = "TOPRIGHT",},["space"] = 2,["scale"] = 0.9800000190734863,["name"] = "BBagBar",},	},
}
