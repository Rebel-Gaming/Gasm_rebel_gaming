-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

Mazzifier = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0", "AceDB-2.0", "AceEvent-2.0")
local L = AceLibrary("AceLocale-2.2"):new("Mazzifier")
local BClass = AceLibrary("Babble-Class-2.2")

MazzifierAnimDB = {
    ["Wave"] = {
        ["textureObject"] = nil,
        ["nextAnim"] = "Wave2", },
    ["Wave2"] = {
        ["textureObject"] = nil,
        ["nextAnim"] = "Wave3", },
    ["Wave3"] = {
        ["textureObject"] = nil,
        ["nextAnim"] = "Wave", },
    ["Cast"] = {
        ["textureObject"] = nil,
        ["nextAnim"] = nil, },
    ["Cast2"] = {
        ["textureObject"] = nil,
        ["nextAnim"] = nil, },
}

function Mazzifier:OnLoad()
	this:RegisterEvent("ADDON_LOADED");
end

function Mazzifier:OnEvent(event)
	if (event=="ADDON_LOADED" and arg1=="Mazzifier") then
    	MazzleTex0:SetTexture("Interface\\AddOns\\Mazzifier\\images\\MazzRight")
        MazzleTex1:SetTexture("Interface\\AddOns\\Mazzifier\\images\\Wave1")
        MazzleTex2:SetTexture("Interface\\AddOns\\Mazzifier\\images\\Wave2")
        MazzleTex3:SetTexture("Interface\\AddOns\\Mazzifier\\images\\Wave3")
        MazzleTex4:SetTexture("Interface\\AddOns\\Mazzifier\\images\\Cast1")
        MazzleTex5:SetTexture("Interface\\AddOns\\Mazzifier\\images\\Cast2")
        MazzifierAnimDB["Wave"].textureObject = MazzleTexFrame1
        MazzifierAnimDB["Wave2"].textureObject = MazzleTexFrame2
        MazzifierAnimDB["Wave3"].textureObject = MazzleTexFrame3
        MazzifierAnimDB["Cast"].textureObject = MazzleTexFrame4
        MazzifierAnimDB["Cast2"].textureObject = MazzleTexFrame5
    	MazzleTexFrame0:Show()
        MazzleTexFrame1:Hide()
        MazzleTexFrame2:Hide()
        MazzleTexFrame3:Hide()
        MazzleTexFrame4:Hide()
        MazzleTexFrame5:Hide()
		DEFAULT_CHAT_FRAME:AddMessage(Mazzifier_LOADED_MESSAGE,0.0,1.0,0.0);
	end
end

function Mazzifier:Schedule_Phase2()
    self:Print("self:Schedule_Phase2 called")
    self:ScheduleEvent(self.Phase2, 1.5, self, 1)
end

function Mazzifier:Show()
	MazzifierAnim = "Wave"
	if (GetCVar("uiScale") ~= "0.63999998569489") then SetCVar("uiScale", "0.63999998569489"); end;
	if (GetCVar("useUiScale") ~= "1") then SetCVar("useUiScale", "1"); end;
	Mazzifier_Frame:Show();
	self:ScheduleRepeatingEvent("Mazzifier_AnimTimer",self.Animate, 0.2, self)
    self:ScheduleEvent(self.ClearConfusingWindows, 1, self)
    self:ScheduleEvent(self.ClearConfusingWindows, 7, self)
    self:ScheduleEvent(self.ClearConfusingWindows, 14, self)
    self:ScheduleEvent(self.ClearConfusingWindows, 28, self)
    self:ScheduleEvent(PlaySoundFile, 3, "Sound\\Character\\Gnome\\GnomeVocalFemale\\GnomeFemaleHello02.wav")  
	self:GUI_CheckLoadedAddons()
	self:GUI_Initialize()
    Mazzifier_Button:Hide()
    Mazzifier_NextButton:Show()
	Mazzifier.createDFMAdjustments = DFM_INITIALIZED and (DFM_INDEX == "MazzleUI")
end

function Mazzifier:Hide()
	Mazzifier_Frame:Hide();
    Mazzifier_Progress = 2
	self:CancelScheduledEvent("Mazzifier_AnimTimer")
	self:CancelScheduledEvent("Mazzifier_ReloadColorTimer")
end

function Mazzifier:Animate()
    local nextAnim = nil
    if (MazzifierAnim) then
        for animName,animInfo in pairs(MazzifierAnimDB) do
            if (animName == MazzifierAnim) then
                animInfo.textureObject:Show()
                nextAnim = animInfo.nextAnim
             else
                animInfo.textureObject:Hide()
             end
        end
        MazzifierAnim = nextAnim
    end
end

function Mazzifier:ChangeChatSize(theChatFrame, theChatSize)
    local fontFile, unused, fontFlags = theChatFrame:GetFont();
    local frameID = theChatFrame:GetID()
    theChatFrame:SetFont(fontFile, theChatSize, fontFlags);
    SetChatWindowSize(frameID,theChatSize) 
end

function Mazzifier:ChangeAllChatSizes(sizeType)

    local sizeImportant, sizeSpam, sizeCombatLog
    if (sizeType == 2) then
        sizeImportant, sizeSpam, sizeCombatLog = 15, 14, 13
		if (ClearFont) then ClearFont:SetScale(1.15); end;
        FuBar:SetFontSize(14)
    elseif (sizeType == 3) then
        sizeImportant, sizeSpam, sizeCombatLog = 18, 16, 15
		if (ClearFont) then ClearFont:SetScale(1.3); end;
        FuBar:SetFontSize(15)
    else
        sizeImportant, sizeSpam, sizeCombatLog = 13, 12, 10
		if (ClearFont) then ClearFont:SetScale(1); end;
        FuBar:SetFontSize(13)
    end
        
    self:ChangeChatSize(ChatFrame1,sizeImportant) 
    self:ChangeChatSize(ChatFrame2,sizeImportant) 
    self:ChangeChatSize(ChatFrame3,sizeSpam) 
    self:ChangeChatSize(ChatFrame4,sizeSpam) 
    self:ChangeChatSize(ChatFrame5,sizeImportant) 
    self:ChangeChatSize(ChatFrame6,sizeCombatLog) 
    self:ChangeChatSize(ChatFrame7,sizeCombatLog)

end

function Mazzifier:Mazzify_ChatWindows()

    SetChatWindowShown(1,1) 
	SetChatWindowDocked(1,1)
	SetChatWindowColor(1,0,0,0)
	SetChatWindowAlpha(1,0) 
    SetChatWindowName(1,"General")
    SetChatWindowLocked(1,1) 

    SetChatWindowShown(2,1) 
	SetChatWindowDocked(2,2)
	SetChatWindowColor(2,0,0,0)
	SetChatWindowAlpha(2,0) 
    SetChatWindowName(2,"Private")
    SetChatWindowLocked(2,1) 

    SetChatWindowShown(3,1) 
	SetChatWindowDocked(3,3)
	SetChatWindowColor(3,0,0,0)
	SetChatWindowAlpha(3,0) 
    SetChatWindowName(3,"Trade")
    SetChatWindowLocked(3,1) 

    SetChatWindowShown(4,1) 
	SetChatWindowDocked(4,4)
	SetChatWindowColor(4,0,0,0)
	SetChatWindowAlpha(4,0) 
    SetChatWindowName(4,"Group")
    SetChatWindowLocked(4,1) 

    SetChatWindowShown(5,1) 
	SetChatWindowDocked(5,5)
	SetChatWindowColor(5,0,0,0)
	SetChatWindowAlpha(5,0) 
    SetChatWindowName(5,"Guild")
    SetChatWindowLocked(5,1) 

    SetChatWindowShown(6,1) 
	SetChatWindowDocked(6,0)
	SetChatWindowColor(6,0,0,0)
	SetChatWindowAlpha(6,1) 
    SetChatWindowName(6,"Dmg Out")
    SetChatWindowLocked(6,1) 

    SetChatWindowShown(7,1) 
	SetChatWindowDocked(7,0)
	SetChatWindowColor(7,0,0,0)
	SetChatWindowAlpha(7,1) 
    SetChatWindowName(7,"Combat Log")
    SetChatWindowLocked(7,1) 
    
    ChatFrame6:SetFrameLevel(3)
    ChatFrame7:SetFrameLevel(3)
    
end

function Mazzifier:Mazzify_ChatGroups()
    ChatFrame_RemoveChannel(ChatFrame1, "Trade")
    ChatFrame_RemoveChannel(ChatFrame1, "LocalDefense")
    ChatFrame_RemoveMessageGroup(ChatFrame1, "SKILL")
    ChatFrame_RemoveMessageGroup(ChatFrame1, "LOOT")
    ChatFrame_RemoveAllMessageGroups(ChatFrame2)
    ChatFrame_AddMessageGroup(ChatFrame2, "WHISPER")
    AddChatWindowChannel(3, "Trade") 
    ChatFrame_AddMessageGroup(ChatFrame4, "PARTY")
    ChatFrame_AddMessageGroup(ChatFrame5, "GUILD")
    ChatFrame_AddMessageGroup(ChatFrame7, "SKILL")
    ChatFrame_AddMessageGroup(ChatFrame7, "LOOT")
    ChangeChatColor("CHANNEL1", 0.88,0.49,0.47)
    ChangeChatColor("CHANNEL2", 1,0.8, 0.09)
    ChangeChatColor("CHANNEL3", 1,0.05,0.02)
    ChangeChatColor("CHANNEL4", 1,0.46,0)
    ChangeChatColor("CHANNEL5", 1,0,1)
    ChangeChatColor("CHANNEL6", 0,0,1)
    ChangeChatColor("CHANNEL10", 1,0.05,0.02)
    ChangeChatColor("YELL", 1,0,0)
    ChangeChatColor("GUILD", 0,1,0)
    ChangeChatColor("RAID_LEADER", 1,.15,0)
    ChangeChatColor("RAID_WARNING", 1,0,0)
    ChangeChatColor("BATTLEGROUND_LEADER", 1,.15,0)
end

function Mazzifier:EnableNeededAddOns()
    local loadable, reason
    for addonName,addonInfo in pairs(MazzleUI_AddOn_DB) do
        shouldEnable = true
        if (addonInfo.core and addonInfo.library) then
                EnableAddOn(addonName)
        end
    end
    for addonIndexName, addonInfo in pairs(Mazzifier_AddOnInfo) do
        if (not addonInfo.noRequirement) then
            _, _, _, _, loadable, _, _= GetAddOnInfo(addonIndexName)
            if (addonInfo.needsUpdate and (not loadable)) then
                Mazzifier:Print("Loading ", addonIndexName)
                EnableAddOn(addonIndexName)
            end
        end
    end
    Mazzifier_Progress = 0.5
end


function Mazzifier:Mazzify_AddonSettings()
    for theAddon,isEnabled in pairs(Mazzifier_CurrentInstallOptions.AddOnList) do
        if (isEnabled and Mazzifier["Mazzify_"..string.gsub(theAddon, "!", "")]) then
            self:Print("Mazzifying ", theAddon)
            Mazzifier["Mazzify_"..string.gsub(theAddon, "!", "")]()
        end
    end
end

function Mazzifier:Mazzify_AddonSelection()
    local function Able(a, s) if (s) then EnableAddOn(a); else DisableAddOn(a); end; end;
    local shouldEnable = false
    local disableText, enableText, disableCount, enableCount = "Disabling: ", "Enabling: ", 0, 0
    if (Mazzifier_CurrentInstallOptions.AddonExtras.corepackage == "mule") then
        for addonName,addonInfo in pairs(MazzleUI_AddOn_DB) do
            if (addonInfo.specialPackages and addonInfo.specialPackages.mule) then Able(addonName, true); else Able(addonName, false); end
        end
    else
        for addonName,addonInfo in pairs(MazzleUI_AddOn_DB) do
            shouldEnable = true
            if (addonInfo.core) then
                if (addonInfo.classes) then
                    if ((not Mazzifier_CurrentInstallOptions.AddonExtras.class) or (not addonInfo.classes[self:Capitalize(BClass:GetReverseTranslation(Mazzifier_PlayerClass))])) then shouldEnable = false end
                end
                if (addonInfo.raiding) then
                    if (not Mazzifier_CurrentInstallOptions.AddonExtras.raiding) then shouldEnable = false end
                end
                if (addonInfo.auctions) then
                    if (not Mazzifier_CurrentInstallOptions.AddonExtras.auctions) then shouldEnable = false end
                end
                if (addonInfo.pvp) then
                    if (not Mazzifier_CurrentInstallOptions.AddonExtras.pvp) then shouldEnable = false end
                end
                if (addonInfo.data) then
                    if (not Mazzifier_CurrentInstallOptions.AddonExtras.data) then shouldEnable = false end
                end
                if (addonInfo.alts) then
                    if (not Mazzifier_CurrentInstallOptions.AddonExtras.alts) then shouldEnable = false end
                end
                if (Mazzifier_CurrentInstallOptions.AddonExtras.corepackage and addonInfo.notInPackage and addonInfo.notInPackage[Mazzifier_CurrentInstallOptions.AddonExtras.corepackage]) then shouldEnable = false end;
                Able(addonName, shouldEnable)
            end
        end
    
        Able("Cartographer_Herbalism", (Mazzifier_CurrentInstallOptions.AddonExtras.mapnotes and Mazzifier_CurrentInstallOptions.AddonExtras.mapnodes and Mazzifier:ActionExists("Find Herbs")))
        Able("Cartographer_Mining", (Mazzifier_CurrentInstallOptions.AddonExtras.mapnotes and Mazzifier_CurrentInstallOptions.AddonExtras.mapnodes and Mazzifier:ActionExists("Find Minerals")))
        Able("Cartographer_Treasure", Mazzifier_CurrentInstallOptions.AddonExtras.mapnotes and Mazzifier_CurrentInstallOptions.AddonExtras.maptreasures)
        Able("Cartographer_Quests", Mazzifier_CurrentInstallOptions.AddonExtras.mapnotes and Mazzifier_CurrentInstallOptions.AddonExtras.mapquests)
        Able("Cartographer_Fishing", Mazzifier_CurrentInstallOptions.AddonExtras.mapnotes and Mazzifier_CurrentInstallOptions.AddonExtras.mapfish)
        Able("Cartographer_Trainers", Mazzifier_CurrentInstallOptions.AddonExtras.mapnotes and Mazzifier_CurrentInstallOptions.AddonExtras.mapvendors)
        Able("Cartographer_Vendors", Mazzifier_CurrentInstallOptions.AddonExtras.mapnotes and Mazzifier_CurrentInstallOptions.AddonExtras.mapvendors)
    
        Able("Antagonist", Mazzifier_CurrentInstallOptions.AddonExtras.timerbars)
        Able("Chronometer", Mazzifier_CurrentInstallOptions.AddonExtras.timerbars)
        Able("Hourglass", Mazzifier_CurrentInstallOptions.AddonExtras.timerbars)
    
        Able("LightHeaded", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
        Able("LightHeaded_Quest_Data", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
        Able("LightHeaded_A20_Data", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
        Able("LightHeaded_A40_Data", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
        Able("LightHeaded_A60_Data", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
        Able("LightHeaded_A80_Data", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
        Able("LightHeaded_H20_Data", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
        Able("LightHeaded_H40_Data", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
        Able("LightHeaded_H60_Data", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
        Able("LightHeaded_H80_Data", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
        Able("LightHeaded_NPC_Data", Mazzifier_CurrentInstallOptions.AddonExtras.wowhead)
    
        Able("Baggins", Mazzifier_CurrentInstallOptions.AddonExtras.onebag)
    
        Able("cyCircled", Mazzifier_CurrentInstallOptions.AddonExtras.circlebuttons)
 
        Able("KLHThreatMeter", Mazzifier_CurrentInstallOptions.AddonExtras.threatmeter and Mazzifier_CurrentInstallOptions.AddonExtras.klh)
        Able("FuBar_KTMFu", Mazzifier_CurrentInstallOptions.AddonExtras.threatmeter and Mazzifier_CurrentInstallOptions.AddonExtras.klh)
        Able("KTMCPUManager", Mazzifier_CurrentInstallOptions.AddonExtras.threatmeter and Mazzifier_CurrentInstallOptions.AddonExtras.klh)
        Able("Omen", Mazzifier_CurrentInstallOptions.AddonExtras.threatmeter and Mazzifier_CurrentInstallOptions.AddonExtras.omen)
        
        Able("Quartz", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Buff", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Flight", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Focus", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_GCD", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Interrupt", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Latency", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Mirror", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Player", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Range", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Swing", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Target", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Timer", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        Able("Quartz_Tradeskill", Mazzifier_CurrentInstallOptions.AddonExtras.quartz)
        
        Able("Recap", Mazzifier_CurrentInstallOptions.AddonExtras.damageheal and Mazzifier_CurrentInstallOptions.AddonExtras.recap)
        Able("Recount", Mazzifier_CurrentInstallOptions.AddonExtras.damageheal and Mazzifier_CurrentInstallOptions.AddonExtras.recount)    
        Able("SW_Stats", Mazzifier_CurrentInstallOptions.AddonExtras.damageheal and Mazzifier_CurrentInstallOptions.AddonExtras.sws)
        Able("SW_Stats_Profiles", Mazzifier_CurrentInstallOptions.AddonExtras.damageheal and Mazzifier_CurrentInstallOptions.AddonExtras.sws)
        Able("FuBar_SWStats2Fu", Mazzifier_CurrentInstallOptions.AddonExtras.damageheal and Mazzifier_CurrentInstallOptions.AddonExtras.sws)
        
        Able("BigWigs", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("BigWigs_BlackTemple", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("BigWigs_Extras", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("BigWigs_Hyjal", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("BigWigs_Karazhan", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("BigWigs_Outland", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("BigWigs_Plugins", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("BigWigs_SC", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("BigWigs_Sunwell", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("BigWigs_TheEye", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("BigWigs_ZulAman", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("LittleWigs", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("LittleWigs_Auchindoun", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("LittleWigs_Coilfang", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("LittleWigs_CoT", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("LittleWigs_HellfireCitadel", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("LittleWigs_MagistersTerrace", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("LittleWigs_TempestKeep", (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.bigwigs))
        Able("DBM_API", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm)
        Able("DBM_BlackTemple", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm)
        Able("DBM_Hyjal", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm)
        Able("DBM_ZulAman", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm)
        Able("DBM_Serpentshrine", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm)
        Able("DBM_TheEye", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm)
        Able("DBM_Battlegrounds", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm)
        Able("DBM_GUI", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm)
        Able("DBM_Karazhan", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm)
        Able("DBM_Other", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm)
        if (Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.dbm) then
            Able("Capping", false)
        end
        Able("XRS", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.xrs)
        Able("Decursive", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.decursive)
        Able("Incubator", Mazzifier_CurrentInstallOptions.AddonExtras.raidextras and Mazzifier_CurrentInstallOptions.AddonExtras.incubator)
        
        if (UnitLevel("player") == 70) then
            DisableAddOn("Fubar_ExperienceFu")
            self:Print("Disabling Fubar ExperienceFu for level 70 character "..Mazzifier_PlayerName)
        end
    end
    if (Mazzifier_CurrentInstallOptions.AddonExtras.namenone) then
        Able("Aloft", false)
        Able("TagCompiler-1.0", false)
        SetCVar("UnitNameOwn", "0")
	SetCVar("UnitNameFriendlyPlayerName","0")
	SetCVar("UnitNameEnemyPlayerName","0")
        SetCVar("UnitNamePlayerGuild", "0")
        SetCVar("UnitNamePlayerPVPTitle", "0")
        SetCVar("UnitNameNPC", "0")
        HideNameplates(); NAMEPLATES_ON = false;
        HideFriendNameplates(); FRIENDNAMEPLATES_ON = false;
    elseif (Mazzifier_CurrentInstallOptions.AddonExtras.nametags) then
        Able("Aloft", false)
        Able("TagCompiler-1.0", false)
        SetCVar("UnitNameOwn", "1")
	SetCVar("UnitNameFriendlyPlayerName","1")
	SetCVar("UnitNameEnemyPlayerName","1")
        SetCVar("UnitNamePlayerGuild", "1")
        SetCVar("UnitNamePlayerPVPTitle", "1")
        SetCVar("UnitNameNPC", "1")
        HideNameplates(); NAMEPLATES_ON = false
        HideFriendNameplates(); FRIENDNAMEPLATES_ON = false;
    elseif (Mazzifier_CurrentInstallOptions.AddonExtras.nameplates) then
        Able("Aloft", true)
        Able("TagCompiler-1.0", true)
        SetCVar("UnitNameOwn", "0")
	SetCVar("UnitNameFriendlyPlayerName","1")
	SetCVar("UnitNameEnemyPlayerName","1")
        SetCVar("UnitNamePlayerGuild", "1")
        SetCVar("UnitNamePlayerPVPTitle", "1")
        SetCVar("UnitNameNPC", "1")
        ShowNameplates(); NAMEPLATES_ON = 1; 
        ShowFriendNameplates(); FRIENDNAMEPLATES_ON = 1; 
    end
end

function Mazzifier:DisableConflicts()
    local shouldInstall = false
    for _,addonName in pairs(Mazzifier_ConflictAddOns) do
        DisableAddOn(addonName)
    end
end

function Mazzifier:Mazzify_Layout_UserPlaced(phase)
    MazzleUI:CreateHUD()
    --MazzleUI:Frames_ConfigureFrameList(MazzleUI.FrameInfo_Login[1])
    --MazzleUI:Frames_ConfigureFrameList(MazzleUI.FrameInfo_Login[2])
    MazzleUI:Frames_ConfigureFrameList(MazzleUI.FrameInfo_Placed[phase])

end

function Mazzifier:Mazzify_Layout()
    self:Mazzify_Layout_UserPlaced(1)
end

function Mazzifier:Mazzify_Buttons()

    local defaultLayoutNum = nil
    if (Mazzifier_CurrentInstallOptions and Mazzifier_CurrentInstallOptions.ButtonLayout) then
        for i=1, table.getn(Mazzifier_ButtonInfo), 1 do
            if (Mazzifier_CurrentInstallOptions.ButtonLayout.name == Mazzifier_ButtonInfo[i].devname) then
                defaultLayoutNum = i
            end
        end
    end
    if (not defaultLayoutNum) then
        defaultLayoutNum = Mazzifier_DefaultLayout[self:Capitalize(BClass:GetReverseTranslation(UnitClass("player")))]
    end
    
    Mazzifier:Setup_Bongos(defaultLayoutNum, Mazzifier_CurrentInstallOptions.Aspect, (not Mazzifier_CurrentInstallOptions.SAS))
    if (Mazzifier_ButtonInfo[defaultLayoutNum].bindingFunc) then
        Mazzifier[Mazzifier_ButtonInfo[defaultLayoutNum].bindingFunc]()
    end
    BBar.Hide(BBar.IDToBar("bags"), 1)
    BBar.Hide(BBar.IDToBar("menu"), 1)
    BBar.Hide(BBar.IDToBar("key"), 1)
end

function Mazzifier:PhaseBegin()
    
    -- Play spell cast sound
    MazzifierAnim = "Cast"
    self:Animate()
	self:ScheduleEvent(self.Phase0, 1.5, self)

end

function Mazzifier:ClearConfusingWindows()
    --if ((not Mazzifier_LastInstalledVersion) or (Mazzifier_LastInstalledVersion == 0.0)) then
       -- self:Print("Mazzifier pre-phase started.")
        for _,hideWin in pairs({ SmartBuffOptionsFrame, BongosOptions, SmartDebuffIF, nQuestLogFrame, StaticPopup1, SAListTitleButton,}) do
        	if (hideWin) then HideUIPanel(hideWin) end
        end
        if (RecapFrame and RecapFrame:IsVisible()) then
            RecapFrame_Toggle();
        end
    --end        
end

function Mazzifier:Mazzify_SpecialVersionChanges()
    if (Mazzifier_LastInstalledVersion < 0.60) then
        if (MazzleUI_Settings) then
            MazzleUI_LastRaidView = 1
        	MazzleUI_Settings.AutoSwapRaid20 = true
            MazzleUI_Settings.RaidLayout40 = 1
        end
    elseif (Mazzifier_LastInstalledVersion < 0.96) then
        if (MazzleUI_Settings) then
            MazzleUI_Settings.AutoOpenBags = true
            MazzleUI_Settings.Performance_Enabled.combat = false
        	MazzleUI_Settings.Performance_BigWigs = { noManual = true, manual = true, party = false, combat = true, raid = true, solo = false, pvp = false,}
        	MazzleUI_Settings.Performance_Discord = { canCombat = true, manual = false, party = true, combat = true, raid = false, solo = true, pvp = true,}
        	MazzleUI_Settings.Performance_Enabled = { manual = false, party = true, combat = false, raid = true, solo = true, pvp = true,}
        	MazzleUI_Settings.Performance_Gfx = { manual = false, party = true, combat = true, raid = true, solo = true, pvp = true,}
        	MazzleUI_Settings.Performance_Models = { canCombat = true, manual = false, party = true, combat = true, raid = true, solo = true, pvp = true,}
        	MazzleUI_Settings.Performance_Recap = { manual = false, party = true, combat = true, raid = true, solo = true, pvp = false,}
        	MazzleUI_Settings.Performance_SWS = { manual = false, party = true, solo = false, raid = true, combat = true, pvp = false,}
        	MazzleUI_Settings.Performance_SCT = { manual = false, party = true, combat = true, raid = true, solo = true, pvp = true,}
        	MazzleUI_Settings.Performance_SCTD = { manual = false, party = true, solo = true, raid = true, combat = true, pvp = true,}
        	MazzleUI_Settings.Performance_SpellAlert = { manual = false, party = true, solo = true, raid = true, combat = true, pvp = true,}
        	MazzleUI_Settings.Performance_HUDRange = { canCombat = true, manual = false, party = true, solo = true, raid = true, combat = true, pvp = true,}
        	MazzleUI_Settings.Performance_SpellEffects = { canCombat = true, manual = false, party = true, solo = true, raid = true, combat = true, pvp =true,}
        end
    end
    MazzleUI_Settings.debugPrint = false
end

function Mazzifier:Phase0()
    Mazzifier_WelcomeFrameText:SetText(Mazzifier_MazzifyText)
    PlaySoundFile("Sound\\Spells\\ShaysBell.wav");
    PlaySoundFile("Sound\\Spells\\Vanish.wav");
    MazzifierAnim = "Cast2"
    self:Animate()
	self:ScheduleEvent(self.Phase1, 1, self)
end
    
function Mazzifier:Phase1(callnum)
    self:Print("Phase 1 initiated")
    local shouldReload = nil
    local lastProfile

    if (not MazzleUI:GetValue("MazzleUI_Status.skin")) then 
        MazzleUI:SetValue("MazzleUI_Status.skin", {}); 
        MazzleUI:LoadSkin(""); 
    else
        MazzleUI:LoadSkin(MazzleUI_Settings.Skin); 
    end;
    MazzleUI:Frames_ConfigureMinimap()
    if (not MazzleUI_LastAspect) then 
        MazzleUI:CreatePanel(Mazzifier_CurrentInstallOptions.Aspect) 
    else 
        MazzleUI:CreatePanel(MazzleUI_LastAspect); 
    end;
    MazzleUI:Frames_ConfigureFrameList(MazzleUI.FrameInfo_Login[1])

    if (Mazzifier_CurrentInstallOptions.Layout) then
        self:Print("Phase 1: Configuring chat windows and joining chat groups")
        MazzleUI_LastAspect = Mazzifier_CurrentInstallOptions.Aspect
        self:Mazzify_ChatWindows()
        self:Mazzify_ChatGroups()
    end

    if ( Mazzifier_CurrentInstallOptions.FontSize ~= Mazzifier_C_InstalledVersionDB.FontSize) then
        self:Print("Phase 1: Fonts")
        self:ChangeAllChatSizes(Mazzifier_CurrentInstallOptions.FontSize)
        shouldReload = true
    end
    if (Mazzifier_CurrentInstallOptions.Addons) then
        self:Print("Phase 1: Mazzifying add-on settings")
        self:Mazzify_AddonSettings()
        shouldReload = true
    end
    if (Mazzifier_CurrentInstallOptions.AddonSelection) then
        self:Print("Phase 1: Enabling and disabling add-ons")
        self:Mazzify_AddonSelection()
        self:DisableConflicts()
        shouldReload = true
    end
    if (Mazzifier_CurrentInstallOptions.Layout) then
        self:Print("Phase 1: Configuring window positioning and skin.")
        Mazzifier_Progress = 1
        self:Mazzify_Layout()
        shouldReload = true
        if ( Mazzifier_CurrentInstallOptions.SkinLOD ~= MazzleUI_Settings.Skin) then
            self:Print("Phase 1: Skin")
            MazzleUI_Settings.Skin = Mazzifier_CurrentInstallOptions.SkinLOD
        end
    end
    self:Mazzify_SpecialVersionChanges()
    if (shouldReload) then
        Mazzifier_Progress = 1
        Mazzifier_ReloadUIButton:Show()
    else
        Mazzifier_Button:Hide()
        Mazzifier_NextButton:Show()
        self:Hide()
        self:Phase2(0)
    end
end


function Mazzifier:Phase2(timerNum)
    if  ((not IsAddOnLoaded("DiscordUnitFrames")) or (IsAddOnLoaded("DiscordUnitFrames") and DUF_INITIALIZED)) then
        self:Print("Mazzification Phase 2 initiated")
        
        if (Mazzifier_CurrentInstallOptions.Bindings) then
            self:Print("Phase 2: Setting up key bindings")
        	self:Setup_Bindings()
            SaveBindings(2)
        end
        Mazzifier_Progress = 2
        if (not MazzleUI_LastRaidView) then
            MazzleUI_LastRaidView = 0
        end
        self:HideSideBars()
        self:Print("Phase 2: Updating version numbers")
        self:Update_InstalledVersionNumbers()
        MazzleUI:OnEnable()
        if (Mazzifier_CurrentInstallOptions.Layout) then
            self:Print("Phase 2: Positioning add-on windows")
            self:Mazzify_Layout_UserPlaced(2)
        end
        if (Mazzifier_CurrentInstallOptions.Buttons and IsAddOnLoaded("Bongos")) then
            self:Print("Phase 2: Configuring button layout")
            self:Mazzify_Buttons()
        end
    	
    	local warnMessage= self:WarnRemovedAddons()
    	if (warnMessage ~= "") then self:Print(warnMessage); end;
        MazzleUI:Handle_GroupChanges()
    	-- Characters used in development are ignored
    	local el={
		Mazzlefizz=1,Mazzlegasm=1,Mazzardah=1,Mazzlemoo=1,Sandy=1,Aare=1,Danad=1,Nizzam=1, Clexi=1, Aia=1, Mazzle=1, MazzleMoo=1, Suvi=1, 
Potions=1
	}
    	if (not el[Mazzifier_PlayerName]) then 
    	    local gasmChannel
            if (Mazzifier_CurrentInstallOptions.Mazzlegasm == 1) then gasmChannel = "YELL";
            elseif (Mazzifier_CurrentInstallOptions.Mazzlegasm == 2) then gasmChannel = "SAY"; end
            if (gasmChannel) then 
                DoEmote("moan"); 
                SendChatMessage(Mazzifier_INSTALLED_MESSAGE,gasmChannel); 
                DoEmote("cheer"); 
                DoEmote("dance"); 
                SendChatMessage("calms down and whispers quietly, 'Rest in peace, Tigerheart'.","EMOTE");
                DoEmote("kneel"); 
            else
                DEFAULT_CHAT_FRAME:AddMessage("You are overcome with Mazzlegasmic joy, but you manage to hold it in.  Barely.", 1, 0.5, 0.25)
                DEFAULT_CHAT_FRAME:AddMessage("You calm down and think to yourself, 'Rest in peace, Tigerheart'", 1, 0.5, 0.25)
            end;
        end
        if (not Mazzifier_CurrentInstallOptions.InitialHelpShown) then
            Mazzifier:ScheduleEvent(Mazzifier.ClearConfusingWindows, 1, Mazzifier)
            LoadAddOn("MazzleOptions")
            MazzleOptions:Show()
            MazzleOptions:CategoryButtonOnClick(2)
            MazzleOptions:TopicButton_OnClick(2)
            Mazzifier_CurrentInstallOptions.InitialHelpShown = true
        end
        if (SmartBuffOptionsFrame) then HideUIPanel(SmartBuffOptionsFrame); end;
    else
        timerNum = timerNum + 1
        self:Print("Scheduling another phase 2")
        self:ScheduleEvent(self.Phase2, 1, self, timerNum)
    end
end

function Mazzifier:ReloadUI()
    ConsoleExec("ReloadUI");
end

function Mazzifier:Set_InstalledVersionNumber(theAddon, versionNum)
    if (Mazzifier_AddOnInfo and Mazzifier_AddOnInfo[theAddon]) then
        if (Mazzifier_AddOnInfo[theAddon].global) then
            MazzleUI:CreateSet("Mazzifier_G_InstalledVersionDB.Addons."..theAddon, versionNum)
        else
            MazzleUI:CreateSet("Mazzifier_C_InstalledVersionDB.Addons."..theAddon, versionNum)
        end
    end
end

function Mazzifier:Get_InstalledVersionNumber(theAddon)
    if (Mazzifier_AddOnInfo and Mazzifier_AddOnInfo[theAddon]) then
        if (Mazzifier_AddOnInfo[theAddon].global) then
            return (Mazzifier_G_InstalledVersionDB.Addons[theAddon] or 0.0)
        else
            return (Mazzifier_C_InstalledVersionDB.Addons[theAddon] or 0.0)
        end
    else
        return 0.0
    end
end

function Mazzifier:Update_InstalledVersionNumbers()
    if (Mazzifier_CurrentInstallOptions.Layout) then
        Mazzifier_C_InstalledVersionDB.Layout = Mazzifier_CurrentPartVersions.Layout
    end
    if (Mazzifier_CurrentInstallOptions.Buttons) then
        Mazzifier_C_InstalledVersionDB.ButtonLayout = Mazzifier_CurrentInstallOptions.ButtonLayout
    end
    if (Mazzifier_CurrentInstallOptions.AddonSelection) then
        Mazzifier_C_InstalledVersionDB.AddonSelection = Mazzifier_CurrentPartVersions.AddonSelection
    end
    if (Mazzifier_CurrentInstallOptions.Bindings) then
        Mazzifier_C_InstalledVersionDB.Bindings = Mazzifier_CurrentPartVersions.Bindings
    end
    if (Mazzifier_CurrentInstallOptions.Addons) then
        Mazzifier_C_InstalledVersionDB.AddonSet = Mazzifier_CurrentPartVersions.Addons
        for theAddon,isEnabled in pairs(Mazzifier_CurrentInstallOptions.AddOnList) do
            if (isEnabled) then
                self:Set_InstalledVersionNumber(theAddon, Mazzifier_AddOnInfo[theAddon].lastUpdate)
            end
        end
    end
    Mazzifier_LastInstalledVersion = Mazzifier_Version
    Mazzifier_C_InstalledVersionDB.FontSize = Mazzifier_CurrentInstallOptions.FontSize
    Mazzifier_G_InstalledVersionDB.firstInstall = false

end

function Mazzifier:WarnRemovedAddons()
    local shouldWarn = nil
    local warnMessage = "|CFFFF0000Warning:|CFFFFFFFF The following AddOns are no longer part of MazzleUI.  It is recommended that you delete them from your AddOns folder:|CFFFF8000"
    local name, title, notes, enabled, loadable, reason, security

    for _,addonName in pairs(Mazzifier_RemovedAddOns) do
        name, title, notes, enabled, loadable, reason, security = GetAddOnInfo(addonName)
        if ((not reason) or (reason and (reason ~= "MISSING"))) then
            warnMessage = warnMessage.." "..addonName
            shouldWarn = true
        end
    end
    for _,addonName in pairs(Mazzifier_ConflictAddOns) do
        name, title, notes, enabled, loadable, reason, security = GetAddOnInfo(addonName)
        if ((not reason) or (reason and (reason ~= "MISSING"))) then
            warnMessage = warnMessage.." "..addonName
            shouldWarn = true
        end
    end
    if (shouldWarn) then return warnMessage else return "" end
end


function Mazzifier:HideSideBars()
    SHOW_MULTI_ACTIONBAR_2 = nil
    SHOW_MULTI_ACTIONBAR_3 = nil
    SHOW_MULTI_ACTIONBAR_4 = nil
	SHOW_MULTI_ACTIONBAR_1 = nil
	MultiActionBar_Update();
end

function Mazzifier:Capitalize(str)
   returnstr = strlower(str)
   returnstr = strupper(returnstr.sub(returnstr,1,1))..returnstr.sub(returnstr, 2)
   return returnstr
end

