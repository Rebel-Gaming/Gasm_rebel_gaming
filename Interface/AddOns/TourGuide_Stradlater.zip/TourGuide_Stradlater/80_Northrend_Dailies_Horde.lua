TourGuide:RegisterGuide("Icecrown (3.2 Dailies)", nil,"Horde", function()
return [[

N Introduction |N|I have not tested the horde version of this guide myself.  Post any bugs to the WoWInterface section for this guide.  Most efficient hearth point is the Argent Tournament Grounds.  If you have the tabard that ports you to the tournament, the most efficient hearth point is K3|


N Get the Valiant/Aspirant quests |N|Mark when done collecting (76.0,24.5)|
N Get the DK champion quests (if possible) |N|Mark when done collecting (73.6,20.0)| |C|Death Knight|
N Get all quests from the champion tent (if possible) |N|Mark when done collecting (69.9,23.5)|
A A Valiant's Field Training |O| |QID|13771|
A A Valiant's Field Training |O| |QID|13776|
A A Valiant's Field Training |O| |QID|13781|
A A Valiant's Field Training |O| |QID|13786|
A A Valiant's Field Training |O| |QID|13765|
A The Grand Melee |O| |QID|13772|
A The Grand Melee |O| |QID|13777|
A The Grand Melee |O| |QID|13782|
A The Grand Melee |O| |QID|13787|
A The Grand Melee |O| |QID|13767|


A Training in the Field |O| |QID|13676|
A Learning the Reins |O| |QID|13677|

A What Do You Feed a Yeti, Anyway! |O| |QID|14145|
A Breakfast of Champions |O| |QID|14092|
A Gormok Wants His Snobolds |O| |QID|14141|

A You've Really Done It This Time, Kul |O| |QID|14142|
A Rescue at Sea |O| |QID|14136|
A Stop the Aggressors |O| |QID|14140|
A The Light's Mercy |O| |QID|14144|
A A Leg Up |O| |QID|14143|



C The Grand Melee |O| |QID|13772|
C The Grand Melee |O| |QID|13777|
C The Grand Melee |O| |QID|13782|
C The Grand Melee |O| |QID|13787|
C The Grand Melee |O| |QID|13767|
C Learning the Reins |O| |QID|13677|




A Taking Battle To The Enemy |O| |QID|13810|
A Taking Battle To The Enemy |O| |QID|13813|
A Among the Champions |O| |QID|13811|
A Among the Champions |O| |QID|13814|


A The Fate of the Fallen |O| |QID|14107|
A Get Kraken! |O| |QID|14108|

A Drottinn Hrothgar |O| |QID|14101|
A Mistcaller Yngvar |O| |QID|14102|
A Ornolf the Scarred |O| |QID|14104|
A Deathspeaker Kharos |O| |QID|14105|


C Get Kraken! |O| |N|Get on the argent hippogryph outside the tent (69.8,22.3), then use your spears on the kraken and the vrykul on the middle ship.| |U|46954| |QID|14108|


C Among the Champions |O| |QID|13811| |N|Jousting in the champion's ring (72,24)|
C Among the Champions |O| |QID|13814| |N|Jousting in the champion's ring (72,24)|



C Deathspeaker Kharos |O| |QID|14105| |N|Under a blue orb, in a ditch at (64,21).  His spawn point is likely surrounded by several of his own corpses.|
C You've Really Done It This Time, Kul |O| |N|Kill for keys and unlock cages.  Kul himself is in a cage on the terrace at (60,23).| |QID|14142|


C What Do You Feed a Yeti, Anyway! |O| |N|Get 3 chum buckets from a ship on the SE edge of the straight (74,10).  Use the chum to attract sharks and kill them.| |QID|14145|

C Rescue at Sea |O| |N|The alliance ship is on the west side of the channel (44,54).  Kill vrykul on the ship.| |QID|14136| |Z|Hrothgar's Landing|


C Drottinn Hrothgar |O| |N|Northeast side of Hrothgar's Landing.  There are 3 statues.  Use the horn in the middle. (50.5,15.6)| |QID|14101| |Z|Hrothgar's Landing|
C Mistcaller Yngvar |O| |N|West side of Hrothgar's Landing (43,25).  Use the charm once inside.| |QID|14102| |Z|Hrothgar's Landing|
C Ornolf the Scarred |O| |N|Southeast end of Hrothgar's Landing at a ship in the harbor (59.3, 31.9).  Use the banner on the ship.| |QID|14104| |Z|Hrothgar's Landing|

C The Light's Mercy |O| |N|Use the book on tuskarr corpses at Hrothgar's Landing| |QID|14144| |Z|Hrothgar's Landing|
C A Leg Up |O| |N|Kill Vrykul and grab legs at Hrothgar's Landing| |QID|14143| |Z|Hrothgar's Landing|
C Stop the Aggressors |O| |N|Kill Vrykul at Hrothgar's Landing| |QID|14140| |Z|Hrothgar's Landing|

R The Storm Peaks |N|We're going Southeast towards (45,60).  If you have the Argent Tabard, you should hearth to K3| |Z|The Storm Peaks|

C Breakfast of Champions |O| |N|In central storm peaks (45,60).  Use the drum near the snow mounds.| |QID|14092| |Z|The Storm Peaks|
C Gormok Wants His Snobolds |O| |N|Just northeast of K3 (43,82).  Use the net on the followers.| |QID|14141| |Z|The Storm Peaks|


A Feeding Arngrim |N|REQUIRES HODIR REVERED -- At the Sons of Hodir camp in Storm Peaks (67.5,60.0)| |QID|13046| |Z|The Storm Peaks|
A Thrusting Hodir's Spear |N|REQUIRES HODIR HONORED -- At the Sons of Hodir camp (65.0,60.9)| |QID|13003| |Z|The Storm Peaks|
A Polishing the Helm |N|At the sons of Hodir camp (64.5,59.6)| |QID|13006| |Z|The Storm Peaks|
C Polishing the Helm |N|In the cave (55,63)| |QID|13006| |Z|The Storm Peaks|
C Feeding Arngrim |QID|13046| |N|Outside the cave (55,63)| |U|42774| |Z|The Storm Peaks|
C Thrusting Hodir's Spear |QID|13003| |N|Outside the cave, look in the sky for wyrms and use the harpoon (55,63)| |U|42769| |Z|The Storm Peaks|
T Feeding Arngrim |N|(67.5,60.0)| |QID|13046| |Z|The Storm Peaks|
T Thrusting Hodir's Spear |N|(65.0,60.9)| |QID|13003| |Z|The Storm Peaks|
T Polishing the Helm |N|(64.5,59.6)| |QID|13006| |Z|The Storm Peaks|


H Sunreaver Pavilion



A Keeping the Alliance Blind |QID|13331| |N|Airship in Icecrown (66,39)|
A Slaves to Saronite |QID|13302|
A Blood of the Chosen |QID|13330|
A Drag and Drop |QID|13353|
A Not a Bug |QID|13365|
A Retest Now |QID|13357|


A Assault by Ground |N|2:30 to complete, also doubles up for another quest.  (58.3, 46.0)| |QID|13301|
A Assault by Air |N|(58.3,46.0)| |QID|13310|
C Assault by Ground |N|Follow the soldiers up the ramp, killing vrykul as you go| |QID|13301|

C Assault by Air |N|Jump in the gunner's seat at (58.3, 46.0)| |QID|13310|



A King of the Mountain |N|(52,57.6)| |QID|13283|
C King of the Mountain |N|At the top of the mountain (54,60)| |QID|13283|
T King of the Mountain |N|(52,57.6)| |QID|13283|

C Slaves to Saronite |N|In the cave (57,59)| |QID|13302|

C Blood of the Chosen |N|Kill more vrykul (not the ones in the cave) (57,59)| |QID|13330|


T Assault by Air |N|(58.3, 46.0)| |QID|13310|
T Assault by Ground |N|(58.3, 46.0)| |QID|13301|







C A Valiant's Field Training |N|Kill 10 converted heroes (45,52)| |O| |QID|13771|
C A Valiant's Field Training |N|Kill 10 converted heroes (45,52)| |O| |QID|13776|
C A Valiant's Field Training |N|Kill 10 converted heroes (45,52)| |O| |QID|13781|
C A Valiant's Field Training |N|Kill 10 converted heroes (45,52)| |O| |QID|13786|
C A Valiant's Field Training |N|Kill 10 converted heroes (45,52)| |O| |QID|13565|


C The Fate of the Fallen |O| |N|Grab stuff off ground and use it on the ghosts (50,43)| |QID|14107|


C Keeping the Alliance Blind |N|(51,42)| |QID|13331| |U|44212|








C Drag and Drop |N|Get orbs from the bitter initates, then use them on the dark subjugators (54,45)| |U|44246| |QID|13353|

A Riding the Wavelength: the Bombardment |N|(54,36.9)| |QID|13406|
C Riding the Wavelength: the Bombardment |N|Kill the ground stuff first (abominations may take two hits), then kill only enough gargoyles to finish the quest, then let them kill you| |QID|13406|
T Riding the Wavelength: the Bombardment |N|Let the gargoyles kill you, you will return to the questgiver faster (54,36.9)| |QID|13406|





U Chug the Tonic |U|44307|
N Get 5 Dark Matters |L|44434 5| |N|Kill Voidwalkers and use the rod on the corpse.  STAND STILL during the process and don't try to do a bunch at once, the quest will bug out. Mark this complete when done. (56,30)| |U|44433| 
C Not a Bug |N|MAKE SURE YOU HAVE 5 DARK MATTERS, then click on the crystal (53.8,33.7)| |U|44433| |QID|13365|
K Get 10 Essences |N|Kill cultists near the cauldrons (49,33)| |L|44301 10|
U Combine the Essences |U|44301| |L|44304|
U Throw into a cauldron |N|Throw the mass into the cauldron of your choice blue = spellpower, light blue = attack power, green = stamina (49,33)| |U|44304|
C Retest Now |N|Throw the mass into the cauldron of your choice blue = spellpower, light blue = attack power, green = stamina (49,33)| |U|44304| |QID|13357|


C Taking Battle To The Enemy |N|Kill any 15 cultists| |O| |QID|13813|
C Taking Battle To The Enemy |N|Kill any 15 cultists| |O| |QID|13810|

C Training in the Field |N|Kill any 8 cultists| |O| |QID|13676|




A Vile Like Fire! |N|(43.5, 24.5)| |QID|13071|
A Shoot 'Em Up |N|(43.6,25.1)| |QID|13069|
A Leave Our Mark |N|(42.9,25.0)| |C|Death Knight, Druid, Hunter, Mage, Paladin, Priest, Shaman, Warlock, Warrior| |QID|12995|

C Leave Our Mark |N|Plant the sword in dead vrykul.  Apparently there's a bunch on Savage Ledge (38,24)| |C|Death Knight, Druid, Hunter, Mage, Paladin, Priest, Shaman, Warlock, Warrior| |QID|12995| |U|42480|
C Shoot 'Em Up |N|Harpoons at (28.4,32.4).| |QID|13069|
C Vile Like Fire! |N|Since this has been fixed, you must set fire to a non-burning house to get credit.  Grabbing any obvious buildings around 3 o'clock then working clockwise seems to work best unless someone has already been here burning things.  Aim for the roofs (27,39)| |QID|13071|

A No Fly Zone |N|(19.7,47.9)| |QID|12815|
A Intelligence Gathering |N|(19.9,47.6)| |C|Rogue| |QID|12838|
A From Their Corpses, Rise! |N|(19.7,48.3)| |QID|12813|

C From Their Corpses, Rise! |N|Kill gryphon riders, turn them into zombies.  Ignore the provided mount.  (10,42.5)| |QID|12813| |U|40587|
C No Fly Zone |N|Ignore the provided mount.  (10,42.5)| |QID|12815| |U|40587|
C Intelligence Gathering |C|Rogue| |N|Drop off mount in stealth mode, sap the harbor guards and pick the locks (10,37)| |QID|12838|


T No Fly Zone |N|(19.7,47.9)| |QID|12815|
T Intelligence Gathering |N|(19.9,47.6)| |C|Rogue| |Q|12838|
T From Their Corpses, Rise! |N|(19.7,48.3)| |QID|12813|


T Vile Like Fire! |N|(43.5,24.5)| |QID|13071|
T Shoot 'Em Up |N|(43.6,25.1)| |QID|13069|
T Leave Our Mark |N|(42.9,25.0)| |C|Death Knight, Druid, Hunter, Mage, Paladin, Priest, Shaman, Warlock, Warrior| |QID|12995|







T Keeping the Alliance Blind |QID|13331|  |N|Airship in Icecrown (66,39)|
T Slaves to Saronite |QID|13302| |N|Airship|
T Blood of the Chosen |QID|13330| |N|Airship|
T Drag and Drop |QID|13353| |N|Airship|
T Not a Bug |QID|13365| |N|Airship|
T Retest Now |QID|13357| |N|Airship|



H Sunreaver Pavilion

T A Valiant's Field Training |O| |QID|13771| |N|(76.0,24.5)|
T A Valiant's Field Training |O| |QID|13776| |N|(76.0,24.5)|
T A Valiant's Field Training |O| |QID|13781| |N|(76.0,24.5)|
T A Valiant's Field Training |O| |QID|13786| |N|(76.0,24.5)|
T A Valiant's Field Training |O| |QID|13565| |N|(76.0,24.5)|
T The Grand Melee |O| |QID|13772| |N|(76.0,24.5)|
T The Grand Melee |O| |QID|13777| |N|(76.0,24.5)|
T The Grand Melee |O| |QID|13782| |N|(76.0,24.5)|
T The Grand Melee |O| |QID|13787| |N|(76.0,24.5)|
T The Grand Melee |O| |QID|13667| |N|(76.0,24.5)|
T Training in the Field |O| |QID|13676| |N|(76.0,24.5)|
T Learning the Reins |O| |QID|13677| |N|(76.0,24.5)|


T What Do You Feed a Yeti, Anyway! |O| |QID|14145| |N|(76.0,24.5)|
T Breakfast of Champions |O| |QID|14092| |N|(76.0,24.5)|
T Gormok Wants His Snobolds |O| |QID|14141| |N|(76.0,24.5)|

T You've Really Done It This Time, Kul |O| |QID|14142| |N|(76.0,24.5)|
T Rescue at Sea |O| |QID|14136| |N|(76.0,24.5)|
T Stop the Aggressors |O| |QID|14140| |N|(76.0,24.5)|
T The Light's Mercy |O| |QID|14144| |N|(76.0,24.5)|
T A Leg Up |O| |QID|14143| |N|(76.0,24.5)|




T Taking Battle To The Enemy |O| |N|Champion's Tent (69.9,23.5)| |QID|13810|
T Taking Battle To The Enemy |O| |QID|13813| |N|(73.6,20.0)|
T Among the Champions |O| |QID|13811| |N|(69.9,23.5)|
T Among the Champions |O| |QID|13814| |N|(73.6,20.0)|
T The Fate of the Fallen |O| |QID|14107| |N|(69.9,23.5)|
T Get Kraken! |O| |QID|14108| |N|(69.9,23.5)|
T Drottinn Hrothgar |O| |QID|14101| |N|(69.9,23.5)|
T Mistcaller Yngvar |O| |QID|14102| |N|(69.9,23.5)|
T Ornolf the Scarred |O| |QID|14104| |N|(69.9,23.5)|
T Deathspeaker Kharos |O| |QID|14105| |N|(69.9,23.5)|






N DONE! |N|You might have a few dailies left over (i.e. Threat From Above, the valiant sword quest, the scourge jousting quests), you can either do these or abandon them (your preference)|





]]
end)
