WoWPro_Leveling:RegisterGuide("JamWin5657", "Winterspring", "Jame", "56", "57", "JamFel5757", "Horde", function()
return [[

R Winterspring|QID|980|N|(65.4,2.9)(68.2,5.5)|Z|Felwood|M|65.1,8.2|
T The New Springs|QID|980|M|31.3,45.2|
A Strange Sources|QID|4842|M|31.3,45.2|
T Toxic Horrors|QID|5086|
A Winterfall Runners|QID|5087|
N Winterfall Runners|QID|5087|N|Keep your eye out for the Winterfall Runners during the next few steps. Kill them and loot the crate if you see them.|

R Everlook|QID|977|N||M|61,38|
A Are We There, Yeti? (Part 2)|QID|977|M|60.9,37.6|

C Winterfall Activity|QID|8464|N|Kill Winterfall Shamans and Ursas around .|M|66,33|
C Are We There, Yeti? (Part 2)|QID|977|N|Kill Yeti Matriarchs and Patriarchs for their horns around .|M|68,42|

T Are We There, Yeti? (Part 2)|QID|977|M|60.9,37.6|
A Are We There, Yeti? (Part 3)|QID|5163|M|60.9,37.6|
N Scare Legacki|QID|977|QO|Scare Legacki: 1/1|U|12928|N|Find a goblin named Legacki, she stands to the left of the Inn . Target her and right click Umi's Mechanical Yeti.|M|61.5,38.6|

C Wild Guardians (Part 2)|QID|4741|N|Kill Moontouched Owlbeasts at Owl Wing Ticket .|M|63,59|
C Strange Sources|QID|4842|N|Head south to Darkwhisper Gorge |M|60.0,73.6|
]]
end)