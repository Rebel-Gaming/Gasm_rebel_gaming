WoWPro_Leveling:RegisterGuide("MawWes1315", "Westfall", "Maw", "13", "15", "MawRed1516", "Alliance", function()
return [[

N Sell junk and repair |QID|153| |N|Close this step when you're done  |M|57.68,53.84|
N Follow the arrows 1 |QID|22| |N|Kill all the Fleshrippers and Goretusks in the area. Then close this step . You can stop killing Fleshrippers once you got 3 Stringy Vulture Meat, but keep on killing Goretusks. |M|60.56,45.71|
N Follow the arrows 2 |QID|22| |N|Kill all the Goretusks in the area. Close this step once you reach the location  |M|56.00,40.26|
N Follow the arrows 3 |QID|22| |N|Keep on killing Goretusks on sight from now on, until you've looted 3 Goretusk Snout and 8 Goretusk Liver. Close this step on you reach the location  | |L|723 8|M|52.00,43.83|
N Follow the arrows 4 |N|Kill all the defias mobs in this camp and also loot any eventual Sack of Oats. Close this step once you reach the location  |M|50.85,39.49|
N Follow the arrows 5 |N|Kill all the defias mobs in the area and also loot any eventual Sack of Oats. Close this step once you reach the location  |M|46.16,37.93|
N Follow the arrows 6 |N|Kill all the defias mobs at this camp and also loot any eventual Sack of Oats. Close this step once you reach the location  |M|48.60,47.07|
N Follow the arrows 7 |QID|22| |N|Kill Defias, Goretusks and loot Sack of Oats on the way. Close this step once you reach the location  |M|45.71,57.76|
N Follow the arrows 8 |QID|22| |N|Kill all the Goretusks in the area. Then close this step |M|60.56,45.71|
N Follow the arrows 9 |QID|22| |N|Kill all the Goretusks in the area. Close this step once you reach the location  | |L|723 8|M|56.00,40.26|
N Follow the arrows 10 |QID|22| |N|Keep on killing Goretusks on sight from now on, until you've looted 8 Goretusk Liver. Close this step on you reach the location  | |L|723 8|M|52.00,43.83|
N Follow the arrows 11 |N|Kill all the defias mobs in this camp and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|50.85,39.49|
N Follow the arrows 12 |N|Kill all the defias mobs in the area and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|46.16,37.93|
N Follow the arrows 13 |N|Kill all the defias mobs at this camp and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|48.60,47.07|
N Follow the arrows 14 |QID|22| |N|Kill Defias, Goretusks and loot Sack of Oats on the way. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|45.71,57.76|
N Follow the arrows 15 |QID|22| |N|Kill all the Goretusks in the area. Then close this step  |  |L|723 8|M|60.56,45.71|
N Follow the arrows 16 |QID|22| |N|Kill all the Goretusks in the area. Close this step once you reach the location  | |L|723 8|M|56.00,40.26|
N Follow the arrows 17 |QID|22| |N|Keep on killing Goretusks on sight from now on, until you've looted 8 Goretusk Liver. Close this step on you reach the location  | |L|723 8|M|52.00,43.83|
N Follow the arrows 18 |N|Kill all the defias mobs in this camp and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|50.85,39.49|
N Follow the arrows 19 |N|Kill all the defias mobs in the area and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|46.16,37.93|
N Follow the arrows 20 |N|Kill all the defias mobs at this camp and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|48.60,47.07|
N Follow the arrows 21 |QID|22| |N|Kill Defias, Goretusks and loot Sack of Oats on the way. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|45.71,57.76|
N Follow the arrows 22 |QID|22| |N|Kill all the Goretusks in the area. Then close this step  | |L|723 8|M|60.56,45.71|
N Follow the arrows 23 |QID|22| |N|Kill all the Goretusks in the area. Close this step once you reach the location  | |L|723 8|M|56.00,40.26|
N Follow the arrows 24 |QID|22| |N|Keep on killing Goretusks on sight from now on, until you've looted 8 Goretusk Liver. Close this step on you reach the location  | |L|723 8|M|52.00,43.83|
N Follow the arrows 25 |N|Kill all the defias mobs in this camp and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|50.85,39.49|
N Follow the arrows 26 |N|Kill all the defias mobs in the area and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|46.16,37.93|
N Follow the arrows 27 |N|Kill all the defias mobs at this camp and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15|  |L|829 15|M|48.60,47.07|
N Follow the arrows 29 |QID|22| |N|Kill all the Goretusks in the area. Then close this step  | |L|723 8|M|60.56,45.71|
N Follow the arrows 30 |QID|22| |N|Kill all the Goretusks in the area. Then close this step  | |L|723 8|M|60.56,45.71|
N Follow the arrows 31 |QID|22| |N|Kill all the Goretusks in the area. Close this step once you reach the location  | |L|723 8|M|56.00,40.26|
N Follow the arrows 32 |QID|22| |N|Keep on killing Goretusks on sight from now on, until you've looted 8 Goretusk Liver. Close this step on you reach the location  | |L|723 8|M|52.00,43.83|
N Follow the arrows 33 |N|Kill all the defias mobs in this camp and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|50.85,39.49|
N Follow the arrows 34 |N|Kill all the defias mobs in the area and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15| |L|829 15|M|46.16,37.93|
N Follow the arrows 35 |N|Kill all the defias mobs at this camp and also loot any eventual Sack of Oats. Close this step once you reach the location  | |QID|12| |QO|Defias Trapper slain: 15/15|  |QID|12| |QO|Defias Smuggler slain: 15/15|  |L|829 15|M|48.60,47.07|
N Follow the arrows 36 |QID|22| |N|Kill Defias, Goretusks and loot Sack of Oats on the way. Close this step once you reach the location  | |L|829 15| |QID|12| |QO|Defias Trapper slain: 15/15| |QID|12| |QO|Defias Smuggler slain: 15/15|M|45.71,57.76|
N Follow the arrows 37 |QID|22| |N|Kill all the Goretusks in the area. Then close this step  | |L|723 8|M|60.56,45.71|
N READ THIS |N|If by now you still haven't finished the People's Militia, revisit the defias camps we've been to while "following the arrows", until you finish the quest| |QID|12| |QO|Defias Trapper slain: 15/15| |QID|12| |QO|Defias Smuggler slain: 15/15|
N READ THIS |QID|22| |N|If by now you still haven't finished Goretusk Liver Pie, revisit the spots we've been to while "following the arrows", until you've looted 8 Goretusk Liver| |L|723 8|
N READ THIS |QID|153| |N|If by now you still haven't finished Red Leather Bandanas, revisit the defias camps we've been to while "following the arrows", until you finish the quest| |L|829 15| 
T Red Leather Bandanas |QID|153|M|54.0,52.9|
h Sentinel Hill |QID|12| |N|Go to the inn and make it your home location  | |Z|Westfall|M|52.85,53.68|
T The People's Militia (Part 1) |QID|12|M|56.3,47.5|
A The People's Militia (Part 2)|QID|13|M|56.3,47.5|
T Return to Lewis |QID|6285|
N Sell junk and repair |QID|22| |N|Close this step when you're done  |M|57.68,53.84|
N WARNING: Goretusk Liver Pie |QID|22| |N|Make sure you didn't sell the Goretusk Livers. If you did, buy them back from the merchant! | |L|723 8|
N WARNING: Westfall Stew |QID|38| |N|WARNING: Make sure you didn't sell the 3 Goretusk Snouts and the 3 Stringy Vulture Meat. If you did, buy them back from the merchant! | |L|731 3| |L|729 3|
T Goretusk Liver Pie |QID|22|M|56.4,30.5|
N Reminder: Sack of Oats |QID|151| |N|Don't forget to loot Sacks of Oats on the way. Close this step.| |L|1528 8|
N Harvest Watcher 1 |QID|9| |N|Kill every Harvest Watcher on this field, then close this step.  |M|54.35,32.68|
N Harvest Watcher 2 |QID|9| |N|Kill every Harvest Watcher on this field, then close this step.  |M|51.17,21.88|
C Poor Old Blanchy |N|Finish this quest now. Sacks of Oats can be found around all farm fields in Westfall. | |QID|151|
C The Forgotten Heirloom |N|Inside the house, click Furlbrow's Wardrobe and get Furlbrow's Pocket Watch | |QID|64|M|49.24,19.15|
N Riverpaw Gnolls 1 |QID|102| |N|Kill all Riverpaw in this camp and loot Gnoll Paws. Close this step once you've cleared the camp  | |L|725 8|M|42.10,19.66|
N Riverpaw Gnolls 2 |QID|102| |N|Kill all Riverpaw in this camp and loot Gnoll Paws. Close this step once you've cleared the camp  | |L|725 8|M|45.00,14.41|
N Riverpaw Gnolls 3 |QID|102| |N|Kill all Riverpaw in this camp and loot Gnoll Paws. Close this step once you've cleared the camp  | |L|725 8|M|51.00,16.30|
N Riverpaw Gnolls 4 |QID|102| |N|Kill all Riverpaw in this camp and loot Gnoll Paws. Close this step once you've cleared the camp  | |L|725 8|M|56.73,14.60|
C Patrolling Westfall |N|If you haven't looted 8 Gnoll Paws yet, go back to the first gnoll camp you cleared and restart the same circuit until you finish this quest  | |QID|102|M|42.10,19.66|
N Murloc Eyes |QID|38| |N|Kill Murlocs along the beach until you've looted 3 Murloc Eyes  | |L|730 3|M|52.64,9.00|
T The Forgotten Heirloom |QID|64|M|60.0,19.4|
T Poor Old Blanchy |QID|151|M|60.0,19.4|
C The Killing Fields |N|Kill Harvest Watchers until you finish this quest. Remember, if you run out of Harvest Watchers, there are two other fields south and southwest of this one  | |QID|9|M|51.15,22.08|
N Loot 3 Okra |QID|38| |N|Keep on killing Harvest Watchers until you've looted 3 Okra  | |L|732 3|M|54.53,32,68|
N Loot 5 Hops |QID|117| |N|Keep on killing Harvest Watchers until you've looted 5 Hops  | |L|1274 5|M|54.53,32,68|
N Loot 5 Flask of Oil |QID|103| N|Keep on killing Harvest Watchers until you've looted 5 Flask of Oil (54.53, 32,68) | |L|814 5|
T The Killing Fields |QID|9|M|56.0,31.2|
T Westfall Stew |QID|38|M|56.4,30.5|
T Patrolling Westfall |QID|102|M|56.3,47.5|
A The Defias Brotherhood (Part 1) |QID|65|M|56.3,47.5|


N Sell junk and repair |QID|117| |N|WARNING. Do not sell the 5 Hops and the 5 Flasks of Oil. Close this step when you're done  |M|57.68,53.84|
N WARNING: Flasks of Oil |QID|103| |N|Make sure you didn't sell the 5 Flasks of Oil. If you did, buy them back from the merchant! | |L|814 5|
N WARNING: Hops |QID|117| |N|Make sure you didn't sell the 5 Hops. If you did, buy them back from the merchant! | |L|1274 5|
N Alexston Farmstead |N|Kill all the Defias Pillagers and Defias Looters you can find around the Alexston Farmstead. Then close this step  | |QID|13| |QO|Defias Pillager slain: 15/15| |QID|13| |QO|Defias Looter slain: 15/15|M|38.18,56.23|
C The People's Militia (Part 2) |N|Kill Defias Pillagers and Looters until you finish the quest. You can go back to the Alexston Farmstead if you run out of mobs to kill in Moonbrook | |QID|13|M|43.23,69.40|
N Grinding session |QID|13| |N|Grind until you've got 5 bars above level 15. Then close this step  |M|43.23,69.40|
H Sentinel Hill |QID|13|
T The People's Militia (Part 2) |QID|13|M|56.3,47.5|
A The People's Militia (Part 3) |QID|14|M|56.3,47.5|
F Trade District |QID|46| |N| Fly to Stormwind  |M|56.60,52.65|
N Train new skills |QID|46| |N| Close this step when you're done. |
R Elwynn Forest |QID|46| |N|Get out of Stormwind  (74.75, 93.40) | |Z|Stormwind City|M|63.71,71.89|
A Bounty on Murlocs |QID|46|
C Bounty on Murlocs |N|Kill Murlocs until you've looted 8 Torn Murloc Fin  | |QID|46| |Z|Elwynn Forest|M|76.22,82.77|
T Bounty on Murlocs |QID|46|


]]
end)
