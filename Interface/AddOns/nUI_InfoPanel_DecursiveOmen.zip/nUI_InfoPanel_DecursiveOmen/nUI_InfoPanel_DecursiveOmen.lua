
------------------------------------------------------------------------------------
-- Name : nUI_InfoPanel_DecursiveOmen                                          
-- Copyright : Tina Kirby AKA Xrystal (C) 2009/2010 All Rights Reserved      
-- Contact : xrystal@swangen.co.uk                                           
-- Download Sites :                                                          
-- http://www.wowinterface.com/downloads/info14169-nUIInfoPanelDecursiveOmen.html
-- http://wow.curse.com/downloads/wow-addons/details/nui-infopanel-decursive-omen.aspx
-- Versions :
-- 1.01.00 - 23rd July 2009 - New Addon ( 3.1 )
-- 1.01.01 - 6th August 2009 - TOC Change and minor text change ( 3.2 )
-- 1.01.02 - 21st January 2010 - TOC Change ( 3.3 )
-- 1.02.00 - 22nd June 2010 - Rewritten ( 3.3.5 )
------------------------------------------------------------------------------------

--[[ Use Addon Wide Data Table ]]--
local addonName,addonData = ...

--[[ Localise Addon Wide Data Table Sub Tables ]]--
local Translate = addonData.Translate

--[[ Make sure we have nUI tables ]]--
if not nUI_InfoPanels then nUI_InfoPanels = {}; end

--[[ Set Up nUI InfoPanel Values ]]--
nUI_INFOMODE_DECURSIVEOMEN  = 16;
nUI_INFOPANEL_DECURSIVEOMEN = "nUI_InfoPanel_DecursiveOmen";

--[[ Some Constants for Decursive ]]--
MAX_PER_LINE = 8;
MAX_TOTAL  = 64;
MIN_SCALE = 0.65;

--[[ Variables to Store The Existing Values ]]--
local OrigDebuffsFrameMaxCount;
local OrigDebuffsFramePerline;
local OrigDebuffsFrameElemScale;

--[[ Set Up the Info Panel Table ]]--
nUI_InfoPanels[nUI_INFOPANEL_DECURSIVEOMEN ] =
{	
	enabled   = true,
	desc      = Translate["INFO_PANEL_TEXT"],		-- player friendly name/description of the panel
	label     = Translate["INFO_PANEL_LABEL"],		-- label to use on the panel selection button face
	rotation  = nUI_INFOMODE_DECURSIVEOMEN,			-- index or position this panel appears on/in when clicking the selector button
	full_size = true, 								-- this plugin requires the entire info panel port without the button bag
	
	options  =
	{
		enabled  = true,
	},
};

--[[ Create the InfoPanel Plugin ]]--
local plugin    = CreateFrame( "Frame", nUI_INFOPANEL_DECURSIVEOMEN, nUI_Dashboard.Anchor );
plugin.active   = true;

--[[ Handle the addons Events ]]--
local function onEvent(self,event,...)

	if ( event == "ADDON_LOADED" ) then
		if ( arg1 ~= addonName ) then return end

		-- If the addons exist make sure they are loaded
		if not IsAddOnLoaded( "Decursive" ) then 
			LoadAddOn( "Decursive" );
		end
		if not IsAddOnLoaded( "Omen" ) then 
			LoadAddOn( "Omen" );
		end
		if not IsAddOnLoaded( "nUI_InfoPanel_Decursive") then
			LoadAddOn("nUI_InfoPanel_Decursive");
		end
		
		-- Disable the built in Omen plugin	
		if ( nUI_InfoPanels[nUI_INFOPANEL_OMEN3] ) then
			nUI_InfoPanels[nUI_INFOPANEL_OMEN3].enabled = false;
		end
		
		-- Disable the Decursive plugin if it exists
		if ( nUI_InfoPanels[nUI_INFOPANEL_DECURSIVE] ) then
			nUI_InfoPanels[nUI_INFOPANEL_DECURSIVE].enabled = false;
		end
		
		-- If both required addons are loaded and available then activate the plugin
		if ( IsAddOnLoaded( "Decursive" ) and IsAddOnLoaded( "Omen" ) ) then 
			plugin.active = true;
		else
			plugin.active = false;
			
			-- If Omen is loaded and available then use the built in plugin
			if ( IsAddOnLoaded( "Omen" ) ) then
				nUI_InfoPanels[nUI_INFOPANEL_OMEN3].enabled = true;
			end
			
			-- If Decursive is loaded and available then use its plugin if available
			if ( IsAddOnLoaded( "nUI_InfoPanel_Decursive") ) then
				nUI_InfoPanels[nUI_INFOPANEL_DECURSIVE].enabled = true;
			end
			
		end
		self:UnregisterEvent(event);
		
	end	
end

--[[ Set Up the Event Script ]]--
plugin:SetScript( "OnEvent", onEvent );
plugin:RegisterEvent( "ADDON_LOADED" );


--[[ Disable the Omen Frame ]]--
disableOmen = function()
	if plugin.saved_bar_parent then
		nUI_Movers:lockFrame( Omen.Anchor, false, nil );		
		Omen.Anchor.Show = Omen.Anchor.nUI_CachedShow;
		Omen.Anchor.Hide = Omen.Anchor.nUI_CachedHide;
		Omen.Grip.Show   = Omen.Grip.nUI_CachedShow;		
		Omen.Anchor:SetParent( Omen.Anchor.saved_bar_parent );		
		Omen.Anchor.saved_bar_parent = nil;		
		Omen.Anchor:SetAlpha( 1 );
	end

end

--[[ Disable the Decursive Frame ]]--
disableDecursive = function()
	local Decursive = plugin.Decursive;
	if Decursive.saved_parent then
		nUI_Movers:lockFrame( Decursive, false, nil );
		Decursive:SetParent( Decursive.saved_parent );
		Decursive:SetBackdropBorderColor( Decursive.border_color );
		Decursive:SetBackdropColor( Decursive.backdrop_color );
		
		-- Get information from the Decursive Addon
		local DecursiveOptions = Dcr.profile;
		local DecursiveFrames = Dcr.MicroUnitF;

		-- Restore original settings if this addon is disabled
		DecursiveOptions.DebuffsFrameMaxCount = OrigDebuffsFrameMaxCount;
		DecursiveOptions.DebuffsFramePerline = OrigDebuffsFramePerline;
		DecursiveOptions.DebuffsFrameElemScale = OrigDebuffsFrameElemScale;
		DecursiveOptions.ShowDebuffsFrame = true;
		DecursiveFrames.Frame:SetScale(DecursiveOptions.DebuffsFrameElemScale);
		DecursiveFrames:ResetAllPositions();
		DecursiveFrames:Delayed_MFsDisplay_Update();
		
	end
end

--[[ Enable the Omen Frame ]]--
enableOmen = function()
	if not plugin.saved_omen_parent then
		plugin.saved_omen_parent = Omen.Anchor:GetParent();
	end
	
	Omen.Anchor:SetParent( plugin.container );
	Omen.Anchor:ClearAllPoints();
	Omen.Anchor:SetPoint( "TOPRIGHT", plugin.container, "TOPRIGHT", -5, -5 );
	Omen.Anchor:SetPoint( "BOTTOM", plugin.container, "BOTTOM", 0 , 5 );
	
	nUI_Movers:lockFrame( Omen.Anchor, true, nil );

	Omen.Anchor.nUI_CachedShow = Omen.Anchor.Show;
	Omen.Anchor.nUI_CachedHide = Omen.Anchor.Hide;
	Omen.Grip.nUI_CachedShow   = Omen.Grip.Show;
	
	Omen.Anchor:SetAlpha(1);
	Omen:UpdateBackdrop();

	Omen.Anchor:Show();			
	Omen.Grip:Hide();
	
	Omen.Anchor.Hide = function() end;
	Omen.Grip.Show = function() end;

	Omen:ResizeBars()
	Omen:ReAnchorLabels()
	Omen:UpdateBars()
end

--[[ Enable the Decursive Frame ]]--
enableDecursive = function()
	local Decursive = DcrMUFsContainer;
	plugin.Decursive = Decursive;
	
	-- Get information from the Decursive Addon
	local DecursiveOptions = Dcr.profile;
	local DecursiveFrames = Dcr.MicroUnitF;
	
	-- Save some important information
	if not Decursive.saved_parent then
		Decursive.saved_parent   = Decursive:GetParent();
		Decursive.border_color   = Decursive:GetBackdropBorderColor();
		Decursive.backdrop_color = Decursive:GetBackdropColor();
		
		-- Store the existing settings
		OrigDebuffsFrameMaxCount = DecursiveOptions.DebuffsFrameMaxCount;
		OrigDebuffsFramePerline = DecursiveOptions.DebuffsFramePerline;
		OrigDebuffsFrameElemScale = DecursiveOptions.DebuffsFrameElemScale;
				
	end
	
	-- Set the Decursive Frame to fit into the info panel
	nUI_Movers:lockFrame( Decursive, false, nil );
	Decursive:SetParent( plugin.container );
	Decursive:SetPoint( "TOPLEFT", plugin.container, "TOPLEFT", 10, -10 );
	Decursive:SetPoint( "BOTTOM", plugin.container, "BOTTOM", 0, 0 );
	Decursive:SetFrameStrata( plugin.container:GetFrameStrata() );
	Decursive:SetFrameLevel( plugin.container:GetFrameLevel()+1 );
	Decursive:SetBackdropBorderColor( 0, 0, 0, 0 );
	Decursive:SetBackdropColor( 0, 0, 0, 0 );
	
	local ContainerWidth = math.floor(plugin.container:GetWidth() / 2) - 10;
	local ContainerHeight = math.floor(plugin.container:GetHeight()) - 10;
	local DecursiveFrameSize = math.floor(Decursive:GetWidth());
	local DecursiveFrameXGap = DecursiveOptions.DebuffsFrameXSpacing;
	local DecursiveFrameYGap = DecursiveOptions.DebuffsFrameYSpacing;
	
	local RequestedPerLine = DecursiveOptions.DebuffsFramePerline;
	local RequestedMaxCount = DecursiveOptions.DebuffsFrameMaxCount;
	local RequestedScale = DecursiveOptions.DebuffsFrameElemScale;
	
	-- Validate these values so that they do not overstep their bounds
	if ( RequestedPerLine > MAX_PER_LINE ) then RequestedPerLine = MAX_PER_LINE; end
	if ( RequestedMaxCount > MAX_TOTAL ) then RequestedMaxCount = MAX_TOTAL; end
	if ( RequestedScale < MIN_SCALE ) then RequestedScale = MIN_SCALE; end
	
	-- Calculate the boxes down and overall width and height from these values
	local RequestedPerCol = math.floor(RequestedMaxCount / RequestedPerLine);
	local RequestedWidth = math.floor((( DecursiveFrameSize + DecursiveFrameXGap ) * RequestedPerLine ) * RequestedScale );
	local RequestedHeight = math.floor((( DecursiveFrameSize + DecursiveFrameYGap ) * RequestedPerCol ) * RequestedScale );
	
	local tryScale = RequestedScale;
	local tryWidth = RequestedWidth;
	local tryHeight = RequestedHeight;
	local tryPerLine = RequestedPerLine;
	local tryPerCol = RequestedPerCol;

	-- If the requested width or height are too big for the panel segment then
	-- scale it down by 0.05 until it either fits or reaches our MIN_SCALE
	while true do
		if ( tryWidth > ContainerWidth or tryHeight > ContainerHeight ) then
			if ( tryScale < MIN_SCALE + 0.05 ) then
				break;
			else
				tryWidth = math.floor(RequestedWidth / RequestedScale);
				tryHeight = math.floor(RequestedHeight / RequestedScale);
				tryScale = tryScale - 0.05;
				tryWidth = math.floor(tryWidth * tryScale);
				tryHeight = math.floor(tryHeight * tryScale);
			end
		else
			break
		end
	end
	
	-- Update the Values currently set to reflect any changes made in the previous loop
	RequestedWidth = tryWidth;
	RequestedHeight = tryHeight;
	RequestedScale = tryScale;

	-- If the width is still too big then cut down the number of boxes across 
	-- until it gets to 1 or fits.
	while true do
		if ( tryWidth > ContainerWidth ) then
			if ( tryPerLine < 2 ) then
				break;
			else
				tryWidth = RequestedWidth / RequestedScale;
				tryWidth = RequestedWidth / RequestedPerLine;
				tryPerLine = tryPerLine - 1;
				tryWidth = tryWidth * tryPerLine;
				tryWidth = tryWidth * RequestedScale;			
			end
		else
			break;
		end
	end
	
	-- Update the current values
	RequestedWidth = tryWidth;
	RequestedPerLine = tryPerLine;
	
	-- If the height is still too big then cut down the number of boxes down 
	-- until it gets to 1 or fits.
	while true do
		if ( tryHeight > ContainerHeight ) then
			if ( tryPerCol < 2 ) then 
				break;
			else
				tryHeight = RequestedHeight / RequestedScale;
				tryHeight = RequestedHeight / RequestedPerCol;
				tryPerCol = tryPerCol - 1;
				tryHeight = tryHeight * tryPerCol;
				tryHeight = tryHeight * tryScale;				
			end
		else
			break;
		end
	end
	
	-- Update the current values
	RequestedHeight = tryHeight;
	RequestedPerCol = tryPerCol;

	-- Set the Decursive Options to reflect the new values
	DecursiveOptions.DebuffsFrameMaxCount = RequestedPerCol * RequestedPerLine;
	DecursiveOptions.DebuffsFramePerline = RequestedPerLine;
	DecursiveOptions.DebuffsFrameElemScale = RequestedScale;
	DecursiveOptions.ShowDebuffsFrame = true;
	DecursiveFrames.Frame:SetScale(DecursiveOptions.DebuffsFrameElemScale);
	DecursiveFrames:ResetAllPositions();
	DecursiveFrames:Delayed_MFsDisplay_Update();
	
	nUI_Movers:lockFrame( Decursive, true, nil );

end

--[[ Resize the Decursive Frame ]]--
resizeDecursive = function(height,width)
	local Decursive   = plugin.Decursive;
	nUI_Movers:lockFrame( Decursive, false, nil );
	Decursive:SetWidth( width / 2 ); 
	Decursive:SetHeight( height ); 
	nUI_Movers:lockFrame( Decursive, true, nil );
end

--[[ Resize the Omen Frame ]]--
resizeOmen = function(height,width)
	nUI_Movers:lockFrame( Omen.Anchor, false, nil );
	Omen.Anchor:SetWidth( width / 2 );	
	Omen:ResizeBars()
	Omen:ReAnchorLabels()
	Omen:UpdateBars()
	nUI_Movers:lockFrame( Omen.Anchor, true, nil );
end

--[[ The InfoPanel initialisation routine ]]--
plugin.initPanel = function( container, options )
	plugin.container = container;
	plugin.options   = options;
	if options and options.enabled then
		plugin.setEnabled( true );
	end
end

--[[ The InfoPanel resizing routine ]]--
plugin.sizeChanged = function( scale, height, width )
	local options  = plugin.options;
	plugin.scale = scale;
	
	resizeDecursive(height,width);
	resizeOmen(height,width);
end	

--[[ The InfoPanel enabling routine ]]--
plugin.setEnabled = function( enabled )
	if plugin.enabled ~= enabled then
		plugin.enabled = enabled;
		if not enabled then
			disableOmen();
			disableDecursive();
		else
			enableDecursive();
			enableOmen();
		end				
	end			
end

--[[ The InfoPanel selection routine ]]--
plugin.setSelected = function( selected )
	if selected ~= plugin.selected then
		plugin.selected = selected;
		if selected then
		else
		end
	end
end
