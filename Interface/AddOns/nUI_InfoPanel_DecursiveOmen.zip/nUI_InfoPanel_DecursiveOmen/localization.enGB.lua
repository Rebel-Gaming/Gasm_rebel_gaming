
-----------------------------------------------------------------------------------
-- Name : Localization.enGB                                          
-- Copyright : Tina Kirby AKA Xrystal (C) 2009/2010 All Rights Reserved      
-- Contact : xrystal@swangen.co.uk                                           
-- Download Sites :                                                          
-- http://www.wowinterface.com
-- http://www.curse.com
-- Versions :
-- 1.01.00 - 23rd July 2009 - New Addon ( 3.1.0 )
-- 1.01.01 - 6th August 2009 - TOC Change and minor text change ( 3.2.0 )
-- 1.02.00 - 16th June 2010 - Rewritten ( 3.3.0 )
--------------------------------------------------------------------------------

local addonName,addonData = ...

if ( addonData.Locale == "enGB" ) then
	addonData.Translate["INFO_PANEL_TEXT"]	= "Info Panel: Decursive / Omen";
	addonData.Translate["INFO_PANEL_LABEL"]	= "Dec / Omen";
end
