----------------------------------------
-- Group Calendar 5 Copyright 2009, 2010 John Stephen, wobbleworks.com
-- All rights reserved, unauthorized redistribution is prohibited
----------------------------------------

GroupCalendar.Cooldowns = {}

