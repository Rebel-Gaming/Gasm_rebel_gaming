----------------------------------------
-- Group Calendar 5 Copyright 2009, 2010 John Stephen, wobbleworks.com
-- All rights reserved, unauthorized redistribution is prohibited
----------------------------------------

function GroupCalendar:InitializeTradeskill()
	self.Tradeskill = GroupCalendar:New(GroupCalendar._Tradeskill)
end

----------------------------------------
GroupCalendar._Tradeskill = {}
----------------------------------------

GroupCalendar._Tradeskill.TradeskillCooldownIDs =
{
	-- Alchemy
	
	[11479] = "XMUT", -- TransmuteIronToGold
	[11480] = "XMUT", -- TransmuteMithrilToTruesilver
	[17187] = "XMUT", -- TransmuteArcanite
	[17559] = "XMUT", -- TransmuteAirToFire
	[17560] = "XMUT", -- TransmuteFireToEarth
	[17562] = "XMUT", -- TransmuteWaterToAir
	[17563] = "XMUT", -- TransmuteUndeathToWater
	[17561] = "XMUT", -- TransmuteEarthToWater
	[17564] = "XMUT", -- TransmuteWaterToUndeath
	[17565] = "XMUT", -- TransmuteLifeToEarth
	[17566] = "XMUT", -- TransmuteEarthToLife
	[28566] = "XMUT", -- TransmutePrimalAirToFire
	[28567] = "XMUT", -- TransmutePrimalEarthToWater
	[28568] = "XMUT", -- TransmutePrimalFireToEarth
	[28569] = "XMUT", -- TransmutePrimalWaterToAir
	[28582] = "XMUT", -- TransmutePrimalManaToFire
	[28583] = "XMUT", -- TransmutePrimalFireToMana
	[28584] = "XMUT", -- TransmutePrimalLifeToEarth
	[28585] = "XMUT", -- TransmutePrimalEarthToLife
	[28580] = "XMUT", -- TransmutePrimalShadowToWater
	[28581] = "XMUT", -- TransmutePrimalWaterToShadow
	[29688] = "XMUT", -- TransmutePrimalMight
	[32765] = "XMUT", -- TransmuteEarthstormDiamond
	[32766] = "XMUT", -- TransmuteSkyfireDiamond

	
	[53777] = "XMUT", -- Transmute: Eternal Air to Earth
	[53776] = "XMUT", -- Transmute: Eternal Air to Water
	[53781] = "XMUT", -- Transmute: Eternal Earth to Air
	[53782] = "XMUT", -- Transmute: Eternal Earth to Shadow
	[53775] = "XMUT", -- Transmute: Eternal Fire to Life
	[53774] = "XMUT", -- Transmute: Eternal Fire to Water
	[53773] = "XMUT", -- Transmute: Eternal Life to Fire
	[53771] = "XMUT", -- Transmute: Eternal Life to Shadow
	[53779] = "XMUT", -- Transmute: Eternal Shadow to Earth
	[53780] = "XMUT", -- Transmute: Eternal Shadow to Life
	[53783] = "XMUT", -- Transmute: Eternal Water to Air
	[53784] = "XMUT", -- Transmute: Eternal Water to Fire
	[54020] = "XMUT", -- Transmute: Eternal Might
	
	[60350] = "XMUT", -- Transmute: Titanium
	
	[60893] = "ALCH", -- Northrend Alchemy Research
	
	--Enchanting
	
	[45765] = "VOID", -- VoidShatter
	[28028] = "SPHR", -- VoidSphere
	
	-- Tailoring
	
	[18560] = "MOON", -- Mooncloth
	[26751] = "PMON", -- PrimalMooncloth
	[31373] = "SPEL", -- Spellcloth
	[36686] = "SHAD", -- Shadowcloth
	[56002] = "EBON", -- Ebonweave
	[56003] = "SWEV", -- Spellweave
	[56001] = "SHRD", -- Moonshroud
	
	-- Jewelcrafting
	
	[47280] = "GLSS", -- BrilliantGlass
	[62242] = "ICYP", -- Icy Prism
	
	-- Inscription

	[61288] = "INSC", -- InscriptionResearch
	[61177] = "INSN", -- NorthrendInscriptionResearch
	
	-- Mining
	
	[55208] = "TITN", -- Smelt Titansteel
}

GroupCalendar.TradeskillCooldownEventInfo =
{
	-- Alchemy
	
	XMUT = {EventTitle = GroupCalendar.cTransmuteCooldownEventName},
	ALCH = {EventTitle = GroupCalendar.cAlchemyResearchCooldownEventName},
	
	-- Tailoring
	
	MOON = {EventTitle = GroupCalendar.cMoonclothCooldownEventName},
	PMON = {EventTitle = GroupCalendar.cPrimalMoonclothCooldownEventName},
	SPEL = {EventTitle = GroupCalendar.cSpellclothCooldownEventName},
	SHAD = {EventTitle = GroupCalendar.cShadowclothCooldownEventName},
	EBON = {EventTitle = GroupCalendar.cEbonweaveCooldownEventName},
	SWEV = {EventTitle = GroupCalendar.cSpellweaveCooldownEventName},
	SHRD = {EventTitle = GroupCalendar.cMoonshroudCooldownEventName},
	
	-- Jewelcrafting
	
	GLSS = {EventTitle = GroupCalendar.cBrilliantGlassCooldownEventName},
	ICYP = {EventTitle = GroupCalendar.cIcyPrismCooldownEventName},
	
	-- Inscription

	INSC = {EventTitle = GroupCalendar.cInscriptionCooldownEventName},
	INSN = {EventTitle = GroupCalendar.cInscription2CooldownEventName},
	
	-- Mining
	
	TITN = {EventTitle = GroupCalendar.cTitansteelCooldownEventName},
	
	-- Leatherworking
	
	SALT = {EventTitle = GroupCalendar.cSaltShakerCooldownEventName},
	
	-- Enchanting
	
	VOID = {EventTitle = GroupCalendar.cVoidShatterCooldownEventName},
	SPHR = {EventTitle = GroupCalendar.cVoidSphereCooldownEventName},
}

function GroupCalendar._Tradeskill:Construct()
	self.Orig_DoTradeSkill = DoTradeSkill
	DoTradeSkill = function (...) self:DoTradeSkill(...) end
	
	GroupCalendar.EventLib:RegisterEvent("TRADE_SKILL_SHOW", self.TradeSkillShow, self)
	GroupCalendar.EventLib:RegisterEvent("TRADE_SKILL_UPDATE", self.UpdateCurrentTradeskillCooldown, self)
	GroupCalendar.EventLib:RegisterEvent("TRADE_SKILL_CLOSE", self.TradeSkillClose, self)
end

function GroupCalendar._Tradeskill:TradeSkillShow()
	self.TradeSkillOpen = true
	self:UpdateCurrentTradeskillCooldown()
end

function GroupCalendar._Tradeskill:TradeSkillClose()
	self.TradeSkillOpen = false
	
	if self.NewEvent then
		if self.NewEvent:IsOpened() then
			self.NewEvent:Save()
		end
		
		self.NewEvent = nil
	end
end

function GroupCalendar._Tradeskill:DoTradeSkill(...)
	return self.Orig_DoTradeSkill(...)
end

function GroupCalendar._Tradeskill:UpdateCurrentTradeskillCooldown()
	if GroupCalendar.Data.Prefs.DisableTradeskills then
		return
	end
	
	local vServerDate, vServerTime = GroupCalendar.DateLib:GetServerDateTime()
	local vNumSkills = GetNumTradeSkills()
	
	for vSkillIndex = 1, vNumSkills do
		local vLink = GetTradeSkillRecipeLink(vSkillIndex)
		local vSpellID
		
		if vLink then
			_, _, vSpellID = vLink:find("|Henchant:(%d+)")
			vSpellID = tonumber(vSpellID)
		end
		
		local vCooldownID = vSpellID and self.TradeskillCooldownIDs[vSpellID]
		
		if vCooldownID then
			local vCooldown = GetTradeSkillCooldown(vSkillIndex)
			
			if vCooldown and vCooldown > 0 then
				local vCooldownDate, vCooldownTime = GroupCalendar.DateLib:AddOffsetToDateTime(vServerDate, vServerTime, vCooldown / 60)
				local vMonth, vDay, vYear = GroupCalendar.DateLib:ConvertDateToMDY(vCooldownDate)
				local vHour, vMinute = GroupCalendar.DateLib:ConvertTimeToHM(vCooldownTime)
				
				-- Add an event for the new cooldown if there isn't already one
				
				if not self:HasCooldownIDEvent(vCooldownID, vMonth, vDay, vYear) then
					self.NewEvent = GroupCalendar.Calendars.PLAYER:NewEvent(vMonth, vDay, vYear, "PLAYER")
					
					self.NewEvent:Open()
					self.NewEvent:SetTitle(GroupCalendar.TradeskillCooldownEventInfo[vCooldownID].EventTitle)
					self.NewEvent:SetTitleTag(vCooldownID)
					self.NewEvent:SetType(CALENDAR_EVENTTYPE_OTHER, 1)
					self.NewEvent:SetTime(vHour, vMinute)
					self.NewEvent:SetDuration(nil)
				end -- if not HasCooldownIDEvent
				
				-- Delete any older occurances of this cooldown
				
				for vDate = vCooldownDate - 30, vCooldownDate - 1 do
					local vMonth, vDay, vYear = GroupCalendar.DateLib:ConvertDateToMDY(vDate)
					local vMonthOffset = CalendarGetMonthOffset(vMonth, vYear)
					local vNumEvents = CalendarGetNumDayEvents(vMonthOffset, vDay) 
					
					for vEventIndex = 1, vNumEvents do
						local vTitle, vHour, vMinute,
							  vCalendarType, vSequenceType, vEventType,
							  vTextureID,
							  vModStatus, vInviteStatus, vInvitedBy = CalendarGetDayEvent(vMonthOffset, vDay, vEventIndex)
						local vTitleTag = CalendarEventGetTitleTag()
						
						if vTitleTag == vCooldownID then
							CalendarContextEventRemove(vMonthOffset, vDay, vEventIndex)
							break
						end
					end -- for vEventIndex
				end -- for vDate
			end -- if vCooldown
		end -- if vCooldownID
	end -- for vSkillIndex
end

function GroupCalendar._Tradeskill:HasCooldownIDEvent(pCooldownID, pMonth, pDay, pYear)
	local vNumEvents = CalendarGetNumAbsDayEvents(pMonth, pDay, pYear)
	
	for vEventIndex = 1, vNumEvents do
		local vTitle, vHour, vMinute = CalendarGetAbsDayEvent(pMonth, pDay, pYear, vEventIndex)
		local vTitleTag = CalendarEventGetTitleTag()

		if vTitleTag == pCooldownID then
			return true, vEventIndex
		end
	end
end
