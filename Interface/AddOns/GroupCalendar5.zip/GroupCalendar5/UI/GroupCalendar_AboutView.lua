--[[
			<Frame name="GroupCalendarAboutFrame" hidden="true" setAllPoints="true">
				<Layers>
					<Layer level="BACKGROUND">
						<Texture file="Interface\Addons\GroupCalendar\Textures\GuildLogo">
							<Size>
								<AbsDimension x="256" y="256"/>
							</Size>
							<Anchors>
								<Anchor point="CENTER">
									<Offset>
										<AbsDimension x="7" y="-25"/>
									</Offset>
								</Anchor>
							</Anchors>
						</Texture>
					</Layer>
					<Layer level="OVERLAY">
						<FontString text="GroupCalendar_cAboutTitle" inherits="GameFontNormalLarge">
							<Anchors>
								<Anchor point="TOP">
									<Offset>
										<AbsDimension x="17" y="-48"/>
									</Offset>
								</Anchor>
							</Anchors>
						</FontString>
						<FontString name="GroupCalendarAboutTitleVersion" text="GroupCalendar_cTitleVersion" inherits="GameFontNormalLarge">
							<Anchors>
								<Anchor point="TOP">
									<Offset>
										<AbsDimension x="7" y="-82"/>
									</Offset>
								</Anchor>
							</Anchors>
						</FontString>
						<FontString name="GroupCalendarAboutAuthor" text="GroupCalendar_cAuthor" inherits="GameFontHighlight">
							<Size x="310" y="0"/>
							<Anchors>
								<Anchor point="TOP" relativeTo="GroupCalendarAboutTitleVersion" relativePoint="BOTTOM">
									<Offset>
										<AbsDimension x="0" y="-5"/>
									</Offset>
								</Anchor>
							</Anchors>
						</FontString>
						<FontString name="GroupCalendarTestersTitle" text="GroupCalendar_cTestersTitle" inherits="GameFontNormal">
							<Size>
								<AbsDimension x="310" y="0"/>
							</Size>
							<Anchors>
								<Anchor point="TOP" relativeTo="GroupCalendarAboutAuthor" relativePoint="BOTTOM">
									<Offset>
										<AbsDimension x="0" y="-10"/>
									</Offset>
								</Anchor>
							</Anchors>
						</FontString>
						<FontString name="GroupCalendarTestersNames" text="GroupCalendar_cTestersNames" inherits="GameFontHighlightSmall">
							<Size>
								<AbsDimension x="310" y="0"/>
							</Size>
							<Anchors>
								<Anchor point="TOP" relativeTo="GroupCalendarTestersTitle" relativePoint="BOTTOM">
									<Offset>
										<AbsDimension x="0" y="-5"/>
									</Offset>
								</Anchor>
							</Anchors>
						</FontString>
						<FontString name="GroupCalendarSpecialThanksTitle" text="GroupCalendar_cSpecialThanksTitle" inherits="GameFontNormal">
							<Size>
								<AbsDimension x="310" y="0"/>
							</Size>
							<Anchors>
								<Anchor point="TOP" relativeTo="GroupCalendarTestersNames" relativePoint="BOTTOM">
									<Offset>
										<AbsDimension x="0" y="-10"/>
									</Offset>
								</Anchor>
							</Anchors>
						</FontString>
						<FontString name="GroupCalendarSpecialThanksNames" text="GroupCalendar_cSpecialThanksNames" inherits="GameFontHighlight">
							<Size>
								<AbsDimension x="310" y="0"/>
							</Size>
							<Anchors>
								<Anchor point="TOP" relativeTo="GroupCalendarSpecialThanksTitle" relativePoint="BOTTOM">
									<Offset>
										<AbsDimension x="0" y="-5"/>
									</Offset>
								</Anchor>
							</Anchors>
						</FontString>
						<FontString name="GroupCalendarGuildURL" text="GroupCalendar_cGuildURL" inherits="GameFontHighlightSmall">
							<Size>
								<AbsDimension x="310" y="0"/>
							</Size>
							<Anchors>
								<Anchor point="BOTTOM">
									<Offset>
										<AbsDimension x="7" y="68"/>
									</Offset>
								</Anchor>
							</Anchors>
						</FontString>
						<FontString name="GroupCalendarTranslation" text="GroupCalendar_cTranslationCredit" inherits="GameFontHighlightSmall">
							<Size>
								<AbsDimension x="310" y="0"/>
							</Size>
							<Anchors>
								<Anchor point="BOTTOM" relativeTo="GroupCalendarGuildURL" relativePoint="TOP">
									<Offset>
										<AbsDimension x="0" y="10"/>
									</Offset>
								</Anchor>
							</Anchors>
						</FontString>
					</Layer>
				</Layers>
				<Frames>
					<Button name="GroupCalendarVersionsButton" hidden="false">
						<Size>
							<AbsDimension x="64" y="32"/>
						</Size>
						<Anchors>
							<Anchor point="TOPRIGHT">
								<Offset>
									<AbsDimension x="0" y="-40"/>
								</Offset>
							</Anchor>
						</Anchors>
						<Scripts>
							<OnClick>
								GroupCalendar_ToggleVersionsFrame()
							</OnClick>
							<OnEnter>
								GroupCalendar.GameTooltip_AddNewbieTip(self, GroupCalendar_cToggleVersionsTitle, 1.0, 1.0, 1.0, GroupCalendar_cToggleVersionsDescription, 1)
							</OnEnter>
							<OnLeave>
								GameTooltip:Hide()
							</OnLeave>
						</Scripts>
						<NormalTexture file="Interface\Addons\GroupCalendar\Textures\VersionsButton">
							<TexCoords left="0" right="1" top="0" bottom="0.5" />
						</NormalTexture>
						<PushedTexture file="Interface\Addons\GroupCalendar\Textures\VersionsButton">
							<TexCoords left="0" right="1" top="0.5" bottom="1" />
						</PushedTexture>
						<HighlightTexture file="Interface\Buttons\UI-Common-MouseHilight" alphaMode="ADD" />
					</Button>
					<Button name="GroupCalendarRebuildButton" inherits="UIPanelButtonTemplate" text="GroupCalendar_cRebuildDatabase">
						<Size>
							<AbsDimension x="250" y="21"/>
						</Size>
						<Anchors>
							<Anchor point="BOTTOM">
								<Offset>
									<AbsDimension x="7" y="40"/>
								</Offset>
							</Anchor>
						</Anchors>
						<Scripts>
							<OnClick>
								PlaySound("igMainMenuOptionCheckBoxOn")
								GroupCalendar.Database.RebuildPlayerDatabases()
							</OnClick>
							<OnEnter>
								GroupCalendar.GameTooltip_AddNewbieTip(self, GroupCalendar_cRebuildDatabase, 1.0, 1.0, 1.0, GroupCalendar_cRebuildDatabaseDescription, 1)
							</OnEnter>
							<OnLeave>
								GameTooltip:Hide()
							</OnLeave>
						</Scripts>
					</Button>
				</Frames>
			</Frame>
			
]]