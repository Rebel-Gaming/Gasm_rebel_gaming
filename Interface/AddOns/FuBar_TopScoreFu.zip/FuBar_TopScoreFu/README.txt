FuBar - Top ScoreFu v1.1 $Revision: 73 $



Author: ckknight (ckknight@gmail.com)

$Date: 2007-01-23 23:43:23 +0000 (Tue, 23 Jan 2007) $



Keeps track of your top hits, heals, criticals, etc.



TO INSTALL: Put the FuBar_TopScore folder into

	\World of Warcraft\Interface\AddOns\



If you find _any_ bugs, feel free to submit them at

http://ckknight.wowinterface.com/portal.php?id=54&a=listbugs



If you want to request any features, feel free to submit your ideas at

http://ckknight.wowinterface.com/portal.php?id=54&a=listfeatures