local L = AceLibrary("AceLocale-2.2"):new("TopScoreFu")

L:RegisterTranslations("esES", function()
	return {
		["NAME"] = "FuBar - Top ScoreFu",
		["DESCRIPTION"] = "Informa sobre tus m\195\161ximos golpes, curaciones, cr\195\173ticos, etc",
		["COMMANDS"] = {"/topfu", "/tsfu", "/topscorefu"},

		["ARGUMENT_SHOWSPLASH"] = "mostrarTexto",
		["ARGUMENT_PLAYNOISE"] = "reproducirSonido",
		["ARGUMENT_SCREENSHOT"] = "screenshot",
		["ARGUMENT_HEALING"] = "curacion",
		["ARGUMENT_DAMAGE"] = "da\195\177o",
		["ARGUMENT_ONLYPVP"] = "soloJcJ",
		["ARGUMENT_RESET"] = "reestablecer",
		["ARGUMENT_POSITION"] = "posicion",
		["ARGUMENT_SHOWTRIVIAL"] = "trivial",

		["MENU_SHOW_SPLASH"] = "Mostrar texto en pantalla",
		["MENU_PLAY_NOISE"] = "Reproducir sonido",
		["MENU_TAKE_SCREENSHOTS"] = "Tomar captura de pantalla",
		["MENU_INCLUDE_HEALING"] = "Incluir curaciones",
		["MENU_INCLUDE_DAMAGE"] = "Incluir da\195\177o",
		["MENU_VS_MONSTERS"] = "contra Monstruos",
		["MENU_RESET_SCORES"] = "Reestablecer puntuaciones",
		["MENU_SHOW_TRIVIAL"] = "Puntuaciones triviales",
		["MENU_FILTER"] = "Filtro",
		["MENU_PURGE"] = "Purgar",
	
		["TEXT_NORMAL"] = "Normal",
		["TEXT_CRITICAL"] = "Cr\195\173tico",
		["PATTERN_NORMAL_SPELL"] = "%s",
		["PATTERN_CRITICAL_SPELL"] = "Cr\195\173tico de %s",
		["TEXT_SCORES_RESET"] = "Puntuaciones reestablecidas",
		["TEXT_SET_POSITION_ERROR"] = "Debes introducir la posici\195\179n en el formato `x y`, donde x e y son n\195\186meros.",

		["HINT"] = "Clic-May\195\186sculas para introducir tus puntuaciones m\195\161ximas en la caja de edici\195\179n de chat.\n Haz clic en un hechizo para introducir su puntuaci\195\179n.",

		["PATTERN_NEW_CRITICAL_RECORD"] = "\194\161Nuevo r\195\169cord de cr\195\173tico de %s!\n|cffffffff%d|r",
		["PATTERN_NEW_NORMAL_RECORD"] = "\194\161Nuevo r\195\169cord de %s!\n|cffffffff%d|r",
		["PATTERN_SET_POSITION"] = "La posici\195\179n es ahora %d, %d",
	}
end)
