local L = AceLibrary("AceLocale-2.2"):new("TopScoreFu")

L:RegisterTranslations("enUS", function()
	return {
		["NAME"] = "FuBar - Top ScoreFu",
		["DESCRIPTION"] = "Keeps track of your top hits, heals, criticals, etc.",
		["COMMANDS"] = {"/topfu", "/tsfu", "/topscorefu"},

		["ARGUMENT_SHOWSPLASH"] = "showSplash",
		["ARGUMENT_PLAYNOISE"] = "playNoise",
		["ARGUMENT_SCREENSHOT"] = "screenshot",
		["ARGUMENT_HEALING"] = "healing",
		["ARGUMENT_DAMAGE"] = "damage",
		["ARGUMENT_ONLYPVP"] = "onlyPvP",
		["ARGUMENT_RESET"] = "reset",
		["ARGUMENT_POSITION"] = "position",
		["ARGUMENT_SHOWTRIVIAL"] = "trivial",

		["MENU_SHOW_SPLASH"] = "Show splash",
		["MENU_SHOW_SOAR"] = "Show as notification in SCT type addons",
		["MENU_PLAY_NOISE"] = "Play noise",
		["MENU_TAKE_SCREENSHOTS"] = "Take screenshots",
		["MENU_INCLUDE_HEALING"] = "Include healing",
		["MENU_INCLUDE_DAMAGE"] = "Include damage",
		["MENU_VS_MONSTERS"] = "vs. Monsters",
		["MENU_RESET_SCORES"] = "Reset scores",
		["MENU_SHOW_TRIVIAL"] = "Trivial scores",
		["MENU_IGNORE_VULNERABLE"] = "Ignore vulnerable mobs",
		["MENU_FILTER"] = "Filter",
		["MENU_PURGE"] = "Purge",
	
		["TEXT_NORMAL"] = "Normal",
		["TEXT_CRITICAL"] = "Critical",
		["PATTERN_NORMAL_SPELL"] = "%s",
		["PATTERN_CRITICAL_SPELL"] = "Critical %s",
		["TEXT_SCORES_RESET"] = "Scores reset",
		["TEXT_SET_POSITION_ERROR"] = "You must give the position in the form of `x y`, where x and y are numbers.",

		["HINT"] = "Shift-Click to insert your highest scores in chat edit box.\nHint: Click a spell to insert its score.",

		["PATTERN_NEW_CRITICAL_RECORD"] = "New critical %s record!\n|cffffffff%d|r",
		["PATTERN_NEW_NORMAL_RECORD"] = "New %s record!\n|cffffffff%d|r",
		["PATTERN_SET_POSITION"] = "Position now %d, %d",

		["Output"] = "Output",

		-- Mobs with silly vulnerabilities
		["VULNERABLE_MOBS"] = {
			--[[ Instances ]]--
			-- Blackwing Lair
			"Death Talon Overseer",
			"Death Talon Wyrmguard",
			-- Tempest Keep: The Eye
			"Phoenix",
			"Phoenix Egg",
			-- Black Temple
			"Priestess of Dementia",
			-- Magisters' Terrace
			"Pure Energy",
			-- [[ Outlands ]]
			-- Netherstorm
			"Socrethar",
			-- Terokkar: Skettis
			"Terokk",
			-- Terokkar: Quest: The Hawk's Essence
			"Guardian of the Hawk",
			-- Ogri'la: Shartuul Event
			"Eye of Shartuul",
			"Dreadmaw",
			"Shatruul",
		},
	}
end)
