local L = AceLibrary("AceLocale-2.2"):new("TopScoreFu")

L:RegisterTranslations("zhTW", function()
	return {
		["NAME"] = "FuBar - 紀錄",
		["DESCRIPTION"] = "追蹤記錄你的傷害、治療、致命一擊等紀錄。",
		["COMMANDS"] = {"/topfu", "/tsfu", "/topscorefu"},

		["ARGUMENT_SHOWSPLASH"] = "顯示跳躍文字",
		["ARGUMENT_PLAYNOISE"] = "聲音提示",
		["ARGUMENT_SCREENSHOT"] = "抓圖",
		["ARGUMENT_HEALING"] = "治療量",
		["ARGUMENT_DAMAGE"] = "傷害",
		["ARGUMENT_ONLYPVP"] = "只紀錄 PvP",
		["ARGUMENT_RESET"] = "重置",
		["ARGUMENT_POSITION"] = "位置",
		["ARGUMENT_SHOWTRIVIAL"] = "其它",

		["MENU_SHOW_SPLASH"] = "显示訊息",
		["MENU_SHOW_SOAR"] = "在 SCT 类插件中顯示通知",
		["MENU_PLAY_NOISE"] = "提示音效",
		["MENU_TAKE_SCREENSHOTS"] = "自動抓圖",
		["MENU_INCLUDE_HEALING"] = "包含治療",
		["MENU_INCLUDE_DAMAGE"] = "包含傷害",
		["MENU_VS_MONSTERS"] = "記錄對怪物戰斗",
		["MENU_RESET_SCORES"] = "重置記錄",
		["MENU_SHOW_TRIVIAL"] = "顯示次要記錄",
		["MENU_IGNORE_VULNERABLE"] = "屏蔽脆弱的怪物",
		["MENU_FILTER"] = "過濾",
		["MENU_PURGE"] = "合并",
	
		["TEXT_NORMAL"] = "普通",
		["TEXT_CRITICAL"] = "致命一擊",
		["PATTERN_NORMAL_SPELL"] = "%s",
		["PATTERN_CRITICAL_SPELL"] = "致命一擊 %s",
		["TEXT_SCORES_RESET"] = "紀錄重置",
		["TEXT_SET_POSITION_ERROR"] = "必須用 x y 的格式設置位置，x 和 y 都是數字。",

		["HINT"] = "Shift-點擊在聊天輸入框中插入你的最高紀錄。",

		["PATTERN_NEW_CRITICAL_RECORD"] = "新%s致命一擊記錄！\n|cffffffff%d|r",
		["PATTERN_NEW_NORMAL_RECORD"] = "新%s紀錄！\n|cffffffff%d|r",
		["PATTERN_SET_POSITION"] = "位置設定為：%d, %d",

		["Output"] = "輸出",

		-- Mobs with silly vulnerabilities
		["VULNERABLE_MOBS"] = {
			--[[ Instances ]]--
			-- Blackwing Lair
			"死爪監督者",
			"死爪龍人護衛",
			-- Tempest Keep: The Eye
			"鳳凰",
			"鳳凰蛋",
			-- Black Temple
			"退化女祭司",
			-- Magisters' Terrace
			"纯净能量",
			-- [[ Outlands ]]
			-- Netherstorm
			"索奎薩爾",
			-- Terokkar: Skettis
			"泰洛克",
			-- Terokkar: Quest: The Hawk's Essence
			"獵鷹守護者",
			-- Ogri'la: Shartuul Event
			"夏圖歐之眼",
			"巨齒",
			"夏圖歐",
		},
	}
end)
