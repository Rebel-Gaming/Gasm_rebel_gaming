﻿--ruRU by Swix
--Report bugs to http://forums.playhard.ru/index.php?showforum=49
local L = AceLibrary("AceLocale-2.2"):new("TopScoreFu")

L:RegisterTranslations("ruRU", function()
	return {
		["NAME"] = "FuBar - Top ScoreFu",
		["DESCRIPTION"] = "Отслеживание ваших лучших ударов, лечений, критов и т.п.",
		["COMMANDS"] = {"/topfu", "/tsfu", "/topscorefu"},

		["ARGUMENT_SHOWSPLASH"] = "показ Всплеском",
		["ARGUMENT_PLAYNOISE"] = "играть Шум",
		["ARGUMENT_SCREENSHOT"] = "скриншот",
		["ARGUMENT_HEALING"] = "лечение",
		["ARGUMENT_DAMAGE"] = "урон",
		["ARGUMENT_ONLYPVP"] = "только PvP",
		["ARGUMENT_RESET"] = "обновить",
		["ARGUMENT_POSITION"] = "позиция",
		["ARGUMENT_SHOWTRIVIAL"] = "обычно",

		["MENU_SHOW_SPLASH"] = "Показывать всплывающие сообщения",
		["MENU_SHOW_SOAR"] = "Показывать сообщения по типу SCT аддона",
		["MENU_PLAY_NOISE"] = "Проигрывать звук",
		["MENU_TAKE_SCREENSHOTS"] = "Делать скриншоты",
		["MENU_INCLUDE_HEALING"] = "Отслеживать лечение",
		["MENU_INCLUDE_DAMAGE"] = "Отслеживать урон",
		["MENU_VS_MONSTERS"] = "Против Монстров",
		["MENU_RESET_SCORES"] = "Сбросить очки",
		["MENU_SHOW_TRIVIAL"] = "Обычные удары",
		["MENU_IGNORE_VULNERABLE"] = "Игнорировать уязвимых мобов",
		["MENU_FILTER"] = "Фильтр",
		["MENU_PURGE"] = "Очистка",
	
		["TEXT_NORMAL"] = "Нормальный",
		["TEXT_CRITICAL"] = "Критический",
		["PATTERN_NORMAL_SPELL"] = "%s",
		["PATTERN_CRITICAL_SPELL"] = "Критический %s",
		["TEXT_SCORES_RESET"] = "Сбросить цифры",
		["TEXT_SET_POSITION_ERROR"] = "вы  должны задать позицию в форме  `x y`, где x и y числа.",

		["HINT"] = "Щёлкните по заклинанию, чтобы вставить результаты в чат (с зажатой клавишей Shift вставится самый высокий результат).",

		["PATTERN_NEW_CRITICAL_RECORD"] = "%s - новый критический рекорд!\n|cffffffff%d|r",
		["PATTERN_NEW_NORMAL_RECORD"] = "%s - новый рекорд!\n|cffffffff%d|r",
		["PATTERN_SET_POSITION"] = "Позиция теперь %d, %d",
	}
end)
