-- 
-- LoracksdkO
-- An addon by Big Mike, aka Lorack
-- Let's kick ass
--

-- Our base array
LoracksdkO = {}

-- Face Melter variables NOT SAVED

LoracksdkO.versionNumber = 1.22
LoracksdkO.currentTarget = ""
LoracksdkO.currentSpell = ""
LoracksdkO.lastTarget = ""
LoracksdkO.npcList = {} -- {guid, name}
LoracksdkO.plagueList = {}  -- {guid, GetTime}
LoracksdkO.icyList = {} -- {guid, GetTime}
LoracksdkO.blightTime = 0
LoracksdkO.lockRunic = false
LoracksdkO.runetapTime = 0
LoracksdkO.iceboundTime = 0
LoracksdkO.lichborneTime = 0
LoracksdkO.shieldTime = 0
LoracksdkO.shieldDown = true
LoracksdkO.DnDTime = 0
LoracksdkO.pestTime = 0
LoracksdkO.freezingFog = false
LoracksdkO.howlingTime = 0
LoracksdkO.rsTime = 0
LoracksdkO.hornTime = 0
LoracksdkO.mindfreezetime = 0
LoracksdkO.strangulateTime = 0
LoracksdkO.badbad = 0
LoracksdkO.bloodTapTime = 0
LoracksdkO.suddenDoom = 0
LoracksdkO.ps = false
LoracksdkO.it = false



LoracksdkO.timeSinceLastUpdate = 0


LoracksdkO.playerName = UnitName("player");
LoracksdkO.spellHaste = GetCombatRatingBonus(20)

LoracksdkO.textureList = {
  ["last"] = nil,
  ["current"] = nil,
  ["next"] = nil,
  ["misc"] = nil,
  ["int"] = nil,
  }
  
LoracksdkO.SL = {
  ["Blood Boil"] = GetSpellInfo(48721),
  ["Blood Strike"] = GetSpellInfo(45902),
  ["Blood Tap"] = GetSpellInfo(45529),
  ["Pestilence"] = GetSpellInfo(50842),
  ["Strangulate"] = GetSpellInfo(47476),
  ["Horn of Winter"] = GetSpellInfo(57330),
  ["Icebound Fortitude"] = GetSpellInfo(48792),
  ["Icy Touch"] = GetSpellInfo(45477),
  ["Mind Freeze"] = GetSpellInfo(47528),
  ["Obliterate"] = GetSpellInfo(49020),
  ["Rune Strike"] = GetSpellInfo(56815),
  ["Bone Shield"] = GetSpellInfo(49222),
  ["Death and Decay"] = GetSpellInfo(43265),
  ["Death Coil"] = GetSpellInfo(52375),
  ["Death Strike"] = GetSpellInfo(49998),
  ["Plague Strike"] = GetSpellInfo(45462),
  ["Scourge Strike"] = GetSpellInfo(55265),
  ["Unholy Blight"] = GetSpellInfo(51376),
  ["Rune Tap"] = GetSpellInfo(48982),
  ["Vampiric Blood"] = GetSpellInfo(55233),
  ["Heart Strike"] = GetSpellInfo(55258),
  ["Lichborne"] = GetSpellInfo(49039),
  ["Howling Blast"] = GetSpellInfo(51408),
  ["Unbreakable Armor"] = GetSpellInfo(51271),
  ["Frost Strike"] = GetSpellInfo(51416),
  ["Frost Fever"] = GetSpellInfo(55095),
  ["Blood Plague"] = GetSpellInfo(55078),
  

}


-- Our sneaky frame to watch for events ... checks LoracksdkO.events[] for the function.  Passes all args.
LoracksdkO.eventFrame = CreateFrame("Frame")
LoracksdkO.eventFrame:SetScript("OnEvent", function(this, event, ...)
  LoracksdkO.events[event](...)
end)

LoracksdkO.eventFrame:RegisterEvent("ADDON_LOADED")
LoracksdkO.eventFrame:RegisterEvent("PLAYER_LOGIN")
LoracksdkO.eventFrame:RegisterEvent("PLAYER_ALIVE")


-- Define our Event Handlers here
LoracksdkO.events = {}

function LoracksdkO.events.PLAYER_ALIVE()
	LoracksdkO:CheckStuff()
	LoracksdkO.eventFrame:UnregisterEvent("PLAYER_ALIVE")
end

function LoracksdkO.events.PLAYER_LOGIN()
  LoracksdkO.playerName = UnitName("player");

  LoracksdkO.spellHaste = GetCombatRatingBonus(20)
 
  
end

function LoracksdkO.events.ADDON_LOADED(addon)
  if addon ~= "LoracksdkO" then return end
  local _,playerClass = UnitClass("player")
  if playerClass ~= "DEATHKNIGHT" then
	LoracksdkO.eventFrame:UnregisterEvent("PLAYER_ALIVE")
	return 
  end
  
  
  -- Default saved variables
  if not LoracksdkOdb then
	LoracksdkOdb = {} -- fresh start
  end
  if not LoracksdkOdb.scale then LoracksdkOdb.scale = 1 end
  if LoracksdkOdb.locked == nil then LoracksdkOdb.locked = false end
  if not LoracksdkOdb.x then LoracksdkOdb.x = 100 end
  if not LoracksdkOdb.y then LoracksdkOdb.y = 100 end
  if LoracksdkOdb.modeSingle == nil then LoracksdkOdb.modeSingle = true end
  if LoracksdkOdb.modeAoE == nil then LoracksdkOdb.modeAoE = true end
  if LoracksdkOdb.modeDefensive == nil then LoracksdkOdb.modeDefensive = true end
  if LoracksdkOdb.modeMisc == nil then LoracksdkOdb.modeMisc = true end
  if LoracksdkOdb.modeInt == nil then LoracksdkOdb.modeInt = true end
  if LoracksdkOdb.horn == nil then LoracksdkOdb.horn = true end
  if not LoracksdkOdb.healthPercent then LoracksdkOdb.healthPercent = 75 end
  if LoracksdkOdb.bloodfirst == nil then LoracksdkOdb.bloodfirst = true end
  if LoracksdkOdb.DSMid == nil then LoracksdkOdb.DSMid = false end
  if LoracksdkOdb.HowlingFirst == nil then LoracksdkOdb.HowlingFirst = false end
  
  
  -- Create GUI
  LoracksdkO:CreateGUI()
  LoracksdkO.displayFrame:SetScale(LoracksdkOdb.scale)
  
  
  -- Create Options Frame
  LoracksdkO:CreateOptionFrame()
  if LoracksdkOdb.locked then
    LoracksdkO.displayFrame:SetScript("OnMouseDown", nil)
    LoracksdkO.displayFrame:SetScript("OnMouseUp", nil)
    LoracksdkO.displayFrame:SetScript("OnDragStop", nil)
    LoracksdkO.displayFrame:SetBackdropColor(0, 0, 0, 0)
	LoracksdkO.displayFrame:EnableMouse(false)
  else
    LoracksdkO.displayFrame:SetScript("OnMouseDown", function(self) self:StartMoving() end)
    LoracksdkO.displayFrame:SetScript("OnMouseUp", function(self) self:StopMovingOrSizing() end)
    LoracksdkO.displayFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    LoracksdkO.displayFrame:SetBackdropColor(0, 0, 0, .4)
	LoracksdkO.displayFrame:EnableMouse(true)
  end
  
  -- Register for Slash Commands
  SlashCmdList["LoracksdkO"] = LoracksdkO.Options
  SLASH_LoracksdkO1 = "/LoracksdkO"
  SLASH_LoracksdkO2 = "/fs"
  
  -- Register for Function Events
  LoracksdkO.eventFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
  LoracksdkO.eventFrame:RegisterEvent("COMBAT_RATING_UPDATE") -- Monitor the all-mighty haste
  LoracksdkO.eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
  LoracksdkO.eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED") -- Left combat, clean up all enemy GUIDs
  LoracksdkO.eventFrame:RegisterEvent("UNIT_INVENTORY_CHANGED")
  LoracksdkO.eventFrame:RegisterEvent("CHARACTER_POINTS_CHANGED")
  LoracksdkO.eventFrame:RegisterEvent("RUNE_POWER_UPDATE") -- hey, we're a deathknight
  LoracksdkO.eventFrame:RegisterEvent("RUNE_TYPE_UPDATE")
  LoracksdkO.eventFrame:RegisterEvent("GLYPH_ADDED")
  LoracksdkO.eventFrame:RegisterEvent("GLYPH_REMOVED")
  LoracksdkO.eventFrame:RegisterEvent("GLYPH_UPDATED")
  
end

function LoracksdkO.events.COMBAT_LOG_EVENT_UNFILTERED(timestamp, event, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, ...)
  if srcName == LoracksdkO.playerName then
    if event == "SPELL_CAST_SUCCESS" then
        local sid, spellName = ...
        if spellName == LoracksdkO.SL["Plague Strike"] then
          LoracksdkO.currentSpell = "Plague Strike"
          LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Icy Touch"] then
          LoracksdkO.currentSpell = "Icy Touch"
          LoracksdkO:DecideSpells()
        elseif spellName == LoracksdkO.SL["Blood Strike"] then
          LoracksdkO.currentSpell = "Blood Strike"
          LoracksdkO:DecideSpells()
        elseif spellName == LoracksdkO.SL["Scourge Strike"] then
          LoracksdkO.currentSpell = "Scourge Strike"
          LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Unholy Blight"] then
          LoracksdkO.currentSpell = "Unholy Blight"
		  LoracksdkO.blightTime = GetTime()
          LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Death Coil"] then
          LoracksdkO.currentSpell = "Death Coil"
		  LoracksdkO.suddenDoom = 0
          LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Rune Tap"] then
			LoracksdkO.runetapTime = GetTime()
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Blood Tap"] then
			LoracksdkO.bloodTapTime = GetTime()
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Vampiric Blood"] or spellName == LoracksdkO.SL["Unbreakable Armor"] or spellName == LoracksdkO.SL["Bone Shield"] then
			LoracksdkO.shieldTime = GetTime()
			LoracksdkO.shieldDown = false;
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Death and Decay"] then
			LoracksdkO.DnDTime = GetTime()
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Pestilence"] then
			LoracksdkO.pestTime = GetTime()
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Howling Blast"] then
			LoracksdkO.howlingTime = GetTime()
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Rune Strike"] then
			LoracksdkO.rsTime = 0
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Mind Freeze"] then
			LoracksdkO.mindfreezetime = GetTime()
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Strangulate"] then
			LoracksdkO.strangulateTime = GetTime()
			LoracksdkO:DecideSpells()
		end
	elseif event == "SPELL_AURA_APPLIED" then
		local sid, spellName = ...
		if spellName == LoracksdkO.SL["Frost Fever"] then
			LoracksdkO.icyList[dstGUID] = GetTime()
		elseif spellName == LoracksdkO.SL["Blood Plague"] then
			LoracksdkO.plagueList[dstGUID] = GetTime()
		elseif spellName == LoracksdkO.SL["Summon Gargoyle"] then
			if dstName == LoracksdkO.playerName then
				LoracksdkO.lockRunic = true
			end	
		elseif spellName == LoracksdkO.SL["Lichborne"] then
			LoracksdkO.lichborneTime = GetTime()
			LoracksdkO.shieldDown = false
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Icebound Fortitude"] then
			LoracksdkO.iceboundTime = GetTime()
			LoracksdkO.shieldDown = false
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Freezing Fog"] then
			LoracksdkO.freezingFog = true;
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Horn of Winter"] then
			LoracksdkO.hornTime = GetTime()
			LoracksdkO:DecideSpells()
		elseif sid == 50466 then -- Sudden Doom proc
			LoracksdkO.suddenDoom = GetTime()
			LoracksdkO:DecideSpells()
		end
	elseif event == "SPELL_AURA_REMOVED" then
		local sid, spellName = ...
		if spellName == LoracksdkO.SL["Frost Fever"] then
			LoracksdkO.icyList[dstGUID] = 0
		elseif spellName == LoracksdkO.SL["Blood Plague"] then
			LoracksdkO.plagueList[dstGUID] = 0
		elseif sid == 50514 then -- Summon Gargoyle buff that matters
			if dstName == LoracksdkO.playerName then
				LoracksdkO.lockRunic = false
			end
		elseif spellName == LoracksdkO.SL["Vampiric Blood"] or spellName == LoracksdkO.SL["Unbreakable Armor"] or spellName == LoracksdkO.SL["Bone Shield"] or spellName == LoracksdkO.SL["Lichborne"] or spellName == LoracksdkO.SL["Icebound Fortitude"] then
			LoracksdkO.shieldDown = true;
			LoracksdkO:DecideSpells()
		elseif spellName == LoracksdkO.SL["Horn of Winter"] then
			LoracksdkO.hornTime = 0
			LoracksdkO:DecideSpells()
		end
	end
  else
	if event == "SPELL_AURA_REFRESH" then
		local sid, spellName = ...
		if spellName == LoracksdkO.SL["Frost Fever"] then
			LoracksdkO.icyList[dstGUID] = GetTime()
		elseif spellName == LoracksdkO.SL["Blood Plague"] then
			LoracksdkO.plagueList[dstGUID] = GetTime()
		elseif spellName == LoracksdkO.SL["Horn of Winter"] then
			LoracksdkO.hornTime = GetTime()
		end
	elseif event == "SWING_MISSED" and dstName == LoracksdkO.playerName then
		local missName = ...
		if missName == "PARRY" or missName == "DODGE" then
			LoracksdkO.rsTime = GetTime()
			LoracksdkO:DecideSpells()
		end
	end
  end
  
end

function LoracksdkO.events.COMBAT_RATING_UPDATE(unit)
  if unit == "player" then
    LoracksdkO.spellHaste = GetCombatRatingBonus(20) -- update spell haste
  end
end

function LoracksdkO.events.PLAYER_TARGET_CHANGED(...)
  -- target changed, set last target, update current target, will be nil if no target

  LoracksdkO.lastTarget = LoracksdkO.currentTarget
  LoracksdkO.currentTarget = UnitGUID("target")
  if UnitName("target") == nil or UnitIsFriend("player","target") ~= nil or UnitHealth("target") == 0 then
    LoracksdkO.displayFrame_last:Hide()
    LoracksdkO.displayFrame_current:Hide()
    LoracksdkO.displayFrame_next:Hide()
	LoracksdkO.displayFrame_misc:Hide()
	LoracksdkO.displayFrame_int:Hide()
  else
    LoracksdkO.displayFrame_last:Show()
    LoracksdkO.displayFrame_current:Show()
    LoracksdkO.displayFrame_next:Show()
	LoracksdkO.displayFrame_misc:Show()
	LoracksdkO.displayFrame_int:Show()
  end
  LoracksdkO:DecideSpells()
end

function LoracksdkO.events.PLAYER_REGEN_ENABLED(...)
  -- We have left combat, clean up GUIDs
  LoracksdkO.plagueList = {}  -- {guid, GetTime}
  LoracksdkO.icyList = {} -- {guid, GetTime}
end


function LoracksdkO.events.UNIT_INVENTORY_CHANGED(name)
  --if name == "player" then
  --  LoracksdkO:CheckStuff()
  --end
end

function LoracksdkO.events.CHARACTER_POINTS_CHANGED()
    LoracksdkO:CheckStuff()
end
function LoracksdkO.events.GLYPH_ADDED()
    LoracksdkO:CheckStuff()
end
function LoracksdkO.events.GLYPH_REMOVED()
    LoracksdkO:CheckStuff()
end
function LoracksdkO.events.GLYPH_CHANGED()
    LoracksdkO:CheckStuff()
end

function LoracksdkO.events.RUNE_POWER_UPDATE(rid, rstatus)
	if rstatus == true then
		if rid ~= 7 and rid ~= 8 then
		LoracksdkO:DecideSpells()
		end
	end
	--DEFAULT_CHAT_FRAME:AddMessage("Update: " .. rid .. "  Status: " .. tostring(rstatus))

end

function LoracksdkO.events.RUNE_TYPE_UPDATE(rid)
	
	local start, duration, runeReady = GetRuneCooldown(rid)
	if runeReady == true then
		LoracksdkO:DecideSpells()
	end
	
	--local rtype = GetRuneType(rid)
	--DEFAULT_CHAT_FRAME:AddMessage("Change: " .. rid .. "  Type: " .. rtype .. "  Cooldown: S-" .. start .. " D- " .. duration .. " R- " .. tostring(runeReady))
end

-- End Event Handlers




function LoracksdkO:CreateGUI()

  local displayFrame = CreateFrame("Frame","LoracksdkODisplayFrame",UIParent)
  displayFrame:SetFrameStrata("BACKGROUND")
  displayFrame:SetWidth(250)
  displayFrame:SetHeight(90)
  displayFrame:SetBackdrop({
          bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", tile = true, tileSize = 32,
  			})
  displayFrame:SetBackdropColor(0, 0, 0, .4)
  displayFrame:EnableMouse(true)
  displayFrame:SetMovable(true)
  --displayFrame:RegisterForDrag("LeftButton")  --causes right buttont to go crazy, go figure
  displayFrame:SetClampedToScreen(true)
  displayFrame:SetScript("OnMouseDown", function(self) self:StartMoving() end)
  displayFrame:SetScript("OnMouseUp", function(self) self:StopMovingOrSizing() end)
  displayFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

  displayFrame:SetPoint("CENTER",-200,-200)
  
  local displayFrame_last = CreateFrame("Frame","$parent_last", LoracksdkODisplayFrame)
  local displayFrame_current = CreateFrame("Frame","$parent_current", LoracksdkODisplayFrame)
  local displayFrame_next = CreateFrame("Frame","$parent_next", LoracksdkODisplayFrame)
  local displayFrame_misc = CreateFrame("Frame","$parent_misc", LoracksdkODisplayFrame)
  local displayFrame_int = CreateFrame("Frame","$parent_int", LoracksdkODisplayFrame)
  
  displayFrame_last:SetWidth(50)
  displayFrame_current:SetWidth(70)
  displayFrame_next:SetWidth(50)
  displayFrame_misc:SetWidth(40)
  displayFrame_int:SetWidth(40)
  
  displayFrame_last:SetHeight(50)
  displayFrame_current:SetHeight(70)
  displayFrame_next:SetHeight(50)
  displayFrame_misc:SetHeight(40)
  displayFrame_int:SetHeight(40)
  
  
  displayFrame_last:SetPoint("TOPLEFT", 0, -40)
  displayFrame_current:SetPoint("TOPLEFT", 90, -10)
  displayFrame_next:SetPoint("TOPLEFT", 200, -40)
  displayFrame_misc:SetPoint("TOPLEFT", 45, 0)
  displayFrame_int:SetPoint("TOPLEFT", 165, 0)
  
    
  local t = displayFrame_last:CreateTexture(nil,"BACKGROUND")
  t:SetTexture(nil)
  t:SetAllPoints(displayFrame_last)
  t:SetAlpha(.8)
  displayFrame_last.texture = t
  LoracksdkO.textureList["last"] = t
  
  t = displayFrame_current:CreateTexture(nil,"BACKGROUND")
  t:SetTexture(nil)
  t:ClearAllPoints()
  t:SetAllPoints(displayFrame_current)
  displayFrame_current.texture = t
  LoracksdkO.textureList["current"] = t


  
  t = displayFrame_next:CreateTexture(nil,"BACKGROUND")
  t:SetTexture(nil)
  t:SetAllPoints(displayFrame_next)
  t:SetAlpha(.8)
  displayFrame_next.texture = t
  LoracksdkO.textureList["next"] = t
  
  t = displayFrame_misc:CreateTexture(nil,"BACKGROUND")
  t:SetTexture(nil)
  t:SetAllPoints(displayFrame_misc)
  t:SetAlpha(.8)
  displayFrame_misc.texture = t
  LoracksdkO.textureList["misc"] = t
  
  t = displayFrame_int:CreateTexture(nil,"BACKGROUND")
  t:SetTexture(nil)
  t:SetAllPoints(displayFrame_int)
  t:SetAlpha(.8)
  displayFrame_int.texture = t
  LoracksdkO.textureList["int"] = t
  

  
  displayFrame:SetScript("OnUpdate", function(this, elapsed)
    LoracksdkO:OnUpdate(elapsed)
  end)
  
  local cooldownFrame = CreateFrame("Cooldown","$parent_cooldown", LoracksdkODisplayFrame_current)
  cooldownFrame:SetHeight(70)
  cooldownFrame:SetWidth(70)
  cooldownFrame:ClearAllPoints()
  cooldownFrame:SetPoint("CENTER", displayFrame_current, "CENTER", 0, 0)
  
  LoracksdkO.displayFrame = displayFrame
  LoracksdkO.displayFrame_last = displayFrame_last
  LoracksdkO.displayFrame_current = displayFrame_current
  LoracksdkO.displayFrame_next = displayFrame_next
  LoracksdkO.displayFrame_misc =  displayFrame_misc
  LoracksdkO.displayFrame_int =  displayFrame_int
  LoracksdkO.cooldownFrame = cooldownFrame
  
  
end



function LoracksdkO:OnUpdate(elapsed)
  LoracksdkO.timeSinceLastUpdate = LoracksdkO.timeSinceLastUpdate + elapsed;
  
  if (LoracksdkO.timeSinceLastUpdate > (1.5 - (1.5 * LoracksdkO.spellHaste * .01)) * 0.3) then
    LoracksdkO:DecideSpells()
  end

end


function LoracksdkO:DecideSpells()

  LoracksdkO.timeSinceLastUpdate = 0;
  local guid = UnitGUID("target")
  if  UnitName("target") == nil or UnitIsFriend("player","target") ~= nil or UnitHealth("target") == 0 then

	return -- ignore the dead and friendly
  end
  
  
  if guid == nil then
    LoracksdkO.textureList["last"]:SetTexture(nil)
    LoracksdkO.textureList["current"]:SetTexture(nil)
    LoracksdkO.textureList["next"]:SetTexture(nil)
	LoracksdkO.textureList["misc"]:SetTexture(nil)
	LoracksdkO.textureList["int"]:SetTexture(nil)

    return
  end  
  
  local runes = {0,0,0,0}
	 for i=1,6,1 do 
		local start, duration, runeReady = GetRuneCooldown(i)
		local runeType = GetRuneType(i)
		if runeReady then
			runes[runeType] = runes[runeType] + 1;
		end
	 end
  local runic = UnitPower("Player");
 
  local spell = ""
  local defspell = ""
  local aoespell = ""
  local miscspell = ""
  local intspell = ""
  
	if LoracksdkOdb.modeSingle then
		spell = LoracksdkO:NextSpell(runes, runic)
	end
	if LoracksdkOdb.modeDefensive then
		defspell = LoracksdkO:DefSpell(runes, runic)
	end
	if LoracksdkOdb.modeAoE then
		aoespell = LoracksdkO:AoESpell(runes, runic)
	end
	if LoracksdkOdb.modeMisc then
		miscspell = LoracksdkO:MiscSpell(runes, runic)
	end
	if LoracksdkOdb.modeInt then
		intspell = LoracksdkO:IntSpell(runes, runic)
	end
	
	if LoracksdkOdb.DSMid and defspell == LoracksdkO.SL["Death Strike"] then
		defspell = spell
		spell = LoracksdkO.SL["Death Strike"]
	end
			
   
   LoracksdkO.textureList["current"]:SetTexture(GetSpellTexture(spell))
   LoracksdkO.textureList["last"]:SetTexture(GetSpellTexture(defspell))
   LoracksdkO.textureList["misc"]:SetTexture(GetSpellTexture(miscspell))
   LoracksdkO.textureList["int"]:SetTexture(GetSpellTexture(intspell))
   
    if spell == LoracksdkO.SL["Plague Strike"] or spell == LoracksdkO.SL["Icy Touch"] then
		if aoespell == LoracksdkO.SL["Unholy Blight"] or aoespell == LoracksdkO.SL["Death and Decay"] then
			LoracksdkO.textureList["next"]:SetTexture(GetSpellTexture(aoespell))
		else
			LoracksdkO.textureList["next"]:SetTexture(nil)
		end
	else
		LoracksdkO.textureList["next"]:SetTexture(GetSpellTexture(aoespell))
	end
   
	if spell ~= "" and spell ~= nil then
	   local start, dur = GetSpellCooldown(spell)
		if dur == 0 then
			LoracksdkO.cooldownFrame:SetAlpha(0)
		else
			LoracksdkO.cooldownFrame:SetAlpha(1)
			LoracksdkO.cooldownFrame:SetCooldown(start, dur)
		end
	end
 
    
     
end

function LoracksdkO:NextSpell(runes, runic)

	local guid = UnitGUID("target")
	local currentTime = GetTime()
	local GCD = 1.5 - (1.5 * LoracksdkO.spellHaste * .01)
	
	-- check our runes yo
	--start, duration, runeReady = GetRuneCooldown(id)
	--runeType = GetRuneType(id)  BUFD

    LoracksdkO.badbad = 0;
	
	--check for sudden doommmmmmm
	
	if currentTime - LoracksdkO.suddenDoom < 15 then
		return LoracksdkO.SL["Death Coil"]
	end
	
	-- Every spec wants diseases up always... I'm fairly sure ;)

	
	LoracksdkO.ps = false
	if LoracksdkO.plagueList[guid] == nil then
		LoracksdkO.ps = true;
	elseif LoracksdkOdb.dDuration - (currentTime - LoracksdkO.plagueList[guid]) < GCD then
		LoracksdkO.ps = true;
	end
	if LoracksdkO.ps and IsSpellInRange(LoracksdkO.SL["Plague Strike"], "target") == 1 then
		if runes[2] > 0 or runes[4] > 0 then
			return LoracksdkO.SL["Plague Strike"]
		else
			-- uh oh, can't apply PS and it's down... we need to death rune something and then ps... right.
			LoracksdkO.badbad = LoracksdkO.badbad + 1;
		end
	end
	
	LoracksdkO.it = false
	if LoracksdkO.icyList[guid] == nil then
		LoracksdkO.it = true;
	elseif LoracksdkOdb.dDuration - (currentTime - LoracksdkO.icyList[guid]) < GCD then
		LoracksdkO.it = true;
	end
	if LoracksdkO.it and IsSpellInRange(LoracksdkO.SL["Icy Touch"], "target") == 1 then
		if runes[3] > 0 or runes[4] > 0 then
			return LoracksdkO.SL["Icy Touch"]
		else
			-- uh oh, can't apply IT and it's down... we need to death rune something and then IT... right.
			LoracksdkO.badbad = LoracksdkO.badbad + 1;
		end
	end
	
	if LoracksdkO.badbad == 1 then
		-- Bleh I say bleh.  Not working the best we can.  Convert to death rune if we can
		if currentTime - LoracksdkO.bloodTapTime > 59 then
			return LoracksdkO.SL["Blood Tap"]
		end
	end
	
	
	if runic > 99 and not LoracksdkO.lockRunic then
		if LoracksdkOdb.spec == LoracksdkO.SL["Frost Strike"] and IsSpellInRange(LoracksdkO.SL["Frost Strike"], "target") == 1 then
			return LoracksdkO.SL["Frost Strike"]
		elseif IsSpellInRange(LoracksdkO.SL["Death Coil"], "target") == 1 then
			return LoracksdkO.SL["Death Coil"]
		end
	end
	
	if LoracksdkOdb.bloodfirst then
		-- Use our blood runes
		if runes[1] > 0 then
			if LoracksdkOdb.spec == LoracksdkO.SL["Heart Strike"] and IsSpellInRange(LoracksdkO.SL["Heart Strike"], "target") == 1 then
				return LoracksdkO.SL["Heart Strike"]
			elseif IsSpellInRange(LoracksdkO.SL["Blood Strike"], "target") == 1 then
				return LoracksdkO.SL["Blood Strike"]
			end
		end	
		-- If we're heart strike spec, we should use our death runes here too for heart strikes
		if LoracksdkOdb.spec == LoracksdkO.SL["Heart Strike"] and IsSpellInRange(LoracksdkO.SL["Heart Strike"], "target") == 1 then
			if runes[4] > 0 then
				return LoracksdkO.SL["Heart Strike"]
			end
		end
	end
	
	
	if LoracksdkOdb.HowlingFirst and currentTime - LoracksdkO.howlingTime > 6 then
		if LoracksdkO.freezingFog and IsSpellInRange(LoracksdkO.SL["Howling Blast"], "target") == 1 then
			LoracksdkO.freezingFog = false
			return LoracksdkO.SL["Howling Blast"]
		end
		
		-- in case Oblit is out of range, but we have the runes for UF strike, and we have howling blast, and hb is in range.... ya...
		if LoracksdkOdb.howling and IsSpellInRange(LoracksdkO.SL["Howling Blast"], "target") == 1 then
			if runes[2] > 0 and runes[3] > 0 then
				return LoracksdkO.SL["Howling Blast"]
			elseif runes[2] > 0 and runes[4] > 0 then
				return LoracksdkO.SL["Howling Blast"]
			elseif runes[3] > 0 and runes[4] > 0 then
				return LoracksdkO.SL["Howling Blast"]
			elseif runes[4] > 1 then
				return LoracksdkO.SL["Howling Blast"]
			end
		end
	end
	
	if IsSpellInRange(LoracksdkOdb.uf, "target") == 1 then
		if runes[2] > 0 and runes[3] > 0 then
			return LoracksdkOdb.uf
		elseif runes[2] > 0 and runes[4] > 0 then
			return LoracksdkOdb.uf
		elseif runes[3] > 0 and runes[4] > 0 then
			return LoracksdkOdb.uf
		elseif runes[4] > 1 then
			return LoracksdkOdb.uf
		end
	end
	
	if not LoracksdkOdb.HowlingFirst and currentTime - LoracksdkO.howlingTime > 6 then
		if LoracksdkO.freezingFog and IsSpellInRange(LoracksdkO.SL["Howling Blast"], "target") == 1 then
			LoracksdkO.freezingFog = false
			return LoracksdkO.SL["Howling Blast"]
		end
		
		-- in case Oblit is out of range, but we have the runes for UF strike, and we have howling blast, and hb is in range.... ya...
		if LoracksdkOdb.howling and IsSpellInRange(LoracksdkO.SL["Howling Blast"], "target") == 1 then
			if runes[2] > 0 and runes[3] > 0 then
				return LoracksdkO.SL["Howling Blast"]
			elseif runes[2] > 0 and runes[4] > 0 then
				return LoracksdkO.SL["Howling Blast"]
			elseif runes[3] > 0 and runes[4] > 0 then
				return LoracksdkO.SL["Howling Blast"]
			elseif runes[4] > 1 then
				return LoracksdkO.SL["Howling Blast"]
			end
		end
	end
	
	if not LoracksdkOdb.bloodfirst then
		-- Use our blood runes
		if runes[1] > 0 then
			if LoracksdkOdb.spec == LoracksdkO.SL["Heart Strike"] and IsSpellInRange(LoracksdkO.SL["Heart Strike"], "target") == 1 then
				return LoracksdkO.SL["Heart Strike"]
			elseif IsSpellInRange(LoracksdkO.SL["Blood Strike"], "target") == 1 then
				return LoracksdkO.SL["Blood Strike"]
			end
		end	
		-- If we're heart strike spec, we should use our death runes here too for heart strikes
		if LoracksdkOdb.spec == LoracksdkO.SL["Heart Strike"] and IsSpellInRange(LoracksdkO.SL["Heart Strike"], "target") == 1 then
			if runes[4] > 0 then
				return LoracksdkO.SL["Heart Strike"]
			end
		end
	end
	
	if runic > 39 and not LoracksdkO.lockRunic then
		if LoracksdkOdb.spec == LoracksdkO.SL["Frost Strike"] and IsSpellInRange(LoracksdkO.SL["Frost Strike"], "target") == 1 then
			return LoracksdkO.SL["Frost Strike"]
		elseif IsSpellInRange(LoracksdkO.SL["Death Coil"], "target") == 1 then
			return LoracksdkO.SL["Death Coil"]
		end
	end
	
	if runes[4] == 1 then
		-- if all else fails, and we have exactly 1 death rune, check to convert a second
		if currentTime - LoracksdkO.bloodTapTime > 59 then
			return LoracksdkO.SL["Blood Tap"]
		end
	end
	
	
	return ""

end

function LoracksdkO:DefSpell(runes, runic)
	
	local currentTime = GetTime()
	
	if not LoracksdkO.it and not LoracksdkO.ps and UnitHealth("player") / UnitHealthMax("player") * 100 <= LoracksdkOdb.healthPercent and IsSpellInRange(LoracksdkO.SL["Death Strike"], "target") == 1 then
		if runes[2] > 0 and runes[3] > 0 then
			return LoracksdkO.SL["Death Strike"]
		elseif runes[2] > 0 and runes[4] > 0 then
			return LoracksdkO.SL["Death Strike"]
		elseif runes[3] > 0 and runes[4] > 0 then
			return LoracksdkO.SL["Death Strike"]
		elseif runes[4] > 1 then
			return LoracksdkO.SL["Death Strike"]
		end
		
		if LoracksdkOdb.runetap then
			if currentTime - LoracksdkO.runetapTime > LoracksdkOdb.runetapcd then
				if runes[1] > 0 or runes[4] > 0 then
					return LoracksdkO.SL["Rune Tap"]
				end
			end
		end
	end
	
	
	if currentTime - LoracksdkO.shieldTime > 59 then
		if LoracksdkOdb.shield == LoracksdkO.SL["Vampiric Blood"] and LoracksdkO.shieldDown then
			if runes[1] > 0 or runes[4] > 0 then
				return LoracksdkOdb.shield
			end
		elseif LoracksdkOdb.shield == LoracksdkO.SL["Unbreakable Armor"] and LoracksdkO.shieldDown then
			if runes[2] > 0 or runes[4] > 0 then
				return LoracksdkOdb.shield
			end
		elseif LoracksdkOdb.shield == LoracksdkO.SL["Bone Shield"] and LoracksdkO.shieldDown then
			if runes[3] > 0 or runes[4] > 0 then
				return LoracksdkOdb.shield
			end
		end
	end
	
	if runic > 19 and LoracksdkO.shieldDown then
		if currentTime - LoracksdkO.iceboundTime > 59 then
			return LoracksdkO.SL["Icebound Fortitude"]
		end
	end
	
	
	if LoracksdkOdb.lichborne and LoracksdkO.shieldDown then
		if currentTime - LoracksdkO.lichborneTime > 179 then
			return LoracksdkO.SL["Lichborne"]
		end
	end
	
	-- guess we got nothing
	return ""

end

function LoracksdkO:AoESpell(runes, runic)

	local guid = UnitGUID("target")
	local currentTime = GetTime()
	local GCD = 1.5 - (1.5 * LoracksdkO.spellHaste * .01)
	
	if LoracksdkOdb.unholyblight and runic > 59 and not LoracksdkO.lockRunic then
		if (currentTime - LoracksdkO.blightTime) > 20 then
			return LoracksdkO.SL["Unholy Blight"]
		end
	end
	
	-- THERE HAS TO BE A BETTER WAY TO FIGURE OUT IF WE HAVE THE RUNES FOR DND... -_-
	if not LoracksdkOdb.howling then
		if currentTime - LoracksdkO.DnDTime > LoracksdkOdb.dndcd then
			if runes[1] > 0 and runes[2] > 0 and runes[3] > 0 then
				return LoracksdkO.SL["Death and Decay"]
			elseif runes[1] > 0 and runes[2] > 0 and runes[4] > 0 then
				return LoracksdkO.SL["Death and Decay"]
			elseif runes[1] > 0 and runes[4] > 0 and runes[3] > 0 then
				return LoracksdkO.SL["Death and Decay"]
			elseif runes[4] > 0 and runes[2] > 0 and runes[3] > 0 then
				return LoracksdkO.SL["Death and Decay"]
			elseif runes[4] > 2 then
				return LoracksdkO.SL["Death and Decay"]
			elseif runes[4] == 2 then
				if runes[1] > 0 or runes[2] > 0 or runes[3] > 0 then
					return LoracksdkO.SL["Death and Decay"]
				end
			end
		end
	end
	-- THAT WAS FUN
	
	-- If the target needs IT or PS, this will get filtered out in the DecideSpells.  We use dDuration since we should only pest once per disease application optimally
	if currentTime - LoracksdkO.pestTime >  LoracksdkOdb.dDuration - 2 and IsSpellInRange(LoracksdkO.SL["Pestilence"], "target") == 1 then -- I dunno why the -2, I just dunno
		if runes[1] > 0 or runes[4] > 0 then
			return LoracksdkO.SL["Pestilence"]
		end
	end
	
	if LoracksdkOdb.howling and currentTime - LoracksdkO.howlingTime > 6 and IsSpellInRange(LoracksdkO.SL["Howling Blast"], "target") == 1 then
		if runes[2] > 0 and runes[3] > 0 then
			return LoracksdkO.SL["Howling Blast"]
		elseif runes[2] > 0 and runes[4] > 0 then
			return LoracksdkO.SL["Howling Blast"]
		elseif runes[3] > 0 and runes[4] > 0 then
			return LoracksdkO.SL["Howling Blast"]
		elseif runes[4] > 1 then
			return LoracksdkO.SL["Howling Blast"]
		end
	end
	
	-- Blood boil... I guess
	if runes[1] > 0 or runes[4] > 0 then
		if IsSpellInRange(LoracksdkO.SL["Blood Boil"], "target") == 1 then
			return LoracksdkO.SL["Blood Boil"]
		end
	end
	
	return ""

end

function LoracksdkO:MiscSpell(runes, runic)

	local guid = UnitGUID("target")
	local currentTime = GetTime()
	local GCD = 1.5 - (1.5 * LoracksdkO.spellHaste * .01)

	-- check if rune strike is up cause it's awsome
	if currentTime - LoracksdkO.rsTime < 25 then
		if runic >= LoracksdkOdb.rsCost then
			return LoracksdkO.SL["Rune Strike"]
		end
	end
	
	if LoracksdkOdb.horn and currentTime - LoracksdkO.hornTime > 120 then
		if runic >= 20 then
			return LoracksdkO.SL["Horn of Winter"]
		end
	end
	
	return ""
	
end

function LoracksdkO:IntSpell(runes, runic)

	local guid = UnitGUID("target")
	local currentTime = GetTime()
	local GCD = 1.5 - (1.5 * LoracksdkO.spellHaste * .01)
	local spell = UnitCastingInfo("target")
	local channel = UnitChannelInfo("target")
	
	if spell or channel then 
		if runic >= LoracksdkOdb.mindfreezeCost and currentTime - LoracksdkO.mindfreezetime > 10 and IsSpellInRange(LoracksdkO.SL["Mind Freeze"], "target") == 1 then
			return LoracksdkO.SL["Mind Freeze"]
		end
		if runes[1] > 0 or runes[4] > 0 then
			if currentTime - LoracksdkO.strangulateTime > 120 and IsSpellInRange(LoracksdkO.SL["Strangulate"], "target") == 1 then
				return LoracksdkO.SL["Strangulate"]
			end
		end
	end
	
	return ""

end

function LoracksdkO:CheckStuff()

	LoracksdkOdb.talentCount = {}
	
	local name,_,pointsSpent,_ = GetTalentTabInfo(1)
	LoracksdkOdb.talentCount["Blood"] = pointsSpent
	name,_,pointsSpent,_ = GetTalentTabInfo(2)
	LoracksdkOdb.talentCount["Frost"] = pointsSpent
	name,_,pointsSpent,_ = GetTalentTabInfo(3)
	LoracksdkOdb.talentCount["Unholy"] = pointsSpent
	
	if LoracksdkOdb.talentCount["Blood"] > 40 then
		local _, _, _, _, currentRank = GetTalentInfo(1, 24); -- check for Heart Strike
		if currentRank == 1 then
			LoracksdkOdb.spec = LoracksdkO.SL["Heart Strike"]
		end
	elseif LoracksdkOdb.talentCount["Frost"] > 40 then
		local _, _, _, _, currentRank = GetTalentInfo(2, 25); -- check for Frost Strike
		if currentRank == 1 then
			LoracksdkOdb.spec = LoracksdkO.SL["Frost Strike"]
		end
	elseif LoracksdkOdb.talentCount["Unholy"] > 40 then
		local _, _, _, _, currentRank = GetTalentInfo(3, 28); -- check for Scourge Strike
		if currentRank == 1 then
			LoracksdkOdb.spec = LoracksdkO.SL["Scourge Strike"]
		end
	else
		LoracksdkOdb.spec = "Default"
	end
	
	if LoracksdkOdb.spec == LoracksdkO.SL["Scourge Strike"] then
		LoracksdkOdb.uf = LoracksdkO.SL["Scourge Strike"]
	else
		LoracksdkOdb.uf = LoracksdkO.SL["Obliterate"]
	end
	
	-- check for epidemic
	_, _, _, _, currentRank = GetTalentInfo(3, 4);
	LoracksdkOdb.dDuration = 12 + (currentRank * 3)
		
	
	-- check for a spec shield
	LoracksdkOdb.shield = ""
	_, _, _, _, currentRank = GetTalentInfo(1, 22);
	if currentRank == 1 then
		LoracksdkOdb.shield = LoracksdkO.SL["Vampiric Blood"]
	end
	_, _, _, _, currentRank = GetTalentInfo(2, 23);
	if currentRank == 1 then
		LoracksdkOdb.shield = LoracksdkO.SL["Unbreakable Armor"]
	end
	_, _, _, _, currentRank = GetTalentInfo(3, 25);
	if currentRank == 1 then
		LoracksdkOdb.shield = LoracksdkO.SL["Bone Shield"]
	end
	
	-- check for Lichborne as many specs can get it
	_, _, _, _, currentRank = GetTalentInfo(2, 8);
	if currentRank == 1 then
		LoracksdkOdb.lichborne = true
	else
		LoracksdkOdb.lichborne = false
	end
	
	-- check for Rune Tap as many specs can get it
	_, _, _, _, currentRank = GetTalentInfo(1, 7);
	if currentRank == 1 then
		LoracksdkOdb.runetap = true
		_, _, _, _, currentRank = GetTalentInfo(1, 10);
		LoracksdkOdb.runetapcd = 60 - (currentRank * 10)
	else
		LoracksdkOdb.runetap = false
	end
	
	-- check for DnD time reduction
	_, _, _, _, currentRank = GetTalentInfo(3, 2);
	LoracksdkOdb.dndcd = 30 - (currentRank * 5)
	
	-- check for Unholy Blight
	_, _, _, _, currentRank = GetTalentInfo(3, 30);
	if currentRank == 1 then
		LoracksdkOdb.unholyblight = true
	else
		LoracksdkOdb.unholyblight = false
	end
	
	-- check for Howling Blast
	_, _, _, _, currentRank = GetTalentInfo(2, 19);
	if currentRank == 1 then
		LoracksdkOdb.howling = true
	else
		LoracksdkOdb.howling = false
	end
	
	-- check for glyph of rune strike 58669
	if LoracksdkO:hasGlyph(58669) then
		LoracksdkOdb.rsCost = 25
	else
		LoracksdkOdb.rsCost = 20
	end
	
	--check for endless winter talent 18, out of 2, 10 sec reduce each
	_, _, _, _, currentRank = GetTalentInfo(2, 18);
	LoracksdkOdb.mindfreezeCost = 20 - (currentRank * 10)
	
end

-- Options Panel

function LoracksdkO:GetLocked()
  return LoracksdkOdb.locked
end

function LoracksdkO:ToggleLocked()
  if LoracksdkOdb.locked then
    LoracksdkOdb.locked = false
    LoracksdkO.displayFrame:SetScript("OnMouseDown", function(self) self:StartMoving() end)
    LoracksdkO.displayFrame:SetScript("OnMouseUp", function(self) self:StopMovingOrSizing() end)
    LoracksdkO.displayFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    LoracksdkO.displayFrame:SetBackdropColor(0, 0, 0, .4)
	LoracksdkO.displayFrame:EnableMouse(true)
  else
    LoracksdkOdb.locked = true
    LoracksdkO.displayFrame:SetScript("OnMouseDown", nil)
    LoracksdkO.displayFrame:SetScript("OnMouseUp", nil)
    LoracksdkO.displayFrame:SetScript("OnDragStop", nil)
    LoracksdkO.displayFrame:SetBackdropColor(0, 0, 0, 0)
	LoracksdkO.displayFrame:EnableMouse(false)
  end
end
function LoracksdkO:GetModeSingle()
  return LoracksdkOdb.modeSingle
end

function LoracksdkO:ToggleModeSingle()
  if LoracksdkOdb.modeSingle then
    LoracksdkOdb.modeSingle = false
  else
    LoracksdkOdb.modeSingle = true
  end
end
function LoracksdkO:GetModeAoE()
  return LoracksdkOdb.modeAoE
end

function LoracksdkO:ToggleModeAoE()
  if LoracksdkOdb.modeAoE then
    LoracksdkOdb.modeAoE = false
  else
    LoracksdkOdb.modeAoE = true
  end
end
function LoracksdkO:GetModeDefensive()
  return LoracksdkOdb.modeDefensive
end

function LoracksdkO:ToggleModeDefensive()
  if LoracksdkOdb.modeDefensive then
    LoracksdkOdb.modeDefensive = false
  else
    LoracksdkOdb.modeDefensive = true
  end
end

function LoracksdkO:GetModeMisc()
  return LoracksdkOdb.modeMisc
end

function LoracksdkO:ToggleModeMisc()
  if LoracksdkOdb.modeMisc then
    LoracksdkOdb.modeMisc = false
  else
    LoracksdkOdb.modeMisc = true
  end
end

function LoracksdkO:GetModeInt()
  return LoracksdkOdb.modeInt
end

function LoracksdkO:ToggleModeInt()
  if LoracksdkOdb.modeInt then
    LoracksdkOdb.modeInt = false
  else
    LoracksdkOdb.modeInt = true
  end
end

function LoracksdkO:GetHorn()
  return LoracksdkOdb.horn
end

function LoracksdkO:ToggleHorn()
  if LoracksdkOdb.horn then
    LoracksdkOdb.horn = false
  else
    LoracksdkOdb.horn = true
  end
end
function LoracksdkO:GetBlood()
  return LoracksdkOdb.bloodfirst
end

function LoracksdkO:ToggleBlood()
  if LoracksdkOdb.bloodfirst then
    LoracksdkOdb.bloodfirst = false
  else
    LoracksdkOdb.bloodfirst = true
  end
end

function LoracksdkO:GetDSMid()
  return LoracksdkOdb.DSMid
end

function LoracksdkO:ToggleDSMid()
  if LoracksdkOdb.DSMid then
    LoracksdkOdb.DSMid = false
  else
    LoracksdkOdb.DSMid = true
  end
end

function LoracksdkO:GetHowlingFirst()
  return LoracksdkOdb.HowlingFirst
end

function LoracksdkO:ToggleHowlingFirst()
  if LoracksdkOdb.HowlingFirst then
    LoracksdkOdb.HowlingFirst = false
  else
    LoracksdkOdb.HowlingFirst = true
  end
end

function LoracksdkO:GetScale()
  return LoracksdkOdb.scale
end
function LoracksdkO:SetScale(num)
  LoracksdkOdb.scale = num
  LoracksdkO.displayFrame:SetScale(LoracksdkOdb.scale)
  LoracksdkO.cooldownFrame:SetScale(LoracksdkOdb.scale)
end
function LoracksdkO:GetHealthPercent()
  return LoracksdkOdb.healthPercent
end
function LoracksdkO:SetHealthPercent(num)
  LoracksdkOdb.healthPercent = num
end


function LoracksdkO:CreateOptionFrame()
  local panel = CreateFrame("FRAME", "LoracksdkOOptions");
  panel.name = "LoracksdkO";
  local fstring1 = panel:CreateFontString("LoracksdkOOptions_string1","OVERLAY","GameFontNormal")
  local fstring5 = panel:CreateFontString("LoracksdkOOptions_string4","OVERLAY","GameFontNormal")
  fstring1:SetText("Lock")
  fstring5:SetText("GUI Scale")
  fstring1:SetPoint("TOPLEFT", 10, -10)
  fstring5:SetPoint("TOPLEFT", 10, -40)
  local checkbox1 = CreateFrame("CheckButton", "$parent_cb1", panel, "OptionsCheckButtonTemplate")
  checkbox1:SetWidth(18)
  checkbox1:SetHeight(18)
  checkbox1:SetScript("OnClick", function() LoracksdkO:ToggleLocked() end)
  checkbox1:SetPoint("TOPRIGHT", -10, -10)
  checkbox1:SetChecked(LoracksdkO:GetLocked())
  local slider2 = CreateFrame("Slider", "$parent_sl2", panel, "OptionsSliderTemplate")
  slider2:SetMinMaxValues(.5, 1.5)
  slider2:SetValue(LoracksdkO:GetScale())
  slider2:SetValueStep(.05)
  slider2:SetScript("OnValueChanged", function(self) LoracksdkO:SetScale(self:GetValue()); getglobal(self:GetName() .. "Text"):SetText(self:GetValue())  end)
  getglobal(slider2:GetName() .. "Low"):SetText("0.5")
  getglobal(slider2:GetName() .. "High"):SetText("1.5")
  getglobal(slider2:GetName() .. "Text"):SetText(LoracksdkO:GetScale())
  slider2:SetPoint("TOPRIGHT", -10, -40)
  
  local fstring2 = panel:CreateFontString("LoracksdkOOptions_string2","OVERLAY","GameFontNormal")
  local fstring3 = panel:CreateFontString("LoracksdkOOptions_string3","OVERLAY","GameFontNormal")
  local fstring4 = panel:CreateFontString("LoracksdkOOptions_string4","OVERLAY","GameFontNormal")
  local fstring6 = panel:CreateFontString("LoracksdkOOptions_string6","OVERLAY","GameFontNormal")
  local fstring7 = panel:CreateFontString("LoracksdkOOptions_string7","OVERLAY","GameFontNormal")
  fstring2:SetText("Single Target Enabled")
  fstring3:SetText("AoE Enabled")
  fstring4:SetText("Defensive Enabled")
  fstring6:SetText("Misc Enabled")
  fstring7:SetText("Interrupt Enabled")
  fstring2:SetPoint("TOPLEFT", 10, -70)
  fstring3:SetPoint("TOPLEFT", 10, -100)
  fstring4:SetPoint("TOPLEFT", 10, -130)
  fstring6:SetPoint("TOPLEFT", 10, -160)
  fstring7:SetPoint("TOPLEFT", 10, -190)
  local checkbox2 = CreateFrame("CheckButton", "$parent_cb2", panel, "OptionsCheckButtonTemplate")
  checkbox2:SetWidth(18)
  checkbox2:SetHeight(18)
  checkbox2:SetScript("OnClick", function() LoracksdkO:ToggleModeSingle() end)
  checkbox2:SetPoint("TOPRIGHT", -10, -70)
  checkbox2:SetChecked(LoracksdkO:GetModeSingle())
  local checkbox3 = CreateFrame("CheckButton", "$parent_cb3", panel, "OptionsCheckButtonTemplate")
  checkbox3:SetWidth(18)
  checkbox3:SetHeight(18)
  checkbox3:SetScript("OnClick", function() LoracksdkO:ToggleModeAoE() end)
  checkbox3:SetPoint("TOPRIGHT", -10, -100)
  checkbox3:SetChecked(LoracksdkO:GetModeAoE())
  local checkbox4 = CreateFrame("CheckButton", "$parent_cb4", panel, "OptionsCheckButtonTemplate")
  checkbox4:SetWidth(18)
  checkbox4:SetHeight(18)
  checkbox4:SetScript("OnClick", function() LoracksdkO:ToggleModeDefensive() end)
  checkbox4:SetPoint("TOPRIGHT", -10, -130)
  checkbox4:SetChecked(LoracksdkO:GetModeDefensive())
  local checkbox5 = CreateFrame("CheckButton", "$parent_cb5", panel, "OptionsCheckButtonTemplate")
  checkbox5:SetWidth(18)
  checkbox5:SetHeight(18)
  checkbox5:SetScript("OnClick", function() LoracksdkO:ToggleModeMisc() end)
  checkbox5:SetPoint("TOPRIGHT", -10, -160)
  checkbox5:SetChecked(LoracksdkO:GetModeMisc())
  local checkbox6 = CreateFrame("CheckButton", "$parent_cb6", panel, "OptionsCheckButtonTemplate")
  checkbox6:SetWidth(18)
  checkbox6:SetHeight(18)
  checkbox6:SetScript("OnClick", function() LoracksdkO:ToggleModeInt() end)
  checkbox6:SetPoint("TOPRIGHT", -10, -190)
  checkbox6:SetChecked(LoracksdkO:GetModeInt())
  
  
  local fstring5 = panel:CreateFontString("LoracksdkOOptions_string5","OVERLAY","GameFontNormal")
  fstring5:SetText("Health % for DS and RT")
  fstring5:SetPoint("TOPLEFT", 10, -220)
  
  local slider1 = CreateFrame("Slider", "$parent_sl1", panel, "OptionsSliderTemplate")
  slider1:SetMinMaxValues(0, 100)
  slider1:SetValue(LoracksdkO:GetHealthPercent())
  slider1:SetValueStep(1)
  slider1:SetScript("OnValueChanged", function(self) LoracksdkO:SetHealthPercent(self:GetValue()); getglobal(self:GetName() .. "Text"):SetText(self:GetValue()) end)
   getglobal(slider1:GetName() .. "Low"):SetText("1")
  getglobal(slider1:GetName() .. "High"):SetText("100")
  getglobal(slider1:GetName() .. "Text"):SetText(LoracksdkO:GetHealthPercent())
  slider1:SetPoint("TOPRIGHT", -10, -220)
  
  local fstring8 = panel:CreateFontString("LoracksdkOOptions_string8","OVERLAY","GameFontNormal")
  fstring8:SetText("Suggest Horn of Winter")
  fstring8:SetPoint("TOPLEFT", 10, -250)
  
  local checkbox8 = CreateFrame("CheckButton", "$parent_cb8", panel, "OptionsCheckButtonTemplate")
  checkbox8:SetWidth(18)
  checkbox8:SetHeight(18)
  checkbox8:SetScript("OnClick", function() LoracksdkO:ToggleHorn() end)
  checkbox8:SetPoint("TOPRIGHT", -10, -250)
  checkbox8:SetChecked(LoracksdkO:GetHorn())
  
  
  local fstring9 = panel:CreateFontString("LoracksdkOOptions_string9","OVERLAY","GameFontNormal")
  fstring9:SetText("Prioritize Blood over Unholy + Frost")
  fstring9:SetPoint("TOPLEFT", 10, -280)
  
  local checkbox9 = CreateFrame("CheckButton", "$parent_cb9", panel, "OptionsCheckButtonTemplate")
  checkbox9:SetWidth(18)
  checkbox9:SetHeight(18)
  checkbox9:SetScript("OnClick", function() LoracksdkO:ToggleBlood() end)
  checkbox9:SetPoint("TOPRIGHT", -10, -280)
  checkbox9:SetChecked(LoracksdkO:GetBlood())
  
  local fstring10 = panel:CreateFontString("LoracksdkOOptions_string10","OVERLAY","GameFontNormal")
  fstring10:SetText("Suggest DS in the Middle")
  fstring10:SetPoint("TOPLEFT", 10, -310)
  
  local checkbox10 = CreateFrame("CheckButton", "$parent_cb10", panel, "OptionsCheckButtonTemplate")
  checkbox10:SetWidth(18)
  checkbox10:SetHeight(18)
  checkbox10:SetScript("OnClick", function() LoracksdkO:ToggleDSMid() end)
  checkbox10:SetPoint("TOPRIGHT", -10, -310)
  checkbox10:SetChecked(LoracksdkO:GetDSMid())
 
  local fstring11 = panel:CreateFontString("LoracksdkOOptions_string11","OVERLAY","GameFontNormal")
  fstring11:SetText("Prioritize Howling Blast over other UF")
  fstring11:SetPoint("TOPLEFT", 10, -340)
  
  local checkbox11 = CreateFrame("CheckButton", "$parent_cb10", panel, "OptionsCheckButtonTemplate")
  checkbox11:SetWidth(18)
  checkbox11:SetHeight(18)
  checkbox11:SetScript("OnClick", function() LoracksdkO:ToggleHowlingFirst() end)
  checkbox11:SetPoint("TOPRIGHT", -10, -340)
  checkbox11:SetChecked(LoracksdkO:GetHowlingFirst())
  

  InterfaceOptions_AddCategory(panel); 
end

-- Slash Command
function LoracksdkO.Options()
  InterfaceOptionsFrame_OpenToCategory(getglobal("LoracksdkOOptions"))
end

function LoracksdkO:hasGlyph(id)
	for i = 1, 6 do
		local _, _, glyphSpell = GetGlyphSocketInfo(i)
		if glyphSpell == id then
			return true
		end
	end
end
	
	


