﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore", "esES" )

if not L then return end

L["Disabled"] = "Desactivado"
L["Enabled"] = "Activado"
L["Memory used for %d |4character:characters;:"] = "Memoria utilizada para %d |4personaje:personajes;:"

