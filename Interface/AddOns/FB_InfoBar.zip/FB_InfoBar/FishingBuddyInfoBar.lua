-- InfoBar support for Fishing Buddy

FB_InfoBar = {};

FB_InfoBar.OnLoad = function(self)
   if ( not InfoBarFrame ) then
      return;
   end

   self:RegisterForClicks("LeftButtonUp", "RightButtonUp");

   self.info = {
      name = FBConstants.NAME,
      version = FBConstants.CURRENTVERSION/100,
      tooltip = FB_InfoBar.Tooltip,
   };	
end

FB_InfoBar.OnClick = function(self, button)
   if (button == "LeftButton") then
      if (FishingBuddy.IsSwitchCLick() ) then
	 FishingBuddy.Command(FBConstants.SWITCH);
      else
	 FishingBuddy.Command("");
      end
   elseif ( IsShiftKeyDown() ) then
      ToggleFishingBuddyFrame("FishingOptionsFrame");
   else
      -- Toggle menu
      local menu = getglobal("FishingBuddyInfoBarMenu");
      menu.point = "TOPRIGHT";
      menu.relativePoint = "CENTER";
      local level = 1;
      ToggleDropDownMenu(level, nil, menu, "IB_FishingBuddy", 0, 0);
   end
end

FB_InfoBar.OnEvent = function()
end

FB_InfoBar.Tooltip = function()
   return FishingBuddy.TooltipBody("ClickToSwitch");
end

FB_InfoBar.Menu_Initialize = function()
   FishingBuddy.MakeDropDown(FBConstants.CLICKTOSWITCH_ONOFF, "ClickToSwitch");
end
