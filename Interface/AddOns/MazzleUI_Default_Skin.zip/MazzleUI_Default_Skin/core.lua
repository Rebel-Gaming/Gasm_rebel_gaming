function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Default_Skin\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Default_Skin\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Default_Skin\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Default_Skin\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Default_Skin\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Default_Skin\\MazzleUICastingBarBorder",
            chatborder = "Interface\\AddOns\\MazzleUI_Default_Skin\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Default_Skin\\MazzleUIMinimapBorder",
        },
    }
end