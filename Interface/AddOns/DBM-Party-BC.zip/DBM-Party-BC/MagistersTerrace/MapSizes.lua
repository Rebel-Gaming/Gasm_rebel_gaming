--[[local WowBuild = select(2, GetBuildInfo())
if tonumber(WowBuild) < 13165 then return end

DBM:RegisterMapSize("MagistersTerrace",
	1, 1355.47009278, 903.647033691
)--]]