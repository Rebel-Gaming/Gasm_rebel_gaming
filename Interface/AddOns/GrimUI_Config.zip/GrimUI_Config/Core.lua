local addonName, addon = ...
addonName = addonName:match("^(.+)_Config$")
addon = _G[addonName]
if not addon then return end

local path = [[Interface\AddOns\]] .. addonName .. [[\Skins\]]
local skins = {
	[path .. "Alliance"] = "Alliance",
	[path .. "Horde"] = "Horde",
	[path .. "BlackMetal"] = "Black Metal"
}

local styles = {
	"Vertical",
	"Horizontal"
}

--[[-----------------------------------------------------------------------------
Common for all options
-------------------------------------------------------------------------------]]
local function Get(info)
	return addon.settings[info[#info]]
end

local function Set(info, value)
	addon.settings[info[#info]] = value or false
end

local function SetOptionWindowWidthStrata()
	InterfaceOptionsFrame:SetFrameStrata("HIGH")
	if addon.configPanel:IsVisible() then
	InterfaceOptionsFrame:SetWidth(800)
	else
	return
	end
end
InterfaceOptionsFrame:HookScript("OnShow", SetOptionWindowWidthStrata)
InterfaceOptionsFrame:HookScript("OnUpdate", SetOptionWindowWidthStrata)

--[[-----------------------------------------------------------------------------
Options
-------------------------------------------------------------------------------]]
local options = {
	type = 'group',
	childGroups = "tab",
	get = Get,
	set = Set,
	args = {
		option1 = {
			name = "General Options",
			desc = "General Options for GrimUI.",
			type = "group",
			order = 1,
			
			args = {
				lockFrames = {
					type = 'toggle',
					order = 1,
					name = "Lock Frames",
					desc = "Prevent frames from being moved by the mouse."
				},
				
				tooltipIconSize = {
					type = 'range',
					order = 3,
					name = "Tooltip Icon Size",
					desc = "Set the size of icons added to tooltips.",
					min = 8, max = 32, step = 1
				},
				uiSkin = {
					type = 'select',
					order = 4,
					name = "Art Skin",
					desc = "Choose which skin to use.",
					values = skins,
					set = function(info, value)
						Set(info, value)
						addon:ConfigureSkin()
					end
				},
				ResetFrames = {
					type = 'execute',
					order = -1,
					name = "Reset Frames",
					desc = "Wipe all frame position data.",
					func = function(info)
					local movedFrames = addon.settings.movedFrames
					for name in pairs(movedFrames) do
						addon:UnlockFrame(name)
						movedFrames[name] = nil
					end
					addon:LockFrame(WatchFrame)
					addon:SafeCall("ResetPlayerFrame")
					addon:SafeCall("ResetPartyFrames")
				end
				},
			},
		},
		option2 = {
			name = "PlayerFrame",
			desc = "PlayerFrame Options for GrimUI.",
			type = "group",
			order = 2,
			args = {
				PlayerFrame = {
					type = 'group', inline = true,
					order = -4,
					name = "Player Frame",
					args = {
						playerFrameScale = {
							type = 'range',
							order = 3,
							name = "PlayerFrame Scale",
							desc = "Set the Scale of PlayerFrame.",
							min = 0.4, 
							max = 2.4, 
							step = 0.1,
							--get = function(info) return addon.ConfigurePlayerFrame end
							--set = addon:SafeCall("PlayerFrameSetScale")
							--func = "PlayerFrameSetScale",
						},
						
						showPlayerFrame = {
							type = 'toggle',
							order = 1,
							name = "Enable",
							desc = "Show " .. addonName .. "'s player frame.",
							set = function(info, value)
								Set(info, value)
								addon:SafeCall("ConfigurePlayerFrame")
							end
						},
						hideBlizPlayerFrame = {
							type = 'toggle',
							order = 2,
							name = "Hide Blizzard",
							desc = "Disable Blizzard's default player frame.",
							set = function(info, value)
								Set(info, value)
									addon:SafeCall("ConfigureBlizPlayerFrame")
							end
						}
					}
				},
			},
		},
		
		
		option3 = {
			name = "PartyFrames",
			desc = "PartyFrames Options for GrimUI.",
			type = "group",
			order = 3,
			args = {
				PartyFrames = {
					type = 'group', inline = true,
					order = -3,
					name = "Party Frames",
					args = {
						showPartyFrames = {
							type = 'toggle',
							order = 1,
							name = "Enable",
							desc = "Show " .. addonName .. "'s party frames.",
							set = function(info, value)
								Set(info, value)
								addon:SafeCall("ConfigurePartyFrames")
							end
						},
						hideBlizPartyFrames = {
							type = 'toggle',
							order = 1,
							name = "Hide Blizzard",
							desc = "Disable Blizzard's default party frames.",
							set = function(info, value)
								Set(info, value)
								addon:SafeCall("ConfigureBlizPartyFrames")
							end
						},
						stylePartyFrames = {
							type = 'select',
							order = 3,
							name = "Party Frames Style",
							desc = "Choose which style to use for party frames.",
							values = styles,
							set = function(info, value)
								Set(info, value)
								addon:SafeCall("StylePartyFrames")
							end
						}
					}
				},
			},
		},

		option4 = {
			name = "ChatFrames",
			desc = "Chat Options for GrimUI.",
			type = "group",
			order = 4,
			args = {
				showCombatLog = {
					type = 'toggle',
					order = 2,
					name = "Show Combat Log",
					desc = "Enable the combat log window.",
					set = function(info, value)
						Set(info, value)
						addon:ConfigureCombatLog()
					end
				},
				showChatTabs = {
					type = 'toggle',
					order = 3,
					name = "Show Chat Tabs",
					desc = "Show Chat Frame 2 and 6's Chat Tabs.",
					set = function(info, value)
						Set(info, value)
						--addon.settings.showCombatLog = not addon.settings.showCombatLog
						addon:ConfigureChatTabs()
					end
				},
				ResetChat = {
					type = 'execute',
					order = -4,
					name = "Reset Chat",
					desc = "Reset the chat windows to " .. addonName .. "'s defaults.",
					func = function(info)
						addon:ResetChatFrames()
					end
				},
			},
		},
	},
}

--[[-----------------------------------------------------------------------------
Initialize
-------------------------------------------------------------------------------]]
LibStub('AceConfigRegistry-3.0'):RegisterOptionsTable(addonName, options)

addon.configPanel:AssignOptions(addonName)
--addon.configPanel:SetDesc("These options allow you to change the appearance and behavior of " .. addonName .. ".")
addon.configPanel:SetInfo("Version: " .. GetAddOnMetadata(addonName, 'Version'))
