--[[
	BVent
		An small event handler.
		Based a bit on AceEvent
--]]


assert(TLib, "TLib not loaded")

--[[ Version Checking ]]--
local VERSION = '6.12.09'
if TLib.OlderIsBetter(BVent, VERSION) then return end

--[[ Library Instantiation ]]--

if not BVent then
	BVent = CreateFrame("Frame")
end

if not BVent.events then
	BVent.events = {}
end

BVent.version = VERSION

--[[ Locals ]]--

--these events only fire once
local fireOnce = {'PLAYER_LOGIN', 'VARIABLES_LOADED'}

local function RemoveEvent(event)
	BVent.events[event] = nil
	BVent:UnregisterEvent(event)
end

--[[ Usable Functions ]]--

--adds an action to the given event
function BVent:AddAction(e, action)
	if action then
		local events = self.events
		if events[e] then
			table.insert(events[e], action)
		else
			events[e] = {action}
			self:RegisterEvent(e)
		end
	end
end

--removes the given action from the given event
function BVent:RemoveAction(e, action)
	if action then
		local actions = self.events[e]
		if actions then
			local index	
			for i, act in pairs(actions) do
				if act == action then
					index = i
					break
				end
			end

			if index then
				table.remove(actions, index)
			end

			if not next(actions) then
				RemoveEvent(event)
			end
		end
	end
end

--Calls an event with the given arguments
function BVent:Call(e, ...)
	local actions = self.events[e]

	if actions then
		for _, action in ipairs(actions) do
			action(action, e, ...)
		end
	end
end

--[[ Event Handler ]]--

BVent:SetScript("OnEvent", function()
	local actions = this.events[event]
	if actions then
		for _, action in ipairs(actions) do
			action(action, event, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12)
		end
	end

	if fireOnce[event] then
		RemoveEvent(event)
	end
end)