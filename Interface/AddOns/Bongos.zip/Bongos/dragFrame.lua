--[[ 
	dragFrame.lua
		A bongos drag frame
--]]

--[[ Click Functions ]]--
	
local function DragFrame_OnClick()
	if arg1 == 'RightButton' then
		if IsShiftKeyDown() then
			BBar.Hide(this.parent)
		elseif this.parent.ShowMenu then
			this.parent:ShowMenu()
		end
	end
end

--[[ Movement Functions ]]--

local function DragFrame_OnMouseDown()
	this.parent:StartMoving()
	GameTooltip:Hide()
end

local function DragFrame_OnMouseUp()
	this.parent:StopMovingOrSizing()
	BBar.TryToStick(this.parent)

	GameTooltip:Show()
end

--[[ Tooltip Functions ]]--

local function DragFrame_OnEnter()
	Bongos_AnchorTooltip(this)

	if not tonumber(this:GetText()) then
		GameTooltip:SetText(this:GetText() .. " bar", 1, 1, 1)
	else
		GameTooltip:SetText("actionbar " .. this:GetText(), 1, 1, 1)
	end

	GameTooltip:AddLine(BONGOS_DRAG_SHOW_MENU)
	if not this:GetParent().alwaysShow then
		GameTooltip:AddLine(BONGOS_DRAG_HIDE_BAR)
	end
end

local function DragFrame_OnLeave()
	GameTooltip:Hide()
end

--[[ Constructor ]]--

function BDragFrame_Add(parent)
	local frame = CreateFrame('Button')
	frame.parent = parent
	
	frame:SetTopLevel(true)
	frame:SetClampedToScreen(true)
	frame:SetFrameStrata('DIALOG')
	
	frame:SetPoint("TOPLEFT", parent, "TOPLEFT", -4, 4)
	frame:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", 4, -4)
	
	--text
	frame:SetTextFontObject(GameFontNormalLarge)
	frame:SetHighlightTextColor(1, 1, 1)
	frame:SetText(parent.id)

	local normalTexture = button:CreateTexture()
	normalTexture:SetTexture(0, 0, 0, 0.4)
	normalTexture:SetAllPoints(button)

	local highlightTexture = button:CreateTexture()
	highlightTexture:SetTexture(0.2, 0.4, 0.8, 0.2)
	highlightTexture:SetAllPoints(button)
	frame:SetHighlightTexture(highlightTexture)

	frame:RegisterForClicks('anyUp')
	frame:SetScript('OnMouseDown', DragFrame_OnMouseDown)
	frame:SetScript('OnMouseUp', DragFrame_OnMouseUp)
	frame:SetScript('OnEnter', DragFrame_OnEnter)
	frame:SetScript('OnLeave', DragFrame_OnLeave)
	frame:SetScript('OnClick', DragFrame_OnClick)
	frame:Hide()
	
	parent.dragFrame = frame
end

--updates the drag button color of a given bar if its attached to another bar
function BDragFrame_UpdateSticky(dragFrame)
	if BBar.IsAnchored(dragFrame.parent) then
		dragFrame:SetTextColor(0.5, 0.5, 1)
	else
		dragFrame:SetTextColor(1, 0.82, 0)
	end
end