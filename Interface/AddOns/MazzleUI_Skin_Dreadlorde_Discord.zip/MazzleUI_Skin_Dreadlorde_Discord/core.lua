function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Skin_Dreadlorde_Discord\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Skin_Dreadlorde_Discord\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Skin_Dreadlorde_Discord\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Skin_Dreadlorde_Discord\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Skin_Dreadlorde_Discord\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Skin_Dreadlorde_Discord\\MazzleUICastingBarBorder",
            chatborder = "Interface\\AddOns\\MazzleUI_Skin_Dreadlorde_Discord\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Skin_Dreadlorde_Discord\\MazzleUIMinimapBorder",
        },
    }
end