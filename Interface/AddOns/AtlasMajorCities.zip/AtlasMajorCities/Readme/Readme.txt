AtlasMajorCities, a World of Warcraft Atlas plugin
Copyright 2006 - 2007 Sheavi, 2007 - 2009 Modefanz Coding
Email me at cashdash@t-online.de

==========================
= About AtlasMajorCities =
==========================

AtlasMajorCities is a plugin for Atlas (by Dan Gilbert) that add the possibility to browse the Major Cities maps with almost every 
Non-playing characters (NPCs) that you can interact with. It also include an advanced search function.

==================
= How to Install =
==================

* Unzip the package into: World of Warcraft/Interface/AddOns/
* Your zip software must preserve directory structures.
* You must have installed Atlas to get this Work.

===========
= Website =
===========
http://www.modefanz.eu
For more informations about Atlas or AtlasMajorCities see:
http://www.atlasmod.com/
There is a sub-forum for AtlasMajorCities in the Atlas forum.

=============
= Languages =
=============

- English (enUS/enGB)
- German  (deDE)

*We need translations, if you want to contribute to Our addon, e-mail me or contact us @ atlasmod.com please!*

===========
= Contact =
===========
Contact: PiDion | Modefanz Coding
Name: Andre Kocker
Email: cashdash@t-online.de

Contact: Chance
At the atlas Board under the nick: chance

===========
= Licence =
===========

AtlasMajorCities is released under the Creative Commons Attribution-Non-Commercial-Share Alike 3.0.
For the full licence text please see cc-by-nc-sa-3.enus.txt in the Readme folder.

==================
= Special Thanks =
==================

Thanks very very much for everyone that supported me in my project and to everyone that helped me.

- Special Thanks from Sheavi to :
- Dan Gilbert
- Daviesh
- Keith (this addon is born from his main code and ideas)
- Devive
- dcemuser
- Lothaer

- Special Thanks from PiDion to :
- Sheavi (to get the addon in my Way^^)
- Andy (for the first Lua Fixes when i had take over it)
- chance (for the help with the english files :D)
