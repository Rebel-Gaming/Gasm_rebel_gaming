if GetLocale()~="esES" then return end

ZygorTalentAdvisor_L("Main", "esES", function() return {
	-- ["English"] = "Localized",
} end)
