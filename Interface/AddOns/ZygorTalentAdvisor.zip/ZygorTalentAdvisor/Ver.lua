ZygorTalentAdvisor.revision = tonumber(string.sub("$Revision: 645 $", 12, -3))
ZygorTalentAdvisor.version = "2.0." .. ZygorTalentAdvisor.revision
ZygorTalentAdvisor.date = string.sub("$Date: 2009-12-10 23:29:31 -0500 (Thu, 10 Dec 2009) $", 8, 17)
--2009/12/11 02:58:55
