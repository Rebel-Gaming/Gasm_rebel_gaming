local sagz_Defaults = {
    ["Options"] = {
      ["status"] = "On",
      ["version"] = "1.0",
      ["debug"] = false,
      ["lasttime"] = 0,
    },
    ["Texts"] = {
      [1] = "gz",
      [2] = "gz #player"
    },
};


function sagz_SlashCmdHandler(message)
  local command, rest = message:match("^(%S*)%s*(.-)$");
  if (command == "help") then
      if (GetLocale() == "deDE") then
          -- things for the german client
          sagz_printMSG("Sven's Auto GZ Hilfe");
          sagz_printMSG("--------------------");
          sagz_printMSG("Befehle:");
          sagz_printMSG("help - diese Hilfeseite");
          sagz_printMSG("list - Alle Nachrichten auflisten");
          sagz_printMSG("say <Nr> - Eine bestimmte Nachricht testen");
          sagz_printMSG("add <Nachricht> - Eine Nachricht hinzufügen");
          sagz_printMSG("remove <Nr> - Eine bestimmte Nachricht entfernen");
          sagz_printMSG("Um den Spielernamen in Nachrichten einzufügen, bitte den Text %player verwenden.");
      else
       -- for the rest
          sagz_printMSG("Sven's Auto GZ Help");
          sagz_printMSG("--------------------");
          sagz_printMSG("Commands:");
          sagz_printMSG("help - these informations");
          sagz_printMSG("list - list all messages");
          sagz_printMSG("say <id> - test a specific message");
          sagz_printMSG("add <message> - add a message");
          sagz_printMSG("remove <id> - remove a specific message");
          sagz_printMSG("Use %player in your messages for the player's name.");
      end
  elseif (command == "add") then
      table.insert(sagz_Options["Texts"], rest);  
  elseif (command == "say") then
      player = UnitName("player");
--       nr = math.random(sagz_Defaults["Options"]["textcount"]);
--       sagz_printMSG("Nummer: "..rest);
      rndmsg = string.gsub(sagz_Options["Texts"][tonumber(rest)],"#player",player);
      sagz_printMSG(rndmsg);
  elseif (command == "remove") then
      table.remove(sagz_Options["Texts"], rest);
  elseif (command == "list") then
    for i,v in ipairs(sagz_Options["Texts"]) do 
        sagz_printMSG(i.." : "..v); 
    end
  else
      if (GetLocale() == "deDE") then
          -- things for the german client
          sagz_printMSG("Versuchen Sie bitte /sagz help für die Befehlsübersicht");
      else
          -- for the rest
          sagz_printMSG("Please try /sagz help");
      end
  end
end

function sagz_printMSG(msg)
  DEFAULT_CHAT_FRAME:AddMessage("sagz: " .. msg, 1, 0, 0);
end

function sagz_OnLoad()
  SlashCmdList["sagz"] = sagz_SlashCmdHandler;
  SLASH_sagz1 = "/sagz";
  
  this:RegisterEvent("CHAT_MSG_GUILD_ACHIEVEMENT");
  this:RegisterEvent("ADDON_LOADED");
  if (GetLocale() == "deDE") then
      -- things for the german client
      sagz_printMSG("Sven's Auto GZ ist nun geladen!");
  else
      -- for the rest
      sagz_printMSG("Sven's Auto GZ is now active!");
  end
end

function sagz_OnEvent( event, ... )
  if(event == "CHAT_MSG_GUILD_ACHIEVEMENT") then
    player = arg2;
    mynow = time();
    mydiff = mynow - sagz_Options["Options"]["lasttime"];
    -- only say something if last achievement is more than 5 seconds old
    if(mydiff > 5) then
        count = # sagz_Options["Texts"];
        nr = math.random(count);
        rndmsg = string.gsub(sagz_Options["Texts"][nr],"#player",player);
        SendChatMessage(rndmsg, "GUILD");
        sagz_Options["Options"]["lasttime"] = mynow;
    end
  end
  if (event == "ADDON_LOADED") and (arg1 == "sagz") then
      if (sagz_Options == nil) then 
          sagz_Options = sagz_Defaults;
          if (GetLocale() == "deDE") then
              -- things for the german client
              sagz_printMSG("Standards geladen!");
          else
              -- for the rest
              sagz_printMSG("Defaults loaded!");
          end
      else 
          if (GetLocale() == "deDE") then
              -- things for the german client
              sagz_printMSG("Benutzereinstellungen geladen!");
          else
              -- for the rest
              sagz_printMSG("Settings loaded!");
          end
      end
  end
end
