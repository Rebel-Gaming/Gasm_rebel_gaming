-- Author             :Alunra - Eredar - The Council of Legends
-- Version: V1.3
-- TCoL_ScoreUs - This addon will scan each member of a raid and score their gear, display their total health, show missing
--                enchants, talent spec, the number of greens/blues/epic each are wearing. For a detailed listing of how 
--		  these are calculated please view the readme.txt

-- Variable declaration
local ColorPally = "|cffF58CBA" -- pink
local ColorDeathKnight = "|cffC41F3B" -- red
local ColorHunter = "|cffABD473" -- green
local ColorMage = "|cff69CCF0" -- light blue
local ColorDruid = "|cffFF7D0A" -- orange
local ColorShaman = "|cff2459FF" -- navy blue
local ColorWarrior = "|cffC79C6E" -- brown
local ColorPriest = "|cffFFFFFF" -- white
local ColorRogue = "|cffFFF569" -- gold
local ColorWarlock = "|cff9482C9" -- purple
local ColorStats = "|cffFFF569" -- gold
local ColorScore = "|cffC41F3B" -- red

TCoL_ScoreUs_PlayersName = {}
TCoL_ScoreUs_PlayersStats = {}
TCoL_ScoreUs_TierBonuses = {}
TCoL_ScoreUs_Talents = {}
TCoL_ScoreUs_MissingGems = {}
TCoL_ScoreUs_MissingEnchants = {}
TCoL_ScoreUs_WearingGear = {}
TCoL_ilvlCount = 0
TCoL_Greenie = 0
TCoL_Blue = 0
TCoL_Epic = 0
TCoL_ScoreUs_Score = 0
TCoL_socketCount = 0
TCoL_ScoreUs_Gemmed = 0

-- BONUS Modifiers
local gemModifier = 20 --missing gem subtraction modifier
local TCoL_tierBonus = 50 --bonus for tier set bonus 2x and 4x, so if you have 4x set this bonus would be 100
local WSModifier = 60 --weapon or shield enchant plus value
local gearModifier = 35 --all other gear enchant plus value

local TCoL_ScoreUs_SlotName = {
	[1] = "HeadSlot",
	[2] = "NeckSlot",
	[3] = "ShoulderSlot",
	[4] = "BackSlot",
	[5] = "ChestSlot",
	[6] = "WristSlot",
	[7] = "HandsSlot",
	[8] = "WaistSlot",
	[9] = "LegsSlot",
	[10] = "FeetSlot",
	[11] = "Finger0Slot",
	[12] = "Finger1Slot",
	[13] = "Trinket0Slot",
	[14] = "Trinket1Slot",
	[15] = "MainHandSlot",
	[16] = "SecondaryHandSlot",
	[17] = "RangedSlot"
	}

local TCoL_ScoreUs_Legend1 = ColorStats.."MG|r - Empty Gem Sockets\n"
TCoL_ScoreUs_Legend1 = TCoL_ScoreUs_Legend1 .. ColorStats.."ME|r - Missing Enchants\n"
TCoL_ScoreUs_Legend1 = TCoL_ScoreUs_Legend1 .. ColorStats.."HP|r - Health"

local TCoL_ScoreUs_Legend2 = "|cffFFFFFFGear Quality Table|r\n"
TCoL_ScoreUs_Legend2 = TCoL_ScoreUs_Legend2 .. ColorStats .. "G|r - Green gear\n"
TCoL_ScoreUs_Legend2 = TCoL_ScoreUs_Legend2 .. ColorStats .. "B|r - Blue gear\n"
TCoL_ScoreUs_Legend2 = TCoL_ScoreUs_Legend2 .. ColorStats .. "E|r - Epic gear"

local TCoL_ScoreUs_Legend3 = "|cffFFFFFFMissing Enchant Table:|r  " .. ColorStats .. "S|r - Shoulders\n"
TCoL_ScoreUs_Legend3 = TCoL_ScoreUs_Legend3 .. ColorStats.."H|r - Head  " .. ColorStats.."F|r - Feet  " .. ColorStats.."M|r - Mainhand  " .. ColorStats.."R1|r - Ring 1\n"
TCoL_ScoreUs_Legend3 = TCoL_ScoreUs_Legend3 .. ColorStats.."C|r - Chest  " .. ColorStats.."B|r - Back  " .. ColorStats.."O|r - Offhand  " .. ColorStats.."R2|r - Ring 2\n"
TCoL_ScoreUs_Legend3 = TCoL_ScoreUs_Legend3 .. ColorStats.."W|r - Waist  " .. ColorStats.."L|r - Legs  " .. ColorStats.."G|r - Gloves  " .. ColorStats.."Wr|r - Wrist\n"
TCoL_ScoreUs_Legend3 = TCoL_ScoreUs_Legend3 .. ColorStats.."S|r - Shield  " .. ColorStats.."T|r - Thrown  "

TCoL_ScoreUs_Author = ColorStats .. "Version:|r 1.3     "..ColorStats.."Author:|r Alunra - Eredar - The Council of Legends"
 

function TCoL_ScoreUs_slash(cmd)
	if cmd and cmd == "open" then
	        TCoL_ScoreUs_Frame:Show()
	        TCoL_ScoreUs_Frame_Body:Show()
	        TCoL_ScoreUs_Frame_Body:SetPoint("TOP", "TCoL_ScoreUs_Frame", "BOTTOM", 0, 7)
	        TCoL_ScoreUs_Frame_Legend:Show()
	        TCoL_ScoreUs_Frame_Legend:SetPoint("TOP", "TCoL_ScoreUs_Frame_Body", "BOTTOM", 0, 7)
	        TCoL_ScoreUs_Legend_Text1:SetText(TCoL_ScoreUs_Legend1)
	        TCoL_ScoreUs_Legend_Text2:SetText(TCoL_ScoreUs_Legend2)
	        TCoL_ScoreUs_Legend_Text3:SetText(TCoL_ScoreUs_Legend3)
	        TCoL_ScoreUs_Legend_Text4:SetText(TCoL_ScoreUs_Author)
                TCoL_ScoreUs_Populate()
        end
end

function TCoL_ScoreUs_Populate()
	-- clear old frame information
        TCoL_ScoreUs_Players:SetText("")
        TCoL_ScoreUs_Stats:SetText("")
        TCoL_ScoreUs_Target = ""
        local TCoL_ScoreUs_PlayersNameText = ""
        local TCoL_ScoreUs_PlayersStatsText = ""
        
        -- clear old table information
        table.wipe(TCoL_ScoreUs_PlayersName)
        table.wipe(TCoL_ScoreUs_PlayersStats)
        table.wipe(TCoL_ScoreUs_TierBonuses)
        table.wipe(TCoL_ScoreUs_Talents)
        table.wipe(TCoL_ScoreUs_MissingGems)
        table.wipe(TCoL_ScoreUs_MissingEnchants)
        table.wipe(TCoL_ScoreUs_WearingGear)

        -- cycle through raid and populate entries for each player
        if (GetNumRaidMembers() > 0) and (GetNumRaidMembers() < 26) then
               --DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: Parsing Raid")
 	       for raidCount=1, GetNumRaidMembers(), 1 do
	               TCoL_ScoreUs_raidCount = raidCount
	               TCoL_ScoreUs_MissingGems[TCoL_ScoreUs_raidCount] = 0
	               TCoL_ScoreUs_MissingEnchants[TCoL_ScoreUs_raidCount] = ""	               
                       TCoL_ScoreUs_Target = "raid" .. raidCount
	                       if (CheckInteractDistance(TCoL_ScoreUs_Target, 1)) then
	                               if UnitIsPlayer(TCoL_ScoreUs_Target) and CanInspect(TCoL_ScoreUs_Target) then
	                               	       TCoL_ScoreUs_Score = 0
	                               	       TCoL_ScoreUs_TierBonuses[raidCount] = 0
	                                       _, TCoL_ScoreUs_PlayerClass = UnitClass("raid" .. raidCount)
	                                       TCoL_ScoreUs_PlayersName[TCoL_ScoreUs_raidCount] = TCoL_ScoreUs_PlayersColor() .. UnitName("raid" .. raidCount) .. "|r\n"
                                               TCoL_ScoreUs_PlayersStats[TCoL_ScoreUs_raidCount] = TCoL_ScoreUs_GearCycle()
                                               TCoL_ScoreUs_PlayersNameText = TCoL_ScoreUs_PlayersNameText .. raidCount.." "..TCoL_ScoreUs_PlayersName[TCoL_ScoreUs_raidCount]
                                               TCoL_ScoreUs_PlayersStatsText = TCoL_ScoreUs_PlayersStatsText .. TCoL_ScoreUs_PlayersStats[TCoL_ScoreUs_raidCount]
                                       end
                               else
                               	       _, TCoL_ScoreUs_PlayerClass = UnitClass("raid" .. raidCount)
                                       TCoL_ScoreUs_PlayersName[TCoL_ScoreUs_raidCount] = raidCount.." "..TCoL_ScoreUs_PlayersColor() .. UnitName("raid" .. raidCount) .. "|r\n"
                                       TCoL_ScoreUs_PlayersStats[TCoL_ScoreUs_raidCount] = "|cffC79C6Eout of range|r\n"
                                       local _, _, _, _, _, _, _, TCoL_playerOnline, TCoL_playerIsDead, _, _ = GetRaidRosterInfo(raidCount);
                                       if (TCoL_playerOnline == nil) then
                                       		TCoL_ScoreUs_PlayersStats[TCoL_ScoreUs_raidCount] = "|cffC79C6Eoffline|r\n"
                                       end
                                       if (TCoL_playerIsDead == 1) then
                                       		TCoL_ScoreUs_PlayersStats[TCoL_ScoreUs_raidCount] = "|cffC79C6EHes dead Jim!|r\n"
                                       end
                                       TCoL_ScoreUs_PlayersNameText = TCoL_ScoreUs_PlayersNameText .. TCoL_ScoreUs_PlayersName[TCoL_ScoreUs_raidCount]
                                       TCoL_ScoreUs_PlayersStatsText = TCoL_ScoreUs_PlayersStatsText .. TCoL_ScoreUs_PlayersStats[TCoL_ScoreUs_raidCount]                                       
                               end
               end
               TCoL_ScoreUs_Players:SetText(TCoL_ScoreUs_PlayersNameText)
               TCoL_ScoreUs_Stats:SetText(TCoL_ScoreUs_PlayersStatsText)
        else
               TCoL_ScoreUs_Stats:SetText("You are not in a raid or your raid exceeds 25 players")
               return
    	end
    	--HideUIPanel(InspectFrame)
end

function TCoL_ScoreUs_PlayersColor()
		--DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: Assign Player Color- " .. TCoL_ScoreUs_PlayerClass)
                if TCoL_ScoreUs_PlayerClass == "PALADIN" then return ColorPally end
                if TCoL_ScoreUs_PlayerClass == "WARRIOR" then return ColorWarrior end
                if TCoL_ScoreUs_PlayerClass == "ROGUE" then return ColorRogue end
                if TCoL_ScoreUs_PlayerClass == "PRIEST" then return ColorPriest end
                if TCoL_ScoreUs_PlayerClass == "SHAMAN" then return ColorShaman end
                if TCoL_ScoreUs_PlayerClass == "WARLOCK" then return ColorWarlock end
                if TCoL_ScoreUs_PlayerClass == "DRUID" then return ColorDruid end
                if TCoL_ScoreUs_PlayerClass == "MAGE" then return ColorMage end
                if TCoL_ScoreUs_PlayerClass == "DEATHKNIGHT" then return ColorDeathKnight end
                if TCoL_ScoreUs_PlayerClass == "HUNTER" then return ColorHunter end
                return
end

function TCoL_ScoreUs_GearCycle()
	InspectUnit(TCoL_ScoreUs_Target)
	--x=0
        --for i=1, 2000000 do x=x+1 end
	for gearCount=1, 17 do
		TCoL_gearCount = gearCount
		TCoL_slotID, _ = GetInventorySlotInfo(TCoL_ScoreUs_SlotName[gearCount])
		if (GetInventoryItemLink(TCoL_ScoreUs_Target, TCoL_slotID)) then
			TCoL_itemLink = GetInventoryItemLink(TCoL_ScoreUs_Target, TCoL_slotID)
			TCoL_itemName, TCoL_itemString, TCoL_itemQuality, TCoL_ilvl, _, _, _, _, TCoL_itemEquipLoc, _ = GetItemInfo(TCoL_itemLink)
			TCoL_ScoreUs_Score = TCoL_ScoreUs_ItemScore(TCoL_ilvl, TCoL_itemQuality)
			TCoL_ScoreUs_MissingEnchants[TCoL_ScoreUs_raidCount] = TCoL_ScoreUs_MissingEnchants[TCoL_ScoreUs_raidCount]..TCoL_ScoreUs_EnchantCheck()
			TCoL_ScoreUs_MissingGems[TCoL_ScoreUs_raidCount] = TCoL_ScoreUs_MissingGems[TCoL_ScoreUs_raidCount] + TCoL_ScoreUs_GemCheck()
			TCoL_ScoreUs_TierBonusesCheck()
			TCoL_ScoreUs_TalentsCheck()
		end
	end
	
	-- Add Tier Bonuses
	if (TCoL_ScoreUs_TierBonuses[TCoL_ScoreUs_raidCount] >= 2) then TCoL_ScoreUs_Score = TCoL_ScoreUs_Score + 50 end
	if (TCoL_ScoreUs_TierBonuses[TCoL_ScoreUs_raidCount] >= 4) then TCoL_ScoreUs_Score = TCoL_ScoreUs_Score + 50 end
		
	TCoL_ScoreUs_WearingGear[TCoL_ScoreUs_raidCount] = ColorStats.." G:|r"..TCoL_Greenie..ColorStats.." B:|r"..TCoL_Blue..ColorStats.." E:|r"..TCoL_Epic.."\n"
	if (TCoL_ScoreUs_MissingEnchants[TCoL_ScoreUs_raidCount] == "") then TCoL_ScoreUs_MissingEnchants[TCoL_ScoreUs_raidCount] = "none" end
	
	
	-- Stats
	TCoL_Stats = ColorStats .. "Score: |r" .. ColorScore .. TCoL_ScoreUs_Score .. "|r"
	TCoL_Stats = TCoL_Stats .. ColorStats .. "  HP: |r" .. UnitHealthMax(TCoL_ScoreUs_Target)	
	TCoL_Stats = TCoL_Stats .. ColorStats .. "  ME: |r" .. TCoL_ScoreUs_MissingEnchants[TCoL_ScoreUs_raidCount]
	--TCoL_Stats = TCoL_Stats .. ColorStats .. "  MG:|r " .. TCoL_ScoreUs_MissingGems[TCoL_ScoreUs_raidCount]
	TCoL_Stats = TCoL_Stats .. TCoL_ScoreUs_WearingGear[TCoL_ScoreUs_raidCount]
	--TCoL_Stats = TCoL_Stats .. ColorStats .. " Spec:|r " .. TCoL_ScoreUs_Talents[TCoL_ScoreUs_raidCount]
	
	-- Enchant variable rest
	enchant_id = ""
	
	-- gear score rest
	TCoL_ilvlCount = 0
	
	-- gear variable reset
	TCoL_Greenie = 0
	TCoL_Blue = 0
	TCoL_Epic = 0
	
	-- Gem variable reset
	TCoL_socketCount = 0
	TCoL_ScoreUs_Gemmed = 0
	
	-- item variable reset
	ClearInspectPlayer()
	TCoL_itemString = ""
	TCoL_itemID = ""
	
	return TCoL_Stats
end

function TCoL_ScoreUs_EnchantCheck()
	TCoL_tmpMissingEnchants=""
	local enchantValue = 0
	_, TCoL_itemID, TCoL_enchantID, TCoL_gem1ID, TCoL_gem2ID, TCoL_gem3ID, TCoL_gem4ID = strsplit(":", TCoL_itemString)	
	--local val1, val2, val3, val4, val5, val6, val7, val8 = strsplit(":", TCoL_itemString)	
	--DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: itemString: " ..val1.."-"..val2.."-"..val3.."-"..val4.."-"..val5.."-"..val6.."-"..val7.."-"..val8)
	
	if (TCoL_itemEquipLoc == "INVTYPE_HEAD" ) and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "H" else enchantValue = gearModifier end
	if (TCoL_itemEquipLoc == "INVTYPE_NECK" ) then end --no neck enchant
	if (TCoL_itemEquipLoc == "INVTYPE_SHOULDER" ) and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "S" else enchantValue = gearModifier 	 end
	if (TCoL_itemEquipLoc == "INVTYPE_CLOAK") and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "B" else enchantValue = gearModifier  end
	if (TCoL_itemEquipLoc == "INVTYPE_CHEST") and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "C" else enchantValue = gearModifier  end
	if (TCoL_itemEquipLoc == "INVTYPE_WRIST" ) and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "Wr" else enchantValue = gearModifier  end
	if (TCoL_itemEquipLoc == "INVTYPE_HAND" ) and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "G" else enchantValue = gearModifier  end
	if (TCoL_itemEquipLoc == "INVTYPE_LEGS" ) and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "L" else enchantValue = gearModifier  end
	if (TCoL_itemEquipLoc == "INVTYPE_FEET") and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "F" else enchantValue = gearModifier  end
	-- RINGS
	--if (tonumber(TCoL_gearCount) == 11) and (tonumber(TCoL_enchantID) == 0)  and GetSpellInfo((GetSpellInfo(7411))) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. TCoL_ScoreUs_EnchantSlotDesc[TCoL_gearCount] end 
	--if (tonumber(TCoL_gearCount) == 12) and (tonumber(TCoL_enchantID) == 0)  and GetSpellInfo((GetSpellInfo(7411))) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. TCoL_ScoreUs_EnchantSlotDesc[TCoL_gearCount] end
	if (TCoL_itemEquipLoc == "INVTYPE_WEAPONMAINHAND") and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "M" else enchantValue = WSModifier end
	-- 2H weapons count the bonus twice
	if (TCoL_itemEquipLoc == "INVTYPE_2HWEAPON") and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "M" else enchantValue = (WSModifier * 2) end
	if (TCoL_itemEquipLoc == "INVTYPE_WEAPONOFFHAND") and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "O" else enchantValue = gearModifier end
	--if (TCoL_itemEquipLoc == "INVTYPE_THROWN") and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "T" end
	if (TCoL_itemEquipLoc == "INVTYPE_SHIELD") and (tonumber(TCoL_enchantID) == 0) then TCoL_tmpMissingEnchants = TCoL_tmpMissingEnchants .. "S" else enchantValue = WSModifier end
	
	-- check the items enchant and calculate the value of the enchant based on the level needed to do the enchant
--	if (tonumber(TCoL_enchantID) > 0) then
--		-- clear the textures first
--		for tooltipCount = 1, 10 do
--			_G["TCoL_ScoreUs_TooltipTexture"..tooltipCount]:SetText("");
--		end
--		TCoL_ScoreUs_Tooltip:SetOwner(UIParent,"ANCHOR_NONE");
--		TCoL_ScoreUs_Tooltip:ClearLines();
--		TCoL_ScoreUs_Tooltip:SetHyperlink("enchant:"..TCoL_itemID)
--		if (TCoL_ScoreUs_Tooltip:NumLines() > 0) then
--			for tooltipCount=1, TCoL_ScoreUs_Tooltip:NumLines()-1 do
--				local tmp_lefttext = "TCoL_ScoreUs_TooltipTextLeft"..tooltipCount
--				local TCoL_leftText = _G["TCoL_ScoreUs_TooltipTextLeft"..tooltipCount]:GetText()
--				DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: textLeft: " .. TCoL_leftText.."-"..TCoL_enchantID.."-"..TCoL_itemID)
--				if TCoL_leftText then
--					local str1, str2, str3 = strsplit(" ", TCoL_leftText, 3)
--					if (str1 == "Requires") then
--						local enchantValue = abs(tonumber(str3) / 13)
--						DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: enchantValue: " .. enchantValue.."-"..str3.."-"..TCoL_leftText)
--					end
--				end
--			end
--		end
--	end
	TCoL_ScoreUs_Score = (TCoL_ScoreUs_Score + enchantValue)
	return TCoL_tmpMissingEnchants
end

function TCoL_ScoreUs_ItemScore(TCoL_ilvl, TCoL_itemQuality)
	--DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: itemScore: " .. TCoL_itemQuality)
	TCoL_ilvlCount = TCoL_ilvlCount + TCoL_ilvl
	if (TCoL_itemQuality == 2) or (TCoL_itemQuality == "2") then TCoL_Greenie = TCoL_Greenie + 1 end
	if (TCoL_itemQuality == 3) or (TCoL_itemQuality == "3")  then TCoL_Blue = TCoL_Blue + 1 end
	if (TCoL_itemQuality == 4) or (TCoL_itemQuality == "4")  then TCoL_Epic = TCoL_Epic + 1 end
	return TCoL_ilvlCount
end

function TCoL_ScoreUs_GemScan()
	--DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: NumLines: " .. TCoL_ScoreUs_Tooltip:NumLines())
	TCoL_ScoreUs_Tooltip:ClearLines();
	TCoL_ScoreUs_Tooltip:SetHyperlink("item:"..TCoL_itemID)	
	if (TCoL_ScoreUs_Tooltip:NumLines() > 0) then
		for gemCount=1, TCoL_ScoreUs_Tooltip:NumLines() do
			local tmp_lefttext = "TCoL_ScoreUs_TooltipTextLeft"..gemCount
			local TCoL_leftText = _G["TCoL_ScoreUs_TooltipTextLeft"..gemCount]:GetText()
			if TCoL_leftText then
				local scanText = TCoL_leftText
				--DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: Text: " .. TCoL_leftText)
				if (scanText == "Yellow Socket") or (scanText == "Red Socket") or (scanText == "Blue Socket") or (scanText == "Meta Socket") then
					TCoL_socketCount = TCoL_socketCount + 1
					local scanText=""
					--DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: SocketCount: " .. TCoL_socketCount .. "-" .. TCoL_itemLink)
				end
			else
				local scanText = ""
			end
		end
	end
	--DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: SocketCount: " .. UnitName(TCoL_ScoreUs_Target).."-".. TCoL_socketCount)
end

function TCoL_ScoreUs_Close()
	TCoL_ScoreUs_Frame_Body:Hide()
	TCoL_ScoreUs_Frame_Legend:Hide()
end

function TCoL_ScoreUs_TierBonusesCheck()
	-- check for tier7 set bonuses
	local itemName,_ = strsplit(" ", TCoL_itemName)
	if (itemName == "Valorous") or (itemName == "Heroes\'") then
		TCoL_ScoreUs_TierBonuses[TCoL_ScoreUs_raidCount] = TCoL_ScoreUs_TierBonuses[TCoL_ScoreUs_raidCount] + 1
	end
end

function TCoL_ScoreUs_TalentsCheckOLD()
	--local val1,val2,val3,val4 = GetTalentTabInfo(1,true)
	local talentTab1,talentTab2,talentTab3 = 0,0,0
	local _,_,talentTab1,_ = GetTalentTabInfo(1,true)
	local _,_,talentTab2,_ = GetTalentTabInfo(2,true)
	local _,_,talentTab3,_ = GetTalentTabInfo(3,true)
	--DEFAULT_CHAT_FRAME:AddMessage("TCoL_ScoreUs Debug: Talents: " .. val1 .. "-" .. val2.."-"..val3.."-"..val4)
	TCoL_ScoreUs_Talents[TCoL_ScoreUs_raidCount] = talentTab1.."/"..talentTab2.."/"..talentTab3
end

function TCoL_ScoreUs_Pause(pauseCount)
	local x=0
	for pauseTimer=1, pauseCount, 1 do
		x=x+1
	end
	x=0
end

function TCoL_ScoreUs_TextStrings()

end

function TCoL_ScoreUs_GemCheck()
	-- this modified code is taken from Tristanian current updater for BonusScanner based on a conversation that I
	-- had with him for scanning for missing gems by textures. so nice code Tristanian.
	if not TCoL_itemLink or TCoL_itemLink == "" then return end
	local textureCount = nil
	local emptySockets = 0
	-- clear the textures first
	for textureCount = 1, 4 do
		if _G["TCoL_ScoreUs_TooltipTexture"..textureCount] then
			_G["TCoL_ScoreUs_TooltipTexture"..textureCount]:SetTexture("");
		end
	end
	TCoL_ScoreUs_Tooltip:SetOwner(UIParent,"ANCHOR_NONE");
	TCoL_ScoreUs_Tooltip:ClearLines();
	TCoL_ScoreUs_Tooltip:SetHyperlink(TCoL_itemString);
	for textureCount = 1, 4 do
		local temp = _G["TCoL_ScoreUs_TooltipTexture"..textureCount]:GetTexture();
		-- texture check
		--if temp then DEFAULT_CHAT_FRAME:AddMessage(textureCount..": "..temp) end --debug code
		if temp and temp == "Interface\\ItemSocketingFrame\\UI-EmptySocket-Meta" then emptySockets = emptySockets + 1 end
		if temp and temp == "Interface\\ItemSocketingFrame\\UI-EmptySocket-Red" then emptySockets = emptySockets + 1 end
		if temp and temp == "Interface\\ItemSocketingFrame\\UI-EmptySocket-Yellow" then emptySockets = emptySockets + 1 end 	
		if temp and temp == "Interface\\ItemSocketingFrame\\UI-EmptySocket-Blue" then emptySockets = emptySockets + 1 end 	
	end
	return emptySockets
end

function TCoL_ScoreUs_OnLoad()
                TCoL_ScoreUs_Frame:RegisterForDrag("LeftButton")
                SlashCmdList["TCoLEmblems"] = TCoL_ScoreUs_slash
                SLASH_TCoLEmblems1 = "/tcolsu"
end

function TCoL_ScoreUs_TalentsCheck()
local specTab, tree
if CheckInteractDistance(TCoL_ScoreUs_Target, 1) then -- and (not UnitIsUnit("player", TCoL_ScoreUs_Target)) then
        --NotifyInspect(TCoL_ScoreUs_Target)

        talentSpec = ""
        tree = { select(3, GetTalentTabInfo(1, true)), select(3, GetTalentTabInfo(2, true)), select(3, GetTalentTabInfo(3, true)) }
        -- treeTotal = tree[1] + tree[2] + tree[3]
	for treeCount = 1, #tree do
                if tree[treeCount] >= tree[1] and tree[treeCount] >= tree[2] and tree[treeCount] >= tree[3] then
                        specTab = treeCount
	                break
                end
        end
        talentSpec = tree[1].."/"..tree[2].."/"..tree[3]
	TCoL_ScoreUs_Talents[TCoL_ScoreUs_raidCount] = talentSpec.." "..GetTalentTabInfo(specTab, true).."\n"
end
end