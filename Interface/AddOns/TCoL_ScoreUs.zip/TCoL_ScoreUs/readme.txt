TCoL ScoreUs - World of Warcraft addon
Author: Alunra(main) Taborious(alt)
Server: Eredar
Guild: TCoL - The Council of Legends
Localization: sorry, this is only my second addon and I do not know enough about localization yet to utilize it. So this version will only work on the English version of WoW. If someone out there would like to contact me via curse regarding localization Id be happy to incorporate it.
Special Note: The coding for this addon is bad. As I mentioned it is only my second addon and I was using the knowledge that I had. I understand it could be written much more efficiently but until i have more lua knowledge it is what it is and it WORKS! so please, flame off coders. I have several ideas for change and additions and during that time I will rewrite a lot of the code.

Special Thanks!: To all the members of The Council of Legends for putting up with me testing the addon and helping me by joining my little raid group so that I could test. Also, for all the input I got during the process. An extra thanks out to those who helped me with extra input and time.
Code troubleshooting: Lenziltord
Calculation for Scoring: Shadohlor & Durin

Overview:
This addon will scan each member of a raid and score their gear, display their total health, show missing
enchants and the number of greens/blues/epic each are wearing in a spreadsheet type format. This is most useful for raid leaders to determine who is the best geared for certain tasks. 

Scoring:
Currently a players score is based on 3 things. ilvl quality, enchants & tier set bonuses. 
	base score = ilvl sum of all gear (excluding tabard & shirt)
	enchant score = 
		Weapon&Shield Modifier = 60 --weapon or shield enchant plus value
		Gear Modifier = 35 --all other gear enchant plus value
		Tier bonuses = 2x bonue=+50 4x bonus=+100 (this is NOT +150, you get +50 for 2x, and once you have 4x, you get +50 again since you have 2 bonuses)

** currently the belt buckle is not checked as I am having issues with gem checking

Version:

1.2	Initial release


To-Do:

- gem quality check for adjusted scoring
- T8 set bonuses
- coding, i need to change the way I am using fontsrting but that is all behind the curtain stuff
- belt buckle check
- check for profession bonuses, ring enchant for enchanters, etc...
- create fubar plugin

