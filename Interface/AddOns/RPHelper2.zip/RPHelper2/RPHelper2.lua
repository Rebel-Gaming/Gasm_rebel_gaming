RPHelper2 = LibStub("AceAddon-3.0"):NewAddon("RPHelper2", "AceConsole-3.0", "AceEvent-3.0")
RPH_L = LibStub("AceLocale-3.0"):GetLocale("RPHelper2")

RPHelper2.playerMoney = -1
RPHelper2.playerTanking = false
RPHelper2.hp = -1
RPHelper2.lasthp = -1
RPHelper2.lastmana = -1
RPHelper2.lastpethp = -1
RPHelper2.TalkToNPCBoxClosed = GetTime()
RPHelper2.LastRP = GetTime()
RPHelper2.IsDead = false
RPHelper2.IsChanneling = false
RPHelper2.RPedAtLeastOnce = false
RPHelper2.JustRPed = false
RPHelper2.currentMount = ""
RPHelper2.InstanceChannel = "SAY"

function RPHelper2:OnInitialize()
	if not (RPHelper2DBPC and RPHelper2DBPC.global) then
		RPHelper2DBPC ={global={}}
	end
--RPHelper2:RegisterDB("RPHelper2DB", "RPHelper2DBPC")
end

function RPHelper2:OnEnable()
	self:defineEvents() -- defines events in the database
	if not RPHelper2DBPC.global.RPLang then
		self:Print("Initializing...")
		self:InitializeSayings()
	end
	if self.initializeOptions then self:initializeOptions(true) end
	if RPHelper2DBPC.global.isEnabled then
		self:initializeEvents() -- starts event capture
	end
	local AceConfigReg = LibStub("AceConfigRegistry-3.0")
	local AceConfigDialog = LibStub("AceConfigDialog-3.0")
--Adding options tables to the Blizzard options
	AceConfigReg:RegisterOptionsTable("RPHelper2", self.giveDictionary)
	AceConfigReg:RegisterOptionsTable("RPHelper2 General Options",self.giveGeneralOptions)
	AceConfigReg:RegisterOptionsTable("RPHelper2 Mount Names",self.giveMountOptions)
	self.events_options=self:giveEventOptions()
	AceConfigReg:RegisterOptionsTable("RPHelper2 Events Options",self.events_options)
	self.spells_options=self.giveSpellOptions()
	AceConfigReg:RegisterOptionsTable("RPHelper2 Spells Options",self.spells_options)
	self.custom_options=self.giveCustomOptions()
	AceConfigReg:RegisterOptionsTable("RPHelper2 Custom Events Options",self.custom_options)
	AceConfigReg:RegisterOptionsTable("RPHelper2 Random Insult Options",self.giveInsultOptions)
	self.giveDictionary=nil
	self.giveGeneralOptions=nil
	self.giveMountOptions=nil
	self.giveEventOptions=nil
	self.giveSpellOptions=nil
	self.giveCustomOptions=nil
	--Must define options table before this bit.
   	self.optionsFrame = AceConfigDialog:AddToBlizOptions("RPHelper2", "RPHelper2")
	self.optionsFrame["About"] = LibStub("LibAboutPanel").new("RPHelper2", "RPHelper2")
	self.optionsFrame["General"]= AceConfigDialog:AddToBlizOptions("RPHelper2 General Options", "General", "RPHelper2")
	self.optionsFrame[MOUNTS] = AceConfigDialog:AddToBlizOptions("RPHelper2 Mount Names", COMPANIONS, "RPHelper2")
	self.optionsFrame[RPH_L["Events"]] = AceConfigDialog:AddToBlizOptions("RPHelper2 Events Options", RPH_L["Events"], "RPHelper2")
	self.optionsFrame[RPH_L["Spells"]] = AceConfigDialog:AddToBlizOptions("RPHelper2 Spells Options", RPH_L["Spells"], "RPHelper2")
	self.optionsFrame["Custom Events"] = AceConfigDialog:AddToBlizOptions("RPHelper2 Custom Events Options", "Custom Events", "RPHelper2")
	self.optionsFrame["Random Insults"] = AceConfigDialog:AddToBlizOptions("RPHelper2 Random Insult Options","Random Insults", "RPHelper2")
    self:RegisterChatCommand("rp", "ChatCommand")
    self:RegisterChatCommand("rphelper", "ChatCommand")
	self:RegisterChatCommand("ri", function()
		self:Roleplay({"RINSULT"},{},{})
		end)
end

function RPHelper2:OnDisable()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
end


function RPHelper2:ChatCommand(input)
    if not input or input:trim() == "" then
        InterfaceOptionsFrame_OpenToCategory(self.optionsFrame)
    else
        LibStub("AceConfigCmd-3.0").HandleCommand(RPHelper2, "rp", "RPHelper2", input)
    end
end

--=======================
--Fubar functions
--=======================
--function RPHelper2:OnTextUpdate()
--    if self:IsTextShown() then
--        self:SetText("RPHelper2")
--    end
--end
--function RPHelper2:OnTooltipUpdate()
--	if tablet then
--	    tablet:SetHint("Click to open Settings Dialog")
--	end
--end

--function RPHelper2:OnClick()
--	if not IsAddOnLoaded("RPHelper2_GUI") then
--		LoadAddOn("RPHelper2_GUI")
--		self:initializeOptions(true)
--	end
--	if (self.value == 0) then
--		AceLibrary("Waterfall-1.0"):Open('RPHelper2')
--		self.value = 1;
--	else
--		AceLibrary("Waterfall-1.0"):Close('RPHelper2')
--		self.value = 0;
--	end
--end
--=====================================


--RegisterMessage doesn't work right; will fix later
function RPHelper2:initializeEvents()
	self:RegisterEvent("PLAYER_ENTERING_WORLD")
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	self:RegisterEvent("CHAT_MSG_SYSTEM")
	--if RPHelper2DBPC.global.RPEvent.petattackstart and RPHelper2DBPC.global.RPEvent.petattackstart.Sayings and self:getChance("petattackstart") > 0 then	
		self:RegisterEvent("PET_ATTACK_START", "GenericEvent", "petattackstart")
	--end
	--if RPHelper2DBPC.global.RPEvent.petattackstop and RPHelper2DBPC.global.RPEvent.petattackstop.Sayings and self:getChance("petattackstop") > 0 then
		self:RegisterEvent("PET_ATTACK_STOP","GenericEvent", "petattackstop")
	--end
	--if RPHelper2DBPC.global.RPEvent.resurrect.Sayings and self:getChance("resurrect") > 0 then
		self:RegisterEvent("PLAYER_UNGHOST")
		self:RegisterEvent("PLAYER_ALIVE")
	--end
	--if RPHelper2DBPC.global.RPEvent.player_camping.Sayings and self:getChance("player_camping") > 0 then
		self:RegisterEvent("PLAYER_CAMPING","GenericEvent", "player_camping")
	--end
	--if RPHelper2DBPC.global.RPEvent.entercombat.Sayings and self:getChance("entercombat") > 0 then
		self:RegisterEvent("PLAYER_REGEN_DISABLED","GenericEvent", "entercombat") --Entering combat
	--end
	--if RPHelper2DBPC.global.RPEvent.leavecombat.Sayings and self:getChance("leavecombat") > 0 then
		self:RegisterEvent("PLAYER_LEAVE_COMBAT","GenericEvent","leavecombat") --Leaving combat
	--end
	self:RegisterEvent("PLAYER_LEVEL_UP")
	--if (RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings or RPHelper2DBPC.global.RPEvent.talktonpc_middle.Sayings) and (self:getChance("talktonpc_beginning") + self:getChance("talktonpc_middle")) > 0 then
		self:RegisterEvent("MERCHANT_SHOW", "TalkToNPC")
		self:RegisterEvent("QUEST_COMPLETE", "TalkToNPC")
		self:RegisterEvent("QUEST_DETAIL", "TalkToNPC")
		self:RegisterEvent("QUEST_GREETING", "TalkToNPC")
		self:RegisterEvent("QUEST_PROGRESS", "TalkToNPC")
		self:RegisterEvent("GOSSIP_SHOW", "TalkToNPC")
	--end
	--if RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings and self:getChance("talktonpc_end") > 0 then
		self:RegisterEvent("GOSSIP_CLOSED", "TalkToNPCEnd")
		self:RegisterEvent("MERCHANT_CLOSED", "TalkToNPCEnd")
		self:RegisterEvent("QUEST_FINISHED", "TalkToNPCEnd")
	--end
	--if RPHelper2DBPC.global.RPEvent.mount.Sayings and self:getChance("mount") > 0 then
		self:RegisterEvent("COMPANION_UPDATE")
	--end
	--if RPHelper2DBPC.global.RPEvent.trade_show.Sayings and self:getChance("trade_show") > 0 then
		self:RegisterEvent("TRADE_SHOW")
	--end
	--if RPHelper2DBPC.global.RPEvent.trade_closed.Sayings and self:getChance("trade_closed") > 0 then
		self:RegisterEvent("TRADE_CLOSED")
	--end
	--if RPHelper2DBPC.global.RPEvent.low_mana and RPHelper2DBPC.global.RPEvent.low_mana.Sayings and self:getChance("low_mana") > 0 and UnitPowerType("player") == MANA then
		self:RegisterEvent("UNIT_MANA")
	--end
	--if RPHelper2DBPC.global.RPEvent.welcome_home.Sayings and self:getChance("welcome_home") > 0 then
		self:RegisterEvent("ZONE_CHANGED")
	--end
--Mail events
	--if RPHelper2DBPC.global.RPEvent.mail_closed.Sayings and self:getChance("mail_closed") > 0 then
		self:RegisterEvent("MAIL_CLOSED","GenericEvent","mail_closed")
	--end
	self:RegisterEvent("MAIL_SEND_SUCCESS","GenericEvent","mail_send")
	self:RegisterEvent("MAIL_SHOW", "GenericEvent", "mail_open")
	self:RegisterEvent("BANKFRAME_OPENED","GenericEvent","bank_open")
	self:RegisterEvent("BANKFRAME_CLOSED","GenericEvent","bank_closed")
	self:RegisterEvent("GUILDBANKFRAME_OPENED","GenericEvent","guildbank_open")
	self:RegisterEvent("GUILDBANKFRAME_CLOSED","GenericEvent","guildbank_closed")
	self:RegisterEvent("LOOT_OPENED","GenericEvent","loot_open")
	self:RegisterEvent("LOOT_CLOSED","GenericEvent","loot_closed")
	self:RegisterEvent("CHAT_MSG_MONEY")
--Vehicle events
	self:RegisterEvent("UNIT_ENTERED_VEHICLE")
	self:RegisterEvent("UNIT_EXITED_VEHICLE")
--Future events:
--"CHAT_MSG_LOOT" - you put something in your bags
--"CHAT_MSG_MONSTER_EMOTE"
--"CHAT_MSG_MONSTER_SAY"
--"CHAT_MSG_MONSTER_YELL"
-- CHAT_MSG_SYSTEM - for the following:
----ERR_AUCTION_BID_PLACED
----ERR_DUEL_REQUESTED
--Character eats/drinks
end

function RPHelper2:GetPhrase(EventOrSpell)
	local s = {}	-- table of sayings
	local e = {}-- table of emotes
	local c = {}	-- table of custom emotes
	local r = {}	-- table of random phrase tables
	if RPHelper2DBPC.global.RPEvent[EventOrSpell]["Sayings"] then
	s = self:JoinArrays(s,RPHelper2DBPC.global.RPEvent[EventOrSpell]["Sayings"])
	for k,v in pairs(RPHelper2DBPC.global.RPEvent[EventOrSpell]["Sayings"]) do
		if string.find(k, "customemote") then
			c=self:JoinArrays(c,RPHelper2DBPC.global.RPEvent[EventOrSpell]["Sayings"][k])
		elseif string.find(k, "emote") then
			e=self:JoinArrays(e,RPHelper2DBPC.global.RPEvent[EventOrSpell]["Sayings"][k])
		elseif string.find(k, "random") then
			if getn(RPHelper2DBPC.global.RPEvent[EventOrSpell]["Sayings"][k]) >0 then
			r = self:JoinArrays(r, RPHelper2DBPC.global.RPEvent[EventOrSpell]["Sayings"][k])
			end
		end
	end
	--if r then 
	--	r = self:RandomPhraseChooser( r ) 
	--	self:JoinArrays(s,r)
	--end
	self:JoinArrays(s,r)
	return s,e,c
	else
	return {},{},{}
	end
end

function RPHelper2:Roleplay(sayings, emotes, customemotes)
	sayings=self:ReplaceFlags(sayings)
	emotes=self:ReplaceFlags(emotes)
	customemotes=self:ReplaceFlags(customemotes)
	sayings = self:ReplaceKeywords( sayings, "saying" )
	customemotes = self:ReplaceKeywords( customemotes, "customemote" )
	local sSize = table.getn( sayings )
	local eSize = 0
	local cSize = table.getn( customemotes )
	--Some emotes interrupt a channeled spell, so we only use the emote table if player is not channeling
	if (self.IsChanneling == false) and (emotes) then
		eSize = table.getn( emotes )
	end
---------------------
--Deciding what language to RP in
--To do in the future - add Lore support
---------------------
	local RPLanguage
	if RPHelper2DBPC.global.RPLang == 0 then
		RPLanguage = DEFAULT_CHAT_FRAME.editBox.language
	elseif RPHelper2DBPC.global.RPLang == 1 then
		RPLanguage = GetLanguageByIndex( math.random( GetNumLanguages() ) )
	else
		RPLanguage = GetLanguageByIndex(RPHelper2DBPC.global.RPLang-1)
	end
--Here we choose which message to send
	if (sSize + eSize + cSize) > 0 then
		local x = math.random(sSize + eSize + cSize)
--Custom emotes
		if x > (sSize + eSize) then
			SendChatMessage( customemotes[x - sSize - eSize], "EMOTE" )  -- CUSTOM EMOTE
--Regular emotes
		elseif x > sSize then
			if string.find( emotes[x - sSize], " SELF" ) then
				emotes[x - sSize] = string.gsub( emotes[x - sSize], " SELF", "" )
				DoEmote( emotes[x - sSize], "player" )		  -- SELF EMOTE
			else
				DoEmote( emotes[x - sSize] )                  -- EMOTE	
			end
--Saying something
		else
--			if self.LoreRP and Lore_Cycle then self:LoreRP(sayings[x],RPLanguage) else
			if HasFullControl() or UnitInVehicle("player") then
				if IsInInstance() then
					SendChatMessage( sayings[x], self.InstanceChannel, RPLanguage )
				else
					SendChatMessage( sayings[x], "SAY", RPLanguage )        -- SAYING
				end
			else
				SendChatMessage( sayings[x], "PARTY", RPLanguage )        -- In cases like fear, possession, etc.
			end
--			end
		end
	end
	self.JustRPed = true
end

function RPHelper2:ReplaceFlags(x)
----------------------
--New! Flags!
----------------------
	local i = 1
	while x[i] do
		--self:Print(x[i])
		if type(x[i]) == "string" then
--Gender flags
			if string.find(x[i],"{"..FEMALE.."}") then
				if UnitSex("target") == 3 then x[i] = string.gsub(x[i],"{"..FEMALE.."}","") else x[i] = "REMOVE ME" end
			elseif string.find(x[i],"{"..MALE.."}") then
				if UnitSex("target") == 2 then x[i] = string.gsub(x[i],"{"..MALE.."}","") else x[i] = "REMOVE ME" end
			end
--Mob Type
			local mobTypes={RPH_L["Beast"],RPH_L["Critter"],RPH_L["Demon"],RPH_L["Dragonkin"],RPH_L["Elemental"],RPH_L["Giant"],RPH_L["Humanoid"],
				RPH_L["Mechanical"],RPH_L["UndeadTYPE"]}
			for j=1,getn(mobTypes) do
				local pattern="{"..strsub(mobTypes[j],1,3).."}"
				--self:Print(pattern)
				if string.find(x[i],pattern) then
				--self:Print("zomg")
					if UnitCreatureType("target") == mobTypes[j] then x[i] = string.gsub(x[i],pattern,"") else x[i]="REMOVE ME" end
				end
			end
--Friend/Enemy
			if string.find(x[i],"{"..FRIENDLY.."}") then
				if UnitIsFriend("player","target") then x[i] = string.gsub(x[i],"{"..FRIENDLY.."}","") else x[i] = "REMOVE ME" end
			elseif string.find(x[i],"{"..ENEMY.."}") then
				if UnitIsFriend("player","target") then x[i] = "REMOVE ME" else x[i] = string.gsub(x[i],"{"..ENEMY.."}","") end
			end
--Level
			if string.find(x[i],"{"..BOSS.."}") then
				if UnitClassification("target") == "worldboss" then x[i] = string.gsub(x[i],"{"..BOSS.."}","") else x[i] = "REMOVE ME" end
			elseif string.find(x[i],"{"..ELITE.."}") then
				if UnitClassification("target") == "elite" or UnitClassification("target") == "rareelite" then x[i] = string.gsub(x[i],"{"..ELITE.."}","") else x[i] = "REMOVE ME" end
			end
			for j=1, GetNumLanguages() do
				local pattern = "{"..GetLanguageByIndex(j).."}"
				if string.find(x[i],pattern) then
				end
			end
			if x[i] == "REMOVE ME" then
				tremove(x,i)
			else
				i = i + 1
			end
		else
			tremove(x,i)
		end
	end
	return x
--Vehicle flags are handled in the appropriate event handlers. Maybe move them here?
end

function RPHelper2:ReplaceKeywords(x, RPType)
	local i = 1
while x[i] do
	if type(x[i]) == "string" then
---------------------------------------------------------------------------
-- RINSULT! or RINSULT
---------------------------------------------------------------------------
		if string.find( x[i], "RINSULT%!" ) then
			local ri = self:RandInsult()
			if ri then
      				ri = string.gsub( ri, "%.", "%!" ) -- Replace period with exclamation mark
      				x[i] = string.gsub( x[i], "RINSULT%!", ri ) -- Only substitute the ones with exclamation marks
			else
				x[i] = "REMOVE ME"
			end
		end

		if string.find( x[i], "RINSULT" ) then
			if self:RandInsult() then
      				x[i] = string.gsub( x[i], "RINSULT", self:RandInsult() )
			else
				x[i] = "REMOVE ME"
			end
		end
---------------------------------------------------------------------------
-- Pet's name
---------------------------------------------------------------------------
		if string.find( x[i], "PNAME" ) then
			if UnitExists("pet") then
				x[i] = string.gsub( x[i], "PNAME", (UnitName("pet")) )
			else
				  x[i] = "REMOVE ME"
			end
		end
---------------------------------------------------------------------------
-- Your class
---------------------------------------------------------------------------
           		 if string.find( x[i], "PLAYER_CLASS" ) then
            			local class = UnitClass("player")
			x[i] = string.gsub( x[i], "PLAYER_CLASS", class )
	 	end
---------------------------------------------------------------------------
-- Your race
---------------------------------------------------------------------------
		if string.find( x[i], "PLAYER_RACE" ) then
		            	local race = UnitRace("player")
			x[i] = string.gsub( x[i], "PLAYER_RACE", race )
		end
---------------------------------------------------------------------------
-- Your target's class
---------------------------------------------------------------------------
		if string.find( x[i], "TARGET_CLASS" ) then
			if UnitExists("target") and UnitIsPlayer("target") and ( (UnitName("target")) ~= (UnitName("player")) ) then
				local class = UnitClass("target")
				x[i] = string.gsub( x[i], "TARGET_CLASS", class )
			else
				x[i] = "REMOVE ME"
			end
            		end
---------------------------------------------------------------------------
-- Your target's race
---------------------------------------------------------------------------
           		if string.find( x[i], "TARGET_RACE" ) then
			if UnitExists("target") and UnitIsPlayer("target") and ( (UnitName("target")) ~= (UnitName("player")) ) then
			            	local race = UnitRace("target")
				x[i] = string.gsub( x[i], "TARGET_RACE", race )
			else
				x[i] = "REMOVE ME"
			end
		end

---------------------------------------------------------------------------
-- Your guild's name & rank
---------------------------------------------------------------------------
		if string.find( x[i], "PLAYER_GUILDNAME" ) or string.find( x[i], "PLAYER_GUILDRANK" )  then
			local guildName, guildRankName, guildRankIndex = GetGuildInfo("player")
			if guildName and guildRankName then
				x[i] = string.gsub( x[i], "PLAYER_GUILDNAME", guildName )
				x[i] = string.gsub( x[i], "PLAYER_GUILDRANK", guildRankName )
			else
				    x[i] = "REMOVE ME"
			end
		end
---------------------------------------------------------------------------
-- Your target's guild's name & rank
---------------------------------------------------------------------------
		if string.find( x[i], "TARGET_GUILDNAME" ) or string.find( x[i], "TARGET_GUILDRANK" ) then
			local guildName, guildRankName, guildRankIndex = GetGuildInfo("target")
			if UnitExists("target") and UnitIsPlayer("target") and ((UnitName("target")) ~= (UnitName("player")) ) and guildName and guildRankName then
				x[i] = string.gsub( x[i], "TARGET_GUILDNAME", guildName )
				x[i] = string.gsub( x[i], "TARGET_GUILDRANK", guildRankName )
			else
				x[i] = "REMOVE ME"
			end
            	end

---------------------------------------------------------------------------
-- Pet's target (name & personal pronouns)
---------------------------------------------------------------------------
		if string.find( x[i], "PT.P" ) or string.find( x[i], "PTNAME" ) then
			if UnitExists("pettarget") then
				local PTSP, PTOP, PTPP = "","",""
			    	if UnitSex("pettarget") == 2 then
					PTSP, PTOP, PTPP = RPH_L["he"], RPH_L["him"], RPH_L["his"]
			        elseif UnitSex("pettarget") == 3 then
					PTSP, PTOP, PTPP = RPH_L["she"], RPH_L["herOP"], RPH_L["herPP"]
				else
					PTSP, PTOP, PTPP = RPH_L["itSP"], RPH_L["itOP"], RPH_L["its"]
			        end

				x[i] = string.gsub( x[i], "PTNAME", (UnitName("pettarget")) )
				x[i] = string.gsub( x[i], "PTSP", PTSP )
				x[i] = string.gsub( x[i], "PTOP", PTOP )
				x[i] = string.gsub( x[i], "PTPP", PTPP )
			else
				x[i] = "REMOVE ME"
			end
		end
---------------------------------------------------------------------------
-- Your target (Name & Personal pronouns)
---------------------------------------------------------------------------
		if string.find( x[i], "TSP" ) or string.find( x[i], "TOP" ) or string.find( x[i], "TPP" ) or string.find( x[i], "TARGET" ) then
			if UnitExists("target") then
				local TSP, TOP, TPP = "","",""
			    	if UnitSex("target") == 2 then
					TSP, TOP, TPP = RPH_L["he"], RPH_L["him"], RPH_L["his"]
			        elseif UnitSex("target") == 3 then
					TSP, TOP, TPP = RPH_L["she"], RPH_L["herOP"], RPH_L["herPP"]
				else
					TSP, TOP, TPP = RPH_L["itSP"], RPH_L["itOP"], RPH_L["its"]
			        end
				x[i] = string.gsub( x[i], "TARGET", (UnitName("target")) )
				x[i] = string.gsub( x[i], "TSP", TSP )
				x[i] = string.gsub( x[i], "TOP", TOP )
				x[i] = string.gsub( x[i], "TPP", TPP )
			else
				x[i] = "REMOVE ME"
			end
		end
---------------------------------------------------------------------------
-- You (Name & Personal pronouns)
---------------------------------------------------------------------------
		if string.find( x[i], "SP" ) or string.find( x[i], "OP" ) or string.find( x[i], "PP" ) or string.find( x[i], "PLAYER" ) then
			local SP,OP,PP = "","",""
			    	if UnitSex("player") == 2 then
					SP, OP, PP = RPH_L["he"], RPH_L["him"], RPH_L["his"]
			        elseif UnitSex("player") == 3 then
					SP, OP, PP = RPH_L["she"], RPH_L["herOP"], RPH_L["herPP"]
				else
					SP, OP, PP = RPH_L["itSP"], RPH_L["itOP"], RPH_L["its"]
			        end
              			x[i] = string.gsub( x[i], "PLAYER", (UnitName("player")) )
				x[i] = string.gsub( x[i], "SP", SP )
				x[i] = string.gsub( x[i], "OP", OP )
				x[i] = string.gsub( x[i], "PP", PP )
		end
---------------------------------------------------------------------------
-- Power Types: Player and Target
-- Tells what power type you or your target uses (mana, rage, energy)
---------------------------------------------------------------------------
---------------------------------------------------------------------------
-- Home (your hearthstone bind location)
---------------------------------------------------------------------------
            	if string.find( x[i], "HOME" ) then
                	x[i] = string.gsub( x[i], "HOME", GetBindLocation() )
            	end
-----------------
--Your mount
-----------------
		if string.find( x[i], "MOUNTNAME" ) then
			if RPHelper2DBPC.global.mounts[self.currentMount] then
				x[i] = string.gsub( x[i], "MOUNTNAME", RPHelper2DBPC.global.mounts[self.currentMount])
			else
	                	x[i]="REMOVE ME"
			end
		end
        if string.find( x[i], "MOUNT" ) then
			local myMount
			if string.find(self.currentMount, "Summon ") then
				myMount = string.gsub(self.currentMount, "Summon ", "")
			else
				myMount = self.currentMount
			end
			x[i] = string.gsub( x[i], "MOUNT", myMount )
         end
            ---------------------------------------------------------------------------
			-- Power Types: Player and Target
			-- Tells what power type you or your target uses (mana, rage, energy)
            ---------------------------------------------------------------------------
		if string.find( x[i], "PLAYER_POWER" ) then
			local power = UnitPowerType("player")
	                if (power == 0) then power = MANA 
        	        elseif (power == 1) then power = RAGE 
                	elseif (power == 3) then power = ENERGY 
					elseif (power==5) then power = RUNES
					elseif (power==6) then power = RUNIC_POWER end
	                x[i] = string.gsub( x[i], "PLAYER_POWER", power)
		end
            
		if string.find( x[i], "TARGET_POWER" ) then
			if UnitExists("target") and (UnitName("target")) ~= (UnitName("player")) then
				local power = UnitPowerType("target")
				if (power == 0) then power = MANA 
				elseif (power == 1) then power = RAGE 
               	elseif (power == 3) then power = ENERGY 
				elseif (power==5) then power = RUNES
				elseif (power==6) then power = RUNIC_POWER end
				x[i] = string.gsub( x[i], "TARGET_POWER", power)
			else
				x[i]= "REMOVE ME"
			end
		end
---------------------------------------------------------------------------
-- Zone Info
-- MAIN_ZONE is the zone you're in, ie. Western Plaguelands
-- SUB_ZONE is the subzone you're in, ie. Ruins of Andorhall
-- (if you're not in a subzone, SUB_ZONE will revert to MAIN_ZONE)
---------------------------------------------------------------------------
        if string.find( x[i], "MAIN_ZONE" ) then
	        x[i] = string.gsub( x[i], "MAIN_ZONE", GetRealZoneText() )
		end
		if string.find( x[i], "SUB_ZONE" ) then
			local zonetext = GetSubZoneText()
			if (zonetext == "") then
				zonetext = GetRealZoneText()
                	end
                    	x[i] = string.gsub( x[i], "SUB_ZONE", zonetext )
            	end
---------------------------------------------------------------------------
-- Capitalize after a period, exclamation mark or question mark
---------------------------------------------------------------------------
		x[i] = string.gsub( x[i], "%.  (%l)", function(s) return ".  "..string.upper(s) end )     -- 2 spaces
		x[i] = string.gsub( x[i], "%.   (%l)", function(s) return ".   "..string.upper(s) end )   -- 3 spaces
		x[i] = string.gsub( x[i], "%.%s+(%l)", function(s) return ". "..string.upper(s) end )     -- any other # becomes 1 space

		x[i] = string.gsub( x[i], "%!  (%l)", function(s) return "!  "..string.upper(s) end )
		x[i] = string.gsub( x[i], "%!   (%l)", function(s) return "!   "..string.upper(s) end )
		x[i] = string.gsub( x[i], "%!%s+(%l)", function(s) return "! "..string.upper(s) end )

		x[i] = string.gsub( x[i], "%?  (%l)", function(s) return "?  "..string.upper(s) end )
		x[i] = string.gsub( x[i], "%?   (%l)", function(s) return "?   "..string.upper(s) end )
		x[i] = string.gsub( x[i], "%?%s+(%l)", function(s) return "? "..string.upper(s) end )

---------------------------------------------------------------------------
-- Capitalize the beginning of a saying
---------------------------------------------------------------------------
		if RPType == "saying" then
			x[i] = string.gsub( x[i], "^(%l)", function(s) return string.upper(s) end )
		end
---------------------------------------------------------------------------
-- Put the edited phrase into the original phrase's spot.
---------------------------------------------------------------------------
		if x[i] == "REMOVE ME" then
			tremove(x,i)
		else
			i = i + 1
		end
	else
		tremove(x,i)
	end
	end -- WHILE
	return x
end


function RPHelper2:RandInsult() -- returns "string" insult; if 1 of the parts is missing, returns false
	local Part1 = {}
	local Part2 = {}
	local Part3 = {}
	local insult
	
if not RPHelper2DBPC.global.RandomInsult then
	self:InitializeInsults(GetLocale())
end
	if RPHelper2DBPC.global.RandomInsult[1] then
		Part1 = self:JoinArrays( Part1, RPHelper2DBPC.global.RandomInsult[1] )
	end
	if RPHelper2DBPC.global.RandomInsult[2] then
		Part2 = self:JoinArrays( Part2, RPHelper2DBPC.global.RandomInsult[2] )
	end
	if RPHelper2DBPC.global.RandomInsult[3] then
		Part3 = self:JoinArrays( Part3, RPHelper2DBPC.global.RandomInsult[3] )
	end
	    
	if ( table.getn( Part1 ) > 0 ) and ( table.getn( Part2 ) > 0 ) and ( table.getn( Part3 ) > 0 ) then
		local p1 = math.random( table.getn( Part1 ) )
		local p2 = math.random( table.getn( Part2 ) )
		local p3 = math.random( table.getn( Part3 ) )
	    
	    -- YOU is a localized variable from Blizzard's GlobalStrings.lua
		insult = YOU .. " " .. Part1[p1] .. " " .. Part2[p2] .. " " .. Part3[p3] .. "."
		return insult
	else
		return false
	end
end


function RPHelper2:RandomPhraseChooser(r)
--This function was pretty much copied unchanged from the original and needs some pruning.
	local RandomPhraseTable = {}
	if r then
		local NumOfPhrases = table.getn( r )
		for k,v in pairs(r) do
			local PhraseWithBlanks, NumOfBlanks = string.gsub( r[k]["phrase"], "BLANK", "BLANKx" )
			local NumOfPossibilities = 1
				for i = 1,NumOfBlanks do
     					NumOfPossibilities = NumOfPossibilities * table.getn( r[k][i] )
				end
				r[k]["NumOfPhrases"] = Round ( NumOfPossibilities / 40 )  -- 40 is an arbitrary number I picked
				if r[k]["NumOfPhrases"] < 1 then
					r[k]["NumOfPhrases"] = 1
				end
				for i = 1, r[k]["NumOfPhrases"] do
					local CompletedPhrase = PhraseWithBlanks
					for j = 1,NumOfBlanks do
						local x = math.random( table.getn( r[k][j] ) )
						CompletedPhrase = string.gsub( CompletedPhrase, "BLANKx", r[k][j][x], 1 )
					end
					table.insert( RandomPhraseTable, CompletedPhrase )
				end

		end
	end
	return RandomPhraseTable
end

function RPHelper2:SameEventStrings( GlobalString, x )
	-- To fix the "unfinished capture" error on French Clients
	GlobalString = string.gsub(GlobalString, "%(", "")
	GlobalString = string.gsub(GlobalString, "%)", "")
	x = string.gsub(x, "%(", "")
	x = string.gsub(x, "%)", "")

	local PartsToCompare = {}
	local a = 1
	local b = string.find( GlobalString, "%%" )
	while b do
		table.insert( PartsToCompare, string.sub( GlobalString, a, b-1 ) )
		a = b+2
		b = string.find( GlobalString, "%%", a )
	end
	table.insert( PartsToCompare, string.sub( GlobalString, a ) )

	local ItsTheSame = true
	for k, v in pairs(PartsToCompare) do
			if string.find( x, v ) == nil then
				ItsTheSame = false
				return ItsTheSame
			end
		end

	return ItsTheSame
end

function RPHelper2:JoinArrays( x, y, useSelectedDialect)
	local i = 1
	if not x and y then
		x=y
	else
		if y then
		while y[i] do
			if useSelectedDialect and self.useDialect and type(y[i]) == "string" then
				y[i] = self:useDwarvenizer(y[i])
			end
			table.insert( x,y[i] )
			i = i + 1
		end
		end
	end
	if x then return x end
end