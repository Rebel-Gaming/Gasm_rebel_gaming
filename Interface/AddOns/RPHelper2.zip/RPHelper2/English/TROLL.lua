function RPHelper2:InitializeTROLL(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB" ) then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Contributors to this file:  mithyk

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"Ya gween ta bark all day or ya gween ta bite?",
	"Strengt aan Honah!",
	"Fi Glory, mon! Fi Honah!",
	"Tremble! A hero a' di Horde be upon ja'!",
	"Fi di Horde!",
	"Oh we gween get along jus' fine!",
	"Mi gween make ja' suffah like ja' was an elf!",
	"Keepin' it real up inna di field.",
	"Mi di baddest soul inna town, mon.",
	"Tas'dingo!",
	"It be time fi a lickle blood.",
	"Now we kill.",
	"Ja' made big mistake.",
	"Here come di voodoo!",
	"Di Loa nuh like ja' much.",
	"Rock aan roll!",
	"Let's Rock!",
	"Fine, mi kill ja' first den eat.",
	"Ja' come get some.",
	"Mi be openin' a bag a' whoopass 'pon ja' now!",
	"Let's zee how big ja' bite be!",
	"Fi di glory a' di warchief!",
	"Fi di glory a' di Horde!",
	"Victory fi di Horde!",
	"Mi life fi di Horde!",
	"Time fi Killin'!",
	"Ja' nuh survive!",
	"Taste di fury a' di Horde!",
	"Deat to all dat oppose di Horde!",
	"Fi Durotah!",
	"A PLAYER_CLASS a' Durotah be upon ja'!",
	"Vengeance for Zul'Jin!",
	"Remember Zul'Jin!",
	"Fool! Jah dare assault one a' PLAYER_GUILDNAME?",
	"Me shall rid SUB_ZONE a' jah filty presence!",
	"PLAYER_GUILDNAME be upon ja!",
	})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"Snarl","Guffaw","Growl","Laugh","Crack"}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {
	
	["phrase"] = "Ja' BLANK, BLANK BLANK",
	
	[1] = {"gween","'bout ta","haffi" },
	
	[2] = {"give mi yer powah","leave di flesh","die", },
	
	[3] = {"aan ain't naa Loa be savin' ya!","fi mi Loa be strongah dan yours!","fi ya face a membah a' di darkspear tribe!"},

})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {
	"Mi came, Mi saw, Mi found some breakfass.",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {"grin SELF","wink"})                                       
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {
	"So much fi foreplay!",
	"Mi would nuh do such tings if mi was you.",
	"Very well, if dass di way you wanna play it.",
	"Ya be payin fi dat!",
	"Does dis mean we're nuh fren's no more?",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {"BLEED","Snarl","growl",})       
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {
	"Did nuh even scratch mi!",
	"Ha! Completely absorbed dat laas hit.",
	"Mi juss get hit? Mi nuh feel it...",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {"laugh SELF","guffaw SELF","wink",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.block then
self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {
	"Ha! Blocked it.",
	"Dat mi shield.",
	"A 'ow mi shield feel?",
	"Haha! Blocked dat one!",
	"Blocked dat laas one.",
	"Jah tryin' to hit mi shield?",
	"Dis mi shield. Deh be many like it, but dis one mine.",
	"Mi shield mi life.",
	"Mi hab a very close fren'ship wid mi shield - we watch one anuddah back.",
	"Wha do mi shield ebah do to deserve a beatin' like dat?",
	"Wha do mi shield ebah do to deserve a beatin' like dat?", 
	"Mi juss get dis shield re-painted!", 
	"Nuh blow shall pass!", 
})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {"laugh SELF","guffaw SELF","wink",}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
end
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {
	"Haha! Dodged dat one!",
	"Dodged dat laas one.",
	"Dodged it easy.",
	"Dodged it. Mi obah here now.",
	"Naa nuh go catch me stan' steel.",                   -- mithyk
	"Cyan't touch dis.",                                -- mithyk
	"At least try to hit mi.",                          -- mithyk
	"Stop trying ta hit me, and HIT ME!",               -- mithyk
	"Jah attack like a clumsy chile, TARGET.",          -- mithyk (modified)
	"Jah call dat an attack?",                         -- mithyk
	"Try swinging di weapon TOWAAD mi!",              -- mithyk
	"Whenebah-time ja waan fi get inna di fight juss jump on inna.",
	"A who teach ja fi fight?",	
	"Ja done hit anytin yet?",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {"laugh SELF","guffaw SELF","wink",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {
	"Ha! Missed mi!",
	"Dat one breezed right by mi.",
	"Be nuh di objective to hit me?", 
	"When jah attack, you suppose to hit mi.", 
	"Hey, you miss me! Mi obah here!",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {"laugh SELF","guffaw SELF","wink",}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.parry then
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {
	"Ha! Parried it easy.",
	"'ow jah like dat parry? RINSULT",
	"Intercepted!",   
	"Dat attack nuh bettah dan dat a' a clumsy chile.",
	"Jah call dat an attack?",   
	"Ja'll haffi do bettah dan dat, TARGET.",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {"laugh SELF","guffaw SELF","wink",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
end
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {
	"Be 'appy. Look a mi, mi 'appy.",
	"We be jammin'!",
	"Mi smell fear.",
	"Mi eatchu still warm body.",
	"Dat look like it haat.",
	"Ha! Did dat haat, TARGET?",
	"Ooh, mi bet dat haat!",
	"Ooh, do dat haat, TARGET? Jah go cry now?",
	"Ooh dat gotta haat.",
	"Dat look painful!",
	"Dat hab to haat TOP",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {"laugh SELF","guffaw SELF","wink",}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {
	"Be 'appy. Look a mi, mi 'appy.",
	"We be jammin'!",
	"Mi smell fear.",
	"Mi eatchu still warm body.",
	"Dat look like it haat.",
	"Ha! Did dat haat, TARGET?",
	"Ooh, mi bet dat haat!",
	"Ooh, do dat haat, TARGET? Jah go cry now?",
	"Ooh dat gotta haat.",
	"Dat look painful!",
	"Dat hab to haat TOP",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {"laugh SELF","guffaw SELF","wink",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.youheal then
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.emote, {"pray",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.customemote, {
	"says a quick prayer of healing.",
	"calls upon the Loa to spread the healing.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.random, {})
end
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.youcritheal then
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.emote, {"pray",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.customemote, {
	"say's a quick prayer of healing.",
	"calls upon the Loa to spread the healing.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.random, {})
end
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME, Pet's Name	
	-- PTNAME, Pet's target's name                           
	-- PTSP, Pet's target's subject pronoun 	(He/She/It)
	-- PTOP, Pet's target's object pronoun 	(him/her/it)
	-- PTPP, Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random, {})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME, Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random, {})
--=====================================================================--
-- When your PET DIES.
	-- PNAME, Pet's Name
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.emote, {})      
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.random, {})
--=====================================================================--
-- When you talk to an NPC  (A dialogue/merchant/quest/etc. box opens)
--=====================================================================--
-------------------------------------------------------------------------
-- The BEGINNING of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
	-- "KNEEL" is automatically added if the NPC is 5 levels higher than you
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings, {
	"TARGET, greetins mon.",
	"TARGET, 'ello mon.",
	"TARGET, talk ta me.",
	"Hay der TARGET.",
	"Di Loa be wit jah TARGET.",
	"TARGET, how jah doin mon?",
	"TARGET, how are ja?",
	"TARGET, don' be shy.",
	"TARGET, jah come get da voodoo.",
	"Watcha jah mean what kinda' accent is dis? It's a TROLL accent. TARGET, I swear jah' makin' meh crazy.",
})
-------------------------------------------------------------------------
-- The END of a conversation with an NPC 
	-- "CURTSEY" is automatically added for female characters
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings, {
	"TARGET, Spirits be with ya mon.",
	"TARGET, you be careful mon.",
	"Be sein ya, TARGET.",
	"Be good, TARGET.",
	"Bye bye now, TARGET.",
	"TARGET, di Loa be wid jah mon.",
	"Latteh TARGET.",
	"Seeya latteh TARGET.",
	"Okie dokie, TARGET.",
	"Stay away from da voodoo, TARGET.",
})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {
	"Mi be alive!",
	"Huh? Wha? How did me get here?",
	"Tanks Doc, I be owin ya one.",
	"All patched up aan ready fi action!",
	"Hehe, dem missed all mi vital spots!",
	"Tas'dingo, blacked out fi a minute!",
	"Tought mi was done fi sure dat time.",
	"Dat's gonna leave a mark.",
	"Dis scar be gettin' mi lotta attention!",
	"Mi walked among di loa, but now mi be wakin.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {
	
	["phrase"]= "BLANK BLANK",
	
	[1]= {"Tanks to di Loa,","By mi Loa's interference,","Di Loa smile 'pon mi,","Di Loa favah mi,"},
	
	[2]= {"mi survived.","mi be livin'.","me life been spared.","mi still inna di flesh.","mi remain 'pon di world."},

})

--=====================================================================--
--  Fear, etc.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})
elseif ( myLocale == "deDE") then
if self.TrollDE then self:TrollDE() end
elseif (myLocale == "frFR") then
if self.TrollFR then self:TrollFR() end
elseif (myLocale == "esES") then
if self.TrollES then self:TrollES() end
end
end