function RPHelper2:InitializeWARLOCK(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB" ) then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"I shall fight fire... with fire.",
	"Chaos boils in my mind.",
	"Your screams will fill the air.",
	"I'll make sure you suffer.",
	"Your pain shall be legendary.",
	"You shall know my wrath.",
	"You offer yourself to me freely; the pact is sealed.",
	"You will be mine.",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"FROWN","GRIN","GLARE","GROWL","WRATH",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME, Pet's Name	
	-- PTNAME, Pet's target's name                           
	-- PTSP, Pet's target's subject pronoun 	(He/She/It)
	-- PTOP, Pet's target's object pronoun 	(him/her/it)
	-- PTPP, Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings, {
	"Show PTOP the meaning of pain, PNAME.",
	"Destroy PTOP, PNAME.",
	"Destroy PTOP for me, PNAME.",
	"PNAME!  I want that soul!",
	"PNAME!  Keep up!",
	"PNAME!  Shred the flesh!",
	"PNAME!  Destroy the husk!",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random, {})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME, Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings, {
	"Try harder, PNAME.",
	"Put more effort into it next time, PNAME.",
	"Do you ever put real effort into anything, PNAME?",
	"Do not attempt to stray from me, PNAME.",
	"Well enough, you won't be punished this time, PNAME.",
	"Keep it up and you'll feast on a soul this night, PNAME.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random, {})
--=====================================================================--
-- When your PET DIES.
	-- PNAME, Pet's Name
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings, {
	"Noooo!",
	"Rotten Spawn of the Abyss!",
	"PNAME, you won't escape me so easily as that!",
	"PNAME! Get up you useless excuse for demonspawn!",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.random, {})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.npctalksfriend then RPHelper2DBPC.global.RPEvent.npctalksfriend = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, { "You spew LANG like urine, NPC." })
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {

	["phrase"] = "BLANK BLANK BLANK",

	[1]= {
		"Quiet NPC.",
		"Shut up NPC.",
		"Quit your babbling NPC.",
		"Don't break my peace NPC.",
		"Don't break my concentration NPC.",
		},

	[2]= {
		"Unless you hope to",
		"Unless you want to",
		"Unless it's your wish to",
		"Unless it's your desire to",
		"Or I'll let know how it feels to",
		"Or else you'll know how it feels to",
		},

	[3]= {
		"be sent into the Twisting Nether.",
		"have your soul drained from you.",
		"suddenly catch on fire.",
		"have a shadow bolt in your groin.",
		"have your face melt off.",
		"have your tongue burnt out.",
		},
		
	})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.npctalksenemy then RPHelper2DBPC.global.RPEvent.npctalksenemy = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, { "You spew LANG like urine, NPC." })
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {

	["phrase"] = "BLANK BLANK BLANK",

	[1] = {
		"Quiet NPC.",
		"Shut up NPC.",
		"Quit your babbling NPC.",
		"Don't break my peace NPC.",
		"Don't break my concentration NPC.",
		},

	[2] = {
		"Unless you hope to",
		"Unless you want to",
		"Unless it's your wish to",
		"Unless it's your desire to",
		"Or I'll let know how it feels to",
		"Or else you'll know how it feels to",
		},

	[3] = {
		"be sent into the Twisting Nether.",
		"have your soul drained from you.",
		"suddenly catch on fire.",
		"have a shadow bolt in your groin.",
		"have your face melt off.",
		"have your tongue burnt out.",
		},
		
	})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})

--=====================================================================--
--  Racials
	-- This way you can RP your racial differently as different classes
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.random, {})

--=====================================================================--
--  Fear, etc.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings, {"Wait a minute, shouldn't it be I who causes YOU to run away?"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})


--//////////////////////////////////////////////////////////////////////////--
-- Sayings Spells
--//////////////////////////////////////////////////////////////////////////--
--=====================================================================--
-- Affliction
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.curse_of_weakness then RPHelper2DBPC.global.RPEvent.curse_of_weakness = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_weakness.Sayings, {"Feeling a little weak, TARGET?"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_weakness.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_weakness.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_weakness.Sayings.random, {})
                                                   
if not RPHelper2DBPC.global.RPEvent.curse_of_agony then RPHelper2DBPC.global.RPEvent.curse_of_agony = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_agony.Sayings, {"I shall inflict pain and agony upon you, TARGET!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_agony.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_agony.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_agony.Sayings.random, {}) 
                                                   
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_recklessness.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_recklessness.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_recklessness.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_recklessness.Sayings.random, {})     
                                        
if not RPHelper2DBPC.global.RPEvent.curse_of_tongues then RPHelper2DBPC.global.RPEvent.curse_of_tongues = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_tongues.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_tongues.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_tongues.Sayings.customemote, {"makes TARGET speak in demonic.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_tongues.Sayings.random, {})                                                                                                   
                                                   
if not RPHelper2DBPC.global.RPEvent.curse_of_exhaustion then RPHelper2DBPC.global.RPEvent.curse_of_exhaustion = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_exhaustion.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_exhaustion.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_exhaustion.Sayings.customemote, {"causes lactic acid to form in TARGET's muscles."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_exhaustion.Sayings.random, {})                                                                                                 
                                                   
if not RPHelper2DBPC.global.RPEvent.curse_of_the_elements then RPHelper2DBPC.global.RPEvent.curse_of_the_elements = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_the_elements.Sayings, {"I don't think you are as guarded against magic as you thought, TARGET."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_the_elements.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_the_elements.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_the_elements.Sayings.random, {})                                                                                             
                                                   
if not RPHelper2DBPC.global.RPEvent.curse_of_doom then RPHelper2DBPC.global.RPEvent.curse_of_doom = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_doom.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_doom.Sayings.emote, {"WRATH"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_doom.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.curse_of_doom.Sayings.random, {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.amplify_curse.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.amplify_curse.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.amplify_curse.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.amplify_curse.Sayings.random, {})

------------------------------------------------------------------------- 
if not RPHelper2DBPC.global.RPEvent.drain_soul then RPHelper2DBPC.global.RPEvent.drain_soul = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.drain_soul.Sayings, {
	"I'll swallow your soul.",
	"Your soul shall burn!",
	"You will know endless torment.",
	"Your soul is mine!",
	"Your soul will sustain my demons.",
	"My demons must feast.",
	"You are mine.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.drain_soul.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.drain_soul.Sayings.random, {})       

if not RPHelper2DBPC.global.RPEvent.drain_life then RPHelper2DBPC.global.RPEvent.drain_life = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.drain_life.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.drain_life.Sayings.customemote, {"begins sucking the very life from TARGET."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.drain_life.Sayings.random, {})    

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.drain_mana.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.drain_mana.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.drain_mana.Sayings.random, {}) 


------------------------------------------------------------------------- 
if not RPHelper2DBPC.global.RPEvent.corruption then RPHelper2DBPC.global.RPEvent.corruption = {Sayings={}} end                                                                          
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.corruption.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.corruption.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.corruption.Sayings.customemote, {"causes cancerous lesions to grow within TARGET."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.corruption.Sayings.random, {}) 
                                                  
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.siphon_life.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.siphon_life.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.siphon_life.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.siphon_life.Sayings.random, {}) 

if not RPHelper2DBPC.global.RPEvent.seed_of_corruption then RPHelper2DBPC.global.RPEvent.seed_of_corruption = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seed_of_corruption.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.seed_of_corruption.Sayings.emote, {"GRIN"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seed_of_corruption.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seed_of_corruption.Sayings.random, {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.unstable_affliction.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.unstable_affliction.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.unstable_affliction.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.unstable_affliction.Sayings.random, {}) 
                                                  
if not RPHelper2DBPC.global.RPEvent.death_coil then RPHelper2DBPC.global.RPEvent.death_coil = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.death_coil.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.death_coil.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.death_coil.Sayings.customemote, {"extends PP palm and shoots a black coil toward TARGET."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.death_coil.Sayings.random, {})

------------------------------------------------------------------------- 
if not RPHelper2DBPC.global.RPEvent.life_tap then RPHelper2DBPC.global.RPEvent.life_tap = {Sayings={}} end                                                                    
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.life_tap.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.life_tap.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.life_tap.Sayings.customemote, {"slits PP wrists."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.life_tap.Sayings.random, {})   
                                                  
if not RPHelper2DBPC.global.RPEvent.dark_pact then RPHelper2DBPC.global.RPEvent.dark_pact = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dark_pact.Sayings, {"PNAME, I need to swipe just a little bit of your mana..."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dark_pact.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dark_pact.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dark_pact.Sayings.random, {})     

------------------------------------------------------------------------- 
if not RPHelper2DBPC.global.RPEvent.fear then RPHelper2DBPC.global.RPEvent.fear = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear.Sayings, {
    "Prepare to know the true meaning of fear.",
    "Don't go away mad, just go away.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear.Sayings.random, {})          

if not RPHelper2DBPC.global.RPEvent.howl_of_terror then RPHelper2DBPC.global.RPEvent.howl_of_terror = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.howl_of_terror.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.howl_of_terror.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.howl_of_terror.Sayings.customemote, {"throws PP head back and shrieks."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.howl_of_terror.Sayings.random, {})

--=====================================================================--
-- Demonology
--=====================================================================--                       
if not RPHelper2DBPC.global.RPEvent.demon_skin then RPHelper2DBPC.global.RPEvent.demon_skin = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demon_skin.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demon_skin.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.demon_skin.Sayings.customemote, {"wraps OPself in demonic energies."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demon_skin.Sayings.random, {}) 
                         
if not RPHelper2DBPC.global.RPEvent.demon_armor then RPHelper2DBPC.global.RPEvent.demon_armor = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demon_armor.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demon_armor.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.demon_armor.Sayings.customemote, {"wraps OPself in demonic energies."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demon_armor.Sayings.random, {})             
                         
if not RPHelper2DBPC.global.RPEvent.health_funnel then RPHelper2DBPC.global.RPEvent.health_funnel = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.health_funnel.Sayings, {"PNAME, you look hurt!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.health_funnel.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.health_funnel.Sayings.random, {})           
                         
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.unending_breath.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.unending_breath.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.unending_breath.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.unending_breath.Sayings.random, {})
                                               
if not RPHelper2DBPC.global.RPEvent.fel_domination then RPHelper2DBPC.global.RPEvent.fel_domination = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fel_domination.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fel_domination.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fel_domination.Sayings.customemote, {"frantically spits out some words in Demonic."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fel_domination.Sayings.random, {})
                                                             
if not RPHelper2DBPC.global.RPEvent.sense_demons then RPHelper2DBPC.global.RPEvent.sense_demons = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sense_demons.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sense_demons.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.sense_demons.Sayings.customemote, {"opens PP senses to nearby fel energies."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sense_demons.Sayings.random, {})
                                                                                
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.detect_invisibility.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.detect_invisibility.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.detect_invisibility.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.detect_invisibility.Sayings.random, {})   
                                                                                
if not RPHelper2DBPC.global.RPEvent.banish then RPHelper2DBPC.global.RPEvent.banish = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.banish.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.banish.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.banish.Sayings.customemote, {"shakes a finger at TARGET.", "makes TARGET incorporeal."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.banish.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eye_of_kilrogg.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eye_of_kilrogg.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eye_of_kilrogg.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eye_of_kilrogg.Sayings.random, {})                          

if not RPHelper2DBPC.global.RPEvent.demonic_sacrifice then RPHelper2DBPC.global.RPEvent.demonic_sacrifice = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.demonic_sacrifice.Sayings, {"Sorry there, PNAME, but you're worth more to me dead than alive."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demonic_sacrifice.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demonic_sacrifice.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demonic_sacrifice.Sayings.random, {})                       

if not RPHelper2DBPC.global.RPEvent.ritual_of_summoning then RPHelper2DBPC.global.RPEvent.ritual_of_summoning = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_summoning.Sayings, {"Summoning TARGET.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_summoning.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_summoning.Sayings.customemote, {"starts chanting in Demonic.  You hear TARGET's name.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_summoning.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.enslave_demon then RPHelper2DBPC.global.RPEvent.enslave_demon = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.enslave_demon.Sayings, {"Haha, TARGET, you are mine!"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.enslave_demon.Sayings.emote, {"GRIN",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.enslave_demon.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.enslave_demon.Sayings.random, {})         

if not RPHelper2DBPC.global.RPEvent.shadow_ward then RPHelper2DBPC.global.RPEvent.shadow_ward = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_ward.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_ward.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_ward.Sayings.customemote, {"weaves a ward of shadows."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_ward.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.soul_link.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.soul_link.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.soul_link.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.soul_link.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.soulshatter then RPHelper2DBPC.global.RPEvent.soulshatter = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.soulshatter.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.soulshatter.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.soulshatter.Sayings.customemote, {"grabs a soul shard and crushes it in PP palm."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.soulshatter.Sayings.random, {})

-------------------------------------------------------------------------

if not RPHelper2DBPC.global.RPEvent.create_healthstone then RPHelper2DBPC.global.RPEvent.create_healthstone = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_healthstone.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_healthstone.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_healthstone.Sayings.customemote, {"creates a small, glowing stone."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_healthstone.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.create_soulstone then RPHelper2DBPC.global.RPEvent.create_soulstone = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_soulstone.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_soulstone.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_soulstone.Sayings.customemote, {"creates a small, translucent stone."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_soulstone.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.create_spellstone then RPHelper2DBPC.global.RPEvent.create_spellstone = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_spellstone.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_spellstone.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_spellstone.Sayings.customemote, {"creates a small, iridescent stone."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_spellstone.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.create_firestone then RPHelper2DBPC.global.RPEvent.create_firestone = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_firestone.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_firestone.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_firestone.Sayings.customemote, {"creates a stone that seems to encase a flame within."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.create_firestone.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_souls.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_souls.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_souls.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_souls.Sayings.random, {})

-------------------------------------------------------------------------
if not RPHelper2DBPC.global.RPEvent.summon_imp then RPHelper2DBPC.global.RPEvent.summon_imp = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_imp.Sayings, {
	"Did you think I would let you rest, imp?",
	"Time to get back to work, imp.",
	"Your labor is not even close to finished, imp.",
	"You cannot escape me that easily, imp.",
	"Weakness will not be tolerated, imp.",
	"You will never know rest, imp, your labor will never be done.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_imp.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_imp.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_imp.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.summon_voidwalker then RPHelper2DBPC.global.RPEvent.summon_voidwalker = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_voidwalker.Sayings, {
	"Did you think I would let you rest, demon?",
	"Demon! Get back to work!",
	"Your labor is not even close to finished, demon!",
	"You cannot escape me that easily, demon!",
	"Weakness will not be tolerated, demon!",
	"You will never know rest, demon, your labor will never be done!",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_voidwalker.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_voidwalker.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_voidwalker.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.succubus then RPHelper2DBPC.global.RPEvent.summon_succubus = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_succubus.Sayings, {
	"Did you think I would let you rest, minx?",
	"Succubus! Get back to work!",
	"Your labor is not even close to finished, temptress!",
	"You cannot escape me that easily, temptress!",
	"Weakness will not be tolerated, Succubus!",
	"You will never know rest, temptress, your labor will never be done!",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_succubus.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_succubus.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_succubus.Sayings.random, {})


--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felhunter.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felhunter.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felhunter.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felhunter.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felsteed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felsteed.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felsteed.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felsteed.Sayings.random, {})  

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_dreadsteed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_dreadsteed.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_dreadsteed.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_dreadsteed.Sayings.random, {})    

if not RPHelper2DBPC.global.RPEvent.inferno then RPHelper2DBPC.global.RPEvent.inferno = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.inferno.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.inferno.Sayings.emote, {"CACKLE"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.inferno.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.inferno.Sayings.random, {})     

if not RPHelper2DBPC.global.RPEvent.ritual_of_doom then RPHelper2DBPC.global.RPEvent.ritual_of_doom = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_doom.Sayings, {"OK, everyone hold hands, and hope you're not the one who dies!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_doom.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_doom.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ritual_of_doom.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felguard.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felguard.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felguard.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_felguard.Sayings.random, {})

--=====================================================================--
-- Destruction
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.immolate then RPHelper2DBPC.global.RPEvent.immolate = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.immolate.Sayings, {"Mind if I turn up the heat a bit, TARGET?", "Time to get a little hot under the collar, TARGET."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.immolate.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.immolate.Sayings.customemote, {"sets TARGET on fire and giggles with glee."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.immolate.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.searing_pain.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.searing_pain.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.searing_pain.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.searing_pain.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.shadow_bolt then RPHelper2DBPC.global.RPEvent.shadow_bolt = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_bolt.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_bolt.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_bolt.Sayings.customemote, {"starts chanting in demonic.","prepares a massive bolt of shadow for TARGET.", "'s hands glow black.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_bolt.Sayings.random, {})
                                          
if not RPHelper2DBPC.global.RPEvent.rain_of_fire then RPHelper2DBPC.global.RPEvent.rain_of_fire = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rain_of_fire.Sayings, {"Rain fire!", "Fire from the sky!", "Come on baby, light my fire!", })
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rain_of_fire.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rain_of_fire.Sayings.random, {})
                                          
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowburn.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowburn.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowburn.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowburn.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowfury.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowfury.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowfury.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowfury.Sayings.random, {})
                                             
if not RPHelper2DBPC.global.RPEvent.hellfire then RPHelper2DBPC.global.RPEvent.helfire = {Sayings={}} end   
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hellfire.Sayings, {"Some like it hot, so let's turn up the heat til we fry."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hellfire.Sayings.customemote, {"lights OPself on fire."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hellfire.Sayings.random, {})     
                                          
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.conflagrate.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.conflagrate.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.conflagrate.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.conflagrate.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.incinerate.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.incinerate.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.incinerate.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.incinerate.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.soul_fire then RPHelper2DBPC.global.RPEvent.soul_fire = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.soul_fire.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.soul_fire.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.soul_fire.Sayings.customemote, {"sets TARGET's soul on fire."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.soul_fire.Sayings.random, {})
elseif ( myLocale == "deDE") then
if self.WarlockDE then self:WarlockDE() end
elseif (myLocale == "frFR") then
if self.WarlockFR then self:WarlockFR() end
elseif (myLocale == "esES") then
if self.WarlockES then self:WarlockES() end
end
end