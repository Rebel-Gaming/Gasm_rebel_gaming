function RPHelper2:InitializeROGUE(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB") then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- contributors to this file:  mithyk

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"To the death!", -- crashinbrn
	"Twin blade action, for a clean close shave every time.",
	"My blade can cut through armor, and still cut a tomato.",
	"Bring it on!",
	"Time to play!",
	"You're goin' down!",
	"It's Game Time!",
	"Stabby stab stab!",
	"TARGET, let's dance!",
	
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"CHARGE",})  
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {
	"Next.",
	"TSP's down! Who's next?",
	"Mess with the best, die like... well, like you just did.",
	"Keep the change...",
	"Erased.",
	"Denied.",
	"Anyone else want some?",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {})             
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {})         
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {})  
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {})  
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {
	"I just can't miss.",
	"Let me introduce you to pain... he's about to become your best friend.",
	"You're gonna die.",
	"I've got a present for ya!",
	"You still want to kill me? Mind if I kill you first?",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {
	"I just can't miss.",
	"Let me introduce you to pain... he's about to become your best friend.",
	"You're gonna die.",
	"I've got a present for ya!",
	"You still want to kill me? Mind if I kill you first?",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {})   
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})

--=====================================================================--
--  Fear, etc.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})


--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})

--=====================================================================--
--  Racials
	-- This way you can RP your racial differently as different classes
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.random, {})

--//////////////////////////////////////////////////////////////////////////--
-- Sayings Spells
--//////////////////////////////////////////////////////////////////////////--
--=====================================================================--
-- Assassination
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eviscerate.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eviscerate.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eviscerate.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eviscerate.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.slice_and_dice.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.slice_and_dice.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.slice_and_dice.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.slice_and_dice.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.expose_armor.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.expose_armor.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.expose_armor.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.expose_armor.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.garrote.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.garrote.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.garrote.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.garrote.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ambush.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ambush.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ambush.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ambush.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.relentless_strikes.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.relentless_strikes.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.relentless_strikes.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.relentless_strikes.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rupture.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rupture.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rupture.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rupture.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cheap_shot.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cheap_shot.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cheap_shot.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cheap_shot.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cold_blood.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cold_blood.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cold_blood.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cold_blood.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.kidney_shot.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.kidney_shot.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.kidney_shot.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.kidney_shot.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mutilate.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mutilate.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mutilate.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mutilate.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.deadly_throw.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.deadly_throw.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.deadly_throw.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.deadly_throw.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.envenom.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.envenom.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.envenom.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.envenom.Sayings.random, {})
--=====================================================================--
-- Combat
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.backstab.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.backstab.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.backstab.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.backstab.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gouge.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gouge.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gouge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gouge.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sinister_strike.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sinister_strike.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sinister_strike.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sinister_strike.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.evasion.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.evasion.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.evasion.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.evasion.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sprint.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sprint.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sprint.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sprint.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.kick.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.kick.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.kick.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.kick.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feint.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feint.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feint.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feint.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.riposte.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.riposte.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.riposte.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.riposte.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blade_fury.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blade_fury.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blade_fury.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blade_fury.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.adrenaline_rush.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.adrenaline_rush.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.adrenaline_rush.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.adrenaline_rush.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shiv.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shiv.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shiv.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shiv.Sayings.random, {})
--=====================================================================--
-- Subtlety
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.stealth then RPHelper2DBPC.global.RPEvent.stealth = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stealth.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stealth.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.stealth.Sayings.customemote, {
 	"slips into the shadows.",
 	"becomes one with the shadows.",
 	"fades from view.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stealth.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.pick_pocket then RPHelper2DBPC.global.RPEvent.pick_pocket = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pick_pocket.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pick_pocket.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.pick_pocket.Sayings.customemote, {
 	"looks in the pockets of TARGET.",
 	"rummages through the pockets of TARGET.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pick_pocket.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.sap then RPHelper2DBPC.global.RPEvent.sap = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.sap.Sayings, {
 	"TARGET is sapped. You spank it, you tank it.",
 	"Sapping TARGET. You spank it, you tank it.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sap.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sap.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sap.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ghostly_strike.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ghostly_strike.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ghostly_strike.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ghostly_strike.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.distract then RPHelper2DBPC.global.RPEvent.distract = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.distract.Sayings, {"Look over there!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.distract.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.distract.Sayings.customemote, {"tosses a pebble in hopes of distracting onlookers."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.distract.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.vanish then RPHelper2DBPC.global.RPEvent.vanish = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vanish.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.vanish.Sayings.emote, {"BYE"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vanish.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vanish.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.detect_traps.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.detect_traps.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.detect_traps.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.detect_traps.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.disarm_trap.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.disarm_trap.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.disarm_trap.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.disarm_trap.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.preparation.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.preparation.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.preparation.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.preparation.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blind.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blind.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blind.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blind.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hemorrhage.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hemorrhage.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hemorrhage.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hemorrhage.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.premeditation.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.premeditation.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.premeditation.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.premeditation.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.safe_fall.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.safe_fall.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.safe_fall.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.safe_fall.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cloak_of_shadows.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cloak_of_shadows.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cloak_of_shadows.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cloak_of_shadows.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowstep.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowstep.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowstep.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowstep.Sayings.random, {})
--=====================================================================--
-- Lockpicking
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.pick_lock then RPHelper2DBPC.global.RPEvent.pick_lock = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pick_lock.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pick_lock.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.pick_lock.Sayings.customemote, {
 	"carefully listens to the tumblers in the lock.",
 	"listens as the tumblers fall into place.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pick_lock.Sayings.random, {})
--=====================================================================--
-- Poisons
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crippling_poison.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crippling_poison.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crippling_poison.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crippling_poison.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_numbing_poison.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_numbing_poison.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_numbing_poison.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_numbing_poison.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.instant_poison.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.instant_poison.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.instant_poison.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.instant_poison.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.deadly_poison.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.deadly_poison.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.deadly_poison.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.deadly_poison.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.wound_poison.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.wound_poison.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.wound_poison.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.wound_poison.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blinding_powder.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blinding_powder.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blinding_powder.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blinding_powder.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_bow.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_bow.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_bow.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_bow.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_crossbow.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_crossbow.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_crossbow.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_crossbow.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_gun.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_gun.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_gun.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_gun.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.throw then RPHelper2DBPC.global.RPEvent.throw = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.throw.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.throw.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.throw.Sayings.customemote, {"throws a dagger to get TARGET's attention."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.throw.Sayings.random, {})
elseif ( myLocale == "deDE") then
if self.RogueDE then self:RogueDE() end
elseif (myLocale == "frFR") then
if self.RogueFR then self:RogueFR() end
elseif (myLocale == "esES") then
if self.RogueES then self:RogueES() end
end
end