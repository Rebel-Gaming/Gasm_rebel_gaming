function RPHelper2:InitializeDRAENEI(Locale)
if ( Locale == "enUS" or Locales == "enGB" ) then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"For Exodar!",
	"For Argus!",
	"For the Light! For the Naaru!",
	"I have no fearing of the battle!",
	"Feta Vai A'kahachi!"
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"guffaw SELF","laugh SELF","crack",})
--RPWORDLIST.entercombat.DRAENEI.customemote = {}
--RPWORDLIST.entercombat.DRAENEI.random = {}
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {
	"The Light has delivered me!",
	"The Naaru have not forgotten me.",
})
--RPWORDLIST.leavecombat.DRAENEI.emote = {}
--RPWORDLIST.leavecombat.DRAENEI.customemote = {}
--RPWORDLIST.leavecombat.DRAENEI.random = {}
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--RPWORDLIST.hurt.DRAENEI = {}
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {"BLEED",})
--RPWORDLIST.hurt.DRAENEI.customemote = {}
--RPWORDLIST.hurt.DRAENEI.random = {}
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {"I didn't feel a thing! Hah!", })
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {"laugh SELF","guffaw SELF",})
--RPWORDLIST.absorb.DRAENEI.customemote = {}
--RPWORDLIST.absorb.DRAENEI.random = {}
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
--RPWORDLIST.block.DRAENEI = {}
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {"laugh SELF","guffaw SELF",})
--RPWORDLIST.block.DRAENEI.customemote = {}
--RPWORDLIST.block.DRAENEI.random = {}
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--RPWORDLIST.dodge.DRAENEI = {}
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {"laugh SELF","guffaw SELF",})
--RPWORDLIST.dodge.DRAENEI.customemote = {}
--RPWORDLIST.dodge.DRAENEI.random = {}
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--RPWORDLIST.miss.DRAENEI = {}
--RPWORDLIST.miss.DRAENEI.emote = {}
--RPWORDLIST.miss.DRAENEI.customemote = {}
--RPWORDLIST.miss.DRAENEI.random = {}
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--RPWORDLIST.parry.DRAENEI = {}
--RPWORDLIST.parry.DRAENEI.emote = {}
--RPWORDLIST.parry.DRAENEI.customemote = {}
--RPWORDLIST.parry.DRAENEI.random = {}
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
--RPWORDLIST.youcrit.DRAENEI = {}
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {"laugh SELF","guffaw SELF",})
--RPWORDLIST.youcrit.DRAENEI.customemote = {}
--RPWORDLIST.youcrit.DRAENEI.random = {}
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
--RPWORDLIST.youcritspell.DRAENEI = {}
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {"laugh SELF","guffaw SELF",})
--RPWORDLIST.youcritspell.DRAENEI.customemote = {}
--RPWORDLIST.youcritspell.DRAENEI.random = {}
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
--RPWORDLIST.youheal.DRAENEI = {}
--RPWORDLIST.youheal.DRAENEI.emote = {}
--RPWORDLIST.youheal.DRAENEI.customemote = {}
--RPWORDLIST.youheal.DRAENEI.random = {}
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
--RPWORDLIST.youcritheal.DRAENEI = {}
--RPWORDLIST.youcritheal.DRAENEI.emote = {}
--RPWORDLIST.youcritheal.DRAENEI.customemote = {}
--RPWORDLIST.youcritheal.DRAENEI.random = {}
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME = Pet's Name	
	-- PTNAME = Pet's target's name                           
	-- PTSP = Pet's target's subject pronoun 	(He/She/It)
	-- PTOP = Pet's target's object pronoun 	(him/her/it)
	-- PTPP = Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
--RPWORDLIST.petattackstart.DRAENEI = {}
--RPWORDLIST.petattackstart.DRAENEI.emote = {}
--RPWORDLIST.petattackstart.DRAENEI.customemote = {}
--RPWORDLIST.petattackstart.DRAENEI.random = {}
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME = Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
--RPWORDLIST.petattackstop.DRAENEI = {}
--RPWORDLIST.petattackstop.DRAENEI.emote = {}
--RPWORDLIST.petattackstop.DRAENEI.customemote = {}
--RPWORDLIST.petattackstop.DRAENEI.random = {}
--=====================================================================--
-- When your PET DIES.
	-- PNAME = Pet's Name
--=====================================================================--
--RPWORDLIST.petdies.DRAENEI = {}
--RPWORDLIST.petdies.DRAENEI.emote = {}
--RPWORDLIST.petdies.DRAENEI.customemote = {}
--RPWORDLIST.petdies.DRAENEI.random = {}
-------------------------------------------------------------------------
-- The BEGINNING of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
	-- "KNEEL" is automatically added if the NPC is 5 levels higher than you
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings, {
	"TARGET, the Legion's end draws near.",
	"Arkanon Por'os.",
	"Good fortune, TARGET",
	"Kruno'kai Kristore.",
	"TARGET, the Naaru have not forgotten us.",
	"TARGET, the Legion will fall.",
	"May the Light embrace you, TARGET.",
	"Blessings upon you, TARGET.",
	"TARGET, each day is a blessing.",
	"Warm wishes to you, TARGET.",
	"TARGET, open your heart to the Light.",
})
-------------------------------------------------------------------------
-- The END of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings, {
	"TARGET, remain vigilant.",
	"Be well, TARGET.",
	"TARGET, remember the lessons of the past.",
	"TARGET, do not lose faith.",
	"TARGET, favor the road travelled by few.",
	"TARGET, each day is a blessing.",
	"Warm wishes to you, TARGET.",
	"TARGET, open your heart to the Light.",
	"May the Light embrace you, TARGET.",
	"Blessings upon your family, TARGET.",
	"TARGET! Good Health! Long life!",
	"TARGET, be kind to those less fortunate.",
})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT = The text message sent by the NPC.	TEXT = Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC  = Mogg
	-- LANG = The Language              		LANG = Orcish
--=====================================================================--
--RPWORDLIST.npctalksfriend.DRAENEI = {}
--RPWORDLIST.npctalksfriend.DRAENEI.emote = {}
--RPWORDLIST.npctalksfriend.DRAENEI.customemote = {}
--RPWORDLIST.npctalksfriend.DRAENEI.random = {}
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT = The text message sent by the NPC.	TEXT = Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC  = Mogg
	-- LANG = The Language              		LANG = Orcish
--=====================================================================--
--RPWORDLIST.npctalksenemy.DRAENEI = {}
--RPWORDLIST.npctalksenemy.DRAENEI.emote = {}
--RPWORDLIST.npctalksenemy.DRAENEI.customemote = {}
--RPWORDLIST.npctalksenemy.DRAENEI.random = {}
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {
	"I am blessed!",
	"My wounds are gone!",
	"The Naaru have not forgotten me.",
	"I am feeling big adrenaline rush for some reason.",
	"That will be leaving big mark.",
	"I will be bearing this scar with much pride.",
})
RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote = {}
RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random = {}


--=====================================================================--
--  Draenei Racial
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.gift_of_the_naaru then RPHelper2DBPC.global.RPEvent.gift_of_the_naaru = {Sayings={}} end
RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings = {"May the Naaru bless you, TARGET.",
}
RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.emote = {}
RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.random = {}
--=====================================================================--
--  Fear, etc.
--=====================================================================--
--RPWORDLIST.feared.DRAENEI = {}
--RPWORDLIST.feared.DRAENEI.random = {}

--RPWORDLIST.possession.DRAENEI = {}
--RPWORDLIST.possession.DRAENEI.random = {}

--RPWORDLIST.confused.DRAENEI = {}
--RPWORDLIST.confused.DRAENEI.random = {}

--RPWORDLIST.polymorphed.DRAENEI = {}
--RPWORDLIST.polymorphed.DRAENEI.random = {}

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--RPWORDLIST.silenced.DRAENEI = {}
--RPWORDLIST.silenced.DRAENEI.emote = {}
--RPWORDLIST.silenced.DRAENEI.customemote = {}
--RPWORDLIST.silenced.DRAENEI.random = {}

elseif ( myLocale == "deDE") then
if self.DraeneiDE then self:DraeneiDE() end
elseif (myLocale == "frFR") then
if self.DraeneiFR then self:DraeneiFR() end
elseif (myLocale == "esES") then
if self.DraeneiES then self:DraeneiES() end

end
end