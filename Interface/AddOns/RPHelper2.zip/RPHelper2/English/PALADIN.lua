function RPHelper2:InitializePALADIN(myLocale)
if ( myLocale == "enUS" or GetLocale == "enGB") then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"I will bring honor to my family and my kingdom!",
	"Light, guide my blade!",
	"Light, give me strength!",
	"My strength is the holy light!",
	"My church is the field of battle - time to worship...",
	"It's hammer time!",
	"I hold you in contempt...",
	"Shall I be your executioner?",
	"Face the hammer of justice!",
	"Come then, shadow spawn!",
	"Prove your worth in the test of arms under the light!",
	"Might I have the pleasure of your name before I crush your skull?",
	"All must fall before the might and right of my cause, you shall be next!",
	"I'm afraid I'm gonna have to kill you now.",
	"Prepare to die!",
	"I must swat you like the insignificant insect you are!",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"CHARGE SELF",}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {
	"My thanks for the lively scrap.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})  
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {})        
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {})   
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {})  
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {})   
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {
	"The vultures begin circling over you.",
	"You will pay in blood for your foolishness.",
	"You are beaten, it is useless to resist.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {})  
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.random, {})
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.random, {})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {
	"By the light!  I'm alive!",
	"The light has brought me back.",
	"The light has seen fit for me to live again.",
	})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {"PRAY",}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})

--=====================================================================--
--  Fear, etc.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear.Sayings, {"Oh, Light, why would you do that?"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})

--=====================================================================--
--  Racials
	-- This way you can RP your racial differently as different classes
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.random, {})

--//////////////////////////////////////////////////////////////////////////--
-- Sayings Spells
--//////////////////////////////////////////////////////////////////////////--
--=====================================================================--
-- Protection
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devotion_aura.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devotion_aura.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devotion_aura.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devotion_aura.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_protection.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_protection.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_protection.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_protection.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hammer_of_justice.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hammer_of_justice.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hammer_of_justice.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hammer_of_justice.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_protection.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_protection.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_protection.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_protection.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.righteous_fury.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.righteous_fury.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.righteous_fury.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.righteous_fury.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_freedom.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_freedom.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_freedom.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_freedom.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_kings.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_kings.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_kings.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_kings.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.concentration_aura.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.concentration_aura.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.concentration_aura.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.concentration_aura.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_justice.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_justice.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_justice.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_justice.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_salvation.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_salvation.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_salvation.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_salvation.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_resistance_aura.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_resistance_aura.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_resistance_aura.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_resistance_aura.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_sanctuary.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_sanctuary.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_sanctuary.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_sanctuary.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_intervention.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_intervention.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_intervention.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_intervention.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_resistance_aura.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_resistance_aura.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_resistance_aura.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_resistance_aura.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_shield.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_shield.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_shield.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_shield.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_resistance_aura.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_resistance_aura.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_resistance_aura.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_resistance_aura.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_shield.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_shield.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_shield.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_shield.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_sacrifice.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_sacrifice.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_sacrifice.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_sacrifice.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_kings.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_kings.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_kings.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_kings.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_salvation.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_salvation.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_salvation.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_salvation.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_sanctuary.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_sanctuary.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_sanctuary.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_sanctuary.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.righteous_defense.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.righteous_defense.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.righteous_defense.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.righteous_defense.Sayings.random, {})

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.avengers_shield.Sayings, {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.avengers_shield.Sayings.emote, {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.avengers_shield.Sayings.customemote, {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.avengers_shield.Sayings.random, {})
--=====================================================================--
-- Retribution
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_might.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_might.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_might.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_might.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.judgement.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.judgement.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.judgement.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.judgement.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_the_crusader.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_the_crusader.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_the_crusader.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_the_crusader.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.retribution_aura.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.retribution_aura.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.retribution_aura.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.retribution_aura.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_command.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_command.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_command.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_command.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sanctity_aura.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sanctity_aura.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sanctity_aura.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sanctity_aura.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.repentance.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.repentance.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.repentance.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.repentance.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_might.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_might.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_might.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_might.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crusader_strike.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crusader_strike.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crusader_strike.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crusader_strike.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crusader_aura.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crusader_aura.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crusader_aura.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.crusader_aura.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_blood.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_blood.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_blood.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_blood.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_vengeance.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_vengeance.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_vengeance.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_vengeance.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.avenging_wrath.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.avenging_wrath.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.avenging_wrath.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.avenging_wrath.Sayings.random, {})

--=====================================================================--
-- Holy                                                                  
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_light.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_light.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_light.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_light.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.purify.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.purify.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.purify.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.purify.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lay_on_hands.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lay_on_hands.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lay_on_hands.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lay_on_hands.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_righteousness.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_righteousness.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_righteousness.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_righteousness.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.redemption.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.redemption.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.redemption.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.redemption.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_wisdom.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_wisdom.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_wisdom.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_wisdom.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.consecration.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.consecration.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.consecration.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.consecration.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.exorcism.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.exorcism.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.exorcism.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.exorcism.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flash_of_light.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flash_of_light.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flash_of_light.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flash_of_light.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.turn_undead.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.turn_undead.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.turn_undead.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.turn_undead.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sense_undead.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sense_undead.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sense_undead.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sense_undead.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_favor.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_favor.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_favor.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_favor.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_light.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_light.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_light.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_light.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_wisdom.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_wisdom.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_wisdom.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.seal_of_wisdom.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_light.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_light.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_light.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blessing_of_light.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_shock.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_shock.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_shock.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_shock.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_warhorse.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_warhorse.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_warhorse.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_warhorse.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cleanse.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cleanse.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cleanse.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cleanse.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hammer_of_wrath.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hammer_of_wrath.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hammer_of_wrath.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hammer_of_wrath.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_wrath.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_wrath.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_wrath.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_wrath.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_wisdom.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_wisdom.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_wisdom.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_wisdom.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_light.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_light.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_light.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_blessing_of_light.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_illumination.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_illumination.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_illumination.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_illumination.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hearthstone.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hearthstone.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hearthstone.Sayings.customemote, {"grasps PP hearthstone and calls upon the Light to transport OP to HOME."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hearthstone.Sayings.random, {})

elseif ( myLocale == "deDE") then
if self.PaladinDE then self:PaladinDE() end
elseif (myLocale == "frFR") then
if self.PaladinFR then self:PaladinFR() end
elseif (myLocale == "esES") then
if self.PaladinES then self:PaladinES() end
end
end