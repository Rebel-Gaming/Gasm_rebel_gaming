function RPHelper2:InitializeGNOME(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB") then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"For Gnomeregan!",
	"Charge!",
 	"I'll bite your legs off!",
	"You looking at me? Are you looking at ME? HEY, I'm down here!",        -- mithyk
	"Do you feel lucky, punk? Well, do ya?! Because I've calculated your odds of success and they are embarassingly low.", -- mithyk & butchered by Syrsa
	"I'm warning you, I'm seriously stressed out here!",                    -- mithyk
	"Hook them! Hammer them! Take out their kneecaps!",
	"You want a piece of me?  Fine, I got my climbing gear ready!",
	"You might be bigger, but you�ve only a fraction of my brains!",
	"Never quote me the odds - I already know them!",
	"Legion One, advance! Legion Two, advance! Legion three, advance! Legions 4-50, secure the flanks!",
	"Here we go again...",
	"If at first you don�t succeed, get the heck out of SUB_ZONE",
	"Bring me my brown pants!",
	})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {
	"Not in the face! Not in the face!",
	"Don't hurt me I'm small.",
	"I don't find this pain agreeable at all.",
-- the following are from mithyk
	"Ok, now that was uncalled for!",
	"That was totally uncalled for!",
	"You could have taken my eye out with that!!!",
	"You could put somebody's eye out!",
	"You'll miss me when I'm gone!",
	"Stop pummelling me! It's really painful!",
	"That's hitting low.",
	"Hey, what's your problem!?",
	"Stop fighting back, it's not fair...",
	"This is it the final, the very very last straw!",
	"Don't you have Sayingsthing better to do?",
	"You don't like me much, do you?",
	"That was not the way I planned it!",
	"Alright, that's the last straw, time to design a trash can! I mean, take out, uh...",
	})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {"BLEED",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {

	["phrase"] = "BLANKBLANK BLANK",
	
	[1] = { "Ow! ","Ouch! ","Oof! ","Ack! ","","", },
	
	[2] = { "Quit it!","That hurts!","Pain.","Not nice.","Not in the face!","That's gonna leave a mark.","Stop the pain!",
			"Stop with the hurting!","I'll get you for that.","You'll regret that.","That hurt.","Stop attacking the little guy!", },

	[3] = { "RINSULT","","","","", },

	})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {
	"Take that!",
	"Take that, and that, and this one too!",
	"Aww - did you have a booboo?",
	"Everything is proceeding as I have planned - kinda weird, actually.",
	"Wow, all that blood is sticky!",
	"Look out! Too late.",
	"Hey! You scratched my weapon!",
	"Combat is much more fun when I'm winning!",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {
	"Take that!",
	"Take that, and that, and this one too!",
	"Oww - did you have a booboo?",
	"Everything is proceeding as I have planned - kinda wierd, actually.",
	"Wow, all that blood is sticky!",
	"Look out! Too late.",
	"Combat is much more fun when I'm winning!",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME, Pet's Name	
	-- PTNAME, Pet's target's name                           
	-- PTSP, Pet's target's subject pronoun 	(He/She/It)
	-- PTOP, Pet's target's object pronoun 	(him/her/it)
	-- PTPP, Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random, {})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME, Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random, {})
--=====================================================================--
-- When your PET DIES.
	-- PNAME, Pet's Name
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.random, {})
--=====================================================================--
-- When you talk to an NPC  (A dialogue/merchant/quest/etc. box opens)
--=====================================================================--
-------------------------------------------------------------------------
-- The BEGINNING of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
	-- "KNEEL" is automatically added if the NPC is 5 levels higher than you
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings, {
	"Hiya TARGET!",
	"Heya, TARGET!",
	"Hey there, TARGET!",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings.random, {})
-------------------------------------------------------------------------
-- The END of a conversation with an NPC 
	-- "CURTSEY" is automatically added for female characters
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings, {
	"TARGET, till next we meet.",
	"See you later, TARGET.",
	"Be seeing you, TARGET."
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings.random, {})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})

--=====================================================================--
--  Fear, etc.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings, {"SWEET MOTHER OF MEKKATORQUE!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})

elseif ( myLocale == "deDE") then
if self.GnomeDE then self:GnomeDE() end
elseif (myLocale == "frFR") then
if self.GnomeFR then self:GnomeFR() end
elseif (myLocale == "esES") then
if self.GnomeES then self:GnomeES() end

end
end