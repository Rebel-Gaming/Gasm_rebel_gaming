function RPHelper2:InitializeNIGHTELF(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB") then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Contributors to this file:  mithyk, Syrsa

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings,{
	"In the name of Goddess!",
	"By Elune!",
	"We can overcome these foul creatures!",
	"Elune, give me strength!",
	"For nature's survival!",
	"You will perish!",
	"Tor ilisar'thera'nal!",
	"Andu-falah-dor!",
	"Bandu Thoribas!",
	"For Cenarius!",	--mithyk
	"Elune, grant me swift victory!",	--mithyk
	"Ana'doreini talah!",	--mithyk
	"Ana'duna thera!",	--mithyk
	"Bash'a no falor talah!",	--mithyk
	"Endu'di riffa!",	--mithyk
	"Thor falah nor dora!",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random,{

	["phrase"]="You BLANK BLANK BLANK",

	[1]={"shall","will","must" },

	[2]={"be cleansed","be purified","die", },

	[3]={"in the name of Elune.","in the name of the Goddess.","for the Goddess."},

	})
	--[[
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random,{})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote,{"BLEED",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random,{})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random,{})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random,{})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random,{})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random,{})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random,{})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random,{})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random,{})
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.random,{})
]]--
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.youcritheal then
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.customemote,{"thanks Elune for a critical heal.",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.random,{})
end
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME,Pet's Name	
	-- PTNAME,Pet's target's name                           
	-- PTSP,Pet's target's subject pronoun 	(He/She/It)
	-- PTOP,Pet's target's object pronoun 	(him/her/it)
	-- PTPP,Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random,{})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME,Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random,{})
--=====================================================================--
-- When your PET DIES.
	-- PNAME,Pet's Name
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.random,{})]]--
--=====================================================================--
-- When you talk to an NPC  (A dialogue/merchant/quest/etc. box opens)
--=====================================================================--
-------------------------------------------------------------------------
-- The BEGINNING of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
	-- "KNEEL" is automatically added if the NPC is 5 levels higher than you
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings,{
 	"TARGET, well met.",
	"Elune be with you, TARGET.",
	"TARGET, Goddess bless you.",
	"Ishnu'Alah, TARGET.",
	"Ishnu'Dal'Dieb, TARGET.",
	"TARGET, I am honored.",
	"Peace be with you, TARGET.",
	"Elune Adore, TARGET.",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings.random,{})
-------------------------------------------------------------------------
-- The MIDDLE of a conversation with an NPC
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_middle.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_middle.Sayings.emote,{"LISTEN"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_middle.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_middle.Sayings.random,{})
-------------------------------------------------------------------------
-- The END of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings,{
	"TARGET, till next we meet.",
	"TARGET, safe travels.",
	"Farewell, TARGET.",
	"TARGET, go in peace.",
	"TARGET, Elune light your path.",
	"Elune light your path, TARGET.",
	"TARGET, Goddess watch over you.",
	"TARGET, may the stars guide you.",
	"En'shu fallah'na TARGET.",
	"Del'nadres, TARGET.",
	"Ande'thoras-ethil, TARGET."
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings.random,{})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT,The text message sent by the NPC.	TEXT,Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC ,Mogg
	-- LANG,The Language              		LANG,Orcish
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random,{})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT,The text message sent by the NPC.	TEXT,Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC ,Mogg
	-- LANG,The Language              		LANG,Orcish
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random,{})]]--
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings,{
	"For but a brief moment, I felt the presence of Elune.",
	"For a moment, I felt the presence of Elune.",
	"Praise the Goddess!"
	})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote,{"PRAY"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random,{

	["phrase"]="BLANK BLANK",

	[1]={"Thanks to Elune,","By the Goddess' mercy,","Elune has smiled upon me and now","By the Goddess' will,"},

	[2]={"I'm alive.","I live again.","my life has been spared.","I am mortal once again.","I am once again connected to this earth."},

	})
--=====================================================================--
--  Fear, etc.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings,{"Sweet Elune, save me!"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random,{})

--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random,{})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random,{})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random,{})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote,{})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random,{})]]--

elseif ( myLocale == "deDE") then
if self.NightElfDE then self:NightElfDE() end
elseif (myLocale == "frFR") then
if self.NightElfFR then self:NightElfFR() end
elseif (myLocale == "esES") then
if self.NightElfES then self:NightElfES() end

end
end