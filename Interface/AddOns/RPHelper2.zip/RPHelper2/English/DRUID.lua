function RPHelper2:InitializeDRUID(myLocale)
if ( myLocale == "enUS" or myLocale =="enGB") then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"I will destroy those who disrupt nature.",
	"I sense darkness in the dream.",
	"For nature's survival!",
	"The grass beneath your feet screams, I answer!",	--mithyk
	"My armies are the rocks and the trees and the birds in the sky!",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"CHARGE","ROAR",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})               
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {})                
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {})              
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {})               
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {})               
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {})                
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {})               
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {})             
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {})        
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.random, {})
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.customemote, {"thanks Elune for a critical heal.","smiles at PP critical heal."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.random, {})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {
    "kisses the earth, spins through the fresh air, and gives thanks to Elune.",
    "is overjoyed at feeling all of living nature around OP once more.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})

--=====================================================================--
--Racials
--=====================================================================--

-- night elf racial
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.customemote, {"fades into the shadows.", "disappears for a bit.", "thinks SP'll hide now."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.random, {})

-- tauren racial
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.random, {})

--=====================================================================--
--  Fear, etc.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

--Considering removing these since Sayingss can shapeshift out of poly.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})


--/////////////////////////////////////////////////////////////////////--
-- Sayings Spells
--/////////////////////////////////////////////////////////////////////--
--=====================================================================--
-- Feral Combat
-- I'm doubtful that shapeshifting will do an RP.
-- Please test "Cat Form", "Travel Form", etc. at 100% and let me know (^_^)/                                                                 
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.demoralizing_roar then RPHelper2DBPC.global.RPEvent.demoralizing_roar = {Sayings={}} end
	--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demoralizing_roar.Sayings, {})
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.demoralizing_roar.Sayings.emote, {"ROAR"})
	--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demoralizing_roar.Sayings.customemote, {})
	--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demoralizing_roar.Sayings.random, {})

--[[                                                        
self:JoinArrays(RPHelper2DBPC.global.RPEvent.enrage.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.enrage.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.enrage.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.enrage.Sayings.random, {})
else
	RPHelper2DBPC.global.RPEvent.enrage.Sayings = {}           
end

if RPHelper2DBPC.global.RPEvent.bash.Sayings then                                                         
self:JoinArrays(RPHelper2DBPC.global.RPEvent.bash.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.bash.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.bash.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.bash.Sayings.random, {})        
else
RPHelper2DBPC.global.RPEvent.bash.Sayings = {}
end

if RPHelper2DBPC.global.RPEvent.swipe.Sayings then                                                         
self:JoinArrays(RPHelper2DBPC.global.RPEvent.swipe.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.swipe.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.swipe.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.swipe.Sayings.random, {})
else
RPHelper2DBPC.global.RPEvent.swipe.Sayings = {}
end

if RPHelper2DBPC.global.RPEvent.maul.Sayings then
self:JoinArrays(RPHelper2DBPC.global.RPEvent.maul.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.maul.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.maul.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.maul.Sayings.random, {})       
else
RPHelper2DBPC.global.RPEvent.maul.Sayings = {}
end
]]--                   				          
if not RPHelper2DBPC.global.RPEvent.cat_form then RPHelper2DBPC.global.RPEvent.cat_form = {Sayings={}} end                               
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cat_form.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cat_form.Sayings.emote, {"GROWL",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cat_form.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cat_form.Sayings.random, {}) 

if not RPHelper2DBPC.global.RPEvent.claw then RPHelper2DBPC.global.RPEvent.claw = {Sayings={}} end    	                                         
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.claw.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.claw.Sayings.emote, {"SCRATCH",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.claw.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.claw.Sayings.random, {})       

if not RPHelper2DBPC.global.RPEvent.feral_charge then RPHelper2DBPC.global.RPEvent.feral_charge = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feral_charge.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feral_charge.Sayings.emote, {"CHARGE",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feral_charge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feral_charge.Sayings.random, {})      
  
if not RPHelper2DBPC.global.RPEvent.prowl then RPHelper2DBPC.global.RPEvent.prowl = {Sayings={}} end  	                                         
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prowl.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prowl.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.prowl.Sayings.customemote, {"fades into the shadows."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prowl.Sayings.random, {})            

if not RPHelper2DBPC.global.RPEvent.rip then RPHelper2DBPC.global.RPEvent.rip = {Sayings={}} end    	                                         
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rip.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rip.Sayings.emote, {"SCRATCH",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rip.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rip.Sayings.random, {})               
    	                                         
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shred.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shred.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shred.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shred.Sayings.random, {})           
    	                                         
if not RPHelper2DBPC.global.RPEvent.rake then RPHelper2DBPC.global.RPEvent.rake = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rake.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rake.Sayings.emote, {"SCRATCH",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rake.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rake.Sayings.random, {})           
    	                                         
if not RPHelper2DBPC.global.RPEvent.tigers_fury then RPHelper2DBPC.global.RPEvent.tigers_fury = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.tigers_fury.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tigers_fury.Sayings.emote, {"ROAR"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tigers_fury.Sayings.customemote, {"roars furiously."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.tigers_fury.Sayings.random, {})     

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dash.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dash.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dash.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dash.Sayings.random, {})          
    	                                         
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.challenging_roar.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.challenging_roar.Sayings.emote, {"ROAR",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.challenging_roar.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.challenging_roar.Sayings.random, {})  

if not RPHelper2DBPC.global.RPEvent.cower then RPHelper2DBPC.global.RPEvent.cower = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cower.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cower.Sayings.emote, {"COWER",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cower.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cower.Sayings.random, {})    
--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.faerie_fire_feral.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.faerie_fire_feral.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.faerie_fire_feral.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.faerie_fire_feral.Sayings.random, {})     

self:JoinArrays(RPHelper2DBPC.global.RPEvent.travel_form.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.travel_form.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.travel_form.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.travel_form.Sayings.random, {})
]]--

if not RPHelper2DBPC.global.RPEvent.ferocious_bite then RPHelper2DBPC.global.RPEvent.ferocious_bite = {Sayings={}} end    	                                         
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ferocious_bite.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ferocious_bite.Sayings.emote, {"BITE",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ferocious_bite.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ferocious_bite.Sayings.random, {})     
    	                                         
if not RPHelper2DBPC.global.RPEvent.ravage then RPHelper2DBPC.global.RPEvent.ravage = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ravage.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ravage.Sayings.emote, {"SCRATCH",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ravage.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ravage.Sayings.random, {})        

if not RPHelper2DBPC.global.RPEvent.track_humanoids then RPHelper2DBPC.global.RPEvent.track_humanoids = {Sayings={}} end    	                                         
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_humanoids.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_humanoids.Sayings.emote, {"SNIFF",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_humanoids.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_humanoids.Sayings.random, {})   
    	                                         
--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frenzied_regeneration.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frenzied_regeneration.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frenzied_regeneration.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frenzied_regeneration.Sayings.random, {})
]]--    	                                         
if not RPHelper2DBPC.global.RPEvent.pounce then RPHelper2DBPC.global.RPEvent.pounce = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.pounce.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.pounce.Sayings.emote, {"POUNCE",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.pounce.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.pounce.Sayings.random, {})        
    	                                         
if not RPHelper2DBPC.global.RPEvent.dire_bear_form then RPHelper2DBPC.global.RPEvent.dire_bear_form = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dire_bear_form.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dire_bear_form.Sayings.emote, {"ROAR",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dire_bear_form.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dire_bear_form.Sayings.random, {})    
--[[    	                                         
self:JoinArrays(RPHelper2DBPC.global.RPEvent.maim.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.maim.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.maim.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.maim.Sayings.random, {}) 

self:JoinArrays(RPHelper2DBPC.global.RPEvent.mangle.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mangle.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mangle.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mangle.Sayings.random, {}) 

self:JoinArrays(RPHelper2DBPC.global.RPEvent.lacerate.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.lacerate.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.lacerate.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.lacerate.Sayings.random, {}) 

self:JoinArrays(RPHelper2DBPC.global.RPEvent.flight_form.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flight_form.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flight_form.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flight_form.Sayings.random, {}) 

self:JoinArrays(RPHelper2DBPC.global.RPEvent.flight_form.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flight_form.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flight_form.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flight_form.Sayings.random, {}) 
]]--
--=====================================================================--
-- Balance        
--=====================================================================-- 
if not RPHelper2DBPC.global.RPEvent.wrath then RPHelper2DBPC.global.RPEvent.wrath = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.wrath.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.wrath.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.wrath.Sayings.customemote, {"'s fingertips crackle with energy."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.wrath.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.moonfire then RPHelper2DBPC.global.RPEvent.moonfire = {Sayings={}} end 
self:JoinArrays(RPHelper2DBPC.global.RPEvent.moonfire.Sayings, {"Elune, burn TARGET with your wrath!"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.moonfire.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.moonfire.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.moonfire.Sayings.random, {}) 

--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.thorns.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.thorns.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.thorns.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.thorns.Sayings.random, {})
]]--

if not RPHelper2DBPC.global.RPEvent.entangling_roots then RPHelper2DBPC.global.RPEvent.entangling_roots = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entangling_roots.Sayings, {
	"Halt in your tracks, TARGET!",	--duerma
	"How about you stick around for awhile, TARGET.'",	--mithyk
	"Oh, were you going somewhere?",	--mithyk
	"I think you're better off being firmly rooted in place, TARGET.",	--mithyk

})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entangling_roots.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entangling_roots.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entangling_roots.Sayings.random, {})

--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_grasp.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_grasp.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_grasp.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_grasp.Sayings.random, {}) 
]]--

if not RPHelper2DBPC.global.RPEvent.faerie_fire then RPHelper2DBPC.global.RPEvent.faerie_fire = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.faerie_fire.Sayings, {"I'm watching you, TARGET."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.faerie_fire.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.faerie_fire.Sayings.customemote, {"outlines TARGET in a pink glow.",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.faerie_fire.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.hibernate then RPHelper2DBPC.global.RPEvent.hibernate = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hibernate.Sayings, {"Sleep, little TARGET."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hibernate.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hibernate.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hibernate.Sayings.random, {}) 

--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.omen_of_clarity.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.omen_of_clarity.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.omen_of_clarity.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.omen_of_clarity.Sayings.random, {})
]]--
if not RPHelper2DBPC.global.RPEvent.starfire then RPHelper2DBPC.global.RPEvent.starfire = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.starfire.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.starfire.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.starfire.Sayings.customemote, {"calls a pillar of arcane fire from the heavens."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.starfire.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.soothe_animal then RPHelper2DBPC.global.RPEvent.soothe_animal = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.soothe_animal.Sayings, {"Shhh, TARGET, I won't hurt you."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.soothe_animal.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.soothe_animal.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.soothe_animal.Sayings.random, {})     

if not RPHelper2DBPC.global.RPEvent.hurricane then RPHelper2DBPC.global.RPEvent.hurricane = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurricane.Sayings, {"Taste the fury of nature!"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurricane.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurricane.Sayings.customemote, {"stays eerily still as the winds around OP whip into a frenzy. The hair of PP foes and friends stands on end from the electricity latent in the air.","summons the violent forces of nature."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurricane.Sayings.random, {})     

if not RPHelper2DBPC.global.RPEvent.moonkin_form then RPHelper2DBPC.global.RPEvent.moonkin_form = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.moonkin_form.Sayings, {"Wark?",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.moonkin_form.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.moonkin_form.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.moonkin_form.Sayings.random, {})  

if not RPHelper2DBPC.global.RPEvent.barkskin then RPHelper2DBPC.global.RPEvent.barkskin = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.barkskin.Sayings, {"Cenarius, grant me the armor of the forest!"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.barkskin.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.barkskin.Sayings.customemote, {"'s skin darkens and appears rough."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.barkskin.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.teleport_moonglade then RPHelper2DBPC.global.RPEvent.teleport_moonglade = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_moonglade.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_moonglade.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_moonglade.Sayings.customemote, {
    "channels arcane forces within OPself and concentrates on Moonglade.",
    "asks Elune to take OP to Moonglade.",
    "feels Moonglade's call as SP summons arcane powers.",
    "evokes Elune's arcane powers and visualizes Nighthaven."
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_moonglade.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.force_of_nature then RPHelper2DBPC.global.RPEvent.force_of_nature = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.force_of_nature.Sayings, {"Trees, protect me!"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.force_of_nature.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.force_of_nature.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.force_of_nature.Sayings.random, {})

--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.cyclone.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cyclone.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cyclone.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cyclone.Sayings.random, {})
]]--
--=====================================================================--
-- Restoration           
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.mark_of_the_wild then RPHelper2DBPC.global.RPEvent.mark_of_the_wild = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mark_of_the_wild.Sayings, {	
	"TARGET, bring honor to yourself and your people.",	-- mithyk
	"TARGET, fight with honor, fight with pride.",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mark_of_the_wild.Sayings.emote, {"pray","pray","pray","pray","pray","pray",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mark_of_the_wild.Sayings.customemote, {"calls upon the spirits of the land to watch over TARGET",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mark_of_the_wild.Sayings.random, {})

--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.rejuvenation.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rejuvenation.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rejuvenation.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rejuvenation.Sayings.random, {})
                       
self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_touch.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_touch.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_touch.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_touch.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.regrowth.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.regrowth.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.regrowth.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.regrowth.Sayings.random, {})  
]]--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.insect_swarm.Sayings, {"TARGET is covered in BEEEEEEES!"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.insect_swarm.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.insect_swarm.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.insect_swarm.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.rebirth.Sayings, {"Elune! Hear my call and restore life to TARGET!"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rebirth.Sayings.emote, {"MOURN"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rebirth.Sayings.customemote, {"places a small seed atop TARGET's body and says a prayer.",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rebirth.Sayings.random, {})     

--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.remove_curse.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.remove_curse.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.remove_curse.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.remove_curse.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_poison.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_poison.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_poison.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_poison.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.abolish_poison.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.abolish_poison.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.abolish_poison.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.abolish_poison.Sayings.random, {}) 

self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_swiftness.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_swiftness.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_swiftness.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_swiftness.Sayings.random, {})  
]]--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tranquility.Sayings, {
    "Elune, hear my plea and help me aid my friends!",
    "Healing spirits, arise!",
})

if not RPHelper2DBPC.global.RPEvent.tranquility then RPHelper2DBPC.global.RPEvent.tranquillity = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tranquility.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tranquility.Sayings.customemote, {"fills the area with the tranquility of the forest.",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tranquility.Sayings.random, {})   

if not RPHelper2DBPC.global.RPEvent.innervate then RPHelper2DBPC.global.RPEvent.innervate = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.innervate.Sayings, {"Innervating TARGET!"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.innervate.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.innervate.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.innervate.Sayings.random, {})  

if not RPHelper2DBPC.global.RPEvent.gift_of_the_wild then RPHelper2DBPC.global.RPEvent.gift_of_the_wild = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_wild.Sayings, {"A gift for you and your comrades, TARGET."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_wild.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_wild.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_wild.Sayings.random, {})

--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.swiftmend.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.swiftmend.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.swiftmend.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.swiftmend.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.tree_of_life.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tree_of_life.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tree_of_life.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tree_of_life.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.lifebloom.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.lifebloom.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.lifebloom.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.lifebloom.Sayings.random, {})
]]--
elseif ( myLocale == "deDE") then
if self.DruidDE then self:DruidDE() end
elseif (myLocale == "frFR") then
if self.DruidFR then self:DruidFR() end
elseif (myLocale == "esES") then
if self.DruidES then self:DruidES() end

end
end