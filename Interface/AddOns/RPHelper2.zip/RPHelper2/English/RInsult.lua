 --=====================================================================--
-- RANDOM INSULTS
-- "You [1] [2] [3]."
-- "You [bad] [pile of] [material]."

-- NOTE: Unlike other random phrases, every RP trait may be used in each insult.
-- Example:  "You [1](WARRIOR) [2](ANY) [3](GNOME)."

-- This file & format will likely change in the future.
--=====================================================================--
-- Contributors to this file:  mithyk

function RPHelper2:InitializeInsults(myLocale, myRace, myClass)
RPHelper2DBPC.global.RandomInsult = {}
if myLocale == "enUS" or myLocale == "enGB" then
RPHelper2DBPC.global.RandomInsult = {

	[1] = {"annoying","cantankerous","demented","disgusting","festering","filthy","infuriating",
		"insignificant","laughable","nauseating","noxious","pathetic","pitiful","revolting","rotten",
		"sickening","useless",
		},

	[2] = {"lump of","crock of","ball of","mass of","tub of","loaf of","bucket of","mound of",
    	"bunch of","stack of","excuse for","glob of","bag of","heap of","mountain of","load of",
    	"barrel of","sack of","blob of","pile of","clump of","shovel full of","bowl of",
    	"wheelbarrel full of","box of","crate of","collection of","wagonload of","vat of",
		},

	[3] = {"armpit hairs","cow cud","cow pies","fleas","foot fungus","garbage","gutter mud","hogwash","leprosy scabs","mule froth",
		"nasal hairs","navel lint","nose pickings","pigeon bombs",
		"pimple squeezings","puke curds","puke lumps","rabbit raisins",
		"rubbish","sewage","sewer seepage","sinus clots","sinus drainage","spittoon spillage","stable sweepings","swamp mud","swine",
		"manure","kodo manure","murloc manure","droppings","kodo droppings","murloc droppings",
     	"trogg cysts","murloc entrails","buzzard innards",
	 	},
	}
-------------------------------------------------------------------------
-- Alliance
-------------------------------------------------------------------------
if (myRace == "DWARF") then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},
	
--	})
elseif myRace == "GNOME" then
self:JoinArrays(RPHelper2DBPC.global.RandomInsult[1], {"bad breathed","boring","contaminated","contemptible","crusty","defective","erratic","imitation",
		"inadequate","incapable","inept","infantile",
		"insufferable","irrational","lousy","malignant","mentally deficient","monotonous","mutilated","obnoxious","pitiable",
		"predictable","putrid","second-hand","sloshy","spastic","stale","stenchy","unimpressive",
--		},

--	[2] = {},

--	[3] = {},
	
	})
--elseif myRace == "HUMAN" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})

--elseif myRace == "NIGHTELF" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})

--elseif myRace == "DRAENEI" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--    [1] = {},
    
--    [2] = {},
    
--    [3] = {},
    
--    })
-------------------------------------------------------------------------
-- Horde
-------------------------------------------------------------------------
--elseif myRace == "ORC" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})
--elseif myRace == "TAUREN" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})

--elseif myRace == "TROLL" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})

--elseif myRace == "UNDEAD" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})
--elseif myRace == "BLOODELF" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})
end
-------------------------------------------------------------------------
-- Classes
-------------------------------------------------------------------------
if myClass == "DRUID" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})
--elseif myClass == "HUNTER" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {


--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})
--elseif myClass == "MAGE" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {


--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})
elseif myClass == "PALADIN" then
self:JoinArrays(RPHelper2DBPC.global.RandomInsult[1], {"appalling","deeply disturbed","depraved","dirty","disgraceful","dismal","embarrassing","foul","grisly","grotesque","gruesome","hopeless","infested",
		"lazy","moth-eaten","nasty","perverted","repulsive","shameless","sick","sloppy",
		
		-- from a shakespearean insult generator (Thanks to: mithyk)
		"annoying","artless","bawdy","beslubbering","bootless",
		"churlish","cockered","clouted","craven","currish","dankish",
		"disgusting","dissembling","droning","errant","fawning","festering",
		"fobbing","forward","frothy","gleeking","goatish","gorbellied",
		"impertinent","infectious","insignificant","jarring","laughable",
		"loggerheaded","lumpish","mammering","mangled","mewling","nauseating",
		"pathetic","paunchy","pitiful","pribbling","puking","puny","qualling",
		"rank","reeky","revolting","roguish","rotten","ruttish","saucy",
		"sickening","spleeny","spongy","surly","tottering","unmuzzled","vain",
		"venomed","villainous","warped","wayward","weedy","yeasty","cullionly",
		"fusty","calumnious","wimpled","burly-boned","misbegotten","odiferous",
		"poisonous","fishified","wart-necked",
		
		-- 2nd part from a shakespearean insult generator (Thanks to: mithyk)
		"base-court","bat-fowling","beef-witted","beetle-headed",
		"boil-brained","clapper-clawed","clay-brained","common-kissing","crook-pated",
		"dismal-dreaming","dizzy-eyed","doghearted","dread-bolted",
		"earth-vexing","elf-skinned","fat-kidneyed","fen-sucked","flap-mouthed",
		"fly-bitten","folly-fallen","fool-born","full-gorged","guts-griping",
		"half-faced","hasty-witted","hedge-born","hell-hated","idle-headed",
		"ill-breeding","ill-nurtured","knotty-pated","milk-livered","motley-minded",
		"onion-eyed","plume-plucked","pottle-deep","pox-marked",
		"reeling-ripe","rough-hewn","rude-growing","rump-fed","shard-borne",
		"sheep-biting","spur-galled","swag-bellied","tardy-gaited","tickle-brained",
		"toad-spotted","unchin-snouted","weather-bitten","whoreson",
		"malmsey-nosed","rampallian","lily-livered","scurvy-valiant","brazen-faced",
		"unwash'd","bunch-back'd","leaden-footed","muddy-mettled",
		"pigeon-liver'd","scale-sided",
		})

--	[2] = {

--		},

	self:JoinArrays(RPHelper2DBPC.global.RandomInsult[1], {
		-- 3rd part from a shakespearean insult generator (modified to plurals) (Thanks to: mithyk)
		"apple-johns","barnacles","bladders","boar-pigs",
		"bugbears","bum-baileys","canker-blossoms","clack-dishs","clotpoles",
		"coxcombs","codpieces","death-tokens","dewberries","flap-dragons","flax-wenchs",
		"flirt-gills","foot-lickers","fustilarians","giglets","gudgeons",
		"haggards","harpies","hedge-pigs","horn-beasts","hugger-muggers","joitheads",
		"lewdsters","louts","maggot-pies","malt-worms","mammets","measles","minnows",
		"miscreants","moldwarps","mumble-news","nut-hooks","pigeon-eggs","pignuts",
		"puttocks","pumpions","ratsbanes","scuts","skainsmates","strumpets","varlots",
		"vassals","whey-faces","wagtails","knaves","blind-worms","popinjays",
		"scullians","jolt-heads","malcontents","devil-monks","toads","rascals",
		"Basket-Cockles",
	})
--elseif myClass == "PRIEST" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})
--elseif myClass == "ROGUE" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})
--elseif myClass == "SHAMAN" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})
--elseif myClass == "WARLOCK" then
--self:JoinArrays(RPHelper2DBPC.global.RandomInsult, {

--	[1] = {},

--	[2] = {},

--	[3] = {},

--	})
elseif myClass == "WARRIOR" then
self:JoinArrays(RPHelper2DBPC.global.RandomInsult[1], {"driveling","double ugly","dumpy",
	    "dumb","fermenting","miserable","moldy","pompous","rancid","raunchy","retarded",
		"seething","septic","skaggy","smelly","spoiled","steaming","stinking","stupid","ugly","worthless",
		})

self:JoinArrays(RPHelper2DBPC.global.RandomInsult[3], {"puke","vomit",})

end
elseif ( myLocale == "deDE") then
if self.RInsultDE then self:RInsultDE(myRace, myClass) end
elseif (myLocale == "frFR") then
if self.RInsultFR then self:RInsultFR() end
elseif (myLocale == "esES") then
if self.RInsultES then self:RInsultES() end
end
end



--[[	
If you are only using the ANY list you can change the random insults to Shakespearean insults
by cutting and pasting what's below.

Provided by mithyk	
-------------------------

--==Start Copy==-
RPHelper2DBPC.global.RandomInsult = {

[1] = {"annoying","artless","bawdy","beslubbering","bootless",
	"churlish","cockered","clouted","craven","currish","dankish",
	"disgusting","dissembling","droning","errant","fawning","festering",
	"fobbing","forward","frothy","gleeking","goatish","gorbellied",
	"impertinent","infectious","insignificant","jarring","laughable",
	"loggerheaded","lumpish","mammering","mangled","mewling","nauseating",
	"pathetic","paunchy","pitiful","pribbling","puking","puny","qualling",
	"rank","reeky","revolting","roguish","rotten","ruttish","saucy",
	"sickening","spleeny","spongy","surly","tottering","unmuzzled","vain",
	"venomed","villainous","warped","wayward","weedy","yeasty","cullionly",
	"fusty","calumnious","wimpled","burly-boned","misbegotten","odiferous",
	"poisonous","fishified","wart-necked",},

[2] = {"base-court","bat-fowling","beef-witted","beetle-headed",
	"boil-brained","clapper-clawed","clay-brained","common-kissing","crook-pated",
	"dismal-dreaming","dizzy-eyed","doghearted","dread-bolted",
	"earth-vexing","elf-skinned","fat-kidneyed","fen-sucked","flap-mouthed",
	"fly-bitten","folly-fallen","fool-born","full-gorged","guts-griping",
	"half-faced","hasty-witted","hedge-born","hell-hated","idle-headed",
	"ill-breeding","ill-nurtured","knotty-pated","milk-livered","motley-minded",
	"onion-eyed","plume-plucked","pottle-deep","pox-marked",
	"reeling-ripe","rough-hewn","rude-growing","rump-fed","shard-borne",
	"sheep-biting","spur-galled","swag-bellied","tardy-gaited","tickle-brained",
	"toad-spotted","unchin-snouted","weather-bitten","whoreson",
	"malmsey-nosed","rampallian","lily-livered","scurvy-valiant","brazen-faced",
	"unwash'd","bunch-back'd","leaden-footed","muddy-mettled",
	"pigeon-liver'd","scale-sided",},

[3] = {"apple-john","baggage","barnacle","bladder","boar-pig",
	"bugbear","bum-bailey","canker-blossom","clack-dish","clotpole",
	"coxcomb","codpiece","death-token","dewberry","flap-dragon","flax-wench",
	"flirt-gill","foot-licker","fustilarian","giglet","gudgeon",
	"haggard","harpy","hedge-pig","horn-beast","hugger-mugger","joithead",
	"lewdster","lout","maggot-pie","malt-worm","mammet","measle","minnow",
	"miscreant","moldwarp","mumble-news","nut-hook","pigeon-egg","pignut",
	"puttock","pumpion","ratsbane","scut","skainsmate","strumpet","varlot",
	"vassal","whey-face","wagtail","knave","blind-worm","popinjay",
	"scullian","jolt-head","malcontent","devil-monk","toad","rascal",
	"Basket-Cockle",},

}
--==End Copy==-


]]