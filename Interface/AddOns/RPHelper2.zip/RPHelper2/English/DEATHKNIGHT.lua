--This has been taken from the Forsaken list.

function RPHelper2:InitializeDEATHKNIGHT(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB" ) then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Contributors to this file:  mithyk, Syrsa

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"Rend flesh with me!",
	"I'm too decrepit for this...",
	"No guts, no gore.",
	"What we do in death echoes in eternity...",
	"Death shall reign!",
	"Let life cease!",
	"Share my pain.",
	"I hunger.",
	"Must feed!",
	"Embrace the end!",
	"Embrace the cold!",
	"Die fool.",
	"Time to die.",
	"None shall survive.",
	"Time to be bad!",
	"Let's see what you're made of.",	--mithyk
	"The living be cursed!",	--mithyk
	"I dig rigor mortis.",	--mithyk
	"Death is the only adventure you have left.",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"cackle","snarl","crack","drool","grin","groan","smirk","snicker",})                  
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {	--from the warrior array
	["phrase"] = "I'll BLANK your BLANK!",

	[1] = {"rip", "tear", "slice", "cut", "carve", "hack", "cleave","eat","bite","claw",},

	[2] = {"arms off", "legs off", "eyeballs out", "eyes out", "face off", "teeth out", "kneecaps off", "intestines out",
			"stomach out", "heart out", "bowels out", "feet off", "ribs out", "spine out",},
	})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, { 
	"Death... is not the end.",
	"Everyone lives. Not everyone truly dies.",
	"Death is its own reward.",
	"Death is our business and business is good.",
	"Oooh, messy!",
	"Humiliation!!!",	--mithyk
	"Ha! Was that TPP best?",	--mithyk
	"Satisfying.",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {"gloat","grin SELF",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {})       
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {"laugh","cackle","snicker","gloat",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {"laugh","cackle","snicker","gloat",}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {"laugh","cackle","snicker","gloat",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {"laugh","cackle","snicker","gloat",}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {"laugh","cackle","snicker","gloat",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {
	"Sooner or later you'll be dead.",
	"Death stalks you at every turn. aaah! There it is, death! Oh, where were we? Death!",
	"Is it hard to breathe with so many holes in your lungs?",
	"Don't die now! The fun is just beginning!",
	"Don't cry. Your pain will end soon.",
	"I will feed upon your fresh corpse.",
	"No remorse!",
	"What's it like knowing your life is about to end?",
	"Beg! I like it when they beg!",
	"Death can be very liberating. Try to think of this as... therapy",	--mithyk
	"Death therapy, it works every time!",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {"laugh","cackle","snicker","gloat",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {"laugh","cackle","snicker","gloat",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings, {
	"Saved by the shadow.",
	"Your time will come, but not yet.",
	"Do not seek death - it will find you soon enough.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.random, {})
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings, {
	"Saved by the shadow.",
	"Your time will come, but not yet.",
	"Do not seek death - it will find you soon enough.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.random, {})
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME, Pet's Name	
	-- PTNAME, Pet's target's name                           
	-- PTSP, Pet's target's subject pronoun 	(He/She/It)
	-- PTOP, Pet's target's object pronoun 	(him/her/it)
	-- PTPP, Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random, {})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME, Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random, {})
--=====================================================================--
-- When your PET DIES.
	-- PNAME, Pet's Name
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings, {"Don't worry, PNAME. Death is an improvement."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.emote, {})                                        
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.random, {})
--=====================================================================--
-- When you talk to an NPC  (A dialogue/merchant/quest/etc. box opens)
--=====================================================================-- 
-------------------------------------------------------------------------
-- The BEGINNING of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
	-- "KNEEL" is automatically added if the NPC is 5 levels higher than you
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings, {
	"TARGET, listen up!",
	"TARGET, pay attention! I haven't got all day.",
	"TARGET, listen very carefully and try to keep up.",
	"TARGET, listen carefully.",
	"TARGET, I require something of you.",
	"TARGET, death speaks, listen.",
})                       
-------------------------------------------------------------------------
-- The END of a conversation with an NPC 
	-- "CURTSEY" is automatically added for female characters
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings, {
	"TARGET, embrace the shadow while time remains.",
	"TARGET, beware, enemies abound.",
	"TARGET, beware the living, trust in the dead.",
	"TARGET, remember - patience, discipline.",
	"TARGET, our time will come.",
	"TARGET, trust no one",
	"TARGET, Watch your back",
})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {
	})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {
	"Shut up, NPC.",
	"Quiet, NPC.",
	"Let's see how well you talk after I cut that tongue out.",
	"Quiet! RINSULT",
	"Shut up! RINSULT",
	"TEXT Haha!"
	})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {
	"I'm alive!... kinda...",
	"It's cold! And there are wolves after me...! Huh? Wha? Where am I?",
	"That was close. In my state, you see death everywhere... DEATH!",
	"Saw a bright light for a moment - then I realized I best get clear.",
	"I'll need to find a replacement for a part or two.",
	"Hrmm, that hole may be permanent.",
	"I'm having a mid-death crisis.",	--mithyk
	})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})

--=====================================================================--
--  Fear, etc.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})
elseif ( myLocale == "deDE") then
if self.UndeadDE then self:DKDE() end
elseif (myLocale == "frFR") then
if self.UndeadFR then self:DKFR() end
elseif (myLocale == "esES") or (myLocale == "esMX") then
if self.UndeadES then self:DKES() end

end
end