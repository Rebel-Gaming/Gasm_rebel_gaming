function RPHelper2:InitializeBLOODELF(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB") then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Contributors to this file:   mithyk

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"Death to all who oppose us!",
	"The Sin'dorei will prevail!",
	"For the glory of Quel'thalas!",
	"For the glory of Anastarian!",
	"Remember the Sunwell!",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"guffaw SELF","laugh SELF","crack",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {
	"The Sin'dorei have prevailed.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {"BLEED",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, { "I didn't feel a thing! Hah!", })
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {"laugh SELF","guffaw SELF",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {"laugh SELF","guffaw SELF",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {"laugh SELF","guffaw SELF",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {"laugh SELF","guffaw SELF",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {"laugh SELF","guffaw SELF",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.random, {})
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.random, {})
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME, Pet's Name	
	-- PTNAME, Pet's target's name                           
	-- PTSP, Pet's target's subject pronoun 	(He/She/It)
	-- PTOP, Pet's target's object pronoun 	(him/her/it)
	-- PTPP, Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random, {})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME, Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random, {})
--=====================================================================--
-- When your PET DIES.
	-- PNAME, Pet's Name
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.random, {})
-------------------------------------------------------------------------
-- The BEGINNING of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
	-- "KNEEL" is automatically added if the NPC is 5 levels higher than you
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings, {
	"TARGET, our enemies will fall.",
	"The eternal sun guides us, TARGET.",
	"We will persevere, TARGET.",
	"TARGET, victory lies ahead.",
	"TARGET, the dark times will pass.",
	"Glory to the Sin'dorei, TARGET.",
})
-------------------------------------------------------------------------
-- The END of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings, {
	"TARGET, remember the Sunwell.",
	"We will have justice, TARGET.",
	"TARGET, the reckoning is at hand.",
	"Hold your head high, TARGET.",
	"Mind yourself, TARGET.",
	"Death to all who oppose us.",
})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})

--=====================================================================--
-- Blood Elf Racials
--=====================================================================--
local playerRace, englishRace = UnitRace("player");
if strupper(englishRace) == "BLOODELF" then
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings, {"My mana tap brings all the boys to the yard.","Your undoing is my power.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.customemote, {"'s eyes glow green as SP sucks the mana from TARGET.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.customemote, {"unleashes a screaming torrent of arcane energy."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.random, {})
end
--=====================================================================--
--  Fear, etc.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {"flies into a rage as PP magic is taken away!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})

elseif ( myLocale == "deDE") then
if self.BloodElfDE then self:BloodElfDE() end
elseif (myLocale == "frFR") then
if self.BloodElfFR then self:BloodElfFR() end
elseif (myLocale == "esES") then
if self.BloodElfES then self:BloodElfES() end

end
end