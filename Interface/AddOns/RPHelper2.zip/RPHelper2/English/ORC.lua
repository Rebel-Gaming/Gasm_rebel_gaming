function RPHelper2:InitializeORC(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB") then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Contributors to this file:  mithyk

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"Strength and Honor!",
	"Tremble! A hero of the horde is upon you!",
	"For the Horde!",
	"Remember Doomhammer!",
	"Remember Durotan!",
	"For Glory! For Honor!",
	 "For the glory of the warchief!",
	"For the glory of the horde!",
	"Victory for the horde!",
	"My life for the Horde!",
	"Time for Killing!",
	"Time to die.",
	"Your destiny is at hand.",
	"Taste the fury of the horde!",
	"You shall not survive!",
	"Your time has come!",
	"Death to all who oppose the horde!",
	"Let us shed blood together!",
	"If we had been meant to fight, we would have been born with tough, baggy, green skin... oh, wait...",  -- butchered by Syrsa
	"Death awaits you on these big, nasty teeth.",
	"To the death!",
	"You will bow to me!",
	"Prepare to die!",
	"Let's play.",
	"You are weak.",

	"You will cower before me!",
	"For my ancestors!",
	"Ancestors watch over me!",
	"Ancestors with me!",
	"Ancestors aid me!",
	"Land and Liberty!",
	"It's clobberin' time!",
	"Ancestors! Honor! Homeland!",
	"Durotar!",
	"For Durotar!",
	"A PLAYER_CLASS of Durotar is upon you!",
	"Durotar forever!",
	"Honor! Skill! Strength!",
	"Remember the camps!",
	"Bare the fangs of war!",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"snarl","guffaw SELF","growl","laugh SELF","crack",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {
	"Next time, I want a real opponent.",
	"Hopeless and dead.",
	"Didn't put up much of a fight.",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {
	"Is that it?",
	"Stop poking me!",
	"Poke! Poke! Poke! Is that all you do?",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {"BLEED","snarl","growl",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {"laugh SELF","guffaw SELF",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.block then
self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {"laugh SELF","guffaw SELF",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
end
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {"laugh SELF","guffaw SELF",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {
	"This is too easy, I'm switching hands.",
	"This enemy is slow and weak.",
	"This enemy is slow and clumsy.",
	"Give up, weakling.",
	"Next time, try dodging... or parrying... Sayingsthing...",
	"Maybe I should do this blindfolded.",
	"Tell me you brought friends?",
	"You are outmatched.",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {"laugh SELF","guffaw SELF",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.random, {})
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.random, {})
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME, Pet's Name	
	-- PTNAME, Pet's target's name                           
	-- PTSP, Pet's target's subject pronoun 	(He/She/It)
	-- PTOP, Pet's target's object pronoun 	(him/her/it)
	-- PTPP, Pet's target's possessive pronoun 	(his/her/its)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random, {})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME, Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random, {})
--=====================================================================--
-- When your PET DIES.
	-- PNAME, Pet's Name
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.random, {})]]--
--=====================================================================--
-- When you talk to an NPC  (A dialogue/merchant/quest/etc. box opens)
--=====================================================================--
-------------------------------------------------------------------------
-- The BEGINNING of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
	-- "KNEEL" is automatically added if the NPC is 5 levels higher than you
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings, {
	"Throm'ka TARGET!",
	"Mak'gra TARGET!",
	"Lok'tar TARGET!",
	"Lok'tar Ogar TARGET!",
	"TARGET, lok'tar friend.",
	"TARGET, glory to the horde!",
	"TARGET, strength!",
	"TARGET, strength and Honor!",
 	"Thrall hal! I must speak to you TARGET.",
	"Blood and thunder! TARGET, we must speak.",

	"TARGET, lok'tar friend!",
	"TARGET, glory to the horde!",
	"TARGET, strength!",
	"TARGET, strength and Honor!",
	"TARGET, throm'ka!",
	"TARGET, mak'gra!",
	"TARGET, lok'tar!",
	"TARGET, I trust you've been well?",
	"TARGET, you look strong as ever!",
	"TARGET, we must speak.",
	"TARGET, I must speak to you.",
	"Throm'ka TARGET!",
	"Throm'ka! TARGET, I trust you've been well?",
	"Throm'ka! I trust you've been well TARGET?",
	"Throm'ka! You look strong as ever TARGET!",
	"Throm'ka! I must speak to you TARGET.",
	"Throm'ka! TARGET, we must speak.",
	"Mak'gra TARGET!",
	"Mak'gra! TARGET, I trust you've been well?",
	"Mak'gra! I trust you've been well TARGET?",
	"Mak'gra! You look strong as ever TARGET!",
	"Mak'gra! I must speak to you TARGET.",
	"Mak'gra! TARGET, we must speak.",
	"Lok'tar TARGET!",
	"Lok'tar! TARGET, I trust you've been well?",
	"Lok'tar! I trust you've been well TARGET?",
	"Lok'tar! You look strong as ever TARGET!",
	"Lok'tar! I must speak to you TARGET.",
	"Lok'tar! TARGET, we must speak.",
	"Thrall hal! TARGET, I trust you've been well?",
	"Thrall hal! I trust you've been well TARGET?",
	"Thrall hal! You look strong as ever TARGET!",
	"Thrall hal! I must speak to you TARGET.",
	"Thrall hal! TARGET, we must speak.",
	"Blood and thunder! TARGET, I trust you've been well?",
	"Blood and thunder! I trust you've been well TARGET?",
	"Blood and thunder! You look strong as ever TARGET!",
	"Blood and thunder! I must speak to you TARGET.",
	"Blood and thunder! TARGET, we must speak.",
	"Glory to the horde! TARGET, I trust you've been well?",
	"Glory to the horde! I trust you've been well TARGET?",
	"Glory to the horde! You look strong as ever TARGET!",
	"Glory to the horde! I must speak to you TARGET.",
	"Glory to the horde! TARGET, we must speak.",
	"Strength! TARGET, I trust you've been well?",
	"Strength! I trust you've been well TARGET?",
	"Strength! I must speak to you TARGET.",
	"Strength! TARGET, we must speak.",
	"Strength and Honor! TARGET, I trust you've been well?",
	"Strength and Honor! I trust you've been well TARGET?",
	"Strength and Honor! I must speak to you TARGET.",
	"Strength and Honor! TARGET, we must speak.",
})
-------------------------------------------------------------------------
-- The END of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
-------------------------------------------------------------------------
self:JoinArrays(RPHelper2DBPC.global.RPEvent.talktonpc_middle.Sayings, {
	"TARGET, strength!",
	"TARGET, until our paths cross again.",
	"TARGET, stay strong.",
	"TARGET, fight well friend.",
	"TARGET, for the horde!",
	"TARGET, may your blade be true.",
	"TARGET, may your blades never dull.",
	"TARGET, go forth to victory.",
	"TARGET, dabu.",
	"TARGET, go forth to victory.",
	"TARGET, go with honor.",
	"TARGET, victory!",
	"TARGET, be safe.",
	"Lok'regar No'gal TARGET.",
	"Lok'tar TARGET.",
	"Lok'tar Ogar TARGET.",
})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Sayingsish
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})]]--
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Sayingsish
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})]]--
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {
	"All patched up and ready for action!",
	"Har!  Missed all my vital spots!",
	"Grrr, blacked out there for a minute!",
	"Thought I was done for sure that time.",
	"That's gonna leave a mark.",
	"Gonna have a great scar to show off!",
	})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})
--=====================================================================--
--  Fear, etc.
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})]]--

elseif ( myLocale == "deDE") then
if self.OrcDE then self:OrcDE() end
elseif (myLocale == "frFR") then
if self.OrcFR then self:OrcFR() end
elseif (myLocale == "esES") then
if self.OrcES then self:OrcES() end

end
end