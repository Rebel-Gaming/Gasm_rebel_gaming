function RPHelper2:InitializeWARRIOR(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB" ) then
local _, englishRace = UnitRace("player");
local _, englishClass = UnitClass("player");
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"CHARGE","ROAR", "MOCK"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {

	["phrase"] = "I'll BLANK your BLANK!",

	[1] = {"rip", "tear", "slice", "cut", "carve", "hack", "cleave", "thrash"},

	[2] = {"arms off", "legs off", "eyeballs out", "eyes out", "face off", "teeth out", "kneecaps off", "intestines out",
			"stomach out", "heart out", "bowels out", "feet off", "ribs out", "spine out"},
	})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {"SNARL"})       
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {

	["phrase"] = "I'll BLANK your BLANK!",

	[1] = {"rip", "tear", "slice", "cut", "carve", "hack", "cleave", "thrash"},

	[2] = {"arms off", "legs off", "eyeballs out", "eyes out", "face off", "teeth out", "kneecaps off", "intestines out",
			"stomach out", "heart out", "bowels out", "feet off", "ribs out", "spine out"},

	})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {"Hit me again!  Let me absorb more!",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {

	["phrase"] =  "BLANK I absorb your BLANK BLANK like BLANK.",

	[1] =  {"You insect.  ", "Haha!  ", ""},

	[2] = {"puny", "pathetic", "insignificant", "laughable", "pitiful", "useless",},

	[3] = {"hits", "blows", "attacks", "attacks", },

	[4] = {"they're nothing.", "they're nothing.", "they're vapor.", "a sponge.", 
	"a stealth aircraft absorbing most of the microwave radiation that hits it and reflecting whatever it doesn't absorb away from the microwave source...  or something."},

	})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {"C'mon, TARGET_RACE, spend some more TARGET_POWER on me."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {"C'mon, TARGET_RACE, spend some more TARGET_POWER on me."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {})  
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {"LAUGH", "MOCK"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {"cackles with delight at PP critical strike."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME, Pet's Name	
	-- PTNAME, Pet's target's name                           
	-- PTSP, Pet's target's subject pronoun 	(He/She/It)
	-- PTOP, Pet's target's object pronoun 	(him/her/it)
	-- PTPP, Pet's target's personal pronoun 	(his/her/its)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random, {})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME, Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random, {})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})


--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hearthstone.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hearthstone.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hearthstone.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hearthstone.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_bow.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_bow.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_bow.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_bow.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_crossbow.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_crossbow.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_crossbow.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_crossbow.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_gun.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_gun.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_gun.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shoot_gun.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.throw.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.throw.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.throw.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.throw.Sayings.random, {})
--=====================================================================--
--  Fear, etc.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})
--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})


--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})

--=====================================================================--
--  Racials
	-- This way you can RP your racial differently as different classes
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.random, {})

if englishClass == "WARRIOR" then
--//////////////////////////////////////////////////////////////////////////--
-- Sayings Spells
--//////////////////////////////////////////////////////////////////////////--
--=====================================================================--
-- Arms
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.charge then RPHelper2DBPC.global.RPEvent.charge = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.charge.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.charge.Sayings.emote, {"CHARGE"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.charge.Sayings.customemote, {
    "yells PP head off as SP runs into battle.",
    "charges at TARGET.",
    "screams a battle cry and charges into combat.",
    })
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.charge.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.rend then RPHelper2DBPC.global.RPEvent.rend = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rend.Sayings, {"Bleed for me, TARGET."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rend.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.thunder_clap.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.thunder_clap.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.thunder_clap.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.thunder_clap.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.hamstring then RPHelper2DBPC.global.RPEvent.hamstring = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hamstring.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hamstring.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hamstring.Sayings.customemote, {"hacks at TARGET's hamstring.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hamstring.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heroic_strike.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heroic_strike.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heroic_strike.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heroic_strike.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.overpower.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.overpower.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.overpower.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.overpower.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.mocking_blow then RPHelper2DBPC.global.RPEvent.mocking_blow = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mocking_blow.Sayings, {"Over here! RINSULT",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mocking_blow.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mocking_blow.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mocking_blow.Sayings.random, {})
                        
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.anger_management.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.anger_management.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.anger_management.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.anger_management.Sayings.random, {})
                        
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.retaliation.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.retaliation.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.retaliation.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.retaliation.Sayings.random, {})
                                                                   
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sweeping_strikes.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sweeping_strikes.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sweeping_strikes.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sweeping_strikes.Sayings.random, {})   
                                                                   
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mortal_strike.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mortal_strike.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mortal_strike.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mortal_strike.Sayings.random, {})
--=====================================================================--
-- Fury
--=====================================================================--
if not RPHelper2DBPC.global.RPEvent.battle_shout then RPHelper2DBPC.global.RPEvent.battle_shout = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.battle_shout.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.battle_shout.Sayings.emote, {"ROAR",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.battle_shout.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.battle_shout.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.demoralizing_shout then RPHelper2DBPC.global.RPEvent.demoralizing_shout = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demoralizing_shout.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.demoralizing_shout.Sayings.emote, {"ROAR",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demoralizing_shout.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.demoralizing_shout.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cleave.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cleave.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cleave.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cleave.Sayings.random, {})
        
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.piercing_howl.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.piercing_howl.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.piercing_howl.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.piercing_howl.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.intimidating_shout then RPHelper2DBPC.global.RPEvent.intimidating_shout = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.intimidating_shout.Sayings, {"Go away!", "Fear me!", "Run you bastards!",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intimidating_shout.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intimidating_shout.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intimidating_shout.Sayings.random, {})
  
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.execute.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.execute.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.execute.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.execute.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.challeinging_shout then RPHelper2DBPC.global.RPEvent.challenging_shout = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.challenging_shout.Sayings, {"Attack me you bastards!",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.challenging_shout.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.challenging_shout.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.challenging_shout.Sayings.random, {})
            
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.death_wish.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.death_wish.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.death_wish.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.death_wish.Sayings.random, {})
             
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intercept.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intercept.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intercept.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intercept.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.slam then RPHelper2DBPC.global.RPEvent.slam = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.slam.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.slam.Sayings.emote, {"HI",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.slam.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.slam.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserker_rage.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserker_rage.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserker_rage.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserker_rage.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.whirlwind.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.whirlwind.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.whirlwind.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.whirlwind.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pummel.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pummel.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pummel.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pummel.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodthirst.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodthirst.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodthirst.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodthirst.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.recklessness.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.recklessness.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.recklessness.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.recklessness.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rampage.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rampage.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rampage.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rampage.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.commanding_shout.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.commanding_shout.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.commanding_shout.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.commanding_shout.Sayings.random, {})
--=====================================================================--
-- Protection
--=====================================================================--   
if not RPHelper2DBPC.global.RPEvent.bloodrage then RPHelper2DBPC.global.RPEvent.bloodrage = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodrage.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodrage.Sayings.emote, {"ROAR", "SNARL"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodrage.Sayings.customemote, {
    "looks like SP's getting angry.", "is going into a rage.",
    "goes into a furious rage."
    })
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodrage.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sunder_armor.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sunder_armor.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sunder_armor.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sunder_armor.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.shield_bash then RPHelper2DBPC.global.RPEvent.shield_bash = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_bash.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_bash.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_bash.Sayings.customemote, {"bashes PP shield into TARGET's face.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_bash.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.revenge.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.revenge.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.revenge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.revenge.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_block.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_block.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_block.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.last_stand.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.last_stand.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.last_stand.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.last_stand.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_wall.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_wall.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_wall.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_wall.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.concussion_blow.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.concussion_blow.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.concussion_blow.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.concussion_blow.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.shield_slam then RPHelper2DBPC.global.RPEvent.shield_slam = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_slam.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_slam.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_slam.Sayings.customemote, {"slams PP shield into TARGET's face.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shield_slam.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devastate.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devastate.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devastate.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devastate.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.spell_reflection then RPHelper2DBPC.global.RPEvent.spell_reflection = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.spell_reflection.Sayings, {"Right back at you, TARGET!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.spell_reflection.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.spell_reflection.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.spell_reflection.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intervene.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intervene.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intervene.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.intervene.Sayings.random, {})
end
elseif ( myLocale == "deDE") then
if self.WarriorDE then self:WarriorDE() end
elseif (myLocale == "frFR") then
if self.WarriorFR then self:WarriorFR() end
elseif (myLocale == "esES") then
if self.WarriorES then self:WarriorES() end
end
end