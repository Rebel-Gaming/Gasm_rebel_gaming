function RPHelper2:InitializePRIEST(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB") then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"I see death in your near future.",
	"Forecast for your next few minutes, a few sprinkles of blood and a chance of doom!",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {})    
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {
	"This trip to the next world brought to you by PLAYER_GUILDNAME.",
	"Are you still here? It's over, move on!",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {})       
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a Sayings shields you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random, {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.random, {})
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.random, {})

-- A Sayings'S GAINS A PET WHEN THEY MIND CONTROL --

--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME, Pet's Name	
	-- PTNAME, Pet's target's name                           
	-- PTSP, Pet's target's subject pronoun 	(He/She/It)
	-- PTOP, Pet's target's object pronoun 	(him/her/it)
	-- PTPP, Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random, {})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME, Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random, {})
--=====================================================================--
-- When your PET DIES.
	-- PNAME, Pet's Name
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.emote, {})      
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.random, {})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {"PRAY"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})
--=====================================================================--
--  Fear, etc.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})

--=====================================================================--
--  Racials
	-- This way you can RP your racial differently as different classes
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.random, {})


--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.random, {})

--//////////////////////////////////////////////////////////////////////////--
-- Priest Spells
--//////////////////////////////////////////////////////////////////////////--
--=====================================================================--
-- Discipline
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_word_fortitude.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_word_fortitude.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_word_fortitude.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_word_fortitude.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_word_shield.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_word_shield.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_word_shield.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_word_shield.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.inner_fire then RPHelper2DBPC.global.RPEvent.inner_fire = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.inner_fire.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.inner_fire.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.inner_fire.Sayings.customemote, {"glows with an Inner Fire.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.inner_fire.Sayings.random, {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dispel_magic.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dispel_magic.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dispel_magic.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dispel_magic.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.inner_focus.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.inner_focus.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.inner_focus.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.inner_focus.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shackle_undead.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shackle_undead.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shackle_undead.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shackle_undead.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_burn.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_burn.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_burn.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_burn.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_spirit.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_spirit.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_spirit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.divine_spirit.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_infusion.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_infusion.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_infusion.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.power_infusion.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.levitate.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.levitate.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.levitate.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.levitate.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_fortitude.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_fortitude.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_fortitude.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_fortitude.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mass_dispel.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mass_dispel.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mass_dispel.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mass_dispel.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pain_suppression.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pain_suppression.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pain_suppression.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.pain_suppression.Sayings.random, {})

-- Night Elf Only
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.starshards.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.starshards.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.starshards.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.elunes_grace.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.elunes_grace.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.elunes_grace.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.elunes_grace.Sayings.random, {})

-- Human Only
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feedback.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feedback.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feedback.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feedback.Sayings.random, {})

--Blood elf only
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.consume_magic.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.consume_magic.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.consume_magic.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.consume_magic.Sayings.random, {})

--=====================================================================--
-- Holy
--=====================================================================-- 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lesser_heal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lesser_heal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lesser_heal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lesser_heal.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.renew.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.renew.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.renew.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.renew.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heal.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flash_heal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flash_heal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flash_heal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flash_heal.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_healing.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_healing.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_healing.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_healing.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_heal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_heal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_heal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.greater_heal.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.circle_of_healing.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.circle_of_healing.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.circle_of_healing.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.circle_of_healing.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.binding_heal.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.binding_heal.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.binding_heal.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.binding_heal.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_mending.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_mending.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_mending.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.prayer_of_mending.Sayings.random, {})

-------------------------------------------------------------------------
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_disease.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_disease.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_disease.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_disease.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.abolish_disease.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.abolish_disease.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.abolish_disease.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.abolish_disease.Sayings.random, {})
-------------------------------------------------------------------------
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.smite.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.smite.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.smite.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.smite.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.resurrection then RPHelper2DBPC.global.RPEvent.resurrection = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrection.Sayings, {"TARGET, your service in this world is not yet finished, awaken!",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrection.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrection.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrection.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_nova.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_nova.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_nova.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_nova.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_fire.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_fire.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_fire.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.holy_fire.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.spirit_of_redemption.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.spirit_of_redemption.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.spirit_of_redemption.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.spirit_of_redemption.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightwell.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightwell.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightwell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightwell.Sayings.random, {})

-- Human and Dwarf Only
if not RPHelper2DBPC.global.RPEvent.desperate_prayer then RPHelper2DBPC.global.RPEvent.desperate_prayer = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.desperate_prayer.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.desperate_prayer.Sayings.emote, {"PRAY",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.desperate_prayer.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.desperate_prayer.Sayings.random, {}) 

-- Dwarf & Draenei Only
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear_ward.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear_ward.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear_ward.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fear_ward.Sayings.random, {})

--=====================================================================--
-- Shadow Magic
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_word_pain.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_word_pain.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_word_pain.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_word_pain.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fade.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fade.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fade.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fade.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_blast.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_blast.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_blast.Sayings.customemote, {"hands glow with a dark magic.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_blast.Sayings.random, {}) 

if not RPHelper2DBPC.global.RPEvent.psychic_scream then RPHelper2DBPC.global.RPEvent.psychic_scream = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.psychic_scream.Sayings, {"Get away from me!",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.psychic_scream.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.psychic_scream.Sayings.customemote, {}) 
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.psychic_scream.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.mind_flay then RPHelper2DBPC.global.RPEvent.mind_flay = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_flay.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_flay.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_flay.Sayings.customemote, {"melts TARGET's face."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_flay.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_soothe.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_soothe.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_soothe.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_soothe.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowguard.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowguard.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowguard.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowguard.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.mind_vision then RPHelper2DBPC.global.RPEvent.mind_vision = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_vision.Sayings, {"Allow me to see though your eyes, TARGET",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_vision.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_vision.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_vision.Sayings.random, {}) 

if not RPHelper2DBPC.global.RPEvent.mind_control then RPHelper2DBPC.global.RPEvent.mind_control = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_control.Sayings, {"Do not resist TARGET, it is Futile!",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_control.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_control.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mind_control.Sayings.random, {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_protection.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_protection.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_protection.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_protection.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silence.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silence.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silence.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.silence.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vampiric_embrace.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vampiric_embrace.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vampiric_embrace.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vampiric_embrace.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.shadowform then RPHelper2DBPC.global.RPEvent.shadowform = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowform.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowform.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowform.Sayings.customemote, {"'s entire body becomes engulfed in pure shadow.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowform.Sayings.random, {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vampiric_touch.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vampiric_touch.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vampiric_touch.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.vampiric_touch.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowfiend.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowfiend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowfiend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowfiend.Sayings.random, {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_word_death.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_word_death.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_word_death.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadow_word_death.Sayings.random, {})

-- Troll Only
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hex_of_weakness.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hex_of_weakness.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hex_of_weakness.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hex_of_weakness.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowguard.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowguard.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowguard.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowguard.Sayings.random, {})

-- Undead Only
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.touch_of_weakness.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.touch_of_weakness.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.touch_of_weakness.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.touch_of_weakness.Sayings.random, {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devouring_plague.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devouring_plague.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devouring_plague.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.devouring_plague.Sayings.random, {})

elseif ( myLocale == "deDE") then
if self.PriestDE then self:PriestDE() end
elseif (myLocale == "frFR") then
if self.PriestFR then self:PriestFR() end
elseif (myLocale == "esES") then
if self.PriestES then self:PriestES() end
end
end