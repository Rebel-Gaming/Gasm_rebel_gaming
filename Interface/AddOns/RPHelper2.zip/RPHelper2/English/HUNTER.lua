function RPHelper2:InitializeHUNTER(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB") then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"The beast with me is nothing compared to the beast within...",
	"Looks like target practice.",	--mithyk
	"Witness the firepower of this fully armed huntsman!",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"CHARGE","ROAR",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})]]--
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})]]--
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})]]--
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})]]--
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})]]--
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random, {})]]--
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {
	"I will feed your corpse to the beasts of the wild.",
	"A single shot to the head... priceless.",	--mithyk
	"Whoops, sorry, finger slipped!",	--mithyk
	"First the ammo goes here, then the ammo goes in your head.",	--mithyk
	"Two shots in the heart. One in the head. Only way to be sure.",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})]]--
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME, Pet's Name	
	-- PTNAME, Pet's target's name                           
	-- PTSP, Pet's target's subject pronoun 	(He/She/It)
	-- PTOP, Pet's target's object pronoun 	(him/her/it)
	-- PTPP, Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings, {
	"Go PNAME!",		
	"Go get PTOP, PNAME!", 
	"Kill PTOP, PNAME.",
	"Kill PTOP for me, PNAME.",
	"Attack PTOP, PNAME.",
	"Attack PTOP for me, PNAME.",
	"Assist me PNAME.",
	"PTSP needs to die, PNAME.",
	"PTSP's in our way, PNAME.",
	"PNAME!  Attack PTOP.",
	"PNAME!  Kill PTOP.",
	"PNAME!  Go get PTOP.",
	"Attack this TARGET, PNAME.",
	"Kill this TARGET, PNAME.",
	"PNAME! Sic this TARGET.",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random, {})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME, Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings, {
	"What's that smell?  Bad PNAME, bad!",
	"Good job, PNAME.",
	"Well done, PNAME.",
	"You're doing well, PNAME.",
	"Stay close to me, PNAME.",
	"You're doing great, PNAME.",
	"Keep it up, PNAME.",
	"PNAME, you've done well.",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote, {
	"commends PNAME on a job well done.",	--mithyk
	"gently pats PNAME.",	--mithyk
	"gives PNAME a quick pat.",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random, {
})
--=====================================================================--
-- When your PET DIES.
	-- PNAME, Pet's Name
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings, {
	"PNAME! Play Dead!",
	"I'll be right there PNAME! Hold on!",
	"PNAME! Play Dead! Oh... you're not playing are you?",
	"Noooo!",	--mithyk
	"PNAME! No!",	--mithyk
	"PNAME!",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.petdies.Sayings.random, {})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})]]--
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})]]--
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})]]--
--=====================================================================--
--  Fear, etc.
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})]]--

--=====================================================================--
--  Racials
	-- This way you can RP your racial differently as different classes
--=====================================================================--
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.shadowmeld.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneform.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.find_treasure.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.random, {})]]--
--//////////////////////////////////////////////////////////////////////////--
-- Sayings Spells
--//////////////////////////////////////////////////////////////////////////--
--=====================================================================--
-- Beast Mastery
--=====================================================================-- 
if not RPHelper2DBPC.global.RPEvent.aspect_of_the_monkey then RPHelper2DBPC.global.RPEvent.aspect_of_the_monkey = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_monkey.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_monkey.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_monkey.Sayings.customemote, {
	"movements take on an agile, jerky motion that is confusing to watch, full of false steps and feints.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_monkey.Sayings.random, {})
                                                    
if not RPHelper2DBPC.global.RPEvent.aspect_of_the_hawk then RPHelper2DBPC.global.RPEvent.aspect_of_the_hawk = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_hawk.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_hawk.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_hawk.Sayings.customemote, {
	"takes on a look of concentration, clearly focusing on his targets to the exclusion of everything else.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_hawk.Sayings.random, {})    
                                                    
if not RPHelper2DBPC.global.RPEvent.aspect_of_the_cheetah then RPHelper2DBPC.global.RPEvent.aspect_of_the_cheetah = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_cheetah.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_cheetah.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_cheetah.Sayings.customemote, {
	"'s movements turn rapid, swift, and careless.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_cheetah.Sayings.random, {})    
                                                    
if not RPHelper2DBPC.global.RPEvent.aspect_of_the_beast then RPHelper2DBPC.global.RPEvent.aspect_of_the_beast = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_beast.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_beast.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_beast.Sayings.customemote, {
	"begins moving with caution, careful to leave no sign of PP passage.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_beast.Sayings.random, {})   
                                                    
if not RPHelper2DBPC.global.RPEvent.aspect_of_the_pack then RPHelper2DBPC.global.RPEvent.aspect_of_the_pack = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_pack.Sayings, { "Faster! Run faster!" })
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_pack.Sayings.emote, {"train"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_pack.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_pack.Sayings.random, {})  
                                                    
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_wild.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_wild.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_wild.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aspect_of_the_wild.Sayings.random, {})          
                                                    
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mend_pet.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mend_pet.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mend_pet.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mend_pet.Sayings.random, {})]]--
                                         
if not RPHelper2DBPC.global.RPEvent.eagle_eye then RPHelper2DBPC.global.RPEvent.eagle_eye = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eagle_eye.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eagle_eye.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.eagle_eye.Sayings.customemote, {
	"gazes into the distance.",	--mithyk
	"scans the horizon.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eagle_eye.Sayings.random, {})
                         
if not RPHelper2DBPC.global.RPEvent.eyes_of_the_beast then RPHelper2DBPC.global.RPEvent.eyes_of_the_beast = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eyes_of_the_beast.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eyes_of_the_beast.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.eyes_of_the_beast.Sayings.customemote, {
	"seems to descend into a trance state, while PP pet PNAME suddenly seems far more focused.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.eyes_of_the_beast.Sayings.random, {}) 
                         
if not RPHelper2DBPC.global.RPEvent.scare_beast then RPHelper2DBPC.global.RPEvent.scare_beast = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.scare_beast.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scare_beast.Sayings.emote, {"CHICKEN"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scare_beast.Sayings.customemote, {
	"starts to make really scary faces at TARGET.",	--duerma
	"locks eyes with the TARGET for several seconds.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.scare_beast.Sayings.random, {})         
                         
if not RPHelper2DBPC.global.RPEvent.beast_lore then RPHelper2DBPC.global.RPEvent.beast_lore = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.beast_lore.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.beast_lore.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.beast_lore.Sayings.customemote, {	
	"carefully considers what SP knows about the TARGET.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.beast_lore.Sayings.random, {})      
                         
if not RPHelper2DBPC.global.RPEvent.bestial_wrath then RPHelper2DBPC.global.RPEvent.bestial_wrath = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bestial_wrath.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bestial_wrath.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.bestial_wrath.Sayings.customemote, {
	", with a single command, sends PP pet PNAME into a furious rage.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bestial_wrath.Sayings.random, {})   
                         
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.tranquilizing_shot.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tranquilizing_shot.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tranquilizing_shot.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.tranquilizing_shot.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.kill_command.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.kill_command.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.kill_command.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.kill_command.Sayings.random, {})   ]]--

--=====================================================================--
-- Marksmanship
--=====================================================================--                                     
if not RPHelper2DBPC.global.RPEvent.arcane_shot then RPHelper2DBPC.global.RPEvent.arcane_shot = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_shot.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_shot.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_shot.Sayings.customemote, {
    "adds some arcane power to this shot for a little more oomph.",
    "sends the gift of an arcane shot, from me to you, TARGET.",
    "blasts TARGET with some arcane power.",
    
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_shot.Sayings.random, {})                                           
                                   
if not RPHelper2DBPC.global.RPEvent.concussive_shot then RPHelper2DBPC.global.RPEvent.concussive_shot = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.concussive_shot.Sayings, {
    "Not so fast, TARGET!",
    "Enjoy the last few seconds of your life, TARGET.",
    "Whoah, slow down, TARGET!",
    "Going somewhere? I think not.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.concussive_shot.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.concussive_shot.Sayings.customemote, {"suggests TARGET slows down a bit.",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.concussive_shot.Sayings.random, {})   

if not RPHelper2DBPC.global.RPEvent.distracting_shot then RPHelper2DBPC.global.RPEvent.distracting_shot = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.distracting_shot.Sayings, {"Yoohoo... look at me!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.distracting_shot.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.distracting_shot.Sayings.customemote, {"tries to distract TARGET."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.distracting_shot.Sayings.random, {})     

--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.multi_shot.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.multi_shot.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.multi_shot.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.multi_shot.Sayings.random, {})]]--

if not RPHelper2DBPC.global.RPEvent.aimed_shot then RPHelper2DBPC.global.RPEvent.aimed_shot = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aimed_shot.Sayings, {
	"Ready, Aim, Fire!",
	"Can you hold still for a moment TARGET? I'm trying to aim.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aimed_shot.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.aimed_shot.Sayings.customemote, {
	"takes careful aim at TARGET.",		--mithyk
	"takes PP time aiming.",	--mithyk
	"aims with careful precision.",	--mithyk
	"takes PP time, targeting for a precise shot.",	--mithyk
	"carefully gauges distance and windage for a precise shot.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.aimed_shot.Sayings.random, {})    
          
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.scatter_shot.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scatter_shot.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scatter_shot.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scatter_shot.Sayings.random, {}) 

self:JoinArrays(RPHelper2DBPC.global.RPEvent.silencing_shot.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silencing_shot.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silencing_shot.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silencing_shot.Sayings.random, {}) 

self:JoinArrays(RPHelper2DBPC.global.RPEvent.steady_shot.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.steady_shot.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.steady_shot.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.steady_shot.Sayings.random, {}) 

-------------------------------------------------------------------------       
                            
self:JoinArrays(RPHelper2DBPC.global.RPEvent.serpent_sting.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.serpent_sting.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.serpent_sting.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.serpent_sting.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.scorpid_sting.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scorpid_sting.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scorpid_sting.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scorpid_sting.Sayings.random, {})    
 
self:JoinArrays(RPHelper2DBPC.global.RPEvent.viper_sting.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.viper_sting.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.viper_sting.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.viper_sting.Sayings.random, {})   

-------------------------------------------------------------------------       
       
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hunters_mark.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hunters_mark.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hunters_mark.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.hunters_mark.Sayings.random, {})  
                                   
self:JoinArrays(RPHelper2DBPC.global.RPEvent.deterrence.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.deterrence.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.deterrence.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.deterrence.Sayings.random, {})   

self:JoinArrays(RPHelper2DBPC.global.RPEvent.disengage.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.disengage.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.disengage.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.disengage.Sayings.random, {}) 

self:JoinArrays(RPHelper2DBPC.global.RPEvent.rapid_fire.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rapid_fire.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rapid_fire.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.rapid_fire.Sayings.random, {})  

self:JoinArrays(RPHelper2DBPC.global.RPEvent.flare.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flare.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flare.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flare.Sayings.random, {})   

self:JoinArrays(RPHelper2DBPC.global.RPEvent.trueshot_aura.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.trueshot_aura.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.trueshot_aura.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.trueshot_aura.Sayings.random, {})   

self:JoinArrays(RPHelper2DBPC.global.RPEvent.volley.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.volley.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.volley.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.volley.Sayings.random, {})]]--
--=====================================================================--
-- Survival
--=====================================================================-- 
if not RPHelper2DBPC.global.RPEvent.track_beasts then RPHelper2DBPC.global.RPEvent.track_beasts = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_beasts.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_beasts.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_beasts.Sayings.customemote, {	--mithyk
"carefully examines the terrain for overturned leaves, broken twigs, bruised leaves - anything to tell OP what beasts have passed this way.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_beasts.Sayings.random, {})      
                                                                
if not RPHelper2DBPC.global.RPEvent.track_humanoids then RPHelper2DBPC.global.RPEvent.track_humanoids = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_humanoids.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_humanoids.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_humanoids.Sayings.customemote, {
	"carefully examines the terrain for sign of folk who have passed this way.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_humanoids.Sayings.random, {})     
                                                                
if not RPHelper2DBPC.global.RPEvent.track_undead then RPHelper2DBPC.global.RPEvent.track_undead = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_undead.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_undead.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_undead.Sayings.customemote, {
	"carefully examines the terrain and air for sign of decay and death.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_undead.Sayings.random, {})   
                                                                
if not RPHelper2DBPC.global.RPEvent.track_hidden then RPHelper2DBPC.global.RPEvent.track_hidden = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_hidden.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_hidden.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_hidden.Sayings.customemote, {
	"begins searching the immediate area for sign of lurking presence.",	--mithyk
	"carefully examines the area for indications of concealed lurkers.",	--mithyk
	"searches the shadows and hiding places for creeping ambushers.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_hidden.Sayings.random, {})       
                                                                
--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_elementals.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_elementals.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_elementals.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_elementals.Sayings.random, {})  
                                                                
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_demons.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_demons.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_demons.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_demons.Sayings.random, {})      
                                                                
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_giants.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_giants.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_giants.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_giants.Sayings.random, {})    
                                                                
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_dragonkin.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_dragonkin.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_dragonkin.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.track_dragonkin.Sayings.random, {}) ]]--       

-------------------------------------------------------------------------        
if not RPHelper2DBPC.global.RPEvent.immolation_trap then RPHelper2DBPC.global.RPEvent.immolation_trap = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.immolation_trap.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.immolation_trap.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.immolation_trap.Sayings.customemote, {
	"lays a fire trap.",	--mithyk
	"sets down a fiery surprise for the unwary.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.immolation_trap.Sayings.random, {})     

if not RPHelper2DBPC.global.RPEvent.freezing_trap then RPHelper2DBPC.global.RPEvent.freezing_trap = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.freezing_trap.Sayings, {"Time for someone to chill out."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.freezing_trap.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.freezing_trap.Sayings.customemote, {
	"lays an immobilizing trap.",	--mithyk
	"sets a trap to immobilize the unwary.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.freezing_trap.Sayings.random, {})        

if not RPHelper2DBPC.global.RPEvent.frost_trap then RPHelper2DBPC.global.RPEvent.frost_trap = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_trap.Sayings, {"This should slow things down a bit"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_trap.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_trap.Sayings.customemote, {
	"lays a trap to cripple movement.",	--mithyk
	"sets a trap to hinder the unwary.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_trap.Sayings.random, {})      

if not RPHelper2DBPC.global.RPEvent.explosive_trap then RPHelper2DBPC.global.RPEvent.explosive_trap = {Sayings={}} end
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.explosive_trap.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.explosive_trap.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.explosive_trap.Sayings.customemote, {
	"lays an explosive trap.",	--mithyk
	"carefully sets explosives.",	--mithyk
	"sets down an explosive surprise for the unwary.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.explosive_trap.Sayings.random, {})     

if not RPHelper2DBPC.global.RPEvent.snake_trap then RPHelper2DBPC.global.RPEvent.snake_trap = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.snake_trap.Sayings, {"Who put these mother-freakin' snakes in my mother-freakin' trap?",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.snake_trap.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.snake_trap.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.snake_trap.Sayings.random, {})     

-------------------------------------------------------------------------        

--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.raptor_strike.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.raptor_strike.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.raptor_strike.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.raptor_strike.Sayings.random, {})       

self:JoinArrays(RPHelper2DBPC.global.RPEvent.wing_clip.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.wing_clip.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.wing_clip.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.wing_clip.Sayings.random, {}) ]]--

if not RPHelper2DBPC.global.RPEvent.mongoose_bite then RPHelper2DBPC.global.RPEvent.mongoose_bite = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mongoose_bite.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mongoose_bite.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mongoose_bite.Sayings.customemote, {
	"slips past PP enemy's attack and delivers a powerful counter-blow.",	--mithyk
	"dodges and deliver's a counter-strike.",	--mithyk
	"steps around PP opponent's attack and quickly counters.",	--mithyk
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mongoose_bite.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.counterattack then RPHelper2DBPC.global.RPEvent.counterattack = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.counterattack.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.counterattack.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.counterattack.Sayings.customemote, {
	"parries and delivers a quick counter-strike.",
	"parries the blow and delivers a powerful counter-blow.",
	"parries PP opponent's attack and quickly counters.",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.counterattack.Sayings.random, {})        

if not RPHelper2DBPC.global.RPEvent.feign_death then RPHelper2DBPC.global.RPEvent.feign_death = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feign_death.Sayings, {
	"Shhh! Don't tell them I'm not really dead.",
	"I am struck down!",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feign_death.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feign_death.Sayings.customemote, {
	"feigns PP death.",
	"clutches at PP chest and collapses.",	--mithyk
	"screams in pain and collapses.",	--mithyk
	"stumbles and falls to the ground.",	--mithyk
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.feign_death.Sayings.random, {})        

--[[self:JoinArrays(RPHelper2DBPC.global.RPEvent.wyvern_sting.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.wyvern_sting.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.wyvern_sting.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.wyvern_sting.Sayings.random, {})       ]]--

if not RPHelper2DBPC.global.RPEvent.readiness then RPHelper2DBPC.global.RPEvent.readiness = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.readiness.Sayings, {"Contrary to popular belief, I AM prepared."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.readiness.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.readiness.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.readiness.Sayings.random, {})  

if not RPHelper2DBPC.global.RPEvent.misdirection then RPHelper2DBPC.global.RPEvent.misdirection = {Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.misdirection.Sayings, {"Hey, look over there!", "TSP did it, not me!"})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.misdirection.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.misdirection.Sayings.customemote, {"whistles and points a finger at TARGET."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.misdirection.Sayings.random, {})  

elseif ( myLocale == "deDE") then
if self.HunterDE then self:HunterDE() end
elseif (myLocale == "frFR") then
if self.HunterFR then self:HunterFR() end
elseif (myLocale == "esES") then
if self.HunterES then self:HunterES() end
end
end