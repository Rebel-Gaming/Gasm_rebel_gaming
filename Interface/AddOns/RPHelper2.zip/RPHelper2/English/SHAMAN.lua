--This is the function to add the default Shaman sayings to the user's database.
--Only the ones that already had data have been converted; the rest of it has been
--commented out so I can add stuff later if I feel like it.

function RPHelper2:InitializeSHAMAN(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB" ) then
--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings,{
	"The spirits guide me.",
	"You ever been hit by lightning where the sun don't shine?",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"CHARGE",})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random = {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote = {})            
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random = {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote = {})       
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random = {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote = {}) 
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random = {})
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.emote = {}) 
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.block.Sayings.random = {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random = {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote = {}) 
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random = {})
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.parry.Sayings.random = {})
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random = {})
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random = {})
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youheal.Sayings.random = {})
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.random = {})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT = The text message sent by the NPC.	TEXT = Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC  = Mogg
	-- LANG = The Language              		LANG = Orcish
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random = {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT = The text message sent by the NPC.	TEXT = Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC  = Mogg
	-- LANG = The Language              		LANG = Orcish
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random = {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote = {})  
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random = {})
--=====================================================================--
--  Fear, etc.
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random = {})

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random = {})

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random = {})

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random = {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random = {})

--=====================================================================--
--  Racials
	-- This way you can RP your racial differently as different classes
--=====================================================================--
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.random = {})

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.random = {})

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.blood_fury.Sayings.random = {})

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.war_stomp.Sayings.random = {})

--//////////////////////////////////////////////////////////////////////////--
-- Shaman Spells
--//////////////////////////////////////////////////////////////////////////--
--=====================================================================--
-- Elemental Combat
--=====================================================================-- 
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_shock.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_shock.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_shock.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_shock.Sayings.random = {})
                          
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.flame_shock.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.flame_shock.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.flame_shock.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.flame_shock.Sayings.random = {})  
                          
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_shock.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_shock.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_shock.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_shock.Sayings.random = {})
                    
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.earthbind_totem.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.earthbind_totem.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.earthbind_totem.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.earthbind_totem.Sayings.random = {})    

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneclaw_totem.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneclaw_totem.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneclaw_totem.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneclaw_totem.Sayings.random = {})   

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_nova_totem.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_nova_totem.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_nova_totem.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_nova_totem.Sayings.random = {})     

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.searing_totem.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.searing_totem.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.searing_totem.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.searing_totem.Sayings.random = {})      

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.magma_totem.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.magma_totem.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.magma_totem.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.magma_totem.Sayings.random = {}) 

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightning_bolt.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightning_bolt.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightning_bolt.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightning_bolt.Sayings.random = {})   

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.purge.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.purge.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.purge.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.purge.Sayings.random = {})   

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.elemental_focus.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.elemental_focus.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.elemental_focus.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.elemental_focus.Sayings.random = {})

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.chain_lightning.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.chain_lightning.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.chain_lightning.Sayings.customemote, {"'s fingertips crackle with electricity."})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.chain_lightning.Sayings.random = {})

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.totem_of_wrath.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.totem_of_wrath.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.totem_of_wrath.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.totem_of_wrath.Sayings.random = {}) 

----self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_elemental_totem.Sayings = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_elemental_totem.Sayings.emote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_elemental_totem.Sayings.customemote = {})
----self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_elemental_totem.Sayings.random = {}) 
--=====================================================================--
-- Enhancement
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rockbiter_weapon.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rockbiter_weapon.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rockbiter_weapon.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.rockbiter_weapon.Sayings.random = {})     

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flametongue_weapon.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flametongue_weapon.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flametongue_weapon.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flametongue_weapon.Sayings.random = {})     

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frostbrand_weapon.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frostbrand_weapon.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frostbrand_weapon.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frostbrand_weapon.Sayings.random = {})     

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windfury_weapon.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windfury_weapon.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windfury_weapon.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windfury_weapon.Sayings.random = {})
                                              
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneskin_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneskin_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneskin_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stoneskin_totem.Sayings.random = {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.strength_of_earth_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.strength_of_earth_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.strength_of_earth_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.strength_of_earth_totem.Sayings.random = {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_resistance_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_resistance_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_resistance_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_resistance_totem.Sayings.random = {})  

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_resistance_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_resistance_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_resistance_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_resistance_totem.Sayings.random = {})  

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flametongue_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flametongue_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flametongue_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.flametongue_totem.Sayings.random = {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.grounding_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.grounding_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.grounding_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.grounding_totem.Sayings.random = {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.nature_resistance_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.nature_resistance_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.nature_resistance_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.nature_resistance_totem.Sayings.random = {})  

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windfury_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windfury_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windfury_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windfury_totem.Sayings.random = {})  

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sentry_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sentry_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sentry_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.sentry_totem.Sayings.random = {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windwall_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windwall_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windwall_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.windwall_totem.Sayings.random = {})   

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.grace_of_air_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.grace_of_air_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.grace_of_air_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.grace_of_air_totem.Sayings.random = {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightning_shield.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightning_shield.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightning_shield.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lightning_shield.Sayings.random = {})     

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ghost_wolf.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ghost_wolf.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ghost_wolf.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ghost_wolf.Sayings.random = {})    

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_breathing.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_breathing.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_breathing.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_breathing.Sayings.random = {})  

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.far_sight.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.far_sight.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.far_sight.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.far_sight.Sayings.random = {})        

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_walking.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_walking.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_walking.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_walking.Sayings.random = {})   

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.astral_recall.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.astral_recall.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.astral_recall.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.astral_recall.Sayings.random = {})   

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.elemental_mastery.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.elemental_mastery.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.elemental_mastery.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.elemental_mastery.Sayings.random = {})   

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stormstrike.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stormstrike.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stormstrike.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.stormstrike.Sayings.random = {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heroism.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heroism.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heroism.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.heroism.Sayings.random = {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodlust.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodlust.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodlust.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.bloodlust.Sayings.random = {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_elemental_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_elemental_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_elemental_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_elemental_totem.Sayings.random = {})
--=====================================================================--
-- Restoration
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_wave.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_wave.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_wave.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_wave.Sayings.random = {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lesser_healing_wave.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lesser_healing_wave.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lesser_healing_wave.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.lesser_healing_wave.Sayings.random = {})      

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_poison.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_poison.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_poison.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_poison.Sayings.random = {})     

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_disease.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_disease.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_disease.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.cure_disease.Sayings.random = {})    

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.tremor_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.tremor_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.tremor_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.tremor_totem.Sayings.random = {})  

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.poison_cleansing_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.poison_cleansing_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.poison_cleansing_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.poison_cleansing_totem.Sayings.random = {})   

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_stream_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_stream_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_stream_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.healing_stream_totem.Sayings.random = {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_spring_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_spring_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_spring_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_spring_totem.Sayings.random = {})   

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.disease_cleansing_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.disease_cleansing_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.disease_cleansing_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.disease_cleansing_totem.Sayings.random = {}) 

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tide_totem.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tide_totem.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tide_totem.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tide_totem.Sayings.random = {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ancestral_spirit.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ancestral_spirit.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ancestral_spirit.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.ancestral_spirit.Sayings.random = {})  

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_swiftness.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_swiftness.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_swiftness.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.natures_swiftness.Sayings.random = {})   

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.reincarnation.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.reincarnation.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.reincarnation.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.reincarnation.Sayings.random = {})  

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.chain_heal.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.chain_heal.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.chain_heal.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.chain_heal.Sayings.random = {})

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_shield.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_shield.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_shield.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.earth_shield.Sayings.random = {})  

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_shield.Sayings = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_shield.Sayings.emote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_shield.Sayings.customemote = {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.water_shield.Sayings.random = {})
elseif ( myLocale == "deDE") then
if self.ShamanDE then self:ShamanDE() end
elseif (myLocale == "frFR") then
if self.ShamanFR then self:ShamanFR() end
elseif (myLocale == "esES") then
if self.ShamanES then self:ShamanES() end
end  								
end