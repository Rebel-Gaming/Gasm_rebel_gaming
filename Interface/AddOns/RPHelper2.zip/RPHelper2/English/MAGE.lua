function RPHelper2:InitializeMAGE(myLocale)
if ( myLocale == "enUS" or myLocale == "enGB") then

--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings, {
	"Let's get this over quick; time is mana.",
	"I'm a magic man. I got magic hands.",
	"I do not think you realise the gravity of your situation.",
	"Buckle up... you're going for a ride.",
})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote, {"CHARGE",})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random, {})
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings, {
 	"Some lessons come hard.",
	"Careful. You don't want to risk learning from this.",
})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random, {})
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote, {})
---self:JoinArrays(RPHelper2DBPC.global.RPEvent.hurt.Sayings.random, {})
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the daSayings.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.absorb.Sayings.random, {})
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote, {
--	"I don't remember casting slow on you...",
--})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.dodge.Sayings.random, {})
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.miss.Sayings.random, {})
--=====================================================================--
-- CRIT: You crit daSayings with a physical attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random, {})
--=====================================================================--
-- CRIT (SPELL): You crit daSayings with a spell attack
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random, {})
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME, Pet's Name	
	-- PTNAME, Pet's target's name                           
	-- PTSP, Pet's target's subject pronoun 	(He/She/It)
	-- PTOP, Pet's target's object pronoun 	(him/her/it)
	-- PTPP, Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random, {})
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME, Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random, {})
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random, {})
--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT, The text message sent by the NPC.	TEXT, Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC , Mogg
	-- LANG, The Language              		LANG, Orcish
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random, {})
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random, {})
--=====================================================================--
--  Fear, etc.
--=====================================================================--
--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.feared.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.possession.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.confused.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random, {})

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.silenced.Sayings.random, {})
]]--
--Racials
--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_tap.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_torrent.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.gift_of_the_naaru.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.berserking.Sayings.random, {})


self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cannibalize.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.will_of_the_forsaken.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.perception.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.escape_artist.Sayings.random, {})
]]--
--//////////////////////////////////////////////////////////////////////////--
-- Sayings Spells
--//////////////////////////////////////////////////////////////////////////--
--=====================================================================--
-- Arcane
--=====================================================================--       
if not RPHelper2DBPC.global.RPEvent.arcane_intellect then RPHelper2DBPC.global.RPEvent.arcane_intellect ={Sayings={}} end
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_intellect.Sayings, {"Of all the material components... FOX DUNG? Ugh...", "Be a dunce no longer, TARGET!"})
	--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_intellect.Sayings.emote, {})
	--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_intellect.Sayings.customemote, {})
	--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_intellect.Sayings.random, {}) 

if not RPHelper2DBPC.global.RPEvent.arcane_missiles then RPHelper2DBPC.global.RPEvent.arcane_missiles ={Sayings={}} end 
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_missiles.Sayings, {"I wanna fire magic missiles!", "I fire magic missiles at the DARKNESS! Er, I mean, the TARGET!"})
	--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_missiles.Sayings.customemote, {})
	--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_missiles.Sayings.random, {})
--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorph.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorph.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorph.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.polymorph.Sayings.random, {})  

self:JoinArrays(RPHelper2DBPC.global.RPEvent.dampen_magic.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dampen_magic.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dampen_magic.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dampen_magic.Sayings.random, {})    

self:JoinArrays(RPHelper2DBPC.global.RPEvent.slow_fall.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.slow_fall.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.slow_fall.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.slow_fall.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_explosion.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_explosion.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_explosion.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_explosion.Sayings.random, {})  

self:JoinArrays(RPHelper2DBPC.global.RPEvent.amplify_magic.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.amplify_magic.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.amplify_magic.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.amplify_magic.Sayings.random, {})     

self:JoinArrays(RPHelper2DBPC.global.RPEvent.remove_curse.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.remove_curse.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.remove_curse.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.remove_curse.Sayings.random, {})     

self:JoinArrays(RPHelper2DBPC.global.RPEvent.blink.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.blink.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.blink.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.blink.Sayings.random, {})        

self:JoinArrays(RPHelper2DBPC.global.RPEvent.evocation.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.evocation.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.evocation.Sayings.random, {})        

self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_shield.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_shield.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_shield.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mana_shield.Sayings.random, {})        

self:JoinArrays(RPHelper2DBPC.global.RPEvent.counterspell.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.counterspell.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.counterspell.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.counterspell.Sayings.random, {})      

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.presence_of_mind.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.presence_of_mind.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.presence_of_mind.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.presence_of_mind.Sayings.random, {})     

self:JoinArrays(RPHelper2DBPC.global.RPEvent.mage_armor.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mage_armor.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mage_armor.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.mage_armor.Sayings.random, {})      

--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_power.Sayings, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_power.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_power.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_power.Sayings.random, {})    

self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_brilliance.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_brilliance.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_brilliance.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.arcane_brilliance.Sayings.random, {})   

self:JoinArrays(RPHelper2DBPC.global.RPEvent.slow.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.slow.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.slow.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.slow.Sayings.random, {}) 

self:JoinArrays(RPHelper2DBPC.global.RPEvent.invisibility.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.invisibility.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.invisibility.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.invisibility.Sayings.random, {}) 

self:JoinArrays(RPHelper2DBPC.global.RPEvent.spellsteal.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.spellsteal.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.spellsteal.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.spellsteal.Sayings.random, {}) 
]]--
-------------------------------------------------------------------------    
if not RPHelper2DBPC.global.RPEvent.conjure_water then RPHelper2DBPC.global.RPEvent.conjure_water ={Sayings={}} end
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_water.Sayings, {"Fresh water, not salt water... Fresh water, not salt water..."})
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_water.Sayings.emote, {})
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_water.Sayings.customemote, {})
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_water.Sayings.random, {})
--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_food.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_food.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_food.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_food.Sayings.random, {})
]]--

if not RPHelper2DBPC.global.RPEvent.conjure_mana_gem then RPHelper2DBPC.global.RPEvent.conjure_mana_gem ={Sayings={}} end
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_mana_gem.Sayings, {})
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_mana_gem.Sayings.emote, {})
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_mana_gem.Sayings.customemote, {"creates a pristine gem in PP hand."})
	self:JoinArrays(RPHelper2DBPC.global.RPEvent.conjure_mana_gem.Sayings.random, {})

-------------------------------------------------------------------------
if not RPHelper2DBPC.global.RPEvent.teleport_ironforge then RPHelper2DBPC.global.RPEvent.teleport_ironforge ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_ironforge.Sayings, {"Ironforge, here I come!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_ironforge.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_ironforge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_ironforge.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.teleport_stormwind then RPHelper2DBPC.global.RPEvent.teleport_stormwind ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_stormwind.Sayings, {"Stormwind, here I come!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_stormwind.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_stormwind.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_stormwind.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.teleport_darnassus then RPHelper2DBPC.global.RPEvent.teleport_darnassus ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_darnassus.Sayings, {"Darnassus, here I come!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_darnassus.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_darnassus.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_darnassus.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.teleport_orgrimmar then RPHelper2DBPC.global.RPEvent.teleport_orgrimmar ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_orgrimmar.Sayings, {"Orgrimmar, here I come!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_orgrimmar.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_orgrimmar.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_orgrimmar.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.teleport_undercity then RPHelper2DBPC.global.RPEvent.teleport_undercity ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_undercity.Sayings, {"Undercity, here I come!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_undercity.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_undercity.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_undercity.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.teleport_thunder_bluff then RPHelper2DBPC.global.RPEvent.teleport_thunder_bluff ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_thunder_bluff.Sayings, {"Thunder Bluff, here I come!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_thunder_bluff.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_thunder_bluff.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_thunder_bluff.Sayings.random, {})     

if not RPHelper2DBPC.global.RPEvent.teleport_exodar then RPHelper2DBPC.global.RPEvent.teleport_exodar ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_exodar.Sayings, {"Exodar, here I come!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_exodar.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_exodar.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_exodar.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.teleport_silvermoon then RPHelper2DBPC.global.RPEvent.teleport_silvermoon ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_silvermoon.Sayings, {"Silvermoon, here I come!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_silvermoon.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_silvermoon.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_silvermoon.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.teleport_shattrath then RPHelper2DBPC.global.RPEvent.teleport_shattrath ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_shattrath.Sayings, {"Shattrath, here I come!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_shattrath.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_shattrath.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.teleport_shattrath.Sayings.random, {})
-------------------------------------------------------------------------
if not RPHelper2DBPC.global.RPEvent.portal_ironforge then RPHelper2DBPC.global.RPEvent.portal_ironforge ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_ironforge.Sayings, {"All aboard for Ironforge!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_ironforge.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_ironforge.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_ironforge.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.portal_stormwind then RPHelper2DBPC.global.RPEvent.portal_stormwind ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_stormwind.Sayings, {"All aboard for Stormwind!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_stormwind.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_stormwind.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_stormwind.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.portal_darnassus then RPHelper2DBPC.global.RPEvent.portal_darnassus ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_darnassus.Sayings, {"All aboard for Darnassus!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_darnassus.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_darnassus.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_darnassus.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.portal_orgrimmar then RPHelper2DBPC.global.RPEvent.portal_orgrimmar ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_orgrimmar.Sayings, {"All aboard for Orgrimmar!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_orgrimmar.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_orgrimmar.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_orgrimmar.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.portal_undercity then RPHelper2DBPC.global.RPEvent.portal_undercity ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_undercity.Sayings, {"All aboard for the Undercity!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_undercity.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_undercity.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_undercity.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.portal_thunder_bluff then RPHelper2DBPC.global.RPEvent.portal_thunder_bluff ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_thunder_bluff.Sayings, {"All aboard for Thunder Bluff!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_thunder_bluff.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_thunder_bluff.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_thunder_bluff.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.portal_exodar then RPHelper2DBPC.global.RPEvent.portal_exodar ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_exodar.Sayings, {"All aboard for the Exodar!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_exodar.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_exodar.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_exodar.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.portal_silvermoon then RPHelper2DBPC.global.RPEvent.portal_silvermoon ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_silvermoon.Sayings, {"All aboard for Silvermoon City!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_silvermoon.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_silvermoon.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_silvermoon.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.portal_shattrath then RPHelper2DBPC.global.RPEvent.portal_shattrath ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_shattrath.Sayings, {"All aboard for Shattrath!"})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_shattrath.Sayings.emote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_shattrath.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.portal_shattrath.Sayings.random, {})
--=====================================================================--
-- Frost
--=====================================================================--
--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frostbolt.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frostbolt.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frostbolt.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frostbolt.Sayings.random, {})
                                      
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_armor.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_armor.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_armor.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_armor.Sayings.random, {})    
                                      
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_nova.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_nova.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_nova.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_nova.Sayings.random, {})   
]]--

if not RPHelper2DBPC.global.RPEvent.blizzard then RPHelper2DBPC.global.RPEvent.blizzard ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.blizzard.Sayings, {"Well, the weather outside is frightful...","Just hear those sleigh bells ring-aling, ting-ting-ting-aling too...","When it snows, ain't it thrilling, though your nose gets a chilling..."})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blizzard.Sayings.customemote, {})
--self:JoinArrays(RPHelper2DBPC.global.RPEvent.blizzard.Sayings.random, {})  

--[[                                      
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cold_snap.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cold_snap.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cold_snap.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cold_snap.Sayings.random, {})    
                                      
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_ward.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_ward.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_ward.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.frost_ward.Sayings.random, {})    
                                      
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cone_of_cold.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cone_of_cold.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cone_of_cold.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.cone_of_cold.Sayings.random, {})   
                                      
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_armor.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_armor.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_armor.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_armor.Sayings.random, {})   
                                      
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_block.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_block.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_block.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_block.Sayings.random, {})       
                                      
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_barrier.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_barrier.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_barrier.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_barrier.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_water_elemental.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_water_elemental.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_water_elemental.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.summon_water_elemental.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_lance.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_lance.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_lance.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.ice_lance.Sayings.random, {}) 
]]--
--=====================================================================--
-- Fire
--=====================================================================--   
--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_blast.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_blast.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_blast.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_blast.Sayings.random, {})
]]--
if not RPHelper2DBPC.global.RPEvent.fireball then RPHelper2DBPC.global.RPEvent.fireball ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fireball.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fireball.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fireball.Sayings.customemote, {"hurls a ball of molten flame at TARGET."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fireball.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.flamestrike then RPHelper2DBPC.global.RPEvent.flamestrike ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flamestrike.Sayings, {"We're having a heat wave! A tropical heat wave!",})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flamestrike.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flamestrike.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.flamestrike.Sayings.random, {}) 

if not RPHelper2DBPC.global.RPEvent.fire_ward then RPHelper2DBPC.global.RPEvent.fire_ward ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_ward.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_ward.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_ward.Sayings.customemote, {"weaves a ward against flames."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.fire_ward.Sayings.random, {})

if not RPHelper2DBPC.global.RPEvent.pyroblast then RPHelper2DBPC.global.RPEvent.pyroblast ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.pyroblast.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.pyroblast.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.pyroblast.Sayings.customemote, {"creates a molten boulder - larger than SP is! - and hurls it at TARGET."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.pyroblast.Sayings.random, {})
--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scorch.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scorch.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scorch.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.scorch.Sayings.random, {})  

self:JoinArrays(RPHelper2DBPC.global.RPEvent.blast_wave.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.blast_wave.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.blast_wave.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.blast_wave.Sayings.random, {})
]]--
if not RPHelper2DBPC.global.RPEvent.combustion then RPHelper2DBPC.global.RPEvent.combustion ={Sayings={}} end
self:JoinArrays(RPHelper2DBPC.global.RPEvent.combustion.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.combustion.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.combustion.Sayings.customemote, {"creates an aura of elemental flame.", "emanates heat as SP gains a fiery aura."})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.combustion.Sayings.random, {})
--[[
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dragons_breath.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dragons_breath.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dragons_breath.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.dragons_breath.Sayings.random, {})

self:JoinArrays(RPHelper2DBPC.global.RPEvent.molten_armor.Sayings, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.molten_armor.Sayings.emote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.molten_armor.Sayings.customemote, {})
self:JoinArrays(RPHelper2DBPC.global.RPEvent.molten_armor.Sayings.random, {})
]]--
elseif ( myLocale == "deDE") then
	if self.MageDE then self:MageDE() end
elseif (myLocale == "frFR") then
	if self.MageFR then self:MageFR() end
elseif (myLocale == "esES") then
	if self.MageES then self:MageES() end
end
end