function RPHelper2:InitializeGeneric(myLocale)

if ( myLocale == "enUS" or myLocale == "enGB") then
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Read "How to Customize.txt" to learn how to use this file.
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Contributors to this file:   mithyk, Syrsa

--=====================================================================--
-- When you ENTER COMBAT (when the crossed swords cover your level #)
--=====================================================================--
RPHelper2DBPC.global.RPEvent.entercombat.Sayings = {
    "Fool! You dare assault one of PLAYER_GUILDNAME?",
    "I shall rid SUB_ZONE of your filthy presence!",
	"PLAYER_GUILDNAME is upon you!", --mithyk
	"For the Honor of PLAYER_GUILDNAME!", -- mithyk
}
RPHelper2DBPC.global.RPEvent.entercombat.Sayings.emote = {"CHARGE", "CHARGE", "CHARGE","GOODLUCK SELF","BRANDISH","ENEMY SELF","BADFEELING SELF","GLOWER","SCOFF"}
RPHelper2DBPC.global.RPEvent.entercombat.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.entercombat.Sayings.random = {}
--=====================================================================--
-- When you LEAVE COMBAT (when the crossed swords leave your level #)
--=====================================================================--
RPHelper2DBPC.global.RPEvent.leavecombat.Sayings = {}
RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.emote = {"CHEER SELF","PULSE SELF"}
RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.leavecombat.Sayings.random = {}
--=====================================================================--
--  HURT: when you get HIT & you have LESS HEALTH than the last time you got hit
--=====================================================================--
RPHelper2DBPC.global.RPEvent.hurt.Sayings = {}
RPHelper2DBPC.global.RPEvent.hurt.Sayings.emote = {}
RPHelper2DBPC.global.RPEvent.hurt.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.hurt.Sayings.random = {
	["phrase"] = "BLANK BLANK BLANK BLANK.",
	[1] = {"staggers as","is sent staggering by","reels as","is sent reeling by", "stumbles as", "stumbles, surprised by", "recoils as"},
	[2] = {"a blow","an assault","an attack"},
	[3] = {"strikes","crashes into","that leaves a deep wound in","that leaves a bloody wound in","that tears through muscle and sinew in","that tears through the flesh in"},
	[4] = {"PP shoulder","PP head", "PP neck","PP chest","PP stomach","PP ribcage","PP thigh","PP knee","PP leg","PP ankle","PP foot"},
}
--=====================================================================--
-- ABSORB: Creature or hostile player attacks but you absorb the damage.
-- For example: when a priest shields you.
-- by default your health must be above 70%
--=====================================================================--
RPHelper2DBPC.global.RPEvent.absorb.Sayings = {
	"Didn't even scratch me!",
	"Ha! Completely absorbed that last hit.",
	"Did I just get hit? I didn't feel it...",                          -- mithyk
	}
RPHelper2DBPC.global.RPEvent.absorb.Sayings.emote = {"FAIL","ROLLEYES","SCOFF","SNORT"}
RPHelper2DBPC.global.RPEvent.absorb.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.absorb.Sayings.random = {

	["phrase"] = "BLANK BLANK!",

	[1] = {"I've been struck harder by","That felt like getting hit by","I think I just get hit by","You hit like",},

	[2] = {"a little goblin girl","my grandmother","a strong breeze","my baby sister",},

}

RPHelper2DBPC.global.RPEvent.absorb.Sayings.randomtwo = {

	["phrase"] = "BLANK BLANK!",

	[1] = {"A little goblin girl","My grandmother","A strong breeze","My baby sister",},

	[2] = {"could hit harder than that","hits harder than that","strikes with more force",},

}
--=====================================================================--
-- BLOCK: Creature or hostile player attacks. You block.
-- by default your health must be above 70%
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.block then
	RPHelper2DBPC.global.RPEvent.block.Sayings = {
		"Ha! Blocked it.",
		"That's my shield.",
		"How'd my shield feel?",
		"Haha! Blocked that one!",
		"Blocked that last one.",
		"Are you trying to hit my shield?",
		"This is my shield. There are many like it, but this one is mine.", -- mithyk
		"My shield is my life.",
		"I have a very close friendship with my shield - we watch each other's back.",  -- mithyk
		"What did my shield ever do to deserve a beating like that?",   -- mithyk
		"What did my shield ever do to deserve a beating like that?",   -- deserves twice the chance
		"I just got this shield re-painted!",                           -- mithyk
		"No blow shall pass!",                                         	-- mithyk
	}
	RPHelper2DBPC.global.RPEvent.block.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.block.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.block.Sayings.random = {}
end
--=====================================================================--
-- DODGE: Creature or hostile player attacks. You dodge.
-- by default your health must be above 70%
--=====================================================================--
RPHelper2DBPC.global.RPEvent.dodge.Sayings = {
	"Haha! Dodged that one!",
	"Dodged that last one.",
	"Dodged it easily.",
	"Dodged it. I'm over here now.",
	"Won't catch me standing still.",                   -- mithyk
	"Can't touch this.",                                -- mithyk
	"At least try to hit me.",                          -- mithyk
	"Stop trying to hit me, and HIT ME!",               -- mithyk
	"You attack like a clumsy child, TARGET.",          -- mithyk (modified)
	"You call that an attack?",                         -- mithyk
	"Try swinging the weapon TOWARDS me!",              -- mithyk
	}
RPHelper2DBPC.global.RPEvent.dodge.Sayings.emote = {}
RPHelper2DBPC.global.RPEvent.dodge.Sayings.customemote = {
	"feigns a step to the right, then slides around PP opponent's attack on the left.", --mithyk
}
RPHelper2DBPC.global.RPEvent.dodge.Sayings.random = {}
--=====================================================================--
-- MISS: Creature or hostile player attacks but misses you.
-- by default your health must be above 70%
--=====================================================================--
RPHelper2DBPC.global.RPEvent.miss.Sayings = {
	"Ha! Missed me!",
	"That one breezed right by me.",
	"Isn't the objective supposed to be to hit me?",    -- mithyk
	"When you attack, you're supposed to hit me.",      -- mithyk
	"Hey, you missed me!  I'm over here!"               -- mithyk
	}
RPHelper2DBPC.global.RPEvent.miss.Sayings.emote = {"FAIL","ROLLEYES","SCOFF","SNORT"}
RPHelper2DBPC.global.RPEvent.miss.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.miss.Sayings.random = {}
--=====================================================================--
-- PARRY: Creature or hostile player attacks. You parry.
-- by default your health must be above 70%
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.parry then
	RPHelper2DBPC.global.RPEvent.parry.Sayings = {
		"Ha! Parried it easily.",
		"How'd you like that parry? RINSULT",
		"Intercepted!",                         					-- mithyk
		"That attack was no better than that of a clumsy child.",   -- mithyk
		"You call that an attack?",                                 -- mithyk
		"You'll have to do better than that, TARGET.",
		}
	RPHelper2DBPC.global.RPEvent.parry.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.parry.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.parry.Sayings.random = {}
end
--=====================================================================--
-- CRIT: You crit damage with a physical attack
--=====================================================================--
RPHelper2DBPC.global.RPEvent.youcrit.Sayings = {
    "That looked like it hurt.",
    "Ha! Did that hurt, TARGET?",
    "It seems I hit in a critical spot.",
    "Oh, I'll bet that hurt!",
    "Oh, did that hurt, TARGET? You gonna cry now?",
}
RPHelper2DBPC.global.RPEvent.youcrit.Sayings.emote = {"LAUGH", "SMIRK",}
RPHelper2DBPC.global.RPEvent.youcrit.Sayings.customemote = {"smiles at PP critical hit.",	"smiles at PP handiwork.",
	"smiles as PP opponent's wounds bleed.",
	"smiles at the wound SP inflicted on PP opponent.",}
RPHelper2DBPC.global.RPEvent.youcrit.Sayings.random = {}
--=====================================================================--
-- CRIT (SPELL): You crit damage with a spell attack
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.youcritspell then
	RPHelper2DBPC.global.RPEvent.youcritspell.Sayings = {}
	RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.customemote = {"smiles at PP critical spell strike.",	"smiles at PP handiwork.",
	"smiles as PP opponent's wounds bleed.",
	"smiles at the wound SP inflicted on PP opponent.",}
	RPHelper2DBPC.global.RPEvent.youcritspell.Sayings.random = {}
end
--=====================================================================--
-- HEAL: You heal someone else
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.youheal then
	RPHelper2DBPC.global.RPEvent.youheal.Sayings = {}
	RPHelper2DBPC.global.RPEvent.youheal.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.youheal.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.youheal.Sayings.random = {}
end
--=====================================================================--
-- CRIT HEAL: You critically heal someone else
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.youcritheal then
	RPHelper2DBPC.global.RPEvent.youcritheal.Sayings = {}
	RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.customemote = {"smiles at PP critical heal.",}
	RPHelper2DBPC.global.RPEvent.youcritheal.Sayings.random = {}
end
--=====================================================================--
-- When your PET STARTS ATTACKING.
	-- PNAME = Pet's Name	
	-- PTNAME = Pet's target's name                           
	-- PTSP = Pet's target's subject pronoun 	(He/She/It)
	-- PTOP = Pet's target's object pronoun 	(him/her/it)
	-- PTPP = Pet's target's possessive pronoun (his/her/its)
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.petattackstart then
	RPHelper2DBPC.global.RPEvent.petattackstart.Sayings = {
		"Go PNAME!",		
		"Go get PTOP, PNAME!", 
		"Kill PTOP, PNAME.",
		"Kill PTOP for me, PNAME.",
		"Attack PTOP, PNAME.",
		"Attack PTOP for me, PNAME.",
		"Hurt PTOP, PNAME. Hurt PTOP badly.",
		"Show no mercy, PNAME.",
		"Show PTOP no mercy, PNAME.",
		"Show PTOP the meaning of pain, PNAME.",
		"Could you help me with this one, PNAME?",
		"PTSP needs to die, PNAME.",
		"PTSP's in our way, PNAME.",
		"PNAME!  Hurt PTOP badly.",
		"PNAME!  Attack PTOP.",
		"PNAME!  Kill PTOP.",
		"PNAME!  Go get PTOP.",
		"PNAME!  Show no mercy.",
	}
	RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.emote = {"point","attacktarget",}
	RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.petattackstart.Sayings.random = {}
end
--=====================================================================--
-- When your PET STOPS ATTACKING.
	-- PNAME = Pet's Name
		-- Your pet no longer has a target.
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.petattackstop then
	RPHelper2DBPC.global.RPEvent.petattackstop.Sayings = {
		"Good job, PNAME.",
		"Well done, PNAME.",
		"You're doing well, PNAME.",
		"Stay close to me, PNAME.",
		"You're doing great, PNAME.",
		"Keep it up, PNAME.",
		"Did you have fun, PNAME?",
		"PNAME, you've done well.",
	}
	RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.emote = {"PET PNAME"}
	RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.petattackstop.Sayings.random = {}
end
--=====================================================================--
-- When your PET DIES.
	-- PNAME = Pet's Name
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.petdies then
	RPHelper2DBPC.global.RPEvent.petdies.Sayings = {
		"Noooo!",
		"Dang it.  PNAME died.",
		"PNAME! No!",
		"PNAME!",
		"You killed PNAME!",
		"You killed PNAME! You bastard!",
	}
	RPHelper2DBPC.global.RPEvent.petdies.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.petdies.Sayings.customemote = {"mourns the loss of PNAME.", "cries over PNAME's corpse."}
	RPHelper2DBPC.global.RPEvent.petdies.Sayings.random = {}
end
--=====================================================================--
-- When you talk to an NPC  (A dialogue/merchant/quest/etc. box opens)
--=====================================================================--
-------------------------------------------------------------------------
-- The BEGINNING of a conversation with an NPC
	-- "CURTSEY" is automatically added for female characters
	-- "KNEEL" is automatically added if the NPC is 5 levels higher than you
-------------------------------------------------------------------------
RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings = {}
RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings.emote = { "TALK", "TALKEX", "BOW", "GREET", "HAIL", "HELLO", "SALUTE", }
RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.talktonpc_beginning.Sayings.random = {} 
-------------------------------------------------------------------------
-- The MIDDLE of a conversation with an NPC
-------------------------------------------------------------------------
RPHelper2DBPC.global.RPEvent.talktonpc_middle.Sayings = {}
RPHelper2DBPC.global.RPEvent.talktonpc_middle.Sayings.emote = { "TALKEX", "TALKQ", "LISTEN", }
RPHelper2DBPC.global.RPEvent.talktonpc_middle.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.talktonpc_middle.Sayings.random = {}
-------------------------------------------------------------------------
-- The END of a conversation with an NPC 
	-- "CURTSEY" is automatically added for female characters
-------------------------------------------------------------------------
RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings = {}
RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings.emote = { "BOW", "BYE", "THANK", }
RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.talktonpc_end.Sayings.random = {}
--=====================================================================--
--  Friendly NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT = The text message sent by the NPC.	TEXT = Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC  = Mogg
	-- LANG = The Language              		LANG = Orcish
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.npctalksfriend then
	RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings = {}
	RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.npctalksfriend.Sayings.random = {}
end

--=====================================================================--
--  Enemy NPC talks
	-- Usage                                    Example
	-- -----                                    -------
	-- TEXT = The text message sent by the NPC.	TEXT = Now to find an unsuspecting Harpy!
	-- NPC 	= The NPC saying it.        		NPC  = Mogg
	-- LANG = The Language              		LANG = Orcish
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.npctalksenemy then
	RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings = {}
	RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.npctalksenemy.Sayings.random = {}
end
--=====================================================================--
--  RESURRECT:  When you resurrect
	-- If you are dead when the UI (User Interface) loads, you will not RP.
--=====================================================================--
RPHelper2DBPC.global.RPEvent.resurrect.Sayings = {
	"I'm alive!",
	"Huh? Wha? How'd I get here?",
	"I'm not dead yet! I feel happy!"
	}
RPHelper2DBPC.global.RPEvent.resurrect.Sayings.emote = {"PULSE SELF"}
RPHelper2DBPC.global.RPEvent.resurrect.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.resurrect.Sayings.random = {}
--=====================================================================--
--  Camp  (When you type /camp)
--=====================================================================--
RPHelper2DBPC.global.RPEvent.player_camping.Sayings = {}
RPHelper2DBPC.global.RPEvent.player_camping.Sayings.emote = {}
RPHelper2DBPC.global.RPEvent.player_camping.Sayings.customemote = {
    "looks around for a good place to go to sleep.",
    "thinks SP'll camp here for now.",
    "clears the area and sets up camp.",
    "decides SP needs rest and sets PP camp.", --duerma, fixed by mithyk
	"lays out PP bedroll.",	--mithyk
	"prepares for sleep.",	--mithyk
}
RPHelper2DBPC.global.RPEvent.player_camping.Sayings.random = {}
--=====================================================================--
--  You Level up
	-- the keyword LEVEL will be replaced with your new level number
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.player_level_up then
	RPHelper2DBPC.global.RPEvent.player_level_up.Sayings = {	--All of these are from mithyk.
		"All my life I have been coasting along as if I were in a dream. Suddenly, facing the trials of the last few days, I have come alive! ((Levelled!))",
		"I think I'm catching on to the secrets of success! ((Levelled!))",
		"It's all suddenly obvious. All the energy and time I've wasted -- it's a crime. But without the experience I've gained, taking risks, taking responsibility for failure, how could I have understood? ((Levelled!))",
		"Everything I do seems just a bit easier, more instinctive, more satisfying. It is as though I have suddenly developed keener senses and instincts! ((Levelled!))",
		"I feel more aware, more open to new ideas. I've learned a lot lately. It's hard to believe how much I had to learn. ((Levelled!))",
		"I've come far, but I'm determined to keep pushing myself. Perhaps there's more to learn! ((Levelled!))",
		"The secret to growth seems to be hard work, but also a kind of blind passion, an inspiration! ((Levelled!))",
		"Experience comes hard. The key is patience and hard work. And when it pays off like this, it's SWEET! ((Levelled!))",
		"It's the most amazing thing. Yesterday it was hard, and today it is easy! ((Levelled!))",
		"It's the most amazing thing. Yesterday's mysteries are today's masteries! ((Levelled!))",
		"I am filled with energy and ideas. Somehow, everything has changed! ((Levelled!))",
		"The results of hard work and dedication always look like luck to saps. But I've earned every bit of my experience! ((Levelled!))",
	}
	RPHelper2DBPC.global.RPEvent.player_level_up.Sayings.emote = {"CHEER SELF","DING SELF"}
	RPHelper2DBPC.global.RPEvent.player_level_up.Sayings.customemote = {"cheers!  SP now has the experience of LEVEL seasons behind OP.  Yay!"}
	RPHelper2DBPC.global.RPEvent.player_level_up.Sayings.random = {}
end
--=====================================================================--
--  Trade Window Opens
--=====================================================================--
RPHelper2DBPC.global.RPEvent.trade_show.Sayings = {}
RPHelper2DBPC.global.RPEvent.trade_show.Sayings.emote = {"GREET"}
RPHelper2DBPC.global.RPEvent.trade_show.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.trade_show.Sayings.random = {}

--=====================================================================--
--  Trade Window Closes
--=====================================================================--
RPHelper2DBPC.global.RPEvent.trade_closed.Sayings = {}
RPHelper2DBPC.global.RPEvent.trade_closed.Sayings.emote = {"THANK"}
RPHelper2DBPC.global.RPEvent.trade_closed.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.trade_closed.Sayings.random = {}

-- MONSTER EMOTES
-- calls for help
if RPHelper2DBPC.global.RPEvent.monster_emote_help then
	RPHelper2DBPC.global.RPEvent.monster_emote_help.Sayings = {"Calling for help? I don't think so.", "It's too late for you now."}
	RPHelper2DBPC.global.RPEvent.monster_emote_help.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.monster_emote_help.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.monster_emote_help.Sayings.random = {}
end
-- runs in fear
if RPHelper2DBPC.global.RPEvent.monster_emote_fear then
	RPHelper2DBPC.global.RPEvent.monster_emote_fear.Sayings = {
	    "Run away, coward!",
    	"Come back here, you coward!",
	    "TARGET, you coward!",
	    "TSP buggered off!",	--duerma
	    "TARGET, run away coward!",	--mithyk
	    "TARGET, where do you think you're going?",	--mithyk
	    "TARGET, come back here!",	--mithyk
	    "Come back here TARGET",	--mithyk
	    "If you run, you�ll only die tired.",	--mithyk
	    "If you scream, you�ll only die hoarse.",	--mithyk
	    "I hate it when they die smelly.",	--mithyk
	    "It�s almost a disgrace to sully myself with your blood.",	--mithyk
	    "You will not escape!",	--mithyk
    }
	RPHelper2DBPC.global.RPEvent.monster_emote_fear.Sayings.emote = {"CHICKEN"}
	RPHelper2DBPC.global.RPEvent.monster_emote_fear.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.monster_emote_fear.Sayings.random = {}
end

-- becomes enraged
if RPHelper2DBPC.global.RPEvent.monster_emote_enrage then
	RPHelper2DBPC.global.RPEvent.monster_emote_enrage.Sayings = {"Enraged? Oh, I'm soooo scared!"}
	RPHelper2DBPC.global.RPEvent.monster_emote_enrage.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.monster_emote_enrage.Sayings.customemote = {"shakes in PP boots."}
	RPHelper2DBPC.global.RPEvent.monster_emote_enrage.Sayings.random = {}
end
--=====================================================================--
--  Mounting
--=====================================================================--
RPHelper2DBPC.global.RPEvent.mount.Sayings = {
	"Ride to victory!", --mithyk
	"Born to ride.", --mithyk
	"I don't use a lance a lot.", --mithyk
	}
RPHelper2DBPC.global.RPEvent.mount.Sayings.emote = {}
RPHelper2DBPC.global.RPEvent.mount.Sayings.customemote = { 
    "mounts up.",
    "calls for PP MOUNT.",
    "whistles for PP MOUNT.",
    "jumps on PP MOUNT and prepares to ride into battle.",
    "summons PP faithful MOUNT.",
    }
RPHelper2DBPC.global.RPEvent.mount.Sayings.random = {}
--=====================================================================--
--  Learn new ability
--=====================================================================--
RPHelper2DBPC.global.RPEvent.learn.Sayings = {}
RPHelper2DBPC.global.RPEvent.learn.Sayings.emote = {"SMILE", "SMILE SELF", "CHEER",}
RPHelper2DBPC.global.RPEvent.learn.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.learn.Sayings.random = {}
--=====================================================================--
--  Drink alcoholic beverage
--=====================================================================--
RPHelper2DBPC.global.RPEvent.drunk.Sayings = {"That's some good stuff!"}
RPHelper2DBPC.global.RPEvent.drunk.Sayings.emote = {"GIGGLE", "GIGGLE SELF", "LAUGH", "LAUGH SELF"}
RPHelper2DBPC.global.RPEvent.drunk.Sayings.customemote = {}
RPHelper2DBPC.global.RPEvent.drunk.Sayings.random = {}

RPHelper2DBPC.global.RPEvent.sober.Sayings = {}
RPHelper2DBPC.global.RPEvent.sober.Sayings.emote = {}
RPHelper2DBPC.global.RPEvent.sober.Sayings.customemote = {
    "sees clearly now.",
    "can walk a straight line now.",
    }
RPHelper2DBPC.global.RPEvent.sober.Sayings.random = {}
--=====================================================================--
--  You fall and take damage
--=====================================================================--
RPHelper2DBPC.global.RPEvent.fall.Sayings = {"Oof!", "That last step was a doozy!"}
RPHelper2DBPC.global.RPEvent.fall.Sayings.emote = {}
RPHelper2DBPC.global.RPEvent.fall.Sayings.customemote = {"'s knees buckle from the fall."}
RPHelper2DBPC.global.RPEvent.fall.Sayings.random = {}
--=====================================================================--
--  You are drowning
--=====================================================================--
RPHelper2DBPC.global.RPEvent.drowning.Sayings = {"Air! I need air!"}
RPHelper2DBPC.global.RPEvent.drowning.Sayings.emote = {}
RPHelper2DBPC.global.RPEvent.drowning.Sayings.customemote = {
    "needs air!",
    "panics as water enters PP lungs, and SP swims for the surface.",
    }
RPHelper2DBPC.global.RPEvent.drowning.Sayings.random = {}
--=====================================================================--
--  You set a new home (Hearthstone bind location)
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.new_home then
	RPHelper2DBPC.global.RPEvent.new_home.Sayings = {}
	RPHelper2DBPC.global.RPEvent.new_home.Sayings.emote = {"THANK"}
	RPHelper2DBPC.global.RPEvent.new_home.Sayings.customemote = {"hopes to enjoy PP new home in HOME."}
	RPHelper2DBPC.global.RPEvent.new_home.Sayings.random = {}
end
--=====================================================================--
--  You zone into your home (Hearthstone bind location)
--=====================================================================--
RPHelper2DBPC.global.RPEvent.welcome_home.Sayings = {}
RPHelper2DBPC.global.RPEvent.welcome_home.Sayings.emote = {}
RPHelper2DBPC.global.RPEvent.welcome_home.Sayings.customemote = {"is glad to be in HOME once more."}
RPHelper2DBPC.global.RPEvent.welcome_home.Sayings.random = {}
--=====================================================================--
--  Exhausted (you lose rest bonus)
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.exhausted then
	RPHelper2DBPC.global.RPEvent.exhausted.Sayings = {}
	RPHelper2DBPC.global.RPEvent.exhausted.Sayings.emote = {"SIGH","YAWN"}
	RPHelper2DBPC.global.RPEvent.exhausted.Sayings.customemote = {"sighs and looks forward to getting more rest."}
	RPHelper2DBPC.global.RPEvent.exhausted.Sayings.random = {}
end
--=====================================================================--
--  Battlegrounds Events
--=====================================================================--
-- Battle Begins!
--RPHelper2DBPC.global.RPEvent.bg_begin.Sayings = {"For the BGFG!"}
--RPHelper2DBPC.global.RPEvent.bg_begin.Sayings.emote = {"charge"}
--RPHelper2DBPC.global.RPEvent.bg_begin.Sayings.customemote = {"charges into battle in the name of the BGFG."}
--RPHelper2DBPC.global.RPEvent.bg_begin.Sayings.random = {}
--RPHelper2DBPC.global.RPEvent.bg_begin.alias = "Battleground begins"
--RPHelper2DBPC.global.RPEvent.bg_begin.type = "event"
--=====================================================================--
--  Hearthstone
--=====================================================================--
RPHelper2DBPC.global.RPEvent.hearthstone.Sayings = {"Off to HOME I go!", "I'm headed home to HOME."}
RPHelper2DBPC.global.RPEvent.hearthstone.Sayings.emote = {"BYE"}
RPHelper2DBPC.global.RPEvent.hearthstone.Sayings.customemote = {"holds PP hearthstone, thinking of HOME.","visualizes HOME and concentrates on PP hearthstone."}
RPHelper2DBPC.global.RPEvent.hearthstone.Sayings.random = {}
--=====================================================================--
--  Fear, etc.
--=====================================================================--
RPHelper2DBPC.global.RPEvent.feared.Sayings = {
"DAAAAAAAAAAAAAAAAH!", 	--duerma
"Run away! Run away!",	--duerma
"Would it help to confuse it if we run away more?",	--duerma
"I think I need to change my armor...",	--duerma
"When danger reared its ugly head, I bravely turned my tail and fled.",	--duerma
"Bravely taking to PP feet, SP beat a very brave retreat.", 	--duerma
"And gallantly I chickened out...",	--duerma
}
RPHelper2DBPC.global.RPEvent.feared.Sayings.random = {}

RPHelper2DBPC.global.RPEvent.possession.Sayings = {
"CURSE MY SUDDEN BUT INEVITABLE BETRAYAL!",	--duerma
"Mwahaha, mine is an evil laugh!",	--duerma
"Ack, I'm sorry, I can't help it!",	--duerma
}
RPHelper2DBPC.global.RPEvent.possession.Sayings.random = {}

RPHelper2DBPC.global.RPEvent.confused.Sayings = {"Huh? What? Where am I?","What's going on?","I'm so confused!"}
RPHelper2DBPC.global.RPEvent.confused.Sayings.random = {}

RPHelper2DBPC.global.RPEvent.polymorphed.Sayings = {"Polymorphed."}
RPHelper2DBPC.global.RPEvent.polymorphed.Sayings.random = {}

--Of these events, "Silenced" is the only one that lets you emote while afflicted.
if RPHelper2DBPC.global.RPEvent.silenced then
	RPHelper2DBPC.global.RPEvent.silenced.Sayings = {} --Theoretically, you shouldn't be able to talk while silenced, but this is still there if you want to make an OOC comment.
	RPHelper2DBPC.global.RPEvent.silenced.Sayings.emote = {"PANIC"}
	RPHelper2DBPC.global.RPEvent.silenced.Sayings.customemote = {"makes some frantic gestures.","opens and closes PP mouth but no sound comes out."}
	RPHelper2DBPC.global.RPEvent.silenced.Sayings.random = {}
end


--=====================================================================--
--  Professions
--=====================================================================--
if RPHelper2DBPC.global.RPEvent.find_herbs then
	RPHelper2DBPC.global.RPEvent.find_herbs.Sayings = {}
	RPHelper2DBPC.global.RPEvent.find_herbs.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.find_herbs.Sayings.customemote = {"sniffs the air for nearby herb bushes."}
	RPHelper2DBPC.global.RPEvent.find_herbs.Sayings.random = {}
end

if RPHelper2DBPC.global.RPEvent.find_minerals then
	RPHelper2DBPC.global.RPEvent.find_minerals.Sayings = {}
	RPHelper2DBPC.global.RPEvent.find_minerals.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.find_minerals.Sayings.customemote = {"glances around carefully for any nearby mineral veins."}
	RPHelper2DBPC.global.RPEvent.find_minerals.Sayings.random = {}
end

if RPHelper2DBPC.global.RPEvent.fishing then
	RPHelper2DBPC.global.RPEvent.fishing.Sayings = {}
	RPHelper2DBPC.global.RPEvent.fishing.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.fishing.Sayings.customemote = {"casts PP line into the water."}
	RPHelper2DBPC.global.RPEvent.fishing.Sayings.random = {}
end

if RPHelper2DBPC.global.RPEvent.basic_campfire then
	RPHelper2DBPC.global.RPEvent.basic_campfire.Sayings = {}
	RPHelper2DBPC.global.RPEvent.basic_campfire.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.basic_campfire.Sayings.customemote = {"carefully stacks a few logs and lights a cozy fire."}
	RPHelper2DBPC.global.RPEvent.basic_campfire.Sayings.random = {}
end

--These spells will be a bit tricky because the item being targetted is not seen by the normal
--targetting system (ie, the gear icon, or an item in your inventory).
--Future functionality will be added - for now, you can try adding emotes and see what happens. ;)

if RPHelper2DBPC.global.RPEvent.herb_gathering then
	RPHelper2DBPC.global.RPEvent.herb_gathering.Sayings = {}
	RPHelper2DBPC.global.RPEvent.herb_gathering.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.herb_gathering.Sayings.customemote = {"carefullly gathers the TARGET."}
	RPHelper2DBPC.global.RPEvent.herb_gathering.Sayings.random = {}
end

if RPHelper2DBPC.global.RPEvent.mining then
	RPHelper2DBPC.global.RPEvent.mining.Sayings = {}
	RPHelper2DBPC.global.RPEvent.mining.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.mining.Sayings.customemote = {"swings PP pick with gusto."}
	RPHelper2DBPC.global.RPEvent.mining.Sayings.random = {}
end

if RPHelper2DBPC.global.RPEvent.skinning then
	RPHelper2DBPC.global.RPEvent.skinning.Sayings = {}
	RPHelper2DBPC.global.RPEvent.skinning.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.skinning.Sayings.customemote = {"brandishes PP knife and defly removes TARGET's skin."}
	RPHelper2DBPC.global.RPEvent.skinning.Sayings.random = {}
end

if RPHelper2DBPC.global.RPEvent.prospecting then
	RPHelper2DBPC.global.RPEvent.prospecting.Sayings = {"C'mon, big money!"}
	RPHelper2DBPC.global.RPEvent.prospecting.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.prospecting.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.prospecting.Sayings.random = {}
end
if RPHelper2DBPC.global.RPEvent.disenchant then
	RPHelper2DBPC.global.RPEvent.disenchant.Sayings = {}
	RPHelper2DBPC.global.RPEvent.disenchant.Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent.disenchant.Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent.disenchant.Sayings.random = {}
end

elseif ( myLocale == "deDE") then
if self.AnyDE then self:AnyDE() end
elseif (myLocale == "frFR") then
if self.AnyFR then self:AnyFR() end
elseif (myLocale == "esES") then
if self.AnyES then self:AnyES() end
end
end