local playerRace, englishRace = UnitRace("player");
local playerClass, englishClass = UnitClass("player");

---------------------------
-- Initializing the database to store emotes & sayings
---------------------------
function RPHelper2:InitializeSayings()
	RPHelper2DBPC.global.isEnabled = true
	RPHelper2DBPC.global.RPLang = 0
	RPHelper2DBPC.global.mounts= {}
	RPHelper2DBPC.global.RPEvent = {}
	--self.db:RegisterDefaults(defaults)
	--self.DBdefaults = true
	self:defineEvents()
	self:InitializeGeneric(GetLocale())
--We have to run a different function for each race and class; using assert/loadstring means we don't have
--to have ginormous if blocks.
	local RaceInitialize = "RPHelper2:Initialize"..strupper(englishRace).."('"..GetLocale().."')"
	assert(loadstring(RaceInitialize))()
	local classInitialize="RPHelper2:Initialize"..englishClass.."('"..GetLocale().."')"
	assert(loadstring(classInitialize))()
	self:InitializeInsults(GetLocale(), englishRace, englishClass)
	for k,v in pairs(RPHelper2DBPC.global.RPEvent) do
		self:setChance(k, 0.1)
		self:setDelay(k, 8)
	end
end


function RPHelper2:getDelay(eventName)
	if not RPHelper2DBPC.global.RPEvent[eventName] then
		return 0
	end
	if not RPHelper2DBPC.global.RPEvent[eventName]["Delay"] then
		RPHelper2DBPC.global.RPEvent[eventName]["Delay"] = self:getGlobalDelay()
	end
	return RPHelper2DBPC.global.RPEvent[eventName]["Delay"]
end

function RPHelper2:setDelay(eventName, newValue)
	RPHelper2DBPC.global.RPEvent[eventName]["Delay"] = newValue
end

function RPHelper2:getChance(eventName)
	if not RPHelper2DBPC.global.RPEvent[eventName] then
		return 0
	end
	if not RPHelper2DBPC.global.RPEvent[eventName]["Chance"] then
			RPHelper2DBPC.global.RPEvent[eventName]["Chance"] = self:getGlobalChance()
	end
	return RPHelper2DBPC.global.RPEvent[eventName]["Chance"]
end

function RPHelper2:setChance(eventName, newValue)
	RPHelper2DBPC.global.RPEvent[eventName]["Chance"] = newValue
end

function RPHelper2:getGlobalDelay()
	if RPHelper2DBPC.global.globalDelay then
		return RPHelper2DBPC.global.globalDelay
	else
		return 8
	end
end

function RPHelper2:getGlobalChance()
	if RPHelper2DBPC.global.globalChance then
		return RPHelper2DBPC.global.globalChance
	else
		return 0.1
	end
end

function RPHelper2:defineEvents()
if not RPHelper2DBPC.global.RPEvent then RPHelper2DBPC.global.RPEvent = {} end
--In a seperate file so we make sure new events are caught by older users.
local eventList = {"entercombat","leavecombat", "hurt", "absorb", "block", "dodge", "miss","parry","youcrit","youcritspell","youheal",
		"youcritheal","petattackstart","petattackstop","petdies","talktonpc_beginning","talktonpc_middle","talktonpc_end",
		"resurrect","player_camping","player_level_up", "trade_show","trade_closed","mount","learn","drunk","sober",
		"fall","drowning","welcome_home","exhausted","hearthstone","feared","possession","confused","polymorphed","silenced",
		"low_mana","mail_open","mail_send","mail_closed","bank_open","bank_closed","guildbank_open","guildbank_closed",
		"loot_open","loot_closed","loot_money", "gain_aggro","lose_aggro","vehicle_enter","vehicle_exit",
		"monster_emote_enrage","monster_emote_fear","noncompet"--"ping"
		}

for k,v in ipairs(eventList) do
if not RPHelper2DBPC.global.RPEvent[v] then
	RPHelper2DBPC.global.RPEvent[v] = {}
	RPHelper2DBPC.global.RPEvent[v].Sayings = {}
	RPHelper2DBPC.global.RPEvent[v].Sayings.emote = {}
	RPHelper2DBPC.global.RPEvent[v].Sayings.customemote = {}
	RPHelper2DBPC.global.RPEvent[v].category = ""
	RPHelper2DBPC.global.RPEvent[v].Chance = .1
	RPHelper2DBPC.global.RPEvent[v].Delay = 8
end
if not RPHelper2DBPC.global.RPEvent[v].type then RPHelper2DBPC.global.RPEvent[v].type = "event" end
end

--Backwards compatibility
if RPHelper2DBPC.global.RPEvent["find_herbs"] then RPHelper2DBPC.global.RPEvent["find_herbs"].type=nil end
if RPHelper2DBPC.global.RPEvent["find_minerals"] then RPHelper2DBPC.global.RPEvent["find_minerals"].type=nil end
if RPHelper2DBPC.global.RPEvent["fishing"] then RPHelper2DBPC.global.RPEvent["fishing"].type=nil end
if RPHelper2DBPC.global.RPEvent["basic_campfire"] then RPHelper2DBPC.global.RPEvent["basic_campfire"].type=nil end
if RPHelper2DBPC.global.RPEvent["herb_gathering"] then RPHelper2DBPC.global.RPEvent["herb_gathering"].type=nil end
if RPHelper2DBPC.global.RPEvent["mining"] then RPHelper2DBPC.global.RPEvent["mining"].type=nil end
if RPHelper2DBPC.global.RPEvent["skinning"] then RPHelper2DBPC.global.RPEvent["skinning"].type=nil end
if RPHelper2DBPC.global.RPEvent["prospecting"] then RPHelper2DBPC.global.RPEvent["prospecting"].type=nil end
if RPHelper2DBPC.global.RPEvent["disenchant"] then RPHelper2DBPC.global.RPEvent["disenchant"].type=nil end

--Combat
RPHelper2DBPC.global.RPEvent.entercombat.alias = "You enter combat"
RPHelper2DBPC.global.RPEvent.leavecombat.alias = "You leave combat"
RPHelper2DBPC.global.RPEvent.hurt.alias = "You are hurt"
RPHelper2DBPC.global.RPEvent.absorb.alias = "You absorb an attack"
RPHelper2DBPC.global.RPEvent.block.alias = "You block an attack"
RPHelper2DBPC.global.RPEvent.dodge.alias = "You dodge an attack"
RPHelper2DBPC.global.RPEvent.miss.alias = "Your attacker swings and misses"
RPHelper2DBPC.global.RPEvent.parry.alias = "You parry an attack"
RPHelper2DBPC.global.RPEvent.youcrit.alias = "You crit (physical)"
RPHelper2DBPC.global.RPEvent.youcritspell.alias = "You crit (spell)"
RPHelper2DBPC.global.RPEvent.youheal.alias = "You heal someone"
RPHelper2DBPC.global.RPEvent.youcritheal.alias = "You crit heal"
RPHelper2DBPC.global.RPEvent.low_mana.alias = "Low Mana"
--RPHelper2DBPC.global.RPEvent.monster_emote_help.alias = "Monster emote: Help"
RPHelper2DBPC.global.RPEvent.monster_emote_fear.alias = "Monster emote: Fear"
RPHelper2DBPC.global.RPEvent.monster_emote_enrage.alias = "Monster emote: Enrage"
RPHelper2DBPC.global.RPEvent.entercombat.category = COMBAT
RPHelper2DBPC.global.RPEvent.leavecombat.category = COMBAT
RPHelper2DBPC.global.RPEvent.hurt.category = COMBAT
RPHelper2DBPC.global.RPEvent.absorb.category = COMBAT
RPHelper2DBPC.global.RPEvent.block.category = COMBAT
RPHelper2DBPC.global.RPEvent.dodge.category = COMBAT
RPHelper2DBPC.global.RPEvent.miss.category = COMBAT
RPHelper2DBPC.global.RPEvent.parry.category = COMBAT
RPHelper2DBPC.global.RPEvent.youcrit.category = COMBAT
RPHelper2DBPC.global.RPEvent.youcritspell.category = COMBAT
RPHelper2DBPC.global.RPEvent.youheal.category = COMBAT
RPHelper2DBPC.global.RPEvent.youcritheal.category = COMBAT
RPHelper2DBPC.global.RPEvent.low_mana.category = COMBAT
RPHelper2DBPC.global.RPEvent.gain_aggro.category = COMBAT
RPHelper2DBPC.global.RPEvent.gain_aggro.alias = "You gain aggro"
RPHelper2DBPC.global.RPEvent.lose_aggro.category = COMBAT
RPHelper2DBPC.global.RPEvent.lose_aggro.alias = "You lose aggro"
--RPHelper2DBPC.global.RPEvent.monster_emote_help.category = COMBAT
RPHelper2DBPC.global.RPEvent.monster_emote_fear.category = COMBAT
RPHelper2DBPC.global.RPEvent.monster_emote_enrage.category = COMBAT
--Pet
RPHelper2DBPC.global.RPEvent.petattackstart.alias = "Pet attack start"
RPHelper2DBPC.global.RPEvent.petattackstop.alias = "Pet attack stop"
RPHelper2DBPC.global.RPEvent.petdies.alias = "Pet dies"
RPHelper2DBPC.global.RPEvent.petattackstart.category = UNIT_NAME_FRIENDLY_PETS
RPHelper2DBPC.global.RPEvent.petattackstop.category = UNIT_NAME_FRIENDLY_PETS
RPHelper2DBPC.global.RPEvent.petdies.category = UNIT_NAME_FRIENDLY_PETS
RPHelper2DBPC.global.RPEvent.noncompet.alias = "You summon a non-combat pet"
RPHelper2DBPC.global.RPEvent.noncompet.category = UNIT_NAME_FRIENDLY_PETS
--NPC
RPHelper2DBPC.global.RPEvent.talktonpc_beginning.alias = "Talk to NPC (beginning)"
RPHelper2DBPC.global.RPEvent.talktonpc_middle.alias = "Talk to NPC (middle)"
RPHelper2DBPC.global.RPEvent.talktonpc_end.alias = "Talk to NPC (end)"
--RPHelper2DBPC.global.RPEvent.npctalksfriend.alias = "Friendly NPC talks"
--RPHelper2DBPC.global.RPEvent.npctalksenemy.alias = "Enemy NPC talks"
RPHelper2DBPC.global.RPEvent.talktonpc_beginning.category = "NPC"
RPHelper2DBPC.global.RPEvent.talktonpc_middle.category = "NPC"
RPHelper2DBPC.global.RPEvent.talktonpc_end.category = "NPC"
--RPHelper2DBPC.global.RPEvent.npctalksfriend.category = "NPC"
--RPHelper2DBPC.global.RPEvent.npctalksenemy.category = "NPC"
RPHelper2DBPC.global.RPEvent.bank_open.alias = "Open bank window"
RPHelper2DBPC.global.RPEvent.bank_closed.alias = "Close bank window"
RPHelper2DBPC.global.RPEvent.guildbank_open.alias = "Open guild bank"
RPHelper2DBPC.global.RPEvent.guildbank_closed.alias = "Close guild bank"
RPHelper2DBPC.global.RPEvent.bank_open.category = "NPC"
RPHelper2DBPC.global.RPEvent.bank_closed.category = "NPC"
RPHelper2DBPC.global.RPEvent.guildbank_open.category = "NPC"
RPHelper2DBPC.global.RPEvent.guildbank_closed.category = "NPC"
--General
RPHelper2DBPC.global.RPEvent.resurrect.alias = "Resurrect"
RPHelper2DBPC.global.RPEvent.player_camping.alias = "You camp"
RPHelper2DBPC.global.RPEvent.player_level_up.alias = "You gain a level"
RPHelper2DBPC.global.RPEvent.trade_show.alias = "Trade window opens"
RPHelper2DBPC.global.RPEvent.trade_closed.alias = "Trade window closes"
RPHelper2DBPC.global.RPEvent.mount.alias = "You mount"
RPHelper2DBPC.global.RPEvent.learn.alias = "You learn something"
RPHelper2DBPC.global.RPEvent.drunk.alias = "You are drunk"
RPHelper2DBPC.global.RPEvent.sober.alias = "You are sober"
RPHelper2DBPC.global.RPEvent.fall.alias = "You fall"
RPHelper2DBPC.global.RPEvent.drowning.alias = "You are drowning"
RPHelper2DBPC.global.RPEvent.welcome_home.alias = "You arrive home"
RPHelper2DBPC.global.RPEvent.exhausted.alias = "You lose rest bonus"
RPHelper2DBPC.global.RPEvent.hearthstone.alias = "Hearthstone"
--RPHelper2DBPC.global.RPEvent.ping.alias = "A player pings the map"
--Crowd control
RPHelper2DBPC.global.RPEvent.feared.alias = "You are feared"
RPHelper2DBPC.global.RPEvent.possession.alias = "You are mind controlled"
RPHelper2DBPC.global.RPEvent.confused.alias = "You are confused"
RPHelper2DBPC.global.RPEvent.polymorphed.alias = "You are polymorphed"
RPHelper2DBPC.global.RPEvent.silenced.alias = "You are silenced"
RPHelper2DBPC.global.RPEvent.feared.category = "Crowd Control"
RPHelper2DBPC.global.RPEvent.possession.category = "Crowd Control"
RPHelper2DBPC.global.RPEvent.confused.category = "Crowd Control"
RPHelper2DBPC.global.RPEvent.polymorphed.category = "Crowd Control"
RPHelper2DBPC.global.RPEvent.silenced.category = "Crowd Control"
--Mail
RPHelper2DBPC.global.RPEvent.mail_open.alias = "Mail open"
RPHelper2DBPC.global.RPEvent.mail_send.alias = "Mail send"
RPHelper2DBPC.global.RPEvent.mail_closed.alias = "Mail closed"
RPHelper2DBPC.global.RPEvent.mail_open.category = MAIL_LABEL
RPHelper2DBPC.global.RPEvent.mail_send.category = MAIL_LABEL
RPHelper2DBPC.global.RPEvent.mail_closed.category = MAIL_LABEL
RPHelper2DBPC.global.RPEvent.loot_open.alias = "You loot a corpse"
RPHelper2DBPC.global.RPEvent.loot_closed.alias = "You stop looting a corpse"
RPHelper2DBPC.global.RPEvent.loot_money.alias = "You loot some money"
RPHelper2DBPC.global.RPEvent.loot_open.category = LOOT
RPHelper2DBPC.global.RPEvent.loot_closed.category = LOOT
RPHelper2DBPC.global.RPEvent.loot_money.category = LOOT
RPHelper2DBPC.global.RPEvent.vehicle_enter.alias = "You enter a vehicle"
RPHelper2DBPC.global.RPEvent.vehicle_exit.alias = "You leave a vehicle"

--Begin filtering events
local _, englishClass = UnitClass("player")
if englishClass == "WARRIOR" or englishClass == "ROGUE" or englishClass== "DEATHKNIGHT" then
	RPHelper2DBPC.global.RPEvent.low_mana = nil
	RPHelper2DBPC.global.RPEvent.youcritspell = nil
	RPHelper2DBPC.global.RPEvent.youheal = nil
	RPHelper2DBPC.global.RPEvent.youcritheal = nil
	RPHelper2DBPC.global.RPEvent.silenced = nil
end
if englishClass == "WARLOCK" or englishClass == "MAGE" or englishClass == "HUNTER" then
	RPHelper2DBPC.global.RPEvent.youheal = nil
	RPHelper2DBPC.global.RPEvent.youcritheal = nil
end
if englishClass ~= "WARRIOR" and englishClass ~= "PALADIN" and englishClass ~= "SHAMAN" then
	RPHelper2DBPC.global.RPEvent.block = nil
end
if englishClass ~="HUNTER" and englishClass ~="WARLOCK" and englishClass ~="DEATHKNIGHT" then
	RPHelper2DBPC.global.RPEvent.petattackstart = nil
	RPHelper2DBPC.global.RPEvent.petattackstop = nil
	RPHelper2DBPC.global.RPEvent.petdies = nil
end
if UnitLevel("player") == 80 then
	RPHelper2DBPC.global.RPEvent.player_level_up = nil
	RPHelper2DBPC.global.RPEvent.exhausted = nil
end
end