--Generic event handler, because many events use the same basic structure
function RPHelper2:GenericEvent(myself, arg)
	arg=strlower(arg)
	if arg=="player_regen_disabled" then	messageName="entercombat"
	elseif arg=="player_leave_combat" then messageName="leavecombat"
	elseif arg=="pet_attack_start" then messageName="pet_attack_start"
	elseif arg=="pet_attack_stop" then messageName="pet_attack_stop"
	elseif arg=="player_camping" then messageName="player_camping"
	elseif arg=="mail_closed" then messageName="mail_closed"
	elseif arg=="mail_show" then messageName="mail_open"
	end
	local a=math.random();
	if ( a <= self:getChance(messageName) ) and ( GetTime() - self.LastRP >= self:getDelay(messageName) ) then	
		local s, e, c = self:GetPhrase(messageName)
		self:Roleplay( s, e, c )			
	end -- Delay & Chance
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
	      self.RPedAtLeastOnce = true
	end
end

--The bulk of it is now going to be in the new COMBAT_LOG_EVENT, so we're going to stick that first.
function RPHelper2:COMBAT_LOG_EVENT_UNFILTERED(event,timestamp, eventname, sourceGUID,sourceName,sourceFlags,destGUID,destName,destFlags)
	--if sourceGUID==UnitGUID("player") then self:Print("~"..eventname.."~") end
	local a=math.random();
	local s,e,c = {},{},{}
	if string.find(eventname,"ENVIRONMENTAL_DAMAGE") and destGUID==UnitGUID("player") then
		if arg9=="DROWNING" then
			if ( a <= self:getChance("drowning") ) and ( GetTime() - self.LastRP >= self:getDelay("drowning")) then
				local s, e, c = self:GetPhrase( "drowning" )
				self:Roleplay( s, e, c )
			end
		elseif arg9=="FALLING" then
			if ( a <= self:getChance("fall") ) and ( GetTime() - self.LastRP >= self:getDelay("fall") ) then
				local s, e, c = self:GetPhrase( "fall" )
				self:Roleplay( s, e, c )
			end
		end
	elseif string.find(eventname,"_DAMAGE") then
		--If the player takes damage
		if destGUID==UnitGUID("player") then
			--Only fire if you are somewhat hurt.
			if UnitHealth("player")/UnitHealthMax("player") < .7 then
    				if ( a <= self:getChance("hurt") ) and ( GetTime() - self.LastRP >= self:getDelay("hurt") and InCombatLockdown()) then
						self.lasthp = self.hp
			      		self.hp = UnitHealth("player")
			    		if (self.hp < self.lasthp) then
	     					local s, e, c = self:GetPhrase( "hurt" )
							self:Roleplay( s, e, c )
			      		end
    				end -- Delay & Chance
			end
		--If you crit
		elseif sourceGUID==UnitGUID("player") and arg18 then
			--Offensive spell crit
			if string.find(eventname,"SPELL_") and arg14 ~=1 then
    			if ( a <= self:getChance("youcritspell") ) and ( GetTime() - self.LastRP >= self:getDelay("youcritspell") ) then
					local s, e, c = self:GetPhrase( "youcritspell" )
					self:Roleplay( s, e, c )
				end
			else
			--Physical crit
    			if ( a <= self:getChance("youcrit") ) and ( GetTime() - self.LastRP >= self:getDelay("youcrit") ) then
					local s, e, c = self:GetPhrase( "youcrit" )
					self:Roleplay( s, e, c )
				end
			end
		end
	elseif string.find(eventname,"_MISSED") and destGUID==UnitGUID("player") then
		if ( UnitHealth("player") / UnitHealthMax("player") ) >= 0.7 then  -- Your health must be above 70%
			if arg9=="ABSORB" then
			--You absorb damage
	    		if ( a <= self:getChance("absorb") ) and ( GetTime() - self.LastRP >= self:getDelay("absorb") ) then	
					s, e, c = self:GetPhrase( "absorb" )
					self:Roleplay(s, e, c)
				end				
			elseif arg9=="BLOCK" then
			--You block an attack
	    		if ( a <= self:getChance("block") ) and ( GetTime() - self.LastRP >= self:getDelay("block") ) then	
				    s, e, c = self:GetPhrase( "block" )
					self:Roleplay(s, e, c)
				end
			elseif arg9=="DODGE" then
			--You dodge an attack
	    		if ( a <= self:getChance("dodge") ) and ( GetTime() - self.LastRP >= self:getDelay("dodge") ) then	
				    s, e, c = self:GetPhrase( "dodge" )
					self:Roleplay(s, e, c)
				end
			elseif arg9=="MISS" then
			--An attack misses you
	    		if ( a <= self:getChance("miss") ) and ( GetTime() - self.LastRP >= self:getDelay("miss") ) then
				    s, e, c = self:GetPhrase( "miss" )
					self:Roleplay(s, e, c)
				end
			elseif arg9=="PARRY" then
	    		if ( a <= self:getChance("parry") ) and ( GetTime() - self.LastRP >= self:getDelay("parry") ) then
				    s, e, c = self:GetPhrase( "parry" )
					self:Roleplay(s, e, c)
				end
			end --fail to hit type
		end --health > 70%
	elseif eventname=="SPELL_AURA_APPLIED" then
		if destGUID==UnitGUID("player") then
			if arg12=="BUFF" then
				--Player gains a buff
				if RPHelper2DBPC.global.RPEvent["BUFFGAINED_"..arg10] and a <= self:getChance("BUFFGAINED_"..arg10) and GetTime() - self.LastRP >= self:getDelay("BUFFGAINED_"..arg10) then
					local s, e, c = self:GetPhrase("BUFFGAINED_"..arg10)
					self:Roleplay( s, e, c )
				end
			else
				--Player gains a debuff. Crowd Control stuff needs to be added.
				if RPHelper2DBPC.global.RPEvent["DEBUFFGAINED_"..arg10] and a <= self:getChance("DEBUFFGAINED_"..arg10) and GetTime() - self.LastRP >= self:getDelay("DEBUFFGAINED_"..arg10) then
					local s, e, c = self:GetPhrase("DEBUFFGAINED_"..arg10)
					self:Roleplay( s, e, c )
				end
			end
		elseif destGUID==UnitGUID("target") then
			if arg12=="BUFF" then
				if arg10==RPH_L["Enrage"] and a<=self:getChance("monster_emote_enrage") and ( GetTime() - self.LastRP >= self:getDelay("monster_emote_enrage") )then
			    	s, e, c = self:GetPhrase( "monster_emote_enrage" )
					self:Roleplay(s, e, c)
				end
			else
				if not HasFullControl() and not UnitOnTaxi("player") then
					if UnitIsCharmed("player") then
						--if string.find(txt,RPH_L["Charmed"]) and name ~= RPH_BS["Seduction"] then
						if ( a <= self:getChance("possession") ) and ( GetTime() - self.LastRP >= self:getDelay("possession") ) then	
							local s, e, c = self:GetPhrase( "possession" )
							self:Roleplay( s, e, c )
						end
						--end
					end
				end
				if RPHelper2DBPC.global.RPEvent["TARGETDEBUFF_"..arg10] and a <= self:getChance("TARGETDEBUFF_"..arg10) and GetTime() - self.LastRP >= self:getDelay("TARGETDEBUFF_"..arg10) then
					local s, e, c = self:GetPhrase("TARGETDEBUFF_"..arg10)
					self:Roleplay( s, e, c )
				end
			end
		end
	elseif eventname=="SPELL_AURA_REMOVED" then
		if destGUID==UnitGUID("player") then
			if arg12=="BUFF" then
				--Player loses a buff
				if RPHelper2DBPC.global.RPEvent["BUFFLOST_"..arg10] and a <= self:getChance("BUFFLOST_"..arg10) and GetTime() - self.LastRP >= self:getDelay("BUFFLOST_"..arg10) then
					local s, e, c = self:GetPhrase("BUFFLOST_"..arg10)
					self:Roleplay( s, e, c )
				end
			else
				--Player loses a debuff
				if RPHelper2DBPC.global.RPEvent["DEBUFFLOST_"..arg10] and a <= self:getChance("DEBUFFLOST_"..arg10) and GetTime() - self.LastRP >= self:getDelay("DEBUFFLOST_"..arg10) then
					local s, e, c = self:GetPhrase("BUFFLOST_"..arg10)
					self:Roleplay( s, e, c )
				end
			end
---This block NYI
		--elseif destGUID==UnitGUID("target") then
		--	if arg12=="BUFF" then
				--Target loses a buff
		--	else
				--Target loses a debuff
		--	end
		end
-----------------
	elseif eventname=="SPELL_CAST_START" or eventname=="SPELL_CAST_SUCCESS" then
		--self:Print(arg9)
		--self:Print(arg10)
		if sourceGUID==UnitGUID("player") then
			if arg9==2366 then
			--Herb gathering evidently uses the Apprentice spell no matter your skill
		    		if ( a <= self:getChance("herb_gathering") ) and ( GetTime() - self.LastRP >= self:getDelay("herb_gathering") ) then
					local s, e, c = self:GetPhrase( "herb_gathering" )
					self:Roleplay( s, e, c )
				end
			elseif arg9==1804 then
			--Lockpicking
	    			if ( a <= self:getChance("pick_lock") ) and ( GetTime() - self.LastRP >= self:getDelay("pick_lock") ) then
					local s, e, c = self:GetPhrase( "pick_lock" )
					self:Roleplay( s, e, c )
				end
			elseif arg9==2369 or arg9==2371 or arg9==32605 then
			--Mining
		    		if ( a <= self:getChance("mining") ) and ( GetTime() - self.LastRP >= self:getDelay("mining") ) then
					local s, e, c = self:GetPhrase( "mining" )
					self:Roleplay( s, e, c )
				end
			elseif arg9==31252 then
			--Prospecting
		    		if ( a <= self:getChance("prospecting") ) and ( GetTime() - self.LastRP >= self:getDelay("prospecting") ) then
					local s, e, c = self:GetPhrase( "prospecting" )
					self:Roleplay( s, e, c )
				end

			elseif arg9==8613 or arg9==8617 or arg9==8618 or arg9==10768 or arg9==32678 then
			--Skinning. Different spells fire according to your level.
		    		if ( a <= self:getChance("skinning") ) and ( GetTime() - self.LastRP >= self:getDelay("skinning") ) then
					local s, e, c = self:GetPhrase( "skinning" )
					self:Roleplay( s, e, c )
				end
			else
				local englishSpell = arg10
				englishSpell = gsub(strlower(englishSpell), " ", "_")
				if RPHelper2DBPC.global.RPEvent[englishSpell] ~= nil then
					if ( a <= self:getChance(englishSpell) ) and (GetTime() - self.LastRP >= self:getDelay(englishSpell) ) then
						local s, e, c = self:GetPhrase( englishSpell )
						self:Roleplay( s, e, c )
					elseif RPHelper2DBPC.global.RPEvent["RANDOMABILITY_"..arg10] ~= nil then
						if ( a <= self:getChance("RANDOMABILITY_"..arg10) ) and (GetTime() - self.LastRP >= self:getDelay("RANDOMABILITY_"..arg10) ) then
							local s, e, c = self:GetPhrase( englishSpell )
							self:Roleplay( s, e, c )
						end
					end
				end
			end
		end
	elseif eventname=="SPELL_HEAL" then
		if sourceGUID==UnitGUID("player") and destGUID~=UnitGUID("player") then
			if arg14==true then
		    		if ( a <= self:getChance("youcritheal") ) and ( GetTime() - self.LastRP >= self:getDelay("youcritheal") ) then
					local s, e, c = self:GetPhrase( "youcritheal" )
					self:Roleplay( s, e, c )
				end			
			else
		    		if ( a <= self:getChance("youheal") ) and ( GetTime() - self.LastRP >= self:getDelay("youheal") ) then
					local s, e, c = self:GetPhrase( "youheal" )
					self:Roleplay( s, e, c )
				end
			end
		end
	elseif eventname=="UNIT_DIED" then
		if destGUID==UnitGUID("player") then
			self.IsDead = true
		end
	end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
	      self.RPedAtLeastOnce = true
	end
end

function RPHelper2:PlayerBacktoLife()
	local a=math.random();
   	if self.IsDead then
    		if a <= self:getChance("resurrect") and GetTime() - self.LastRP >= self:getDelay("resurrect") then
			local s, e, c = self:GetPhrase( "resurrect" )
			self:Roleplay( s, e, c )				
		end -- Delay & Chance
	end
	IsDead = false
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
	        self.RPedAtLeastOnce = true
	end
end

function RPHelper2:TalkToNPC()
	if UnitExists("target") then
	local a=math.random();
	if not self.TalkingToNPC then
		RPHelper2.TalkingToNPC = true
		if a <= self:getChance("talktonpc_beginning") and GetTime() - self.LastRP >= self:getDelay("talktonpc_beginning") then	
			local s, e, c = self:GetPhrase( "talktonpc_beginning" )
			if UnitSex("player") == 1 then 		-- if the player is female
				table.insert( e,"CURTSEY" )
			end
			if UnitLevel("target") >= UnitLevel("player") + 5 then   -- if the NPC is 5 levels higher than you
				table.insert( e,"KNEEL" )
			end
			self:Roleplay( s, e, c )
		end
	else
		if a <= self:getChance("talktonpc_middle") and GetTime() - self.LastRP >= self:getDelay("talktonpc_middle") then	
			local s, e, c = self:GetPhrase("talktonpc_middle")
			self:Roleplay( s, e, c )
		end
	end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
	        	self.RPedAtLeastOnce = true
	end
	end
end

function RPHelper2:TalkToNPCEnd()
	if UnitExists("target") then
		local a=math.random();
		if a <= self:getChance("talktonpc_end") and GetTime() - self.LastRP >= self:getDelay("talktonpc_end") then	
			local s, e, c = self:GetPhrase( "talktonpc_end" )
			if UnitSex("player") == 1 then 		-- if the player is female
				table.insert( e,"CURTSEY" )
			end
				self:Roleplay( s, e, c )
		end
		if self.JustRPed == true then
			self.LastRP = GetTime()
			self.JustRPed = false
		        self.RPedAtLeastOnce = true
			RPHelper2.TalkingToNPC = true
		end
	end
end

function RPHelper2:CHAT_MSG_MONEY()
	local a=math.random();
	if ( a <= self:getChance("loot_money") ) and ( GetTime() - self.LastRP >= self:getDelay("loot_money") ) then
		local exactAmount=self.playerMoney-GetMoney()
		local exactAmountString, roughAmount = ""
		if (exactAmount/10000) >= 1 then 
		--	exactAmountString = floor(exactAmount/10000).." gold"
		--	exactAmount= (exactAmount/10000)-floor(exactAmount/10000)
		--	roughAmount="some gold"
		end
		if (exactAmount/100) >= 1 then
		--	if (exactAmountString ~= "") then exactAmountString=exactAmountString..", "
		--	exactAmountString = exactAmountString..floor(exactAmount/100).." silver"
		--	exactAmount = (exactAmount/100)-floor(exactAmount/100)
		--	if roughAmount=="" then roughAmount="some silver"
		end
		--if exactAmountString~="" then exactAmountString=exactAmountString..", "
		--exactAmountString = exactAmountString..exactAmount.." copper"
		--if roughAmount=="" then roughAmount="some copper"

		local s, e, c = self:GetPhrase( "loot_money" )
		for k,v in pairs(s) do
		--	v = string.gsub( v, "EXACTAMOUNT", exactAmountString )
		--	s[k] = v
		end	
		for k,v in pairs(c) do
		--	v = string.gsub( v, "ROUGHAMOUNT", roughAmount )
		--	c[k] = v
		end	
		self:Roleplay( s, e, c )
		self.playerMoney=GetMoney()			
	end -- Delay & Chance
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
		self.RPedAtLeastOnce = true
	end
end

function RPHelper2:CHAT_MSG_MONSTER_EMOTE()
--The arguments in this function need to be localized, so I haven't coded this one in yet.
end

function RPHelper2:CHAT_MSG_SYSTEM(arg1)
	local a=math.random();
        if (self:SameEventStrings(ERR_LEARN_ABILITY_S, arg1)) or (self:SameEventStrings(ERR_LEARN_RECIPE_S, arg1)) or (self:SameEventStrings(ERR_LEARN_SPELL_S, arg1)) then
		if a <= self:getChance("learn") and GetTime() - self.LastRP >= self:getDelay("learn") then
			local s, e, c = self:GetPhrase("learn")
			self:Roleplay( s, e, c )
		end
        elseif (self:SameEventStrings(DRUNK_MESSAGE_SELF2, arg1)) or (self:SameEventStrings(DRUNK_MESSAGE_SELF3, arg1)) or (self:SameEventStrings(DRUNK_MESSAGE_SELF4, arg1)) then
		if  a <= self:getChance("drunk")  and  GetTime() - self.LastRP >= self:getDelay("drunk") then
			local s, e, c = self:GetPhrase( "drunk" )
			self:Roleplay( s, e, c )
		end
        elseif (self:SameEventStrings(DRUNK_MESSAGE_SELF1, arg1)) then
		if a <= self:getChance("sober") and GetTime() - self.LastRP >= self:getDelay("sober") then
			local s, e, c = self:GetPhrase( "sober" )
			self:Roleplay( s, e, c )
		end
        elseif (self:SameEventStrings(ERR_DEATHBIND_SUCCESS_S, arg1)) then
		if a <= self:getChance("new_home") and GetTime() - self.LastRP >= self:getDelay("new_home") then
			local s, e, c = self:GetPhrase( "new_home" )
			self:Roleplay( s, e, c )
		end
        elseif (self:SameEventStrings(ERR_EXHAUSTION_NORMAL,arg1)) then
		if a <= self:getChance("exhausted") and  GetTime() - self.LastRP >= self:getDelay("exhausted") then
			local s, e, c = self:GetPhrase("exhausted")
			self:Roleplay(s, e, c)
		end
        end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
		self.RPedAtLeastOnce = true
	end
end

function RPHelper2:LOOT_OPENED()
	if arg1==0 then self:GenericEvent(self,"loot_open") end
end


function RPHelper2:MINIMAP_PING()
	local a=math.random();
	if ( a <= self:getChance("ping") ) and ( GetTime() - self.LastRP >= self:getDelay("ping") ) then	
		local s, e, c = self:GetPhrase( "ping" )
		for k,v in pairs(s) do
			v = string.gsub( v, "TARGET", UnitName(arg1) )
			s[k] = v
		end	
		for k,v in pairs(c) do
			v = string.gsub( v, "TARGET", UnitName(arg1) )
			c[k] = v
		end	
		self:Roleplay( s, e, c )			
	end -- Delay & Chance
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
	        self.RPedAtLeastOnce = true
	end
end

function RPHelper2:PLAYER_ALIVE()
	if not UnitIsDeadOrGhost("player") then
		self:PlayerBacktoLife()
		self.IsDead = false
	end
end

function RPHelper2:PLAYER_LEVEL_UP(arg1)
	local a=math.random();
	local k,v = 0,0
    	if a <= self:getChance("player_level_up") and GetTime() - self.LastRP >= self:getDelay("player_level_up") then
		local s, e, c = self:GetPhrase( "player_level_up" )	
		for k,v in pairs(s) do
			v = string.gsub( v, "LEVEL", arg1 )
			s[k] = v
		end	
		for k,v in pairs(c) do
			v = string.gsub( v, "LEVEL", arg1 )
			c[k] = v
		end	
		self:Roleplay( s, e, c )	
	end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
		self.RPedAtLeastOnce = true
	end

end

function RPHelper2:PLAYER_REGEN_DISABLED()
	local a=math.random();
	if ( a <= self:getChance("entercombat") ) and ( GetTime() - self.LastRP >= self:getDelay("entercombat") ) then
		local s, e, c = self:GetPhrase( "entercombat" )
		self:Roleplay( s, e, c )
	end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
	    self.RPedAtLeastOnce = true
	end
end

function RPHelper2:PLAYER_UNGHOST()
	self:PlayerBacktoLife()
	self.IsDead = false
end

--This whole thing needs to be redone
function RPHelper2:SpecialEvents_PlayerDebuffGained(name, count, dispelType, debuffTexture, rank, index)
		self.gratuity:SetPlayerBuff(GetPlayerBuff(index, "HARMFUL"))
		local txt = self.gratuity:GetLine(2)
		local a=math.random();
		if string.find(txt,RPH_L["Fleeing in"]) or string.find(txt,RPH_L["Horrified"]) or string.find(txt, RPH_L["Feared"]) or string.find(txt, RPH_L["Intimidated"]) then
			if ( a <= self:getChance("feared") ) and ( GetTime() - self.LastRP >= self:getDelay("feared") ) then	
				local s, e, c = self:GetPhrase( "feared" )
				self:Roleplay( s, e, c )
			end
			return
		end
		--if string.find(txt,RPH_L["Charmed"]) and name ~= RPH_BS["Seduction"] then
		--		if ( a <= self:getChance("possession") ) and ( GetTime() - self.LastRP >= self:getDelay("possession") ) then	
		--			local s, e, c = self:GetPhrase( "possession" )
		--			self:Roleplay( s, e, c )
		--		end
		--		return
		--end
		if string.find(txt,RPH_L["Silenced"]) then
			if ( a <= self:getChance( "silenced") ) and ( GetTime() - self.LastRP >= self:getDelay("silenced")) then	
				local s, e, c = self:GetPhrase( "silenced" )
				self:Roleplay( s, e, c )
			end
			return
		end
		if string.find(txt,RPH_L["Confused"]) or string.find(txt,RPH_L["Confused"]) or UnitIsCharmed("player") then
			if ( a <= self:getChance("confused") ) and ( GetTime() - self.LastRP >= self:getDelay("confused") ) then	
				local s, e, c = self:GetPhrase( "confused" )
				self:Roleplay( s, e, c )
			end
			return
		end
		if string.find(txt,RPH_L["Hexed"]) or string.find(txt,RPH_L["Cannot attack or cast spells"]) then
			local asound = ""
			if ( a <= self:getChance("polymorphed") ) and ( GetTime() - self.LastRP >= self:getDelay("polymorphed") ) then
				if (string.find(debuffTexture, "Cow")) then
					asound=self.Animalsounds["cow"]
				elseif (string.find(debuffTexture, "Pig")) then
					asound=self.Animalsounds["pig"]
				elseif (string.find(debuffTexture, "Chicken")) then
					asound=self.Animalsounds.chicken
				elseif (string.find(debuffTexture, "Turtle")) then
					asound=self.Animalsounds.turtle
				elseif (string.find(debuffTexture, "TouchGrow")) then
					asound=self.Animalsounds.lasher
				elseif (string.find(debuffTexture, "Unholy")) then
					asound=self.Animalsounds.rat
				else
		--For some reason, hex (frog) and poly (sheep) have the same icon
					if string.find(txt,polyd2) then
						asound=self.Animalsounds.frog
					else
						asound=self.Animalsounds.sheep
					end
				end
				local s, e, c = self:GetPhrase( "polymorphed" )
				--Add the animal sound to the sayings table we just extracted.
				table.insert(s,asound)
				self:Roleplay( s, e, c )

			end
			return
		end
	if RPHelper2DBPC.global.RPEvent["DEBUFFGAINED_"..name] then
		if a <= self:getChance("DEBUFFGAINED_"..name) and GetTime() - self.LastRP >= self:getDelay("DEBUFFGAINED_"..name) then
			local s, e, c = self:GetPhrase("DEBUFFGAINED_"..name)
			self:Roleplay( s, e, c )
		end
	end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
		self.RPedAtLeastOnce = true
	end
end

function RPHelper2:TRADE_SHOW()
	local a=math.random();
	if UnitExists("target") and UnitIsPlayer("target") then
		if a <= self:getChance("trade_show") and GetTime() - self.LastRP >= self:getDelay("trade_show") then
			local s, e, c = self:GetPhrase("trade_show")
			if UnitSex("player") == 1 then 		-- if the player is female
		      		table.insert( e,"CURTSEY")
			end
			self:Roleplay( s, e, c )
		end
	end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
		self.RPedAtLeastOnce = true
	end
end

function RPHelper2:TRADE_CLOSED()
	local a=math.random();
	if UnitExists("target") and UnitIsPlayer("target") then
		if a <= self:getChance("trade_closed") and GetTime() - self.LastRP >= self:getDelay("trade_closed") then
			local s, e, c = self:GetPhrase("trade_closed")
			self:Roleplay( s, e, c )
		end
	end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
		self.RPedAtLeastOnce = true
	end
end

function RPHelper2:UNIT_MANA(myUnit)
	local a=math.random();
	if myUnit == "player" and (UnitMana(myUnit) < self.lastmana) and (UnitMana(myUnit)/UnitManaMax(myUnit) < .15) then
		if a <= self:getChance("low_mana") and GetTime() - self.LastRP >= self:getDelay("low_mana") then
			local s, e, c = self:GetPhrase("low_mana")
			self:Roleplay( s, e, c )
		end
	end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
		self.RPedAtLeastOnce = true
	end
	self.lastmana = UnitMana("player")
end

function RPHelper2:UNIT_SPELLCAST_CHANNEL_START(unitCasting)
	if unitCasting == "player" then
		self.IsChanneling = true
	end
end

function RPHelper2:UNIT_SPELLCAST_CHANNEL_STOP(unitCasting)
	if unitCasting == "player" then
		self.IsChanneling = false
	end
end

function RPHelper2:ZONE_CHANGED()
	local a=math.random();
	if (GetRealZoneText() == GetBindLocation()) then
		if  a <= self:getChance("welcome_home") and GetTime() - self.LastRP >= self:getDelay("welcome_home") then
			local s, e, c = self:GetPhrase("welcome_home")
			self:Roleplay(s, e, c)
		end
	end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
		self.RPedAtLeastOnce = true
	end
end

function RPHelper2:PLAYER_ENTERING_WORLD()
	local inInstance, instanceType = IsInInstance()
	self.playerMoney=GetMoney()
	if inInstance then
		if (instanceType == "party" and RPHelper2DBPC.global.disable5man) or (instanceType == "arena" and RPHelper2DBPC.global.disablearena) or
			(instanceType == "pvp" and RPHelper2DBPC.global.disableBG) or (instanceType == "raid" and RPHelper2DBPC.global.disableraid) then
			self:UnregisterAllEvents()
			self:RegisterEvent("PLAYER_ENTERING_WORLD")
		end
	else
		if RPHelper2DBPC.global.isEnabled then
			self:initializeEvents()
		end
	end
end

function RPHelper2:COMPANION_UPDATE()
	for i=1, GetNumCompanions("MOUNT") do
		local _,name,_,_,active=GetCompanionInfo("MOUNT",i)
		if active then
			self.currentMount=name
			local a=math.random();
			if ( a <= self:getChance("mount") ) and ( GetTime() - self.LastRP >= self:getDelay("mount") ) then	
				local s, e, c = self:GetPhrase("mount")
				self:Roleplay( s, e, c )			
			end -- Delay & Chance
		break
		end
	end
	for i=1, GetNumCompanions("CRITTER") do
		local _,name,_,_,active=GetCompanionInfo("CRITTER",i)
		if active then
			local a=math.random();
			if ( a <= self:getChance("noncompet") ) and ( GetTime() - self.LastRP >= self:getDelay("noncompet") ) then	
				local s, e, c = self:GetPhrase("noncompet")
		if s then
			for k,v in pairs(s) do
				if string.find( v, "PNAME" ) then s[k] = string.gsub( v, "PNAME", RPHelper2DBPC.global.mounts[name]) end
			end
		end
		if c then
			for k,v in pairs(c) do
				if string.find( v, "PNAME" ) then c[k] = string.gsub( v, "PNAME", RPHelper2DBPC.global.mounts[name]) end
			end
		end
		self:Roleplay( s, e, c )			
			end -- Delay & Chance
		break
		end
	end
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
	      self.RPedAtLeastOnce = true
	end
end

function RPHelper2:UNIT_THREAT_LIST_UPDATE()
	local s,e,c = {},{},{}
	local a=math.random();
	if self.playerTanking and UnitThreatSituation("player", arg1) < 2 then
		if ( a <= self:getChance("lose_aggro") ) and ( GetTime() - self.LastRP >= self:getDelay("lose_aggro") ) then	
			s, e, c = self:GetPhrase( "lose_aggro" )
		end
		--Player lost aggro
		self.playerTanking = false
	elseif (not self.playerTanking) and UnitThreatSituation("player",arg1) == 3 and GetNumPartyMembers() > 0 then
		if ( a <= self:getChance("gain_aggro") ) and ( GetTime() - self.LastRP >= self:getDelay("gain_aggro") ) then
			s, e, c = self:GetPhrase( "gain_aggro" )
		end
		--Player gained aggro
		self.playerTanking = true
	end
	for k,v in pairs(s) do
		v = string.gsub( v, "AGGRO", UnitName(arg1) )
		local asp,aop,app = "","",""
	    	if UnitSex(arg1) == 2 then
			asp, aop, app = RPH_L["he"], RPH_L["him"], RPH_L["his"]
	        elseif UnitSex(arg1) == 3 then
			asp, aop, app = RPH_L["she"], RPH_L["herOP"], RPH_L["herPP"]
		else
			asp, aop, app = RPH_L["itSP"], RPH_L["itOP"], RPH_L["its"]
	      end
		v = string.gsub( v, "ASP", asp)
		v = string.gsub( v, "AOP", aop)
		v = string.gsub( v, "APP", app)
		s[k] = v
	end	
	for k,v in pairs(c) do
		v = string.gsub( v, "AGGRO", UnitName(arg1))
		local asp,aop,app = "","",""
	    	if UnitSex(arg1) == 2 then
			asp, aop, app = RPH_L["he"], RPH_L["him"], RPH_L["his"]
		elseif UnitSex(arg1) == 3 then
			asp, aop, app = RPH_L["she"], RPH_L["herOP"], RPH_L["herPP"]
		else
			asp, aop, app = RPH_L["itSP"], RPH_L["itOP"], RPH_L["its"]
		end
		v = string.gsub( v, "ASP", asp)
		v = string.gsub( v, "AOP", aop)
		v = string.gsub( v, "APP", app)
		c[k] = v
	end
	self:Roleplay( s, e, c )
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
		self.RPedAtLeastOnce = true
	end
end

function RPHelper2:UNIT_ENTERED_VEHICLE()
	self.currentMount=string.gsub(UnitName("vehicle")," nil","")
	local s,e,c = {},{},{}
	local a=math.random();
	if arg1=="player" then
		for i=1, GetNumCompanions("MOUNT") do
			local _,name=GetCompanionInfo("MOUNT",i)
			if name==self.currentMount then break end
		end
		--if name == self.currentMount then
			--if ( a <= self:getChance("mount") ) and ( GetTime() - self.LastRP >= self:getDelay("mount") ) then
				--s, e, c = self:GetPhrase( "mount" )
			--end
		--else
			if ( a <= self:getChance("vehicle_enter") ) and ( GetTime() - self.LastRP >= self:getDelay("vehicle_enter") ) then
				s, e, c = self:GetPhrase( "vehicle_enter" )
			end
		--end
	end
	if s then
		for k,v in pairs(s) do
			if UnitVehicleSeatCount("player") >1 then
				if string.find(v,"RANDOMPASSENGER") then
				v=string.gsub( v, "RANDOMPASSENGER", math.random(2,UnitVehicleSeatCount("player"))) end
				local passengerlist =""
				for i=1, UnitVehicleSeatCount("player") do
					local controlType, occupantName = UnitVehicleSeatInfo("player", i);
					if controlType ~="Root" then 
						passengerlist = passengerlist..occupantName
						if i ~=UnitVehicleSeatCount("player") then passengerlist = passengerlist.." and " end
					end --if it's not Root
				end --passenger loop
				v=string.gsub(v,"ALLPASSENGERS",passengerlist)
			else
				if string.find(v, "RANDOMPASSENGER") then v="REMOVE ME" end
				if string.find(v, "ALLPASSENGERS") then v="REMOVE ME" end
			end -- vehicle seat count
			if (string.find(v,"{Mech}") and arg3~="Mechanical") then v="REMOVE ME" end
			if string.find(v,"{Nat}") and arg3 ~="Natural" then v="REMOVE ME" end
			s[k]=v
		end -- pairs loop
	end -- if s
	if c then
		for k,v in pairs(c) do
			if UnitVehicleSeatCount("player") >1 then
				v=string.gsub( v, "RANDOMPASSENGER", UnitVehicleSeatInfo("player", math.random(2,UnitVehicleSeatCount("player"))))
				local passengerlist =""
				for i=1, UnitVehicleSeatCount("player") do
					local controlType, occupantName = UnitVehicleSeatInfo("player", i);
					if controlType ~="Root" then 
						passengerlist = passengerlist..occupantName
						if i ~=UnitVehicleSeatCount("player") then passengerlist = passengerlist.." and " end
					end
				end
				v=string.gsub(v,"ALLPASSENGERS",passengerlist)
			else
				if string.find(v, "RANDOMPASSENGER") then v="REMOVE ME" end
				if string.find(v, "ALLPASSENGERS") then v="REMOVE ME" end
			end
			if string.find(v,"{Mech}") and arg3~="Mechanical" then v="REMOVE ME" end
			if string.find(v,"{Nat}") and arg3 ~="Natural" then v="REMOVE ME"end
			c[k]=v
		end
	end
	self:Roleplay( s, e, c )
	if self.JustRPed == true then
		self.LastRP = GetTime()
		self.JustRPed = false
		self.RPedAtLeastOnce = true
	end
end

function RPHelper2:UNIT_EXITED_VEHICLE()
--	self:Print("~~UNIT_EXITED_VEHICLE~~")
--	self:Print("Unit: "..arg1)
--	self:Print(arg2) --vehicle dismount organic
end