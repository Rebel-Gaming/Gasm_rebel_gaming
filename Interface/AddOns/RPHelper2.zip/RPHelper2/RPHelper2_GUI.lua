--This file includes the structure of the Waterfall GUI and 
--various functions associated with populating it correctly.

RPHelper2.sayingType = nil
RPHelper2.eventToAdd = nil
RPHelper2.eventType = nil
RPHelper2.potentialImport = nil
RPHelper2.currentLocale = GetLocale()
RPHelper2.useDialect = 0
local k,v

--Basic structure of the main GUI. Splitting it up into multiple functions makes it easier for the blizz options to handle, and it's
--easier to read too. :)


--This needs to be localized.
function RPHelper2:giveDictionary()
	local dictionary = { type="group", childGroups="tab",
		args={
		welcome={type="description",width="full",name="Welcome to RPHelper2!"},
		slashes={ type="group",name="Slash Commands",args={
		definitions={type="description",width="full",
		name=RPH_L["Slash definitions"]
		}}},
		flags = { type="group",name="Flags",args= {
		definitions = { type="description",width="full",
		name=[[|cFF11FF00{]]..FEMALE.."}|r - "..RPH_L["RP will only fire if target is a"].." "..FEMALE..[[.
|cFF11FF00{]]..MALE.."}|r - "..RPH_L["RP will only fire if target is a"].." "..MALE..[[.
|cFF11FF00{]]..FRIENDLY.."}|r - "..RPH_L["RP will only fire if target is a"].." "..FRIENDLY..[[.
|cFF11FF00{]]..ENEMY.."}|r - "..RPH_L["RP will only fire if target is a"].." "..ENEMY..[[.
|cFF11FF00{]]..strsub(RPH_L["Beast"],1,3).."}|r - "..RPH_L["RP will only fire if target is a"].." "..RPH_L["Beast"]..[[.
|cFF11FF00{]]..strsub(RPH_L["Critter"],1,3).."}|r - "..RPH_L["RP will only fire if target is a"].." "..RPH_L["Critter"]..[[.
|cFF11FF00{]]..strsub(RPH_L["Demon"],1,3).."}|r - "..RPH_L["RP will only fire if target is a"].." "..RPH_L["Demon"]..[[.
|cFF11FF00{]]..strsub(RPH_L["Dragonkin"],1,3).."}|r - "..RPH_L["RP will only fire if target is a"].." "..RPH_L["Dragonkin"]..[[.
|cFF11FF00{]]..strsub(RPH_L["Elemental"],1,3).."}|r - "..RPH_L["RP will only fire if target is a"].." "..RPH_L["Elemental"]..[[.
|cFF11FF00{]]..strsub(RPH_L["Giant"],1,3).."}|r - "..RPH_L["RP will only fire if target is a"].." "..RPH_L["Giant"]..[[.
|cFF11FF00{]]..strsub(RPH_L["Humanoid"],1,3).."}|r - "..RPH_L["RP will only fire if target is a"].." "..RPH_L["Humanoid"]..[[.
|cFF11FF00{]]..strsub(RPH_L["Mechanical"],1,3).."}|r - "..RPH_L["RP will only fire if target is a"].." "..RPH_L["Mechanical"]..[[.
|cFF11FF00{]]..strsub(RPH_L["UndeadTYPE"],1,3).."}|r - "..RPH_L["RP will only fire if target is a"].." "..RPH_L["UndeadTYPE"]..[[.
|cFF11FF00{Mech}|r - RP will only fire if vehicle is mechanical.
|cFF11FF00{Nat}|r - RP will only fire if vehicle is natural (ie, a mammoth or dragon, etc.).
]]
		}}},
		myTitle={ type="group",
		name="Keywords",
		args={
		definitions = {
		type="description",
		width="full",
		name=[[|cFF11FF00AGGRO|r - The monster whose aggro has been gained or lost.
	Example: Oh no, the AGGRO is coming after me!
	Returns: Oh no, the Sunseeker Astromage is coming after me!
|cFF11FF00ALLPASSENGERS|r - a list of all passengers in a vehicle.
	Example: Hiya, ALLPASSENGERS!
	Returns: Hiya, Hakmud of Argus and Gnimo!
|cFF11FF00AOP|r - The aggroed monster's object pronoun.
	Example: AGGRO is chasing me - someone get AOP quick!
	Returns: Priestess Delrissa is chasing me - someone get her quick!
|cFF11FF00APP|r - The aggroed monster's possessive pronoun.
	Example: AGGRO is loose - give me some time to get APP attention back.
	Returns: Selin Fireheart is loose - give me some time to get his attention back.
|cFF11FF00ASP|r - The aggroed monster's subject pronoun.
	Example: The AGGRO is loose, and I think ASP likes me!
	Returns: The Sunblade Keeper is loose, and I think he likes me!
|cFF11FF00HOME|r - your hearthstone bind location
	Example: I'm going home to HOME!
	Returns: I'm going home to Shattrath City!
|cFF11FF00LEVEL|r - your current level (usable only after you gained a level)
	Example: Hurray, season LEVEL!
	Returns: Hurray, season 42!
|cFF11FF00MOUNT|r - The mount or vehicle you are riding.
	Example: /e climbs onto the MOUNT.
	Returns: Duerma climbs onto the Snowy White Gryphon.
	Returns: Duerma climbs onto the Wyrmrest Defender.
|cFF11FF00MOUNTNAME|r - Name of your mount
	Example: Hi-ho, MOUNTNAME, away!
	Returns: Hi-ho, Shmoopy, away!
|cFF11FF00OP|r - your object pronoun
	Example: /e lights OPself on fire.
	Returns: Duerma lights herself on fire. (or, Xinthos lights himself on fire)
|cFF11FF00PLAYER|r - Your name
	Example: I can summon fire without flint or tinder! Some call me... PLAYER!
	Returns: I can summon fire without flint or tinder! Some call me... Duerma!
|cFF11FF00PLAYER_CLASS|r - Your class
	Example: You should know better than to mess with a PLAYER_CLASS.
	Returns: You should know better than to mess with a warlock.
|cFF11FF00PLAYER_GUILDNAME|r - The name of your guild.
	Example: Fool! You dare assault one of PLAYER_GUILDNAME?
	Returns: Fool! You dare assault one of The Order of the White Tower!
|cFF11FF00PLAYER_GUILDRANK|r - Your rank in the guild.
	Example:
	Returns:
|cFF11FF00PLAYER_POWER|r - The type of power you use.
	Example: I don't want to waste PLAYER_POWER on the likes of you.
	Returns: I don't want to waste rage on the likes of you.
|cFF11FF00PLAYER_RACE|r - Your race
	Example: This is for all PLAYER_RACE-kind!
	Returns: This is for all gnome-kind!
|cFF11FF00PNAME|r - Pet name.
	Example: PNAME, rip him to shreds!
	Returns: Kal'thun, rip him to shreds!
|cFF11FF00PP|r - your possessive pronoun
	Example: /e wants PP mommy.
	Returns: Duerma wants her mommy.
|cFF11FF00PTNAME|r - Name of pet's target
	Example: Go get that PTNAME!
	Returns: Go get that Scarlet Defender!
|cFF11FF00PTOP|r - Object pronoun of pet's target
	Example: Tear PTOP limb from limb!
	Returns: Tear him limb from limb!
|cFF11FF00PTPP|r - Possessive pronoun of pet's target
	Example: Bite PTPP knee!
	Returns: Bite his knee!
|cFF11FF00PTSP|r - Subject pronoun of pet's target
	Example: PTSP needs to die.
	Returns: She needs to die.
|cFF11FF00RANDOMPASSENGER|r - Random passenger in vehicle
	Example: /e greets RANDOMPASSENGER warmly.
	Returns: Duerma greets Gnimo warmly.
|cFF11FF00RINSULT|r - Random insult.
	Example: Go away, RINSULT!
	Returns: Go away, you useless bucket of trogg cysts!
|cFF11FF00SP|r - Your subject pronoun
	Example: /e thinks SP'll go to sleep.
	Returns: Duerma thinks she'll go to sleep.
|cFF11FF00SUB_ZONE|r - The sub-zone you're in.
	Example: Get out of SUB_ZONE, you wanker!
	Returns: Get out of Lower Veil Shilak, you wanker!
|cFF11FF00TARGET|r - your target's name
	Example: /e lights TARGET on fire.
	Returns: Duerma lights Scarlet Defender on fire.
|cFF11FF00TARGET_CLASS|r - Target's class
	Example: You are the worst TARGET_CLASS I've ever seen.
	Returns: You are the worst rogue I've ever seen.
|cFF11FF00TARGET_GUILDNAME|r - Target's guild
	Example: Tell TARGET_GUILDNAME to fear my name!
	Returns: Tell Shardracona to fear my name!
|cFF11FF00TARGET_GUILDRANK|r - Target's rank in the guild
	Example:
	Returns:
|cFF11FF00TARGET_POWER|r - Your target's power.
	Example: C'mon, waste some more TARGET_POWER on me!
	Returns: C'mon, waste some more energy on me!
|cFF11FF00TARGET_RACE|r - Target's race
	Example: Stupid TARGET_RACE, get back here!
	Returns: Stupid tauren, get back here!
|cFF11FF00TOP|r - Target's object pronoun
	Example: I smacked TOP good, huh guys?
	Returns: I smacked her good, huh guys?
|cFF11FF00TPP|r - Target's possessive pronoun
	Example: Watch me hack TPP brains out!
	Returns: Watch me hack his brains out!
|cFF11FF00TSP|r - Target's subject pronoun
	Example: TSP buggered off!
	Returns: She buggered off!
]]
	}}}}}
	return dictionary
end

function RPHelper2:giveGeneralOptions()
	local general_options={ type="group",
		name=RPH_L["General Options"],
		desc="Options controlling enabling and importing.",
		args={
		isEnabled = {name = ENABLE,
				type = "toggle",
				get = function ()
					if RPHelper2DBPC.global.isEnabled == nil then RPHelper2DBPC.global.isEnabled = true end
					return RPHelper2DBPC.global.isEnabled
				end,	
				set = function ()
					RPHelper2DBPC.global.isEnabled = not RPHelper2DBPC.global.isEnabled
					if RPHelper2DBPC.global.isEnabled then
						RPHelper2:initializeEvents()
					else
						RPHelper2:UnregisterAllEvents()
					end
				end,
				width="double",
				order = 1,
				},
		disable5man = {name = PARTY_SILENCE,
				type = "toggle",
				get = function ()
					return RPHelper2DBPC.global.disable5man
				end,	
				set = function ()
					RPHelper2DBPC.global.disable5man = not RPHelper2DBPC.global.disable5man
				end,
				width="double",
				order = 1.1,},
		disablearena = {name = "Silence in arenas",
				type = "toggle",
				get = function ()
					return RPHelper2DBPC.global.disablearena
				end,	
				set = function ()
					RPHelper2DBPC.global.disablearena = not RPHelper2DBPC.global.disablearena
				end,
				width="double",
				order = 1.2,},
		disablepvp = {name = BATTLEGROUND_SILENCE,
				type = "toggle",
				get = function ()
					return RPHelper2DBPC.global.disableBG
				end,	
				set = function ()
					RPHelper2DBPC.global.disableBG = not RPHelper2DBPC.global.disableBG
				end,
				width="double",
				order = 1.3,},
		disableraid = {name = RAID_SILENCE,
				type = "toggle",
				get = function ()
					return RPHelper2DBPC.global.disableraid
				end,	
				set = function ()
					RPHelper2DBPC.global.disableraid = not RPHelper2DBPC.global.disableraid
				end,
				width="double",
				order = 1.4,},
		RPLanguage = { name = LANGUAGE,
			type = "select",
			desc = RPH_L["Select the language you will RP in"],
			--Not all languages are initially defined here; it will depend on the user's race.
			values = {[0] = RPH_L["Use Current"],[1] = RPH_L["Random"]},
			get = function (info)
				return RPHelper2DBPC.global.RPLang
			end,
			set = function (info,newValue)
				RPHelper2DBPC.global.RPLang = newValue
			end,
			order=2,
		},
--Some requested that RPs be heard further away, such as when a rogue saps someone. However, this could lead to abuse in the wider world,
--so this selection only affects RPs when you are in an instance.
		InstanceChannel = {type = "select",
			desc = RPH_L["When in an instance, you will RP in this channel instead."],
			name = RPH_L["Instance Channel"],
			values = {["SAY"] = CHAT_MSG_SAY, ["YELL"] = CHAT_MSG_YELL, ["PARTY"] = CHAT_MSG_PARTY},
			get = function (info)
				return RPHelper2.InstanceChannel
			end,
			set = function (info,newValue)
				RPHelper2.InstanceChannel = newValue
			end,
			order = 3,
		},
		globalchance = { type = "range",
			name = RPH_L["Global Chance"],
			desc = RPH_L["Sets the chance that you will roleplay."],
			min = 0,
			max = 1,
			step = .01,
			isPercent = true,
			get=function (info)
				return RPHelper2:getGlobalChance()
			end,
			set = function (info, newValue)
			for k,v in pairs(RPHelper2DBPC.global.RPEvent) do
				if v.Chance==RPHelper2:getGlobalChance() then v.Chance=newValue end
			end
				RPHelper2DBPC.global.globalChance = newValue
			end,
			order = 4,
		},
		globaldelay = { type = "range",
			name = RPH_L["Global Delay"],
			desc = RPH_L["Seconds to wait after last RP"],
			min = 0,
			max = 15,
			step = 0.5,
			get = function (info)
				return RPHelper2:getGlobalDelay()
			end,
			set = function (info, newValue)
				for k,v in pairs(RPHelper2DBPC.global.RPEvent) do
					if v.Delay==RPHelper2:getGlobalDelay() then v.Delay=newValue end
				end
				RPHelper2DBPC.global.globalDelay = newValue
			end,
			order = 5
		},
--Some European users asked for the ability to switch locales (such as, a German client who plays with English speaking friends).
--[[		ChooseLocale = { type = "select",
				values = {["enUS"] = "English", ["deDE"] = "Deutsch", ["frFR"] = "Fran\195\167ais"},
				desc = OPTION_TOOLTIP_LOCALE,
				name = RPH_L["Locale"],
				get = function (info)
					return RPHelper2.currentLocale
				end,
				set = function (info,newValue)
					RPHelper2.currentLocale = newValue
				end,
				order = 4,
		},
--To replace the "traits" picker from the original version, instead we have the ability to import from other files. This lets the user
--customize any of the sayings, and they can be as flexible as they want. This selection also gives the ability to wipe all phrases from
--this character's database.
--This needs to be updated for WOTLK.
		ImportOthers = { type = "select",
			desc = RPH_L["RP like another race or class. Or delete everything and start from scratch."],
			name = RPH_L["Import/Wipe phrases"],
			values = {["XXXXX"] = RPH_L["Wipe all phrases"], ["Generic"] = RPH_L["Generic"], ["BLOODELF"] = RPH_L["Blood elf"],
					["DRAENEI"] = RPH_L["Draenei"], ["HUMAN"] = RPH_L["Human"], ["NIGHTELF"] = RPH_L["Night elf"],
					["GNOME"] = RPH_L["Gnome"], ["ORC"] = RPH_L["Orc"], ["TAUREN"] = RPH_L["Tauren"],
					["TROLL"] = RPH_L["Troll"], ["DWARF"] = RPH_L["Dwarf"], ["SCOURGE"] = RPH_L["UndeadRACE"],
					["WARLOCK"] = RPH_L["Warlock"], ["WARRIOR"] =  RPH_L["Warrior"], ["HUNTER"] = RPH_L["Hunter"],
					["MAGE"] = RPH_L["Mage"], ["PRIEST"] = RPH_L["Priest"], ["DRUID"] = RPH_L["Druid"],
					["PALADIN"] = RPH_L["Paladin"],["SHAMAN"] = RPH_L["Shaman"],["ROGUE"]= RPH_L["Rogue"]},
			get = function (info)
				return RPHelper2.potentialImport
			end,
			set = function (info,newValue)
				RPHelper2.potentialImport = newValue
				if newValue == "XXXXX" then
				--	RPHelper2.opts.args.ConfirmImport.name = RPH_L["Delete all phrases"]
				--	RPHelper2.opts.args.ConfirmImport.desc = RPH_L["Delete all phrases"].." "..RPH_L["from RPHelper"]
				--	RPHelper2.opts.args.ConfirmImport.confirm = RPH_L["Are you sure you want to delete all phrases from RPHelper?"]
				--	LibStub("AceConfigRegistry-3.0"):NotifyChange("RPHelper2")
				--else
				--	RPHelper2.opts.args.ConfirmImport.name = RPH_L["Import"]
				--	RPHelper2.opts.args.ConfirmImport.desc = RPH_L["Import the selected options into RPHelper"]
				--	RPHelper2.opts.args.ConfirmImport.confirm = "Are you sure you want to import "..RPHelper2.potentialImport.." phrases for the "..RPHelper2.currentLocale.." locale?"
				--	LibStub("AceConfigRegistry-3.0"):NotifyChange("RPHelper2")
				end
			end,
			order = 5,
		},
--Because there are multiple options, and we want to make sure the user really wants to do this, nothing happens until
--they press this button.
		ConfirmImport = { type = "execute",
			name = RPH_L["Import"],
			desc = RPH_L["Import the selected options into RPHelper"],
			func = function ()
				if RPHelper2.potentialImport == "XXXXX" then
					for k,v in pairs(RPHelper2DBPC.global.RPEvent) do
						if v.type ~="custom" then		--Don't want to destroy custom events.
							RPHelper2DBPC.global.RPEvent[k].Sayings = nil
							RPHelper2DBPC.global.RPEvent[k].Sayings = {}
							RPHelper2DBPC.global.RPEvent[k].Sayings.emote = {}
							RPHelper2DBPC.global.RPEvent[k].Sayings.customemote = {}
							RPHelper2DBPC.global.RPEvent[k].Sayings.random = {}
							RPHelper2DBPC.global.RPEvent[k].Chance = nil
							RPHelper2DBPC.global.RPEvent[k].Delay = nil
						end
					end
				else
					if not RPHelper2.DBdefaults then
					RPHelper2:RegisterDefaults("char", {
						RPEvent = {
							["*"] = {
							["Sayings"] = {},
							["Chance"] = .1,
							["Delay"] = 8
							},
						},
					} )
					RPHelper2.DBdefaults = true
					end
					local myInitialize="RPHelper2:Initialize"..RPHelper2.potentialImport.."('"..RPHelper2.currentLocale.."')"
					assert(loadstring(myInitialize))()
					RPHelper2:defineEvents()
				end
				RPHelper2.events_options.args.events.args = nil
				RPHelper2.events_options.args.events.args = {}
				RPHelper2.spell_options.args.spells.args = nil
				RPHelper2.spell_options.args.spells.args = {}
				RPHelper2:initializeOptions()
				LibStub("AceConfigRegistry-3.0"):NotifyChange("RPHelper2") -- Event Options")
			end,
			confirm = "Are you sure?",
			order = 10
		},
		ResetChances = { type = "execute",
			name = "Set all chances to zero",
			desc = "Turn off all RPs so you can only use the ones you want",
			func = function() 
					for k,v in pairs(RPHelper2DBPC.global.RPEvent) do
						RPHelper2:setChance(k, 0)
					end
				end,
			confirm = "Are you sure you want to reset all chances to 0?",
			order = 11
		} ]]--
	}
}
	for i=GetNumLanguages(), 1, -1 do
	--Insert user's common and racial languages into the selection box.
	--TODO: Add languages from the Lore tablet.
		tinsert(general_options.args.RPLanguage.values, 2, GetLanguageByIndex(i))
	end

	return general_options
end

function RPHelper2:giveMountOptions()
	local companion_options = { 
		type="group",
		name=COMPANIONS,
		desc="Name your companions here",
		childGroups="tab", 
		args={
			mounts={type="group",
			name = MOUNTS,
			desc = RPH_L["Name your various mounts here."],
			args={}
			},
		pets={
		type="group", 
		name=PETS,
		desc="Name your pets here",
		args={}
		}
	}}
	local m = {}
	for i = 1, GetNumCompanions("MOUNT") do
		_, m[i]=GetCompanionInfo("MOUNT", i)
	end
	i=1
--This populates the Mounts section so you can name your mounts.
	while m[i] do
		companion_options.args.mounts.args[string.gsub(m[i]," ","_")] = { type = "input",
			name = m[i],
			desc = RPH_L["Name your "]..m[i],
			get = function(info)
				return RPHelper2:getMountName(gsub(info[2],"_"," "))
			end,
			set = function (info,newValue)
				return RPHelper2:setMountName(gsub(info[2],"_"," "),newValue)
			end,
			--passValue = m[i],
			usage = RPH_L["<Clever mount name>"]
		}
		i = i + 1
	end
	--Now do the same for pets
	m = {}
	for i = 1, GetNumCompanions("CRITTER") do
		_, m[i]=GetCompanionInfo("CRITTER", i)
	end
	i=1
--This populates the Mounts section so you can name your mounts.
	while m[i] do
		companion_options.args.pets.args[string.gsub(m[i]," ","_")] = { type = "input",
			name = m[i],
			desc = RPH_L["Name your "]..m[i],
			get = function(info)
				return RPHelper2:getMountName(gsub(info[2],"_"," "))
			end,
			set = function (info,newValue)
				return RPHelper2:setMountName(gsub(info[2],"_"," "),newValue)
			end,
			--passValue = m[i],
			usage = RPH_L["<Clever pet name>"]
		}
		i = i + 1
	end
	return companion_options
end

function RPHelper2:giveEventOptions()
	local event_options= {type = "group",
		name = RPH_L["Events"],
		desc = RPH_L["RP options for Events"],
		args = {}
	}
	for k,v in pairs(RPHelper2DBPC.global.RPEvent) do
		--copy this out to a different function?
		if v.type == "event" then -- Save for another function: or v.type == "custom" then
			eventType = v.type
			local eventTypeFormatted=strupper(strsub(eventType,1,1))..strsub(eventType,2)
			if eventType == "event" then eventType = "events" end
			if v.category=="" or not v.category then v.category="General" end
			if not event_options.args[gsub(v.category," ","_")] then
				event_options.args[gsub(v.category," ","_")] = {name=v.category,type="group",args={}}
			end
			event_options.args[gsub(v.category," ","_")].args[strsub(eventType,1,5).."_"..k]=RPHelper2:addNewEvent(eventType, k, RPH_L[RPHelper2DBPC.global.RPEvent[k].alias], RPH_L[RPHelper2DBPC.global.RPEvent[k].alias], v.category)
			if v.Sayings then
				for k2,v2 in ipairs(v.Sayings) do
					if type(v2) == "string" then
						event_options.args[gsub(v.category," ","_")].args[strsub(eventType,1,5).."_"..k].args.phrases.args["phrase-s"..k2] = self:newOption(eventType,k,"saying",v.category,k2)
					end
				end
				if v.Sayings.emote then
					for k2,v2 in ipairs(v.Sayings.emote) do
						if type(v2) == "string" then
							event_options.args[gsub(v.category," ","_")].args[strsub(eventType,1,5).."_"..k].args.phrases.args["phrase-e"..k2] = self:newOption(eventType,k,"emote",v.category,k2)
						end
					end
				end
				if v.Sayings.customemote then
					for k2,v2 in ipairs(v.Sayings.customemote) do
						if type(v2) == "string" then
							event_options.args[gsub(v.category," ","_")].args[strsub(eventType,1,5).."_"..k].args.phrases.args["phrase-c"..k2] = self:newOption(eventType,k,"customemote",v.category,k2)
						end --type(v2)
					end --for loop
				end --customemote
			end -- v.Sayings
		end	--if v.type
	end --for loop

	return event_options
end

function RPHelper2:giveSpellOptions()
	local spell_options = {type = "group",
		name = SPELLBOOK_ABILITIES_BUTTON,
		desc = RPH_L["RP options for Spells"],
		args = {}
	}
--This part populates the spells. We want users to be able to add RP for spells they have, even if we are not brilliant enough to
--give them a default value. Thus, we loop through the spell tab. This also means that if a user specs out of something and then
--puts talent points back into it, they won't lose any RPs they defined. However, if they can't cast that spell, then they won't have
--options for it.
	for i = 1, MAX_SKILLLINE_TABS do
		local tabName, _, offset, numSpells = GetSpellTabInfo(i);
		--RPHelper2:Print(tabName)
		local playerClass, englishClass = UnitClass("player");
		local fixedTabName = ""
		if not tabName then
			break;
		else
		fixedTabName = gsub(strlower(tabName), " ", "_")
			if not spell_options.args[fixedTabName] then
				spell_options.args[fixedTabName]={
					type="group",
					name=tabName,
					args={}
				}
			end
		end
		--RPHelper2:Print(fixedTabName)
		for s = offset + 1, offset + numSpells do
			local spell, rank = GetSpellName(s, BOOKTYPE_SPELL);
			if not IsPassiveSpell (s, BOOKTYPE_SPELL) and not IsAttackSpell(spell) then
				local spellName = gsub(spell, "%p","")
				spellName = gsub(strlower(spellName), " ", "_")
				if not RPHelper2DBPC.global.RPEvent[spellName] then RPHelper2DBPC.global.RPEvent[spellName] = {} end
				newSpell = RPHelper2:addNewEvent("spells",spellName, spell, spell, fixedTabName)
				local _, _, _, _, _, _, castTime = GetSpellInfo(spell)
				if castTime ~= nil and castTime >= 3000 then
					newSpell.args.general.args.beginningRP = {
						type="select",
						style="radio",
						name = "When to RP?",
						values={["BEGIN"]="Beginning of cast",["END"]="End of cast time"},
						get=assert(loadstring([[return function (info)
							if RPHelper2DBPC.global.RPEvent[']]..spellName.."'] and RPHelper2DBPC.global.RPEvent['"..spellName..[['].beginRP then
								return RPHelper2DBPC.global.RPEvent[']]..spellName..[['].beginRP
							end
							end]]))(info),
						set = assert(loadstring([[return function (info,newValue)
							RPHelper2DBPC.global.RPEvent[']]..spellName..[['].beginRP=newValue
							end]]))(info,newValue),
					}
				end --castTime >3000
				if RPHelper2DBPC.global.RPEvent[spellName].Sayings then
					for k2,v2 in ipairs(RPHelper2DBPC.global.RPEvent[spellName].Sayings) do
						if type(v2) == "string" then
							newSpell.args.phrases.args["phrase-s"..k2] = RPHelper2:newOption("spells",spellName,"saying",fixedTabName,k2)
						end
					end
					if RPHelper2DBPC.global.RPEvent[spellName].Sayings.emote then
						for k2,v2 in ipairs(RPHelper2DBPC.global.RPEvent[spellName].Sayings.emote) do
							if type(v2) == "string" then
								newSpell.args.phrases.args["phrase-e"..k2] = RPHelper2:newOption("spells",spellName,"emote",fixedTabName,k2)
							end
						end
					end --if event-emote
					if RPHelper2DBPC.global.RPEvent[spellName].Sayings.customemote then
						for k2,v2 in ipairs(RPHelper2DBPC.global.RPEvent[spellName].Sayings.customemote) do
							if type(v2) == "string" then
								newSpell.args.phrases.args["phrase-c"..k2] = RPHelper2:newOption("spells",spellName,"customemote",fixedTabName,k2)
							end
						end
					end --if event-customemote
				end --if event-Sayings
				--RPHelper2:Print(fixedTabName)
				spell_options.args[fixedTabName].args["spell_"..spellName] = newSpell
			end --isPassive
		end --offset/numSpells loop
	end --for loop on tabs
	return spell_options
end

function RPHelper2:giveCustomOptions()
	RPHelper2.CustomEventType = nil
	RPHelper2.CustomEventName = nil
	local custom_events = { type = "group",
		name = "Custom Events",
		desc = "Add your own events here!",
		childGroups="tab",
		args={
			newEvent={ type="group", name="New Event", desc="Add a New Event",order=1,
				args = {
					EventType = { type = "select",
						name = "Event Type",
						desc= "Select the type of event you want to create.",
						values = {["BUFFGAINED"] = "Buff Gained", ["DEBUFFGAINED"] = "Debuff Gained", 
						["BUFFLOST"] = "Buff Lost", ["DEBUFFLOST"] = "Debuff Lost", ["TARGETDEBUFF"] = "Target gains debuff",
						["RANDOMABILITY"] = "Ability or item use"},
						get = function ()
							return RPHelper2.CustomEventType
							end,
						set = function (info,newValue)
								RPHelper2.CustomEventType = newValue
							end,
						order = 1
					},
					EventName = { type = "input",
						name = "Event Name",
						desc = "Type the name of the buff or debuff EXACTLY how it appears in your combat log.",
						get = function ()
							return RPHelper2.CustomEventName
							end,
						set = function (info,newValue)
							RPHelper2.CustomEventName = newValue
							end,
						order = 2
					},
					CustomConfirm = { type = "execute",
						name = CALENDAR_CREATE_EVENT,
						func = function ()
							local newID = gsub(RPHelper2.CustomEventName, "%p","")
							RPHelper2:Print(newID)
							newID = gsub(strlower(newID), " ", "_")
							newID = RPHelper2.CustomEventType .. "_" .. newID
							local length = getn(RPHelper2.custom_options.args.oldEvents.args)+1
							local descriptor = ""
							if RPHelper2.CustomEventType == "BUFFGAINED" or RPHelper2.CustomEventType == "DEBUFFGAINED" then
								descriptor = "("..ACTION_SPELL_AURA_APPLIED_BUFF..")"
							elseif RPHelper2.CustomEventType == "BUFFLOST" or RPHelper2.CustomEventType == "DEBUFFLOST" then
								descriptor = "("..ACTION_SPELL_AURA_REMOVED_BUFF..")"
							elseif RPHelper2.CustomEventType =="TARGETDEBUFF" then
								descriptor = "("..TARGET..")"
							end
							RPHelper2DBPC.global.RPEvent[newID] = {}
							RPHelper2DBPC.global.RPEvent[newID].Sayings = {}
							RPHelper2DBPC.global.RPEvent[newID].Sayings.emote = {}
							RPHelper2DBPC.global.RPEvent[newID].Sayings.customemote = {}
							RPHelper2DBPC.global.RPEvent[newID].type = "custom"
							RPHelper2DBPC.global.RPEvent[newID].alias = RPHelper2.CustomEventName .. " " .. descriptor
							RPHelper2DBPC.global.RPEvent[newID].Chance = 1
							RPHelper2DBPC.global.RPEvent[newID].Delay = 8
							RPHelper2.custom_options.args.oldEvents.args["custo_"..length]=RPHelper2:addNewEvent("custom", newID, RPHelper2.CustomEventName .. " " .. descriptor, "Options for ".. RPHelper2.CustomEventName .. " " .. descriptor)
							LibStub("AceConfigRegistry-3.0"):NotifyChange("RPHelper2")
						end,
						order = 3
					},
				},
			},
			oldEvents={ type="group",name="Existing Events",desc="Edit Existing Events",order=2,
				args={
				}
			},
		}
	}
	for k,v in pairs(RPHelper2DBPC.global.RPEvent) do
	if strfind(k," ") then
		RPHelper2DBPC.global.RPEvent[string.gsub(k," ","_")] = RPHelper2DBPC.global.RPEvent[k]
		RPHelper2DBPC.global.RPEvent[k] = nil
		k=string.gsub(k," ","_")
	else
		if v.type == "custom" then
			eventType = v.type
			local eventTypeFormatted=strupper(strsub(eventType,1,1))..strsub(eventType,2)
			custom_events.args.oldEvents.args["custo_"..k]=RPHelper2:addNewEvent("custom", k, RPHelper2DBPC.global.RPEvent[k].alias, "Options for ".. RPHelper2DBPC.global.RPEvent[k].alias)
			if v.Sayings then
				for k2,v2 in ipairs(v.Sayings) do
					if type(v2) == "string" then
							custom_events.args.oldEvents.args["custo_"..k].args.phrases.args["phrase-e"..k2] = RPHelper2:newOption(eventType,k,"saying",v.category,k2)
					end
				end
				if v.Sayings.emote then
					for k2,v2 in ipairs(v.Sayings.emote) do
						if type(v2) == "string" then
								custom_events.args.oldEvents.args["custo_"..k].args.phrases.args["phrase-e"..k2] = RPHelper2:newOption(eventType,k,"emote",v.category,k2)
						end
					end
				end
				if v.Sayings.customemote then
					for k2,v2 in ipairs(v.Sayings.customemote) do
						if type(v2) == "string" then
								custom_events.args.oldEvents.args["custo_"..k].args.phrases.args["phrase-c"..k2] = RPHelper2:newOption(eventType,k,"customemote",v.category,k2)
						end --type(v2)
					end --for loop
				end --customemote
			end -- v.Sayings
		end	--if v.type
		end
	end --for loop
	return custom_events
end

function RPHelper2:giveInsultOptions()
	local insult_options = { type="group",
		name = RPH_L["Random Insults"],
		desc = RPH_L["Customize your random insults here"],
		childGroups = "tab",
		args={
			adjectives = { type= "group",
				name=RPH_L["Adjectives"],
				desc=RPH_L["Descriptive, insulting adjectives go here!"],
				args = {}
			},
			container = { type = "group",
				name=RPH_L["Containers"],
				desc=RPH_L["Things that hold other things go here!"],
				args={}
			},
			nouns = { type="group",
				name=RPH_L["Nouns"],
				desc=RPH_L["Disgusting things go here!"],
				args = {}
			}
		}
	}
	for i=1, getn(RPHelper2DBPC.global.RandomInsult[1]) do
		insult_options.args.adjectives.args["adjective-"..i] = {
			type="input",
			name="Adjective "..i,
			get=assert(loadstring([[return function(info)
				return RPHelper2DBPC.global.RandomInsult[1][]]..i..[[]
			end]]))(info),
			set=assert(loadstring([[return function(info, newValue)
				RPHelper2DBPC.global.RandomInsult[1][]]..i..[[] = newValue
			end]]))(info, newValue)
		}
	end
	for i=1, getn(RPHelper2DBPC.global.RandomInsult[2]) do
		insult_options.args.container.args["container-"..i] = {
			type="input",
			name="Container "..i,
			get=assert(loadstring([[return function(info)
				return RPHelper2DBPC.global.RandomInsult[2][]]..i..[[]
			end]]))(),
			set=assert(loadstring([[return function(info, newValue)
				RPHelper2DBPC.global.RandomInsult[2][]]..i..[[] = newValue
			end]]))(info, newValue)
		}
	end
	for i=1, getn(RPHelper2DBPC.global.RandomInsult[3]) do
		insult_options.args.nouns.args["noun-"..i] = {
			type="input",
			name="Noun "..i,
			get=assert(loadstring([[return function(info)
				return RPHelper2DBPC.global.RandomInsult[3][]]..i..[[]
			end]]))(),
			set=assert(loadstring([[return function(info, newValue)
				RPHelper2DBPC.global.RandomInsult[3][]]..i..[[] = newValue
			end]]))(info, newValue)
		}
	end
	return insult_options
end

function RPHelper2:giveRepeaterOptions()
	return repeater_options
end

--change this so it returns a table
function RPHelper2:newOption(eventType,eventName,sayingType, subCat,optionNumber)
		if subCat=="" then subCat= nil end
		local eventTypeFormatted=strupper(strsub(eventType,1,1))..strsub(eventType,2)
		if eventTypeFormatted=="Custom" then eventTypeFormatted="Custom Events" end
-----------------
--This function inserts a new text box for a new saying or emote into the appropriate panel
-----------------
	local length = 0
	if sayingType == "customemote" then
		if optionNumber then
			length=optionNumber
		else
			if RPHelper2DBPC.global.RPEvent[eventName] and RPHelper2DBPC.global.RPEvent[eventName].Sayings and RPHelper2DBPC.global.RPEvent[eventName].Sayings.customemote then
				length = getn(RPHelper2DBPC.global.RPEvent[eventName].Sayings.customemote) + 1
			else
				if not RPHelper2DBPC.global.RPEvent[eventName] then RPHelper2DBPC.global.RPEvent[eventName] = {} end
				if not RPHelper2DBPC.global.RPEvent[eventName].Sayings then RPHelper2DBPC.global.RPEvent[eventName].Sayings = {} end
				RPHelper2DBPC.global.RPEvent[eventName].Sayings.customemote = {}
				length = 1
			end
		tinsert(RPHelper2DBPC.global.RPEvent[eventName].Sayings.customemote, "")
		end
		local ctemp = {
			type = "input",
			name = RPH_L["Phrase"].." "..length.." "..RPH_L["(custom emote)"],
			desc = RPH_L["Insert a custom emote (/e ...)"],
			usage = RPH_L["<Clever emote>"],
			get = assert(loadstring([[return function (info)
				return RPHelper2DBPC.global.RPEvent[']]..eventName.."'].Sayings.customemote["..length..[[]
			end]]))(info),
			set = assert(loadstring([[return function (info, newValue)
				if not RPHelper2DBPC.global.RPEvent[']]..eventName..[['] then
					RPHelper2DBPC.global.RPEvent[']]..eventName..[['] = {}
					RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings = {}
					RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings.customemote = {}
				end
				if newValue == nil or newValue == '' then
					if info[4] then
						RPHelper2.]]..eventType.."_options.args[info[1]].args[info[2]].args[info[3]].args['phrase-c"..length..[[']=nil
					else
						RPHelper2.]]..eventType.."_options.args[info[1]].args[info[2]].args['phrase-c"..length..[[']=nil
					end
					LibStub('AceConfigRegistry-3.0'):NotifyChange('RPHelper2')
				end
				if newValue == '' then
				RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings.customemote[]]..length..[[] = nil
				else
				RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings.customemote[]]..length..[[] = newValue
				end
				end]]))(info, newValue),
			--passValue = {eventName, length, eventType,subCat},
			order = 200 + length
		}
		if optionNumber then
			return ctemp
		else
			if subCat then
				RPHelper2[eventType.."_options"].args[subCat].args[strsub(eventType,1,5).."_"..eventName].args.phrases.args["phrase-c"..length] = ctemp
			else
				if eventTypeFormatted=="Custom Events" then
					self:Print(strsub(eventType,1,5).."_"..eventName)
					RPHelper2.custom_options.args.oldEvents.args[strsub(eventType,1,5).."_"..eventName].args.phrases.args["phrase-c"..length] = ctemp
				else
					RPHelper2[eventType.."_options"].args[strsub(eventType,1,5).."_"..eventName].args.phrases.args["phrase-c"..length] = ctemp
				end
			end
		end
	elseif sayingType == "emote" then
		if optionNumber then
			length=optionNumber
		else
			if RPHelper2DBPC.global.RPEvent[eventName] and RPHelper2DBPC.global.RPEvent[eventName].Sayings and RPHelper2DBPC.global.RPEvent[eventName].Sayings.emote then
				length = getn(RPHelper2DBPC.global.RPEvent[eventName].Sayings.emote) + 1
			else
				if not RPHelper2DBPC.global.RPEvent[eventName] then RPHelper2DBPC.global.RPEvent[eventName] = {} end
				if not RPHelper2DBPC.global.RPEvent[eventName].Sayings then RPHelper2DBPC.global.RPEvent[eventName].Sayings = {} end
				RPHelper2DBPC.global.RPEvent[eventName].Sayings.emote = {}
				length = 1
			end
			tinsert(RPHelper2DBPC.global.RPEvent[eventName].Sayings.emote, "")
		end
		local etemp = {
			type = "input",
			name = RPH_L["Phrase"].." "..length.." ("..CHAT_MSG_EMOTE..")",
			desc = RPH_L["Insert an emote"],
			usage = RPH_L["<Game emote, i.e. KNUCKLES>"],
			get = assert(loadstring([[return function (info)
				return RPHelper2DBPC.global.RPEvent[']]..eventName.."'].Sayings.emote["..length..[[]
			end]]))(info),
			set = assert(loadstring([[return function (info, newValue)
				if not RPHelper2DBPC.global.RPEvent[']]..eventName..[['] then
					RPHelper2DBPC.global.RPEvent[']]..eventName..[['] = {}
					RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings = {}
					RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings.emote = {}
				end
				if newValue == nil or newValue == '' then
					if info[4] then
						RPHelper2.]]..eventType.."_options.args[info[1]].args[info[2]].args[info[3]].args['phrase-e"..length..[[']=nil
					else
						RPHelper2.]]..eventType.."_options.args[info[1]].args[info[2]].args['phrase-e"..length..[[']=nil
					end
					LibStub('AceConfigRegistry-3.0'):NotifyChange('RPHelper2')
				end
				if newValue =='' then
				RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings.emote[]]..length..[[] = nil
				else
				RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings.emote[]]..length..[[] = newValue
				end
				end]]))(info, newValue),
			order = 100 + length
		}
		if optionNumber then
			return etemp
		else
			if subCat then
				RPHelper2[eventType.."_options"].args[subCat].args[strsub(eventType,1,5).."_"..eventName].args.phrases.args["phrase-e"..length] = etemp
			else
				if eventTypeFormatted=="Custom Events" then
					RPHelper2.custom_options.args.oldEvents.args[strsub(eventType,1,5).."_"..eventName].args.phrases.args["phrase-e"..length] = etemp
				else
					RPHelper2[eventType.."_options"].args[strsub(eventType,1,5).."_"..eventName].args.phrases.args["phrase-e"..length] = etemp
				end
			end
		end
	else
	if optionNumber then
		length=optionNumber
	else
		if RPHelper2DBPC.global.RPEvent[eventName] and RPHelper2DBPC.global.RPEvent[eventName].Sayings then
			length = getn(RPHelper2DBPC.global.RPEvent[eventName].Sayings) + 1
			if RPHelper2DBPC.global.RPEvent[eventName].Sayings.emote then length = length - 1 end
			if RPHelper2DBPC.global.RPEvent[eventName].Sayings.customemote then length = length - 1 end
			if RPHelper2DBPC.global.RPEvent[eventName].Sayings.random then length = length - 1 end
		else
			if not RPHelper2DBPC.global.RPEvent[eventName] then RPHelper2DBPC.global.RPEvent[eventName] = {} end
			if not RPHelper2DBPC.global.RPEvent[eventName].Sayings then RPHelper2DBPC.global.RPEvent[eventName].Sayings = {} end
			length = 1
		end
		tinsert(RPHelper2DBPC.global.RPEvent[eventName].Sayings, "")
	end
		local stemp = {
			type = "input",
			name = RPH_L["Phrase"].." "..length.." "..RPH_L["(say)"],
			desc = RPH_L["Insert phrase to say here"],
			usage = RPH_L["<Clever phrase>"],
			get = assert(loadstring([[return function (info)
				return RPHelper2DBPC.global.RPEvent[']]..eventName.."'].Sayings["..length..[[]
			end]]))(info), 
			set = assert(loadstring([[return function (info, newValue)
				if not RPHelper2DBPC.global.RPEvent[']]..eventName..[['] then
					RPHelper2DBPC.global.RPEvent[']]..eventName..[['] = {}
					RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings = {}
				end
				if newValue == nil or newValue == '' then
					if info[4] then
						RPHelper2.]]..eventType.."_options.args[info[1]].args[info[2]].args[info[3]].args['phrase-s"..length..[[']=nil
					else
						RPHelper2.]]..eventType.."_options.args[info[1]].args[info[2]].args['phrase-s"..length..[[']=nil
					end
					LibStub('AceConfigRegistry-3.0'):NotifyChange('RPHelper2')
				end
				if newValue == '' then
				RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings[]]..length..[[] = nil
				else
				RPHelper2DBPC.global.RPEvent[']]..eventName..[['].Sayings[]]..length..[[] = newValue
				end
				end]]))(info, newValue),
			order = 10 + length,
		}
		if optionNumber then
			return stemp
		else
			if subCat then
				RPHelper2[eventType.."_options"].args[subCat].args[strsub(eventType,1,5).."_"..eventName].args.phrases.args["phrase-s"..length] = stemp
			else
				if eventTypeFormatted=="Custom Events" then
					RPHelper2.custom_options.args.oldEvents.args[strsub(eventType,1,5).."_"..eventName].args.phrases.args["phrase-s"..length] = stemp
				else
					RPHelper2[eventType.."_options"].args[strsub(eventType,1,5).."_"..eventName].args.phrases.args["phrase-s"..length] = stemp
				end
			end
		end
	end
	LibStub('AceConfigRegistry-3.0'):NotifyChange("RPHelper2")
end

function RPHelper2:addNewEvent(eventCat,eventID, eventName, eventDesc, subCat)
	if subCat==nil then subCat="" end
	--self:Print(eventID)
	local realID = strsub(eventCat,1,5).."_"..eventID
	local v = { type = "group",
		name = eventName,
		desc = "RP options for "..eventDesc,
		childGroups="tab",
		args = {general = {type="group",name="options",desc="Chance and Delay options",args={
			chance = { type = "range",
				name = RPH_L["Chance"],
				desc = RPH_L["Sets the chance that you will roleplay."],
				min = 0,
				max = 1,
				step = .01,
				isPercent = true,
				get=assert(loadstring([[return function (info)
					return RPHelper2:getChance(']]..eventID..[[')
				end]]))(info),
				set = assert(loadstring([[return function (info, newValue)
					return RPHelper2:setChance(']]..eventID..[[',newValue)
				end]]))(info, newValue),
				order = 2,
			},
			delay = { type = "range",
				name = RPH_L["Delay"],
				desc = RPH_L["Seconds to wait after last RP"],
				min = 0,
				max = 15,
				step = 0.5,
				get = assert(loadstring([[return function (info)
					return RPHelper2:getDelay(']]..eventID..[[')
				end]]))(info),
				set = assert(loadstring([[return function (info,newValue)
					return RPHelper2:setDelay(']]..eventID..[[',newValue)
				end]]))(info,newValue),
				order = 4
			},
			useGlobalChance = {type = "select",
					name = RPH_L["Global/Custom Chance"],
					style="radio",
					values={["GLOBAL"]=RPH_L["Use Global Chance"],["CUSTOM"]=RPH_L["Use Custom Chance"]},
					get = assert(loadstring([[return function (info)
						if RPHelper2:getChance(']]..eventID..[[') == RPHelper2:getGlobalChance() then return 'GLOBAL' else return 'CUSTOM' end
					end]]))(info),
					set = assert(loadstring([[return function (info)
						if RPHelper2:getChance(']]..eventID..[[') == RPHelper2:getGlobalChance() then
							RPHelper2:setChance(']]..eventID..[[',1)
							if ']]..subCat..[[' then
								RPHelper2.]]..eventCat.."_options.args['"..gsub(subCat," ","_").."'].args['"..strsub(eventCat,1,5).."_"..eventID..[['].args.general.args.chance.guiHidden = false
							else
								RPHelper2.]]..eventCat.."_options.args['"..strsub(eventCat,1,5).."_"..eventID..[['].args.general.args.chance.guiHidden = false
							end
							LibStub('AceConfigRegistry-3.0'):NotifyChange('RPHelper2')
							return 'CUSTOM'
						else
							RPHelper2:setChance(']]..eventID..[[',RPHelper2:getGlobalChance())
							if ']]..subCat..[[' then
								RPHelper2.]]..eventCat.."_options.args['"..gsub(subCat," ","_").."'].args['"..strsub(eventCat,1,5).."_"..eventID..[['].args.general.args.chance.guiHidden = true
							else
								RPHelper2.]]..eventCat.."_options.args['"..strsub(eventCat,1,5).."_"..eventID..[['].args.general.args.chance.guiHidden = true
							end
							LibStub('AceConfigRegistry-3.0'):NotifyChange('RPHelper2')
							return 'GLOBAL'
						end
					end]]))(info,newValue),
					order = 1},
			useGlobalDelay = {type = "select",
					name = RPH_L["Global/Custom Delay"],
					style="radio",
					values={["GLOBAL"]=RPH_L["Use Global Delay"],["CUSTOM"]=RPH_L["Use Custom Delay"]},
					get = assert(loadstring([[return function (info)
						if RPHelper2:getDelay(']]..eventID..[[') == RPHelper2:getGlobalDelay() then return 'GLOBAL' else return 'CUSTOM' end
					end]]))(info),
					set = assert(loadstring([[return function (info)
						if RPHelper2:getDelay(']]..eventID..[[') == RPHelper2:getGlobalDelay() then
							RPHelper2:setDelay(']]..eventID..[[',0)
							if ']]..subCat..[[' then
								RPHelper2.]]..eventCat.."_options.args['"..gsub(subCat," ","_").."'].args['"..strsub(eventCat,1,5).."_"..eventID..[['].args.general.args.delay.guiHidden = false
							else
								RPHelper2.]]..eventCat.."_options.args['"..strsub(eventCat,1,5).."_"..eventID..[['].args.general.args.delay.guiHidden = false
							end
							LibStub('AceConfigRegistry-3.0'):NotifyChange('RPHelper2')
							return 'CUSTOM'
						else
							RPHelper2:setDelay(']]..eventID..[[',RPHelper2:getGlobalDelay())
							if ']]..subCat..[[' then
								RPHelper2.]]..eventCat.."_options.args['"..gsub(subCat," ","_").."'].args['"..strsub(eventCat,1,5).."_"..eventID..[['].args.general.args.delay.guiHidden = true
							else
								RPHelper2.]]..eventCat.."_options.args['"..strsub(eventCat,1,5).."_"..eventID..[['].args.general.args.delay.guiHidden = true
							end
							LibStub('AceConfigRegistry-3.0'):NotifyChange('RPHelper2')
							return 'GLOBAL'
						end
					end]]))(info,newValue),
					order = 3}}},
			phrases = { type = "group",
				name = RPH_L["Phrases"],
				desc = RPH_L["These are phrases you will say or emote"],
				args = { 
					addSaying = {
						name = RPH_L["New Saying"],
						order = 98,
						type = "execute",
						--passValue = {eventCat, eventID,subCat},
						func = assert(loadstring([[return function(info)
							RPHelper2:newOption(']]..eventCat.."','"..eventID.."','Sayings','"..subCat..[[')
						end]]))()
					},
					addEmote = {
						name = RPH_L["New Emote"],
						order = 198,
						type = "execute",
						--passValue = {eventCat, eventID,subCat},
						func = assert(loadstring([[return function()
							RPHelper2:newOption(']]..eventCat.."','"..eventID.."','emote','"..subCat..[[')
						end]]))()
					},
					addcustomemote = {
						name = RPH_L["New Custom Emote"],
						order = 298,
						type = "execute",
						--passValue = {eventCat, eventID,subCat},
						func = assert(loadstring([[return function()
							RPHelper2:newOption(']]..eventCat.."','"..eventID.."','customemote','"..subCat..[[')
						end]]))()
					} -- customemote
				} -- args
			} -- phrases
		} -- args
	} -- top
	--if Dwarvenizer and self.newEventDwarvenizer then
	--	v.args.dwarfTrollIt = self:newEventDwarvenizer(eventID)
	--end
	if eventCat == "custom" then
		v.args.delEvent = { type = "execute",
			name = CALENDAR_DELETE_EVENT,
			order = 10,
	--		--passValue = {eventCat, eventID,subCat},
			confirm=true,
			confirmText = CALENDAR_DELETE_EVENT_CONFIRM,
			func = function(arg)
			end,
		}
	end
	if self:getDelay(eventID) == self:getGlobalDelay() then v.args.general.args.delay.guiHidden = true end
	if self:getChance(eventID) == self:getGlobalChance() then v.args.general.args.chance.guiHidden = true end
	--Need to figure out what I was doing here and fix it. Need to axe global references.
		if v.args.delEvent then
		--self:Print(eventID)
			v.args.delEvent.func = assert(loadstring([[return function()
				RPHelper2DBPC.global.RPEvent[']]..eventID..[['] = nil
				RPHelper2.custom_options.args.oldEvents.args['custo_]]..eventID..[['] = nil
				LibStub('AceConfigRegistry-3.0'):NotifyChange('RPHelper2')
				end]]))(info)
		end
		--self.opts.args[eventCat].args[realID] = v
	return v
end



function RPHelper2:getMountName(mount)
	if RPHelper2DBPC.global.mounts then
		return RPHelper2DBPC.global.mounts[mount]
	else
		return ""
	end
end



function RPHelper2:setMountName(mount, mountName)
	if not RPHelper2DBPC.global.mounts then
		RPHelper2DBPC.global.mounts = {}
	end
	RPHelper2DBPC.global.mounts[mount] = mountName
	--self:Print(mountName)
end