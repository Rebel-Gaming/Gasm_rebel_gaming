Custom Comix Functions for developers

Comix_CustomPic(path)

	this will show a custom pic in the Comix style, just specify the path

Comix_CustomSound(path)

	same as the pic function except its for playing sounds

Comix_ShakeScreen()

	call this to shake the screen using the current Comix screen shake settings

Comix_ScreenFlash(r, g, b, size)

	flash the screen, r, g, b are red/green/blue color values (between 0 and 1) and the size is either the large flash(1) or small flash(2)