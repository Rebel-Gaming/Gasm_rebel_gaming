ComixSpecialImages = {}
ComixSpecialImages[1] = "Specials\\battleshout.blp"
ComixSpecialImages[2] = "Specials\\demoshout.blp"
ComixSpecialImages[3] = "Specials\\ironman.blp"
ComixSpecialImages[4] = "Specials\\stun.blp"
ComixSpecialImages[5] = "Specials\\objection.blp"

ComixMortalCombatImages = {}
ComixMortalCombatImages[1] = "Specials\\brutality.blp"
ComixMortalCombatImages[2] = "Specials\\fatality.blp"
ComixMortalCombatImages[3] = "Specials\\superb.blp"
ComixMortalCombatImages[4] = "Specials\\outstanding.blp"
ComixMortalCombatImages[5] = "Specials\\excellent.blp"
