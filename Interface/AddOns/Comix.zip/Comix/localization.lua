-- English Localization --

-- Abilities --
COMIX_BS = "Battle Shout"
COMIX_DS = "Demoralizing Shout"
COMIX_DR = "Demoralizing Roar"
COMIX_SV = "is afflicted by Spell Vunerability"
COMIX_SPRINT = "Sprint"
COMIX_DASH = "Dash"
COMIX_CANNIBALIZE = "Cannibalize"
COMIX_ICEBLOCK = "Ice Block"

-- Targets --
COMIX_BIGGLESWORTH = "Mr. Bigglesworth"
COMIX_REPAIRBOT = "Field Repair Bot 74A"
COMIX_REPAIRBOT2 = "Field Repair Bot 110G"
COMIX_MUFFIN = "Muffin Man Moser"
-- Hug Meter --
COMIX_YOULOW = "you"
COMIX_YOUUP = "You "
COMIX_NEED = " need "
COMIX_HUGS = " hugs "
COMIX_HUG = " hug"
COMIX_HUGGAP = 6
COMIX_HUGSGAP = 6
-- Classes --
COMIX_PALADIN = "Paladin"
COMIX_SHAMAN = "Shaman"
COMIX_DRUID = "Druid"

--Objections
COMIX_OBJECT = "OBJECT!"
COMIX_OBJECTS = "OBJECTS!"
COMIX_OBJECTTO = "object to"
COMIX_OBJECTSTO = "objects to"

--bad jokes
COMIX_BADJOKE = "bad joke"
COMIX_JOKEEMOTE1= "senses a bad joke"
COMIX_JOKEEMOTE2A= "facepalms at "
COMIX_JOKEEMOTE2B= "'s bad joke"

COMIX_DRAMAEMOTE = "detects a hint of drama"