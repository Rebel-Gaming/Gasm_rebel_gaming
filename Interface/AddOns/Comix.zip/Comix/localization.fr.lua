if ( GetLocale() == "frFR" ) then
	-- French Localization --
	-- Dmg Types --
	COMIX_FIRE = "Feu."
	COMIX_FROST = "Givre."
	COMIX_NATURE = "Nature."
	COMIX_SHADOW = "Ombre."
	COMIX_ARCANE = "Arcane."
	COMIX_HOLY = "Sacr�."
	COMIX_HEAL = "soigne"
	-- Crits --
	COMIX_CRIT = " coup critique "
	COMIX_CRITS = " critique "
	COMIX_CRITICALLY = "coup critique"
	COMIX_CRITICALLY2 = "critique"
	COMIX_CRITHEAL = "(. +) 's (. +) vous gu�rit en critique pour (%d+)."
COMIX_CRITHEAL2 = "Votre (. +) gu�rit en critique (. +) pour (%d+)."
COMIX_CRITYOU = "(. +) crits vous pour (%d+)."
COMIX_SPELLCRITYOU = "(.+)'s (.+) crits vous pour (%d+)."
	-- Abilities --
	COMIX_BS = " Cri de guerre"
	COMIX_DS = " Cri d'affliction"
	COMIX_DR = " Grognement d'intimidation"
	COMIX_SV = "is afflicted by Spell Vunerability" -- Message for Nightfall Procc.... hope someone knows it :P
	COMIX_SPRINT = "Sprint"
	COMIX_DASH = "Dash"
	COMIX_CANNIBALIZE = "You gain Cannibalize."
	COMIX_ICEBLOCK = "Ice Block"
	-- Targets --
	COMIX_BIGGLESWORTH = "Mr. Bigglesworth"
	COMIX_REPAIRBOT = "Robot r�parateur 74A"
	COMIX_MUFFIN = "Muffin Man Moser"
	-- Hug Meter --
	COMIX_YOULOW = "vous"
	COMIX_YOUUP = "Vous "
	COMIX_NEED = " voulez "
	COMIX_HUGS = "dans vos bras"
	COMIX_HUG = "dans ses bras"
	COMIX_HUGGAP = 8
	COMIX_HUGSGAP = 13
end