﻿-- Simple Chinese Localization Translate By Cheerleader(Eruku)  at 2007-08-01 // v.1.2.5--
-- Dmg Types --
if ( GetLocale() == "zhCN" ) then
COMIX_FIRE = "火焰"
COMIX_FROST = "冰霜"
COMIX_NATURE = "自然"
COMIX_SHADOW = "暗影"
COMIX_ARCANE = "奥术"
COMIX_HOLY = "神圣"
COMIX_HEAL = "恢复了"
-- Crits --
COMIX_CRIT = "爆击"
COMIX_CRITS = "爆击"
COMIX_CRITICALLY = "爆击"
COMIX_CRITICALLY2 = "爆击"
COMIX_CRITHEAL = "(.+)的(.+)爆击为你恢复了"
COMIX_CRITHEAL2 = "你的(.+)爆击为(.+)恢复了"
COMIX_CRITYOU = "(.+)的爆击对你造成"
COMIX_CRITYOU2 = "(.+) 的爆击对你造成"
COMIX_SPELLCRITYOU = "(.+)的(.+)爆击对你造成"
COMIX_SPELLCRITYOU2 = "(.+) 的 (.+) 爆击对你造成"
-- Abilities --
COMIX_BS = "战斗怒吼"
COMIX_DS = "挫志怒吼"
COMIX_DR = "挫志咆哮"
COMIX_SV = "获得了萨满之怒的效果"
COMIX_SPRINT = "疾跑"
COMIX_DASH = "急奔"
COMIX_CANNIBALIZE = "你获得了食尸的效果"
-- Targets --
COMIX_BIGGLESWORTH = "比格沃斯"
COMIX_REPAIRBOT = "修理机器人74A型"
COMIX_MUFFIN = "松饼人慕瑟尔"
-- Hug Meter --
COMIX_YOULOW = " you"
COMIX_YOUUP = "You"
COMIX_NEED = "needs"
COMIX_HUGS = "hugs"
COMIX_HUG = "hug"
COMIX_HUGGAP = 6
COMIX_HUGSGAP = 6

end