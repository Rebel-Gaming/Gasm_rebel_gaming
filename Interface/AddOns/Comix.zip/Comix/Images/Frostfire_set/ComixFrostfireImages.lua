-- Frostfire Grafix --
ComixFrostfireImages = {};
ComixFrostfireImages[1] = "Images\\Frostfire_set\\frostfire1.blp";
ComixFrostfireImages[2] = "Images\\Frostfire_set\\frostfire2.blp";
ComixFrostfireImages[3] = "Images\\Frostfire_set\\frostfire3.blp";
ComixFrostfireImages[4] = "Images\\Frostfire_set\\frostfire4.blp";

