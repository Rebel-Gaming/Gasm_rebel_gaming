-- Arcane Grafix --
ComixArcaneImages = {};
ComixArcaneImages[1] = "Images\\Arcane_set\\arcane1.blp";
ComixArcaneImages[2] = "Images\\Arcane_set\\arcane2.blp";
ComixArcaneImages[3] = "Images\\Arcane_set\\arcane3.blp";
ComixArcaneImages[4] = "Images\\Arcane_set\\arcane4.blp";


