-- Nature Grafix --
ComixNatureImages = {};
ComixNatureImages[1] = "Images\\Nature_set\\nature1.blp";
ComixNatureImages[2] = "Images\\Nature_set\\nature2.blp";
ComixNatureImages[3] = "Images\\Nature_set\\nature3.blp";
ComixNatureImages[4] = "Images\\Nature_set\\nature4.blp";


