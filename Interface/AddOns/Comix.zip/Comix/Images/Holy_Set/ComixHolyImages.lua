-- Holy Grafix --
ComixHolyHealImages = {};
ComixHolyHealImages[1] = "Images\\Holy_set\\holyheal1.blp";
ComixHolyHealImages[2] = "Images\\Holy_set\\holyheal2.blp";
ComixHolyHealImages[3] = "Images\\Holy_set\\holyheal3.blp";
ComixHolyHealImages[4] = "Images\\Holy_set\\holyheal4.blp";

ComixHolyDmgImages = {};
ComixHolyDmgImages[1] = "Images\\Holy_set\\holydmg1.blp";
ComixHolyDmgImages[2] = "Images\\Holy_set\\holydmg2.blp";
ComixHolyDmgImages[3] = "Images\\Holy_set\\holydmg3.blp";
ComixHolyDmgImages[4] = "Images\\Holy_set\\holydmg4.blp";
