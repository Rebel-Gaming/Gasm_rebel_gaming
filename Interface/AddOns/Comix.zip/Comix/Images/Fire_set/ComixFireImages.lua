-- Fire Grafix --
ComixFireImages = {};
ComixFireImages[1] = "Images\\Fire_set\\fire1.blp";
ComixFireImages[2] = "Images\\Fire_set\\fire2.blp";
ComixFireImages[3] = "Images\\Fire_set\\fire3.blp";
ComixFireImages[4] = "Images\\Fire_set\\fire4.blp";
ComixFireImages[5] = "Images\\Fire_set\\fire5.blp";
ComixFireImages[6] = "Images\\Fire_set\\fire6.blp";
ComixFireImages[7] = "Images\\Fire_set\\fire7.blp";
ComixFireImages[8] = "Images\\Fire_set\\fire8.blp";
ComixFireImages[9] = "Images\\Fire_set\\fire9.blp";
