-- Death Grafix --
ComixDeathImages = {};
ComixDeathImages[1] = "Images\\Death_set\\death1.blp";
ComixDeathImages[2] = "Images\\Death_set\\death2.blp";
ComixDeathImages[3] = "Images\\Death_set\\death3.blp";


