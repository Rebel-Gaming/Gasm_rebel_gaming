-- Overkill Grafix --
ComixOverkillImages = {};
ComixOverkillImages[1] = "Images\\Overkill_set\\overkill1.blp";
ComixOverkillImages[2] = "Images\\Overkill_set\\overkill2.blp";
ComixOverkillImages[3] = "Images\\Overkill_set\\overkill3.blp";
ComixOverkillImages[4] = "Images\\Overkill_set\\overkill4.blp";


