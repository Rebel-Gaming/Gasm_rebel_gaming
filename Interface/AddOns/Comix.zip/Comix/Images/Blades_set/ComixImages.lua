-- Normal Grafix --
ComixImages = {};
ComixImages[1] = "Images\\Blades_set\\blade1.blp";
ComixImages[2] = "Images\\Blades_set\\blade2.blp";
ComixImages[3] = "Images\\Blades_set\\blade3.blp";
ComixImages[4] = "Images\\Blades_set\\blade4.blp";
ComixImages[5] = "Images\\Blades_set\\blade5.blp";
ComixImages[6] = "Images\\Blades_set\\blade6.blp";
ComixImages[7] = "Images\\Blades_set\\blade7.blp";
ComixImages[8] = "Images\\Blades_set\\blade8.blp";
ComixImages[9] = "Images\\Blades_set\\blade9.blp";
ComixImages[10] = "Images\\Blades_set\\blade10.blp";
ComixImages[11] = "Images\\Blades_set\\blade11.blp";
ComixImages[12] = "Images\\Blades_set\\blade12.blp";
