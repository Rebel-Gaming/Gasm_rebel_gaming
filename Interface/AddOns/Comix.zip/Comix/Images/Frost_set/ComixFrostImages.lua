-- Frost Grafix --
ComixFrostImages = {};
ComixFrostImages[1] = "Images\\Frost_set\\frost1.blp";
ComixFrostImages[2] = "Images\\Frost_set\\frost2.blp";
ComixFrostImages[3] = "Images\\Frost_set\\frost3.blp";
ComixFrostImages[4] = "Images\\Frost_set\\frost4.blp";
ComixFrostImages[5] = "Images\\Frost_set\\frost5.blp";
ComixFrostImages[6] = "Images\\Frost_set\\frost6.blp";
ComixFrostImages[7] = "Images\\Frost_set\\frost7.blp";
ComixFrostImages[8] = "Images\\Frost_set\\frost8.blp";
ComixFrostImages[9] = "Images\\Frost_set\\frost9.blp";
ComixFrostImages[10] = "Images\\Frost_set\\frost10.blp";
ComixFrostImages[11] = "Images\\Frost_set\\frost11.blp";

