-- Shadow Grafix --
ComixShadowImages = {};
ComixShadowImages[1] = "shadow1.blp";
ComixShadowImages[2] = "shadow2.blp";
ComixShadowImages[3] = "shadow3.blp";
ComixShadowImages[4] = "shadow4.blp";
ComixShadowImages[5] = "shadow5.blp";
ComixShadowImages[6] = "shadow6.blp";
