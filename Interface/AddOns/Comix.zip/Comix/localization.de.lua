if ( GetLocale() == "deDE" ) then
	-- Dmg Types --
	COMIX_FIRE = "Feuer"
	COMIX_FROST = "Frost"
	COMIX_NATURE = "Natur"
	COMIX_SHADOW = "Schatten"
	COMIX_ARCANE = "Arkan"
	COMIX_HOLY = "Heilig"
	COMIX_HEAL = "heilt"
	-- Crits --
	COMIX_CRIT = " kritisch "
	COMIX_CRITS = " kritisch."
	COMIX_CRITICALLY = " kritisch "
	COMIX_CRITICALLY2 = "Kritische "
	COMIX_CRITHEAL = "Kritische Heilung: (.+) heilt (.+) um (%d+) Punkte."
COMIX_CRITHEAL2 = "Kritische Heilung: (.+) heilt Euch um (%d+) Punkte."
COMIX_CRITYOU = "(. +) crits du f�r (%d+)."
COMIX_SPELLCRITYOU = "(.+)'s (.+) crits du f�r (%d+)."
	-- Abilities --
	COMIX_BS = "Schlachtruf"
	COMIX_DS = " Demoralisierungsruf"
	COMIX_DR = " Demoralisierendes Gebr\195\188ll"
	COMIX_SV = "is afflicted by Spell Vunerability"
	COMIX_SPRINT = "Sprinten"
	COMIX_DASH = "Spurt"
	COMIX_CANNIBALIZE = "You gain Cannibalize."
	COMIX_ICEBLOCK = "Ice Block"
	-- Targets --
	COMIX_BIGGLESWORTH = "Mr. Bigglesworth"
	COMIX_REPAIRBOT = "Field Repair Bot 74A"
	COMIX_MUFFIN = "Muffin Man Moser"
	-- Hug Meter --
	COMIX_YOULOW = "Euch"
	COMIX_YOUUP = "Ihr"
	COMIX_NEED = " m�sst "
	COMIX_HUGS = "umarmt"
	COMIX_HUG = "umarmt"
	COMIX_HUGGAP = 9
	COMIX_HUGSGAP = 7
end