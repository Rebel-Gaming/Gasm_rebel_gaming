﻿--[[
	OmniCC Localization File
		French by TrAsHeR
--]]

if GetLocale() == 'frFR' then
	OMNICC_LOCALS = {}
	local L = OMNICC_LOCALS
	L.UpgradeIncompatible = "Mise à jour depuis une version incompatible. Les paramètres par défaut ont été chargés."
	L.Updated = "Updated to v%s"
end