﻿-- Author      : Mart
-- Create Date : 3/27/2010 4:55:17 PM

--Variables globales		
GuildDonationHelper = LibStub("AceAddon-3.0"):NewAddon("GuildDonationHelper","AceEvent-3.0","AceConsole-3.0","AceComm-3.0","AceSerializer-3.0");

--Nombres de personajes de la hermandad
GuildNames={};

local MENUOPTIONS=
 {
    name = "GuildDonationHelper",
    handler = GuildDonationHelper,
    type = 'group',
    args = {
        msg = {
            type = 'input',
            name = 'My Message',
            desc = 'The message for my addon',
            set = 'SetMyMessage',
            get = 'GetMyMessage',
        },
    },
}

--Lista de paramtros usados por toda la aplicacion
PARAMETER =
{
	totalHistoryPayed		=0,
	totalMoney				=0,
	totalCredit				=0,
	taxAmount				=0,
	creditTax				=0,
	totalSmallChanges		=0,
	totalComerce			=0,
	totalMail				=0,
	totalQuest				=0,
	paymentTax				=0,
	showActivity			=0,
	userList				={}
}
--Variable para indicar que si hay depuraciones
ISDEBUG=false;

--Nombre del canal de comunicaciones
CHANNELNAME="GuildDonationHelper";

-- Code that you want to run when the addon is first loaded goes here.
function GuildDonationHelper:OnInitialize()	
	self:ShowSystemMessage("OnInitialize");
	
	--Registra el comando de chat
	self:RegisterChatCommand("gdh", "SlashCmdHandler");
	
	--Inicializa el manejo de datos
	self.db = LibStub("AceDB-3.0"):New("GuildDonationHelperDB");
	
	--self:RegisterEvent("ADDON_LOADED");		
	self:RegisterEvent("CHAT_MSG_SYSTEM");
	self:RegisterEvent("CHAT_MSG_WHISPER");			
	self:RegisterEvent("CHAT_MSG_MONEY");	
	self:RegisterEvent("GUILDBANKFRAME_OPENED");	
	self:RegisterEvent("PLAYER_LOGOUT");	
	self:RegisterEvent("MAIL_SHOW");
	self:RegisterEvent("MAIL_CLOSED");	
	self:RegisterEvent("MERCHANT_SHOW");
	self:RegisterEvent("MERCHANT_CLOSED");	
	self:RegisterEvent("GUILD_ROSTER_UPDATE");
	self:RegisterEvent("PLAYER_MONEY");
	self:RegisterEvent("GUILDBANKFRAME_CLOSED");
end

-- Called when the addon is enabled
function GuildDonationHelper:OnEnable()	
	self:ShowSystemMessage("OnEnable");	
	
	--Evento para solicitudes
	self:RegisterComm(CHANNELNAME.."REQUEST","OnCommRequest");				
		
	--Evento para respuestas
	self:RegisterComm(CHANNELNAME.."RESPONSE","OnCommResponse");	
	
	--Carga las variables del disco
	self:LoadVariables();
		
	--Obtiene el valor para la tasa de impuesto		
	self:SetGuildTaxRate();	
	
	--Inicializa la miniventana con la tasa actual de impuesto
	self:FrmMiniTaxFrame_Init();
	
	--Notifica a la guild el estado de la cuenta
	self:SendCommMessage(CHANNELNAME.."RESPONSE", self:BuildMessage(), "GUILD");
	
	--Pide informacion a todos
	self:SendCommMessage(CHANNELNAME.."REQUEST", "REPORT", "GUILD");
end

-- Called when the addon is disabled
function GuildDonationHelper:OnDisable()
	self:UnregisterChatCommand("gdh");
end

--Evento cuando el jugador cierra la sesion
function GuildDonationHelper:PLAYER_LOGOUT()	
	self:SaveVariables();  
	
end

--Evento cuando llega informacion de la hermandad
function GuildDonationHelper:GUILD_ROSTER_UPDATE()

	GuildNames = {};
	v = 1;
	
	--Consulta el numero de miembros de hermandad incluyendo los desconectados
	for i=1, GetNumGuildMembers(true) do
	
		--Obtiene el nombre del personaje de hermandad
		
		local name, rank, rankIndex, level, class, zone, note, officernote, online, status, classFileName = GetGuildRosterInfo(i);
		GuildNames[v] = name;		
		v = v + 1;		
	end
		
	table.sort(GuildNames);
	
	--Muestra cuantos hay en la hermandad
	self:ShowSystemMessage("Total in the guild: "..#GuildNames);	
end

--Recibe los mensajes en el canal
function GuildDonationHelper:OnCommRequest(prefix, message, distribution, sender) 	
	self:ShowSystemMessage("OnCommRequest");		
	
	if(message=="REPORT" and prefix==CHANNELNAME.."REQUEST") then		
		local serialized				=self:BuildMessage();
			  
		if(serialized~=nil) then			
			--Envia un mensaje de respuesta a quien solicito la informacion
			self:SendCommMessage(CHANNELNAME.."RESPONSE", serialized, "WHISPER",sender);    		        		
		end
	end
    
end

--Funcion de respuesta
function GuildDonationHelper:OnCommResponse(prefix, message, distribution, sender) 
		
	self:ShowSystemMessage("OnCommResponse "..sender.." "..prefix.." MSG:"..message);		
	
	--Coloca el mensaje recibido en la tabla
	if(prefix==CHANNELNAME.."RESPONSE") then		
			
		--Desserializa el mensaje		
		local sucess,registry=self:Deserialize(message);
		
		if(sucess) then
		
			local row=
			{
				player				= sender,
				totalHistoryPayed	= registry["totalHistoryPayed"],
				totalMoney			= registry["totalMoney"],
				taxAmount			= registry["taxAmount"], 
				totalCredit			= registry["totalCredit"] 
			};
			
			local index=0;	
		
			for i = 1, #PARAMETER["userList"] do		
				if(PARAMETER["userList"][i].player==sender) then
					index=i;
				end
			end				
			
			if(index==0) then
				table.insert(PARAMETER["userList"],row);	
			else
				PARAMETER["userList"][index]=row;
			end
			
			--Actualiza la tabla de usuarios
			self:UpdateUserTable();
		end
	end	
end

--Obtiene las variables desde el sistema de persistencia
function GuildDonationHelper:LoadVariables() 

	self:ShowSystemMessage("LoadVariables");
	
	if(self.db.char.totalMoney==nil) then
		self.db.char.totalMoney=0;	
	end
	
	if(self.db.char.totalCredit==nil) then
		self.db.char.totalCredit=0;	
	end
	
	if(self.db.char.taxAmount==nil) then
		self.db.char.taxAmount=0;
	end	
	
	if(self.db.char.creditTax==nil) then
		self.db.char.creditTax=0;
	end	
	
	if(self.db.char.paymentTax==nil) then
		self.db.char.paymentTax=50;
	end		
	
	if(self.db.char.totalSmallChanges==nil) then
		self.db.char.totalSmallChanges=0;	
	end	
	
	if(self.db.char.totalHistoryPayed==nil) then
		self.db.char.totalHistoryPayed=0;	
	end
	
	if(self.db.char.totalComerce==nil) then
		self.db.char.totalComerce=0;	
	end
	
	if(self.db.char.totalMail==nil) then
		self.db.char.totalMail=0;	
	end
	
	if(self.db.char.totalQuest==nil) then
		self.db.char.totalQuest=0;	
	end			
	
	if(self.db.char.showActivity==nil) then
		self.db.char.showActivity=1;	
	end
	
	if(self.db.char.userList==nil) then
		self.db.char.userList={};	
	end
		
	PARAMETER=
		{
			totalHistoryPayed		=self.db.char.totalHistoryPayed,
			totalMoney				=self.db.char.totalMoney,
			totalCredit				=self.db.char.totalCredit,
			taxAmount				=self.db.char.taxAmount,
			paymentTax				=self.db.char.paymentTax,
			totalSmallChanges		=self.db.char.totalSmallChanges,
			totalComerce			=self.db.char.totalComerce,
			totalMail				=self.db.char.totalMail,
			totalQuest				=self.db.char.totalQuest,
			showActivity			=self.db.char.showActivity,	
			userList				=self.db.char.userList		
		}
end

--Guarda las variables en disco
function GuildDonationHelper:SaveVariables()
	self:ShowSystemMessage("SaveVariables");    
     
    self.db.char.totalMoney			=	PARAMETER["totalMoney"];        
    self.db.char.totalCredit		=	PARAMETER["totalCredit"];        
    self.db.char.totalSmallChanges	=	PARAMETER["totalSmallChanges"];
    self.db.char.totalComerce		=	PARAMETER["totalComerce"];
    self.db.char.totalMail			=	PARAMETER["totalMail"];
    self.db.char.taxAmount			=	PARAMETER["taxAmount"];
    self.db.char.creditTax			=	PARAMETER["creditTax"];        
    self.db.char.paymentTax			=	PARAMETER["paymentTax"];     
    self.db.char.totalQuest			=	PARAMETER["totalQuest"];
    self.db.char.totalHistoryPayed	=	PARAMETER["totalHistoryPayed"];
    self.db.char.showActivity		=	PARAMETER["showActivity"];    
    self.db.char.userList			=	PARAMETER["userList"];                  	
    
end

--Funcion que maneja los comandos del teclado
function GuildDonationHelper:SlashCmdHandler(msg)
	
	--mensaje en minusculas
	msg=msg:lower();	
	
	self:ShowSystemMessage("SlashCmdHandler:"..msg);		
	
	if(msg=="set") then
		--Envia el estado de la variables la hermandad
		ChatMessage(GDHELPER_SYNC);		
		self:SendCommMessage(CHANNELNAME.."RESPONSE", self:BuildMessage(), "GUILD");
	end
	
	if(msg:match("get .+")~=nil) then
		local player=string.sub(msg, 5)
		
		if(player:len()>0 and player~=nil) then
			ChatMessage(GDHELPER_SYNC..player);		
		
			GuildDonationHelper:SendCommMessage(CHANNELNAME.."REQUEST", "REPORT", "WHISPER",player);
		end
	end
	
	--Modo depuracion
	if(msg=="debug") then
		
		if (ISDEBUG) then		
			ISDEBUG	= false;
			self:Print("Debug mode DISABLED");
		else
			ISDEBUG= true;
			self:Print("Debug mode ENABLED");
		end
	end
	
	if (msg=="?") then				
		self:Print(GDHELPER_MENUSHOW);
		self:Print(GDHELPER_MENUSET);
		self:Print(GDHELPER_MENUGET);
		self:Print(GDHELPER_MENUDEBUG);
	end 
	
	if(msg=="show") then
		FrmMiniTaxFrame:Show();
	end
	
	if(msg==nil or msg=="") then	
		self:ShowSystemMessage("Inicializating Windows options");	
		self:FrmOptions_Init();	
		self:ShowSystemMessage("Opening windows options");	
		FrmOptions:Show();	
	end
end

--Coloca la tasa de impuesto
function GuildDonationHelper:SetGuildTaxRate()

	--Obtiene el mensaje del dia 
	local guildDayMessage = GetGuildRosterMOTD();
	guildDayMessage = guildDayMessage:lower();
	
	--Obtiene la informacion de la hermandad
	local guildINFO = GetGuildInfoText();	
	guildINFO = guildINFO:lower();
	
	--Obtiene las tasas desde los 2 textos
	local fromGuildInfo	=ExtractTaxFromText(guildINFO,"gdhtax:%d+");
	
	local fromDayMessage=ExtractTaxFromText(guildDayMessage,"gdhtax:%d+");
			
	self:ShowSystemMessage("Tax: GuilInfo: "..fromGuildInfo.." DayMessage:"..fromDayMessage);
	
	local taxCuota=0;
	local creditTax=0;
	
	--Asigna la tasa mas grande
	if(fromGuildInfo>fromDayMessage) then
		taxCuota=fromGuildInfo;
	else
		taxCuota=fromDayMessage;
	end	
	
	--Valor por defecto, luego de buscar ambas dieron cero
	if(taxCuota==0) then
		if(PARAMETER["taxAmount"]~=nil and PARAMETER["taxAmount"]>0) then
			taxCuota=PARAMETER["taxAmount"];		
		else
			taxCuota=5;
		end		
	end
	
	local creditTax=ExtractTaxFromText(guildINFO,"gdhcredit:%d+");
		
    --Valor por defecto, luego de buscar ambas dieron cero
	if(creditTax==0) then
		if(PARAMETER["creditTax"]~=nil and PARAMETER["creditTax"]>0) then
			creditTax=PARAMETER["creditTax"];		
		else
			creditTax=5;
		end		
	end
	
	self:ShowSystemMessage("Credit: GuilInfo: "..creditTax.."%");
	
	--Coloca los parametros
	PARAMETER["creditTax"]=creditTax;
	PARAMETER["taxAmount"]=taxCuota;
	
end

--Busca la tasa de impuesto en el texto especificado
function ExtractTaxFromText(text,pattern)
	local value=0;
	
	local finded = text:match(pattern);
	if(finded ~= nil) then
		--Extrae el numero
		finded = finded:match("%d+");
					
		if(finded ~= nil) then	
			--Convierte tipo numero
			local tax=finded+0;		
			if(tax<=100 and tax>=0) then
				--Ajusta la tasa de impuesto
				value = tax;
			end	
		end	
	else 
		tax=0;
	end	
	
	return value;
end

--Construye un mensaje con la informacion del addon
function GuildDonationHelper:BuildMessage() 

	local commData=
	{
		totalHistoryPayed	= PARAMETER["totalHistoryPayed"],
		totalMoney			= PARAMETER["totalMoney"],
		taxAmount			= PARAMETER["taxAmount"],
		totalCredit			= PARAMETER["totalCredit"]
	};
			
	local serialized = self:Serialize(commData);
		
	return serialized;
	
	--local playerName = UnitName("player");
	--return "T:"..PARAMETER["totalHistoryPayed"].." Q:"..PARAMETER["totalMoney"].." Tax:"..PARAMETER["taxAmount"];
end

--Funcion para mostrar mensajes de depuracion
function GuildDonationHelper:ShowSystemMessage(msg)
	if(ISDEBUG) then
		self:Print(msg);		
	end
end

--Devuelve el estado de GuilDonation a quien lo solicite
function GuildDonationHelper:CHAT_MSG_WHISPER(event,message, sender)

	local header=strsub(message,1,4);
	
	if (header == "!gdh") then		
		local message="Total:"..GetCoinText(PARAMETER["totalHistoryPayed"]," ").." Quote:"..GetCoinText(PARAMETER["totalMoney"]," ").." Tax:"..PARAMETER["taxAmount"].."%";
		
		SendChatMessage(message, "WHISPER", nil, sender);
	end
end

--Muestra mensajes al sistema
function ChatMessage(message)
	if(PARAMETER["showActivity"]==1) then
		DEFAULT_CHAT_FRAME:AddMessage("GuildDonationHelper:"..message);	
	end
end

