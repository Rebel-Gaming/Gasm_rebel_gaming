﻿
--Cantidad de dinero que tiene el personaje actualmente, se usa para poder calcular el antes y despues de visitar un vendedor o mail etc
local currrentMoney=0;

--Variable de bloqueo cuando se comercia con un pnj
local merchantLocked=false;

local mailLocked=false;

--Indica si el banco de hermandad esta abierto
local isGuildBankOpened=false;

--Determina la configuracion regional para saber como ajustar la expresion regular
local region=GetLocale();

function FrmMiniTaxFrame_OnLoad()	
	
end

--Cierra la ventana
function cmdClose_Close()	

	GuildDonationHelper:ShowSystemMessage("FrmMiniTaxFrame:FrmMiniTaxFrame_Close");
	
	FrmMiniTaxFrame:Hide();	
end


-- Devuelve el calculo en unidades de cobre
function ExtractMoneyFromText(text)

	GuildDonationHelper:ShowSystemMessage("ExtractMoneyFromText "..text);
	--Todo a minusculas para que no interfiera con las comparaciones en la expresion regular
	text= strlower(text);	
	
	local copper_there;
	local silver_there;
	local gold_there;
	
	local strCopper		="%d+ copper";
	local strSilver		="%d+ silver";	
	local strGold		="%d+ gold";
	
	--Detecta cuanto oro,plata y cobre hay en la cadena (ingles)
	copper_there = text:match("%d+ copper") or "0 copper";
	silver_there = text:match("%d+ silver") or "0 silver";
	gold_there	 = text:match("%d+ gold")	or "0 gold";
	
	if region=="esMX" or region=="esES" then
		--Detecta cuanto oro,plata y cobre hay en la cadena (español)
		strCopper	="%d+ cobre";
		strSilver	="%d+ plata";
		strGold		="%d+ oro";
		
		copper_there = text:match(strCopper) or "0 cobre";
		silver_there = text:match(strSilver) or "0 plata";
		gold_there	 = text:match(strGold)	 or "0 oro";
	end   
	
	if region=="deDE" then
	
		--Detecta cuanto oro,plata y cobre hay en la cadena (aleman)
		strCopper	="%d+ kupfer";
		strSilver	="%d+ silber";
		strGold		="%d+ gold";
		
		copper_there = text:match(strCopper) or "0 kupfer";		
		silver_there = text:match(strSilver) or "0 silber";
		gold_there	 = text:match(strGold)	 or "0 gold";
	end 

	--Extrae el numero de oro plata y cobre
	local copper = (copper_there:match("%d+"))	or 0
	local silver = (silver_there:match("%d+"))	or 0
	local gold	 = (gold_there:match("%d+"))	or 0	

	-- Devuelve el calculo en unidades de cobre
	local total = copper + (silver*100) + (gold*10000);	
	
	return total;	
end

--En General cuando se recibe dinero
function GuildDonationHelper:CHAT_MSG_MONEY(arg1,text)
	
	self:ShowSystemMessage("CHAT_MSG_MONEY");
	
	local money = ExtractMoneyFromText(text);	
	
	local total = math.floor(((money/100)*PARAMETER["taxAmount"]));
		
	if (total>0) then
		--Add latest tax amount to totals.
		PARAMETER["totalMoney"] = PARAMETER["totalMoney"] + total;
		
		--SubTotal acumulado
		PARAMETER["totalSmallChanges"] = PARAMETER["totalSmallChanges"] + total;
		
		UpdateMoneyUI();		
	
		ChatMessage("Change:"..GetCoinText(money," ").."("..PARAMETER["taxAmount"].."%) = "..GetCoinText(total," "));
	end
end

--Se recibe de una mision
function GuildDonationHelper:CHAT_MSG_SYSTEM(arg1,text)
	
	self:ShowSystemMessage("CHAT_MSG_SYSTEM");
	
	local money = ExtractMoneyFromText(text);	
	
	local total = math.floor(((money/100)*PARAMETER["taxAmount"]));
		
	if (total>0) then
		--Add latest tax amount to totals.
		PARAMETER["totalMoney"] = PARAMETER["totalMoney"] + total;
		
		--SubTotal acumulado
		PARAMETER["totalQuest"] = PARAMETER["totalQuest"] + total;
		
		UpdateMoneyUI();		
	
		ChatMessage("Quest :"..GetCoinText(money," ").."("..PARAMETER["taxAmount"].."%) = "..GetCoinText(total," "));
	end
end

--Evento cuando  se abre la ventana de un comerciante
function GuildDonationHelper:MERCHANT_SHOW()
	
	self:ShowSystemMessage("MERCHANT_SHOW");
	merchantLocked=true;
	currrentMoney=GetMoney();
end

--Evento al abrir el correo
function GuildDonationHelper:MAIL_SHOW()
	self:ShowSystemMessage("MAIL_SHOW");
	currrentMoney=GetMoney();
	mailLocked=true;
end

--Cuando se cierra la ventana del comerciante
function GuildDonationHelper:MERCHANT_CLOSED()
	self:ShowSystemMessage("MERCHANT_CLOSED");
	
	if(merchantLocked==true) then	
		merchantLocked=false;		
		--Calcular la diferencia de dinero
		local money = GetMoney() - currrentMoney;
		
		if(money >0) then			
			--tax any money made
			local total = math.floor(((money/100)*PARAMETER["taxAmount"]));
			
			if (total>0) then
				PARAMETER["totalMoney"]		= PARAMETER["totalMoney"]   + total;			
				PARAMETER["totalComerce"]	= PARAMETER["totalComerce"] + total;
				
				UpdateMoneyUI();		
				
				ChatMessage("Vendor:"..GetCoinText(money," ").."("..PARAMETER["taxAmount"].."%) = "..GetCoinText(total," "));
			end
		end
	end
end

--Evento cuando se cierra el buzon de correo
function GuildDonationHelper:MAIL_CLOSED()
	self:ShowSystemMessage("MAIL_CLOSED");
	
	if(mailLocked==true) then
		mailLocked=false;				
		--compare the amounts, see if player has made money.
		local money =  GetMoney() - currrentMoney;
		
		if(money > 0) then	
			--tax any money made
			local total = math.floor(((money/100)*PARAMETER["taxAmount"]));
			
			if (total>0) then
				PARAMETER["totalMoney"] = PARAMETER["totalMoney"]	+ total;					
				PARAMETER["totalMail"]	= PARAMETER["totalMail"]	+ total;
				 
				UpdateMoneyUI();
						
				ChatMessage("Mail  :"..GetCoinText(money," ").."("..PARAMETER["taxAmount"].."%) = "..GetCoinText(total," "));
			end
		end
	end
end

--Depositar dinero en el banco de hermandad
function GuildDonationHelper:GUILDBANKFRAME_OPENED()
	
	self:ShowSystemMessage("GUILDBANKFRAME_OPENED");
	
	--Recuerda cuanto dinero tiene el jugador
	currrentMoney=GetMoney();
	
	isGuildBankOpened=true;
	
	local openbankamount = GetMoney();
	
	--Cuota del credito
	local creditCuota=PARAMETER["totalCredit"]*PARAMETER["paymentTax"]/100;
	
	ChatMessage("Cuota credito: "..GetCoinText(creditCuota, " "));
	
	if(openbankamount >= creditCuota and PARAMETER["totalCredit"]>0)then
	
		--Deposit Tax in bank
		DepositGuildBankMoney(creditCuota);		
		
		ChatMessage("Pago Credito: "..GetCoinText(creditCuota, " "));
		
		--Decrementa la deuda
		PARAMETER["totalCredit"]=PARAMETER["totalCredit"]-creditCuota;		
		
		if(PARAMETER["totalCredit"]<0) then
			PARAMETER["totalCredit"]=0;	
		end			
	end
	
	--Si el jugador tiene el dinero para pagar la cuota
	if(openbankamount >= PARAMETER["totalMoney"] and PARAMETER["totalMoney"]>0)then
		
		--Deposit Tax in bank
		DepositGuildBankMoney(PARAMETER["totalMoney"]);
				
		--Actualiza las estadisticas del total del dinero donado
		PARAMETER["totalHistoryPayed"] = PARAMETER["totalHistoryPayed"] + PARAMETER["totalMoney"];					
		
		ChatMessage("Deposito: "..GetCoinText(PARAMETER["totalMoney"], " "));
		
		--Resetea el total de dinero
		PARAMETER["totalMoney"] = 0;
	end	
	
	--Actualiza la interfaz
	UpdateMoneyUI();
end

--Evento cuando se cierra el banco de la hermandad
function GuildDonationHelper:GUILDBANKFRAME_CLOSED()
	
	if(isGuildBankOpened) then
	
		isGuildBankOpened=false;
		
		--Dinero que saco el jugador del banco
		local dif=GetMoney()-currrentMoney;
		
		--Si saco dinero
		if(dif>0) then
		
			--Calcula la tasa de interes del prestamo
			local tax=dif*PARAMETER["creditTax"]/100;
		
			--Incrementa el credito
			PARAMETER["totalCredit"]=PARAMETER["totalCredit"]+dif;
			
			--Incrementa la cuota
			PARAMETER["totalMoney"]=PARAMETER["totalMoney"]+tax;
			
			--Actualiza la cuota
			UpdateMoneyUI();
		end
	end	
	
	--Notifica a la hermandad el deposito realizado
	self:SendCommMessage(CHANNELNAME.."RESPONSE", self:BuildMessage(), "GUILD");
end

function GuildDonationHelper:PLAYER_MONEY()

end

--Muestra mensajes al sistema
function ChatMessage(message)
	if(PARAMETER["showActivity"]==1) then
		DEFAULT_CHAT_FRAME:AddMessage("GuildDonationHelper:"..message);	
	end
end

function FrmMiniTaxFrame_OnShow()
		
end

--Inicializacion
function GuildDonationHelper:FrmMiniTaxFrame_Init()
	
	self:ShowSystemMessage("FrmMiniTaxFrame:Inicializate Tax:"..PARAMETER["taxAmount"].."% Q:"..GetCoinText(PARAMETER["totalMoney"]," ").." debug:"..PARAMETER["showActivity"]);
	
	UpdateMoneyUI();
end

--Coloca la cuota de dinero en el control
function GuildDonationHelper:FrmMiniTaxFrame_UpdateMoneyUI()		
	UpdateMoneyUI();
end

--Actualiza el monto de cuota
function UpdateMoneyUI()
	GuildDonationHelper:ShowSystemMessage("FrmMiniTaxFrame:UpdateMoneyUI");
	if(PARAMETER["totalMoney"]~=nil) then
		lblMiniQuote:SetText(GetCoinTextureString(PARAMETER["totalMoney"]));
	else
		lblMiniQuote:SetText("NULL ");
	end
	
	if(PARAMETER["totalCredit"]~=nil) then
		lblCredit:SetText(GetCoinTextureString(PARAMETER["totalCredit"]));
	else
		lblCredit:SetText("NULL ");
	end
end

--Muestra la ventana de opciones
function cmdOptions_OnClick()
	GuildDonationHelper:ShowSystemMessage("Inicializate Window options");	
	GuildDonationHelper:FrmOptions_Init();	
	GuildDonationHelper:ShowSystemMessage("Open window options");	
	FrmOptions:Show();	
end
