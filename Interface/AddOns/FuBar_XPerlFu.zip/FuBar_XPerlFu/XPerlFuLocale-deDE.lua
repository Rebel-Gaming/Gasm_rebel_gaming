local L = AceLibrary("AceLocale-2.2"):new("FuBar_XPerlFu")

L:RegisterTranslations("deDE", function() return {
	["Open Options"] = "Optionen \195\182ffnen",
	["Open XPerl Options Frame"] = "XPerl-Optionen Fenster \195\182ffnen",
	["|c00FFFFFFLeft click|r for Options (and to |c0000FF00unlock frames|r)"] = "|c00FFFFFFLinksklick|r f\195\188r Optionen (und Frames entsperren)",
	}
end)