local L = AceLibrary("AceLocale-2.2"):new("FuBar_XPerlFu")

L:RegisterTranslations("enUS", function() return {
	["Open Options"] = true,
	["Open XPerl Options Frame"] = true,
	["|c00FFFFFFLeft click|r for Options (and to |c0000FF00unlock frames|r)"] = true,
	}
end)