-- TODO localisation
local L = Rock("LibRockLocale-1.0"):GetTranslationNamespace("FuBar_DBMFu")

DBMFu = Rock:NewAddon("DBMFu", "LibRockConfig-1.0", "LibRockDB-1.0", "LibFuBarPlugin-3.0")
local self = DBMFu

self:SetDatabase("DBMFuDB")
self:SetFuBarOption("tooltipType", "GameTooltip")
self:SetFuBarOption('cannotDetachTooltip', true)
self:SetFuBarOption('hasNoColor', true)
self:SetFuBarOption("iconPath", [[Interface\icons\Spell_Shadow_NetherCloak]])	
	
function DBMFu:OnInitialize()
	local optionsTable = {
		name = "FuBar_DBMFu",
		desc = self.notes,
		handler = DBMFu,
		type = 'group',
		args = {}
	}
	self:SetConfigTable(optionsTable)
	self.OnMenuRequest = optionsTable
end

function DBMFu:OnEnable()

end

function DBMFu:OnFuBarClick(button)
      DBMMinimapButton:GetScript("OnClick")()
end

function DBMFu:OnUpdateFuBarTooltip()
	-- TODO localisation
	GameTooltip:AddLine("|c00FFFFFFLeft click|r to toggle Deadly Boss Mods Options")
end

function DBMFu:OnUpdateFuBarText()
    if self:IsFuBarTextShown() then
        self:SetFuBarText("DBMFu")
    end
    if not self:IsFuBarIconShown() then
        self:HideFuBarIcon()
    end
end

