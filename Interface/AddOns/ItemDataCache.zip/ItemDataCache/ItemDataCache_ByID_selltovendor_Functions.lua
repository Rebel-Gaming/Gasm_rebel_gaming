if (not ItemDataCache) then
  ItemDataCache = {}
  IDC = ItemDataCache
  ItemDataCache.OnInit = {}
  ItemDataCache.OnUpdate = {}
  ItemDataCache.Get = {}
end

local ItemDataCache = ItemDataCache

-- cache for speed
local ItemDataCache_ByID_selltovendor                    --  = ItemDataCache_ByID_selltovendor
local ItemID2sellprice = ItemDataCacheE_ByID_selltovendor

-- local ItemDataCacheLocal_ByID_selltovendor
-- postpone this after variables load
function ItemDataCache.OnInit.ByID_selltovendor()
	ItemDataCacheLocal_ByID_selltovendor = ItemDataCacheLocal.ByID_selltovendor
	-- self-destruct
	ItemDataCache.OnInit.ByID_selltovendor = nil
end

function ItemDataCache.OnUpdate.ByID_selltovendor()
end

function ItemDataCache.Get.ByID_selltovendor(itemID, ...)
	local onlyStatic=...
	return ((not onlyStatic and (ItemDataCacheLocal_ByID_selltovendor[itemID])) or
		ItemID2sellprice[itemID])
end

