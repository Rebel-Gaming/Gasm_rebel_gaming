function ItemDataCache.ScanMerchantItems()
	for itemIdx=1, GetMerchantNumItems() do
	        local _, _, price, quantity, numAvailable, isUsable, extendedCost = GetMerchantItemInfo(itemIdx)
		itemLink = GetMerchantItemLink(itemIdx)
		ItemDataCache.Chatback(price.." "..quantity.." "..tostring(extendedCost).." "..link)
		-- itemID=tonumber(strmatch(scaningLink, ".*item:(%d+):.*"))
		-- ItemDataCache.UpdateLocalDataByID("ByID_buyfromvendor", itemID, price)
	end
end
