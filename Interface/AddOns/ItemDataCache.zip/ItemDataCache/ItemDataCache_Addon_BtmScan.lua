if (not ItemDataCache) then ItemDataCache = {} end
local ItemDataCache=ItemDataCache

local oldBtmScanGetVendorPrice
local ItemDataCacheGetByID_selltovendor=ItemDataCache.Get.ByID_selltovendor
function ItemDataCache.NewBtmScanGetVendorPrice(itemID, count)
	local myPrice=ItemDataCacheGetByID_selltovendor(itemID)
	if(not myPrice) then return oldBtmScanGetVendorPrice(itemID, count) end
	if (count and count > 1) then return myPrice * count else return myPrice end
end

function ItemDataCache.OverrideBtmScan()
	if((not BtmScan) or (not BtmScan.GetVendorPrice)) then return false end
	oldBtmScanGetVendorPrice=BtmScan.GetVendorPrice
	BtmScan.GetVendorPrice=ItemDataCache.NewBtmScanGetVendorPrice
	-- self-destruct to free memory and avoid repeated hooking
	ItemDataCache.OverrideBtmScan=nil
end
