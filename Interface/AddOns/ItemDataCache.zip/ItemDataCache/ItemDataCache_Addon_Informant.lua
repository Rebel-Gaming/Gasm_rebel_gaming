local ItemDataCache = ItemDataCache

local oldInformantGetItem
local ItemDataCacheGetByID_selltovendor = ItemDataCache.Get.ByID_selltovendor
function ItemDataCache.NewInformantGetItem(itemID, ...)
	local dataItem = oldInformantGetItem(itemID, ...)
	if (not dataItem) then return nil end
	local myPrice=ItemDataCacheGetByID_selltovendor(itemID)
--	local myPrice = ItemDataCache.Get.ByID_selltovendor(itemID)
	if (myPrice) then dataItem.sell = myPrice end
	return dataItem
end

function ItemDataCache.OverrideInformant()
	-- ItemDataCache.Chatback("here1" .. tostring(Infortmant)) --  tostring(Informant.GetITem))
	if ((not Informant) or (not Informant.GetItem)) then return false end
	oldInformantGetItem = Informant.GetItem
	ItemDataCache.OriginalInformantGetItem = oldInformantGetItem
	Informant.GetItem = ItemDataCache.NewInformantGetItem
	-- self-destruct to free memory and avoid repeated hooking
	ItemDataCache.OverrideInformant = nil
end
