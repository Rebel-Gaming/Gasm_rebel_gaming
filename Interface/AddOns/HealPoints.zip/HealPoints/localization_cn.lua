
if (GetLocale() == "zhCN") then
  HealPointsBSL = { };

	HealPointsBSL.SOCKET_MSG = "<Shift+右键点击打开镶嵌界面>";
	HealPointsBSL.GEM_TYPE = "宝石";
	HealPointsBSL.AND = "和";
	HealPointsBSL.ARMOR = "护甲";
	HealPointsBSL.BLUE_SOCKET = "蓝色插槽";
	HealPointsBSL.RED_SOCKET = "红色插槽";
	HealPointsBSL.YELLOW_SOCKET = "黄色插槽";

	HealPointsBSL.PATTERNS_SETEQUIP = {
    -- General patterns
    { pattern = "Increases spell power by (%d+)%.", effect = "HEAL" },
    { pattern = "Restores (%d+) mana per 5 sec%.", effect = "MANAREG" },
    { pattern = "Restores (%d+) mana every 5 sec%.", effect = "MANAREG" },
    { pattern = "Improves critical strike rating by (%d+)%.", effect = "SPELLCRITRATING" },
    { pattern = "Increases your critical strike rating by (%d+)%.", effect = "SPELLCRITRATING" },
    { pattern = "Improves haste rating by (%d+)%.", effect = "SPELLHASTERATING" },
    { pattern = "Allow (%d+)%% of your Mana regeneration to continue while casting%.", effect = "CASTINGREG"}, -- Primal Mooncloth
    { pattern = "Increases spell power by (%d+)%% of your total Intellect%.", effect = "HEALFROMINT" }, -- Whitemend and Spellfire

		-- Paladin sets
		{ pattern = "Increases the critical effect chance of your Flash of Light by (%d+)%%%.", effect = "CRIT_FOL"}, -- Arena
    { pattern = "Increases the effective spell power of your Holy Shock when used as a healing spell by (%d+)%%%.", effect = "AVG_PC_HS"}, -- Arena
		{ pattern = "使你的圣光术的爆击几率提高(%d+)%%。", effect = "CRIT_HL"}, -- Tier 6
		{ pattern = "使你的圣光闪现的治疗效果提高(%d+)%%。", effect = "AVG_PC_FOL"}, -- Tier 6 

    -- Priest sets
		{ pattern = "使你的恢复术的持续时间延长(%d+)秒。", effect = "DURATION_RENEW"}, -- AQ40, Tier 5
		{ pattern = "使你的治疗祷言法术所消耗的法力值减少(%d+)%%点。", effect = "MANA_PC_POH"}, -- Tier 6 
		{ pattern = "使你的强效治疗术的治疗效果提高(%d+)%%。", effect = "AVG_PC_GH"}, -- Tier 6

    -- Druid sets
		{ pattern = "使你的愈合法术的持续时间延长(%d+)秒。", effect = "DURATION_REGR"}, -- Tier 5
		{ pattern = "使你的生命绽放法术的最终治疗量提高(%d+)点。", effect = "AVG_BURST_LIFEBL"}, -- Tier 5
		{ pattern = "Increases the healing from your Healing Touch ability by (%d+)%%%.", effect = "AVG_PC_HT"}, -- Tier 6 

    -- Shaman sets
		{ pattern = "使你的次级治疗波所消耗的法力值减少(%d+)%%。", effect = "MANA_PC_LHW"}, -- Tier 5
		{ pattern = "你的治疗链所消耗的法力值减少(%d+)%%。", effect = "MANA_PC_CHAIN"}, -- Tier 6
		{ pattern = "使你的治疗链所恢复的生命值提高(%d+)%%。", effect = "AVG_PC_CHAIN"}, -- Tier 6

    -- Librams
		{ pattern = "圣光术的治疗效果提高最多(%d+)点。", effect = "MANA_ABS_HL"}, 
		{ pattern = "使圣光闪现的治疗效果提高最多(%d+)点。", effect = "AVG_ABS_FOL"},
		{ pattern = "圣光闪现的治疗效果提高最多(%d+)点。", effect = "AVG_ABS_FOL"},
		{ pattern = "使你的圣光闪现和圣光术由光明祝福而获得的效果加成提高(%d+)点。", effect = "AVG_ABS_BOL"},
		{ pattern = "Increases healing done by Holy Light by up to (%d+)%.", effect = "AVG_ABS_HL"},

    -- Idols
		{ pattern = "使你的生命绽放法术的持续治疗效果提高最多(%d+)点。", effect = "AVG_BURST_LIFEBL"},
		{ pattern = "Reduces the mana cost of Rejuvenation by (%d+)%.", effect = "MANA_ABS_REJUV"},
		{ pattern = "使你的治疗之触法术的治疗量提高(%d+)点。", effect = "AVG_ABS_HT"},
		{ pattern = "使你的治疗之触所恢复的生命值提高(%d+)点。", effect = "AVG_ABS_HT"},
		{ pattern = "你每次施放治疗之触都可以回复最多(%d+)点法力值。", effect = "MANA_REFUND_HT"},
		{ pattern = "使你的愈合法术所消耗的法力值减少(%d+)点。", effect = "MANA_ABS_REGR"},
		{ pattern = "使回春术所恢复的生命值提高最多(%d+)点。", effect = "AVG_ABS_REJUV"},
		{ pattern = "回春术的治疗效果提高最多(%d+)点。", effect = "AVG_ABS_REJUV"},
		{ pattern = "使你的生命绽放法术的最终治疗量提高(%d+)点。", effect = "AVG_HOT_LIFEBL"},

    -- Totems
		{ pattern = "你每次施放次级治疗波都可以回复最多(%d+)点法力值。", effect = "MANA_REFUND_LHW"}, -- TODO: Implement
		{ pattern = "使你的治疗链的基础治疗量提高(%d+)点。", effect = "AVG_ABS_CHAIN"},
		{ pattern = "使次级治疗波的治疗效果提高最多(%d+)点。", effect = "AVG_ABS_LHW"},
		{ pattern = "次级治疗波的治疗效果提高最多(%d+)点。", effect = "AVG_ABS_LHW"},
		{ pattern = "使次级治疗波所恢复的生命值提高最多(%d+)点。", effect = "AVG_ABS_LHW"},
		{ pattern = "Reduces the base mana cost of Chain Heal by (%d+)%.", effect = "MANA_ABS_CHAIN"},
		{ pattern = "治疗链的法力值消耗降低(%d+)点。", effect = "MANA_ABS_HW"},
		{ pattern = "治疗波的治疗效果提高最多(%d+)点。", effect = "AVG_ABS_HW"},
 	};

	-- generic patterns have the form "+xx bonus" or "bonus +xx" with an optional % sign after the value.

	-- first the generic bonus string is looked up in the following table
	HealPointsBSL.PATTERNS_GENERIC_LOOKUP = { -- must be lower case
		["所有属性"] 			= {"INT", "SPI", "AGI"},
		["智力"]			= "INT",
		["精神"] 				= "SPI",
		["敏捷"]      = "AGI",

		["法术治疗"] 		= "HEAL",
		["治疗"] = "HEAL",
		["increases healing"] 	= "HEAL",
		["法术伤害和治疗"] = "HEAL",
		["法术治疗和伤害"] = "HEAL",
		["伤害和治疗法术"] = "HEAL",
		["法术伤害和治疗"] = "HEAL",
		["每5秒法力回复"] 	= "MANAREG",
		["每5秒法力回复"] 	= "MANAREG",
		["每5秒法力回复"] 	= "MANAREG",
		["每5秒法力回复"] 	= "MANAREG",
		["每5秒法力回复"] 	= "MANAREG",
		["法术爆击等级"] 	= "SPELLCRITRATING",
		["法术爆击等级"] 	= "SPELLCRITRATING",
		["法术爆击等级"] 	= "SPELLCRITRATING",
		["法术急速等级"] = "SPELLHASTERATING",
		["法术伤害"] 		= "HEAL", -- Spell Power enchant also increase +healing (added in patch 1.12)
		["法力回复"] 			= "MANAREG",
		["法力"]				= "MANA",
		["法力值"]				= "MANA",
	};

	-- finally if we got no match, we match against some special enchantment patterns.
	HealPointsBSL.PATTERNS_OTHER = {
		{ pattern = "每5秒法力回复(%d+)", effect = "MANAREG" },

		{ pattern = "初级巫师之油", effect = "HEAL", value = 8 },
		{ pattern = "次级巫师之油", effect = "HEAL", value = 16 },
		{ pattern = "巫师之油", effect = "HEAL", value = 24 },
		{ pattern = "卓越巫师之油", effect = {"HEAL", "SPELLCRIT"}, value = {36, 1} },

		{ pattern = "初级法力之油", effect = "MANAREG", value = 4 },
		{ pattern = "次级法力之油", effect = "MANAREG", value = 8 },
		{ pattern = "卓越法力之油", effect = { "MANAREG", "HEAL"}, value = {12, 25} },
		{ pattern = "超级法力之油", effect = "MANAREG", value = 14 },

    { pattern = "活力", effect = "MANAREG", value = 4 },

    { pattern = "%+(%d+) Spell Damage and Minor Run Speed Increase", effect = "HEAL"},
  };
end
