
if (GetLocale() == "enUS" or GetLocale() == "enGB") then
  HealPointsBSL = { };

  HealPointsBSL.SOCKET_MSG = "<Shift Right Click to Socket>";
  HealPointsBSL.GEM_TYPE = "Gem";
  HealPointsBSL.AND = "and";
  HealPointsBSL.ARMOR = "Armor";
  HealPointsBSL.BLUE_SOCKET = "Blue Socket";
  HealPointsBSL.RED_SOCKET = "Red Socket";
  HealPointsBSL.YELLOW_SOCKET = "Yellow Socket";

  HealPointsBSL.PATTERNS_SETEQUIP = {
    -- General patterns
    { pattern = "Increases spell power by (%d+)%.", effect = "HEAL" },
    { pattern = "Restores (%d+) mana per 5 sec%.", effect = "MANAREG" },
    { pattern = "Restores (%d+) mana every 5 sec%.", effect = "MANAREG" },
    { pattern = "Improves critical strike rating by (%d+)%.", effect = "SPELLCRITRATING" },
    { pattern = "Increases your critical strike rating by (%d+)%.", effect = "SPELLCRITRATING" },
    { pattern = "Improves haste rating by (%d+)%.", effect = "SPELLHASTERATING" },
    { pattern = "Allow (%d+)%% of your Mana regeneration to continue while casting%.", effect = "CASTINGREG"}, -- Primal Mooncloth
    { pattern = "Increases spell power by (%d+)%% of your total Intellect%.", effect = "HEALFROMINT" }, -- Whitemend and Spellfire

    -- Paladin sets
    { pattern = "Increases the critical effect chance of your Flash of Light by (%d+)%%%.", effect = "CRIT_FOL"}, -- Arena
    { pattern = "Increases the effective spell power of your Holy Shock when used as a healing spell by (%d+)%%%.", effect = "AVG_PC_HS"}, -- Arena
    { pattern = "Increases the critical strike chance of your Holy Light ability by (%d+)%%%.", effect = "CRIT_HL"}, -- Tier 6
    { pattern = "Increases the spell power of your Flash of Light ability by (%d+)%%%.", effect = "AVG_PC_FOL"}, -- Tier 6 
    { pattern = "Your Holy Shock gains an additional (%d+)%% chance to critically strike%.", effect = "CRIT_HS" }, -- Tier 7
    { pattern = "The cost of your Holy Light is reduced by (%d+)%%%.", effect = "MANA_PC_HL" }, -- Tier 7

    -- Priest sets
    { pattern = "Increases the duration of your Renew spell by (%d+) sec%.", effect = "DURATION_RENEW"}, -- AQ40, Tier 5
    { pattern = "Reduces the mana cost of your Prayer of Healing ability by (%d+)%%%.", effect = "MANA_PC_POH"}, -- Tier 6 
    { pattern = "Increases the healing from your Greater Heal ability by (%d+)%%%.", effect = "AVG_PC_GH"}, -- Tier 6
    { pattern = "The cost of your Greater Heal is reduced by (%d+)%%%.", effect = "MANA_PC_GH" }, -- Tier 7

    -- Druid sets
    { pattern = "Increases the duration of your Regrowth spell by (%d+) sec%.", effect = "DURATION_REGR"}, -- Tier 5
    { pattern = "Increases the final amount healed by your Lifebloom spell by (%d+)%.", effect = "AVG_BURST_LIFEBL"}, -- Tier 5
    { pattern = "Increases the healing from your Healing Touch ability by (%d+)%%%.", effect = "AVG_PC_HT"}, -- Tier 6 
    { pattern = "The cost of your Rejuvenation is reduced by (%d+)%%%.", effect = "MANA_PC_REJUV" }, -- Tier 7

    -- Shaman sets
    { pattern = "Reduces the cost of your Lesser Healing Wave spell by (%d+)%%%.", effect = "MANA_PC_LHW"}, -- Tier 5
    { pattern = "Your Chain Heal ability costs (%d+)%% less mana%.", effect = "MANA_PC_CHAIN"}, -- Tier 6
    { pattern = "Increases the amount healed by your Chain Heal ability by (%d+)%%%.", effect = "AVG_PC_CHAIN"}, -- Tier 6
    { pattern = "Increases the healing done by your Chain Heal and Healing Wave by (%d+)%%%.", effect = "AVG_PC_CHAIN_HW" }, -- Tier 7

    -- Librams
    { pattern = "Reduces the mana cost of Holy Light by (%d+).", effect = "MANA_ABS_HL"}, 
    { pattern = "Increases spell power of Flash of Light by (%d+)%.", effect = "AVG_ABS_FOL"},
    { pattern = "Increases spell power of Holy Light by (%d+)%.", effect = "AVG_ABS_HL" },

    -- Idols
    { pattern = "Increases the spell power of the final healing value of your Lifebloom by (%d+)%.", effect = "AVG_BURST_LIFEBL"}, 
    { pattern = "Reduces the mana cost of Rejuvenation by (%d+)%.", effect = "MANA_ABS_REJUV"}, 
    { pattern = "Increases the amount healed by Healing Touch by (%d+)%.", effect = "AVG_ABS_HT"}, 
    { pattern = "Gain up to (%d+) mana each time you cast Healing Touch%.", effect = "MANA_REFUND_HT"},
    { pattern = "Reduces the mana cost of Regrowth by (%d+)%.", effect = "MANA_ABS_REGR"},
    { pattern = "Increases spell power of Rejuvenation by (%d+)%.", effect = "AVG_ABS_REJUV"}, 
    { pattern = "Increases the spell power on the periodic portion of your Lifebloom by (%d+)%.", effect = "AVG_HOT_LIFEBL"},  -- Strange that it's "on" and not "of"

    -- Totems
    { pattern = "Regain up to (%d+) mana each time you cast Lesser Healing Wave.", effect = "MANA_REFUND_LHW"}, -- TODO: Implement
    { pattern = "Increases the base amount healed by Chain Heal by (%d+)%.", effect = "AVG_ABS_CHAIN"},
    { pattern = "Increases spell power of Lesser Healing Wave by (%d+)%.", effect = "AVG_ABS_LHW"},
    { pattern = "Reduces the base mana cost of Chain Heal by (%d+)%.", effect = "MANA_ABS_CHAIN"},
    { pattern = "Reduces the mana cost of Healing Wave by (%d+)%.", effect = "MANA_ABS_HW"},
    { pattern = "Increases spell power of Healing Wave by (%d+)%.", effect = "AVG_ABS_HW"},
   };

  -- generic patterns have the form "+xx bonus" or "bonus +xx" with an optional % sign after the value.

  -- first the generic bonus string is looked up in the following table
  HealPointsBSL.PATTERNS_GENERIC_LOOKUP = { -- must be lower case
    ["all stats"]  = {"INT", "SPI", "AGI"},
    ["intellect"]  = "INT",
    ["spirit"]     = "SPI",
    ["agility"]    = "AGI",

    ["spell power"]                 = "HEAL",
    ["critical strike rating"]      = "SPELLCRITRATING",
    ["haste rating"]                = "SPELLHASTERATING",
    ["mana every 5 seconds"]        = "MANAREG",
    ["mana every 5 second"]         = "MANAREG",
    ["mana every 5 sec"]            = "MANAREG",
    ["mana per 5 seconds"]          = "MANAREG",
    ["mana per 5 sec"]              = "MANAREG",
    ["mana regen"]                  = "MANAREG",
    ["mana"]                        = "MANA",
  };

  -- finally if we got no match, we match against some special enchantment patterns.
  HealPointsBSL.PATTERNS_OTHER = {
    { pattern = "Mana Regen (%d+) per 5 sec%.", effect = "MANAREG" },

    { pattern = "Minor Wizard Oil", effect = "HEAL", value = 8 },
    { pattern = "Lesser Wizard Oil", effect = "HEAL", value = 16 },
    { pattern = "Wizard Oil", effect = "HEAL", value = 24 },
    { pattern = "Brilliant Wizard Oil", effect = {"HEAL", "SPELLCRIT"}, value = {36, 1} },

    { pattern = "Minor Mana Oil", effect = "MANAREG", value = 4 },
    { pattern = "Lesser Mana Oil", effect = "MANAREG", value = 8 },
    { pattern = "Brilliant Mana Oil", effect = { "MANAREG", "HEAL"}, value = {12, 25} },
    { pattern = "Superior Mana Oil", effect = "MANAREG", value = 14 },

    { pattern = "Vitality", effect = "MANAREG", value = 4 },
    { pattern = "Greater Vitality", effect = "MANAREG", value = 6 },

    { pattern = "%+(%d+) Spell Power and Minor Run Speed Increase", effect = "HEAL"},
    { pattern = "%+(%d+) Intellect and Chance to restore mana on spellcast", effect = "INT"},
    { pattern = "Counterweight %(%+(%d+) Haste Rating%)", effect = "SPELLHASTERATING"}, -- Hehe
  };
end
