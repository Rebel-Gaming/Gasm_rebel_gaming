
HealPointsConfigUI = { };

local valueUpdating = 0;
local SPELLLIST = { };
local SpellClassIDs = { };

local function updateSpellLists()
	local function updateSpellList(objref, funct)
		for i = 1, table.getn(SPELLLIST), 1 do
			local info ={
				text = SPELLLIST[i],
				func = funct
			};
			if (objref and type(objref) == "table") then
				info.owner = objref;
			end
			UIDropDownMenu_AddButton(info)
		end
	end

	for k in pairs(SPELLLIST) do
		SPELLLIST[k] = nil;
	end
  for i = 1, table.getn(SpellClassIDs), 1 do
    if (HealPointsSpells:getHighestSpellRank(SpellClassIDs[i]) > 0) then 
      local spell = HealPointsSpells:getSpellByClassID(SpellClassIDs[i]);
      local spellName = GetSpellInfo(spell.id);
      table.insert(SPELLLIST, spellName);
    end
  end

	if (HealPoints.db.char.power['spell'] == '') then
		HealPoints.db.char.power['spell'] = SPELLLIST[1];
	end
	if (HealPoints.db.char.endurance['spell'] == '') then
		HealPoints.db.char.endurance['spell'] = SPELLLIST[1];
	end

	UIDropDownMenu_Initialize(HealPointsPowerConfigManualSelectSpell,function()
		updateSpellList(HealPointsPowerConfigManualSelectSpell, HealPointsConfigUI.powerSpellSelected);
	end);
	UIDropDownMenu_Initialize(HealPointsEnduranceConfigManualSelectSpell,function()
		updateSpellList(HealPointsEnduranceConfigManualSelectSpell, HealPointsConfigUI.enduranceSpellSelected);
	end);
end

local function updateGUI() -- Updates GUI to match HEALPOINTS_CONFIG
	valueUpdating = 1;
	-- PowerPoints
	getglobal("HealPointsPowerConfigDuration"):SetValue(HealPoints.db.char.power['duration']);
	getglobal("HealPointsPowerConfigDurationText"):SetText(HealPoints.db.char.power['duration'].." mins");
	if (HealPoints.db.char.power['auto'] == true) then
		getglobal("HealPointsPowerConfigAutoSelect"):SetChecked(1);
		getglobal("HealPointsPowerConfigManualSelect"):SetChecked(0);
	else
		getglobal("HealPointsPowerConfigAutoSelect"):SetChecked(0);
		getglobal("HealPointsPowerConfigManualSelect"):SetChecked(1);
	end
	getglobal("HealPointsPowerConfigMana"):SetValue(HealPoints.db.char.power['mana']);
	getglobal("HealPointsPowerConfigManaText"):SetText(HealPoints.db.char.power['mana'].."%");

	-- EndurancePoints
	getglobal("HealPointsEnduranceConfigDuration"):SetValue(HealPoints.db.char.endurance['duration']);
	getglobal("HealPointsEnduranceConfigDurationText"):SetText(HealPoints.db.char.endurance['duration'].." mins");
	if (HealPoints.db.char.endurance['auto'] == true) then
		getglobal("HealPointsEnduranceConfigAutoSelect"):SetChecked(1);
		getglobal("HealPointsEnduranceConfigManualSelect"):SetChecked(0);
	else
		getglobal("HealPointsEnduranceConfigAutoSelect"):SetChecked(0);
		getglobal("HealPointsEnduranceConfigManualSelect"):SetChecked(1);
	end
	getglobal("HealPointsEnduranceConfigMana"):SetValue(HealPoints.db.char.endurance['mana']);
	getglobal("HealPointsEnduranceConfigManaText"):SetText(HealPoints.db.char.endurance['mana'].."%");

	-- SpellLists
	if (UIDropDownMenu_GetSelectedID(HealPointsPowerConfigManualSelectSpell) ~= HealPointsUtil:getTableIndex(SPELLLIST, HealPoints.db.char.power['spell'])) then
		UIDropDownMenu_SetSelectedID(HealPointsPowerConfigManualSelectSpell, HealPointsUtil:getTableIndex(SPELLLIST, HealPoints.db.char.power['spell']));
	end
	if (UIDropDownMenu_GetSelectedID(HealPointsEnduranceConfigManualSelectSpell) ~= HealPointsUtil:getTableIndex(SPELLLIST, HealPoints.db.char.endurance['spell'])) then
		UIDropDownMenu_SetSelectedID(HealPointsEnduranceConfigManualSelectSpell, HealPointsUtil:getTableIndex(SPELLLIST, HealPoints.db.char.endurance['spell']));
	end

	-- Heal-over-time
	local _, className = UnitClass("player");
	if (className == "PRIEST" or className == "DRUID") then
		getglobal("HealPointsHotConfigNumTargets"):SetValue(HealPoints.db.char.hot['numtargets']);
		getglobal("HealPointsHotConfigNumTargetsText"):SetText(HealPoints.db.char.hot['numtargets']);
	end

    if (HealPoints.db.char.replenishment == true) then
        getglobal("HealPointsOptionsConfigReplenish"):SetChecked(1);
    else
        getglobal("HealPointsOptionsConfigReplenish"):SetChecked(0);
    end
    
    if (HealPoints.db.char.divineplea == true) then
        getglobal("HealPointsOptionsConfigDivinePlea"):SetChecked(1);
    else
        getglobal("HealPointsOptionsConfigDivinePlea"):SetChecked(0);
    end    
    
	valueUpdating = 0;
end

function HealPointsConfigUI:powerSpellSelected()
	if (this.owner) then
		UIDropDownMenu_SetSelectedID(this.owner, this:GetID());
		HealPoints.db.char.power['spell'] = SPELLLIST[UIDropDownMenu_GetSelectedID(HealPointsPowerConfigManualSelectSpell)];
		HealPointsCalculator:updateHealPoints();
	end
end

function HealPointsConfigUI:enduranceSpellSelected()
	if (this.owner) then
		UIDropDownMenu_SetSelectedID(this.owner, this:GetID());
		HealPoints.db.char.endurance['spell'] = SPELLLIST[UIDropDownMenu_GetSelectedID(HealPointsEnduranceConfigManualSelectSpell)];
		HealPointsCalculator:updateHealPoints();
	end
end

function HealPointsConfigUI:init()
	local _, className = UnitClass("player");
	if (className == "PALADIN") then
		SpellClassIDs ={ HealPointsSpells.SPELL_FOL, HealPointsSpells.SPELL_HL };
	elseif (className == "PRIEST") then
		SpellClassIDs ={ HealPointsSpells.SPELL_FH, HealPointsSpells.SPELL_LH, HealPointsSpells.SPELL_HEAL,
		HealPointsSpells.SPELL_GH, HealPointsSpells.SPELL_RENEW, HealPointsSpells.SPELL_POH,
		HealPointsSpells.SPELL_HOLYNOVA, HealPointsSpells.SPELL_COH };
	elseif (className == "DRUID") then
		SpellClassIDs ={ HealPointsSpells.SPELL_HT, HealPointsSpells.SPELL_REJUV, HealPointsSpells.SPELL_REGR,
		HealPointsSpells.SPELL_LIFEBL };
	elseif (className == "SHAMAN") then
		SpellClassIDs ={ HealPointsSpells.SPELL_LHW, HealPointsSpells.SPELL_HW, HealPointsSpells.SPELL_CHAIN };
	end
end

function HealPointsConfigUI:update()
	if (valueUpdating == 0) then
		-- PowerPoints
		HealPoints.db.char.power['duration'] = getglobal("HealPointsPowerConfigDuration"):GetValue();
		getglobal("HealPointsPowerConfigDurationText"):SetText(HealPoints.db.char.power['duration'].." mins");
		if (getglobal("HealPointsPowerConfigAutoSelect"):GetChecked() == 1) then
			HealPoints.db.char.power['auto'] = true;
		else
			HealPoints.db.char.power['auto'] = false;
		end
		HealPoints.db.char.power['mana'] = getglobal("HealPointsPowerConfigMana"):GetValue();
		getglobal("HealPointsPowerConfigManaText"):SetText(HealPoints.db.char.power['mana'].."%");

		-- EndurancePoints
		HealPoints.db.char.endurance['duration'] = getglobal("HealPointsEnduranceConfigDuration"):GetValue();
		getglobal("HealPointsEnduranceConfigDurationText"):SetText(HealPoints.db.char.endurance['duration'].." mins");
		if (getglobal("HealPointsEnduranceConfigAutoSelect"):GetChecked()) then
			HealPoints.db.char.endurance['auto'] = true;
		else
			HealPoints.db.char.endurance['auto'] = false;
		end
		HealPoints.db.char.endurance['mana'] = getglobal("HealPointsEnduranceConfigMana"):GetValue();
		getglobal("HealPointsEnduranceConfigManaText"):SetText(HealPoints.db.char.endurance['mana'].."%");

		-- Heal-over-time/AoE
		HealPoints.db.char.hot['numtargets'] = getglobal("HealPointsHotConfigNumTargets"):GetValue();
		local _, className = UnitClass("player");
		if (className == "PRIEST" or className == "DRUID") then
			getglobal("HealPointsHotConfigNumTargetsText"):SetText(HealPoints.db.char.hot['numtargets']);
		end
        
		HealPointsCalculatorUI:updateSelectedSpellStats();
		HealPointsCalculator:updateHealPoints();
	end
end

function HealPointsConfigUI:reset()
	--HealPoints:ResetDB("char"); -- Doesn't work anymore for some reason
	HealPoints.db.char.power['auto'] = true;
	HealPoints.db.char.power['duration'] = 1;
	HealPoints.db.char.power['rank'] = nil;
	HealPoints.db.char.power['mana'] = 100;
	HealPoints.db.char.endurance['auto'] = true;
	HealPoints.db.char.endurance['duration'] = 5;
	HealPoints.db.char.endurance['rank'] = nil;
	HealPoints.db.char.endurance['mana'] = 0;
	HealPoints.db.char.hot['numtargets'] = 3;
	HealPoints.db.char.power['spell'] = SPELLLIST[1];
	HealPoints.db.char.endurance['spell'] = SPELLLIST[1];
	updateGUI();

	HealPointsCalculatorUI:updateSelectedSpellStats();
	HealPointsCalculator:updateHealPoints();
end

function HealPointsConfigUI:spellsChanged()
	updateSpellLists()
	updateGUI();
end

function HealPointsConfigUI:lifeblChanged()
  -- Replenishment
  if (getglobal("HealPointsOptionsConfigReplenish"):GetChecked()) then
    HealPoints.db.char.replenishment = true;
  else
    HealPoints.db.char.replenishment = false;        
  end

  -- Divine Plea
  if (getglobal("HealPointsOptionsConfigDivinePlea"):GetChecked()) then
    HealPoints.db.char.divineplea = true;
  else
    HealPoints.db.char.divineplea = false;        
  end

  HealPointsCalculator:updateStats();
  HealPointsCalculatorUI:updateSelectedSpellStats();
  HealPointsCalculator:updateHealPoints();
end

function HealPointsConfigUI:setTooltip()
  GameTooltip:SetOwner(this, "ANCHOR_RIGHT");
  if (this:GetID() == 1) then -- HoT config
    GameTooltip:SetText("Number of targets", HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
    GameTooltip:AddLine("Number of targets you try to keep the HoT constantly running on (mana permitting) or number of targets for AoE heals.");
  elseif (this:GetID() == 2) then -- Start mana
    GameTooltip:SetText("Starting mana", HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
    GameTooltip:AddLine("Percentage of mana available at the start of the computation.");
  elseif (this:GetID() == 3) then -- Replenishment
    GameTooltip:SetText("Replenishment", HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
    GameTooltip:AddLine("Assume that the Replenishment buff is always active.");  
  elseif (this:GetID() == 4) then -- Divine Plea
    GameTooltip:SetText("Divine Plea", HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
    GameTooltip:AddLine("Assume that Divine Plea is used on every cooldown.");  
  end
  GameTooltip:Show();
end


