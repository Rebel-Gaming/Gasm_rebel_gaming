
if (GetLocale() == "esES") then
  HealPointsBSL = { };

  HealPointsBSL.SOCKET_MSG = "<May\195\186s clic derecho para insertar>";
  HealPointsBSL.GEM_TYPE = "Gema";
  HealPointsBSL.AND = "y";
  HealPointsBSL.ARMOR = "armadura"; 
  HealPointsBSL.BLUE_SOCKET = "Ranura azul";
  HealPointsBSL.RED_SOCKET = "Renura roja";
  HealPointsBSL.YELLOW_SOCKET = "Ranura amarilla";

  HealPointsBSL.PATTERNS_SETEQUIP = {
    -- General patterns
    { pattern = "Aumenta el poder con hechizos (%d+) p%.", effect = "HEAL" },
    { pattern = "Mejora tu \195\173ndice de golpe cr\195\173tico (%d+) p%.", effect = "SPELLCRITRATING" },
    { pattern = "Mejora tu \195\173ndice de celeridad (%d+) p%.", effect = "SPELLHASTERATING" },
    { pattern = "Restaura (%d+) p%. de man\195\161 cada 5 s%.", effect = "MANAREG" },

    -- Paladin sets
    -- Priest sets
    -- Druid sets
    -- Shaman sets

    -- Librams
    { pattern = "Aumenta el poder con hechizos de Destello de Luz hasta (%d+) p%.", effect = "AVG_ABS_FOL"},

    -- Idols
    -- Totems
  };

  HealPointsBSL.PATTERNS_GENERIC_LOOKUP = { -- must be lower case
    ["todas las estadisticas"] = { "AGI", "INT", "SPI" },
    ["agilidad"] = "AGI",
    ["intelecto"] = "INT",
    ["esp\195\173ritu"] = "SPI",

    ["poder con hechizos" ] = "HEAL",
    ["man\195\161 cada 5 s"] = "MANAREG",
    ["man\195\161 cada 5 segundos"] = "MANAREG",
    ["man\195\161 por 5 s"] = "MANAREG",
    ["\195\173ndice de golpes cr\195\173ticos con hechizos"] = "SPELLCRITRATING",
  };

  HealPointsBSL.PATTERNS_OTHER = {
    { pattern = "Aceite de man\195\161 excelente", effect = "MANAREG", value = 14 },
    { pattern = "Vitalidad", effect = "MANAREG", value = 4 }, -- ok
  };
end