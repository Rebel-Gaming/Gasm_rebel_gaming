
local int ={ stat = "Intellect", statmod = 1 };
local spi ={ stat = "Spirit", statmod = 1 };
local mp5 ={ stat = "Mana/5s", statmod = 2.5 };
local heal ={ stat = "+Spell power", statmod = 0.7 };
local crit ={ stat = "Crit rating", statmod = 1 };
local haste ={ stat = "Haste rating", statmod = 1 };

local stats = { };
stats[1] = int;
stats[2] = spi;
stats[3] = mp5;
stats[4] = heal;
stats[5] = crit;
stats[6] = haste;

function HealPoints:PrintMVS()
  local function statTableSort(e1, e2)
    if (e1.value > e2.value) then
      return true;
    else
      return false;
    end
  end

  if HealPoints.ISHEALER then
    local iv, sv, mv, hv, cv, h2v = HealPointsCalculator:computeHealPointsDelta();
    int.value = HealPointsUtil:round(iv / int.statmod);
    spi.value = HealPointsUtil:round(sv / spi.statmod);
    mp5.value = HealPointsUtil:round(mv / mp5.statmod);
    heal.value = HealPointsUtil:round(hv / heal.statmod);
    crit.value = HealPointsUtil:round(cv / crit.statmod);
    haste.value = HealPointsUtil:round(h2v / haste.statmod);
    table.sort(stats, statTableSort);
  end

  self:Print("Most valuable stat ranking:");
  self:Print("--------------------------------------");
  for i = 1, table.getn(stats) do
    self:Print(stats[i].stat.."     "..stats[i].value.." points/cost");
  end
end

local options = {
  name = "HealPoints",
  desc = "HealPoints Configuration.",
  type = "group",
  args = {
    tooltips ={
      type = "toggle",
      name = "Values in tooltips",
      desc = "Toggles the display of HealPoints change in item tooltips.",
      order = 10,
      get = function()
        return HealPoints.db.char.tooltips == 1;
      end,
      set = function()
        HealPoints.db.char.tooltips = 1 - HealPoints.db.char.tooltips;
      end
    },
    debug ={
      type = "toggle",
      name = "Debug mode",
      desc = "Toggles the display of debug messages.",
      order = 11,
      get = function()
        return HealPoints.db.char.debug == 1;
      end,
      set = function()
        HealPoints:clearLinkCache();
        HealPoints.db.char.debug = 1 - HealPoints.db.char.debug;
      end
    },

    computemvs ={
      type = "execute",
      name = "Most valuable stats",
      desc = "Lists the most valuable stat ranking according to current gear and buffs.",
      order = 20,
      func = function()
        HealPoints:PrintMVS();
      end,
    },
    bscan ={
      type = "execute",
      name = "Special item bonuses",
      desc = "Print special set/equip bonuses detected to the console.",
      order = 21,
      func = function()
        HealPoints:listScannedBonuses();
      end
    },

    gemheader = {
      type = "header",
      name = "Gem selector",      
      desc = "",
      order = 30,
      cmdHidden = true,
    },    
    bluegems ={
      type = "select",
      name = "Blue Sockets",
      desc = "Select gem to be used for empty blue socket calculations.",
      order = 31,
      cmdHidden = true,
      width = "full",
      get = function() 
        return HealPoints.db.char.gems.blueGem;
      end,
      set = function(t, v)
        HealPoints:clearLinkCache();
        HealPoints.db.char.gems.blueGem = v;
      end,
      values = HealPointsGems.blueSocket,
    },
    redgems ={
      type = "select",
      name = "Red Sockets",
      desc = "Select gem to be used for empty red socket calculations.",
      order = 32,
      cmdHidden = true,
      width = "full",
      get = function() 
        return HealPoints.db.char.gems.redGem;
      end,
      set = function(t, v)
        HealPoints:clearLinkCache();
        HealPoints.db.char.gems.redGem = v;
      end,
      values = HealPointsGems.redSocket,
    },
    yellowgems ={
      type = "select",
      name = "Yellow Sockets",
      desc = "Select gem to be used for empty yellow socket calculations.",
      order = 33,
      cmdHidden = true,
      width = "full",
      get = function() 
        return HealPoints.db.char.gems.yellowGem;
      end,
      set = function(t, v)
        HealPoints:clearLinkCache();
        HealPoints.db.char.gems.yellowGem = v;
      end,
      values = HealPointsGems.yellowSocket,
    },
  },
};

LibStub("AceConfig-3.0"):RegisterOptionsTable("HealPoints", options, "healpoints");
LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("HealPoints", options);
LibStub("AceConfigDialog-3.0"):AddToBlizOptions("HealPoints", "HealPoints");
