
HealPointsTalents = { };

HealPointsTalents.PALADIN = {
  HEALIG = { tab = 1, num =  3 },
  DIVINT = { tab = 1, num =  4 },
  ILLUMI = { tab = 1, num =  7 },
  SANCLI = { tab = 1, num = 13 },
  HOLYGU = { tab = 1, num = 21 },

  BENEDI = { tab = 3, num = 2},
};

HealPointsTalents.PRIEST = {
  TWINDI = { tab = 1, num =  2 },
  MEDITA = { tab = 1, num =  9 },
  MENAGI = { tab = 1, num = 11 },
  MENSTR = { tab = 1, num = 13 },
  FOCUSP = { tab = 1, num = 16 },
  ENLIGH = { tab = 1, num = 17 },

  IMPREN = { tab = 2, num =  2 },
  DIVFUR = { tab = 2, num =  5 },
  IMPHEA = { tab = 2, num = 10 },
  HEAPRA = { tab = 2, num = 12 },
  SPIRED = { tab = 2, num = 13 },
  SPIGUI = { tab = 2, num = 14 },
  SPIHEA = { tab = 2, num = 16 }, 
  HOLCON = { tab = 2, num = 17 },
  EMPHEA = { tab = 2, num = 20 },
  IMPHOC = { tab = 2, num = 22 },
  DIVPRO = { tab = 2, num = 25 },
};

HealPointsTalents.DRUID = {
  GENESI = { tab = 1, num =  2 }, -- TODO: How does this work with Regrowth and Lifebloom?
  MOONGL = { tab = 1, num =  3 }, 
  NATMAJ = { tab = 1, num =  4 },
  NATSPL = { tab = 1, num =  8 }, 
  LUNGUI = { tab = 1, num = 12 },
  DREAMS = { tab = 1, num = 15 },

  NURINS = { tab = 2, num = 15 },
  HEOFWI = { tab = 2, num = 17 },
  SURFIT = { tab = 2, num = 18 },

  NATURA = { tab = 3, num =  4 },
  INTENS = { tab = 3, num =  7 },
  MASSHA = { tab = 3, num =  9 },
  TRASPI = { tab = 3, num = 10 },
  IMPREJ = { tab = 3, num = 11 },
  GIOFNA = { tab = 3, num = 13 },
  EMPOHT = { tab = 3, num = 15 }, 
  IMPREG = { tab = 3, num = 16 }, 
  LIVSPI = { tab = 3, num = 17 },
  EMPREJ = { tab = 3, num = 20 }, -- TODO: How does this work with Regrowth and Lifebloom?
  IMPTOL = { tab = 3, num = 24 },
  GOTEMO = { tab = 3, num = 25 }, -- TODO: Implement
};

HealPointsTalents.SHAMAN = {
  UNRSTO = { tab = 1, num = 13 },

  ANCKNO = { tab = 2, num =  3 },
  MENQUI = { tab = 2, num = 21 }, -- TODO: Implement

  IMHEWA = { tab = 3, num =  1 },
  TIDFOC = { tab = 3, num =  5 }, 
  PURIFI = { tab = 3, num = 15 },
  IMPCHA = { tab = 3, num = 20 },
  NATBLE = { tab = 3, num = 21 },
  TIDWAV = { tab = 3, num = 25 }, -- Supported 50%
};
    
function HealPointsTalents:getTalentRank(talent)
  local _, _, _, _, currRank, _ = GetTalentInfo(talent.tab, talent.num);
  return currRank
end

function HealPointsTalents:talentTest(tab, num)
  local name = GetTalentInfo(tab, num);
  HealPoints:Print("*"..name.."*");
end