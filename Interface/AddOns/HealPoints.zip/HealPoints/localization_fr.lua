
if (GetLocale() == "frFR") then
  HealPointsBSL = { };

  HealPointsBSL.SOCKET_MSG = "<Maj clic-droit pour sertir>";
  HealPointsBSL.GEM_TYPE = "Gemme";
  HealPointsBSL.AND = "et";
  HealPointsBSL.ARMOR = "Armure"; 
  HealPointsBSL.BLUE_SOCKET = "Ch\195\163sse bleue";
  HealPointsBSL.RED_SOCKET = "Ch\195\163sse rogue";
  HealPointsBSL.YELLOW_SOCKET = "Ch\195\163sse jaune";

  HealPointsBSL.PATTERNS_SETEQUIP = {
    -- General patterns
    { pattern = "Augmente la puissance des sorts de (%d+)%.", effect = "HEAL" },
    { pattern = "Augmente de (%d+) le score de coup critique%.", effect = "SPELLCRITRATING" },
    { pattern = "Augmente de (%d+) le score de h\195\162te%.", effect = "SPELLHASTERATING" },
    { pattern = "Rend (%d+) points de mana toutes les 5 secondes%.", effect = "MANAREG" }, -- ok
    { pattern = "Rend (%d+) points de mana toutes les 5 sec%.", effect = "MANAREG" }, -- ok

    -- Paladin sets
    -- Priest sets
    -- Druid sets
    -- Shaman sets

    -- Librams
    { pattern = "Augmente de (%d+) la puissance du sort Eclair lumineux%.", effect = "AVG_ABS_FOL"}, -- ok

    -- Idols
    { pattern = "Recevez un maximum de (%d+) points de mana chaque fois que vous lancez un Toucher gu\195\169risseur%.", effect = "MANA_REFUND_HT"},
    { pattern = "Augmente les soins prodigu\195\169s par R\195\169cup\195\169ration de (%d+) au maximum%.", effect = "AVG_ABS_REJUV"},

    -- Totems
    { pattern = "Augmente les soins prodigu\195\169s par votre Vague de Soins Inf\195\169rieurs de (%d+)%.", effect = "AVG_ABS_LHW"},
  };

  HealPointsBSL.PATTERNS_GENERIC_LOOKUP = { -- must be lower case
    ["\195\160 toutes les caract\195\169ristiques"] = {"INT", "SPI", "AGI"}, -- ok
    ["intelligence"] = "INT", -- ok
    ["esprit"] = "SPI", -- ok
    ["agilit\195\169"] = "AGI", 

    ["\195\160 la puissance des sorts"] = "HEAL",
    ["au score de coup critique des sorts"] = "SPELLCRITRATING", -- ok
    ["mana chaque 5 sec"] = "MANAREG",
    ["points de mana toutes les 5 sec"] = "MANAREG", -- ok
    ["points de mana toutes les 5 secondes"] = "MANAREG", -- ok
    ["mana toutes les 5 secondes"] = "MANAREG", -- ok
    ["mana"] = "MANA",
  };

  HealPointsBSL.PATTERNS_OTHER = {
    { pattern = "Mana chaque (%d+) per 5 sec%.", effect = "MANAREG" }, --?
    { pattern = "Score de critique %+%d+ et (%d+) points de mana toutes les 5 sec%.", effect = "MANAREG"}, -- ok
    { pattern = "Vitalit\195\169", effect = "MANAREG", value = 4 }, -- ok
    };
end