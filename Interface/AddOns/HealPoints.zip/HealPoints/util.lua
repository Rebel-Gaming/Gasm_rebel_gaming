
HealPointsUtil = { };

function HealPointsUtil:colorValue(value)
  local v = format("%5.0f", value);
  if (value == 0) then
    return v;
  elseif (value > 0) then
    return GREEN_FONT_COLOR_CODE..v..FONT_COLOR_CODE_CLOSE;
  else
    return RED_FONT_COLOR_CODE..v..FONT_COLOR_CODE_CLOSE;
  end
end

function HealPointsUtil:getTableIndex(t, entry)
  for i = 1, table.getn(t), 1 do
    if (t[i] == entry) then
      return i;
    end
  end
end

function HealPointsUtil:round(num)
  return math.floor(num + 0.5);
end

function HealPointsUtil:isPlayerBuffUp(buffName)
  local iIterator = 1
  while (UnitBuff("player", iIterator)) do
    if (string.find(UnitBuff("player", iIterator), buffName)) then
      return true
    end
    iIterator = iIterator + 1
  end
  return false
end;

function HealPointsUtil:getBaseMana()
  local _, intellect, _, _ = UnitStat("player", 4);
  return UnitManaMax("player") - (math.min(20, intellect) + 15 * (intellect - math.min(20, intellect))); 
end
