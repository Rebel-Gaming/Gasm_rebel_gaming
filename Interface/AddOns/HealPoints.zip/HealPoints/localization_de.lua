
if (GetLocale() == "deDE") then
  HealPointsBSL = { };

  HealPointsBSL.SOCKET_MSG = "<Zum Sockeln Shift-Rechtsklick>";
  HealPointsBSL.GEM_TYPE = "Edelstein";
  HealPointsBSL.AND = "und";
  HealPointsBSL.ARMOR = "R\195\188stung"; 
  HealPointsBSL.BLUE_SOCKET = "Blauer Sockel";
  HealPointsBSL.RED_SOCKET = "Roter Sockel";
  HealPointsBSL.YELLOW_SOCKET = "Gelber Sockel";

  HealPointsBSL.PATTERNS_SETEQUIP = {
    -- General patterns
    { pattern = "Erh\195\182ht kritische Trefferwertung um (%d+)%.", effect = "SPELLCRITRATING" },
    { pattern = "Erh\195\182ht die Zaubermacht um (%d+)%.", effect = "HEAL" },
    { pattern = "Erh\195\182ht Zaubermacht um (%d+)%.", effect = "HEAL" }, 
    { pattern = "Stellt alle 5 Sek%. (%d+) Mana wieder her%.", effect = "MANAREG" }, 
    { pattern = "Erh\195\182ht Tempowertung um (%d+).", effect = "SPELLHASTERATING"}, -- ok    
    
    { pattern = "Stellt alle 5 Sek%. (%d+) Punkt%(e%) Mana wieder her%.", effect = "MANAREG" },
    { pattern = "Erh\195\182ht Eure kritische Zaubertrefferwertung um (%d+)%.", effect = "SPELLCRITRATING"}, -- ok
    { pattern = "Erh\195\182ht kritische Zaubertrefferwertung um (%d+)%.", effect = "SPELLCRITRATING"}, -- ok
    { pattern = "Erh\195\182ht Zaubertempowertung um (%d+).", effect = "SPELLHASTERATING"}, -- ok

    -- Paladin sets
    { pattern = "Erh\195\182ht die Chance auf einen kritischen Treffer mit Eurem Zauber %'Lichtblitz%' um (%d+)%%%.", effect = "CRIT_FOL"}, -- Arena -- ok
    { pattern = "Erh\195\182ht die Chance f\195\188r einen kritischen Treffer Eures Zaubers %'Heiliges Licht%' um (%d+)%%%.", effect = "CRIT_HL"}, -- Tier 6 -- ok
    { pattern = "Erh\195\182ht die Heilwirkung Eures Zaubers %'Lichtblitz%' um (%d+)%%%.", effect = "AVG_PC_FOL"}, -- Tier 6 -- ok

    -- Priest sets
    { pattern = "Erh\195\182ht die Wirkungsdauer von %'Erneuern%' um (%d+) Sekunden%.", effect = "DURATION_RENEW"}, -- AQ40, Tier 5 -- ok
    { pattern = "Verringert die Manakosten Eures Zaubers %'Gebet der Heilung%' um (%d+)%%%.", effect = "MANA_PC_POH"}, -- Tier 6 
    { pattern = "Erh\195\182ht die Heilwirkung Eures Zaubers %'Gro\195\159e Heilung%' um (%d+)%%%.", effect = "AVG_PC_GH"}, -- Tier 6 -- ok

    -- Druid sets
    { pattern = "Erh\195\182ht die Dauer Eures Zaubers %'Nachwachsen%' um (%d+) Sek%.", effect = "DURATION_REGR"}, -- Tier 5 -- ok
    { pattern = "Erh\195\182ht die sofortige Heilung Eurer F\195\164higkeit %'Bl\195\182hendes Leben%' um (%d+)%.", effect = "AVG_BURST_LIFEBL"}, -- Tier 5 -- ok
    { pattern = "Erh\195\182ht die Heilwirkung Eures Zaubers %'Heilende Ber\195\182hrung%' um (%d+)%%%.", effect = "AVG_PC_HT"}, -- Tier 6 -- ok

    -- Shaman sets
    { pattern = "Verringert die Manakosten Eures Zaubers %'Geringe Welle der Heilung%' um (%d+)%%%.", effect = "MANA_PC_LHW"}, -- Tier 5 -- ok
    { pattern = "Eure Zauber %'Kettenheilung%' kostet (%d+)%% weniger Mana%.", effect = "MANA_PC_LHW"}, -- Tier 6
    { pattern = "Erh\195\182ht den durch Euren Zauber %'Kettenheilung%' geheilten Wert um (%d+)%%%.", effect = "AVG_PC_CHAIN"}, -- Tier 6

    -- Librams
    { pattern = "Erh\195\182ht die Zaubermacht Eures Zaubers %'Lichtblitz%' um (%d+)%.", effect = "AVG_ABS_FOL"}, 
    { pattern = "Erh\195\182ht die von %'Heiliges Licht%' verursachte Heilung um bis zu (%d+)%.", effect = "AVG_ABS_HL"}, -- ok
    { pattern = "Verringert die Manakosten Eures Zaubers %'Heiliges Licht%' um (%d+)%.", effect = "MANA_ABS_HL"}, -- ok

    -- Idols
    { pattern = "Erh\195\182ht den durch Euren Zauber %'Heilende Ber\195\188hrung%' geheilten Wert um (%d+).", effect = "AVG_ABS_HT"}, -- ok
    { pattern = "Jedes Mal%, wenn Ihr %'Heilende Ber\195\188hrung%' wirkt%, erhaltet ihr bis zu (%d+) Mana zur\195\188ckerstattet%.", effect = "MANA_REFUND_HT"}, -- ok
    { pattern = "Erh\195\182ht die abschlie\195\159ende Heilung von %'Bl\195\188hendes Leben%' um (%d+)%.", effect = "AVG_BURST_LIFEBL"}, -- ok
    { pattern = "Erh\195\182ht die Heilwirkung Eures Zaubers %'Verj\195\188ngung%' um bis zu (%d+)%.", effect = "AVG_ABS_REJUV"}, -- ok
    { pattern = "Erh\195\182ht die regelm\195\164\195\159ige Heilung von %'Bl\195\188hendes Leben%' um bis zu (%d+)%.", effect = "AVG_HOT_LIFEBL"}, -- ok
    { pattern = "Verringert die Manakosten des Zaubers %'Nachwachsen%' um (%d+)%.", effect = "MANA_ABS_REGR"}, -- ok

    -- Totems
    { pattern = "Jedes Mal%, wenn Ihr %'Geringe Welle der Heilung%' wirkt%, erhaltet ihr bis zu (%d+) Mana zur\195\188ck%.", effect = "MANA_REFUND_LHW"}, -- ok
    { pattern = "Erh\195\182ht den von %'Kettenheilung%' geheilten Grundwert um (%d+)%.", effect = "AVG_ABS_CHAIN"}, -- ok
    { pattern = "Erh\195\182ht die durch %'Geringe Welle der Heilung%' verursachte Heilung um bis zu (%d+)%.", effect = "AVG_ABS_LHW"}, -- ok
    { pattern = "Verringert die Manakosten Eures Zaubers %'Welle der Heilung%' um (%d+)%.", effect = "MANA_ABS_HW"}, -- ok
    { pattern = "Erh\195\182ht den durch %'Welle der Heilung%' geheilten Betrag um bis zu (%d+)%.", effect = "AVG_ABS_HW"}, -- ok
};


  HealPointsBSL.PATTERNS_GENERIC_LOOKUP = { -- must be lower case
    ["alle werte"]      = {"INT", "SPI", "AGI"},
    ["intelligenz"]     = "INT",
    ["willenskraft"]    = "SPI",
    ["beweglichkeit"]   = "AGI", 
   
    ["zaubermacht"]     = "HEAL",
    ["mana alle 5 sek"] = "MANAREG",
    ["manaregeneration"]= "MANAREG",
    ["mana"]            = "MANA",
    ["kritische zaubertrefferwertung"] = "SPELLCRITRATING",
    ["kritische trefferwertung"] = "SPELLCRITRATING",
  };

  HealPointsBSL.PATTERNS_OTHER = {
    { pattern = "Manaregeneration (%d+) per 5 Sek%.", effect = "MANAREG" },
    { pattern = "Alle 5 Sek%. (%d+) Mana", effect = "MANAREG" }, -- ok
    { pattern = "alle 5 Sek%. (%d+) Mana", effect = "MANAREG" }, -- ok

    { pattern = "Vitalit\195\164t", effect = "MANAREG", value = 4 }, -- ok

    { pattern = "Kritische Trefferwertung %+%d+ und alle 5 Sek%. (%d+) Mana", effect = "MANAREG"},
    { pattern = "Zaubertrefferwertung %+%d+ und alle 5 Sek%. (%d+) Mana", effect = "MANAREG"},
    { pattern = "Verteidigungswertung %+%d+ und alle 5 Sek%. (%d+) Mana", effect = "MANAREG"},
    { pattern = "%+%d+ Angriffskraft und alle 5 Sek%. (%d+) Mana", effect = "MANAREG" },
    { pattern = "Angriffskraft %+%d+ und alle 5 Sek%. (%d+) Mana", effect = "MANAREG" },
    { pattern = "%+(%d+) Zaubermacht und alle 5 Sek%. (%d+) Mana", effect = { "HEAL", "MANAREG" }},
    { pattern = "Intelligenz %+(%d+) und alle 5 Sek%. (%d+) Mana", effect = { "INT", "MANAREG" }},
    { pattern = "%+(%d+) Intelligenz und alle 5 Sek%. (%d+) Mana", effect = { "INT", "MANAREG" }},
    { pattern = "Kritische Zaubertrefferwertung %+(%d+) und alle 5 Sek%. (%d+) Mana", effect = { "SPELLCRITRATING", "MANAREG" }},
  };
end