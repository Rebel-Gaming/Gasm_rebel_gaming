
HealPoints - A WoW healer gear benchmark addon, Version 3.2
===========================================================

1: About
2: Usage
3: Formulas used
4: HealPoint stats
5: Equipment supported
6: Talents supported
7: Buffs supported
8: Known bugs and limitations
9: Frequently asked questions (FAQ)

----------------------------------------------------------------
1: About
----------------------------------------------------------------

HealPoints was developed by Eridan, Argent Dawn EU.

With assistance from Melthruil (coding and testing), Elanae, Tas & Allendria (testing),
Nihlo, Nyce & olixxl (German localization).

HealPoints uses a modified version of the BonusScanner library by CrowleyAJ.
HealPoints was inspired by TankPoints by Whitetooth.

----------------------------------------------------------------
2: Usage
----------------------------------------------------------------

The addon is accessed from the Character Info sheet. Below the character, the computed HealPoints benchmark
value will be displayed (healing classes only). If you mouse-over the "HealPoints: xxxxx" line, additional
information (such as mana regen) will be displayed.

If you click on "HealPoints: xxxxx", the HealPoints Calculator will be displayed. The calculator is divided
into three parts. Several of the displayed stats have explanatory tooltips - just mouse-over.

The bottom part displays basic stats such as intelligence and spirit. These stats can be adjusted using
buttons or by entering a value directly. You can then observe how this will change other stats. (Useful to
choose between +24 healing or +4 mana/5s enchants for your new bracer, for example)

The middle part displays stats about the healing spells your character knows. You can select the different
spells using the drop down menus. The right drop down menu is used for heal-over-time (HoT) spells and is
only used for priests and druids. For each of the selected spells, HP/sec, HP/mana, Tot HP(-r) and Tot HP(+r)
are displayed. Tot HP(-r) is the amount of HP you can heal with the selected spell using a full mana bar
without manaregenration. Tot HP(+r) is the same, but with mana regeneration taken into consideration.

The top part explains how the HealPoints stat is computed. It consists of two parts: PowerPoints and
EndurancePoints. Both are explained by tooltip and in section 4 of this readme.

----------------------------------------------------------------
3: Formulas used - NOT UPDATED YET FOR PATCH 3.0
----------------------------------------------------------------

Effect of spirit:
-----------------
Spirit increases normal mana regeneration. The first 50 points of spirit gives
0.25 mana/sec per point. Spirit beyond 50 gives different amounts depending on class.
  Priests: 0.125 mana/sec per point.
  Druids: 0.1125 mana/sec per point.
  Paladins and shamans: 0.1 mana/sec per point.

Intellect and spell critical effect chance:
-------------------------------------------
HealPoints uses the relevant crit chance displayed in the character sheet
(holy for paladins and priests, nature for druids and shamans).

When evaluating intellect change (calculator or item tooltips), HealPoints
uses the following conversion:
  80 Intellect = 1% spell crit.

These are only accurate for level 70 characters.

A spell crit increases the healing effect by 50 %. Heal-over-time spells cannot crit.
(For regrowth the burst part can crit, the HoT part not.)

Spell critical strike rating:
-----------------------------
HealPoints converts spell critical strike ratings to spell critical chance
using the following formula:

crit% = critRating * 26 / (7 * characterLevel - 56), levels 10-60
crit% = critRating * (262 - 3 * characterLevel) / 1148, levels 60+

Formula from the Rating Buster addon by Whitetooth.

(The formula is only used for evaluating crit rating changes from the calculator
or item tooltips.)

+healing and spell casting time:
--------------------------------
The effect of +healing equipment varies with spell casting time. For burst spells, casting time of 3.5s or
longer gives full effect. Faster spells get x/3.5s of the +healing bonus (where x = casting time). Heal over
time (HoT) spells are treated similarly, but with 15s instead of 3.5s. For these spells, the +healing bonus
is divided between each HoT tick. If a spell has reduced casting time (from talents or equipment), the
original casting time is used to find the effect of +healing.

+healing and lower ranked spells:
---------------------------------
Lower ranked healing spells have reduced effect from +healing equipment depending on the level of
the character. HealPoints uses the following factor:
  effect = (slvl + 11) / clvl
where slvl is the level the spell is learned and clvl is the character level

In addition, spells learned before level 20 have this additional +healing effect reduction:
      effect = 1 - ((20 - slvl) * 0.0375)
where slvl is the level the spell is learned.

+healing and regrowth:
----------------------
For regrowth, the +healing bonus is split in two. Half is applied to the HoT-effect and 2.0/3.5 of the other
half is applied to the burst heal effect. As the HoT-effect lasts more than 15s, it gets more than
100% of the other half of the +healing bonus. 

Blessing of Light and lowlevel spells:
--------------------------------------
BoL also have reduced effect for spells learned before level 20. I've found these values:
Holy Light rank 1: 20 %; rank 2: 40 %; rank 3: 70 %

----------------------------------------------------------------
4: HealPoint stats
----------------------------------------------------------------

PowerPoints:
Hitpoints healed in 1 minute using your most powerful spell, starting with 100% mana.
Regeneration and 5 second rule are taken into account.

EndurancePoints:
Hitpoints healed in 5 minutes using your most efficient spell, starting with 0% mana.
Regeneration and 5 second rule are taken into account.

These are the default settings. You can change them by clicking  the "Configure"-button in the
calculator window.

----------------------------------------------------------------
5: Equipment supported
----------------------------------------------------------------

All set/equip bonuses that increase the following stats are always supported:
* intellect
* spirit
* +healing
* +mana/5s
* spell critical strike rating
* spell haste rating

In addition, the following special set bonuses are supported.

Paladin sets:
 Tier 5 - 4pc
 Tier 6 - 2pc & 4pc
 Arena - Glove equip bonus, 4pc

Priest sets:
 Tier 5 - 4pc
 Tier 6 - 2pc & 4pc
 AQ40 - 5pc

Druid sets:
 Tier 5 - 2pc & 4pc
 Tier 6 - 4pc

Shaman sets:
 Tier 5 - 2pc & 4pc
 Tier 6 - 2pc & 4pc
 AQ40 - 5pc

General sets:
 Primal mooncloth - 3pc
 Whitemend wisdom - 2pc
 Wrath of spellfire - 3pc

Also supported:
- All relevant relics
- All relevant gems
- All relevant enchants

Please note that equipment with activated abilities are (typically) not supported.
(Ex: Scroll of Blinding Light, Neltharion's Tear, Gri'lek's Charm of Valor, ...)

----------------------------------------------------------------
6: Talents supported
----------------------------------------------------------------

Paladin:
--------
Healing Light, Divine Intellect, Illumination, Sanctified Light, Holy Power, Holy Shock, 
Holy Guidance,
Benediction

Priest:
-------
Twin Disciplines, Meditation, Mental Agility, Mental Strength, Focused Power, Enlightenment,
Improved Renew, Holy Specialization, Divine Fury, Improved Healing, Healing Prayers,
Spirit of Redemption, Spiritual Guidance, Spiritual Healing, Holy Concentration, Empowered Healing,
Improved Holy Concentration, Circle of Healing, Divine Providence

Druid:
------
Genesis, Moonglow, Nature's Majesty, Nature's Splendor, Lunar Guidance, Dreamstate,
Nurturing Instinct, Heart of the Wild, Survival of the Fittest,
Naturalist, Intensity, Master Shapeshifter, Tranquil Spirit, Improved Rejuvenation, Gift of Nature, 
Empowered Touch, Improved Regrowth, Living Spirit, Natural Perfection, Empowered Rejuvenation, 
Tree of Life, Improved Tree of Life

Shaman:
-------
Unrelenting Storm,
Ancestral Knowledge,
Improved Healing Wave, Tidal Focus, Tidal Mastery, Purification, Blessing of the Eternals,
Improved Chain Heal, Nature's Blessing, Tidal Waves

----------------------------------------------------------------
7: Buffs supported
----------------------------------------------------------------

All buffs that increase intelligence, spirit, spell crit, mana/5s and mana pool are supported.
(Ex: Arcane Intellect, Divine Spirit, Blessing of Kings, Moonkin Aura, Blessing of Wisdom).

----------------------------------------------------------------
8: Known bugs and limitations
----------------------------------------------------------------

Overhealing isn't considered.

For Heal-over-time spells, HealPoints assumes that the effect isn't overwritten.
For Regrowth and Greater Heal with the Transcendence 8/8 bonus, HealPoints assumes that the HoT
effect isn't overwritten by anyone else (HealPoints calculates overwrites done by yourself).

Known bugs/limitations with item tooltips:
- Changes in set bonuses are not detected
- Does not currently work correctly for relics
- Will not appear for items which already have very large tooltips

----------------------------------------------------------------
9: Frequently asked questions (FAQ)
----------------------------------------------------------------

Q: Why is (name of slow, powerful spell) selected as my most efficient spell and used to compute
EndurancePoints when (name of fast, less powerful spell) has much higher HP/mana?

A: The advantage with slow, powerful spells is that you don't need to cast so many of them to heal a lot.
And fewer casts means more time with normal mana regeneration. Fast spells may be cheap, but they don't heal
a lot so you need to cast more of them - meaning little or no time with normal mana regeneration.

If there is a large difference between your casting regen and normal regen, a slow and powerful spell will
probably heal more in x mins than a fast, less powerful. Actually, EndurancePoints are computed for all
spells you know with the spell giving the highest value selected as the most efficient.

Q: Will you make a similar addon for damage spells and/or physical attack abilities?

A: No :-)

