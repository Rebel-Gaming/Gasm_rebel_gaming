
-- Localization
if (GetLocale() == "enUS" or GetLocale() == "enGB") then
  HealPointsLoc = {
    DIV_RANK = "Rank",
    BUFF_TREELI = "Tree of Life",
  };

elseif (GetLocale() == "deDE") then
  HealPointsLoc = {
    DIV_RANK = "Rang",
    BUFF_TREELI = "Baum des Lebens",
  };

elseif (GetLocale() == "frFR") then
  HealPointsLoc = {
    DIV_RANK = "Rang",
    BUFF_TREELI = "Arbre de vie",
  };

elseif (GetLocale() == "esES") then
  HealPointsLoc = {
    DIV_RANK = "Rango",
    BUFF_TREELI = "\195\129rbol de vida",
  };

  elseif (GetLocale() == "zhCN") then
  HealPointsLoc = {
    DIV_RANK = "等级",
    BUFF_TREELI = "生命之树",
  };
end
