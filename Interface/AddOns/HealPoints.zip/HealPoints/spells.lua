
HealPointsSpells = {
  SPELLTABLE = { },

  SPELL_FOL = 1,
  SPELL_HL = 2,
  SPELL_HS = 3,

  SPELL_FH = 11,
  SPELL_LH = 12,
  SPELL_HEAL = 13,
  SPELL_GH = 14,
  SPELL_RENEW = 15,
  SPELL_POH = 16,
  SPELL_HOLYNOVA = 17,
  SPELL_COH = 18,

  SPELL_REGR = 21,
  SPELL_HT = 22,
  SPELL_REJUV = 23,
  SPELL_LIFEBL = 24,

  SPELL_LHW = 31,
  SPELL_HW = 32,
  SPELL_CHAIN = 33,
};

local rankCache = { };

function HealPointsSpells:init()
  local _, className = UnitClass("player");
  if (className == "PALADIN") then
    fol = { classID = HealPointsSpells.SPELL_FOL, type = 'normal', abbr = "FoL", time = 1.5};
    self.SPELLTABLE[1] = {
                { class = fol, id = 19750, rank = 1, min =  86, max =  98, manaP = 8, level = 20},
                { class = fol, id = 19939, rank = 2, min = 130, max = 151, manaP = 8, level = 26},
                { class = fol, id = 19940, rank = 3, min = 197, max = 219, manaP = 8, level = 34},
                { class = fol, id = 19941, rank = 4, min = 265, max = 298, manaP = 8, level = 42},
                { class = fol, id = 19942, rank = 5, min = 357, max = 401, manaP = 8, level = 50},
                { class = fol, id = 19943, rank = 6, min = 458, max = 512, manaP = 8, level = 58},
                { class = fol, id = 27137, rank = 7, min = 600, max = 670, manaP = 7, level = 66},
                { class = fol, id = 48784, rank = 8, min = 682, max = 764, manaP = 7, level = 74}, -- Wotlk
                { class = fol, id = 48785, rank = 9, min = 785, max = 879, manaP = 7, level = 79}}; -- Wotlk

    hl = { classID = HealPointsSpells.SPELL_HL, type = 'normal', abbr = "HL", time = 2.5 };
    self.SPELLTABLE[2] = {
                { class = hl, id =   635, rank =  1, min =   53, max =   64, manaP = 34, level =  1},
                { class = hl, id =   639, rank =  2, min =  101, max =  122, manaP = 34, level =  6},
                { class = hl, id =   647, rank =  3, min =  211, max =  248, manaP = 34, level = 14},
                { class = hl, id =  1026, rank =  4, min =  409, max =  467, manaP = 34, level = 22},
                { class = hl, id =  1042, rank =  5, min =  643, max =  724, manaP = 34, level = 30},
                { class = hl, id =  3472, rank =  6, min =  913, max = 1017, manaP = 34, level = 38},
                { class = hl, id = 10328, rank =  7, min = 1232, max = 1372, manaP = 34, level = 46},
                { class = hl, id = 10329, rank =  8, min = 1621, max = 1803, manaP = 34, level = 54},
                { class = hl, id = 25292, rank =  9, min = 2063, max = 2295, manaP = 34, level = 60},
                { class = hl, id = 27135, rank = 10, min = 2264, max = 2518, manaP = 34, level = 62},
                { class = hl, id = 27136, rank = 11, min = 2818, max = 3138, manaP = 29, level = 70},
                { class = hl, id = 48781, rank = 12, min = 4199, max = 4677, manaP = 29, level = 75}, -- Wotlk
                { class = hl, id = 48782, rank = 13, min = 4888, max = 5444, manaP = 29, level = 80}}; -- Wotlk
                
    hs = { classID = HealPointsSpells.SPELL_HS, type = 'instant', abbr = "HS", cooldown = 6 };
    self.SPELLTABLE[3] = { 
                { class = hs, id = 20473, rank = 1, min =  481, max =  519, manaP = 21, level = 40},
                { class = hs, id = 20929, rank = 2, min =  644, max =  696, manaP = 21, level = 48},
                { class = hs, id = 20930, rank = 3, min =  845, max =  915, manaP = 21, level = 56},
                { class = hs, id = 27174, rank = 4, min = 1061, max = 1149, manaP = 21, level = 64},
                { class = hs, id = 33072, rank = 5, min = 1258, max = 1362, manaP = 18, level = 70},
                { class = hs, id = 48824, rank = 6, min = 2065, max = 2235, manaP = 18, level = 75}, -- Wotlk
                { class = hs, id = 48825, rank = 7, min = 2401, max = 2599, manaP = 18, level = 80}}; -- Wotlk
                
  elseif (className == "PRIEST") then
    fh = { classID = HealPointsSpells.SPELL_FH, type = 'normal', abbr = "FH", time = 1.5 };
    self.SPELLTABLE[1] = {
                { class = fh, id =  2061, rank =  1, min =  202, max =  247, manaP = 20, level = 20},
                { class = fh, id =  9472, rank =  2, min =  269, max =  325, manaP = 20, level = 26},
                { class = fh, id =  9473, rank =  3, min =  339, max =  406, manaP = 20, level = 32},
                { class = fh, id =  9474, rank =  4, min =  414, max =  492, manaP = 20, level = 38},
                { class = fh, id = 10915, rank =  5, min =  534, max =  633, manaP = 20, level = 44},
                { class = fh, id = 10916, rank =  6, min =  662, max =  783, manaP = 20, level = 50},
                { class = fh, id = 10917, rank =  7, min =  833, max =  979, manaP = 20, level = 56},
                { class = fh, id = 25233, rank =  8, min =  931, max = 1078, manaP = 20, level = 61},
                { class = fh, id = 25235, rank =  9, min = 1116, max = 1295, manaP = 18, level = 67},
                { class = fh, id = 48070, rank = 10, min = 1578, max = 1832, manaP = 18, level = 73}, -- Wotlk
                { class = fh, id = 48071, rank = 11, min = 1887, max = 2193, manaP = 18, level = 79}}; -- Wotlk

    lh = { classID = HealPointsSpells.SPELL_LH, type = 'normal', abbr = "LH" };
    heal = { classID = HealPointsSpells.SPELL_HEAL, type = 'normal', abbr = "Heal", time = 3.0 };
    gh = { classID = HealPointsSpells.SPELL_GH, type = 'normal', abbr = "GH", time = 3.0 };
    self.SPELLTABLE[2] = {
                { class = lh, id = 2050, rank = 1, min =  47, max =  58, time = 1.5, manaP = 36, level = 1},
                { class = lh, id = 2052, rank = 2, min =  76, max =  91, time = 2.0, manaP = 36, level = 4},
                { class = lh, id = 2053, rank = 3, min = 143, max = 165, time = 2.5, manaP = 36, level = 10},
                { class = heal, id = 2054, rank = 1, min = 307, max = 353, manaP = 36, level = 16},
                { class = heal, id = 2055, rank = 2, min = 445, max = 507, manaP = 36, level = 22},
                { class = heal, id = 6063, rank = 3, min = 586, max = 662, manaP = 36, level = 28},
                { class = heal, id = 6064, rank = 4, min = 734, max = 827, manaP = 36, level = 34},
                { class = gh, id =  2060, rank = 1, min =  924, max = 1039, manaP = 36, level = 40},
                { class = gh, id = 10963, rank = 2, min = 1178, max = 1318, manaP = 36, level = 46},
                { class = gh, id = 10964, rank = 3, min = 1470, max = 1642, manaP = 36, level = 52},
                { class = gh, id = 10965, rank = 4, min = 1835, max = 2044, manaP = 36, level = 58},
                { class = gh, id = 25314, rank = 5, min = 2006, max = 2235, manaP = 36, level = 60},
                { class = gh, id = 25210, rank = 6, min = 2107, max = 2444, manaP = 36, level = 63},
                { class = gh, id = 25213, rank = 7, min = 2414, max = 2803, manaP = 32, level = 68},
                { class = gh, id = 48062, rank = 8, min = 3395, max = 3945, manaP = 32, level = 73}, -- Wotlk
                { class = gh, id = 48063, rank = 9, min = 3950, max = 4590, manaP = 32, level = 78}}; -- Wotlk
                
    renew = { classID = HealPointsSpells.SPELL_RENEW, type = 'hot', abbr = "Renew", tickcount = 5, interval = 3 };
    self.SPELLTABLE[3] = {
                { class = renew, id =   139, rank =  1, tick =   9, manaP = 19, level =  8},
                { class = renew, id =  6074, rank =  2, tick =  20, manaP = 19, level = 14},
                { class = renew, id =  6075, rank =  3, tick =  35, manaP = 19, level = 20},
                { class = renew, id =  6076, rank =  4, tick =  49, manaP = 19, level = 26},
                { class = renew, id =  6077, rank =  5, tick =  63, manaP = 19, level = 32},
                { class = renew, id =  6078, rank =  6, tick =  80, manaP = 19, level = 38},
                { class = renew, id = 10927, rank =  7, tick = 102, manaP = 19, level = 44},
                { class = renew, id = 10928, rank =  8, tick = 130, manaP = 19, level = 50},
                { class = renew, id = 10929, rank =  9, tick = 162, manaP = 19, level = 56},
                { class = renew, id = 25315, rank = 10, tick = 194, manaP = 19, level = 60},
                { class = renew, id = 25211, rank = 11, tick = 202, manaP = 19, level = 65},
                { class = renew, id = 25222, rank = 12, tick = 222, manaP = 17, level = 70},
                { class = renew, id = 48067, rank = 13, tick = 247, manaP = 17, level = 75}, -- Wotlk
                { class = renew, id = 48068, rank = 14, tick = 280, manaP = 17, level = 80}}; -- Wotlk

    poh = { classID = HealPointsSpells.SPELL_POH, type = 'aoe', abbr = "PoH", time = 3 };
    self.SPELLTABLE[4] = {
                { class = poh, id =   596, rank = 1, min =  312, max =  333, manaP =  54, level = 30},
                { class = poh, id =   996, rank = 2, min =  458, max =  487, manaP =  54, level = 40},
                { class = poh, id = 10960, rank = 3, min =  675, max =  713, manaP =  54, level = 50},
                { class = poh, id = 10961, rank = 4, min =  960, max = 1013, manaP =  54, level = 60},
                { class = poh, id = 25316, rank = 5, min = 1019, max = 1076, manaP =  54, level = 60},
                { class = poh, id = 25308, rank = 6, min = 1251, max = 1322, manaP =  48, level = 68},
                { class = poh, id = 48072, rank = 7, min = 2091, max = 2209, manaP =  48, level = 76}}; -- Wotlk

    holynova = { classID = HealPointsSpells.SPELL_HOLYNOVA, type = 'aoe', abbr = "HNova", time = 0 };
    self.SPELLTABLE[5] = {
                { class = holynova, id = 15237, rank = 1, min =  54, max =  63, manaP = 27, level = 20},
                { class = holynova, id = 15430, rank = 2, min =  89, max = 101, manaP = 27, level = 28},
                { class = holynova, id = 15431, rank = 3, min = 124, max = 143, manaP = 27, level = 36},
                { class = holynova, id = 27799, rank = 4, min = 165, max = 192, manaP = 27, level = 44},
                { class = holynova, id = 27800, rank = 5, min = 239, max = 276, manaP = 27, level = 52},
                { class = holynova, id = 27801, rank = 6, min = 307, max = 356, manaP = 25, level = 60},
                { class = holynova, id = 25331, rank = 7, min = 386, max = 448, manaP = 25, level = 68},
                { class = holynova, id = 48077, rank = 8, min = 611, max = 709, manaP = 25, level = 75}, -- Wotlk
                { class = holynova, id = 48078, rank = 9, min = 713, max = 827, manaP = 25, level = 80}}; -- Wotlk
                
    coh = { classID = HealPointsSpells.SPELL_COH, type = 'aoe', abbr = 'CoH', time = 0 };
    self.SPELLTABLE[6] = {
                { class = coh, id = 34861, rank = 1, min = 246, max = 270, manaP = 24, level = 50}, -- Not verified
                { class = coh, id = 34863, rank = 2, min = 288, max = 318, manaP = 24, level = 56},
                { class = coh, id = 34864, rank = 3, min = 327, max = 361, manaP = 24, level = 60},
                { class = coh, id = 34865, rank = 4, min = 370, max = 408, manaP = 24, level = 65},
                { class = coh, id = 34866, rank = 5, min = 409, max = 451, manaP = 21, level = 70},
                { class = coh, id = 48088, rank = 6, min = 589, max = 651, manaP = 21, level = 75},
                { class = coh, id = 48089, rank = 7, min = 684, max = 756, manaP = 21, level = 80}};

  elseif (className == "DRUID") then
    regr = { classID = HealPointsSpells.SPELL_REGR, type = 'regrowth', abbr = "Regr", tickcount = 7, interval = 3, time = 2 };
    self.SPELLTABLE[1] = {
                { class = regr, id =  8936, rank =  1, min =   93, max =  107, tick =  14, manaP = 33, level = 12},
                { class = regr, id =  8938, rank =  2, min =  176, max =  201, tick =  25, manaP = 33, level = 18},
                { class = regr, id =  8939, rank =  3, min =  255, max =  290, tick =  37, manaP = 33, level = 24},
                { class = regr, id =  8940, rank =  4, min =  336, max =  378, tick =  49, manaP = 33, level = 30},
                { class = regr, id =  8941, rank =  5, min =  425, max =  478, tick =  61, manaP = 33, level = 36},
                { class = regr, id =  9750, rank =  6, min =  534, max =  599, tick =  78, manaP = 33, level = 42},
                { class = regr, id =  9856, rank =  7, min =  672, max =  751, tick =  98, manaP = 33, level = 48},
                { class = regr, id =  9857, rank =  8, min =  839, max =  935, tick = 123, manaP = 33, level = 54},
                { class = regr, id =  9858, rank =  9, min = 1023, max = 1140, tick = 152, manaP = 33, level = 60},
                { class = regr, id = 26980, rank = 10, min = 1253, max = 1394, tick = 182, manaP = 29, level = 65},
                { class = regr, id = 48442, rank = 11, min = 1710, max = 1908, tick = 256, manaP = 29, level = 71}, -- Wotlk
                { class = regr, id = 48443, rank = 12, min = 2234, max = 2494, tick = 335, manaP = 29, level = 77}}; -- Wotlk
                
    ht = { classID = HealPointsSpells.SPELL_HT, type = 'normal', abbr = "HT" };
    self.SPELLTABLE[2] = {
                { class = ht, id =  5185, rank =  1, min =   40, max =   55, time = 1.5, manaP = 38, level =  1},
                { class = ht, id =  5186, rank =  2, min =   94, max =  119, time = 2.0, manaP = 38, level =  8},
                { class = ht, id =  5187, rank =  3, min =  204, max =  253, time = 2.5, manaP = 38, level = 14},
                { class = ht, id =  5188, rank =  4, min =  376, max =  459, time = 3.0, manaP = 38, level = 20},
                { class = ht, id =  5189, rank =  5, min =  505, max =  609, time = 3.0, manaP = 38, level = 26},
                { class = ht, id =  6778, rank =  6, min =  653, max =  783, time = 3.0, manaP = 38, level = 32},
                { class = ht, id =  8903, rank =  7, min =  821, max =  980, time = 3.0, manaP = 38, level = 38},
                { class = ht, id =  9758, rank =  8, min = 1211, max = 1450, time = 3.0, manaP = 38, level = 44},
                { class = ht, id =  9888, rank =  9, min = 1324, max = 1565, time = 3.0, manaP = 38, level = 50},
                { class = ht, id =  9889, rank = 10, min = 1648, max = 1941, time = 3.0, manaP = 38, level = 56},
                { class = ht, id = 25297, rank = 11, min = 1962, max = 2313, time = 3.0, manaP = 38, level = 60},
                { class = ht, id = 26978, rank = 12, min = 2032, max = 2399, time = 3.0, manaP = 38, level = 62},
                { class = ht, id = 26979, rank = 13, min = 2328, max = 2746, time = 3.0, manaP = 33, level = 69},
                { class = ht, id = 48377, rank = 14, min = 3223, max = 3805, time = 3.0, manaP = 33, level = 74}, -- Wotlk
                { class = ht, id = 48378, rank = 15, min = 3750, max = 4428, time = 3.0, manaP = 33, level = 79}}; -- Wotlk
    
    rejuv = { classID = HealPointsSpells.SPELL_REJUV, type = 'hot', abbr = "Rejuv", tickcount = 4, interval = 3 };
    self.SPELLTABLE[3] = {
                { class = rejuv, id =   774, rank =  1, tick =   8, manaP = 21, level =  4},
                { class = rejuv, id =  1058, rank =  2, tick =  14, manaP = 21, level = 10},
                { class = rejuv, id =  1430, rank =  3, tick =  29, manaP = 21, level = 16},
                { class = rejuv, id =  2090, rank =  4, tick =  45, manaP = 21, level = 22},
                { class = rejuv, id =  2091, rank =  5, tick =  61, manaP = 21, level = 28},
                { class = rejuv, id =  3627, rank =  6, tick =  76, manaP = 21, level = 34},
                { class = rejuv, id =  8910, rank =  7, tick =  97, manaP = 21, level = 40},
                { class = rejuv, id =  9839, rank =  8, tick = 122, manaP = 21, level = 46},
                { class = rejuv, id =  9840, rank =  9, tick = 152, manaP = 21, level = 52},
                { class = rejuv, id =  9841, rank = 10, tick = 189, manaP = 21, level = 58},
                { class = rejuv, id = 25299, rank = 11, tick = 222, manaP = 21, level = 60},
                { class = rejuv, id = 26981, rank = 12, tick = 233, manaP = 21, level = 63},
                { class = rejuv, id = 26982, rank = 13, tick = 265, manaP = 18, level = 69},
                { class = rejuv, id = 48440, rank = 14, tick = 298, manaP = 18, level = 75}, -- Wotlk
                { class = rejuv, id = 48441, rank = 15, tick = 338, manaP = 18, level = 80}}; -- Wotlk

    lifebl = { classID = HealPointsSpells.SPELL_LIFEBL, type = 'lifebloom', abbr = "LifeBl", tickcount = 7, interval = 1 };
    self.SPELLTABLE[4] = {
                { class = lifebl, id = 33763, rank = 1, burst = 600, tick = 32, manaP = 14, level = 64},
                { class = lifebl, id = 48450, rank = 2, burst = 770, tick = 41, manaP = 14, level = 72}, -- Wotlk
                { class = lifebl, id = 48451, rank = 3, burst = 970, tick = 53, manaP = 14, level = 80}}; -- Wotlk

  elseif (className == "SHAMAN") then
    lhw = { classID = HealPointsSpells.SPELL_LHW, type = 'normal', abbr = "LHW", time = 1.5 };
    self.SPELLTABLE[1] = {
                { class = lhw, id =  8004, rank = 1, min =  170, max =  195, manaP = 19, level = 20},
                { class = lhw, id =  8008, rank = 2, min =  257, max =  292, manaP = 19, level = 28},
                { class = lhw, id =  8010, rank = 3, min =  349, max =  394, manaP = 19, level = 36},
                { class = lhw, id = 10466, rank = 4, min =  473, max =  529, manaP = 19, level = 44},
                { class = lhw, id = 10467, rank = 5, min =  634, max =  709, manaP = 19, level = 52},
                { class = lhw, id = 10468, rank = 6, min =  853, max =  949, manaP = 19, level = 60},
                { class = lhw, id = 25420, rank = 7, min = 1055, max = 1202, manaP = 15, level = 66}, 
                { class = lhw, id = 49275, rank = 9, min = 1382, max = 1578, manaP = 15, level = 72}, -- Wotlk
                { class = lhw, id = 49276, rank = 8, min = 1606, max = 1834, manaP = 15, level = 77}}; -- Wotlk
                
    hw = { classID = HealPointsSpells.SPELL_HW, type = 'normal', abbr = "HW" };
    self.SPELLTABLE[2] = {
                { class = hw, id =   331, rank =  1, min =   36, max =   47, time = 1.5, manaP = 32, level =  1},
                { class = hw, id =   332, rank =  2, min =   69, max =   83, time = 2.0, manaP = 32, level =  6},
                { class = hw, id =   547, rank =  3, min =  136, max =  163, time = 2.5, manaP = 32, level = 12},
                { class = hw, id =   913, rank =  4, min =  279, max =  328, time = 3.0, manaP = 32, level = 18},
                { class = hw, id =   939, rank =  5, min =  389, max =  454, time = 3.0, manaP = 32, level = 24},
                { class = hw, id =   959, rank =  6, min =  552, max =  639, time = 3.0, manaP = 32, level = 32},
                { class = hw, id =  8005, rank =  7, min =  759, max =  874, time = 3.0, manaP = 32, level = 40},
                { class = hw, id = 10395, rank =  8, min = 1040, max = 1191, time = 3.0, manaP = 32, level = 48},
                { class = hw, id = 10396, rank =  9, min = 1394, max = 1589, time = 3.0, manaP = 32, level = 56},
                { class = hw, id = 25357, rank = 10, min = 1647, max = 1878, time = 3.0, manaP = 32, level = 60},
                { class = hw, id = 25391, rank = 11, min = 1756, max = 2001, time = 3.0, manaP = 32, level = 63},
                { class = hw, id = 25396, rank = 12, min = 2134, max = 2436, time = 3.0, manaP = 25, level = 70},
                { class = hw, id = 49272, rank = 13, min = 2624, max = 2996, time = 3.0, manaP = 25, level = 75}, -- Wotlk
                { class = hw, id = 49273, rank = 14, min = 3034, max = 3466, time = 3.0, manaP = 25, level = 80}}; -- Wotlk
                
    chain = { classID = HealPointsSpells.SPELL_CHAIN, type = 'chain', abbr = "CH", time = 2.5 }; 
    self.SPELLTABLE[3] = {  
                { class = chain, id =  1064, rank = 1, min =  332, max =  381, manaP = 24, level = 32},
                { class = chain, id = 10622, rank = 2, min =  419, max =  479, manaP = 24, level = 40},
                { class = chain, id = 10623, rank = 3, min =  567, max =  646, manaP = 24, level = 48},
                { class = chain, id = 25422, rank = 4, min =  624, max =  710, manaP = 24, level = 56},
                { class = chain, id = 25423, rank = 5, min =  833, max =  950, manaP = 19, level = 63},
                { class = chain, id = 55458, rank = 6, min =  906, max = 1034, manaP = 19, level = 74}, -- Wotlk
                { class = chain, id = 55459, rank = 7, min = 1055, max = 1205, manaP = 19, level = 80}}; -- Wotlk
  end
end

function HealPointsSpells:getSpell(spellName) -- TODO
  for t = 1, table.getn(self.SPELLTABLE), 1 do
    for i = 1, table.getn(self.SPELLTABLE[t]), 1 do
      local thisName = GetSpellInfo(self.SPELLTABLE[t][i]['id']);
      if (thisName == spellName and self.SPELLTABLE[t][i]['rank'] == self:getHighestSpellRank(self.SPELLTABLE[t][i]['class']['classID'])) then
        return self.SPELLTABLE[t][i];
      end
    end
  end
end

function HealPointsSpells:getSpellByClassID(spellClassID) 
  for t = 1, table.getn(self.SPELLTABLE), 1 do
    for i = 1, table.getn(self.SPELLTABLE[t]), 1 do
      if (self.SPELLTABLE[t][i]['class']['classID'] == spellClassID and self.SPELLTABLE[t][i]['rank'] == self:getHighestSpellRank(self.SPELLTABLE[t][i]['class']['classID'])) then
        return self.SPELLTABLE[t][i];
      end
    end
  end
end

function HealPointsSpells:spellsChanged()
  for k in pairs(rankCache) do
    rankCache[k] = nil;
  end
end

function HealPointsSpells:getHighestSpellRank(spellClassID) 
  local function getAnySpellByClass(spellClassID)
    for t = 1, table.getn(self.SPELLTABLE), 1 do
      for i = 1, table.getn(self.SPELLTABLE[t]), 1 do
        if (self.SPELLTABLE[t][i].class.classID == spellClassID) then
          return self.SPELLTABLE[t][i];
        end
      end
    end
  end
    
  local function getRealRank(spellClassID)
    local spell = getAnySpellByClass(spellClassID);
    local spellName = GetSpellInfo(spell.id);
    
    local totalSpellTabs = GetNumSpellTabs();
    local totalSpells = 0;
    for t = 1, totalSpellTabs do
      local _, _, _, numSpells = GetSpellTabInfo(t);
      totalSpells = totalSpells + numSpells;
    end

    local highestRank = 0;
    for t = 1, totalSpells do
      local nameSpell, rankSpell = GetSpellName(t, BOOKTYPE_SPELL);
      if (nameSpell == spellName) then
        local j, k = string.find(rankSpell, HealPointsLoc.DIV_RANK.." ");
        if (j ~= nil) then
          highestRank = math.max(highestRank, string.sub(rankSpell, k));
        end
      end
    end
    return highestRank;
  end
  
  if (rankCache[spellClassID] == nil) then
    rankCache[spellClassID] = getRealRank(spellClassID);
  end
  return rankCache[spellClassID];  
end

function HealPointsSpells:getCastTime(spell, spellHaste) 
  local castTime = spell.class['time'];
  if (castTime == nil) then
    castTime = spell['time'];
  end

  local _, className = UnitClass("player");

  if (className == "PRIEST") then
    if (spell.class.classID == HealPointsSpells.SPELL_HEAL or spell.class.classID == HealPointsSpells.SPELL_GH) then
      castTime = castTime - HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.DIVFUR) * 0.1; -- Reduced time for Heal/Greater Heal by 0.1 per rank
    end

  elseif (className == "DRUID") then
    if (spell.class.classID == HealPointsSpells.SPELL_HT) then
      castTime = castTime - HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.NATURA) * 0.1; -- Reduced time for Healing Touch by 0.1 per rank
    end

  elseif (className == "SHAMAN") then
    if (spell.class.classID == HealPointsSpells.SPELL_HW) then
      castTime = castTime - HealPointsTalents:getTalentRank(HealPointsTalents.SHAMAN.IMHEWA) * 0.1; -- Reduced time for Healing Wave by 0.1 per rank
    end
  end
  
  if (castTime ~= nil) then
    castTime = castTime / (1 + spellHaste / 100);
  end
  
  return castTime;
end

function HealPointsSpells:getNumberOfTicks(spell)
  local tickcount = spell.class['tickcount'];

  local _, className = UnitClass("player");

  if (className == "PRIEST") then
    if (spell.class.classID == HealPointsSpells.SPELL_RENEW) then
      tickcount = tickcount + HealPointsBS:GetBonus('DURATION_RENEW') / spell.class['interval']; -- 5 pc Oracle bonus + tier 5
    end

  elseif (className == "DRUID") then
    if (spell.class.classID == HealPointsSpells.SPELL_REJUV) then
      tickcount = tickcount + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.NATSPL);
    elseif (spell.class.classID == HealPointsSpells.SPELL_REGR) then
      tickcount = tickcount + HealPointsBS:GetBonus('DURATION_REGR') / spell.class['interval']; -- tier 5
      tickcount = tickcount + 2 * HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.NATSPL);
    elseif (spell.class.classID == HealPointsSpells.SPELL_LIFEBL) then
      tickcount = tickcount + 2 * HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.NATSPL);
    end
  end

  return tickcount;
end

function HealPointsSpells:getManaCost(spell, spellCrit)
  local percentCheaper = 0;
  local refund = 0;

  spellCrit = spellCrit + self:getSpellCritBonus(spell);

  local _, className = UnitClass("player");

  if (className == "PALADIN") then
    percentCheaper = (spellCrit / 100) * 0.20 * HealPointsTalents:getTalentRank(HealPointsTalents.PALADIN.ILLUMI) * 0.6; -- Reduced mana cost for crits by 20% per rank
    if (spell.class.classID == HealPointsSpells.SPELL_HL) then
      refund = HealPointsBS:GetBonus('MANA_ABS_HL'); -- Straight mana reduction
      percentCheaper = percentCheaper + HealPointsBS:GetBonus('MANA_PC_HL') * 0.01; -- Tier 7
    elseif (spell.class.classID == HealPointsSpells.SPELL_HS) then
      percentCheaper = percentCheaper + HealPointsTalents:getTalentRank(HealPointsTalents.PALADIN.BENEDI) * 0.02; -- Instant spells 2% cheaper per rank
    end

  elseif (className == "PRIEST") then
    if (spell.class.classID == HealPointsSpells.SPELL_LH or spell.class.classID == HealPointsSpells.SPELL_HEAL or spell.class.classID == HealPointsSpells.SPELL_GH) then
      percentCheaper = HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.IMPHEA) * 0.05; -- Reduced mana cost for slow heal by 5% per rank
    end
    if (spell.class.classID == HealPointsSpells.SPELL_FH or spell.class.classID == HealPointsSpells.SPELL_GH) then
      percentCheaper = percentCheaper + (spellCrit / 100) * (HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.HOLCON) * 0.10 + -- 10% chance per rank for free spell after crit
                                                             HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.IMPHOC) * 0.05); -- 5% increased chance per rank
    end
    if (spell.class.classID == HealPointsSpells.SPELL_GH) then
      percentCheaper = percentCheaper + HealPointsBS:GetBonus('MANA_PC_GH') * 0.01; -- Tier 7
    end
    if (spell.class.classID == HealPointsSpells.SPELL_RENEW) then
      percentCheaper = HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.MENAGI) * 0.02; -- Reduced mana cost for Renew by 2% per rank
    elseif (spell.class.classID == HealPointsSpells.SPELL_POH) then
      percentCheaper = HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.HEAPRA) * 0.1; -- Reduced mana cost for Prayer of Healing by 10% per rank
      percentCheaper = percentCheaper + HealPointsBS:GetBonus('MANA_PC_POH') * 0.01; -- Tier 6
    elseif (spell.class.classID == HealPointsSpells.SPELL_HOLYNOVA or spell.class.classID == HealPointsSpells.SPELL_COH) then
      percentCheaper = HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.MENAGI) * 0.02; -- Reduced mana cost for instants by 2% per rank    
    end

  elseif (className == "DRUID") then
    if (spell.class.classID == HealPointsSpells.SPELL_HT or spell.class.classID == HealPointsSpells.SPELL_REGROWTH or spell.class.classID == HealPointsSpells.SPELL_REJUV) then
        percentCheaper = HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.MOONGL) * 0.03; -- Reduced mana cost for all spells by 3% per rank
    end
    if (spell.class.classID == HealPointsSpells.SPELL_HT) then
      percentCheaper = percentCheaper + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.TRASPI) * 0.02; -- Reduced mana cost for Healing Touch by 2% per rank
      if (HealPointsBS:GetBonus('MANA_REFUND_HT') > 0) then
        refund = refund + math.min(HealPointsBS:GetBonus('MANA_REFUND_HT'), (spell['manaP'] / 100) * HealPointsUtil:getBaseMana() / (HealPointsBS:GetBonus('MANA_REFUND_HT') - 1)); -- Idol of Longevity
      end
    elseif (spell.class.classID == HealPointsSpells.SPELL_REGROWTH) then
      refund = refund + HealPointsBS:GetBonus('MANA_ABS_REGR'); -- Straight mana reduction
    elseif (spell.class.classID == HealPointsSpells.SPELL_REJUV) then
      refund = refund + HealPointsBS:GetBonus('MANA_ABS_REJUV'); -- Straight mana reduction
      percentCheaper = percentCheaper + HealPointsBS:GetBonus('MANA_PC_REJUV') * 0.01; -- Tier 7
    end    
    if (HealPointsUtil:isPlayerBuffUp(HealPointsLoc.BUFF_TREELI) and (spell.class.classID == HealPointsSpells.SPELL_REJUV or spell.class.classID == HealPointsSpells.SPELL_REGR or spell.class.classID == HealPointsSpells.SPELL_LIFEBL)) then
      percentCheaper = percentCheaper + 0.2; -- 20% cheaper in treeform
    end

  elseif (className == "SHAMAN") then
    percentCheaper = HealPointsTalents:getTalentRank(HealPointsTalents.SHAMAN.TIDFOC) * 0.01; -- Reduced mana cost for all spells by 1% per rank
    if (spell.class.classID == HealPointsSpells.SPELL_LHW) then
      percentCheaper = percentCheaper + HealPointsBS:GetBonus('MANA_PC_LHW') * 0.01; -- Tier 5
    elseif (spell.class.classID == HealPointsSpells.SPELL_HW) then
      refund = refund + HealPointsBS:GetBonus('MANA_ABS_HW'); -- Straight mana reduction
    elseif (spell.class.classID == HealPointsSpells.SPELL_CHAIN) then
      percentCheaper = percentCheaper + HealPointsBS:GetBonus('MANA_PC_CHAIN') * 0.01; -- Tier 6
      refund = refund + HealPointsBS:GetBonus('MANA_ABS_CHAIN'); -- Straight mana reduction
    end
    
  end
    
  return (spell['manaP'] / 100) * HealPointsUtil:getBaseMana() * (1 - percentCheaper) - refund;
end

function HealPointsSpells:getHealingPercentBonus(spell) 
  local percentBonus = 0;

  local _, className = UnitClass("player");

  if (className == "PALADIN") then
    percentBonus = HealPointsTalents:getTalentRank(HealPointsTalents.PALADIN.HEALIG) * 0.04; -- Increases avg for all three spells by 4% per rank
    if (spell.class.classID == HealPointsSpells.SPELL_FOL) then
      percentBonus = percentBonus + HealPointsBS:GetBonus('AVG_PC_FOL') * 0.01; -- Tier 6
    elseif (spell.class.classID == HealPointsSpells.SPELL_HS) then
      percentBonus = percentBonus + HealPointsBS:GetBonus('AVG_PC_HS') * 0.01; -- Arena    
    end
    percentBonus = 1 + percentBonus;

  elseif (className == "PRIEST") then
    percentBonus = 1 + HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.SPIHEA) * 0.02;  -- Increased avg for all spells by 2% per rank
    percentBonus = percentBonus + HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.FOCUSP) * 0.02;  -- Increased avg for all spells by 2% per rank
    if (spell.class['type'] == 'hot' or (spell.class['type'] == 'aoe' and spell.class['time'] == 0)) then
        percentBonus = percentBonus + HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.TWINDI) * 0.01; -- Increased avg for instant spells by 1% per rank
    end
    if (spell.class.classID == HealPointsSpells.SPELL_RENEW) then
      percentBonus = percentBonus * (1 + HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.IMPREN) * 0.05); -- Increased avg for Renew by 5% per rank
    elseif (spell.class.classID == HealPointsSpells.SPELL_GH) then
      percentBonus = percentBonus * (1 + HealPointsBS:GetBonus('AVG_PC_GH') * 0.01); -- Tier 6
    elseif (spell.class['type'] == 'aoe') then
      percentBonus = percentBonus + HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.DIVPRO) * 0.02; -- Increased avg for aoe spells by 2% per rank
    end
    -- Tested to be multiplicative for Renew

  elseif (className == "DRUID") then
    percentBonus = HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.GIOFNA) * 0.02; -- Increased avg for all spells by 2% per rank
    if (spell.class.classID == HealPointsSpells.SPELL_REJUV) then
      percentBonus = percentBonus + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.IMPREJ) * 0.05; -- Increased avg for Rejuvenation by 5% per rank
      percentBonus = percentBonus + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.GENESI) * 0.01; -- Increases hots by 1% per rank
    elseif (spell.class.classID == HealPointsSpells.SPELL_HT) then
      percentBonus = percentBonus + HealPointsBS:GetBonus('AVG_PC_HT') * 0.01; -- Tier 6
    end
    if (HealPointsUtil:isPlayerBuffUp(HealPointsLoc.BUFF_TREELI)) then
      percentBonus = percentBonus + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.MASSHA) * 0.02; -- Increased avg by 2% per rank while in Tree Form
    end
    percentBonus = 1 + percentBonus; -- Tested not to be multiplicative for Rejuvenation

  elseif (className == "SHAMAN") then
    percentBonus = HealPointsTalents:getTalentRank(HealPointsTalents.SHAMAN.PURIFI) * 0.02; -- Increased avg for all spells by 2% per rank
    if (spell.class.classID == HealPointsSpells.SPELL_CHAIN) then
      percentBonus = percentBonus + HealPointsTalents:getTalentRank(HealPointsTalents.SHAMAN.IMPCHA) * 0.1; -- Increased avg for Chain heal by 10% per rank
      percentBonus = percentBonus + HealPointsBS:GetBonus('AVG_PC_CHAIN') * 0.01; -- Tier 6
    end
    if (spell.class.classID == HealPointsSpells.SPELL_CHAIN or spell.class.classID == HealPointsSpells.SPELL_HW) then
      percentBonus = percentBonus + HealPointsBS:GetBonus('AVG_PC_CHAIN_HW') * 0.01; -- Tier 7
    end
    percentBonus = 1 + percentBonus;
  end
    
  return percentBonus;
end

function HealPointsSpells:getHealingFactor(spell)
  local levelFactor = 1 - ((20 - math.min(20, spell['level'])) * 0.0375);
  levelFactor = levelFactor * math.min(1, (spell['level'] + 11) / UnitLevel("player"));

  local castTime = spell.class['time'];
  if (castTime == nil) then
    castTime = spell['time'];
  end

  local timeFactor, timeFactor2;
  if (spell.class['type'] == 'regrowth') then
    timeFactor = 0.5 * castTime / 1.838;                                        -- Experimental 3.0 (Burst)
    timeFactor2 = 0.5 * spell.class['tickcount'] * spell.class['interval'] / 8; -- Experimental 3.0 (HoT)
  elseif (spell.class['type'] == 'lifebloom') then
    timeFactor = 2 / 3;                                                         -- Experimental 3.0 (HoT)
    timeFactor2 = 0.645;                                                        -- Experimental 3.0 (Burst)
  elseif (spell.class['type'] == 'hot') then
    timeFactor = spell.class['tickcount'] * spell.class['interval'] / 8;        -- Experimental 3.0
  elseif (spell.class['type'] == 'instant') then
    timeFactor = 1.5 / 1.854;                                                   -- Experimental 3.0
  elseif (spell.class['type'] == 'aoe') then
    timeFactor = (math.max(1.5, castTime) / 1.87) / 2;                          -- Experimental 3.0
    if (spell.class.classID == HealPointsSpells.SPELL_HOLYNOVA) then
      timeFactor = timeFactor * 3 / 4;                                          -- Experimental 3.0
    end
  else -- normal / chain
    timeFactor = castTime / 1.47;                                               -- Experimental 3.0
  end
  
  -- Empowered talents (strange difference between empowered healing and empowered rejuvenation)
  if (spell.class.classID == HealPointsSpells.SPELL_GH) then
    timeFactor = timeFactor + HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.EMPHEA) * 0.08; -- +8% bonus healing per rank
  elseif (spell.class.classID == HealPointsSpells.SPELL_FH) then
    timeFactor = timeFactor + HealPointsTalents:getTalentRank(HealPointsTalents.PRIEST.EMPHEA) * 0.04; -- +4% bonus healing per rank
  elseif (spell.class.classID == HealPointsSpells.SPELL_HT) then
    timeFactor = timeFactor * (1 + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.EMPOHT) * 0.1); -- +10% bonus healing per rank
  elseif (spell.class.classID == HealPointsSpells.SPELL_REJUV) then
    timeFactor = timeFactor * (1 + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.EMPREJ) * 0.04); -- +4% bonus healing per rank
  elseif (spell.class.classID == HealPointsSpells.SPELL_REGR) then
    timeFactor = timeFactor * (1 + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.EMPREJ) * 0.04); -- +4% bonus healing per rank (Burst)
    timeFactor2 = timeFactor2 * (1 + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.EMPREJ) * 0.04); -- +4% bonus healing per rank (HoT)
  elseif (spell.class.classID == HealPointsSpells.SPELL_LIFEBL) then
    timeFactor = timeFactor * (1 + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.EMPREJ) * 0.04); -- +4% bonus healing per rank 
    timeFactor2 = timeFactor2 * (1 + HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.EMPREJ) * 0.04); -- +4% bonus healing per rank 
  elseif (spell.class.classID == HealPointsSpells.SPELL_HW) then
    timeFactor = timeFactor + HealPointsTalents:getTalentRank(HealPointsTalents.SHAMAN.TIDWAV) * 0.04; -- +4% bonus healing per rank
  elseif (spell.class.classID == HealPointsSpells.SPELL_LHW) then
    timeFactor = timeFactor + HealPointsTalents:getTalentRank(HealPointsTalents.SHAMAN.TIDWAV) * 0.02; -- +2% bonus healing per rank  
  end
  
  if (timeFactor2 ~= nil) then
    return levelFactor * timeFactor, levelFactor * timeFactor2;
  else
    return levelFactor * timeFactor;
  end
end

function HealPointsSpells:getSpellCritBonus(spell)
  local critBonus = 0;
  
  if (spell.class.classID == HealPointsSpells.SPELL_REGR) then
    critBonus = 10 * HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.IMPREG); -- Increases crit for Regrowth by 10% per rank
  elseif (spell.class.classID == HealPointsSpells.SPELL_HT) then
    critBonus = 2 * HealPointsTalents:getTalentRank(HealPointsTalents.DRUID.NATMAJ); -- Increases crit for Healing Touch by 2% per rank
  elseif (spell.class.classID == HealPointsSpells.SPELL_HL) then
    critBonus = 2 * HealPointsTalents:getTalentRank(HealPointsTalents.PALADIN.SANCLI); -- Increases crit for Holy Light and Holy Shock by 2% per rank
    critBonus = critBonus + HealPointsBS:GetBonus('CRIT_HL'); -- Tier 6
  elseif (spell.class.classID == HealPointsSpells.SPELL_HS) then
    critBonus = 2 * HealPointsTalents:getTalentRank(HealPointsTalents.PALADIN.SANCLI); -- Increases crit for Holy Light and Holy Shock by 2% per rank  
    critBonus = critBonus + HealPointsBS:GetBonus('CRIT_HS'); -- Tier 7
  elseif (spell.class.classID == HealPointsSpells.SPELL_FOL) then
    critBonus = HealPointsBS:GetBonus('CRIT_FOL'); -- Arena set
  end
  
  return critBonus;
end

function HealPointsSpells:getHealingBonus(spell)
  local healBonus = 0;

  if (spell.class.classID == HealPointsSpells.SPELL_FOL) then
    healBonus = HealPointsBS:GetBonus('AVG_ABS_FOL'); -- Libram of Grace/Divinity
  elseif (spell.class.classID == HealPointsSpells.SPELL_HL) then
    healBonus = HealPointsBS:GetBonus('AVG_ABS_HL');
  elseif (spell.class.classID == HealPointsSpells.SPELL_REJUV) then
    healBonus = HealPointsBS:GetBonus('AVG_ABS_REJUV'); -- Idol of Rejuvenation
  elseif (spell.class.classID == HealPointsSpells.SPELL_HT) then
    healBonus = HealPointsBS:GetBonus('AVG_ABS_HT'); -- Idol of Health
  elseif (spell.class.classID == HealPointsSpells.SPELL_LHW) then
    healBonus = HealPointsBS:GetBonus('AVG_ABS_LHW'); -- Totem of Life/Sustaining
  elseif (spell.class.classID == HealPointsSpells.SPELL_HW) then
    healBonus = HealPointsBS:GetBonus('AVG_ABS_HW');
  elseif (spell.class.classID == HealPointsSpells.SPELL_CHAIN) then
    healBonus = HealPointsBS:GetBonus('AVG_ABS_CHAIN');
  end
  
  return healBonus;
end
