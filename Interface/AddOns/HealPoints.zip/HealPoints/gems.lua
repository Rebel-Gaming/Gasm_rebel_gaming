
HealPointsGems = {
};

HealPointsGems.gems ={
    -- Red gems
  runedScarletRuby = {
    name = "+19 Spell Power - Runed Scarlet Ruby",
    stats = {
      HEAL = 19,
    }
  },

  -- Blue gems
  lustrousSkySapphire = {
    name = "+6 Mana every 5 seconds - Lustrous Sky Sapphire",
    stats = {
      MANAREG = 6,
    }
  },
  sparklingSkySapphire = {
    name = "+16 Spirit - Sparkling Sky Sapphire",
    stats = {
      SPI = 16,
    }
  },
  
  -- Yellow gems
  brilliantAutumnsGlow = {
    name = "+16 Intellect - Brilliant Autumn's Glow",
    stats = {
      INT = 16,
    }
  },
  quickAutumnsGlow = {
    name = "+16 Haste Rating - Quick Autumn's Glow",
    stats = {
      SPELLHASTERATING = 16,
    }
  },
  smoothAutumnsGlow = {
    name = "+16 Critical Strike Rating - Smooth Autumn's Glow",
    stats = {
      SPELLCRITRATING = 16,
    }
  },

  -- Purple gems
  glowingTwilightOpal = {
    name = "+9 Spell Power and +12 Stamina - Glowing Twilight Opal",
    stats = {
      HEAL = 9,
    },
  },
  purifiedTwilightOpal = {
    name = "+9 Spell Power and +8 Spirit - Purified Twilight Opal",
    stats = {
      HEAL = 9,
      SPI = 8,
    },
  },
  royalTwilightOpal = {
    name = "+9 Spell Power and +3 Mana every 5 seconds - Royal Twilight Opal",
    stats = {
      HEAL = 9,
      MANAREG = 3,
    },
  },


  -- Green gems
  dazzlingForestEmerald = {
    name = "+8 Intellect and +3 Mana every 5 seconds - Dazzling Forest Emerald",
    stats = {
      INT = 8,
      MANAREG = 3,
    },
  },
  energizedForestEmerald = {
    name = "+8 Haste Rating and +3 Mana every 5 seconds - Energized Forest Emerald",
    stats = {
      SPELLHASTERATING = 8,
      MANAREG = 3,
    },
  },
  forcefulForestEmerald = {
    name = "+8 Haste Rating and +12 Stamina - Forceful Forest Emerald",
    stats = {
      SPELLHASTERATING = 8,
    }
  },
  intricateForestEmerald = {
    name = "+8 Haste Rating and +8 Spirit - Intricate Forest Emerald",
    stats = {
      SPELLHASTERATING = 8,
      SPI = 8,
    },
  },
  jaggedForestEmerald = {
    name = "+8 Critical Strike Rating and +12 Stamina - Jagged Forest Emerald",
    stats = {
      SPELLCRITRATING = 8,
    }
  },
  mistyForestEmerald = {
    name = "+8 Critical Strike Rating and +8 Spirit - Misty Forest Emerald",
    stats = {
      SPELLCRITRATING = 8,
      SPI = 8,
    }
  },
  seersForestEmerald = {
    name = "+8 Intellect and +8 Spirit - Seer's Forest Emerald",
    stats = {
      INT = 8,
      SPI = 8,
    }
  },
  sunderedForestEmerald = {
    name = "+8 Critical Strike Rating and +3 Mana every 5 seconds - Sundered Forest Emerald",
    stats = {
      SPELLCRITRATING = 8,
      MANAREG = 3,
    }
  },
  timelessForestEmerald = {
    name = "+8 Intellect and +12 Stamina - Timeless Forest Emerald",
    stats = {
      INT = 8,
    }
  },

  -- Orange gems
  luminousMonarchTopaz = {
    name = "+9 Spell Power and +8 Intellect - Luminous Monarch Topaz",
    stats = {
      HEAL = 9,
      INT = 8,
    }
  },
  potentMonarchTopaz = {
    name = "+9 Spell Power and +8 Critical Strike Rating - Potent Monarch Topaz",
    stats = {
      HEAL = 9,
      SPELLCRITRATING = 8,
    }    
  },
  recklessMonarchTopaz = {
    name = "+9 Spell Power and +8 Haste Rating - Reckless Monarch Topaz",
    stats = {
      HEAL = 9,
      SPELLHASTERATING = 8,
    }
  },
}

function HealPointsGems:getBlueSelected()
  local number = HealPoints.db.char.gems.blueGem;
  local gemName = HealPointsGems.blueSocket[number];
  if (gemName == nil or gemName == "None") then
    return nil;
  else
    local i, gem;
    for i, gem in pairs(HealPointsGems.gems) do
      if (gemName == gem.name) then
        return gem.stats;
      end
    end
    return nil;
  end
end
    
function HealPointsGems:getRedSelected()
  local number = HealPoints.db.char.gems.redGem;
  local gemName = HealPointsGems.redSocket[number];
  if (gemName == nil or gemName == "None") then
    return nil;
  else
    local i, gem;
    for i, gem in pairs(HealPointsGems.gems) do
      if (gemName == gem.name) then
        return gem.stats;
      end
    end
    return nil;
  end
end

function HealPointsGems:getYellowSelected()
  local number = HealPoints.db.char.gems.yellowGem;
  local gemName = HealPointsGems.yellowSocket[number];
  if (gemName == nil or gemName == "None") then
    return nil;
  else
    local i, gem;
    for i, gem in pairs(HealPointsGems.gems) do
      if (gemName == gem.name) then
        return gem.stats;
      end
    end
    return nil;
  end
end

HealPointsGems.blueSocket ={
  [1]  = "None",
  
  -- Blue
  [2]  = HealPointsGems.gems.lustrousSkySapphire.name,
  [3] =  HealPointsGems.gems.sparklingSkySapphire.name,

  -- Purple
  [4] = HealPointsGems.gems.glowingTwilightOpal.name,
  [5] = HealPointsGems.gems.purifiedTwilightOpal.name,
  [6] = HealPointsGems.gems.royalTwilightOpal.name,

  -- Green
  [7]  = HealPointsGems.gems.dazzlingForestEmerald.name,
  [8] =  HealPointsGems.gems.energizedForestEmerald.name,
  [9] =  HealPointsGems.gems.forcefulForestEmerald.name,
  [10] = HealPointsGems.gems.intricateForestEmerald.name,
  [11] = HealPointsGems.gems.jaggedForestEmerald.name,
  [12] = HealPointsGems.gems.mistyForestEmerald.name,
  [13] = HealPointsGems.gems.seersForestEmerald.name,
  [14] = HealPointsGems.gems.sunderedForestEmerald.name,
  [15] = HealPointsGems.gems.timelessForestEmerald.name,
}

HealPointsGems.redSocket ={
  [1] =  "None",

  -- Red
  [2] = HealPointsGems.gems.runedScarletRuby.name,

  -- Purple
  [3] = HealPointsGems.gems.glowingTwilightOpal.name,
  [4] = HealPointsGems.gems.purifiedTwilightOpal.name,
  [5] = HealPointsGems.gems.royalTwilightOpal.name,

  -- Orange
  [6] =  HealPointsGems.gems.luminousMonarchTopaz.name,
  [7] =  HealPointsGems.gems.potentMonarchTopaz.name,
  [8] =  HealPointsGems.gems.recklessMonarchTopaz.name,
}

HealPointsGems.yellowSocket ={
  [1] =  "None",

  -- Yellow
  [2] =  HealPointsGems.gems.brilliantAutumnsGlow.name,
  [3] =  HealPointsGems.gems.quickAutumnsGlow.name,
  [4] =  HealPointsGems.gems.smoothAutumnsGlow.name,

  -- Green
  [5]  = HealPointsGems.gems.dazzlingForestEmerald.name,
  [6] =  HealPointsGems.gems.energizedForestEmerald.name,
  [7] =  HealPointsGems.gems.forcefulForestEmerald.name,
  [8] =  HealPointsGems.gems.intricateForestEmerald.name,
  [9] =  HealPointsGems.gems.jaggedForestEmerald.name,
  [10] = HealPointsGems.gems.mistyForestEmerald.name,
  [11] = HealPointsGems.gems.seersForestEmerald.name,
  [12] = HealPointsGems.gems.sunderedForestEmerald.name,
  [13] = HealPointsGems.gems.timelessForestEmerald.name,

  -- Orange
  [14] = HealPointsGems.gems.luminousMonarchTopaz.name,
  [15] = HealPointsGems.gems.potentMonarchTopaz.name,
  [16] = HealPointsGems.gems.recklessMonarchTopaz.name,
}

