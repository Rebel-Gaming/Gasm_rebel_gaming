HealPoints = LibStub("AceAddon-3.0"):NewAddon("HealPoints", "AceConsole-3.0", "AceEvent-3.0", "AceHook-3.0")

HealPoints.ISHEALER = nil;
local lastLink = nil;
local diff1 = nil;
local diff2 = nil;
local diff3 = nil;
local diff4 = nil;

local defaults = {};
defaults.char = {};
defaults.char.power = {};
defaults.char.endurance = {};
defaults.char.hot = {};
defaults.char.gems = {};
defaults.char.power.spell = "";
defaults.char.power.auto = true;
defaults.char.power.duration = 1;
defaults.char.power.rank = nil; -- Old stat
defaults.char.power.mana = 100;
defaults.char.endurance.spell = "";
defaults.char.endurance.auto = true;
defaults.char.endurance.duration = 5;
defaults.char.endurance.rank = nil; -- Old stat
defaults.char.endurance.mana = 0;
defaults.char.hot.numtargets = 3;
defaults.char.tooltips = 1;
defaults.char.debug = 0;
defaults.char.gems.blueGem = 1;
defaults.char.gems.redGem = 1;
defaults.char.gems.yellowGem = 1;
defaults.char.replenishment = false;
defaults.char.divineplea = false;

function HealPoints:OnInitialize()
  local _, className = UnitClass("player");
  if (className == "PALADIN" or className == "PRIEST" or className == "DRUID" or className == "SHAMAN") then
    HealPoints.ISHEALER = 1;
    self.db = LibStub("AceDB-3.0"):New("HEALPOINTS_CONFIG", defaults);
    HealPointsSpells:init();
    HealPointsCalculatorUI:init();
    HealPointsConfigUI:init();
  else
    return;
  end

  self:SecureHook(GameTooltip, "SetAuctionItem", function(...)
    local _, link = GameTooltip:GetItem();
    self:DrawTooltip(GameTooltip, link);
    end);

  self:SecureHook(GameTooltip, "SetBagItem", function(...)
    local _, link = GameTooltip:GetItem();
    self:DrawTooltip(GameTooltip, link);
    end);

  self:SecureHook(GameTooltip, "SetHyperlink", function(...)
    local _, link = GameTooltip:GetItem();
    self:DrawTooltip(GameTooltip, link)
    end);

  self:SecureHook(GameTooltip, "SetInventoryItem", function(this, unit, slot)
    if (slot > 39) then -- bank
      local _, link = GameTooltip:GetItem();
      self:DrawTooltip(GameTooltip, link);
    end
    end);

  self:SecureHook(GameTooltip, "SetLootItem", function(...)
    local _, link = GameTooltip:GetItem();
    self:DrawTooltip(GameTooltip, link);
    end);

  self:SecureHook(GameTooltip, "SetLootRollItem", function(...)
    local _, link = GameTooltip:GetItem();
    self:DrawTooltip(GameTooltip, link);
    end);

  self:SecureHook(GameTooltip, "SetMerchantItem", function(...)
    local _, link = GameTooltip:GetItem();
    self:DrawTooltip(GameTooltip, link);
    end);

  self:SecureHook(GameTooltip, "SetQuestItem", function(...)
    local _, link = GameTooltip:GetItem();
    self:DrawTooltip(GameTooltip, link);
    end);

  self:SecureHook(GameTooltip, "SetQuestLogItem", function(...)
    local _, link = GameTooltip:GetItem();
    self:DrawTooltip(GameTooltip, link);
    end);

  self:SecureHook(GameTooltip, "SetTradeSkillItem", function(...)
    local _, link = GameTooltip:GetItem();
    self:DrawTooltip(GameTooltip, link);
    end);

  self:SecureHook("SetItemRef", function(link, name, button)
    if(link and name and ItemRefTooltip) then
      if( strsub(link, 1, 6) ~= "Player" ) then
        if( ItemRefTooltip:IsVisible()) then
          if(not DressUpFrame:IsVisible()) then
            self:DrawTooltip(ItemRefTooltip, link);
          end
          ItemRefTooltip.isDisplayDone = nil;
        end
      end
    end
  end);

  self:SecureHook(HealPointsBS, "update", HealPoints.GearChanged);

  -- Remove old settings
  HEALPOINTS_CONFIG['endurance'] = nil;
  HEALPOINTS_CONFIG['power'] = nil;
  HEALPOINTS_CONFIG['tooltips'] = nil;
  HEALPOINTS_CONFIG['regen'] = nil;
  HEALPOINTS_CONFIG['hot'] = nil;
end

function HealPoints:OnEnable(first)
  if (HealPoints.ISHEALER == 1) then
    self:RegisterEvent("UNIT_AURA", "StatsChanged");
    self:RegisterEvent("UNIT_LEVEL", "StatsChanged");
    self:RegisterEvent("UNIT_MAXMANA", "StatsChanged");
    self:RegisterEvent("UNIT_STATS", "StatsChanged");
    self:RegisterEvent("LEARNED_SPELL_IN_TAB", "SpellsChanged");
    self:RegisterEvent("CHARACTER_POINTS_CHANGED", "TalentsChanged");
    if (not self:IsHooked(HealPointsBS, "update")) then
      self:SecureHook(HealPointsBS, "update", HealPoints.GearChanged);
    end
    HealPointsConfigUI:spellsChanged();
    HealPoints_CharFrame:Show();
    if (not first) then
      HealPointsCalculator:updateHealPoints();
    end
  else
    DisableAddOn("HealPoints");
  end
end

function HealPoints:OnDisable()
  HealPoints_CharFrame:Hide();
  HealPoints_CalcFrame:Hide();
  HealPoints_ConfigFrame:Hide();
end

function HealPoints:StatsChanged(target) -- UNIT_AURA, UNIT_LEVEL, UNIT_MAXMANA, UNIT_STATS
  lastLink = nil;
  if (UnitIsUnit(target, "player")) then
    if (HealPoints_CalcFrame:IsVisible()) then
      HealPointsCalculator:updateStats();
      HealPointsCalculatorUI:updateSelectedSpellStats();
    end
    if (HealPoints_CalcFrame:IsVisible() or CharacterFrame:IsVisible()) then
      HealPointsCalculator:updateHealPoints();
    end
  end
end

function HealPoints:SpellsChanged(spelltabnr) -- LEARNED_SPELL_IN_TAB
  lastLink = nil;
  HealPointsSpells:spellsChanged();
  HealPointsCalculatorUI:updateSpellLists();
  if (HealPoints_CalcFrame:IsVisible()) then
    HealPointsCalculator:updateStats();
    HealPointsCalculatorUI:updateSelectedSpellStats();
  end
  HealPointsCalculator:updateHealPoints();
  HealPointsConfigUI:spellsChanged();
end

function HealPoints:TalentsChanged(delta) -- CHARACTER_POINTS_CHANGED
  lastLink = nil;
  HealPointsCalculator:talentsChanged();
  HealPointsCalculatorUI:updateSpellLists();
  if (HealPoints_CalcFrame:IsVisible()) then
    HealPointsCalculator:updateStats();
    HealPointsCalculatorUI:updateSelectedSpellStats();
  end
  HealPointsCalculator:updateHealPoints();
end

function HealPoints:GearChanged()
  lastLink = nil;
  if (HealPoints_CalcFrame:IsVisible()) then
    HealPointsCalculator:updateStats();
    HealPointsCalculatorUI:updateSelectedSpellStats();
  end
  if (HealPoints_CalcFrame:IsVisible() or CharacterFrame:IsVisible()) then
    HealPointsCalculator:updateHealPoints();
  end
end

function HealPoints:DrawTooltip(frame, reference)
  local function addLine(text, d1, d2)
    if (d1 == d2) then
      frame:AddDoubleLine(text, HealPointsUtil:colorValue(d1),
        NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b,
        NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
    else
      frame:AddDoubleLine(text, HealPointsUtil:colorValue(d1).." / "..HealPointsUtil:colorValue(d2),
        NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b,
        NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
    end
  end

  if (HealPoints:IsEnabled() and HealPoints.db.char.tooltips ~= 0 and reference ~= nil and string.find(reference, "item", 0, true) ~= nil) then
    if (reference ~= lastLink) then
      diff1, diff2, diff3, diff4 = HealPointsCalculator:computeHealpointsDiff(reference)
      lastLink = reference;
    end
    if (diff3 ~= nil and diff3 ~= 0 and diff4 ~= nil and diff4 ~= 0) then
      addLine("HealPoints difference, top slot:", diff1, diff2);
      addLine("HealPoints difference, bottom slot:", diff3, diff4);
      frame:Show();
    elseif (diff1 ~= 0 or diff2 ~= 0) then
      addLine("HealPoints difference:", diff1, diff2);
      frame:Show();
    end
  end
end

function HealPoints:clearLinkCache()
  lastLink = nil;
end

function HealPoints:listScannedBonuses()
  local _, className = UnitClass("player");
  self:Print("Special set/equip bonuses detected:");
  self:Print("===================================");
  if (className == "PALADIN") then
    self:Print("Increases the effective spell power of your Holy Shock when used as a healing spell by "..HealPointsBS:GetBonus('AVG_PC_HS').."%");
    self:Print("Increases spell power of Flash of Light by "..HealPointsBS:GetBonus('AVG_PC_FOL').."%");
    self:Print("The cost of your Holy Light is reduced by "..HealPointsBS:GetBonus('MANA_PC_HL').."%");
    self:Print("Increases spell power of Flash of Light by "..HealPointsBS:GetBonus('AVG_ABS_FOL'));
    self:Print("Increases spell power of Holy Light by "..HealPointsBS:GetBonus('AVG_ABS_HL'));
    self:Print("Reduces the mana cost of Holy Light by "..HealPointsBS:GetBonus('MANA_ABS_HL'));
  elseif (className == "PRIEST") then
    self:Print("Increases the duration of your Renew spell by "..HealPointsBS:GetBonus('DURATION_RENEW').." sec.");
    self:Print("Reduces the mana cost of your Prayer of Healing ability by "..HealPointsBS:GetBonus('MANA_PC_POH').."%");
    self:Print("Increases the healing from your Greater Heal ability by "..HealPointsBS:GetBonus('AVG_PC_GH').."%");
    self:Print("The cost of your Greater Heal is reduced by "..HealPointsBS:GetBonus('MANA_PC_GH').."%");
  elseif (className == "DRUID") then
    self:Print("Increases the duration of your Regrowth spell by "..HealPointsBS:GetBonus('DURATION_REGR').." sec.");
    self:Print("Increases the spell power of the final healing value of your Lifebloom by "..HealPointsBS:GetBonus('AVG_BURST_LIFEBL'));
    self:Print("Increases the healing from your Healing Touch ability by "..HealPointsBS:GetBonus('AVG_PC_HT').."%");
    self:Print("The cost of your Rejuvenation is reduced by "..HealPointsBS:GetBonus('MANA_PC_REJUV').."%");
    self:Print("Increases the amount healed by Healing Touch by "..HealPointsBS:GetBonus('AVG_ABS_HT'));
    self:Print("Gain up to "..HealPointsBS:GetBonus('MANA_REFUND_HT').." mana each time you cast Healing Touch ");
    self:Print("Increases spell power of Rejuvenation by "..HealPointsBS:GetBonus('AVG_ABS_REJUV'));
    self:Print("Increases the spell power on the periodic portion of your Lifebloom by "..HealPointsBS:GetBonus('AVG_HOT_LIFEBL'));
    self:Print("Reduces the mana cost of Regrowth by "..HealPointsBS:GetBonus('MANA_ABS_REGR'));
    self:Print("Reduces the mana cost of Rejuvenation by "..HealPointsBS:GetBonus('MANA_ABS_REJUV'));
  elseif (className == "SHAMAN") then
    self:Print("Reduces the cost of your Lesser Healing Wave spell by "..HealPointsBS:GetBonus('MANA_PC_LHW').."%");
    self:Print("Your Chain Heal ability costs "..HealPointsBS:GetBonus('MANA_PC_CHAIN').."% less mana.");
    self:Print("Increases the amount healed by your Chain Heal ability by "..HealPointsBS:GetBonus('AVG_PC_CHAIN').."%");
    self:Print("Increases the healing done by your Chain Heal and Healing Wave by "..HealPointsBS:GetBonus('AVG_PC_CHAIN_HW').."%");
    self:Print("Increases the base amount healed by Chain Heal by "..HealPointsBS:GetBonus('AVG_ABS_CHAIN'));
    self:Print("Increases spell power of Lesser Healing Wave by "..HealPointsBS:GetBonus('AVG_ABS_LHW'));
    self:Print("Reduces the mana cost of Heaing Wave by "..HealPointsBS:GetBonus('MANA_ABS_HW'));
    self:Print("Increases spell power of Healing Wave by "..HealPointsBS:GetBonus('AVG_ABS_HW'));
    self:Print("Reduces the mana cost of Chain Heal by "..HealPointsBS:GetBonus('MANA_ABS_CHAIN'));
  end
end
