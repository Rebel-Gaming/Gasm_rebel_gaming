-------------------
--  Load Module  --
-------------------
local mod = DBM:NewMod("MODNAME", "DBM-Forte")
local L = mod:GetLocalizedStrings()


-------------------
--  Initialize   --
-------------------
mod:SetRevision(("$Revision: 180 $"):sub(12, -3))
mod:SetCreatureID(IDHERE)
mod:SetZone()
mod:RegisterCombat("combat")

mod:RegisterEvents(
	"SPELL_AURA_APPLIED",
	"SPELL_AURA_REMOVED"
)


-------------------
--  Options      --
-------------------
mod.Options.HealthFrame = nil


-------------------
--  Event Funcs  --
-------------------
function mod:OnCombatStart(delay)
	
end

function mod:OnCombatEnd()

end

function mod:SPELL_AURA_APPLIED(args)

end

function mod:SPELL_AURA_REMOVED(args)

end


-------------------
--  Other Funcs  --
-------------------



