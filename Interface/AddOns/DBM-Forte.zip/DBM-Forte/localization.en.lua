local L

---------------
--  Malygos  --
---------------
L = DBM:GetModLocalization("Malygos-Forte")

L:SetGeneralLocalization({
	name = "Malygos-Forte"
})

L:SetWarningLocalization({
})

L:SetTimerLocalization({
	TimerSurge		= "Shield Yourself Soon!!!"
})

L:SetOptionLocalization({
	TimerSurge		= "Surge Timer: Pre-emptive timer 3 seconds before you are hit with Surge",
	Camera	= "Camera Max: Increase your camera distance to Max-Range at the start of combat, returns to your current at the end of combat"
})

L:SetMiscLocalization({
	YellPull		= "My patience has reached its limit. I will be rid of you!",
	EmoteSpark		= "A Power Spark forms from a nearby rift!",
	YellPhase2		= "I had hoped to end your lives quickly",
	EmoteBreath		= "%s takes a deep breath.",
	YellBreath		= "You will not succeed while I draw breath!",
	YellPhase3		= "Now your benefactors make their"
})

---------------
--  Kel'thuzad  --
---------------
L = DBM:GetModLocalization("KT-Forte")

L:SetGeneralLocalization({
	name = "KT-Forte"
})

L:SetWarningLocalization({
	WarningKT = "Kel'Thuzad Active in 10 Seconds!"
})

L:SetTimerLocalization({
	BlastTimer		= "HEAL NOW!"
})

L:SetOptionLocalization({
	BlastTimer		= "Frost Blast Timer: 4 second Countdown timer until the victims die",
	BlastAlarm		= "Frost Blast Alarm: Siren sounds when Frost Blast is cast",
	ShowRange		= "Turn on the RangeFinder when KT is active",
	WarningKT 		= "Warn 10 sec before KT is active"
})

L:SetMiscLocalization({
	Yell	= "Minions, servants, soldiers of the cold dark! Obey the call of Kel'Thuzad!"
})


---------------
--  Grobbulus  --
---------------
L = DBM:GetModLocalization("Grobbulus-Forte")

L:SetGeneralLocalization({
	name = "Grobbulus-Forte"
})

L:SetWarningLocalization({

})

L:SetTimerLocalization({
})

L:SetOptionLocalization({
	MultiMark = "MultiMark: Sets multiple marks for injections"
})

L:SetMiscLocalization({
})

---------------
--  Loatheb  --
---------------
L = DBM:GetModLocalization("Loatheb-Forte")

L:SetGeneralLocalization({
	name = "Loatheb-Forte"
})

L:SetWarningLocalization({

})

L:SetTimerLocalization({
})

L:SetOptionLocalization({
	SporeDamageAlert = "AchieveAssist: Raid Warn and Whisper offenders who damage Spores"
})

L:SetMiscLocalization({
})