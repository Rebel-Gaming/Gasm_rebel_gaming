local origslash = SlashCmdList["DEADLYBOSSMODS"]

SlashCmdList["DEADLYBOSSMODS"] = function(msg)
	local cmd = msg:lower()
	if cmd:sub(0,5) == "break" then
		if DBM:GetRaidRank() == 0 then
			DBM:AddMsg(DBM_ERROR_NO_PERMISSION)
			return
		end
		local timer = tonumber(cmd:sub(6)) or 5
		local timer = timer * 60
		local BREAK_START = "Break starting now -- you have %s minute(s)!"
		local BREAK_MIN = "Break ends in %s minutes!"
		local BREAK_SEC = "Break ends in %s seconds!"
		DBM:CreatePizzaTimer(timer, "Break time!", true)
		DBM:Unschedule(SendChatMessage)
		SendChatMessage(BREAK_START:format(timer/60), "RAID_WARNING")
		if timer/60 > 5 then DBM:Schedule(timer - 5*60, SendChatMessage, BREAK_MIN:format(5), "RAID") end
		if timer/60 > 2 then DBM:Schedule(timer - 2*60, SendChatMessage, BREAK_MIN:format(2), "RAID") end
		if timer/60 > 1 then DBM:Schedule(timer - 1*60, SendChatMessage, BREAK_MIN:format(1), "RAID_WARNING") end
		if timer > 30 then DBM:Schedule(timer - 30, SendChatMessage, BREAK_SEC:format(30), "RAID_WARNING") end
		DBM:Schedule(timer, SendChatMessage, "Break time is over", "RAID_WARNING")
	else
		return origslash(msg)
	end
end

table.insert(DBM_CORE_SLASHCMD_HELP, "/dbm break <min>: Starts a break for <min> minutes.  Will give all raid members with DBM a break timer.(DBM-Forte)")