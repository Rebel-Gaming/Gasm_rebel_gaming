-------------------
--  Load Module  --
-------------------
local mod = DBM:NewMod("Loatheb-Forte", "DBM-Forte")
local L = mod:GetLocalizedStrings()


-------------------
--  Initialize   --
-------------------
mod:SetRevision(("$Revision: 180 $"):sub(12, -3))
mod:SetCreatureID(16011)
mod:SetZone()
mod:RegisterCombat("combat")

mod:RegisterEvents(
	"SPELL_DAMAGE",
	"SWING_DAMAGE"
)


-------------------
--  Options      --
-------------------
mod.Options.HealthFrame = nil
mod:AddBoolOption("SporeDamageAlert", false)


-------------------
--  Event Funcs  --
-------------------
function mod:OnCombatStart(delay)
	
end

function mod:OnCombatEnd()

end

function mod:SPELL_DAMAGE(args)
	if self.Options.SporeDamageAlert and args.destName == "Spore" and args.spellId ~= 62124 and self:IsInCombat() then
		SendChatMessage(args.sourceName..", YOU are damaging a Spore!!! ("..args.amount.." damage)", "RAID_WARNING")
		SendChatMessage(args.sourceName..", YOU are damaging a Spore!!! ("..args.amount.." damage)", "WHISPER", nil, args.sourceName)
	end
end

function mod:SWING_DAMAGE(args)
	if self.Options.SporeDamageAlert and args.destName == "Spore" and self:IsInCombat() then
		SendChatMessage(args.sourceName..", YOU are damaging a Spore!!! ("..args.amount.." damage)", "RAID_WARNING")
		SendChatMessage(args.sourceName..", YOU are damaging a Spore!!! ("..args.amount.." damage)", "WHISPER", nil, args.sourceName)
	end
end


-------------------
--  Other Funcs  --
-------------------



