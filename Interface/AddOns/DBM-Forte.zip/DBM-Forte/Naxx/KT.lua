-------------------
--  Load Module  --
-------------------
local mod = DBM:NewMod("KT-Forte", "DBM-Forte")
local L = mod:GetLocalizedStrings()


-------------------
--  Initialize   --
-------------------
mod:SetRevision(("$Revision: 458 $"):sub(12, -3))
mod:SetCreatureID(15990)
mod:SetZone()
mod:SetMinCombatTime(60)

mod:RegisterCombat("yell", L.Yell)

mod:RegisterEvents(
	"SPELL_AURA_APPLIED"
)

local blastTimer		= mod:NewTimer(4, "BlastTimer")
local warnKT			= mod:NewSpecialWarning("WarningKT")

-------------------
--  Options      --
-------------------
mod:AddBoolOption("BlastAlarm", true)
mod:AddBoolOption("ShowRange", true)
mod.Options.HealthFrame = nil


-------------------
--  Event Funcs  --
-------------------
function mod:OnCombatStart(delay)
	if self.Options.ShowRange then
		self:ScheduleMethod(215-delay, "RangeToggle", true)
	end	
	warnKT:Schedule(215-delay)
end

function mod:OnCombatEnd()
	if self.Options.ShowRange then
		self:RangeToggle(false)
	end
end

function mod:SPELL_AURA_APPLIED(args)
	if self:IsInCombat() then	
		if args.spellId == 27808 then
			self:SendSync("BlastAlarm")
		end
	end
end

function mod:OnSync(event, arg)
	if event == "BlastAlarm" and self.Options.BlastAlarm then
		PlaySoundFile("Interface\\Addons\\DBM-Forte\\sound\\alarm1.wav")
		blastTimer:Start()
	end
end

-------------------
--  Other Funcs  --
-------------------

function mod:RangeToggle(show)
	if show then
		DBM.RangeCheck:Show(10)
	else
		DBM.RangeCheck:Hide()
	end
end