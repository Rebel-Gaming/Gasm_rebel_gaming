-------------------
--  Load Module  --
-------------------
local mod = DBM:NewMod("Grobbulus-Forte", "DBM-Forte")
local L = mod:GetLocalizedStrings()


-------------------
--  Initialize   --
-------------------
mod:SetRevision(("$Revision: 180 $"):sub(12, -3))
mod:SetCreatureID(15931)
mod:SetZone()
mod:RegisterCombat("combat")

mod:RegisterEvents(
	"SPELL_AURA_APPLIED",
	"SPELL_AURA_REMOVED"
)

mod.icontrack = {}
local oldSetIcon = 0


-------------------
--  Options      --
-------------------
mod:AddBoolOption("MultiMark", true)
mod.Options.HealthFrame = nil


-------------------
--  Event Funcs  --
-------------------
function mod:OnCombatStart(delay)
	grobmod = DBM:GetModByName("Grobbulus")
	if grobmod and self.Options.MultiMark then
		oldSetIcon = grobmod.SetIcon
		function grobmod:SetIcon(...)	end	
	end
	if self.Options.MultiMark then
		self.icontrack = {}
	end
end	


function mod:OnCombatEnd()
	for i,j in ipairs(self.icontrack) do SetRaidTarget(j, 0) end
	self.icontrack = {}
	grobmod = DBM:GetModByName("Grobbulus")
	if grobmod and self.Options.MultiMark then
		grobmod.SetIcon = oldSetIcon
	end
end
--------------------
function mod:SPELL_AURA_APPLIED(args)
	if self:IsInCombat() then	
		if self.Options.MultiMark then
			if args.spellId == 28169 then
				table.insert(self.icontrack, args.destName)
				self:AddIcon()
				self:ScheduleMethod(1, "AddIcon")
			end
		end
	end
end

function mod:SPELL_AURA_REMOVED(args)
	if self:IsInCombat() then	
		if args.spellId == 28169 then
			for i,j in ipairs(self.icontrack) do
				if (j == args.destName) then 
					table.remove(self.icontrack, i)
					self:RemIcon(args.destName) 
					self:ScheduleMethod(1, "AddIcon")
				end
			end
		end
	end
end


-------------------
--  Other Funcs  --
-------------------
function mod:AddIcon()
	local icon = nil
	for i,j in ipairs(self.icontrack) do
		if (i == 1) then icon = 8 end
		if (i == 2) then icon = 2 end
		if (i == 3) then icon = 5 end
		if (i == 4) then icon = 3 end
		SetRaidTarget(j,icon)
	end

end

function mod:RemIcon(unitid)
	SetRaidTarget(unitid, 0)
	self:AddIcon()
end


