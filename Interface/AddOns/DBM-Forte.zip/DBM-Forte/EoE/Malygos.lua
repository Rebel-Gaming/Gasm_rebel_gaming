-------------------
--  Load Module  --
-------------------
local mod = DBM:NewMod("Malygos-Forte", "DBM-Forte")
local L = mod:GetLocalizedStrings()


-------------------
--  Initialize   --
-------------------
mod:SetRevision(("$Revision: 458 $"):sub(12, -3))
mod:SetCreatureID(28859)
mod:SetZone()

mod:RegisterCombat("yell", L.YellPull)

mod:RegisterEvents(
	"CHAT_MSG_RAID_BOSS_WHISPER",
	"SPELL_CAST_SUCCESS",
	"COMBAT_LOG_EVENT_UNFILTERED"
)


-------------------
--  Options      --
-------------------
local timerSurge	= mod:NewTimer(3, "TimerSurge")
local hotTimer

mod:AddBoolOption("Camera", true, nil)
mod:AddBoolOption("SurgeAlarm", true, nil)
mod.Options.HealthFrame = nil


-------------------
--  Event Funcs  --
-------------------
function mod:OnCombatStart(delay)
	self.usercamera = GetCVar("cameraDistancemax")
	if self.Options.Camera then
		SetCVar("cameraDistancemax", 50)
	end
end

function mod:OnCombatEnd()
	if self.Options.Camera then
		SetCVar("cameraDistancemax", self.usercamera)
	end
	self:TimerHot()
end

function mod:CHAT_MSG_RAID_BOSS_WHISPER(msg)
	if self:IsInCombat() then
		--DBM:AddMsg(msg)
		if self.Options.SurgeAlarm then
			PlaySoundFile("Interface\\Addons\\DBM-Forte\\sound\\alarm1.wav")
			timerSurge:Start()
		end
	end
end

function mod:SPELL_CAST_SUCCESS(args)
	if self:IsInCombat() then	
		--DBM:AddMsg("spell cast by "..args.sourceGUID.." looking for "..UnitGUID("playerpet").."Spell ID: "..args.spellId)
		if args.sourceGUID == UnitGUID("playerpet") or args.sourceGUID == UnitGUID("player") then
			if args.spellId == 56092 then
				if not self.stacks then self.stacks = 0 end
				--DBM:AddMsg("found Flame Engulph")
				self.stacks = self.stacks + 1
				self:TimerHot("start")
				self.combo = 0
			elseif args.spellId == 56091 then
				if not self.combo then self.combo = 0 end
				--DBM:AddMsg("found a flame spike")
				if self.combo < 6 then
					self.combo =self.combo + 1
				end
			elseif args.spellId == 57108 or args.spellId == 57143 or args.spellId == 57090 then
				self.combo = 0
			end
		end
	end
end

function mod:COMBAT_LOG_EVENT_UNFILTERED(timestamp, event, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, ...)
	if self:IsInCombat() then	
		if event == "SPELL_AURA_REMOVED" then
			spellId, spellName, spellSchool = select(1, ...)
			--DBM:AddMsg("Spell Cast Removed with name"..sourceGUID.."and spellid: "..spellId)
			if sourceGUID == UnitGUID("playerpet") or sourceGUID == UnitGUID("player") then
				if spellId == 56092 then
					--DBM:AddMsg("Stack Faded")
					self.stacks = 0
				end
			end
		end
	end
end

-------------------
--  Other Funcs  --
-------------------

function mod:TimerHot(startstop)
	if startstop == "start" then
		hotTimer:Stop()
		local duration = (2 + (mod.combo * 4))
		local hotdps = self.stacks * 500
		hotTimer = self:NewTimer(duration, "Stacks:"..self.stacks.."  Approx:"..hotdps.." DPS")
		hotTimer:Start()
	else
		hotTimer:Stop()
	end
end
