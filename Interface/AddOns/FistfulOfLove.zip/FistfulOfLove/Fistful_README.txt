Fistful of Love Helper AddOn
by Larry Johnson

What does it do?
--------------------------------------------------------------------------------
Any time you target another player, the addon checks to see if that 
player is one of the race/class combinations you need for the 
"Fistful of Love" achievement.  If so, you will receive an alert in 
the chat window as well as a larger alert on the screen so that you 
don't miss it.


How to use it?
--------------------------------------------------------------------------------
The fastest way to use this on friendly units is to stand in a crowded 
city and press Ctrl+Tab to cycle through all nearby friendly units.  When
you hit a unit you need you'll see the alert.

Unfortunately, I'm not aware of any keyboard combo to cycle through players 
of the opposite faction, even when you are in a neutral city like Shattrath or 
Dalaran.  You'll have to click them individually, but it is still faster than 
doing it without the addon.


Enjoy!
