--[[
]]

function Fistful_OnLoad()
	this:RegisterEvent("PLAYER_TARGET_CHANGED");
	Fistful_Print("Fistful Of Love assistant loaded.");
end


function Fistful_OnEvent()
	if ( event == "PLAYER_TARGET_CHANGED" ) then
		if( UnitIsPlayer("target")) then 
			local className = UnitClass("target");
			local raceName = UnitRace("target");
			
			if(
					( (raceName == "Human") and (className == "Death Knight") )
					or 
					( (raceName == "Draenei") and (className == "Paladin") )
					or 
					( (raceName == "Gnome") and (className == "Warlock") )
					or 
					( (raceName == "Night Elf") and (className == "Priest") )
					or 
					( (raceName == "Orc") and (className == "Shaman") ) 
					or 
					( (raceName == "Tauren") and (className == "Druid") ) 
					or 
					( (raceName == "Troll") and (className == "Rogue") )
					or 
					( (raceName == "Undead") and (className == "Warrior") ) 
					or 
					( (raceName == "Blood Elf") and (className == "Mage") ) 
					or 
					( (raceName == "Dwarf") and (className == "Hunter") ) 
				) then 
					--print tostring(Fistful_RaceClassCompleted(raceName, className));
					if(Fistful_RaceClassCompleted(raceName, className)) then 
						--Fistful_Print("You don't need it");
					else 
						Fistful_Alert(raceName, className);
						Fistful_Print("Fistful of Love Alert!  There's a " .. raceName .. " " .. className .. "!" );
					end 
			end 
		end
	end 
end

function Fistful_RaceClassCompleted(raceName, className)
	local combined = raceName .. " " .. className;
	local criteriaName;
	local criteriaCompleted;
	
	for i = 1, GetAchievementNumCriteria(1699) do
		criteriaName, _ , criteriaCompleted = GetAchievementCriteriaInfo(1699, i);
		if(criteriaName == combined) then 
			return criteriaCompleted;
		end 
	end
end 

function Fistful_Alert(raceName, className)
	ZoneTextString:SetText("Fistful of Love Alert!");
	ZoneTextString:SetTextColor(1, 1, 0);
	SubZoneTextString:SetText("There's a " .. raceName .. " " .. className .. "!" );
	SubZoneTextString:SetTextColor(0, 1, 0);
	ZoneTextFrame.startTime=GetTime();
	SubZoneTextFrame.startTime=GetTime();
	ZoneTextFrame:Show();
	SubZoneTextFrame:Show();
end 

function Fistful_Print(msg) 
	if ( ( msg ) and ( strlen(msg) > 0 ) ) then
		if ( DEFAULT_CHAT_FRAME ) then
			DEFAULT_CHAT_FRAME:AddMessage(msg, 1, 1, 0);
		end
	end
end
