﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanWG","frFR",false)

-- Initially translated by Alain (Mirie Elune Alliance)

if L then 

L["TITAN_WG_ACCEPT"] = "Accepter"
L["TITAN_WG_ALLIANCE"] = "Alliance"
L["TITAN_WG_AUTO_ANNOUNCE_GUILD"] = "Avertissement de guilde - 15 min" -- Needs review
-- L["TITAN_WG_AUTO_ANNOUNCE_SELF"] = ""
L["TITAN_WG_AUTO_ANNOUNCE_TRADE"] = "Avertissement commerce - 15 min" -- Needs review
L["TITAN_WG_BATTLE_UNDERWAY"] = "La bataille pour le Joug d'hiver a commencé"
L["TITAN_WG_BROADCAST"] = "Diffusion"
L["TITAN_WG_BUTTON_LABEL"] = "Joug : "
L["TITAN_WG_CANCEL"] = "Annuler"
L["TITAN_WG_CHANNEL"] = "Canal"
L["TITAN_WG_CONTROLLER"] = "Conquis par"
-- L["TITAN_WG_DEFAULT_CHANNEL"] = ""
L["TITAN_WG_ENABLED"] = "Activé"
L["TITAN_WG_GUILD"] = "Guilde"
L["TITAN_WG_HEROIC"] = "Héroïque"
L["TITAN_WG_HIDE"] = "Fermer"
L["TITAN_WG_HORDE"] = "Horde"
L["TITAN_WG_MENU_TEXT"] = "TitanJoug"
L["TITAN_WG_NEXT_BATTLE"] = "Prochaine bataille"
-- L["TITAN_WG_NONE"] = ""
L["TITAN_WG_NORMAL"] = "Normal"
L["TITAN_WG_NORTHREND"] = "Norfendre"
L["TITAN_WG_NO_CURRENCIES"] = "<Rien>"
L["TITAN_WG_NO_ZONE_INFO"] = "Information sur le Joug non disponible"
L["TITAN_WG_PARTY"] = "Groupe"
L["TITAN_WG_PROBABLE_ERROR"] = "Probabilité d'erreur"
L["TITAN_WG_RAID"] = "Raid"
L["TITAN_WG_SAVED"] = "<sauvegardé>"
L["TITAN_WG_SAY"] = "Dire"
-- L["TITAN_WG_SHOW_SECONDS"] = ""
L["TITAN_WG_TIME_ELAPSED"] = "Temp restant"
L["TITAN_WG_TIME_OF_LAST_SYNC"] = "Dernière synchro"
L["TITAN_WG_TIME_UNTIL_WG"] = "Prochain Joug dans "
L["TITAN_WG_TOOLTIP_TITLE"] = "Info sur le Joug d'hiver"
L["TITAN_WG_TRADE"] = "Commerce"
L["TITAN_WG_UNSAVED"] = "Non sauvegardé"
L["TITAN_WG_VAULT_OF_ARCHAVON"] = "Caveau d'Archavon"
L["TITAN_WG_VAULT_OF_ARCHAVON_INFO"] = "Info Caveau d'Archavon"
L["TITAN_WG_WHISPER"] = "Chuchoter"
L["TITAN_WG_WHISPER_TEXT"] = "Envoyer un message à :"
L["TITAN_WG_WINTERGRASP"] = "Essence de Joug-d'hiver"
L["TITAN_WG_WINTERGRASP_CURRENCY_INFO"] = "Info marques Joug d'hiver"
L["TITAN_WG_YELL"] = "Crier"

end
