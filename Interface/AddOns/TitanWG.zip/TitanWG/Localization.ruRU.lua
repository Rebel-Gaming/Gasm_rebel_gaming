﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanWG","ruRU",false)

-- Translated by StingerSoft

if L then

L["TITAN_WG_ACCEPT"] = "Принять"
L["TITAN_WG_ALLIANCE"] = "Альянс"
L["TITAN_WG_AUTO_ANNOUNCE_GUILD"] = "Сообщать в гильдию за 15м до боя"
L["TITAN_WG_AUTO_ANNOUNCE_SELF"] = "Сообщать себе  за 15м до боя"
L["TITAN_WG_AUTO_ANNOUNCE_TRADE"] = "Сообщать в торговый канал за 15м до боя"
L["TITAN_WG_BATTLE_UNDERWAY"] = "Битва за Озеро Ледяных Оков уже идёт"
L["TITAN_WG_BROADCAST"] = "Оповещение"
L["TITAN_WG_BUTTON_LABEL"] = "Озеро: "
L["TITAN_WG_CANCEL"] = "Отмена"
L["TITAN_WG_CHANNEL"] = "В канал"
L["TITAN_WG_CONTROLLER"] = "Контроль над Озером"
L["TITAN_WG_DEFAULT_CHANNEL"] = "Канал по умолчанию для оповещения"
L["TITAN_WG_ENABLED"] = "Включен"
L["TITAN_WG_GUILD"] = "В гильдию"
L["TITAN_WG_HEROIC"] = "Героик"
L["TITAN_WG_HIDE"] = "Скрыть"
L["TITAN_WG_HORDE"] = "Орда"
L["TITAN_WG_MENU_TEXT"] = "TitanWG"
L["TITAN_WG_NEXT_BATTLE"] = "Следующая битва"
L["TITAN_WG_NONE"] = "N/A"
L["TITAN_WG_NORMAL"] = "Обычный"
L["TITAN_WG_NORTHREND"] = "Нордскол"
L["TITAN_WG_NO_CURRENCIES"] = "<Нет>"
L["TITAN_WG_NO_ZONE_INFO"] = "[ Информация об Озере Ледяных Оков недоступна ]"
L["TITAN_WG_PARTY"] = "Группе"
L["TITAN_WG_PROBABLE_ERROR"] = "Возможная ошибка"
L["TITAN_WG_RAID"] = "Рейду"
L["TITAN_WG_SAVED"] = "<сохранён>"
L["TITAN_WG_SAY"] = "Сказать"
L["TITAN_WG_SHOW_SECONDS"] = "Показать секунды"
L["TITAN_WG_TIME_ELAPSED"] = "Прошло времени"
L["TITAN_WG_TIME_OF_LAST_SYNC"] = "Последняя синхр" -- Needs review
L["TITAN_WG_TIME_UNTIL_WG"] = "Битва на Озере через"
L["TITAN_WG_TOOLTIP_TITLE"] = "Информация об Озере Ледяных Оков"
L["TITAN_WG_TRADE"] = "Торговля"
L["TITAN_WG_UNSAVED"] = "<не сохранён>"
L["TITAN_WG_VAULT_OF_ARCHAVON"] = "Склеп Аркавона"
L["TITAN_WG_VAULT_OF_ARCHAVON_INFO"] = "Информация о Склепе Аркавона"
L["TITAN_WG_WHISPER"] = "Шепот"
L["TITAN_WG_WHISPER_TEXT"] = "Выслать сообщение:"
L["TITAN_WG_WINTERGRASP"] = "Озеро Ледяных Оков"
L["TITAN_WG_WINTERGRASP_CURRENCY_INFO"] = "Информация о валюте Озера"
L["TITAN_WG_YELL"] = "Крикнуть"

end

