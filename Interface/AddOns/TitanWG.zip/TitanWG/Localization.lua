local L = LibStub("AceLocale-3.0"):NewLocale("TitanWG","enUS",true)

if L then 
	L["TITAN_WG_NORTHREND"] = "Northrend";
	L["TITAN_WG_WINTERGRASP"] = "Wintergrasp";
	L["TITAN_WG_HORDE"] = "Horde";
	L["TITAN_WG_ALLIANCE"] = "Alliance";
	
	L["TITAN_WG_MENU_TEXT"] = "TitanWG";
	L["TITAN_WG_TOOLTIP_TITLE"] = "Wintergrasp Info";
	L["TITAN_WG_BUTTON_LABEL"] = "WG: ";
	L["TITAN_WG_HIDE"] = "Hide";
	
	L["TITAN_WG_WINTERGRASP_CURRENCY_INFO"] = "Wintergrasp Currency Info";
	L["TITAN_WG_VAULT_OF_ARCHAVON"] = "Vault of Archavon";
	L["TITAN_WG_VAULT_OF_ARCHAVON_INFO"] = "Vault of Archavon Info";
	L["TITAN_WG_NORMAL"] = "Normal";
	L["TITAN_WG_HEROIC"] = "Heroic";
	L["TITAN_WG_UNSAVED"] = "<unsaved>";
	L["TITAN_WG_SAVED"] = "<saved>";
	L["TITAN_WG_TIME_UNTIL_WG"] = "Time until Wintergrasp";
	L["TITAN_WG_SAY"] = "Say";
	L["TITAN_WG_YELL"] = "Yell";
	L["TITAN_WG_GUILD"] = "Guild";
	L["TITAN_WG_PARTY"] = "Party";
	L["TITAN_WG_RAID"] = "Raid";
	L["TITAN_WG_CHANNEL"] = "Channel";
	L["TITAN_WG_BROADCAST"] = "Broadcast";
	L["TITAN_WG_WHISPER"] = "Whisper";
	L["TITAN_WG_TRADE"] = "Trade";
	
	L["TITAN_WG_WHISPER_TEXT"] = "Send message to:";
	
	L["TITAN_WG_AUTO_ANNOUNCE_GUILD"] = "Post 15m warning to guild";
	L["TITAN_WG_AUTO_ANNOUNCE_TRADE"] = "Post 15m warning to trade";
	L["TITAN_WG_AUTO_ANNOUNCE_SELF"] = "Post 15m warning to self";
	
	L["TITAN_WG_ENABLED"] = "Enabled";
	L["TITAN_WG_ACCEPT"] = "Accept";
	L["TITAN_WG_CANCEL"] = "Cancel";
	L["TITAN_WG_NO_CURRENCIES"] = "<None>";
	
	L["TITAN_WG_CONTROLLER"] = "Controller";
	L["TITAN_WG_NEXT_BATTLE"] = "Next Battle";
	L["TITAN_WG_TIME_ELAPSED"] = "Time Elapsed";
	L["TITAN_WG_TIME_OF_LAST_SYNC"] = "Last Sync";
	L["TITAN_WG_PROBABLE_ERROR"] = "Probable Error";
	
	L["TITAN_WG_BATTLE_UNDERWAY"] = "The battle for Wintergrasp is underway";
	L["TITAN_WG_NO_ZONE_INFO"] = "[ Wintergrasp zone information is unavailable ]";
	
	L["TITAN_WG_DEFAULT_CHANNEL"] = "Default channel for broadcasts";
	L["TITAN_WG_NONE"] = "None"
	L["TITAN_WG_SHOW_SECONDS"] = "Show Seconds"
end
