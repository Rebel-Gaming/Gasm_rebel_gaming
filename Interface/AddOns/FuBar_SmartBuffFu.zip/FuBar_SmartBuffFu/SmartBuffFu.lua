-------------------------------------------------------------------------------
-- SmartBuffFu
-- Created by Aeldra (EU-Proudmoore)
--
-- FuBar support
-------------------------------------------------------------------------------

SMARTBUFF_FU_ICON_ON = "Interface\\AddOns\\SmartBuff\\Icons\\IconEnabled";
SMARTBUFF_FU_ICON_OFF = "Interface\\AddOns\\SmartBuff\\Icons\\IconDisabled";

SMARTBUFF_Fu = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0", "AceDB-2.0", "FuBarPlugin-2.0");
local Tablet = AceLibrary("Tablet-2.0");

SMARTBUFF_Fu.hasIcon = SMARTBUFF_FU_ICON_ON;
SMARTBUFF_Fu.defaultPosition  = "RIGHT";
SMARTBUFF_Fu.hasNoColor = true;
SMARTBUFF_Fu.hasNoText = true;
SMARTBUFF_Fu.cannotDetachTooltip = true;
SMARTBUFF_Fu.defaultMinimapPosition = 220;
SMARTBUFF_Fu.title = SMARTBUFF_TITLE;
SMARTBUFF_Fu.version = SMARTBUFF_VERSION;
SMARTBUFF_Fu.name = SMARTBUFF_TITLE;
SMARTBUFF_Fu.category = "Buffs";
SMARTBUFF_Fu.description = SMARTBUFF_DESC;
SMARTBUFF_Fu.independentProfile = true;

function SMARTBUFF_Fu:OnInitialize()
  SMARTBUFF_Fu:RegisterDB("FuBar_SmartBuffFuDB");
end

function SMARTBUFF_Fu:OnEnable()
	self:SetIcon(SMARTBUFF_FU_ICON_ON);
end

function SMARTBUFF_Fu:OnTooltipUpdate()
  if (Tablet) then
    Tablet:SetHint(SMARTBUFF_FUBAR_TT);
  end
end

function SMARTBUFF_Fu_SetIcon()
  if (SMARTBUFF_Options and SMARTBUFF_Options.Toggle) then
    SMARTBUFF_Fu:SetIcon(SMARTBUFF_FU_ICON_ON);
  else
    SMARTBUFF_Fu:SetIcon(SMARTBUFF_FU_ICON_OFF);
  end

  -- Update the SmartDebuffFu icon
  if (IsAddOnLoaded("FuBar_SmartDebuffFu")) then
    SMARTDEBUFF_Fu_UpdateIcon();
  end
end

function SMARTBUFF_Fu:OnClick(button)
  if (button == "LeftButton" and IsShiftKeyDown()) then
    SMARTBUFF_OToggle();
  elseif (button == "LeftButton" and IsAltKeyDown()) then
    if (IsAddOnLoaded("SmartDebuff")) then
      SMARTDEBUFF_ToggleSF();
    end      
  elseif (button == "LeftButton") then
    SMARTBUFF_OptionsFrame_Toggle();          
  end
end
