
-----------------------------------------------------------------------------------
-- Name : nUI_InfoPanel_Decursive                                          
-- Copyright : Tina Kirby AKA Xrystal (C) 2009/2010 All Rights Reserved      
-- Contact : xrystal@swangen.co.uk                                           
-- Download Sites :                                                          
-- http://www.wowinterface.com/downloads/info13508-nUIInfoPanelDecursive.html
-- http://wow.curse.com/downloads/wow-addons/details/nui_infopanel_decursive.aspx
-- Versions :
-- 1.01.00 - 18th May 2009 - New Addon (3.1)
-- 1.01.01 - 21st May 2009 - Sizing Fix (3.1)
-- 1.01.02 - 20th June 2009 - Alignment Fix (3.1)
-- 1.01.03 - 6th August 2009 - TOC Update (3.2)
-- 1.01.04 - 15th December 2009 - TOC Update (3.3)
-- 1.02.00 - 22nd June 2010 - Rewritten (3.3.5)
--------------------------------------------------------------------------------

--[[ Use Addon Wide Data Table ]]--
local addonName,addonData = ...

--[[ Localise Addon Wide Data Table Sub Tables ]]--
local Translate = addonData.Translate

--[[ Make sure we have nUI tables ]]--
if not nUI_InfoPanels then nUI_InfoPanels = {}; end

--[[ Set Up nUI InfoPanel Values ]]--
nUI_INFOMODE_DECURSIVE  = 16;
nUI_INFOPANEL_DECURSIVE = "nUI_InfoPanel_Decursive";

--[[ Set Up the Info Panel Table ]]--
nUI_InfoPanels[nUI_INFOPANEL_DECURSIVE ] =
{	
	enabled   = true,
	desc      = Translate["INFO_PANEL_TEXT"],		-- player friendly name/description of the panel
	label     = Translate["INFO_PANEL_LABEL"],		-- label to use on the panel selection button face
	rotation  = nUI_INFOMODE_DECURSIVE,				-- index or position this panel appears on/in when clicking the selector button
	full_size = true,								-- this plugin requires the entire info panel port without the button bag
	
	options  =
	{
		enabled  = true,
	},
};

--[[ Create the InfoPanel Plugin ]]--
local plugin    = CreateFrame( "Frame", nUI_INFOPANEL_DECURSIVE, nUI_Dashboard.Anchor );
plugin.active   = true;

--[[ Handle the addons Events ]]--
local function onEvent(self,event,...)

	if ( event == "ADDON_LOADED" ) then
		if ( arg1 ~= addonName ) then return end

		-- If the addons exist make sure they are loaded
		if not IsAddOnLoaded( "Decursive" ) then 
			LoadAddOn( "Decursive" );
		end
		plugin.active = IsAddOnLoaded("Decursive");
		self:UnregisterEvent(event);
		
	
	end	
end

--[[ Set Up the Event Script ]]--
plugin:SetScript( "OnEvent", onEvent );
plugin:RegisterEvent( "ADDON_LOADED" );

--[[ Disable the Decursive Frame ]]--
disableDecursive = function()
	local Decursive = plugin.Decursive;
	if Decursive.saved_parent then
		nUI_Movers:lockFrame( Decursive, false, nil );
		Decursive:SetParent( Decursive.saved_parent );
		Decursive:SetBackdropBorderColor( Decursive.border_color );
		Decursive:SetBackdropColor( Decursive.backdrop_color );
	end
end

--[[ Enable the Decursive Frame ]]--
enableDecursive = function()
	local Decursive = DcrMUFsContainer;
	plugin.Decursive = Decursive;
	if not Decursive.saved_parent then
		Decursive.saved_parent   = Decursive:GetParent();
		Decursive.border_color   = Decursive:GetBackdropBorderColor();
		Decursive.backdrop_color = Decursive:GetBackdropColor();
	end
	Decursive:SetParent( plugin.container );
	Decursive:SetPoint( "TOPLEFT", plugin.container, "TOPLEFT", 10, -10 );
	Decursive:SetPoint( "BOTTOMRIGHT", plugin.container, "BOTTOMRIGHT", 0, 0 );
	Decursive:SetFrameStrata( plugin.container:GetFrameStrata() );
	Decursive:SetFrameLevel( plugin.container:GetFrameLevel()+1 );
	Decursive:SetBackdropBorderColor( 0, 0, 0, 0 );
	Decursive:SetBackdropColor( 0, 0, 0, 0 );
	
	local DecursiveOptions = Dcr.profile;
	local DecursiveFrames = Dcr.MicroUnitF;
	DecursiveOptions.DebuffsFramePerline = 14;
	DecursiveOptions.DebuffsFrameMaxCount = 86;
	DecursiveOptions.DebuffsFrameXSpacing = 3;
	DecursiveOptions.DebuffsFrameYSpacing = 3;
	DecursiveOptions.DebuffsFrameElemScale = 1;
	DecursiveOptions.ShowDebuffsFrame = true;
	DecursiveFrames.MaxUnit = 86;			
	DecursiveFrames.Frame:SetScale(1);
	DecursiveFrames:ResetAllPositions();
	DecursiveFrames:Delayed_MFsDisplay_Update();
			
	nUI_Movers:lockFrame( Decursive, true, nil );
end

--[[ Resize the Decursive Frame ]]--
resizeDecursive = function(height,width)
	local Decursive   = plugin.Decursive;
	nUI_Movers:lockFrame( Decursive, false, nil );
	Decursive:SetWidth( width / 2 ); 
	Decursive:SetHeight( height ); 
	nUI_Movers:lockFrame( Decursive, true, nil );
end

--[[ The InfoPanel initialisation routine ]]--
plugin.initPanel = function( container, options )
	plugin.container = container;
	plugin.options   = options;
	if options and options.enabled then
		plugin.setEnabled( true );
	end
end

--[[ The InfoPanel resizing routine ]]--
plugin.sizeChanged = function( scale, height, width )
	local options  = plugin.options;
	plugin.scale = scale;
	resizeDecursive(height,width);
end	

--[[ The InfoPanel enabling routine ]]--
plugin.setEnabled = function( enabled )
	if plugin.enabled ~= enabled then
		plugin.enabled = enabled;
		if not enabled then
			disableDecursive();
		else
			enableDecursive();
		end				
	end			
end

--[[ The InfoPanel selection routine ]]--
plugin.setSelected = function( selected )
	if selected ~= plugin.selected then
		plugin.selected = selected;
		if selected then
		else
		end
	end
end
