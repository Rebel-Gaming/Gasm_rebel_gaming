
-----------------------------------------------------------------------------------
-- Name : Localization.enGB                                          
-- Copyright : Tina Kirby AKA Xrystal (C) 2009/2010 All Rights Reserved      
-- Contact : xrystal@swangen.co.uk                                           
-- Download Sites :                                                          
-- http://www.wowinterface.com
-- http://www.curse.com
-- Versions :
-- 1.01.00 - 18th May 2009 - New Addon (3.1)
-- 1.02.00 - 17th June 2010 - Rewritten (3.3)
--------------------------------------------------------------------------------

local addonName,addonData = ...

if (addonData.Locale == "enGB") then
	
	addonData.Translate["INFO_PANEL_TEXT"]		= "Info Panel: Decursive Mode";
	addonData.Translate["INFO_PANEL_LABEL"]		= "Decursive";
	
end
