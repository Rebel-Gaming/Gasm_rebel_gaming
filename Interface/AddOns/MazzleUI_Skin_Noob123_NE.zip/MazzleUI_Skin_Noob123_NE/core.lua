function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Skin_Noob123_NE\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Skin_Noob123_NE\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Skin_Noob123_NE\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Skin_Noob123_NE\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Skin_Noob123_NE\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Skin_Noob123_NE\\MazzleUICastingBarBorder",
            chatborder = "Interface\\AddOns\\MazzleUI_Skin_Noob123_NE\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Skin_Noob123_NE\\MazzleUIMinimapBorder",
        },
    }
end