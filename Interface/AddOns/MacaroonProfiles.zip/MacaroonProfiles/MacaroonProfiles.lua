﻿--MacaroonProfiles, a World of Warcraft® user interface addon.
--Copyright© 2009 Connor H. Chenoweth, aka Maul - All rights reserved.
--All rights reserved.

MacaroonProfiles = {}

local copyTable = Macaroon.copyTable
local clearTable = Macaroon.clearTable

local match = string.match

local numShown = 5

function Macaroon.ProfilesScrollFrame_OnLoad(self)

	self.offset = 0
	self.scrollbar = _G[self:GetName().."ScrollBar"]
	self.scrollChild = _G[self:GetName().."ScrollChildFrame"]

	self:SetBackdropBorderColor(0.5, 0.5, 0.5)
	self:SetBackdropColor(0,0,0,0.5)

	local button, lastButton, rowButton, count, fontString, script = false, false, false, 0

	for i=1,numShown do

		button = CreateFrame("CheckButton", self:GetName().."Button"..i, self, "MacaroonButtonTemplate2")

		button.frame = self
		button.numShown = numShown

		button:SetScript("OnClick",
			function(self)

				if (IsShiftKeyDown() and MacaroonProfileManagerSpecs.currFocus) then
					MacaroonProfileManagerSpecs.currFocus:SetText(match(self.index:GetText(), "^[^:]+"))
				end

				local button, buttonIndex, buttonBody
				for i=1,numShown do

					button = _G["MacaroonProfileManagerProfilesScrollFrameButton"..i]

					if (i == self:GetID()) then
						if (self.index:GetText() and strlen(self.index:GetText()) > 1) then
							MacaroonProfileManagerOptionsNameEdit:SetText(match(self.index:GetText(), "^[^:]+"))
							MacaroonProfileManagerOptionsNameEdit.text:SetText("")
						else
							MacaroonProfileManagerOptionsNameEdit:SetText("")
							MacaroonProfileManagerOptionsNameEdit.text:SetText(MACAROONPROFILES_STRINGS.NAME_EDIT)
						end

						if (self.note:GetText() and strlen(self.note:GetText()) > 1) then
							MacaroonProfileManagerOptionsNoteEdit:SetText(self.note:GetText())
							MacaroonProfileManagerOptionsNoteEdit.text:SetText("")
						else
							MacaroonProfileManagerOptionsNoteEdit:SetText("")
							MacaroonProfileManagerOptionsNoteEdit.text:SetText(MACAROONPROFILES_STRINGS.NOTE_EDIT)
						end

						MacaroonProfileManagerOptionsLayout:SetChecked(self.layout)
						MacaroonProfileManagerOptionsButtons:SetChecked(self.buttons)
						MacaroonProfileManagerOptionsButtonData:SetChecked(self.buttondata)
						MacaroonProfileManagerOptionsSettings:SetChecked(self.settings)

					else
						button:SetChecked(nil)
					end
				end

			end)

		button:SetScript("OnShow",
			function(self)
				self:SetHeight(self.frame:GetHeight()/self.numShown)
			end)

		fontString = button:CreateFontString(button:GetName().."Index", "ARTWORK", "GameFontNormalLarge");
		fontString:SetPoint("BOTTOMLEFT", button, "LEFT", 5, 0)
		fontString:SetPoint("TOPLEFT", button, "TOPLEFT", 5, -3)
		fontString:SetJustifyV("TOP")
		fontString:SetJustifyH("LEFT")
		button.index = fontString

		fontString = button:CreateFontString(button:GetName().."Note", "ARTWORK", "GameFontNormalSmall");
		fontString:SetPoint("TOPLEFT", button.index, "TOPRIGHT", 15, 3)
		fontString:SetPoint("BOTTOMRIGHT", button, "RIGHT", 0, 0)
		fontString:SetJustifyV("CENTER")
		fontString:SetJustifyH("LEFT")
		fontString:SetTextColor(0.7,0.7,0.7)
		button.note = fontString

		fontString = button:CreateFontString(button:GetName().."Data", "ARTWORK", "GameFontNormalSmall");
		fontString:SetPoint("TOPLEFT", button, "LEFT", 7, 0)
		fontString:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT")
		fontString:SetJustifyV("TOP")
		fontString:SetJustifyH("LEFT")
		fontString:SetTextColor(1,1,1)
		button.data = fontString

		button:SetID(i)
		button:SetFrameLevel(self:GetFrameLevel()+2)
		button:SetNormalTexture("")

		if (not lastButton) then
			button:SetPoint("TOPLEFT",1,5)
			button:SetPoint("TOPRIGHT",-20,5)
			lastButton = button
		else
			button:SetPoint("TOPLEFT", lastButton, "BOTTOMLEFT", 0, 0)
			button:SetPoint("TOPRIGHT", lastButton, "BOTTOMRIGHT", 0, 0)
			lastButton = button
		end
	end

	Macaroon.ProfilesScrollFrameUpdate()
end

function Macaroon.ProfilesScrollFrameUpdate()

	local frame = MacaroonProfileManagerProfilesScrollFrame
	local dataOffset, count, data, button, text, datum = FauxScrollFrame_GetOffset(frame), 1, {}

	for k,v in pairs(MacaroonProfiles) do
		data[count] = k; count = count + 1
	end

	table.sort(data)

	frame:Show()

	for i=1,numShown do

		button = _G["MacaroonProfileManagerProfilesScrollFrameButton"..i]
		button:SetChecked(nil)
		button.tooltip = nil
		button.layout = nil
		button.buttons = nil
		button.buttondata = nil
		button.settings = nil

		button:SetHeight(frame:GetHeight()/numShown)

		count = dataOffset + i

		if (data[count]) then

			text = data[count]

			if (MacaroonProfiles[data[count]].layout or MacaroonProfiles[data[count]].buttons or MacaroonProfiles[data[count]].buttondata or MacaroonProfiles[data[count]].settings) then

				datum = ""

				if (MacaroonProfiles[data[count]].layout) then
					datum = datum.."*"..MACAROONPROFILES_STRINGS.LAYOUT.."  "
					button.layout = 1
				end

				if (MacaroonProfiles[data[count]].buttons) then
					datum = datum.."*"..MACAROONPROFILES_STRINGS.BUTTONS.."  "
					button.buttons = 1
				end

				if (MacaroonProfiles[data[count]].buttondata) then
					datum = datum.."*"..MACAROONPROFILES_STRINGS.BUTTONDATA.."  "
					button.buttondata = 1
				end

				if (MacaroonProfiles[data[count]].settings) then
					datum = datum.."*"..MACAROONPROFILES_STRINGS.SETTINGS.."  "
					button.settings = 1
				end
			end

			button.index:SetText(text)
			button.note:SetText(MacaroonProfiles[data[count]].note or "")
			button.data:SetText(datum or "")
			button:Enable()
			button:Show()
		else

			if (i==1) then
				button.index:SetText(MACAROONPROFILES_STRINGS.NOPROFILES)
				button.note:SetText("")
				button.data:SetText("")
				button:Disable()
			else
				button:Hide()
			end
		end
	end

	count = numShown + 1

	if (#data > count) then
		count = #data
	end

	FauxScrollFrame_Update(frame, count, numShown, 2)
end

function Macaroon.SaveProfile(name, update)

	PlaySound("gsTitleOptionOK")

	local origData, data, layout, buttons, settings, updateData
	local saveLayout, saveButtons, saveSettings

	if (strlen(name) < 1) then
		MacaroonMessageFrame:AddMessage(MACAROONPROFILES_STRINGS.INVALID_NAME, 1.0, 1.0, 1.0, 1.0, UIERRORS_HOLD_TIME)
		return
	end

	if (update) then

		if (not MacaroonProfiles[name]) then
			MacaroonMessageFrame:AddMessage(MACAROONPROFILES_STRINGS.INVALID_NAME, 1.0, 1.0, 1.0, 1.0, UIERRORS_HOLD_TIME)
			return
		end

		updateData = copyTable(MacaroonProfiles[name])
	else
		saveLayout = MacaroonProfileManagerOptionsLayout:GetChecked()
		saveButtons = MacaroonProfileManagerOptionsButtons:GetChecked()
		saveButtonData = MacaroonProfileManagerOptionsButtonData:GetChecked()
		saveSettings = MacaroonProfileManagerOptionsSettings:GetChecked()
	end

	if (not saveLayout and not saveButtons and not saveButtonData and not saveSettings) then
		MacaroonMessageFrame:AddMessage(MACAROONPROFILES_STRINGS.NOTHINGTOSAVE, 1.0, 1.0, 1.0, 1.0, UIERRORS_HOLD_TIME)
		return
	end

	if (MacaroonProfiles[name]) then
		clearTable(MacaroonProfiles[name])
	else
		MacaroonProfiles[name] = {}
	end

	for k,v in pairs(Macaroon.StatesToSave) do

		origData, layout, buttons = v()

		data = copyTable(origData)

		local bars, btns = {}, {}

		if (layout) then
			for i=1,select('#',(";"):split(layout)) do
				local barsplit = select(i,(";"):split(layout))
				bars[barsplit] = true
			end
		end

		if (buttons) then
			for i=1,select('#',(";"):split(buttons)) do
				local btnsplit = select(i,(";"):split(buttons))
				btns[btnsplit] = true
			end
		end

		if (not saveLayout and layout) then

			for k,v in pairs(bars) do
				data[k] = nil
			end
		end

		if (not saveButtons and not saveButtonData and buttons) then

			for k,v in pairs(btns) do
				data[k] = nil
			end

			for k,v in pairs(bars) do
				if (data[k]) then
					for kk,vv in pairs(data[k]) do
						for key,value in pairs(data[k][kk][1].buttonList) do
							data[k][kk][1].buttonList[key] = ""
						end
					end
				end
			end
		end

		if (not saveButtonData and buttons) then

			for k,v in pairs(btns) do
				if (data[k]) then
					for kk,vv in pairs(data[k]) do
						clearTable(data[k][kk][1])
						clearTable(data[k][kk][2])
					end
				end
			end
		end

		local protected = {}

		for k,v in pairs(bars) do
			if (data[k]) then protected[k] = true end
		end

		for k,v in pairs(btns) do
			if (data[k]) then protected[k] = true end
		end

		if (not saveSettings) then
			for k,v in pairs(data) do
				if (not protected[k]) then
					data[k] = nil
				end
			end
		end

		MacaroonProfiles[name][k] = copyTable(data)
	end

	if (update) then

		MacaroonProfiles[name].note = updateData.note
		MacaroonProfiles[name].layout = updateData.layout
		MacaroonProfiles[name].buttons = updateData.buttons
		MacaroonProfiles[name].buttondata = updateData.buttondata
		MacaroonProfiles[name].settings = updateData.settings

	else

		MacaroonProfiles[name].note = MacaroonProfileManagerOptionsNoteEdit:GetText() or ""
		MacaroonProfiles[name].layout = saveLayout
		MacaroonProfiles[name].buttons = saveButtons
		MacaroonProfiles[name].buttondata = saveButtonData
		MacaroonProfiles[name].settings = saveSettings

		MacaroonProfileManagerOptionsNameEdit:ClearFocus()
		MacaroonProfileManagerOptionsNoteEdit:ClearFocus()

		Macaroon.ProfilesScrollFrameUpdate()
	end
end

function Macaroon.LoadProfile(name)

	PlaySound("gsTitleOptionOK")

	local data

	if (not MacaroonProfiles[name]) then
		MacaroonMessageFrame:AddMessage(MACAROONPROFILES_STRINGS.INVALID_NAME, 1.0, 1.0, 1.0, 1.0, UIERRORS_HOLD_TIME)
		return
	end

	Macaroon.Ypos = 90

	if (MacaroonProfiles[name].layout) then
		for k,v in pairs(Macaroon.BarIndex) do
			Macaroon.DeleteBar(v)
		end
	end

	if (MacaroonProfiles[name].buttons or MacaroonProfiles[name].buttondata) then
		for k,v in pairs(Macaroon.Buttons) do
			Macaroon.ClearBindings(v[1])
		end
	end

	for k,v in pairs(Macaroon.SavedDataLoad) do

		data = copyTable(MacaroonProfiles[name][k])
		v(data, true)
	end

	for k,v in pairs(Macaroon.SavedDataUpdate) do
		v()
	end

	if (MacaroonProfiles[name].settings) then
		for k,v in pairs(Macaroon.CheckbuttonOptions) do
			v(_G["MacaroonMainMenuCheck"..k])
		end
	end

	MacaroonProfileManagerOptionsNameEdit:ClearFocus()
	MacaroonProfileManagerOptionsNoteEdit:ClearFocus()

	Macaroon.ProfilesScrollFrameUpdate()

	Macaroon.Control_OnEvent(nil, "PLAYER_LOGIN")

	Macaroon.Init()

	Macaroon.UpdateButtonStorage()
end

function Macaroon.DeleteProfile(name)

	PlaySound("gsTitleOptionOK")

	if (strlen(name) < 1 or not MacaroonProfiles[name]) then
		MacaroonMessageFrame:AddMessage(MACAROONPROFILES_STRINGS.INVALID_NAME, 1.0, 1.0, 1.0, 1.0, UIERRORS_HOLD_TIME)
		return
	end

	MacaroonProfileManagerOptionsNameEdit:SetText("")
	MacaroonProfileManagerOptionsNameEdit:ClearFocus()
	MacaroonProfileManagerOptionsNameEdit.text:SetText(MACAROONPROFILES_STRINGS.NAME_EDIT)

	MacaroonProfileManagerOptionsNoteEdit:SetText("")
	MacaroonProfileManagerOptionsNoteEdit:ClearFocus()
	MacaroonProfileManagerOptionsNoteEdit.text:SetText(MACAROONPROFILES_STRINGS.NOTE_EDIT)

	MacaroonProfileManagerOptionsLayout:SetChecked(nil)
	MacaroonProfileManagerOptionsButtons:SetChecked(nil)
	MacaroonProfileManagerOptionsButtonData:SetChecked(nil)
	MacaroonProfileManagerOptionsSettings:SetChecked(nil)

	MacaroonProfiles[name] = nil

	Macaroon.ProfilesScrollFrameUpdate()

end

local function controlOnEvent(self, event, ...)

	if (event == "ADDON_LOADED" and ... == "MacaroonProfiles") then

	end
end

local frame = CreateFrame("Frame", nil, UIParent)
frame:SetScript("OnEvent", controlOnEvent)
frame:RegisterEvent("ADDON_LOADED")