-- Korean localizations by DroArc


local function load_localization()

MACAROONPROFILES_STRINGS= {

	INVALID_NAME = "Invalid profile name",

	NAME_EDIT = "Click here to edit Name",
	NOTE_EDIT = "Click here to edit notes",

	SAVE = "Save",
	LOAD = "Load",
	DELETE = "Delete",

	LAYOUT = "Bar Layout",
	BUTTONS = "Button Layout",
	BUTTONDATA = "Button Data",
	SETTINGS = "Settings",

	NOTHINGTOSAVE = "Nothing selected to save",

	NOPROFILES = "No Saved Profiles",

	USEPROFILES = "Enable profile switching upon spec change",

	SPEC1_EDIT = "Primary Talent Spec Profile",
	SPEC2_EDIT = "Secondary Talent Spec Profile",

}

end

if ( GetLocale() == "koKR" ) then
  load_localization()
end