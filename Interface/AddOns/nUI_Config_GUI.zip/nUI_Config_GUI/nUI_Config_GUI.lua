nUIConfigGUI = LibStub('AceAddon-3.0'):NewAddon('nUIConfigGUI', 'AceEvent-3.0', 'AceConsole-3.0')
local L = LibStub('AceLocale-3.0'):GetLocale('nUIConfigGUI')
local CURRENT_VERSION = GetAddOnMetadata('nUI_Config_GUI', 'Version')
local NUI_LATEST_VERSION = false
local NUI_CHECK_VERSION = '5.06.04'
local NUI6_ALPHA = false
local NUI6_ALPHA_VERSION = GetAddOnMetadata('nUI6', 'Version')
local NUI6_ALPHA_CHECK = '6.03.03.05'

local ADDON_TITLE = GetAddOnMetadata('nUI_Config_GUI', 'Title')
local ADDON_AUTHOR = GetAddOnMetadata('nUI_Config_GUI', 'Author')

local nUI_SlashCmdHandler = SlashCmdList["NUI"]
local _profiling = false

local LSM = LibStub("LibSharedMedia-3.0")

local function getCommandOptions()

	local command_options = {
	    type = "group",
	    args =
		{
			__header1 = {
				type = "header",
				name = "",
				order = 5,
			},
			
			__title = {
				type = "description",
				name = ADDON_TITLE,
				order = 6,
			},
			
			__version =
			{
				type = "description",
				name = L["Version"] .. " " .. CURRENT_VERSION .. "\n",
				order = 7,
			},
			
			__author = {
				type = "description",
				name = L["Author"] .. " " .. ADDON_AUTHOR,
				order = 8,
			},
			
			__header2 =  {
				type = "header",
				name = "",
				order = 9,
			},
						
			__nuilatest = {
				type = "description",
				-- name = "Minimum nUI version requirement met.  You have at least nUI version " .. NUI_CHECK_VERSION .. " installed.",
				-- nUI_L["splash title"]:format(
				name = L["MSG_NUI_LATEST"]:format(NUI_CHECK_VERSION),
				order = 10,
				hidden = not NUI_LATEST_VERSION,
			},
			
			__nuiupgrade = {
				type = "description",
				-- name = "Please upgrade your version of nUI.  You need to have at least nUI version " .. NUI_CHECK_VERSION .. " installed.",
				name = L["MSG_NUI_UPGRADE"]:format(NUI_CHECK_VERSION),
				order = 10,
				hidden = NUI_LATEST_VERSION,
			},

			__header3 =  {
				type = "header",
				name = "",
				order = 11,
				hidden = not NUI6_ALPHA,
			},
			
			__nui6 = {
				type = "description",
				name = "Brave soul! Thank you for testing nUI6.",
				order = 12,
				hidden = not NUI6_ALPHA,
			}
		}
	}

	return command_options

end

local function getConfigHUD()
	local hud = {
		type = "group",
		name = L["LBL_GRP_HUD_NAME"],
		desc = L["LBL_GRP_HUD_DESC"],
		args = {
			__healthrace = {
				type = "toggle",
				-- name = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_HEALTHRACE].name,
				-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_HEALTHRACE].desc,
				name = L["LBL_ARG_HUD_HEALTHRACE_NAME"],
				desc = L["LBL_ARG_HUD_HEALTHRACE_DESC"],
				get = function() return nUI_Options.hud_healthrace end,
				set = function(t,b)
					local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
					local option = master.sub_menu[nUI_SLASHCMD_HUD_HEALTHRACE];
					local command = master.command .. " " .. option.command
					--[[
					if (b) then 
						command = command .. " on"
					else 
						command = command .. " off"
					end
					--]]
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 1,
			},
			
			__noncombatnpc = {
				type = "toggle",
				-- name = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_SHOWNPC].name,
				-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_SHOWNPC].desc,
				name = L["LBL_ARG_HUD_SHOWNPC_NAME"],
				desc = L["LBL_ARG_HUD_SHOWNPC_DESC"],
				
				get = function() return nUI_Options.show_npc end,
				set = function(t,b) 
					local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
					local option = master.sub_menu[nUI_SLASHCMD_HUD_SHOWNPC];
					local command = master.command .. " " .. option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 2,
			},
			
			__focus = {
				type = "toggle",
				-- name = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_FOCUS].name,
				-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_FOCUS].desc,
				name = L["LBL_ARG_HUD_FOCUS_NAME"],
				desc = L["LBL_ARG_HUD_FOCUS_DESC"],
				get = function() return nUI_Options.hud_focus end,
				set = function(t,b)
					local master = nUI_SlashCommands[nUI_SLASHCMD_HUD]
					local option = master.sub_menu[nUI_SLASHCMD_HUD_FOCUS]
					local command = master.command .. " " .. option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 3,
			},
			
			__display = {
				type = "group",
				name = L["LBL_GRP_HUD_DISPLAY_NAME"],
				desc = L["LBL_GRP_HUD_DISPLAY_DESC"],
				args = {
					__scale = {
						type = "range",
						-- name = "Scale",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_SCALE].desc,
						name = L["LBL_ARG_HUD_SCALE_NAME"],
						desc = L["LBL_ARG_HUD_SCALE_DESC"],
						min = 0.25,
						max = 1.75,
						step = 0.05,
						get = function() return nUI_Options.hud_scale end,
						set = function(t, n) 
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
							local option = master.sub_menu[nUI_SLASHCMD_HUD_SCALE];
							local command = master.command .. " " .. option.command .. " " .. tostring(n)
							nUI_SlashCmdHandler(command)
						end,
						order = 1,
					},
					
					__hgap = {
						type = "range",
						-- name = "Horizontal gap",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_HGAP].desc,
						name = L["LBL_ARG_HUD_HGAP_NAME"],
						desc = L["LBL_ARG_HUD_HGAP_DESC"],
						min = 1,
						max = 1200,
						step = 1,
						get = function() 
							return nUI_Options.hud_hGap 
						end,
						set = function(t, n)
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
							local option = master.sub_menu[nUI_SLASHCMD_HUD_HGAP];
							local command = master.command .. " " .. option.command .. " " .. tostring(n)
							nUI_SlashCmdHandler(command)							
						end,
						order = 2
					},
					
					__vofs = {
						type = "range",
						-- name = "Vertical offset",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_VOFS].desc,
						name = L["LBL_ARG_HUD_VOFS_NAME"],
						desc = L["LBL_ARG_HUD_VOFS_DESC"],
						min = 0,
						max = 100,
						step = 1,
						get = function()
							return nUI_Options.hud_vOfs
						end,
						set = function(t, n)
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD]
							local option = master.sub_menu[nUI_SLASHCMD_HUD_VOFS]
							local command = master.command .. " " .. option.command .. " " .. tostring(n)
							nUI_SlashCmdHandler(command)
						end,
						order = 3,
					},
				},
				order = 4,
			},
			
			__alpha = {
				type = "group",
				-- name = "Transparency",
				-- desc = "HUD transparency",
				name = L["LBL_GRP_HUD_ALPHA_NAME"],
				desc = L["LBL_GRP_HUD_ALPHA_DESC"],
				args = {
					__idle = {
						type = "range",
						-- name = "Idle",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_IDLEALPHA].desc,
						name = L["LBL_ARG_HUD_IDLEALPHA_NAME"],
						desc = L["LBL_ARG_HUD_IDLEALPHA_DESC"],
						min = 0,
						max = 1,
						step = 0.1,
						get = function() return nUI_Options.hud_alpha.idle end,
						set = function(t, n) 
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
							local option = master.sub_menu[nUI_SLASHCMD_HUD_IDLEALPHA];
							local command = master.command .. " " .. option.command .. " " .. tostring(n)
							nUI_SlashCmdHandler(command)
						end,
						order = 1,
					},
					
					__target = {
						type = "range",
						-- name = "Target",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_TARGETALPHA].desc,
						name = L["LBL_ARG_HUD_TARGETALPHA_NAME"],
						desc = L["LBL_ARG_HUD_TARGETALPHA_DESC"],
						min = 0,
						max = 1,
						step = 0.1,
						get = function() return nUI_Options.hud_alpha.target end,
						set = function(t, n) 
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
							local option = master.sub_menu[nUI_SLASHCMD_HUD_TARGETALPHA];
							local command = master.command .. " " .. option.command .. " " .. tostring(n)
							nUI_SlashCmdHandler(command)
						end,
						order = 2,
					},
					
					__regen = {
						type = "range",
						-- name = "Regen",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_REGENALPHA].desc,
						name = L["LBL_ARG_HUD_REGENALPHA_NAME"],
						desc = L["LBL_ARG_HUD_REGENALPHA_DESC"],
						min = 0,
						max = 1,
						step = 0.1,
						get = function() return nUI_Options.hud_alpha.regen end,
						set = function(t, n)
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
							local option = master.sub_menu[nUI_SLASHCMD_HUD_REGENALPHA];
							local command = master.command .. " " .. option.command .. " " .. tostring(n)
							nUI_SlashCmdHandler(command)
						end,
						order = 3,
					},
					
					__combat = {
						type = "range",
						-- name = "Combat",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_COMBATALPHA].desc,
						name = L["LBL_ARG_HUD_COMBATALPHA_NAME"],
						desc = L["LBL_ARG_HUD_COMBATALPHA_DESC"],
						min = 0,
						max = 1,
						step = 0.1,
						get = function() return nUI_Options.hud_alpha.combat end,
						set = function(t, n)
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
							local option = master.sub_menu[nUI_SLASHCMD_HUD_COMBATALPHA];
							local command = master.command .. " " .. option.command .. " " .. tostring(n)
							nUI_SlashCmdHandler(command)
						end,
						order = 3,
					},					
				
				},
				order = 5,
			},
			
			__cooldown = {
				type = "group",
				-- name = "Cooldown",
				-- desc = "Cooldown options",
				name = L["LBL_GRP_HUD_COOLDOWN_NAME"],
				desc = L["LBL_GRP_HUD_COOLDOWN_DESC"],
				args = {
					__bar = {
						type = "toggle",
						-- name = "Bar",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_COOLDOWN].desc,
						name = L["LBL_ARG_HUD_COOLDOWN_NAME"],
						desc = L["LBL_ARG_HUD_COOLDOWN_DESC"],
						get = function() return nUI_Options.hud_cooldown end,
						set = function(t,b) 
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
							local option = master.sub_menu[nUI_SLASHCMD_HUD_COOLDOWN];
							local command = master.command .. " " .. option.command
							nUI_SlashCmdHandler(command)
						end,
						width = "full",
						order = 1,
					},
					
					__minimum = {
						type = "range",
						-- name = "Minimum",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDMIN].desc,
						name = L["LBL_ARG_HUD_CDMIN_NAME"],
						desc = L["LBL_ARG_HUD_CDMIN_DESC"],
						min = 0,
						max = 60,
						step = 1,
						get = function() return nUI_Options.minCooldown end,
						set = function(t,n)
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD]
							local option = master.sub_menu[nUI_SLASHCMD_HUD_CDMIN]
							local command = master.command .. " " .. option.command .. " " .. tostring(n)
							nUI_SlashCmdHandler(command)
						end,
						width = "full",
						order = 2,
					},
					
					__alert = {
						type = "toggle",
						-- name = "Alert",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDALERT].desc,
						name = L["LBL_ARG_HUD_CDALERT_NAME"],
						desc = L["LBL_ARG_HUD_CDALERT_DESC"],
						get = function() return nUI_Options.hud_cdalert end,
						set = function(t,b) 
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
							local option = master.sub_menu[nUI_SLASHCMD_HUD_CDALERT];
							local command = master.command .. " " .. option.command
							nUI_SlashCmdHandler(command)
						end,
						width = "full",
						order = 3,
					},
					
					__sound = {
						type = "toggle",
						-- name = "Sound",
						-- desc = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDSOUND].desc,
						name = L["LBL_ARG_HUD_CDSOUND_NAME"],
						desc = L["LBL_ARG_HUD_CDSOUND_DESC"],
						get = function() return nUI_Options.hud_cdsound end,
						set = function(t,b) 
							local master = nUI_SlashCommands[nUI_SLASHCMD_HUD];
							local option = master.sub_menu[nUI_SLASHCMD_HUD_CDSOUND];
							local command = master.command .. " " .. option.command
							nUI_SlashCmdHandler(command)
						end,
						width = "full",
						order = 4,
					},
					
				},
				order = 6,
			},
			
		},
	}
	
	return hud
end

local function getConfigActionbars()
	local actionbars = {
		type = "group",
		name = "Actionbar options",
		desc = nUI_SlashCommands[nUI_SLASHCMD_BAR].desc,
		args = {
			__cooldown = {
				type = "toggle",
				name = "Cooldown",
				desc = nUI_SlashCommands[nUI_SLASHCMD_BAR].sub_menu[nUI_SLASHCMD_BAR_COOLDOWN].desc,
				get = function() return nUI_Options.barCooldowns end,
				set = function(t,b) 
					local master = nUI_SlashCommands[nUI_SLASHCMD_BAR];
					local option = master.sub_menu[nUI_SLASHCMD_BAR_COOLDOWN];
					local command = master.command .. " " .. option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 1,				
			},
			
			__duration = {
				type = "toggle",
				name = "Duration",
				desc = nUI_SlashCommands[nUI_SLASHCMD_BAR].sub_menu[nUI_SLASHCMD_BAR_DURATION].desc,
				get = function() return nUI_Options.barDurations end,
				set = function(t,b) 
					local master = nUI_SlashCommands[nUI_SLASHCMD_BAR];
					local option = master.sub_menu[nUI_SLASHCMD_BAR_DURATION];
					local command = master.command .. " " .. option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 2,				
			},
			
			__macro = {
				type = "toggle",
				name = "Macro names",
				desc = nUI_SlashCommands[nUI_SLASHCMD_BAR].sub_menu[nUI_SLASHCMD_BAR_MACRO].desc,
				get = function() return nUI_Options.barMacroNames end,
				set = function(t,b) 
					local master = nUI_SlashCommands[nUI_SLASHCMD_BAR];
					local option = master.sub_menu[nUI_SLASHCMD_BAR_MACRO];
					local command = master.command .. " " .. option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 3,				
			},
			
			__stackcount = {
				type = "toggle",
				name = "Stack counts",
				desc = nUI_SlashCommands[nUI_SLASHCMD_BAR].sub_menu[nUI_SLASHCMD_BAR_STACKCOUNT].desc,
				get = function() return nUI_Options.barStackCounts end,
				set = function(t,b) 
					local master = nUI_SlashCommands[nUI_SLASHCMD_BAR];
					local option = master.sub_menu[nUI_SLASHCMD_BAR_STACKCOUNT];
					local command = master.command .. " " .. option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 4,				
			},
			
			__keybind = {
				type = "toggle",
				name = "Keybind",
				desc = nUI_SlashCommands[nUI_SLASHCMD_BAR].sub_menu[nUI_SLASHCMD_BAR_KEYBIND].desc,
				get = function() return nUI_Options.barKeyBindings end,
				set = function(t,b) 
					local master = nUI_SlashCommands[nUI_SLASHCMD_BAR];
					local option = master.sub_menu[nUI_SLASHCMD_BAR_KEYBIND];
					local command = master.command .. " " .. option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 5,				
			},
			
			__mouseover = {
				type = "toggle",
				name = "Mouseover",
				desc = nUI_SlashCommands[nUI_SLASHCMD_BAR].sub_menu[nUI_SLASHCMD_BAR_MOUSEOVER].desc,
				get = function() return nUI_Options.barMouseover end,
				set = function(t,b)
					local master = nUI_SlashCommands[nUI_SLASHCMD_BAR]
					local option = master.sub_menu[nUI_SLASHCMD_BAR_MOUSEOVER]
					local command = master.command .. " " .. option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 6,
			},
			
			__totem = {
				type = "toggle",
				name = "Hide Totem Bar",
				desc = nUI_SlashCommands[nUI_SLASHCMD_BAR].sub_menu[nUI_SLASHCMD_BAR_TOTEMS].desc,
				get = function() return nUI_Options.noTotemBar end,
				set = function(t,b)
					local master = nUI_SlashCommands[nUI_SLASHCMD_BAR]
					local option = master.sub_menu[nUI_SLASHCMD_BAR_TOTEMS]
					local command = master.command .. " " .. option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 7,
			},
			
			__dimming = {
				type = "toggle",
				name = "Dimming",
				desc = nUI_SlashCommands[nUI_SLASHCMD_BAR].sub_menu[nUI_SLASHCMD_BAR_DIMMING].desc,
				get = function() return nUI_Options.barDimming end,
				set = function(t,b)
					local master = nUI_SlashCommands[nUI_SLASHCMD_BAR]
					local option = master.sub_menu[nUI_SLASHCMD_BAR_DIMMING]
					local command = master.command .. " " .. option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 8,
			},
			
			__dimalpha = {
				type = "range",
				name = "Dim alpha",
				desc = nUI_SlashCommands[nUI_SLASHCMD_BAR].sub_menu[nUI_SLASHCMD_BAR_DIMALPHA].desc,
				min = 0.0,
				max = 1.0,
				step = 0.05,
				get = function () return nUI_Options.dimmingAlpha end,
				set = function(t,n)
					local master = nUI_SlashCommands[nUI_SLASHCMD_BAR]
					local option = master.sub_menu[nUI_SLASHCMD_BAR_DIMALPHA]
					local command = master.command .. " " .. option.command .. " " .. tostring(n)
					nUI_SlashCmdHandler(command)
				end,
				order = 9,
				disabled = not nUI_Options.barDimming,
			},
		},
		
	}
	
	return actionbars
end

local function getConfigTooltips()
	local tooltips = {
		type = "group",
		name = "Tooltip options",
		desc = nUI_SlashCommands[nUI_SLASHCMD_TOOLTIPS].desc,
		args = {
			__combat = {
				type = "toggle",
				name = "Combat",
				desc = nUI_SlashCommands[nUI_SLASHCMD_COMBATTIPS].desc,
				get = function() return nUI_Options.combat_tooltips end,
				set = function(t,b) 
					local option = nUI_SlashCommands[nUI_SLASHCMD_COMBATTIPS];
					local command = option.command
					nUI_SlashCmdHandler(command)
				end,
				width = "full",
				order = 1,
			},

			__anchor = {
				type = "select",
				name = "Anchor",
				desc = nUI_SlashCommands[nUI_SLASHCMD_TOOLTIPS].desc .. ". NOTE: 'default' will force a reload of your UI.",
				values = {
					["owner"] = "Owner",
					["mouse"] = "Mouse",
					["fixed"] = "Fixed",
					["default"] = "Default"
				},
				style = "dropdown",
				get = function() return nUI_Options.tooltips end,
				set = function(t, s) 
					local option = nUI_SlashCommands[nUI_SLASHCMD_TOOLTIPS]
					local command = option.command .. " " .. s
					nUI_SlashCmdHandler(command)
				end,
				order = 2,
			},
		
		},
	}
	
	return tooltips
end

local function getConfigUnitframes()
	local unitframes = {
		type = "group",
		name = "Unit Frames",
		desc = "Unit Frames",
		args = {
		
			__animatedportraits = {
				type = "toggle",
				name = "Animated portraits",
				desc = nUI_SlashCommands[nUI_SLASHCMD_SHOWANIM].desc,
				get = function() return nUI_Options.show_anim end,
				set = function(t,b) 
					local option = nUI_SlashCommands[nUI_SLASHCMD_SHOWANIM]
					local command = option.command
					nUI_SlashCmdHandler(command)
				end,
				order = 1,
			},
			
			__hplost = {
				type = "toggle",
				name = "HP Lost",
				desc = nUI_SlashCommands[nUI_SLASHCMD_HPLOST].desc,
				get = function() return nUI_Options.hplost end,
				set = function(t,b) 
					local option = nUI_SlashCommands[nUI_SLASHCMD_HPLOST]
					local command = option.command
					nUI_SlashCmdHandler(command)
				end,
				order = 2,
			},

			__autogroup = {
				type = "toggle",
				name = "Auto group",
				desc = nUI_SlashCommands[nUI_SLASHCMD_AUTOGROUP].desc,
				get = function() return nUI_Options.auto_group end,
				set = function(t,b)
					local option = nUI_SlashCommands[nUI_SLASHCMD_AUTOGROUP]
					local command = option.command
					nUI_SlashCmdHandler(command)
				end,
				order = 2,
			},
	
			__showhits = {
				type = "toggle",
				name = "Show Hits",
				desc = nUI_SlashCommands[nUI_SLASHCMD_SHOWHITS].desc,
				get = function() return nUI_Options.show_hits end,
				set = function(t,b)
					local option = nUI_SlashCommands[nUI_SLASHCMD_SHOWHITS]
					local command = option.command
					nUI_SlashCmdHandler(command)
				end,
				order = 3,
			},
			
			__feedback = {
				type = "group",
				name = "Feedback",
				desc = "Feedback",
				args = {
					__fbcurse = {
						type = "toggle",
						name = "Curse",
						desc = "Toggle the feedback highlight for character who has a Curse",
						get = function() return nUI_Options.feedback_curse end,
						set = function(t,b)
							local option = nUI_SlashCommands[nUI_SLASHCMD_FEEDBACK]
							local command = option.command .. " " .. "curse"
							nUI_SlashCmdHandler(command)
						end,
						order = 1,
					},

					__fbpoison = {
						type = "toggle",
						name = "Poison",
						desc = "Toggle the feedback highlight for character who is Poisoned",
						get = function() return nUI_Options.feedback_poison end,
						set = function(t,b)
							local option = nUI_SlashCommands[nUI_SLASHCMD_FEEDBACK]
							local command = option.command .. " " .. "poison"
							nUI_SlashCmdHandler(command)
						end,
						order = 2,
					},

					__fbdisease = {
						type = "toggle",
						name = "Disease",
						desc = "Toggle the feedback highlight for character who is Diseased",
						get = function() return nUI_Options.feedback_disease end,
						set = function(t,b)
							local option = nUI_SlashCommands[nUI_SLASHCMD_FEEDBACK]
							local command = option.command .. " " .. "disease"
							nUI_SlashCmdHandler(command)
						end,
						order = 3,
					},

					__fbmagic = {
						type = "toggle",
						name = "Magical Debuff",
						desc = "Toggle the feedback highlight for character who is under the effect of a magical debuff",
						get = function() return nUI_Options.feedback_magic end,
						set = function(t,b)
							local option = nUI_SlashCommands[nUI_SLASHCMD_FEEDBACK]
							local command = option.command .. " " .. "magic"
							nUI_SlashCmdHandler(command)
						end,
						order = 4,
					},
				},
				
				order = 4,
			},
		},
	}
	
	return unitframes
end

local function getConfigRaid()
	local raid = {
		type = "group",
		name = "Raid options",
		args = {
			__sort = {
				type = "select",
				name = "Sort",
				desc = nUI_SlashCommands[nUI_SLASHCMD_RAIDSORT].desc,
				values = {
					[nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "unit")]] = nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "unit")],
					[nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "group")]] = nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "group")],
					[nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "class")]] = nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "class")],
				},
				style = "dropdown",
				get = function() return nUI_Options.raidSort end,
				set = function(t,s)
					local option = nUI_SlashCommands[nUI_SLASHCMD_RAIDSORT]
					local command = option.command .. " " .. s
					nUI_SlashCmdHandler(command)
				end,
				order = 1,
			},
		}
	}
	
	return raid
end

local function getConfigFonts()
	local fonts = {
		type = "group",
		name = "Font options",
		args = {
			__notice = {
				type = "description",
				name = "Changing fonts requires a restart of the World of Warcraft user interface.",
				order = 1,
			},
			
		
			__font1_list = {
				type = "select",
				name = "Font 1",
				desc = "Font 1",
				values = {
					["Interface\\AddOns\\nUI\\Layouts\\Default\\Fonts\\ABF.ttf"] = "ABF",
					["Interface\\AddOns\\nUI\\Layouts\\Default\\Fonts\\Accidental Presidency.ttf"] = "Accidental Presidency",
					["Interface\\AddOns\\nUI\\Layouts\\Default\\Fonts\\Adventure.ttf"]  = "Adventure",
					["Interface\\AddOns\\nUI\\Layouts\\Default\\Fonts\\Bazooka.ttf"] = "Bazooka",
					["Interface\\AddOns\\nUI\\Layouts\\Default\\Fonts\\Emblem.ttf"] = "Emblem",
					["Interface\\AddOns\\nUI\\Layouts\\Default\\Fonts\\Enigma__2.ttf"] = "Enigma 2",
					["Interface\\AddOns\\nUI\\Layouts\\Default\\Fonts\\Tw_Cen_MT_Bold.ttf"] = "Tw Cen MT Bold", -- default
					["Interface\\AddOns\\nUI\\Layouts\\Default\\Fonts\\VeraSe.ttf"] = "VeraSe",
				},
				style = "dropdown",
				get = function() return nUI_Options.gui.fonts.font1 end,
				set = function(t,s)
					local command = nUI_SlashCommands[nUI_SLASHCMD_RELOAD].command
					nUI_Options.gui.fonts.font1 = s
					nUI_L["font1"] = nUI_Options.gui.fonts.font1
					-- DEFAULT_CHAT_FRAME:AddMessage("Font1: " .. nUI_L["font1"])
					nUI_SlashCmdHandler(command)
				end,
				order = 2,
				confirm = true,
				confirmText = "This will reload your UI.",
				hidden = true,
			}, 
			
			__font2_list = {
				type = "select",
				name = "Font 2",
				desc = "Font 2",
				values = {
					-- [nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "unit")]] = nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "unit")],
					-- [nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "group")]] = nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "group")],
					-- [nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "class")]] = nUI_L[nUI_SLASHCMD_OPTIONS(nUI_SLASHCMD_RAIDSORT, "class")],
					["Interface\\AddOns\\nUI\\Layouts\\Default\\Fonts\\Emblem.ttf"] = "Emblem"					
				},
				style = "dropdown",
				get = function() return nUI_Options.gui.fonts.font2 end,
				set = function(t,s)
					local command = nUI_SlashCommands[nUI_SLASHCMD_RELOAD].command
					nUI_Options.gui.fonts.font2 = s
					nUI_L["font2"] = nUI_Options.gui.fonts.font2
					-- DEFAULT_CHAT_FRAME:AddMessage("Font2: " .. nUI_L["font2"])
					nUI_SlashCmdHandler(command)
				end,
				order = 3,
				confirm = true,
				confirmText = "This will reload your UI.",
				hidden = true,
			},
			
			__font1_lsm = {
				type = 'select',
				dialogControl = 'LSM30_Font',
				name = 'Font 1',
				desc = 'Font 1',
				values = AceGUIWidgetLSMlists.font, 
				get = function() return nUI_Options.gui.fonts.font1 end,
				set = function(t,s)
					local command = nUI_SlashCommands[nUI_SLASHCMD_RELOAD].command
					nUI_Options.gui.fonts.font1 = s
					nUI_L["font1"] = LSM:Fetch("font", nUI_Options.gui.fonts.font1)
					nUI_SlashCmdHandler(command)
				end,
				order = 1,
				confirm = true,
				confirmText = "This will reload your UI.",
			},

			__font2_lsm = {
				type = 'select',
				dialogControl = 'LSM30_Font',
				name = 'Font 2',
				desc = 'Font 2',
				values = AceGUIWidgetLSMlists.font, 
				get = function() return nUI_Options.gui.fonts.font2 end,
				set = function(t,s)
					local command = nUI_SlashCommands[nUI_SLASHCMD_RELOAD].command
					nUI_Options.gui.fonts.font2 = s
					nUI_L["font2"] = LSM:Fetch("font", nUI_Options.gui.fonts.font2)
					nUI_SlashCmdHandler(command)
				end,
				order = 2,
				confirm = true,
				confirmText = "This will reload your UI.",
			},
			
			__statusbar = {
				type = 'select',
				dialogControl = 'LSM30_Statusbar', --Select your widget here
				name = 'Some Name',
				desc = 'Some Description',
				values = AceGUIWidgetLSMlists.statusbar, -- this table needs to be a list of keys found in the sharedmedia type you want
				get = function() return  end,
				set = function(t,s)
					DEFAULT_CHAT_FRAME:AddMessage("Statusbar: " .. s)
				end,
				order = 5,
				hidden = true,
			},
			
		}
	}
	
	return fonts
end

local function getConfigInfopanels()
	local infopanels = {
		type = "group",
		name = "Infopanel options",
		desc = "Infopanel options",
		args = {
			__note = {
				type = "description",
				name = "IMPORTANT! You have to reload the UI for changes to take effect.",
				order = 1,
			},
		
			__omen = {
				type = "toggle",
				name = "Omen",
				desc = "Toggle display of Omen in the Infopanels.",
				get = function() return nUI_Options.gui.infopanels.omen end,
				set = function(t,b) 
					nUI_Options.gui.infopanels.omen = b
				end,
				disabled = not nUI_InfoPanels[nUI_INFOPANEL_OMEN],
				order = 2,
			},		

			__recount = {
				type = "toggle",
				name = "Recount",
				desc = "Toggle display of Recount in the Infopanels.",
				get = function() return nUI_Options.gui.infopanels.recount end,
				set = function(t,b) 
					nUI_Options.gui.infopanels.recount = b
				end,
				disabled = not nUI_InfoPanels[nUI_INFOPANEL_RECOUNT],
				order = 3,
			},		
		
			__reloadui = {
				type = "execute",
				name = "Reload UI",
				desc = "Reload UI",
				func = function()
					ReloadUI()
				end,
				confirm = true,
				confirmText = "Are you sure you wish to reload the UI?",
				order = 4,
			},
		}
	}
		
	return infopanels
end

local function getConfigGeneral()
	local general = {
		type = "group",
		args = {
			__movers = {
				type = "execute",
				name = "Movers",
				desc = nUI_SlashCommands[nUI_SLASHCMD_MOVERS].desc,
				func = function() 
					local option = nUI_SlashCommands[nUI_SLASHCMD_MOVERS]				
					local command = option.command
					nUI_SlashCmdHandler(command)
				end,
				-- width = "full",
				order = 1,
			},

			__buttonbag = {
				type = "execute",
				name = "Button bag",
				desc = nUI_SlashCommands[nUI_SLASHCMD_BUTTONBAG].desc,
				func = function()
					local option = nUI_SlashCommands[nUI_SLASHCMD_BUTTONBAG]
					local command = option.command
					nUI_SlashCmdHandler(command)
				end,
				order = 2,
			},
			
			__calendar = {
				type = "toggle",
				name = "Guild calendar",
				desc = nUI_SlashCommands[nUI_SLASHCMD_CALENDAR].desc,
				get = function() return nUI_Options.showCalendar end,
				set = function(t,b)
					local option = nUI_SlashCommands[nUI_SLASHCMD_CALENDAR]
					local command = option.command
					nUI_SlashCmdHandler(command)
				end,
				order = 3,
			},

			__mountscale = {
				type = "range",
				name = nUI_SlashCommands[nUI_SLASHCMD_MOUNTSCALE].name,
				desc = nUI_SlashCommands[nUI_SLASHCMD_MOUNTSCALE].desc,
				min = 0.5,
				max = 1.5,
				step = 0.1,
				get = function () return nUI_Options.mountScale end,
				set = function(t, n)
					local option = nUI_SlashCommands[nUI_SLASHCMD_MOUNTSCALE]
					local command = option.command .. " " .. tostring(n)
					nUI_SlashCmdHandler(command)
				end,
				order = 4,
			},
			
			__clock = {
				type = "group",
				name = "Clock",
				desc = "Clock options",
				args = {
					__format = {
						type = "toggle",
						name = "24 hour clock",
						desc = "24 hour clock",
						get = function() return true end,
						set = function(t,b) end,
						order = 1,
						hidden = true,
					},
					
					__display = {
						type = "select",
						name = "Display",
						desc = nUI_SlashCommands[nUI_SLASHCMD_CLOCK].desc,
						values = {
							["server"] = "Server",
							["local"] = "Local",
							["both"] = "Both",
						},
						style = "dropdown",
						get = function() return nUI_Options.clock end,
						set = function(t,s) 
							local option = nUI_SlashCommands[nUI_SLASHCMD_CLOCK]
							local command = option.command .. " " .. s
							nUI_SlashCmdHandler(command)
						end,
						order = 2,
					},

				},
				order = 5,
			},
			
			__bagbar = {
				type = "group",
				name = "Bag bar",
				desc = "Bag bar options",
				args = {
					__active = {
						type = "select",
						name = "Visible",
						desc = nUI_SlashCommands[nUI_SLASHCMD_BAGBAR].desc,
						values = {
							["on"] = "On",
							["off"] = "Off",
							["mouseover"] = "Mouseover"
						},
						style = "dropdown",
						get = function() return nUI_Options.bagbar end,
						set = function(t,s)
							local option = nUI_SlashCommands[nUI_SLASHCMD_BAGBAR]
							local command = option.command .. " " .. s
							nUI_SlashCmdHandler(command)
						end,
						order = 1,
					},
					
					__onebag = {
						type = "toggle",
						name = "One bag",
						desc = nUI_SlashCommands[nUI_SLASHCMD_ONEBAG].desc,
						get = function() return nUI_Options.onebag end,
						set = function(t,b)
						local option = nUI_SlashCommands[nUI_SLASHCMD_ONEBAG]
						local command = option.command
						nUI_SlashCmdHandler(command)
						end,
						order = 2,
					},
				},
				order = 6,
			},
			
			__minimap = {
				type = "group",
				name = "Minimap",
				desc = "Minimap",
				args = {
					__managed = {
						type = "toggle",
						name = "Managed by nUI",
						desc = nUI_SlashCommands[nUI_SLASHCMD_MINIMAP].desc,
						get = function() return nUI_Options.minimap end,
						set = function(t,b) 
							local option = nUI_SlashCommands[nUI_SLASHCMD_MINIMAP]
							local command = option.command
							nUI_SlashCmdHandler(command)
						end,
						order = 1,
					},
							
					__shape = {
						type = "select",
						name = "Shape",
						desc = nUI_SlashCommands[nUI_SLASHCMD_ROUNDMAP].desc,
						values = {
							["round"] = "Round",
							["square"] = "Square",
						},
						style = "dropdown",
						get = function()
							local mode = "square"
							if (nUI_Options.round_map) then
								mode = "round"
							end
							return mode
						end,
						set = function(t, s)
							local option = nUI_SlashCommands[nUI_SLASHCMD_ROUNDMAP]
							local command = option.command
							nUI_SlashCmdHandler(command)
						end,
						order = 2,
					},
				},
				order = 7,
				
			},
			
			__display = {
				type = "group",
				name = "Display",
				desc = "Display",
				args = {
					__frameupdate = {
						type = "range",
						name = "Frame update rate",
						desc = nUI_SlashCommands[nUI_SLASHCMD_FRAMERATE].desc,
						min = 1,
						max = 120,
						step = 1,
						get = function() return nUI_Options.frame_rate or 30 end,
						set = function(t,n) 
							local option = nUI_SlashCommands[nUI_SLASHCMD_FRAMERATE]
							local command = option.command .. " " .. tostring(n)
							nUI_SlashCmdHandler(command)
						end,
						order = 1,
					},
					
					__console = {
						type = "select",
						name = "Top Console",
						desc = nUI_SlashCommands[nUI_SLASHCMD_CONSOLE].desc,
						style = "dropdown",
						values = {
							["mouseover"] = "Mouse",
							["on"] = "On",
							["off"] = "Off",
						},
						get = function() return nUI_Options.console end,
						set = function(t, s)
							local option = nUI_SlashCommands[nUI_SLASHCMD_CONSOLE]
							local command = option.command .. " " .. s
							nUI_SlashCmdHandler(command)
						end,
						order = 3,
					},
				
				},
				order = 8,
			},

			__location = {
				type = "group",
				name = "Location",
				desc = "Location options",
				args = {
					__mapcoords = {
						type = "toggle",
						name = "Map Coordinates",
						desc = nUI_SlashCommands[nUI_SLASHCMD_MAPCOORDS].desc,
						get = function() return nUI_Options.map_coords end,
						set = function(t,b)
							local option = nUI_SlashCommands[nUI_SLASHCMD_MAPCOORDS]
							local command = option.command
							nUI_SlashCmdHandler(command)
						end,
						order = 1,
					},
				},
				order = 9,
			},
			
			__auras = {
				type = "group",
				name = "Aura",
				desc = "Aura options",
				args = {
					__maxauras = {
						type = "range",
						name = "Maximum Auras",
						desc = nUI_SlashCommands[nUI_SLASHCMD_MAXAURAS].desc,
						min = 1,
						max = 40,
						step = 1,
						get = function() return nUI_Options.max_auras or 40 end,
						set = function(t,n)
							local option = nUI_SlashCommands[nUI_SLASHCMD_MAXAURAS]
							local command = option.command .. " " .. tostring(n)
							nUI_SlashCmdHandler(command)
						end,
						order = 1,
					},
				},
				order = 10,
			},
			
			__profiling = {
				type = "toggle",
				name = "Profiling",
				desc = nUI_SlashCommands[nUI_SLASHCMD_LASTITEM+2].desc,
				get = function() return _profiling end,
				set = function(t,b) 
					local option = nUI_SlashCommands[nUI_SLASHCMD_LASTITEM+2]				
					local command = option.command
					nUI_SlashCmdHandler(command)
					_profiling = b
				end,
				order = 99,
				hidden = true,
			},
			
			__debugging = {
				type = "range",
				name = "Debug",
				desc = nUI_SlashCommands[nUI_SLASHCMD_LASTITEM+1].desc,
				min = 0,
				max = 3,
				step = 1,
				get = function() return nUI_Options.debug end,
				set = function(t,n)
					local option = nUI_SlashCommands[nUI_SLASHCMD_LASTITEM+1]				
					local command = option.command .. " " .. tostring(n)
					nUI_SlashCmdHandler(command)
				end,
				order = 100,	
				-- hidden = true,
			},
			
		},
	}
	
	return general
end

local function getConfigSix()
	local six  = {
		type = "group",
		name = "nUI 6 options",
		desc = "nUI 6 options",
		args = {
			__healthlost = {
				type = "toggle",
				name = "Health Lost",
				desc = "Toggle display of health lost.",
				get = function() return nUI6_PlayerOptions.showHealthLost end,
				set = function(t,b) 
					nUI6_PlayerOptions.showHealthLost = b
				end,
				order = 1,
				width = "full",
			},			

			__sort = {
				type = "select",
				name = "Raid Sort",
				desc = nUI_SlashCommands[nUI_SLASHCMD_RAIDSORT].desc,
				values = {
					["playerName"] = "Player Name",
					["className"] = "Class Name",
					["role"] = "Role (Tank, Healer or DPS)",
					["raidID"] = "Raid ID",
					["raidGroup"] = "Raid Group",
				},
				style = "dropdown",
				get = function() return nUI6_PlayerOptions.raidSort end,
				set = function(t,s)
					nUI6_PlayerOptions.raidSort = s
				end,
				order = 2,
			},		


			__testunitframes = {
				type = "select",
				name = "Test Unit Frames",
				desc = "Forces all unit frames in the specified unit frame panel to be displayed using the current player's data.",
				values = {
					["Solo"] = "Solo",
					["Party"] = "Party",
					["Raid10"] = "Raid10",
					["Raid15"] = "Raid15",
					["Raid20"] = "Raid20",
					["Raid25"] = "Raid25",
					["Raid40"] = "Raid40",
					["Off"] = "Off"
				},
				style = "dropdown",
				get = function() 
					if (nUI6_PlayerOptions.testUnitFrames == nil) then 
						return "Off"
					else
						return nUI6_PlayerOptions.testUnitFrames:match('nUI6 Default DPS Panel: (%w+)')
					end
				end,
				set = function(t,s)
					if (s == "Off") then
						nUI6_PlayerOptions.testUnitFrames = nil
					else
						nUI6_PlayerOptions.testUnitFrames = "nUI6 Default DPS Panel: " .. s
					end
					ReloadUI()					
				end,
				confirm = true,
				confirmText = "Are you sure you wish to change this setting?  This will reload your UI.",				
				order = 3,
			},		
			
			__combatfeedback = {
				type = "group",
				name = "Combat Feedback",
				desc = "Combat Feedback",
				args = {
					__cfhidemagic = {
						type = "toggle",
						name = "Hide Magic indicator",
						desc = "Toggle display of the magic indicator.",
						get = function() return nUI6_PlayerOptions.hideMagic end,
						set = function(t,b) 
							nUI6_PlayerOptions.hideMagic = b
						end,
						order = 1,
					},	

					__cfhidedisease = {
						type = "toggle",
						name = "Hide Disease indicator",
						desc = "Toggle display of the disease indicator.",
						get = function() return nUI6_PlayerOptions.hideDisease end,
						set = function(t,b) 
							nUI6_PlayerOptions.hideDisease = b
						end,
						order = 2,
					},	

					__cfhidepoison = {
						type = "toggle",
						name = "Hide Poison inidicator",
						desc = "Toggle display of the poison indicator.",
						get = function() return nUI6_PlayerOptions.hidePoison end,
						set = function(t,b) 
							nUI6_PlayerOptions.hidePoison = b
						end,
						order = 3,
					},	

					__cfhidecurse = {
						type = "toggle",
						name = "Hide Curse indicator",
						desc = "Toggle display of the curse indicator.",
						get = function() return nUI6_PlayerOptions.hideCurse end,
						set = function(t,b) 
							nUI6_PlayerOptions.hideCurse = b
						end,
						order = 4,
					},	

					__cfhidedamage = {
						type = "toggle",
						name = "Hide Damage indicator",
						desc = "Toggle display of the damage indicator.",
						get = function() return nUI6_PlayerOptions.hideDamage end,
						set = function(t,b) 
							nUI6_PlayerOptions.hideDamage = b
						end,
						order = 5,
					},	

					__cfhideheals = {
						type = "toggle",
						name = "Hide Heals indicator",
						desc = "Toggle display of the heals indicator.",
						get = function() return nUI6_PlayerOptions.hideHeals end,
						set = function(t,b) 
							nUI6_PlayerOptions.hideHeals = b
						end,
						order = 6,
					},	

					__cfhideagro = {
						type = "toggle",
						name = "Hide Agro indicator",
						desc = "Toggle display of the agro indicator.",
						get = function() return nUI6_PlayerOptions.hideAgro end,
						set = function(t,b) 
							nUI6_PlayerOptions.hideAgro = b
						end,
						order = 7,
					},	

					__cfhidecustom = {
						type = "toggle",
						name = "Hide Custom indicator",
						desc = "Toggle display of the custom indicator.",
						get = function() return nUI6_PlayerOptions.hideCustom end,
						set = function(t,b) 
							nUI6_PlayerOptions.hideCustom = b
						end,
						order = 8,
					},	

				},
				order = 4,
			}
		}
	}
	
	return six
end
		
function nUIConfigGUI:OnInitialize()
	local AceConfigReg = LibStub("AceConfigRegistry-3.0")
	local AceConfigDialog = LibStub("AceConfigDialog-3.0")
	
	local AceGUI = LibStub("AceGUI-3.0")

	-- Create the options with Ace3
	LibStub("AceConfig-3.0"):RegisterOptionsTable("nUIConfigGUI",getCommandOptions)
	AceConfigReg:RegisterOptionsTable("nUI General",getConfigGeneral)
	AceConfigReg:RegisterOptionsTable("nUI Actionbars",getConfigActionbars)
	AceConfigReg:RegisterOptionsTable("nUI HUD",getConfigHUD)
	AceConfigReg:RegisterOptionsTable("nUI Raid", getConfigRaid)
	AceConfigReg:RegisterOptionsTable("nUI Tooltips",getConfigTooltips)
	AceConfigReg:RegisterOptionsTable("nUI Unitframes", getConfigUnitframes)
	AceConfigReg:RegisterOptionsTable("nUI Fonts", getConfigFonts)
	AceConfigReg:RegisterOptionsTable("nUI Infopanels", getConfigInfopanels)
	
	self.optionsFrame = AceConfigDialog:AddToBlizOptions("nUIConfigGUI","nUI")
	self.optionsFrame[L["About"]] = LibStub("LibAboutPanel").new("nUI", "nUI")
	self.optionsFrame[L["General"]] = AceConfigDialog:AddToBlizOptions("nUI General", L["General"], "nUI")		
	self.optionsFrame[L["Actionbars"]] = AceConfigDialog:AddToBlizOptions("nUI Actionbars", L["Actionbars"], "nUI")
	self.optionsFrame[L["HUD"]] = AceConfigDialog:AddToBlizOptions("nUI HUD", L["HUD"], "nUI")		
	self.optionsFrame[L["Raid"]] = AceConfigDialog:AddToBlizOptions("nUI Raid", L["Raid"], "nUI")
	self.optionsFrame[L["Tooltips"]] = AceConfigDialog:AddToBlizOptions("nUI Tooltips", L["Tooltips"], "nUI")		
	self.optionsFrame[L["Unitframes"]] = AceConfigDialog:AddToBlizOptions("nUI Unitframes", L["Unitframes"], "nUI")
	self.optionsFrame[L["Fonts"]] = AceConfigDialog:AddToBlizOptions("nUI Fonts", L["Fonts"], "nUI")
	self.optionsFrame[L["Infopanels"]] = AceConfigDialog:AddToBlizOptions("nUI Infopanels", L["Infopanels"], "nUI")
	
	if (nUIConfigGUI:nUI6()) then
		AceConfigReg:RegisterOptionsTable("nUI Six", getConfigSix)
		self.optionsFrame[L["Six"]] = AceConfigDialog:AddToBlizOptions("nUI Six", L["Six"], "nUI")
	end
	
	self:Patch()
	
	nUI_SLASHCMD_GUI = #nUI_SlashCommands + 1

	nUI_SlashCommands[nUI_SLASHCMD_GUI] =
	{
		command = "gui",
		options = nil,
		desc    = "Opens the nUI GUI configuration window",
		message = nil,
	}

	local option = nUI_SlashCommands[nUI_SLASHCMD_GUI]
	nUI_SlashCommands:setHandler( option.command, function() nUIConfigGUI:ChatCommand(); end )

	-- Register slash commands
	self:RegisterChatCommand("nuigui", "ChatCommand")

	-- Register shared media
	self:SharedMedia()

	nUI_Options.gui.enabled = true
	
	if not nUI_Options.gui.fonts then
		nUI_Options.gui.fonts = {
			["font1"] = "Tw Cen MT Bold",
			["font2"] = "Emblem"
		} 
	end
	
	if not nUI_Options.gui.infopanels then
		nUI_Options.gui.infopanels = {
			["omen"] = true,
			["recount"] = true
		}
	end
	
end

function nUIConfigGUI:OnEnable()
	NUI_LATEST_VERSION = nUIConfigGUI:nUILastestVersion()
	NUI6_ALPHA = nUIConfigGUI:nUI6()
	
	nUI_L["font1"] = LSM:Fetch("font", nUI_Options.gui.fonts.font1)
	nUI_L["font2"] = LSM:Fetch("font", nUI_Options.gui.fonts.font2)
	
	if (nUI_InfoPanels[nUI_INFOPANEL_OMEN]) then
		nUI_InfoPanels[nUI_INFOPANEL_OMEN]["enabled"] = nUI_Options.gui.infopanels.omen
	end
	
	if (nUI_InfoPanels[nUI_INFOPANEL_RECOUNT]) then
		nUI_InfoPanels[nUI_INFOPANEL_RECOUNT]["enabled"] = nUI_Options.gui.infopanels.recount
	end
end

function nUIConfigGUI:UpdateSettings(major, minor, bugfix)
	--do stuff
	DEFAULT_CHAT_FRAME:AddMessage("UPDATESETTINGS: major: " .. major)
	DEFAULT_CHAT_FRAME:AddMessage("UPDATESETTINGS: major: " .. minor)
	DEFAULT_CHAT_FRAME:AddMessage("UPDATESETTINGS: major: " .. bugfix)
end

function nUIConfigGUI:UpdateVersion()
	nUI_Options.gui.version = CURRENT_VERSION
	self:Print(format(L.Updated, nUI_Options.gui.version))
end

function nUIConfigGUI:nUILastestVersion()
	if (nUI_Options.version < NUI_CHECK_VERSION) then return false end
	return true
end

function nUIConfigGUI:nUI6()
	local result = false
	
	if (IsAddOnLoaded("nUI6")) then
		-- '6.03.03.05 (ALPHA)'
	
		if (NUI6_ALPHA_VERSION >= NUI6_ALPHA_CHECK) then result = true end
	end
	
	return result
end

function nUIConfigGUI:ChatCommand(input)
	InterfaceOptionsFrame_OpenToCategory(self.optionsFrame[L["General"]])
end

function nUIConfigGUI:Patch()
	
	-- if not nUI_Options.gui then nUI_Options.gui = {} end
	if type(nUI_Options.gui) ~= "table" then nUI_Options.gui = {} end
	if not nUI_Options.gui.version then nUI_Options.gui.version = CURRENT_VERSION end

	--version update
	if nUI_Options.gui.version ~= CURRENT_VERSION then
		DEFAULT_CHAT_FRAME:AddMessage("nUI_Options.gui.version: " .. nUI_Options.gui.version)
		DEFAULT_CHAT_FRAME:AddMessage("CURRENT_VERSION: " .. CURRENT_VERSION)
		
		if type(nUI_Options.gui.fonts) ~= "table" then 
			nUI_Options.gui.fonts = {
				["font1"] = "Tw Cen MT Bold",
				["font2"] = "Emblem"
			} 
		end
		
		if type(nUI_Options.gui.infopanels) ~= "table" then
			nUI_Options.gui.infopanels = {
				["omen"] = true,
				["recount"] = true
			}
		end
		
		-- self:UpdateSettings(nUI_Options.gui.version:match('(%w+)%.(%w+)%.(%w+)'))
		self:UpdateVersion()
	end

end

function nUIConfigGUI:SharedMedia()
	-- fonts
	LSM:Register("font", "ABF", [[Interface\AddOns\nUI\Layouts\Default\Fonts\ABF.ttf]])
	LSM:Register("font", "Accidental Presidency", [[Interface\AddOns\nUI\Layouts\Default\Fonts\Accidental Presidency.ttf]])
	LSM:Register("font", "Adventure", [[Interface\AddOns\nUI\Layouts\Default\Fonts\Adventure.ttf]])
	LSM:Register("font", "Bazooka", [[Interface\AddOns\nUI\Layouts\Default\Fonts\Bazooka.ttf]])
	LSM:Register("font", "Emblem", [[Interface\AddOns\nUI\Layouts\Default\Fonts\Emblem.ttf]])
	LSM:Register("font", "Enigma 2", [[Interface\AddOns\nUI\Layouts\Default\Fonts\Enigma__2.ttf]])
	LSM:Register("font", "Tw Cen MT Bold", [[Interface\AddOns\nUI\Layouts\Default\Fonts\Tw_Cen_MT_Bold.ttf]])
	LSM:Register("font", "Vera Serif", [[Interface\AddOns\nUI\Layouts\Default\Fonts\VeraSe.ttf]])
	
	-- statusbars
end
