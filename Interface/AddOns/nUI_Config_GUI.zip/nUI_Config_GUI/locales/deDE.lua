﻿local L = LibStub('AceLocale-3.0'):NewLocale('nUIConfigGUI', 'deDE', true)

L.About = 'About'
L.General = 'General'
L.Actionbars = 'Actionbars'
L.HUD = 'HUD'
L.Tooltips = 'Tooltips'
L.Unitframes = 'Unitframes'
L.Fonts = 'Fonts'
L.Infopanels = 'Infopanels'
L.Raid = 'Raid'
L.Profile = 'Profile'
L.Version = 'Version'
L.Author = 'Author'
L.Six = 'Six'

-- messages
L.MSG_NUI_LATEST = 'Minimum nUI version requirement met.  You have at least nUI version %s installed.'
L.MSG_NUI_UPGRADE = 'Please upgrade your version of nUI.  You need to have at least nUI version %s installed.'

--system messages
L.NewPlayer = 'Created new profile for %s'
L.Updated = 'Updated to v%s'

--profiles
L.ProfileCreated = 'Created new profile "%s"'
L.ProfileLoaded = 'Set profile to "%s"'
L.ProfileDeleted = 'Deleted profile "%s"'
L.ProfileCopied = 'Copied settings from "%s"'
L.ProfileReset = 'Reset profile "%s"'
L.CantDeleteCurrentProfile = 'Cannot delete the current profile'
L.InvalidProfile = 'Invalid profile "%s"'

--slash command help
L.ShowOptionsDesc = 'Shows the options menu'
L.ConfigDesc = 'Toggles configuration mode'

L.SetScaleDesc = 'Sets the scale of <frameList>'
L.SetAlphaDesc = 'Sets the opacity of <frameList>'
L.SetFadeDesc = 'Sets the faded opacity of <frameList>'

L.SetColsDesc = 'Sets the number of columns for <frameList>'
L.SetPadDesc = 'Sets the padding level for <frameList>'
L.SetSpacingDesc = 'Sets the spacing level for <frameList>'

L.ShowFramesDesc = 'Shows the given <frameList>'
L.HideFramesDesc = 'Hides the given <frameList>'
L.ToggleFramesDesc = 'Toggles the given <frameList>'

--slash commands for profiles
L.SetDesc = 'Switches settings to <profile>'
L.SaveDesc = 'Saves current settings and switches to <profile>'
L.CopyDesc = 'Copies settings from <profile>'
L.DeleteDesc = 'Deletes <profile>'
L.ResetDesc = 'Returns to default settings'
L.ListDesc = 'Lists all profiles'
L.AvailableProfiles = 'Available Profiles'
L.PrintVersionDesc = 'Prints the current version'

--dragFrame tooltips
L.ShowConfig = '<Right Click> to configure'
L.HideBar = '<Middle Click or Shift-Right Click> to hide'
L.ShowBar = '<Middle Click or Shift-Right Click> to show'
L.SetAlpha = '<Mousewheel> to set opacity (|cffffffff%d|r)'

--misc
L.On = "On"
L.Off = "Off"
L.Mouseover = "Mouseover"
-- tooltips
L.Owner = "Owner"
L.Mouse = "Mouse"
L.Fixed = "Fixed"
L.Default = "Default"
-- feedback
L.Curse = "Curse"
L.Disease = "Disease"
L.Magic = "Magic"
L.Poison = "Poison"
-- clock
L.Server = "Server"
L.Local = "Local"
L.Both = "Both"

-- config HUD
L.LBL_GRP_HUD_NAME = 'HUD options'
L.LBL_GRP_HUD_DESC = 'HUD options'
L.LBL_GRP_HUD_DISPLAY_NAME = 'Display'
L.LBL_GRP_HUD_DISPLAY_DESC = 'Display'
L.LBL_GRP_HUD_ALPHA_NAME = 'Transparency'
L.LBL_GRP_HUD_ALPHA_DESC = 'HUD transparency'
L.LBL_GRP_HUD_COOLDOWN_NAME = 'Cooldown'
L.LBL_GRP_HUD_COOLDOWN_DESC = 'Cooldown options'

L.LBL_ARG_HUD_HEALTHRACE_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_HEALTHRACE].name or 'Health Race'
L.LBL_ARG_HUD_HEALTHRACE_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_HEALTHRACE].desc or 'Health Race'
L.LBL_ARG_HUD_SHOWNPC_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_SHOWNPC].name or 'Non-combat NPC'
L.LBL_ARG_HUD_SHOWNPC_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_SHOWNPC].desc or 'Non-combat NPC'
L.LBL_ARG_HUD_COOLDOWN_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_COOLDOWN].name or 'Spell Cool Down Bar'
L.LBL_ARG_HUD_COOLDOWN_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_COOLDOWN].desc or 'Spell Cool Down Bar'
L.LBL_ARG_HUD_CDMIN_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDMIN].name or 'Cool Down Minimum'
L.LBL_ARG_HUD_CDMIN_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDMIN].desc or 'Cool Down Minimum'
L.LBL_ARG_HUD_CDALERT_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDALERT].name or 'Cool Down Alert'
L.LBL_ARG_HUD_CDALERT_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDALERT].desc or 'Cool Down Alert'
L.LBL_ARG_HUD_CDSOUND_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDSOUND].name or 'Cool Down Sound'
L.LBL_ARG_HUD_CDSOUND_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDSOUND].desc or 'Cool Down Sound'
L.LBL_ARG_HUD_SCALE_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_SCALE].name or 'Scale'
L.LBL_ARG_HUD_SCALE_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_SCALE].desc or 'Scale'
L.LBL_ARG_HUD_HGAP_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_HGAP].name or 'Horizontal Gap'
L.LBL_ARG_HUD_HGAP_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_HGAP].desc or 'Horizontal Gap'
L.LBL_ARG_HUD_VOFS_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_VOFS].name or 'Vertical Offset'
L.LBL_ARG_HUD_VOFS_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_VOFS].desc or 'Vertical Offset'
L.LBL_ARG_HUD_FOCUS_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_FOCUS].name or 'Player Focus'
L.LBL_ARG_HUD_FOCUS_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_FOCUS].desc or 'Player Focus'
L.LBL_ARG_HUD_IDLEALPHA_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_IDLEALPHA].name or 'Idle Transparency'
L.LBL_ARG_HUD_IDLEALPHA_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_IDLEALPHA].desc or 'Idle Transparency'
L.LBL_ARG_HUD_REGENALPHA_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_REGENALPHA].name or 'Regen Transparency'
L.LBL_ARG_HUD_REGENALPHA_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_REGENALPHA].desc or 'Regen Transparency'
L.LBL_ARG_HUD_TARGETALPHA_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_TARGETALPHA].name or 'Target Transparency'
L.LBL_ARG_HUD_TARGETALPHA_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_TARGETALPHA].desc or 'Target Transparency'
L.LBL_ARG_HUD_COMBATALPHA_NAME = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_COMBATALPHA].name or 'Combat Transparency'
L.LBL_ARG_HUD_COMBATALPHA_DESC = nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_COMBATALPHA].desc or 'Combat Transparency'

-- nUI SlashCommands
nUI_SlashCommands[nUI_SLASHCMD_HELP].name = "Help"
nUI_SlashCommands[nUI_SLASHCMD_RELOAD].name = "Reload UI"
nUI_SlashCommands[nUI_SLASHCMD_BUTTONBAG].name = "Minimap Button Bag"
nUI_SlashCommands[nUI_SLASHCMD_CALENDAR].name = "Guild Calendar"
nUI_SlashCommands[nUI_SLASHCMD_MOVERS].name = "Movers"
nUI_SlashCommands[nUI_SLASHCMD_CONSOLE].name = "Top Console"
nUI_SlashCommands[nUI_SLASHCMD_TOOLTIPS].name = "Tooltips"
nUI_SlashCommands[nUI_SLASHCMD_COMBATTIPS].name = "Action Button Tooltips"
nUI_SlashCommands[nUI_SLASHCMD_BAGSCALE].name = "Bag Scale"
nUI_SlashCommands[nUI_SLASHCMD_BAGBAR].name = "Bag Bar"
nUI_SlashCommands[nUI_SLASHCMD_FRAMERATE].name = "Frame Rate"
nUI_SlashCommands[nUI_SLASHCMD_FEEDBACK].name = "Unitframe Feedback"
nUI_SlashCommands[nUI_SLASHCMD_SHOWHITS].name = "Unitframe Show Hits"
nUI_SlashCommands[nUI_SLASHCMD_MAXAURAS].name = "Maximum Auras"
nUI_SlashCommands[nUI_SLASHCMD_AUTOGROUP].name = "Automatic Unit Panel Switch"
nUI_SlashCommands[nUI_SLASHCMD_RAIDSORT].name = "Raid Sort"
nUI_SlashCommands[nUI_SLASHCMD_SHOWANIM].name = "Animated Unit Portraits"
nUI_SlashCommands[nUI_SLASHCMD_HPLOST].name = "Unitframe Health"
nUI_SlashCommands[nUI_SLASHCMD_HUD].name = "HUD"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_HEALTHRACE].name = "Health Race"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_SHOWNPC].name = "Non-combat NPC"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_COOLDOWN].name = "Spell Cool Down Bar"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDALERT].name = "Cool Down Alert"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_CDSOUND].name = "Cool Down Sound"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_SCALE].name = "Scale"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_HGAP].name = "Horizontal Gap"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_VOFS].name = "Vertical Offset"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_FOCUS].name = "Player Focus"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_IDLEALPHA].name = "Idle Transparency"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_REGENALPHA].name = "Regen Transparency"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_TARGETALPHA].name = "Target Transparency"
nUI_SlashCommands[nUI_SLASHCMD_HUD].sub_menu[nUI_SLASHCMD_HUD_COMBATALPHA].name = "Combat Transparency"
nUI_SlashCommands[nUI_SLASHCMD_MOUNTSCALE].name = "Mount Scale"
nUI_SlashCommands[nUI_SLASHCMD_CLOCK].name = "Clock"
nUI_SlashCommands[nUI_SLASHCMD_MAPCOORDS].name = "Worldmap Coordinates"
nUI_SlashCommands[nUI_SLASHCMD_ROUNDMAP].name = "Minimap Shape"
nUI_SlashCommands[nUI_SLASHCMD_MINIMAP].name = "Minimap Management"
nUI_SlashCommands[nUI_SLASHCMD_ONEBAG].name = "Single Bag Button"
nUI_SlashCommands[nUI_SLASHCMD_LASTITEM+1].name = "Debug"
nUI_SlashCommands[nUI_SLASHCMD_LASTITEM+2].name = "Profile"

