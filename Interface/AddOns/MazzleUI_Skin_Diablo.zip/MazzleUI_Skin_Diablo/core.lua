function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Skin_Diablo\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Skin_Diablo\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Skin_Diablo\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Skin_Diablo\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Skin_Diablo\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Skin_Diablo\\MazzleUICastingBarBorder",
            chatborder = "Interface\\AddOns\\MazzleUI_Skin_Diablo\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Skin_Diablo\\MazzleUIMinimapBorder",
        },
    }
end