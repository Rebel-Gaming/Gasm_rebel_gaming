--[[
	State.lua
		Does state changing for class bars and paging
--]]

local PLAYER_CLASS = select(2,UnitClass("player"))
local MAX_PAGES = 12
local classMap = ''
local pageMap = ''
local maxState = 0
local statesLoaded

--[[ State Mapping ]]--

local function AddPair(stateString, fromState, toState)
	if stateString then
		return stateString .. format('%s:%s;', fromState, toState)
	end
	return format('%s:%s;', fromState, toState)
end

--[[ Class States ]]--

-- Paging memory by Darklin
local function LoadStanceStates(stateMachine, maxStance)
	for toS = 0, maxStance do
		local stanceMap
		for page = 0, MAX_PAGES - 1 do
			for fromS = 0, maxStance do
				if fromS ~= toS then
					stanceMap = AddPair(stanceMap, (fromS * 1000) + page, (toS * 1000) + page)
				end
			end
		end
		stateMachine:SetAttribute('statemap-stance-' .. toS, stanceMap) -- shapeshift forms
    end    
end
 
local function LoadProwlStates(stateMachine)
    local toProwl
  	for j = 0, MAX_PAGES - 1 do
  		toProwl = AddPair(toProwl, (3000 + j), (7000 + j))
  	end
  	stateMachine:SetAttribute('statemap-stealth-1', toProwl)
  	
  	local toCat
  	for j = 0, MAX_PAGES - 1 do
	  	toCat = AddPair(toCat, (7000 + j), (3000 + j))
  	end
  	stateMachine:SetAttribute('statemap-stealth-0', toCat)
end

local function LoadPageStates(stateMachine)
	for page = 1, MAX_PAGES do
		local stateMap = ''
		for state = 0, maxState do
			local sIndex = state*1000
			stateMap = AddPair(stateMap, sIndex .. '-' .. sIndex + MAX_PAGES-1, sIndex + page-1)
		end
		stateMachine:SetAttribute('statemap-actionbar-' .. page, stateMap)
	end
end

--[[ Stances ]]--

local function LoadStateMaps()
	-- load class mapping
	local stances = BONGOS_STANCES[PLAYER_CLASS]
	if stances then
		for i in pairs(stances) do
			classMap = AddPair(classMap, i * 1000, 's' .. i)
			maxState = maxState + 1
		end
	end

	--load page mapping	
	for state = 0, maxState do
		for page = 1, MAX_PAGES do
			pageMap = AddPair(pageMap, (state * 1000) + (page - 1), 'p' .. page - 1)
		end
	end	
end

--[[ Constructor ]]--

function BState_Update(stateMachine)
	local currentState = 0
	if PLAYER_CLASS == 'DRUID' and IsStealthed() then
		if GetShapeshiftForm() == 3 then
			currentState = '7000' + GetActionBarPage() - 1
		end
	elseif BONGOS_STANCES[PLAYER_CLASS] then
		currentState =  1000 * GetShapeshiftForm() + GetActionBarPage() - 1
	else
		currentState =  GetActionBarPage() - 1
	end

	stateMachine:SetAttribute('state', currentState)
end

function BState_Create(parent)
	if not statesLoaded then
		LoadStateMaps()
		statesLoaded = true
	end
		
	local stateMachine = CreateFrame('Frame', nil, parent, 'SecureStateDriverTemplate')
	
	LoadStanceStates(stateMachine, maxState)
	if PLAYER_CLASS == 'DRUID' then
		LoadProwlStates(stateMachine)
	end
	LoadPageStates(stateMachine)

	stateMachine:SetAttribute('statebutton', classMap .. pageMap)
	
	BState_Update(stateMachine)

	return stateMachine
end
