--[[
	BActionBar
		A Bongos Actionbar
--]]

BActionBar = CreateFrame('Button')
local Bar_mt = {__index = BActionBar}

local DEFAULT_SPACE = 2
local DEFAULT_ACTIONBARS = 10
local MAX_BUTTONS = BActionButton.GetMax()
local BUTTON_SIZE = BActionButton.GetSize()
local nextOpenButton = 1
--[[  Rightclick Menu ]]--

local function CreateConfigMenu(name)
	local menu = CreateFrame("Button", name, UIParent, "BongosRightClickMenu")
	menu:SetWidth(220)
	menu:SetHeight(325)

	local hideButton = CreateFrame("CheckButton", name .. "Hide", menu, "BongosHideButtonTemplate")

	local sizeSlider = CreateFrame("Slider", name .. "Size", menu, "BongosSlider")
	sizeSlider:SetPoint("TOPLEFT", hideButton, "BOTTOMLEFT", 2, -10)
	sizeSlider:SetScript("OnValueChanged", function()
		getglobal(this:GetName() .. "ValText"):SetText(this:GetValue())
	end)
	sizeSlider:SetScript("OnMouseUp", function()
		if not this:GetParent().onShow then
			this:GetParent().onShow = true
			local bar = this:GetParent().frame
			local newValue = this:GetValue()
            MazzleUI:SaveActionMapping(bar.id, newValue, bar.sets.numPages)
            BActionSets[bar.id].size = newValue
            MazzleUI:RegenerateBars()
            MazzleUI:RestoreActionMapping()
			if (BActionSets[bar.id].cols and (BActionSets[bar.id].cols > newValue)) then BActionSets[bar.id].cols = nil; end
			BongosActionBarMenuColsHigh:SetText(newValue)
			BongosActionBarMenuCols:SetMinMaxValues(1, newValue)
        	BongosActionBarMenuCols:SetValue((BActionSets[bar.id].cols or newValue))
			local mp = MazzleUI:GetMaxPages(bar.id)
			BongosActionBarMenuPages:SetMinMaxValues(1, mp)
			BongosActionBarMenuPagesHigh:SetText(mp)
			MazzleUI:SetMaxBars()
            MazzleUI:UpdateBarPositions()
			this:GetParent().onShow = nil
		end
	end)
	sizeSlider:SetValueStep(1)
	getglobal(name .. "SizeText"):SetText(BONGOS_SIZE)
	getglobal(name .. "SizeLow"):SetText(1)

	local colsSlider = CreateFrame("Slider", name .. "Cols", menu, "BongosSlider")
	colsSlider:SetPoint("TOP", sizeSlider, "BOTTOM", 0, -24)
	colsSlider:SetScript("OnValueChanged", function()
		getglobal(this:GetName() .. "ValText"):SetText(this:GetValue())
	end)
	colsSlider:SetScript("OnMouseUp", function()
		local bar = this:GetParent().frame
		if not this:GetParent().onShow then
			this:GetParent().onShow = true
			if (this:GetValue() == BActionSets[bar.id].size) then 
                BActionSets[bar.id].cols = nil
            else
                BActionSets[bar.id].cols = this:GetValue()
            end
            MazzleUI:RegenerateBars()
            MazzleUI:UpdateBarPositions()
			this:GetParent().onShow = nil
		end
	end)
	colsSlider:SetValueStep(1)
	getglobal(name .. "ColsText"):SetText(BONGOS_COLUMNS)
	getglobal(name .. "ColsLow"):SetText(1)
	
	local pagesSlider = CreateFrame("Slider", name .. "Pages", menu, "BongosSlider")
	pagesSlider:SetPoint("TOP", colsSlider, "BOTTOM", 0, -24)
	pagesSlider:SetScript("OnValueChanged", function()
		if not this:GetParent().onShow then
			getglobal(this:GetName() .. "ValText"):SetText(this:GetValue())
		end
	end)
	pagesSlider:SetScript("OnMouseUp", function()
		if not this:GetParent().onShow then
			this:GetParent().onShow = true
			local bar = this:GetParent().frame
			local newValue = this:GetValue()
            MazzleUI:SaveActionMapping(bar.id, bar.sets.size, newValue)
			if (newValue > 1) then BActionSets[bar.id].paging = 1; else BActionSets[bar.id].paging = nil; end
            BActionSets[bar.id].numPages = newValue
            MazzleUI:RegenerateBars()
            MazzleUI:RestoreActionMapping()
            local ms = MazzleUI:GetMaxBarSize(bar.id)
			BongosActionBarMenuSize:SetMinMaxValues(1, ms)
			BongosActionBarMenuSizeHigh:SetText(ms)
			MazzleUI:SetMaxBars()
			this:GetParent().onShow = nil
		end
	end)
	pagesSlider:SetValueStep(1)
	getglobal(name .. "PagesText"):SetText("Pages")
	getglobal(name .. "PagesLow"):SetText(1)
	
	local spacingSlider = CreateFrame("Slider", name .. "Spacing", menu, "BongosSpaceSlider")
	spacingSlider:SetPoint("TOP", pagesSlider, "BOTTOM", 0, -24)
	spacingSlider:SetScript("OnValueChanged", function()
		getglobal(this:GetName() .. "ValText"):SetText(this:GetValue())
	end)
	spacingSlider:SetScript("OnMouseUp", function()
		if not this:GetParent().onShow then
			local bar = this:GetParent().frame
            BActionSets[bar.id].space = this:GetValue()
            MazzleUI:RegenerateBars()
			--bar:Layout(nil, this:GetValue(), nil)
            MazzleUI:UpdateBarPositions()
		end
        MazzleUI:UpdateBarPositions()
	end)

	local scaleSlider = CreateFrame("Slider", name .. "Scale", menu, "BongosScaleSlider")
	scaleSlider:SetPoint("TOP", spacingSlider, "BOTTOM", 0, -24)
	scaleSlider:SetScript("OnValueChanged", function()
		if(not this:GetParent().onShow) then
			BBar.SetScale(this:GetParent().frame, this:GetValue() / 100, 1);
		end
		getglobal(this:GetName() .. "ValText"):SetText(this:GetValue())
	end)
	scaleSlider:SetScript("OnMouseUp", function()
        MazzleUI:UpdateBarPositions()
	end)

	local opacitySlider = CreateFrame("Slider", name .. "Opacity", menu, "BongosOpacitySlider")
	opacitySlider:SetPoint("TOP", scaleSlider, "BOTTOM", 0, -24)
end

--[[ Settings Loading ]]--

local function LoadMainBarDefaults()
	BActionSets[1] = {vis = 1, paging = 1}

	local class = select(2,UnitClass("player"))
	if class == 'DRUID' then
		BActionSets[1].stances = {8, nil, 6, nil, 9, nil, 7} --bear, aquatic, cat, travel, moonkin, flight, prowl
	elseif class == 'WARRIOR' then
		BActionSets[1].stances = {6, 7, 8}
	elseif class == 'ROGUE' then
		BActionSets[1].stances = {6}
--	elseif class == 'PRIEST' then
--		BActionSets[1].stances = {6}
	end
end

--[[ 
	ActionBar Methods 
--]]

function BActionBar.Create(id)
	if InCombatLockdown() then CQ.Do(function() BActionBar.Create(id) end) return end		
	if id == 1 and not BActionSets[1] then LoadMainBarDefaults() end

	local bar = BBar.Create(id, "BActionBar" .. id,  "BActionSets." .. id, BActionBar.ShowMenu, nil, BActionBar.Delete)
	setmetatable(bar, Bar_mt)
	bar:SetID(id)
    bar:SetFrameStrata("LOW")
	if not bar.driver then
		bar.driver = BState_Create(bar, bar:GetNumPages())
	end
	if id==1 then
		nextOpenButton = 1
	end
	bar.sets.startID = nextOpenButton
	if not bar:IsUserPlaced() then
		local col = mod(bar:GetStart(), 12)
		if col == 0 then col = 12 end

		local row = ceil(bar:GetStart() / 12) - 1
		bar:SetPoint("BOTTOMLEFT", UIParent, "BOTTOM", -38*(12-col)+222, 38*row)
	end
	bar.maxSize = MAX_BUTTONS - bar:GetStart() + 1 
	bar:Layout()
	nextOpenButton = bar:GetStart()+bar:GetPagedSize()
	return bar
end

function BActionBar:Delete()
	for i = self:GetStart(), self:GetStart() + self:GetPagedSize() do
		button = BActionButton.Get(i)
		if button then
			button:Release()
		else
			break
		end
	end
end

function BActionBar:Layout(cols, space, size)
	if InCombatLockdown() then CQ.Do(function() self:Layout(cols, space, size) end) return end

	--[[ load settings ]]--
	
	local maxSize = self:GetSize()
	if size == maxSize then
		self.sets.size = nil
	elseif size then
		self.sets.size = size
	end
	size = self:GetSize()

	cols = cols or self.sets.cols
	if cols == size then
		self.sets.cols = nil
	elseif cols then
		self.sets.cols = cols
	end
	cols = cols or size
    
	if space == DEFAULT_SPACE then
		self.sets.space = nil
	elseif space then
		self.sets.space = space
	end
	space = self.sets.space or DEFAULT_SPACE

	--[[ Layout the Buttons ]]--
	
	if size < 1 then
		self:SetWidth(0); self:SetHeight(0)
	else
		local buttonSize = BUTTON_SIZE + space
		local offset = space / 2
		
		self:SetWidth(buttonSize * cols - space)
		self:SetHeight(buttonSize * ceil(size / cols) - space)
		local startID = self:GetStart()
		local endID = self:GetEnd()
		for i = startID, endID do
			local button = BActionButton.Set(i, self)
			if button then
				local normID = i - startID + 1
				local row = mod(normID - 1, cols)
				local col = ceil(normID / cols) - 1
				button:SetPoint('TOPLEFT', self, 'TOPLEFT', buttonSize * row, -buttonSize * col)
			else
				break
			end
		end
	end
	
	local minID = self:GetEnd()+1
	local maxID = self:GetStart() + self:GetMaxSize() - 1
	for i = minID, maxID do
		local button = BActionButton.Get(i)
		if button then
			button:Release()
		else
			break
		end
	end
end

function BActionBar:SetSize(size)
	if size then
		self.sets.size = size
	end
	size = self:GetSize()
end

function BActionBar:SetNumPages(numPages)
		self.sets.numPages = numPages
end

function BActionBar:GetNumPages()
	return self.sets.numPages or 1
end

--[[
	Paging Functions

	Precedence:
		1. paged manually  return (BActionSets[id].page and CURRENT_ACTIONBAR_PAGE ~= 1)
			special key held down, shift + number
		2. paged via shapeshift return (BActionSets[id].switchOnShift and BActionMain.shapeshifted)
			in bear form, in cat form, in fury stance
		3. contextual paging
			should be used for such things as, if targeting a friendly unit,
--]]

--normal paging
function BActionBar:SetPaging(enable)
	if enable then
		self.sets.paging = 1
	else
		self.sets.paging = nil
	end
	self:UpdatePages()
end

function BActionBar:UpdatePages()
	for i = self:GetStart(), self:GetStart() + self:GetPagedSize() do
		local button = BActionButton.Get(i)
		if button then
			button:UpdateAllPages()
		else
			break
		end
	end
end

function BActionBar:GetPageOffset(page)
	if self:CanPage() then
		page = math.fmod(page, self:GetNumPages())
		return page * self:GetSize()
	end
	return 0
end

function BActionBar:CanPage()
	return self.sets.paging
end

--[[ State Offsets - Handles things like which bar to go to when changing stances ]]--

function BActionBar:SetStanceOffset(stance, offset)
	local stances = self:GetStances()
	if offset and offset ~= 0 then
		if not stances then
			self.sets.stances = {}
			stances = self.sets.stances
		end
		stances[stance] = offset
	elseif stances then
		stances[stance] = nil
	end
	self:UpdateStance(stance)
end

function BActionBar:UpdateStance(stance)
	for i = self:GetStart(), self:GetEnd() do
		local button = BActionButton.Get(i)
		if button then
			button:UpdateStance(stance)
		else
			break
		end
	end
end

function BActionBar:UpdateStances()
	local stances = self:GetStances()
	if stances then
		for i = self:GetStart(), self:GetEnd() do
			local button = BActionButton.Get(i)
			if button then
				button:UpdateAllStances()
			else
				break
			end
		end
	end
end

function BActionBar:GetStanceOffset(stance)
	local stances = self:GetStances()
	if stances then
		local offset = stances[stance]
		if offset then
			return offset * self:GetSize() or 0
		end
	end
	return 0
end

function BActionBar:GetStances()
	return self.sets.stances
end

function BActionBar:HasStance()
	local stances = self:GetStances()
	return stances and next(stances)
end

--[[ Start/End/Size ]]--

function BActionBar:GetSize()
	local maxSize = self:GetMaxSize()
	local size

	if self.sets then
		size = self.sets.size
	end

	return math.min(size or maxSize, maxSize)
end

function BActionBar:GetStart()
	return self.sets.startID or 1
end

function BActionBar:GetEnd()
	return min((self:GetStart() + self:GetSize() - 1), MAX_BUTTONS + 1)
end

function BActionBar:GetMaxSize()
	return MAX_BUTTONS - self:GetStart() + 1 --self.maxSize
end

function BActionBar:GetPagedSize()
	return self:GetSize() * self:GetNumPages()
end

--[[
	Sets how many actionbars to use.  This function deletes all actionbars, then recreates them.
	This is done to make it easier to layout bars after adjusting how many there are.
--]]

function BActionBar.SetNumber(numBars)
	local diff = (numBars or DEFAULT_ACTIONBARS) - BActionBar.GetNumber()
	if diff ~= 0 then
		BActionBar.ResetBars(numBars,false,true)
	end
	
end

-- 'safe' added in for safe re-creation of bars so we can keep our settings.
function BActionBar.ResetBars(numBars, safe)
		local old_BActionSets = TLib.TCopy(BActionSets)
		for i = 1, BActionBar.GetNumber() do
			BBar.Delete(i)
		end
		nextOpenButton = 1
		BActionSets.g.numActionBars = numBars
		local i = 1
		while i <= BActionBar.GetNumber() do
			if(safe) then
				if(old_BActionSets[i]) then
					old_BActionSets[i].startID = nil
					BActionSets[i] = TLib.TCopy(old_BActionSets[i])
				end
			end
			BActionBar.Create(i)
			if(BActionBar.Get(i):GetEnd()>=MAX_BUTTONS) then
				BActionSets.g.numActionBars = i
				break
			elseif i == BActionBar.GetNumber() then
				BActionSets.g.numActionBars = i + 1
			end

			i=i+1
		end
		for i = 1, BActionBar.GetNumber() do
			local bar = BActionBar.Get(i)
			bar:UpdateStances()
			bar:UpdatePages()
		end	
end

function BActionBar.GetNumber()
	return (BActionSets and BActionSets.g and BActionSets.g.numActionBars) or DEFAULT_ACTIONBARS
end

--[[ Menu Functions ]]--

--Show the menu, loading all values
function BActionBar:ShowMenu()
	if not BongosActionBarMenu then
		CreateConfigMenu("BongosActionBarMenu")
	end

	BongosActionBarMenu.onShow = 1

	BongosActionBarMenu.frame = self
    local thisID = self:GetID()
	BongosActionBarMenuText:SetText("Action Bar " .. thisID)
	BongosActionBarMenuHide:SetChecked(not self.sets.vis)

	local maxSize = MazzleUI:GetMaxBarSize(thisID)
	local currentSize = self:GetSize()

	BongosActionBarMenuSizeHigh:SetText(maxSize)
	BongosActionBarMenuSize:SetMinMaxValues(1, maxSize)
	BongosActionBarMenuSize:SetValue(currentSize)

	BongosActionBarMenuCols:SetMinMaxValues(1, currentSize)
	BongosActionBarMenuColsHigh:SetText(currentSize)
	BongosActionBarMenuCols:SetValue((self.sets.cols or currentSize))

	local maxPgs = MazzleUI:GetMaxPages(thisID)
	BongosActionBarMenuPagesHigh:SetText(maxPgs)
	BongosActionBarMenuPages:SetMinMaxValues(1,maxPgs)
	BongosActionBarMenuPages:SetValue(self:GetNumPages())
	BongosActionBarMenuPagesValText:SetText(self:GetNumPages())

	BongosActionBarMenuSpacing:SetValue(self.sets.space or DEFAULT_SPACE)
	BongosActionBarMenuScale:SetValue(self:GetScale() * 100)
	BongosActionBarMenuOpacity:SetValue(self:GetAlpha() * 100)

	BMenu.ShowForBar(BongosActionBarMenu, self)

	BongosActionBarMenu.onShow = nil
end
	
--[[ Utility ]]--
	
function BActionBar.Get(id)
	return getglobal('BActionBar' .. id)
end
