FuBar - FarmerFu v2.0 $Revision: 29970 $

Author: Aileen (aileen.wow@gmail.com)
$Date: 2007-03-11 16:34:22 -0400 (Sun, 11 Mar 2007) $

Keeps track of what you are farming. Inspired by AceSilverFarmer.

INSTALL: Put the FuBar_FarmerFu folder into the AddOns folder
     e.g. c:\Games\World of Warcraft\Interface\AddOns\

BUGS: http://www.wowinterface.com/portal.php?id=86&a=listbugs

REQUESTS:  http://www.wowinterface.com/portal.php?id=86&a=listfeatures 