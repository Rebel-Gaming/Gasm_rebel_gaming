﻿--[[---------------------------------------------------------------------------

Copyright (c) 2008 by K. Scott Piel 
All Rights Reserved

E-mail: < kscottpiel@gmail.com >
Web:    < http://www.scottpiel.com >

This file is part of nUI.

    nUI is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    nUI is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with nUI.  If not, see <http://www.gnu.org/licenses/>.
	
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

--]]---------------------------------------------------------------------------

if not nUI then nUI = {}; end
if not nUI_InfoPanels then nUI_InfoPanels = {}; end

local CreateFrame = CreateFrame;
local MouseIsOver = MouseIsOver;

nUI_INFOMODE_OMEN3RECOUNT  = 7;
nUI_INFOPANEL_OMEN3RECOUNT = "nUI_InfoPanel_Omen3Recount";

-------------------------------------------------------------------------------
-- localization

nUI_L[nUI_INFOPANEL_OMEN3RECOUNT]		   	= "Info Panel: Omen3 Threat + Recount Damage Meter Mode"; -- this is the phrase shown in the mouseover tooltip
nUI_L[nUI_INFOPANEL_OMEN3RECOUNT.."Label"]	= "Stats"; -- small word or abbreviation to show on the panel selector button

if nUI_Locale == "deDE" then
	
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT]		   	= "Info Panel: Omen3 + Recount Damage Meter Modus";
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT.."Label"]	= "Stats";
	
elseif nUI_Locale == "enGB" then
	
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT]		   	= "Info Panel: Omen3 Threat + Recount Damage Metre Mode";
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT.."Label"]	= "Stats";
	
elseif nUI_Locale == "esES" then
	
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT]		   	= "Panel de Información : Modo del contador de amenaza Omen3  + daño Recount ";
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT.."Label"]	= "Stats";

elseif nUI_Locale == "frFR" then
	
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT]		   	= "Panneau info:  Affichage Omen3 + Recount";
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT.."Label"]	= "Stats";
	
elseif nUI_Locale == "zhCN" then		-- Simplified Chinese

	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT]		   	= "Info Panel: Omen3 仇恨表 + Recount 伤害表模式";
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT.."Label"]	= "Stats";
	
elseif nUI_Locale == "zhTW" then		-- Traditional Chinese
		
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT]		   	= "Info Panel: Omen3 仇恨表 + Recount 傷害表模式";
	nUI_L[nUI_INFOPANEL_OMEN3RECOUNT.."Label"]	= "Stats";
	
end

-------------------------------------------------------------------------------
-- default configuration for the minimap info panel

nUI_InfoPanels[nUI_INFOPANEL_OMEN3RECOUNT] =
{	
	enabled   = true,
	desc      = nUI_L[nUI_INFOPANEL_OMEN3RECOUNT],			-- player friendly name/description of the panel
	label     = nUI_L[nUI_INFOPANEL_OMEN3RECOUNT.."Label"],	-- label to use on the panel selection button face
	rotation  = nUI_INFOMODE_OMEN3RECOUNT,					-- index or position this panel appears on/in when clicking the selector button
	full_size = true;										-- this plugin requires the entire info panel port without the button bag
	
	options  =
	{
		enabled  = true,
	},
};

-------------------------------------------------------------------------------
-- master frame for the plugin

local plugin  = CreateFrame( "Frame", nUI_INFOPANEL_OMEN3RECOUNT, nUI_Dashboard.Anchor );
plugin.active = true;

local function onStatsEvent( self, event, arg1 )
	
	if arg1 == "nUI_InfoPanel_Stats" then

		-- disabled the Recount and Omen3 information panels that are distributed with nUI
		
		nUI_InfoPanels[nUI_INFOPANEL_RECOUNT].enabled = false;
		nUI_InfoPanels[nUI_INFOPANEL_OMEN3].enabled = false;

		if not IsAddOnLoaded( "Omen" ) then 
			LoadAddOn( "Omen" );
		end
		
		if not IsAddOnLoaded( "Recount" ) then 
			LoadAddOn( "Recount" );
		end
		
		plugin.active = IsAddOnLoaded( "Omen" ) and IsAddOnLoaded( "Recount" );

	end
end

plugin:SetScript( "OnEvent", onStatsEvent );
plugin:RegisterEvent( "ADDON_LOADED" );

-------------------------------------------------------------------------------

plugin.initPanel = function( container, options )

	plugin.container = container;
	plugin.options   = options;

	if options and options.enabled then
			
		plugin.setEnabled( true );
		
	end
end

-------------------------------------------------------------------------------

plugin.sizeChanged = function( scale, height, width )
	
	local options  = plugin.options;
	local rframe   = plugin.rframe;
	
	plugin.scale = scale;

	Omen:ResizeBars()
	Omen:ReAnchorLabels()
	Omen:UpdateBars()
			
	nUI_Movers:lockFrame( rframe, false, nil );
	Recount:LockWindows( false );

	rframe:SetWidth( width ); 
	rframe:SetHeight( height+10 ); 

	Recount:ResizeMainWindow();
	Recount:LockWindows( true );
	nUI_Movers:lockFrame( rframe, true, nil );
	
end	

-------------------------------------------------------------------------------

plugin.setEnabled = function( enabled )

	if plugin.enabled ~= enabled then
		
		plugin.enabled = enabled;
		
		if not enabled then

			plugin:UnregisterEvent( "PET_ATTACK_START" );
			plugin:UnregisterEvent( "PET_ATTACK_STOP" );
			plugin:UnregisterEvent( "PLAYER_REGEN_ENABLED" );
			plugin:UnregisterEvent( "PLAYER_REGEN_DISABLED" );			
			plugin:SetScript( "OnEvent", nil );
			
			local rframe = plugin.rframe;
			
			if rframe.saved_parent then

				nUI_Movers:lockFrame( rframe, false, nil );
				Recount:LockWindows( false );
				
				rframe:SetParent( rframe.saved_parent );
				rframe:SetBackdropBorderColor( rframe.border_color );
				rframe:SetBackdropColor( rframe.backdrop_color );

				rframe.Show = rframe.cachedShow;
				rframe.Hide = rframe.cachedHide;
				
				rframe:SetAlpha( 1 );
				
			end
		
			if plugin.saved_bar_parent then

				nUI_Movers:lockFrame( Omen.Anchor, false, nil );
				
				Omen.Anchor.Show = Omen.Anchor.nUI_CachedShow;
				Omen.Anchor.Hide = Omen.Anchor.nUI_CachedHide;
				Omen.Grip.Show   = Omen.Grip.nUI_CachedShow;
				
				Omen.Anchor:SetParent( Omen.Anchor.saved_bar_parent );
				
				Omen.Anchor.saved_bar_parent = nil;
				
				Omen.Anchor:SetAlpha( 1 );
				
			end
			
		else

			local rframe = Recount.MainWindow;
			
			plugin.rframe = rframe;
			plugin.combat = InCombatLockdown();
			
			if not rframe.saved_parent then
				rframe.saved_parent   = rframe:GetParent();
				rframe.border_color   = rframe:GetBackdropBorderColor();
				rframe.backdrop_color = rframe:GetBackdropColor();
			end
			
			rframe:SetParent( plugin.container );
			rframe:SetPoint( "TOPLEFT", plugin.container, "TOPLEFT", 0, 10 );
			rframe:SetPoint( "BOTTOMRIGHT", plugin.container, "BOTTOMRIGHT", 0, 0 );
			rframe:SetFrameStrata( plugin.container:GetFrameStrata() );
			rframe:SetFrameLevel( plugin.container:GetFrameLevel()+1 );
			rframe:SetBackdropBorderColor( 0, 0, 0, 1 );
			rframe:SetBackdropColor( 0, 0, 0, 0 );
			rframe:Show();
			
			rframe.CloseButton:Hide();			

			rframe.cachedShow = rframe.Show;
			rframe.cachedHide = rframe.Hide;
			
			rframe.Show = function() end;
			rframe.Hide = function() end;

			rframe:SetAlpha( plugin.combat and 0 or 1 );
			
			Recount:LockWindows( true );
			nUI_Movers:lockFrame( rframe, true, nil );
			
			if not plugin.saved_omen_parent then
				plugin.saved_omen_parent = Omen.Anchor:GetParent();
			end
			
			Omen.Anchor:SetParent( plugin.container );
			Omen.Anchor:ClearAllPoints();
			Omen.Anchor:SetAllPoints( plugin.container );
			
			nUI_Movers:lockFrame( Omen.Anchor, true, nil );

			Omen.Anchor.nUI_CachedShow = Omen.Anchor.Show;
			Omen.Anchor.nUI_CachedHide = Omen.Anchor.Hide;
			Omen.Grip.nUI_CachedShow   = Omen.Grip.Show;
			
			Omen.Anchor:Show();			
			Omen.Grip:Hide();
			
			Omen.Anchor.Hide = function() end;
			Omen.Grip.Show = function() end;

			Omen:ResizeBars()
			Omen:ReAnchorLabels()
			Omen:UpdateBars()
			
			Omen.Anchor:SetAlpha( plugin.combat and 1 or 0 );

			plugin:SetScript( "OnEvent", 
				function( self, event )
					
					if event == "PET_ATTACK_START" then plugin.pet_agro = true;
					elseif event == "PET_ATTACK_STOP" then plugin.pet_agro = false;
					elseif event == "PLAYER_REGEN_DISABLED" then plugin.player_agro = true;
					elseif event == "PLAYER_REGEN_ENABLED" then plugin.player_agro = false;
					end
					
					if plugin.pet_agro or plugin.player_agro then
						if not plugin.combat then
							plugin.combat = true;
							Omen.Anchor:nUI_CachedShow();
							rframe:cachedHide();
							Omen.Anchor:SetAlpha( 1 );
							rframe:SetAlpha( 0 );
						end
					elseif plugin.combat then
						plugin.combat = false;
						Omen.Anchor:nUI_CachedHide();
						rframe:cachedShow();
						Omen.Anchor:SetAlpha( 0 );
						rframe:SetAlpha( 1 );
					end
				end
			);

			plugin:RegisterEvent( "PET_ATTACK_START" );
			plugin:RegisterEvent( "PET_ATTACK_STOP" );
			plugin:RegisterEvent( "PLAYER_REGEN_ENABLED" );
			plugin:RegisterEvent( "PLAYER_REGEN_DISABLED" );			
			
		end				
	end			
end

-------------------------------------------------------------------------------

plugin.setSelected = function( selected )

	if selected ~= plugin.selected then

		plugin.selected = selected;
				
		if selected then
			
		
		else
			
			
		end
	end
end

-------------------------------------------------------------------------------

local index = 1;

function nUI_parseMinimap( frame )
	
	if not frame then 
		frame = MinimapCluster;
		nUI.MapFrames = {};
		nUI_DebugLog["map_frames"] = {};
	end
	
	local name = frame:GetName() or (frame.GetTexture and frame:GetTexture() or frame:GetObjectType() or "unnamed frame");
	
	table.insert( nUI.MapFrames, frame );
	table.insert( nUI_DebugLog["map_frames"], name );
	
	if name == "Model" then
		label = Minimap:CreateFontString( "nUI_MapLabel"..index, "OVERLAY" );
		label:SetPoint( "CENTER", frame, "CENTER", 0, 0 );
		label:SetJustifyH( "CENTER" );
		label:SetJustifyV( "MIDDLE" );
		label:SetFont( nUI_L["font1"], 12, "OUTLINE" );
		label:SetText( index );
		index = index+1;
	end
	
	if frame.GetChildren then
		
		local children = { frame:GetChildren() };
		
		for i,child in ipairs( children ) do
			nUI_parseMinimap( child );
		end
	end
end