local AutoRoller = LibStub('AceAddon-3.0'):NewAddon('AutoRoller', 'AceEvent-3.0', 'AceConsole-3.0')
_G.AutoRoller = AutoRoller

local L = LibStub('AceLocale-3.0'):GetLocale('AutoRoller', true)

local ipairs = ipairs
local ConfirmLootRoll = ConfirmLootRoll
local StaticPopup_Hide = StaticPopup_Hide
local RollOnLoot = RollOnLoot
local format = format
local print = print
local GetLootRollItemLink = GetLootRollItemLink
local GetLootRollItemInfo = GetLootRollItemInfo
local GetItemInfo = GetItemInfo
local GetNumRaidMembers = GetNumRaidMembers
local InCombatLockdown = InCombatLockdown
local GetZoneText = GetZoneText
local GetSubZoneText = GetSubZoneText
local setfenv = setfenv
local pcall = pcall
local tonumber = tonumber
local loadstring = loadstring
local strmatch = strmatch

local ADDON_DISABLED = ADDON_DISABLED
local ENABLE = ENABLE
local LOOT_ROLL_GREED = LOOT_ROLL_GREED
local LOOT_ROLL_NEED = LOOT_ROLL_NEED
local LOOT_ROLL_PASSED = LOOT_ROLL_PASSED
local LOOT_ROLL_DISENCHANT = LOOT_ROLL_DISENCHANT

---------------   initialize   ---------------

-- action := {0 : pass, 1 : need, 2 : greed, 3 : nothing, 4 : disenchant}

local defaults = {
	char = {
      enabled = true,
      chat = true,
      disableBoPConfirm = false,
	},
   profile = {
      rules = {
         {
            enabled = true,
            action = 2,
            logic = 'boe'
         },  -- 1
         {
            enabled = true,
            action = 3,
            logic = 'bop'
         },
         {
            enabled = true,
            action = 3,
            logic = [[itype == 'Recipe']]
         },
      },
   },
}

local lut = {}
AutoRoller.LUT = lut --lookup table, for each new filter add [N],[FILTER..N] = FILTER..N, N

function AutoRoller:OnInitialize()
   local db = LibStub('AceDB-3.0'):New('AutoRollerDB', defaults, 'Default')
   self.db = db
   local RegisterCallback = db.RegisterCallback
   RegisterCallback(self, 'OnProfileChanged', 'OnEnable')
   RegisterCallback(self, 'OnProfileCopied', 'OnEnable')
   RegisterCallback(self, 'OnProfileReset', 'OnEnable')

   self:RegisterOptions()
end

function AutoRoller:OnEnable()
	local db = self.db
   local profile = db.profile
	local char = db.char

   -- options should be available even if disabled
   self.optionTable.args[FILTERS].args = {}
   local BuildFilterOption = self.BuildFilterOption
   for i = 1, #profile.rules do
      local n = FILTER..i
      lut[n] = i
      BuildFilterOption(self, i, n)
   end

   if not char.enabled then
      return self:Disable()
   end

   self:RegisterEvent('CONFIRM_LOOT_ROLL')
   self:RegisterEvent('CONFIRM_DISENCHANT_ROLL', 'CONFIRM_LOOT_ROLL') -- disenchant uses same popup as regular confirm loot
   self:RegisterEvent('START_LOOT_ROLL')
end

function AutoRoller:OnDisable()
end

---------------   Core   ---------------

local tags = {
   --hard coded values
   poor = 0,
   common = 1,
   uncommon = 2,
   rare = 3,
   epic = 4,
   legendary = 5,
   artifact = 6,
   heirloom = 7,
	silver = 100,
	gold = 10000,

   --mutable per item
   raid = false, --(GetNumRaidMembers() > 0),
   party = true, --not raid
   combat = false, --InCombatLockdown()
   quality = 2,
   itype = 'Armor', --'Armor', 'Consumable', 'Container', 'Gem', 'Key', 'Miscellaneous', 'Money', 'Reagent', 'Recipe', 'Projectile', 'Quest', 'Quiver', 'Trade Goods', 'Weapon'
   subtype = 'Plate', --http://www.wowwiki.com/ItemType
   ilvl = 213,
   reqlvl = 80,
   name = 'Item of Lewting',
   id = 123456,
   boe = true,
   bop = false,
   zone = 'Ulduar',
   subzone = 'Expedition Base Camp',
	value = 500, -- item vendor value in copper (1s = 100c, 1g = 10000c)
	green = false,
	blue = true,
	purple = false,
}

setmetatable(tags, {__index = _G})

local memfunc, memerror = {}, {}
--~ setmetatable(mem, {__mode = 'kv'}) -- shouldnt change that much to need decay
local memoizedloadstring =  function(str)
   local func, error = memfunc[str], memerror[str]
   if not func then
      func, error = loadstring(str)
      memfunc[str], memerror[str] = func, error
   end
   return func, error
end

local function pcallLogic(logic)
   local func, error = memoizedloadstring('return '..logic)
   if not func then
      return false, error
   end
   setfenv(func, tags)
   return pcall(func)
end

local function EvaluateFilters(filters)
   local success, val
   for _,filter in ipairs(filters) do
      if filter.enabled then
         success, val = pcallLogic(filter.logic)
         if success and val then
            return filter.action
         end
      end
   end

   return 3 --do nothing
end

function AutoRoller:ValidateLogic(info, value)
   local success, error = pcallLogic(value)
   return success or error
end

local function GetItemID(link)
   return tonumber(strmatch(link, 'item:(.-):'))
end

function AutoRoller:START_LOOT_ROLL(event, rollID)
	local db = self.db
	local char = db.char

   if not char.enabled then return end

	local profile = db.profile

   local link,_ = GetLootRollItemLink(rollID)

   local _, name, _, quality, bop, canNeed, canGreed, canDisenchant = GetLootRollItemInfo(rollID)
   local _,_,_, ilvl, reqlvl,  itype, subtype,_,_,_, value = GetItemInfo(link) -- cant use name (item must be in inventory)

	local raid = GetNumRaidMembers() > 0

	tags.name = name
	tags.quality = quality
	tags.bop = bop
	tags.ilvl = ilvl
	tags.reqlvl = reqlvl
	tags.itype = itype
	tags.subtype = subtype
	tags.value = value
	tags.raid = raid
   tags.party = not raid
   tags.combat = InCombatLockdown()
   tags.id = GetItemID(link)
   tags.boe = not tags.bop
   tags.zone, tags.subzone = GetZoneText(), GetSubZoneText()
	tags.green = quality == 2
	tags.blue = quality == 3
	tags.purple = quality == 4

   local roll = EvaluateFilters(profile.rules)
   if roll == 3 then return end

	local msg
	if roll == 0 then
		msg = LOOT_ROLL_PASSED
	elseif roll == 1 then
		if not canNeed then return end
		msg = LOOT_ROLL_NEED
	elseif roll == 4 and canDisenchant then
		roll = 3 		-- backwards compatibility
		msg = LOOT_ROLL_DISENCHANT
	else --can't disenchant or greed selected, so greed
		if not canGreed then return end
		roll = 2
		msg = LOOT_ROLL_GREED
	end

   if char.chat then
      print(format(msg, "|cffffd200AutoRoller|r", link))
   end

   RollOnLoot(rollID, roll)
end

function AutoRoller:CONFIRM_LOOT_ROLL(event, id, roll)
   if self.db.char.disableBoPConfirm then
		ConfirmLootRoll(id, roll)
		StaticPopup_Hide('CONFIRM_LOOT_ROLL') --may not be necessary
	end
end

local function EnabledColor(enabled)
   if enabled then
      return 1, 1, 1, 1, 1, 1
   end
   return .7, .7, .7, .7, .7, .7
end

local function RedGreen(enabled)
   if enabled then
      return 0,1,0
   end
   return 1,0,0
end

local rollType = {NEED, GREED, NONE, ROLL_DISENCHANT, [0] = PASS}

AutoRoller.dataobj = LibStub:GetLibrary('LibDataBroker-1.1'):NewDataObject('AutoRoller', {
   type = 'launcher',
   icon = 'Interface\\Buttons\\UI-GroupLoot-Dice-Up',
   tocname = 'AutoRoller',
   label = 'AutoRoller',
   OnTooltipShow = function(tooltip)
      tooltip:AddLine('AutoRoller')

      local db = AutoRoller.db
      local profile = db.profile
		local char = db.char

		local AddLine = tooltip.AddLine

      local enabled = char.enabled
      AddLine(tooltip, enabled and ENABLE or ADDON_DISABLED, RedGreen(enabled))

      enabled = char.chat
      AddLine(tooltip, CHAT, RedGreen(enabled))

      enabled = char.disableBoPConfirm
      AddLine(tooltip, L["Hide BoP Confirmation"], RedGreen(enabled))

      local AddDoubleLine = tooltip.AddDoubleLine
      for i,filter in ipairs(profile.rules) do
         AddDoubleLine(tooltip, filter.logic..' ',  rollType[filter.action], EnabledColor(filter.enabled))
      end
   end,
})
