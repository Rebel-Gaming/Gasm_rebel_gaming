local L = LibStub("AceLocale-3.0"):NewLocale("AutoRoller", "enUS", true)

if not L then return end

L["Automatically roll on items."] = true
L["Output to chat when automatically rolling on an item."] = true
L["Hide BoP Confirmation"] = true
L["Hide the confirmation dialog that appears every time you roll on a bind on pickup item."] = true
L["Action"] = true
L["Logic"] = true
L["TagHelp"] = [[
Each filter's logic can be any statement that evaluates to true or false.
There are several |cffEF9C00tags|r available to ease use.

The following values are constant, and used for the quality tag:

|cffEF9C00poor|r = |cff00FFFF0|r
|cffEF9C00common|r = |cff00FFFF1|r
|cffEF9C00uncommon|r = |cff00FFFF2|r
|cffEF9C00rare|r = |cff00FFFF3|r
|cffEF9C00epic|r = |cff00FFFF4|r
|cffEF9C00legendary|r = |cff00FFFF5|r
|cffEF9C00artifact|r = |cff00FFFF6|r
|cffEF9C00heirloom|r = |cff00FFFF7|r

The following will change depending on the item being rolled on:

|cffEF9C00raid|r = |cffFF7FFFtrue|r if you are in a raid
|cffEF9C00party|r = |cffFF7FFFfalse|r if you are in a raid
|cffEF9C00combat|r = |cffFF7FFFtrue|r if you are in combat
|cffEF9C00quality|r = |cff00FFFF0|r to |cff00FFFF7|r or use the tags above
|cffEF9C00itype|r = |cff00FFFFArmor|r, |cff00FFFFConsumable, |cff00FFFFWeapon, ...  Case sensitive
|cffEF9C00subtype|r = see http://www.wowwiki.com/ItemType
|cffEF9C00ilvl|r = item level, |cff00FFFF226|r from ulduar
|cffEF9C00reqlvl|r = required level to wear item
|cffEF9C00name|r = name of item, case sensitive
|cffEF9C00id|r = itemID
|cffEF9C00boe|r = |cffFF7FFFtrue|r if item is bind on equip
|cffEF9C00bop|r = |cffFF7FFFtrue|r if item is bind on pickup


All of the preceding tags must be lower case, and can be combined with '|cffFF7FFFand|r', '|cffFF7FFFor|r', and '|cffFF7FFFnot|r' along with parenthesis.  Following are some examples:

Roll if the item is bind on equip and a green (uncommon) or blue (rare):

|cffEF9C00boe|r |cffFF7FFFand|r (|cffEF9C00quality|r == |cffEF9C00uncommon|r |cffFF7FFFor|r |cffEF9C00quality|r == |cffEF9C00rare|r)


If in a raid and in combat, for epic BoP items:

|cffEF9C00raid|r |cffFF7FFFand|r |cffEF9C00combat|r |cffFF7FFFand|r |cffEF9C00bop|r |cffFF7FFFand|r (|cffEF9C00quality|r == |cffEF9C00epic|r)


If your character's name is Jimbo, ilvl is 226 or above, and it is not armor:

UnitName(|cff00FFFF'player'|r) == |cff00FFFF"Jimbo"|r |cffFF7FFFand|r |cffEF9C00ilvl|r >= |cff00FFFF226|r |cffFF7FFFand|r |cffFF7FFFnot|r (|cffEF9C00itype|r == |cff00FFFF"Armor"|r)


]]
