local L = LibStub('AceLocale-3.0'):NewLocale('AutoRoller', 'zhCN', true)
if not L then return end

L["Automatically roll on items."] = "物品自动投点。"
-- L["bettergs"] = ""
-- L["betterilvl"] = ""
-- L["blue"] = ""
-- L["boe"] = ""
-- L["bop"] = ""
-- L["combat"] = ""
-- L["constant description"] = ""
-- L["disenchant"] = ""
-- L["example-description"] = ""
-- L["gearscore"] = ""
-- L["greed"] = ""
-- L["green"] = ""
L["Hide BoP Confirmation"] = "隐藏拾取绑定确认"
L["Hide the confirmation dialog that appears every time you roll on a bind on pickup item."] = "当每次投点拾取绑定的物品时隐藏确认窗口。"
-- L["id"] = ""
-- L["ilvl"] = ""
-- L["itype"] = ""
-- L["name"] = ""
-- L["need"] = ""
-- L["optional description"] = ""
L["Output to chat when automatically rolling on an item."] = "自动输出物品投点信息到聊天窗口。"
-- L["party"] = ""
-- L["purple"] = ""
-- L["quality"] = ""
-- L["raid"] = ""
-- L["reqlvl"] = ""
-- L["subtype"] = ""
-- L["subzone"] = ""
-- L["tag description"] = ""
L["TagHelp"] = [=[
每个过滤的逻辑可以是任何声明的值为 true 或 false。
这里提用一些|cffEF9C00标签|r可供方便使用。

下面的值为常数，对品质标签使用：

|cffEF9C00|r = |cff00FFFF0|r 普通
|cffEF9C00common|r = |cff00FFFF1|r 一般
|cffEF9C00uncommon|r = |cff00FFFF2|r 优良
|cffEF9C00rare|r = |cff00FFFF3|r 稀有
|cffEF9C00epic|r = |cff00FFFF4|r 史诗
|cffEF9C00legendary|r = |cff00FFFF5|r 传说
|cffEF9C00artifact|r = |cff00FFFF6|r 创造物
|cffEF9C00heirloom|r = |cff00FFFF7|r 传家宝

下面将改变根据物品投点

|cffEF9C00raid|r = |cffFF7FFFtrue|r 如在团队
|cffEF9C00party|r = |cffFF7FFFfalse|r 如在团队
|cffEF9C00combat|r = |cffFF7FFFtrue|r 如在战斗
|cffEF9C00quality|r = |cff00FFFF0|r 到 |cff00FFFF7|r 或使用上面标签
|cffEF9C00itype|r = |cff00FFFFArmor|r, |cff00FFFFConsumable, |cff00FFFFWeapon, ...  区分大小写
|cffEF9C00subtype|r = 从 http://www.wowwiki.com/ItemType 查找
|cffEF9C00ilvl|r = 物品等级, |cff00FFFF226|r从奥杜尔获得
|cffEF9C00reqlvl|r = 需要装备等级
|cffEF9C00name|r = 物品名称，区分大小写
|cffEF9C00id|r = 物品 ID
|cffEF9C00boe|r = |cffFF7FFFtrue|r装备绑定
|cffEF9C00bop|r = |cffFF7FFFtrue|r拾取绑定

前面的标签都必须小写，并可与'|cffFF7FFFand|r', '|cffFF7FFFor|r', and '|cffFF7FFFnot|r' 括号内相结合。这里有一些举例：

假如投点物品为装备绑定或绿色品质（优良）或蓝色（稀有）：

|cffEF9C00boe|r |cffFF7FFFand|r (|cffEF9C00quality|r == |cffEF9C00uncommon|r |cffFF7FFFor|r |cffEF9C00quality|r == |cffEF9C00rare|r)


假如在团队或战斗中投点拾取绑定物品：

|cffEF9C00raid|r |cffFF7FFFand|r |cffEF9C00combat|r |cffFF7FFFand|r |cffEF9C00bop|r |cffFF7FFFand|r (|cffEF9C00quality|r == |cffEF9C00epic|r)


加入你的角色名称为 Adavak，投点物品等级为226或更高，并且不是护甲：

UnitName(|cff00FFFF'player'|r) == |cff00FFFF"Jimbo"|r |cffFF7FFFand|r |cffEF9C00ilvl|r >= |cff00FFFF226|r |cffFF7FFFand|r |cffFF7FFFnot|r (|cffEF9C00itype|r == |cff00FFFF"Armor"|r)

]=]
-- L["value"] = ""
-- L["variable description"] = ""
-- L["zone"] = ""

