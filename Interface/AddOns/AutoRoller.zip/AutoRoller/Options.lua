local AutoRoller = AutoRoller
local L = LibStub('AceLocale-3.0'):GetLocale('AutoRoller', true)

local rollType = {NEED, GREED, NONE, ROLL_DISENCHANT, [0] = PASS}

--~ local function GetProfileValue(info)
--~    return info.handler.db.profile[info.arg]
--~ end

--~ local function SetProfileValue(info, value)
--~    info.handler.db.profile[info.arg] = value
--~ end

local function GetCharValue(info)
   return info.handler.db.char[info.arg]
end

local function SetCharValue(info, value)
   info.handler.db.char[info.arg] = value
end

local function FilterGet(info)
   local n = #info
   local self = info.handler
   return self.db.profile.rules[self.LUT[info[n-1]]][info[n]]
end

local function FilterSet(info, value)
   local n = #info
   local self = info.handler
   self.db.profile.rules[self.LUT[info[n-1]]][info[n]] = value
end

local function DeleteFilter(info)
   local self = info.handler
   local filters = self.db.profile.rules

   self.optionTable.args[FILTERS].args[FILTER..#filters] = nil --remove last filter (order of options doesnt matter, just count)

   tremove(filters, self.LUT[info[#info-1]])
end

local function MoveFilterUp(info)
   --only have to swap filters in db, optionsTable will automatically adjust
   local self = info.handler
   local n = self.LUT[info[#info-1]]

   if n == 1 then return end

   local filters = self.db.profile.rules

   filters[n],filters[n-1] = filters[n-1],filters[n]
end

-- insert a new filter in database at 1, and option at n (order of options doesnt matter, just count)
local function NewFilter(info)
   local self = info.handler
   local filters = self.db.profile.rules

   local i = #filters+1
   local n = FILTER..i

   self.LUT[n] = i

   tinsert(filters, 1, {
      enabled = false,
      action = 3,
      logic = "",
   })

   self:BuildFilterOption(i, n)
end

local function SetEnabled(info, v)
   local self = info.handler
   self.db.char.enabled = v
   if v then
      self:Enable()
   else
      self:Disable()
   end
end

AutoRoller.optionTable = {
   name = 'AutoRoller',
   desc = L["Automatically roll on items."],
   type = 'group',
   handler = AutoRoller,
   get = GetCharValue,
   set = SetCharValue,
   args = {
      desc = {
         name = L["Automatically roll on items."],
         type = 'description',
         order = 100,
         width = 'full',
      },
      [ENABLE] = {
         name = ENABLE,
         type = 'toggle',
         order = 200,
         get = 'IsEnabled',
         width = 'full',
         set = SetEnabled,
      },
      [CHAT] = {
         name = CHAT_OPTIONS_LABEL,
         desc = L["Output to chat when automatically rolling on an item."],
         type = 'toggle',
         order = 300,
         width = 'full',
         arg = 'chat',
      },
      disableBoPConfirm = {
         name = L["Hide BoP Confirmation"],
         desc = L["Hide the confirmation dialog that appears every time you roll on a bind on pickup item."],
         type = 'toggle',
         order = 350,
         width = 'full',
         arg = 'disableBoPConfirm',
      },
      [ADD] = {
         name = ADD_FILTER,
         type = 'execute',
         order = 400,
         func = NewFilter,
      },
      [FILTERS] = {
         name = FILTERS,
         type = 'group',
         inline = true,
         order = 500,
         set = FilterSet,
         get = FilterGet,
         --args = { --filters go here },
      },
      [HELP_LABEL] = {
         name = L["TagHelp"],
         type = 'description',
         order = 600,
         width = 'full',
      }
   }
}

local filterArgs = {
   enabled = {
      name = ENABLE,
      type = 'toggle',
      order = 100,
      width = 'half',
   },
   action = {
      name = L["Action"],
      type = 'select',
      values = rollType,
      order = 101,
   },
   delete = {
      name = DELETE,
      type = 'execute',
      order = 201,
      width = 'half',
      confirm = true,
      func = DeleteFilter,
      confirmText = CONFIRM_COMBAT_FILTER_DELETE,
   },
   moveup = {
      name = MOVE_FILTER_UP,
      type = 'execute',
      order = 202,
      func = MoveFilterUp,
   },
   logic = {
      name = L["Logic"],
      type = 'input',
      order = 300,
      width = 'full',
      validate = 'ValidateLogic',
   },
}

function AutoRoller:BuildFilterOption(i, n)
   self.optionTable.args[FILTERS].args[n] = {
      type = 'group',
      name = n,
      order = i,
      args = filterArgs,
   }
end

function AutoRoller:RegisterOptions()
   local options = self.optionTable
   local profile = LibStub('AceDBOptions-3.0'):GetOptionsTable(self.db)

   local registry = LibStub('AceConfigRegistry-3.0')
   local dialog = LibStub('AceConfigDialog-3.0')
   LibStub('AceConfig-3.0'):RegisterOptionsTable('AutoRoller', options, 'autoroller')

   registry:RegisterOptionsTable('AutoRoller Options', options)
   registry:RegisterOptionsTable('AutoRoller Profiles', profile)

   local main = dialog:AddToBlizOptions('AutoRoller Options', 'AutoRoller')
   dialog:AddToBlizOptions('AutoRoller Profiles', 'Profiles', 'AutoRoller')

   if self.dataobj then
      self.dataobj.OnClick = function() InterfaceOptionsFrame_OpenToCategory(main) end
   end
end
