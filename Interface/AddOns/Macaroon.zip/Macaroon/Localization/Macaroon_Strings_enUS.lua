﻿-- Default strings by me!

MacaroonLocale = {}; MacaroonLocale.Macaroon = {}; MacaroonLocale.Current = "enUS"

local function load_localization()

MACAROON_STRINGS = {

	TITLE = "Macaroon!",
	DESC = "An unlimted number of highly configurable macro bars and buttons",

	SLASH1 = "/macaroon",
	SLASH2 = "/mac",

	SLASH_COMMAND_1 = "menu",
	SLASH_COMMAND_1_DESC = "Open the main menu",
	SLASH_COMMAND_1_FUNC = "OpenMainMenu", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_2 = "create",
	SLASH_COMMAND_2_DESC = "Create a blank bar",
	SLASH_COMMAND_2_FUNC = "CreateNewBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_3 = "delete",
	SLASH_COMMAND_3_DESC = "Delete the currently selected bar",
	SLASH_COMMAND_3_FUNC = "DeleteBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_4 = "config",
	SLASH_COMMAND_4_DESC = "Toggle configuration mode for all bars",
	SLASH_COMMAND_4_FUNC = "ConfigBars", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_5 = "add",
	SLASH_COMMAND_5_DESC = "Adds buttons to the currently selected bar (add or add #)",
	SLASH_COMMAND_5_FUNC = "AddButton", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_6 = "remove",
	SLASH_COMMAND_6_DESC = "Removes buttons from the currently selected bar (remove or remove #)",
	SLASH_COMMAND_6_FUNC = "RemoveButton", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_7 = "edit",
	SLASH_COMMAND_7_DESC = "Toggle edit mode for all buttons",
	SLASH_COMMAND_7_FUNC = "ButtonEdit", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_8 = "bind",
	SLASH_COMMAND_8_DESC = "Toggle binding mode for all buttons",
	SLASH_COMMAND_8_FUNC = "ButtonBind", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_9 = "scale",
	SLASH_COMMAND_9_DESC = "Scale a bar to the desired size",
	SLASH_COMMAND_9_FUNC = "ScaleBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_10 = "snapto",
	SLASH_COMMAND_10_DESC = "Toggle SnapTo for current bar",
	SLASH_COMMAND_10_FUNC = "SnapToBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_11 = "autohide",
	SLASH_COMMAND_11_DESC = "Toggle AutoHide for current bar",
	SLASH_COMMAND_11_FUNC = "AutohideBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_12 = "hidden",
	SLASH_COMMAND_12_DESC = "Toggle if bar is shown or hidden",
	SLASH_COMMAND_12_FUNC = "HideBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_13 = "shape",
	SLASH_COMMAND_13_DESC = "Change current bar's shape",
	SLASH_COMMAND_13_FUNC = "ShapeBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_14 = "name",
	SLASH_COMMAND_14_DESC = "Change current bar's name",
	SLASH_COMMAND_14_FUNC = "NameBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_15 = "strata",
	SLASH_COMMAND_15_DESC = "Change current bar's frame strata",
	SLASH_COMMAND_15_FUNC = "StrataSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_16 = "alpha",
	SLASH_COMMAND_16_DESC = "Change current bar's alpha (transparency)",
	SLASH_COMMAND_16_FUNC = "AlphaSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_17 = "alphaup",
	SLASH_COMMAND_17_DESC = "Set current bar's conditions to 'alpha up'",
	SLASH_COMMAND_17_FUNC = "AlphaUpSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_18 = "arcstart",
	SLASH_COMMAND_18_DESC = "Set current bar's starting arc location (in degrees)",
	SLASH_COMMAND_18_FUNC = "ArcStartSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_19 = "arclen",
	SLASH_COMMAND_19_DESC = "Set current bar's arc length (in degrees)",
	SLASH_COMMAND_19_FUNC = "ArcLengthSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_20 = "columns",
	SLASH_COMMAND_20_DESC = "Set the number of columns for the current bar (for shape Multi-Column)",
	SLASH_COMMAND_20_FUNC = "ColumnsSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_21 = "padh",
	SLASH_COMMAND_21_DESC = "Set current bar's horizontal padding",
	SLASH_COMMAND_21_FUNC = "PadHSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_22 = "padv",
	SLASH_COMMAND_22_DESC = "Set current bar's vertical padding",
	SLASH_COMMAND_22_FUNC = "PadVSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_23 = "padhv",
	SLASH_COMMAND_23_DESC = "Adjust both horizontal and vertical padding of the current bar incrementally",
	SLASH_COMMAND_23_FUNC = "PadHVSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_24 = "showgrid",
	SLASH_COMMAND_24_DESC = "Toggle the current bar's showgrid flag",
	SLASH_COMMAND_24_FUNC = "ShowgridSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_25 = "x",
	SLASH_COMMAND_25_DESC = "Change current bar's horizontal axis position",
	SLASH_COMMAND_25_FUNC = "XAxisSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_26 = "y",
	SLASH_COMMAND_26_DESC = "Change current bar's vertical axis position",
	SLASH_COMMAND_26_FUNC = "YAxisSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_27 = "state",
	SLASH_COMMAND_27_DESC = "Toggle states for the current bar (/mac state <state>). Type /mac statelist for vaild states",
	SLASH_COMMAND_27_FUNC = "SetBarStates",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_28 = "statelist",
	SLASH_COMMAND_28_DESC = "Print a list of valid states",
	SLASH_COMMAND_28_FUNC = "PrintStateList",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_29 = "lock",
	SLASH_COMMAND_29_DESC = "Toggle button lock",
	SLASH_COMMAND_29_FUNC = "ButtonLock",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_30 = "load",
	SLASH_COMMAND_30_DESC = "Load a profile",
	SLASH_COMMAND_30_FUNC = "LoadFromProfile",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_31 = "storage",
	SLASH_COMMAND_31_DESC = "Open the button storage area",
	SLASH_COMMAND_31_FUNC = "OpenStorage", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_32 = "profiles",
	SLASH_COMMAND_32_DESC = "Open Profile Options",
	SLASH_COMMAND_32_FUNC = "OpenProfiles", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_33 = "timerlimit",
	SLASH_COMMAND_33_DESC = "Sets the minimum time in seconds to show on text timers",
	SLASH_COMMAND_33_FUNC = "SetTimerLimit", -- function call, do not tranlsate, leave in English

	SLASH_HINT1 = "\n/macaroon or /mac |cff00ff00<command>|r",
	SLASH_HINT2 = "\nCommand List -\n",

	BAR_SNAPTO_DISABLED = "SnapTo disabled for ",
	BAR_SNAPTO_ENABLED = "SnapTo enabled for ",
	BAR_SHOWGRID_DISABLED = "ShowGrid disabled for ",
	BAR_SHOWGRID_ENABLED = "ShowGrid enabled for ",
	BAR_HIDDEN_DISABLED	= "Current bar will be shown",
	BAR_HIDDEN_ENABLED	= "Current bar will be hidden",
	BAR_DUALSPEC_DISABLED = "DualSpec disabled for ",
	BAR_DUALSPEC_ENABLED = "DualSpec enabled for ",
	BAR_SHAPES = "\n1=Horizontal\n2=Vertical\n3=Multi-Column\n4=Circle\n5=Circle+One",
	BAR_STRATAS = "\n1=BACKGROUND\n2=LOW\n3=MEDIUM\n4=HIGH\n5=DIALOG",
	BAR_ALPHA = "Alpha value must be between zero(0) and one(1)",
	BAR_ARCSTART = "Arc start must be bewtween 0 and 359",
	BAR_ARCLENGTH = "Arc length must be bewtween 0 and 359",
	BAR_COLUMNS = "Enter a number of desired columns for the bar higher than zero(0)",
	BAR_PADH = "Enter a valid number for desired horizontal button padding",
	BAR_PADV = "Enter a valid number for desired vertical button padding",
	BAR_PADHV = "Enter a valid number to increase/decrease both the horizontal and vertical button padding",

	INVALID_CHOICE = "That is not a valid choice",
	INVALID_STATE = "That is not a valid bar state",
	NO_BAR_SELECTED = "No bar is selected",

	OPT1 = "Opt1:",
	VALUE = "Value:",
	APPLY = "Apply",
	COPY = "Copy",
	DONE = "Dismiss",
	DELETE = "Delete",
	CHARGES = "Charge",

	CREATE_BUTTON = "Create Button",
	DELETE_BUTTON = "Delete Button",
	STORED_BUTTONS = "Number of stored buttons:",
	OVERFLOW = "Storage Overflow:",
	LOCKROW = "Lock Row",

	MACRO_EDIT = "Macro Editor",
	MACRO_NAME = "-macro name-",
	MACRO_MASTER = "Macro Master",
	MACRO_EDITNOTE = "Click here to edit macro note",
	MACRO_ICON = "Click to change icon",
	MACRO_EXPAND = "Expand",
	ACTION_EDIT = "Action ID Editor",
	ACTION_PROP = "Propagate Action ID's on Bar  ",

	BUTTON_OPTIONS = "Button Options",

	CLICK_ANCHOR = "Click Anchor",
	MOUSE_ANCHOR = "Mouse Anchor",
	ANCHOR_DELAY = "Delay: ",

	BTNOPTION_EDIT_BUTTON_1 = "Scale",
	BTNOPTION_EDIT_BUTTON_2 = "X Offset",
	BTNOPTION_EDIT_BUTTON_3 = "Y Offset",

	BTNOPTION_EDIT_CHECK_1 = "Up Clicks",
	BTNOPTION_EDIT_CHECK_2 = "Down Clicks",
	BTNOPTION_EDIT_CHECK_3 = "Spell Counts",
	BTNOPTION_EDIT_CHECK_4 = "Combo Counts",

	BAR_EDIT_ADD = "Add",
	BAR_EDIT_REMOVE = "Remove",
	BAR_EDIT_BARLINK = "Bar Link",
	BAR_EDIT_NAME = "Bar Name",

	BAR_EDIT_BUTTON_1 = "Scale",
	BAR_EDIT_BUTTON_2 = "Shape",
	BAR_EDIT_BUTTON_3 = "Columns",
	BAR_EDIT_BUTTON_4 = "Strata",
	BAR_EDIT_BUTTON_5 = "Alpha",
	BAR_EDIT_BUTTON_6 = "AlphaUp",
	BAR_EDIT_BUTTON_7 = "Arc Start",
	BAR_EDIT_BUTTON_8 = "Arc Length",
	BAR_EDIT_BUTTON_9 = "Arc Preset",
	BAR_EDIT_BUTTON_10 = "Pad Horz",
	BAR_EDIT_BUTTON_11 = "Pad Vert",
	BAR_EDIT_BUTTON_12 = "Pad Horz+Vert",
	BAR_EDIT_BUTTON_13 = "Button Count",

	BAR_MESSAGE = "LClick/RClick/Mousewheel to adjust: |cffffffff",

	BAR_EDIT_BUTTON_TEXT_1 = "scale",
	BAR_EDIT_BUTTON_TEXT_2 = "shape",
	BAR_EDIT_BUTTON_TEXT_3 = "number of columns",
	BAR_EDIT_BUTTON_TEXT_4 = "frame strata",
	BAR_EDIT_BUTTON_TEXT_5 = "alpha (transparency)",
	BAR_EDIT_BUTTON_TEXT_6 = "condition to \'alpha-up\'",
	BAR_EDIT_BUTTON_TEXT_7 = "arc starting point",
	BAR_EDIT_BUTTON_TEXT_8 = "arc length",
	BAR_EDIT_BUTTON_TEXT_9 = "preset arc shape",
	BAR_EDIT_BUTTON_TEXT_10 = "horizontal padding",
	BAR_EDIT_BUTTON_TEXT_11 = "vertical padding",
	BAR_EDIT_BUTTON_TEXT_12 = "horizontal & vertical padding",
	BAR_EDIT_BUTTON_TEXT_13 = "button count",

	CHECK_101 = "Enable Blizzard Main Bar",
	CHECK_102 = "Enable Button Tooltips",
	CHECK_103 = "Hide Tooltips in Combat",
	CHECK_104 = "Enable Key Bind Text",
	CHECK_105 = "Enable Macro Text",
	CHECK_106 = "Enable Count Text",
	CHECK_107 = "Enable Right-Drag btn copy",
	CHECK_108 = "Allow Macaroon to adj. bags",
	CHECK_109 = "Enable Button Lock",
	CHECK_110 = "Enable Shift-Drag",
	CHECK_111 = "Enable Control-Drag",
	CHECK_112 = "Enable Alt-Drag",
	CHECK_113 = "Text Cooldown Timers",
	CHECK_114 = "Text Buff/Debuff Timers",
	CHECK_115 = "Buff/Debuff Highlighting",
	CHECK_116 = "Enable Button Down Clicks",
	CHECK_117 = "Enable Blizzard Vehicle Bar",

	SLIDER_1 = "Bag X Offset",
	SLIDER_2 = "Bag Y Offset",
	SLIDER_3 = "Bag Scale",
	SLIDER_4 = "Ideal Free Bag Space",
	SLIDER_5 = "Cooldown Alpha",
	SLIDER_6 = "Pet Autocast Alpha",
	SLIDER_7 = "Alpha-Up Fade Speed",
	SLIDER_8 = "SnapTo Tolerance",

	FLOAT_EDITORS = "Floating Editors",
	ANIMATED = "Animated Menus",
	DUALSPEC = "Enable Dual Spec",
	BEGINNER = "Beginner Tooltips",

	CHECK_MACRO = "Use note \nas tooltip ",

	EMPTY_BUTTON = "Empty Button",

        MINIMAP_CHECK = "Minimap Button",
	MINIMAP_TOOLTIP0 = "Macaroon\n",
	MINIMAP_TOOLTIP1 = "|cffffffffRight-Click|r for mini-menu\n\n|cffffffffLeft-Click|r to toggle bar editing\n|cffffffffShift-Click|r to toggle binding mode\n|cffffffffAlt-Click|r to toggle button editing\n|cffffffffCtrl-Click|r to open the main menu\n\n|cffffffff/mac|r for command line options",
	MINIMAP_TOOLTIP2 = "\nButton Lock: ",

	MINIMAP_ACTION_1 = "Button Lock",
	MINIMAP_ACTION_1_FUNC = "ButtonLock", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_2 = "Button Edit",
	MINIMAP_ACTION_2_FUNC = "ButtonEdit", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_3 = "Bar Edit",
	MINIMAP_ACTION_3_FUNC = "ConfigBars", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_4 = "Bind Edit",
	MINIMAP_ACTION_4_FUNC = "ButtonBind", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_5 = "Main Menu",
	MINIMAP_ACTION_5_FUNC = "OpenMainMenu", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_6 = "Create Bar",
	MINIMAP_ACTION_6_FUNC = "CreateNewBar", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_6_ARG = "bar", -- function args, do not tranlsate, leave in English
	MINIMAP_ACTION_7 = "Delete Bar",
	MINIMAP_ACTION_7_FUNC = "DeleteBar", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_8 = "» Close «",
	MINIMAP_ACTION_8_FUNC = "MinimapMenuClose", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_9 = "Storage",
	MINIMAP_ACTION_9_FUNC = "OpenStorage", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_10 = "Profiles",
	MINIMAP_ACTION_10_FUNC = "OpenProfiles", -- function call, do not tranlsate, leave in English

	BINDFRAME_BIND = "bind",
	BINDFRAME_LOCKED = "locked",
	BINDFRAME_PRIORITY = "priority",

	BINDINGS_LOCKED	= "This button's bindings are locked.\nLeft-Click button to unlock.",

	BARTOOLTIP_1 = "On",
	BARTOOLTIP_2 = "Off",
	BARTOOLTIP_3 = "Scale: ",
	BARTOOLTIP_4 = "Strata: ",
	BARTOOLTIP_5 = "Alpha: ",
	BARTOOLTIP_6 = "AlphaUp: ",
	BARTOOLTIP_7 = "Shape: ",
	BARTOOLTIP_8 = "Columns: ",
	BARTOOLTIP_9 = "ArcS: ",
	BARTOOLTIP_10 = "ArcL: ",
	BARTOOLTIP_11 = "PadH: ",
	BARTOOLTIP_12 = "PadV: ",
	BARTOOLTIP_13 = "SnapTo: ",
	BARTOOLTIP_14 = "ShowGrid: ",
	BARTOOLTIP_15 = "Autohide: ",
	BARTOOLTIP_16 = "Target: ",
	BARTOOLTIP_17 = "|cffffffffCurrent State: |r",
	BARTOOLTIP_18 = "|cffffffffActive States: |r",
	BARTOOLTIP_19 = "|cffffffffButtons: |r",
	BARTOOLTIP_20 = "Point: ",
	BARTOOLTIP_21 = "  x:",
	BARTOOLTIP_22 = "  y:",

	BARTOOLTIP_23 = "|cff00ff00Current Bar|r",

	BARTOOLTIP_24 = "\n|cffffffffLeft-Click|r to cycle through active states",
	BARTOOLTIP_25 = "\n|cffffffffLeft-Click|r to select Bar",

	BARTOOLTIP_26 = "|cffffffffRight-Click|r to toggle Bar Editor",
	BARTOOLTIP_27 = "|cffffffffMiddle-Click|r to toggle hidden state",
	BARTOOLTIP_275 = "|cffffffffShift-Click|r to adjust position using arrow keys",

	BARTOOLTIP_28 = "|cffffffffLeft-Click|r to increase current value",
	BARTOOLTIP_29 = "|cffffffffRight-Click|r to decrease current value",
	BARTOOLTIP_30 = "|cffffffffMousewheel|r to increase/decrease current value",
	BARTOOLTIP_31 = "\nTo leave value edit mode: |cffffffffMiddle-Click|r\n  or move |cffffffffmouse|r out of bar frame",

	KEYBIND_TOOLTIP1 = "\nHit a key to bind it to |cff00ff00%s ",
	KEYBIND_TOOLTIP2 = "Left-Click to lock this %s's bindings\nHit |cfff00000ESC|r to clear this %s's current binding(s)",
	KEYBIND_TOOLTIP3 = "|cffffffffCurrent Binding(s): |r|cff00ff00",
	KEYBIND_NONE = "none",

	BUTTONEDIT_TOOLTIP1 = "Left-Click to change button type\nRight-Click to Edit |cff00ff00Button ",
	BUTTONEDIT_TOOLTIP2 = " to cycle button types",

	BARSHAPE_1 = "Linear",
	BARSHAPE_2 = "Circle",
	BARSHAPE_3 = "Circle + One",

	BARSTATE_1 = "Paged Bar",
	BARSTATE_2 = "Stance",
	BARSTATE_3 = "Pet",
	BARSTATE_4 = "Control Bar",
	BARSTATE_5 = "Stealth",
	BARSTATE_6 = "Reaction",
	BARSTATE_7 = "Combat",
	BARSTATE_8 = "Group",
	BARSTATE_9 = "Alt Key",
	BARSTATE_10 = "Ctrl Key",
	BARSTATE_11 = "Shift Key",
	BARSTATE_12 = "Custom",

	BARSTATE_AH = "Autohide",
	BARSTATE_SG = "Showgrid",
	BARSTATE_ST = "SnapTo",
	BARSTATE_HD = "Hidden",
	BARSTATE_DS = "Dual Spec",

	TEXTEDIT_NAME = "Bar Name:",
        TEXTEDIT_TARGET = "Bar Target:",
        TEXTEDIT_LSTATE = "State:",
        TEXTEDIT_LTO = "Linked To:",
        TEXTEDIT_BSTATE = "Bar State:",
        TEXTEDIT_REMAP = "Remap To:",
        TEXTEDIT_CUSTOM = "Custom Visibility:",

	ALPHAUP_NONE = "none",
	ALPHAUP_BATTLE = "Battle",
	ALPHAUP_MOUSEOVER = "Mouseover",
	ALPHAUP_BATTLEMOUSE = "Battle+Mouseover",
	ALPHAUP_RETREAT = "Retreat",
	ALPHAUP_RETREATMOUSE = "Retreat+Mouseover",

	ARC_PRESET_1 = "Top Arc",
	ARC_PRESET_2 = "Bottom Arc",
	ARC_PRESET_3 = "Left Arc",
	ARC_PRESET_4 = "Right Arc",
	ARC_PRESET_5 = "Full Circle",

	STATES = {
		homestate = "Normal",
		laststate = "Should not see!",
		pagedbar1 = "Page 1",
		pagedbar2 = "Page 2",
		pagedbar3 = "Page 3",
		pagedbar4 = "Page 4",
		pagedbar5 = "Page 5",
		pagedbar6 = "Page 6",
		stance0 = "Stance 0",
		companion0 = "No Pet",
		companion1 = "Pet",
		stealth1 = "Stealth",
		reaction1 = "Hostile",
		combat1 = "Battle",
		group1 = "Group: Raid",
		group2 = "Group: Party",
		control1 = "Controls: Vehicle/Possess",
		possess1 = "Possession",
		vehicle1 = "Vehicle",
		alt1 = "Alt Down",
		ctrl1 = "Control Down",
		shift1 = "Shift Down",
		custom = "Custom States",
	},

	--class specific state names
	DRUID_STANCE0 = "Caster Form",
	DRUID_PROWL = "Prowl",
	PRIEST_HEALER = "Healer Form",
	ROGUE_ATTACK = "Attack",
	WARLOCK_CASTER = "Caster Form",

	PETATTACK = "Attack",
	PETFOLLOW = "Follow",
	PETSTAY = "Stay",
	PETAGGRESSIVE = "Aggressive",
	PETDEFENSIVE = "Defensive",
	PETPASSIVE = "Passive",

	CUSTOM_OPTION = "\n\nFor custom states, add a desired state string (/mac state custom <state string>) where <state string> is a semicolon seperated list of state conditions\n\n|cff00ff00Example:|r [actionbar:1];[stance:1];[stance3,stealth];[mounted]\n\n|cff00ff00Note:|r the first state listed will be considered the \"home state\". If the state manager ever gets confused, that is the state it will default to.",

}

-- Some languages Blizzard is now making a distinction on class names based on gender.
if (UnitSex("player") == 2) then

	MACAROON_STRINGS.DRUID = "Druid"
	MACAROON_STRINGS.WARRIOR = "Warrior"
	MACAROON_STRINGS.ROGUE = "Rogue"
	MACAROON_STRINGS.PRIEST = "Priest"
	MACAROON_STRINGS.HUNTER = "Hunter"
	MACAROON_STRINGS.PALADIN = "Paladin"
	MACAROON_STRINGS.SHAMAN = "Shaman"
	MACAROON_STRINGS.MAGE = "Mage"
	MACAROON_STRINGS.WARLOCK = "Warlock"
	MACAROON_STRINGS.DEATHKNIGHT = "Death Knight"

else

	MACAROON_STRINGS.DRUID = "Druid"
	MACAROON_STRINGS.WARRIOR = "Warrior"
	MACAROON_STRINGS.ROGUE = "Rogue"
	MACAROON_STRINGS.PRIEST = "Priest"
	MACAROON_STRINGS.HUNTER = "Hunter"
	MACAROON_STRINGS.PALADIN = "Paladin"
	MACAROON_STRINGS.SHAMAN = "Shaman"
	MACAROON_STRINGS.MAGE = "Mage"
	MACAROON_STRINGS.WARLOCK = "Warlock"
	MACAROON_STRINGS.DEATHKNIGHT = "Death Knight"

end

BINDING_HEADER_MACAROON_BARS = "Macaroon"

end

MacaroonLocale.Macaroon.enUS = load_localization

load_localization()