-- Korean localizations by DroArc(Kor Mediv Alliance)



local function load_localization()

MACAROON_STRINGS = {

	TITLE = "Macaroon!",
	DESC = "An unlimted number of highly configurable macro bars and buttons",

	SLASH1 = "/마카",
	SLASH2 = "/mac",

	SLASH_COMMAND_1 = "메뉴",
	SLASH_COMMAND_1_DESC = "메뉴를 호출합니다.",
	SLASH_COMMAND_1_FUNC = "OpenMainMenu", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_2 = "바추가",
	SLASH_COMMAND_2_DESC = "비어있는 바를 생성합니다.",
	SLASH_COMMAND_2_FUNC = "CreateBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_3 = "바삭제",
	SLASH_COMMAND_3_DESC = "현재 지정된 바를 삭제합니다.",
	SLASH_COMMAND_3_FUNC = "DeleteBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_4 = "바설정",
	SLASH_COMMAND_4_DESC = "모든 바에 대한 설정 모드를 토글합니다.",
	SLASH_COMMAND_4_FUNC = "ConfigBars", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_5 = "버튼추가",
	SLASH_COMMAND_5_DESC = "현재 지정된 바에 버튼을 추가합니다. (추가 또는 추가 #)",
	SLASH_COMMAND_5_FUNC = "AddButton", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_6 = "버튼삭제",
	SLASH_COMMAND_6_DESC = "현재 지정한 바에서 버튼을 제거합니다. (제거 또는 제거 #)",
	SLASH_COMMAND_6_FUNC = "RemoveButton", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_7 = "버튼설정",
	SLASH_COMMAND_7_DESC = "모든 버튼에 대해 수정모드를 토글합니다.",
	SLASH_COMMAND_7_FUNC = "ButtonEdit", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_8 = "단축키",
	SLASH_COMMAND_8_DESC = "모든 버튼에 대하여 단추키 모드를 토글합니다.",
	SLASH_COMMAND_8_FUNC = "ButtonBind", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_9 = "크기",
	SLASH_COMMAND_9_DESC = "바의 크기를 원하는 사이즈로 바꿉니다.",
	SLASH_COMMAND_9_FUNC = "ScaleBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_10 = "스냅",
	SLASH_COMMAND_10_DESC = "현재 지정한 바에 대한 스냅설정을 토글합니다.",
	SLASH_COMMAND_10_FUNC = "SnapToBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_11 = "자동숨김",
	SLASH_COMMAND_11_DESC = "현재 바에 대한 자동숨김을 설정합니다.",
	SLASH_COMMAND_11_FUNC = "AutohideBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_12 = "숨김",
	SLASH_COMMAND_12_DESC = "바에 대한 숨김 또는 보임 설정을 토글합니다.",
	SLASH_COMMAND_12_FUNC = "HideBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_13 = "형태",
	SLASH_COMMAND_13_DESC = "현재 지정된 바의 형태를 바꿉니다.",
	SLASH_COMMAND_13_FUNC = "ShapeBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_14 = "이름",
	SLASH_COMMAND_14_DESC = "현재 지정된 바의 이름을 바꿉니다.",
	SLASH_COMMAND_14_FUNC = "NameBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_15 = "깊이",
	SLASH_COMMAND_15_DESC = "현재 지정된 바의 프레임 깊이를 바꿉니다.",
	SLASH_COMMAND_15_FUNC = "StrataSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_16 = "투명도",
	SLASH_COMMAND_16_DESC = "현재 지정된 바의 알파(투명도)값을 바꿉니다.",
	SLASH_COMMAND_16_FUNC = "AlphaSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_17 = "투명해제조건",
	SLASH_COMMAND_17_DESC = "현재 바의 투명화 상태에 관련된 설정",
	SLASH_COMMAND_17_FUNC = "AlphaUpSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_18 = "원형시작점",
	SLASH_COMMAND_18_DESC = "현재 바의 원형 시작 지점을 설정합니다.",
	SLASH_COMMAND_18_FUNC = "ArcStartSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_19 = "원형길이",
	SLASH_COMMAND_19_DESC = "현재 바의 원형 길이를 설정합니다.",
	SLASH_COMMAND_19_FUNC = "ArcLengthSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_20 = "열수",
	SLASH_COMMAND_20_DESC = "현재 바의 열 갯수를 설정합니다. (행렬 모양을 위한 설정)",
	SLASH_COMMAND_20_FUNC = "ColumnsSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_21 = "수평간격",
	SLASH_COMMAND_21_DESC = "현재 바의 버튼간 수평 간격을 설정합니다.",
	SLASH_COMMAND_21_FUNC = "PadHSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_22 = "수직간격",
	SLASH_COMMAND_22_DESC = "현재 바의 버튼간 수직 간격을 설정합니다.",
	SLASH_COMMAND_22_FUNC = "PadVSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_23 = "전체간격",
	SLASH_COMMAND_23_DESC = "현재 바의 버튼간 좌우 간격을 동시에 설정합니다.",
	SLASH_COMMAND_23_FUNC = "PadHVSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_24 = "격자표시",
	SLASH_COMMAND_24_DESC = "현재 바의 격자표시 설정을 토글합니다.",
	SLASH_COMMAND_24_FUNC = "ShowgridSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_25 = "x",
	SLASH_COMMAND_25_DESC = "현재 바의 수평 위치좌표 설정을 합니다.",
	SLASH_COMMAND_25_FUNC = "XAxisSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_26 = "y",
	SLASH_COMMAND_26_DESC = "현재 바의 수직 위치좌표 설정을 합니다.",
	SLASH_COMMAND_26_FUNC = "YAxisSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_27 = "상태",
	SLASH_COMMAND_27_DESC = "현재 바의 상태를 토글합니다. (/마카 상재 <상태>). [/마카 상태목록]으로 유효 상태들을 확인 가능합니다. ",
	SLASH_COMMAND_27_FUNC = "SetBarStates",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_28 = "상태목록",
	SLASH_COMMAND_28_DESC = "유효한 상태들의 목록을 표시합니다.",
	SLASH_COMMAND_28_FUNC = "PrintStateList",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_29 = "고정",
	SLASH_COMMAND_29_DESC = "버튼 고정 토글",
	SLASH_COMMAND_29_FUNC = "ButtonLock",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_30 = "load",
	SLASH_COMMAND_30_DESC = "Load a profile",
	SLASH_COMMAND_30_FUNC = "LoadFromProfile",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_31 = "storage",
	SLASH_COMMAND_31_DESC = "Open the button storage area",
	SLASH_COMMAND_31_FUNC = "OpenStorage", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_32 = "profiles",
	SLASH_COMMAND_32_DESC = "Open Profile Options",
	SLASH_COMMAND_32_FUNC = "OpenProfiles", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_33 = "timerlimit",
	SLASH_COMMAND_33_DESC = "Sets the minimum time in seconds to show on text timers",
	SLASH_COMMAND_33_FUNC = "SetTimerLimit", -- function call, do not tranlsate, leave in English

	SLASH_HINT1 = "\n/mac 또는 /마카 |cff00ff00<명령어>|r",
	SLASH_HINT2 = "\n명령어 목록 -\n",

	BAR_SNAPTO_DISABLED = "스냅 비활성화 :",
	BAR_SNAPTO_ENABLED = "스냅 활성화 :",
	BAR_SHOWGRID_DISABLED = "격자표시 비활성화 :",
	BAR_SHOWGRID_ENABLED = "격자표시 활성화 :",
	BAR_HIDDEN_DISABLED	= "현재 바를 표시 설정",
	BAR_HIDDEN_ENABLED	= "현재 바를 숨김 설정",
	BAR_DUALSPEC_DISABLED = "DualSpec disabled for ",
	BAR_DUALSPEC_ENABLED = "DualSpec enabled for ",
	BAR_SHAPES = "\n1=수평\n2=수직\n3=멀티-행렬\n4=원형\n5=원형+중앙바",
	BAR_STRATAS = "\n1=백그라운드\n2=하위\n3=중간\n4=상위\n5=대화",
	BAR_ALPHA = "투명도 값은 반드시 0 과 1 사이에서 설정하세요.",
	BAR_ARCSTART = "원형 시작점은 반드시 0 과 359 사이에서 설정하세요.",
	BAR_ARCLENGTH = "원형 길이는 반드시 0 과 359 사이에서 설정하세요.",
	BAR_COLUMNS = "원하는 바의 열 수를 0 보다 높게 표기하세요.",
	BAR_PADH = "원하는 버튼의 수평간격을 설정하세요.",
	BAR_PADV = "원하는 버튼의 수직간격을 설정하세요.",
	BAR_PADHV = "원하는 버튼의 전체 간격을 설정하세요.",

	INVALID_CHOICE = "잘못된 선택입니다.",
	INVALID_STATE = "잘못된 바 설정입니다.",
	NO_BAR_SELECTED = "바가 선택되지 않았습니다.",

	OPT1 = "설정1:",
	VALUE = "값:",
	APPLY = "적용",
	COPY = "복사",
	DONE = "Dismiss",
	DELETE = "삭제",
	CHARGES = "Charge",

	CREATE_BUTTON = "Create Button",
	DELETE_BUTTON = "Delete Button",
	STORED_BUTTONS = "Number of stored buttons:",
	OVERFLOW = "Storage Overflow:",
	LOCKROW = "Lock Row",

	MACRO_EDIT = "매크로 에디터",
	MACRO_NAME = "-매크로 이름-",
	MACRO_MASTER = "매크로 마스터",
	MACRO_EDITNOTE = "매크로 노트를 수정하려면 여길 클릭하세요.",
	MACRO_ICON = "클릭으로 아이콘 수정",
	MACRO_EXPAND = "확장",
	ACTION_EDIT = "액션 ID 에디터",
	ACTION_PROP = "바에서의 액션 ID 전달",

	BUTTON_OPTIONS = "버튼 Options",

	CLICK_ANCHOR = "Click Anchor",
	MOUSE_ANCHOR = "Mouse Anchor",
	ANCHOR_DELAY = "Delay: ",

	BTNOPTION_EDIT_BUTTON_1 = "Scale",
	BTNOPTION_EDIT_BUTTON_2 = "X Offset",
	BTNOPTION_EDIT_BUTTON_3 = "Y Offset",

	BTNOPTION_EDIT_CHECK_1 = "Up Clicks",
	BTNOPTION_EDIT_CHECK_2 = "Down Clicks",
	BTNOPTION_EDIT_CHECK_3 = "Spell Counts",
	BTNOPTION_EDIT_CHECK_4 = "Combo Counts",

	BAR_EDIT_ADD = "추가",
	BAR_EDIT_REMOVE = "제거",
	BAR_EDIT_BARLINK = "바 링크",
	BAR_EDIT_NAME = "바 이름",

	BAR_EDIT_BUTTON_1 = "크기",
	BAR_EDIT_BUTTON_2 = "모양",
	BAR_EDIT_BUTTON_3 = "열수",
	BAR_EDIT_BUTTON_4 = "깊이",
	BAR_EDIT_BUTTON_5 = "투명도",
	BAR_EDIT_BUTTON_6 = "투명해제조건",
	BAR_EDIT_BUTTON_7 = "원형시작점",
	BAR_EDIT_BUTTON_8 = "원형길이",
	BAR_EDIT_BUTTON_9 = "원형프리셋",
	BAR_EDIT_BUTTON_10 = "수평간격",
	BAR_EDIT_BUTTON_11 = "수직간격",
	BAR_EDIT_BUTTON_12 = "전체간격",
	BAR_EDIT_BUTTON_13 = "버튼갯수",

	BAR_MESSAGE = "좌클릭/우클릭/마우스휠로 조정: |cffffffff",

	BAR_EDIT_BUTTON_TEXT_1 = "크기",
	BAR_EDIT_BUTTON_TEXT_2 = "모양",
	BAR_EDIT_BUTTON_TEXT_3 = "열수",
	BAR_EDIT_BUTTON_TEXT_4 = "프레임 깊이",
	BAR_EDIT_BUTTON_TEXT_5 = "알파(투명도)",
	BAR_EDIT_BUTTON_TEXT_6 = "\'투명해제\' 상태",
	BAR_EDIT_BUTTON_TEXT_7 = "원형시작점",
	BAR_EDIT_BUTTON_TEXT_8 = "원형길이",
	BAR_EDIT_BUTTON_TEXT_9 = "원형모양 프리셋",
	BAR_EDIT_BUTTON_TEXT_10 = "수평간격",
	BAR_EDIT_BUTTON_TEXT_11 = "수직간격",
	BAR_EDIT_BUTTON_TEXT_12 = "수평&수직 간격",
	BAR_EDIT_BUTTON_TEXT_13 = "버튼갯수",

	CHECK_101 = "블리자드 메인바 활성화",
	CHECK_102 = "버튼 툴팁 활성화",
	CHECK_103 = "전투시 툴팁 숨김",
	CHECK_104 = "단축키 표시 활성화",
	CHECK_105 = "매크로 텍스트 활성화",
	CHECK_106 = "카운트 텍스트 활성화",
	CHECK_107 = "오른쪽 드래그로 버튼 복사",
	CHECK_108 = "마카룬에 의한 가방조절 허가",
	CHECK_109 = "버튼 고정 활성화",
	CHECK_110 = "Shift+드래그 활성화",
	CHECK_111 = "Control+드래그 활성화",
	CHECK_112 = "Alt+드래그 활성화",
	CHECK_113 = "쿨다운 타이머 텍스트",
	CHECK_114 = "버프/디버프 타이머 텍스트",
	CHECK_115 = "버프/디버프 강조",
	CHECK_116 = "버튼 다운 클릭 활성화",
	CHECK_117 = "Enable Blizzard Vehicle Bar",

	SLIDER_1 = "가방 X 좌표값",
	SLIDER_2 = "가방 Y 좌표값",
	SLIDER_3 = "가방 크기",
	SLIDER_4 = "가상 빈 가방 공간",
	SLIDER_5 = "쿨다운 투명도",
	SLIDER_6 = "소환수 사동시전 투명도",
	SLIDER_7 = "투명화 해제 속도",
	SLIDER_8 = "스냅 허용오차",

	FLOAT_EDITORS = "Floating Editors",
	ANIMATED = "움직이는 메뉴",
	DUALSPEC = "Enable Dual Spec",
	BEGINNER = "Beginner Tooltips",

	CHECK_MACRO = "노트에 \n툴팁 사용 ",

	EMPTY_BUTTON = "빈 버튼",

        MINIMAP_CHECK = "Minimap Button",
	MINIMAP_TOOLTIP0 = "마카룬\n",
	MINIMAP_TOOLTIP1 = "|cffffffff우-클릭|r 으로 미니 메뉴\n\n|cffffffff좌-클릭|r 으로 바설정 토글\n|cffffffffShift-Click|r으로 단축키 모드 토글\n|cffffffffAlt-Click|r으로 버튼설정 토글\n|cffffffffCtrl-Click|r으로 메인 메뉴 열기\n\n|cffffffff/마카|r 로 명령어 출력",
	MINIMAP_TOOLTIP2 = "\n버튼 고정: ",

	MINIMAP_ACTION_1 = "버튼고정",
	MINIMAP_ACTION_1_FUNC = "ButtonLock",		-- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_2 = "버튼수정",
	MINIMAP_ACTION_2_FUNC = "ButtonEdit",		-- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_3 = "바 설정",
	MINIMAP_ACTION_3_FUNC = "ConfigBars",		-- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_4 = "단축설정",
	MINIMAP_ACTION_4_FUNC = "ButtonBind",		-- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_5 = "메인메뉴",
	MINIMAP_ACTION_5_FUNC = "OpenMainMenu",		-- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_6 = " 바 생성",
	MINIMAP_ACTION_6_FUNC = "CreateNewBar", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_6_ARG = "bar", -- function args, do not tranlsate, leave in English
	MINIMAP_ACTION_7 = " 바 삭제",
	MINIMAP_ACTION_7_FUNC = "DeleteBar", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_8 = "» Close «",
	MINIMAP_ACTION_8_FUNC = "MinimapMenuClose", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_9 = "Storage",
	MINIMAP_ACTION_9_FUNC = "OpenStorage", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_10 = "Profiles",
	MINIMAP_ACTION_10_FUNC = "OpenProfiles", -- function call, do not tranlsate, leave in English

	BINDFRAME_BIND = "단축키",
	BINDFRAME_LOCKED = "고정됨",
	BINDFRAME_PRIORITY = "priority",

	BINDINGS_LOCKED	= "이 버튼은 단축 설정이 고정되어 있습니다.\n좌-클릭으로 고정을 해제합니다.",

	BARTOOLTIP_1 = "켜짐",
	BARTOOLTIP_2 = "꺼짐",
	BARTOOLTIP_3 = "크기: ",
	BARTOOLTIP_4 = "깊이: ",
	BARTOOLTIP_5 = "투명도: ",
	BARTOOLTIP_6 = "투명해제: ",
	BARTOOLTIP_7 = "모양: ",
	BARTOOLTIP_8 = "열수: ",
	BARTOOLTIP_9 = "원형시작: ",
	BARTOOLTIP_10 = "원형반경: ",
	BARTOOLTIP_11 = "수평간격: ",
	BARTOOLTIP_12 = "수직간격: ",
	BARTOOLTIP_13 = "스냅: ",
	BARTOOLTIP_14 = "격자표시: ",
	BARTOOLTIP_15 = "자동숨김: ",
	BARTOOLTIP_16 = "대상: ",
	BARTOOLTIP_17 = "|cffffffff현재 상태: |r",
	BARTOOLTIP_18 = "|cffffffff활성 상태: |r",
	BARTOOLTIP_19 = "|cffffffff버튼: |r",
	BARTOOLTIP_20 = "포인트: ",
	BARTOOLTIP_21 = "  x:",
	BARTOOLTIP_22 = "  y:",

	BARTOOLTIP_23 = "|cff00ff00현재 바|r",

	BARTOOLTIP_24 = "\n|cffffffff좌-클릭|r으로 활성상태 순환 변경",
	BARTOOLTIP_25 = "\n|cffffffff좌-클릭|r으로 바 선택",

	BARTOOLTIP_26 = "|cffffffff우-클릭|r으로 바 편집기 토글",
	BARTOOLTIP_27 = "|cffffffffMiddle-Click|r to toggle hidden state",
	BARTOOLTIP_275 = "|cffffffffShift-Click|r to adjust position using arrow keys",

	BARTOOLTIP_28 = "|cffffffff좌-클릭|r으로 현재 값 증가",
	BARTOOLTIP_29 = "|cffffffff우-클릭|r으로 현재 값 감소",
	BARTOOLTIP_30 = "|cffffffff마우스휠|r로 현재 값 증가/감소",
	BARTOOLTIP_31 = "\n편집 모드에서 나가시려면: |cffffffff휠-클릭|r\n  또는 |cffffffff마우스|r를 바 바깥으로 이동시키세요.",

	KEYBIND_TOOLTIP1 = "\n의 단축키를 지정해주세요.",
	KEYBIND_TOOLTIP2 = "좌-클릭으로 버튼의 단축설정을 고정합니다.\n|cfff00000ESC|r키로 버튼의 현재 단축설정을 초기화 합니다.",
	KEYBIND_TOOLTIP3 = "|cffffffff현재 단축설정: |r|cff00ff00",
	KEYBIND_NONE = "없음",

	BUTTONEDIT_TOOLTIP1 = "좌-클릭으로 버튼 타입을 바꿉니다.\n우-클릭으로 |cff00ff00",
	BUTTONEDIT_TOOLTIP2 = " 원형 버튼 모양",

	BARSHAPE_1 = "배열",
	BARSHAPE_2 = "원형",
	BARSHAPE_3 = "원형+중앙",

	BARSTATE_1 = "페이지연동",
	BARSTATE_2 = "태세/폼",
	BARSTATE_3 = "소환수",
	BARSTATE_4 = "Control Bar",
	BARSTATE_5 = "은신상태",
	BARSTATE_6 = "적대대상",
	BARSTATE_7 = "전투중",
	BARSTATE_8 = "파티중",
	BARSTATE_9 = "Alt키",
	BARSTATE_10 = "Ctrl키",
	BARSTATE_11 = "Shift키",
	BARSTATE_12 = "사용자설정",

	BARSTATE_AH = "자동숨김",
	BARSTATE_SG = "빈칸표시",
	BARSTATE_ST = "스냅",
	BARSTATE_HD = "숨김",
	BARSTATE_DS = "Dual Spec",

	TEXTEDIT_NAME = "바 이름:",
        TEXTEDIT_TARGET = "바 대상:",
        TEXTEDIT_LSTATE = "상태:",
        TEXTEDIT_LTO = "Linked To:",
        TEXTEDIT_BSTATE = "바 상태:",
        TEXTEDIT_REMAP = "Remap To:",
        TEXTEDIT_CUSTOM = "사용사 설정:",

	ALPHAUP_NONE = "없음",
	ALPHAUP_BATTLE = "전투중",
	ALPHAUP_MOUSEOVER = "마우스오버",
	ALPHAUP_BATTLEMOUSE = "전투+마우스오버",
	ALPHAUP_RETREAT = "비전투",
	ALPHAUP_RETREATMOUSE = "비전투+마우스오버",

	ARC_PRESET_1 = "상단 반원",
	ARC_PRESET_2 = "하단 반원",
	ARC_PRESET_3 = "좌측 반원",
	ARC_PRESET_4 = "우측 반원",
	ARC_PRESET_5 = "완전 원형",

	STATES = {
		homestate = "일반",
		laststate = "볼수없음!",
		pagedbar1 = "페이지 1",
		pagedbar2 = "페이지 2",
		pagedbar3 = "페이지 3",
		pagedbar4 = "페이지 4",
		pagedbar5 = "페이지 5",
		pagedbar6 = "페이지 6",
		stance0 = "태세/폼 없음",
		companion0 = "소환수 없음",
		companion1 = "소환수",
		stealth1 = "투명/은신",
		reaction1 = "적대",
		combat1 = "전투",
		group1 = "공격대",
		group2 = "파티",
		control1 = "Controls: Vehicle/Possess",
		possess1 = "소유",
		vehicle1 = "Vehicle",
		alt1 = "Alt키 눌림",
		ctrl1 = "Control키 눌림",
		shift1 = "Shift키 눌림",
		custom = "사용자 설정",
	},

	--class specific state names
	DRUID_STANCE0 = "인간형 폼",
	DRUID_PROWL = "숨기",
	PRIEST_HEALER = "힐러 폼",
	ROGUE_ATTACK = "전투상태",
	WARLOCK_CASTER = "캐스터 폼",

	PETATTACK = "Attack",
	PETFOLLOW = "Follow",
	PETSTAY = "Stay",
	PETAGGRESSIVE = "Aggressive",
	PETDEFENSIVE = "Defensive",
	PETPASSIVE = "Passive",

	CUSTOM_OPTION = "\n\n사용자 설정에서는 자신이 원하는 조건을 (/mac state custom <state string>)형식으로 편집할 수 있습니다. 여기서 <state string>은 세미콜론(;)으로 구분합니다.\n\n|cff00ff00예시:|r [actionbar:1];[stance:1];[stance3,stealth];[mounted]\n\n|cff00ff00메모:|r 가장 첫 항목은 일종의 \"home state\" 이라고 볼 수 있습니다. 만일 state manager 가 조건을 제대로 인식하지 못할 경우 이 것을 기본상태로 설정하게 됩니다.",

}

-- Some languages Blizzard is now making a distinction on class names based on gender.
if (UnitSex("player") == 2) then

	MACAROON_STRINGS.DRUID = "드루이드"
	MACAROON_STRINGS.WARRIOR = "전사"
	MACAROON_STRINGS.ROGUE = "도적"
	MACAROON_STRINGS.PRIEST = "사제"
	MACAROON_STRINGS.HUNTER = "사냥꾼"
	MACAROON_STRINGS.PALADIN = "성기사"
	MACAROON_STRINGS.SHAMAN = "주술사"
	MACAROON_STRINGS.MAGE = "마법사"
	MACAROON_STRINGS.WARLOCK = "흑마법사"
	MACAROON_STRINGS.DEATHKNIGHT = "Death Knight"

else

	MACAROON_STRINGS.DRUID = "드루이드"
	MACAROON_STRINGS.WARRIOR = "전사"
	MACAROON_STRINGS.ROGUE = "도적"
	MACAROON_STRINGS.PRIEST = "사제"
	MACAROON_STRINGS.HUNTER = "사냥꾼"
	MACAROON_STRINGS.PALADIN = "성기사"
	MACAROON_STRINGS.SHAMAN = "주술사"
	MACAROON_STRINGS.MAGE = "마법사"
	MACAROON_STRINGS.WARLOCK = "흑마법사"
	MACAROON_STRINGS.DEATHKNIGHT = "Death Knight"

end

BINDING_HEADER_MACAROON_BARS = "마카룬"

end

MacaroonLocale.Macaroon.koKR = load_localization

if ( GetLocale() == "koKR" ) then
  load_localization()
end