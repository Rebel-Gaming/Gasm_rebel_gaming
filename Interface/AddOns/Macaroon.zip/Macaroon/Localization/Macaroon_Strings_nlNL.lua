-- Dutch Localization by Deep92 at wowinterface.com



local function load_localization()

MACAROON_STRINGS = {

	TITLE = "Macaroon!",
	DESC = "An unlimted number of highly configurable macro bars and buttons",

	SLASH1 = "/macaroon",
	SLASH2 = "/mac",

	SLASH_COMMAND_1 = "menu",
	SLASH_COMMAND_1_DESC = "Hoofdmenu openen",
	SLASH_COMMAND_1_FUNC = "OpenMainMenu", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_2 = "create",
	SLASH_COMMAND_2_DESC = "Nieuwe balk maken",
	SLASH_COMMAND_2_FUNC = "CreateNewBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_3 = "delete",
	SLASH_COMMAND_3_DESC = "Huidige balk verwijderen",
	SLASH_COMMAND_3_FUNC = "DeleteBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_4 = "config",
	SLASH_COMMAND_4_DESC = "Aanpassingsmodus voor alle balken aan-/uitzetten ",
	SLASH_COMMAND_4_FUNC = "ConfigBars", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_5 = "add",
	SLASH_COMMAND_5_DESC = "Knoppen aan huidige balk toevoegen (add or add #)",
	SLASH_COMMAND_5_FUNC = "AddButton", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_6 = "remove",
	SLASH_COMMAND_6_DESC = "Knoppen van de huidige balk verwijderen (remove or remove #)",
	SLASH_COMMAND_6_FUNC = "RemoveButton", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_7 = "edit",
	SLASH_COMMAND_7_DESC = "Aanpassingsmodus voor alle knoppen aan-/uitzetten",
	SLASH_COMMAND_7_FUNC = "ButtonEdit", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_8 = "bind",
	SLASH_COMMAND_8_DESC = "Bindingsmodus voor alle knoppen aan-/uitzetten ",
	SLASH_COMMAND_8_FUNC = "ButtonBind", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_9 = "scale",
	SLASH_COMMAND_9_DESC = "Gelecteerde balk naar gewenste maat Wijzigen",
	SLASH_COMMAND_9_FUNC = "ScaleBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_10 = "snapto",
	SLASH_COMMAND_10_DESC = "SnapTo voor huidige balk aan-/uitzetten",
	SLASH_COMMAND_10_FUNC = "SnapToBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_11 = "autohide",
	SLASH_COMMAND_11_DESC = "Automatisch verbergen voor huidige balk aan-/uitzetten",
	SLASH_COMMAND_11_FUNC = "AutohideBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_12 = "hidden",
	SLASH_COMMAND_12_DESC = "Laten zien of verbergen wijzigen",
	SLASH_COMMAND_12_FUNC = "HideBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_13 = "shape",
	SLASH_COMMAND_13_DESC = "Vorm van huidige balk wijzigen",
	SLASH_COMMAND_13_FUNC = "ShapeBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_14 = "name",
	SLASH_COMMAND_14_DESC = "Naam van huidige balk wijzigen",
	SLASH_COMMAND_14_FUNC = "NameBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_15 = "strata",
	SLASH_COMMAND_15_DESC = "Laag van de huidige balk wijzigen",
	SLASH_COMMAND_15_FUNC = "StrataSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_16 = "alpha",
	SLASH_COMMAND_16_DESC = "Alpha van huidige balk wijzigen (Transparantie)",
	SLASH_COMMAND_16_FUNC = "AlphaSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_17 = "alphaup",
	SLASH_COMMAND_17_DESC = "Zet voorwaarden van huidige balk naar 'Alpha Up'",
	SLASH_COMMAND_17_FUNC = "AlphaUpSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_18 = "arcstart",
	SLASH_COMMAND_18_DESC = "Start positie van kromming van de huidige balk aanpassen (in graden)",
	SLASH_COMMAND_18_FUNC = "ArcStartSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_19 = "arclen",
	SLASH_COMMAND_19_DESC = "Lengte van kromming van de huidige balk aanpassen (in graden)",
	SLASH_COMMAND_19_FUNC = "ArcLengthSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_20 = "columns",
	SLASH_COMMAND_20_DESC = "Aantal kolommen van huidige balk wijzigen (Voor vorm 'Multi-Column')",
	SLASH_COMMAND_20_FUNC = "ColumnsSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_21 = "padh",
	SLASH_COMMAND_21_DESC = "Horizontale opvulling van huidige balk wijzigen",
	SLASH_COMMAND_21_FUNC = "PadHSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_22 = "padv",
	SLASH_COMMAND_22_DESC = "Verticale opvulling van huidige balk wijzigen ",
	SLASH_COMMAND_22_FUNC = "PadVSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_23 = "padhv",
	SLASH_COMMAND_23_DESC = "Horizontale en verticale opvulling van de huidige balk gelijkmatig wijzigen",
	SLASH_COMMAND_23_FUNC = "PadHVSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_24 = "showgrid",
	SLASH_COMMAND_24_DESC = "Raster van huidige balk altijd laten zien",
	SLASH_COMMAND_24_FUNC = "ShowgridSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_25 = "x",
	SLASH_COMMAND_25_DESC = "Positie van horizontale as van huidige balk wijzigen",
	SLASH_COMMAND_25_FUNC = "XAxisSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_26 = "y",
	SLASH_COMMAND_26_DESC = " Positie van verticale as van huidige balk wijzigen ",
	SLASH_COMMAND_26_FUNC = "YAxisSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_27 = "state",
	SLASH_COMMAND_27_DESC = "Status van huidige balk wijzigen (/mac state <state>). Typ /mac statelist voor juiste staten",
	SLASH_COMMAND_27_FUNC = "SetBarStates", 	-- function call, do not tranlsate, leave in English

	SLASH_COMMAND_28 = "statelist",
	SLASH_COMMAND_28_DESC = "Lijst van juiste staten laten zien",
	SLASH_COMMAND_28_FUNC = "PrintStateList",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_29 = "lock",
	SLASH_COMMAND_29_DESC = "Knoppen Slot aan-/uitzetten",
	SLASH_COMMAND_29_FUNC = "ButtonLock",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_30 = "load",
	SLASH_COMMAND_30_DESC = "Profiel laden",
	SLASH_COMMAND_30_FUNC = "LoadFromProfile",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_31 = "storage",
	SLASH_COMMAND_31_DESC = "Open the button storage area",
	SLASH_COMMAND_31_FUNC = "OpenStorage", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_32 = "profiles",
	SLASH_COMMAND_32_DESC = "Open Profile Options",
	SLASH_COMMAND_32_FUNC = "OpenProfiles", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_33 = "timerlimit",
	SLASH_COMMAND_33_DESC = "Sets the minimum time in seconds to show on text timers",
	SLASH_COMMAND_33_FUNC = "SetTimerLimit", -- function call, do not tranlsate, leave in English

	SLASH_HINT1 = "\n/Macaroon of /mac |cff00ff00<command>|r",
	SLASH_HINT2 = "\nLijst van commando’s -\n",

	BAR_SNAPTO_DISABLED = "SnapTo uitgeschakeld voor ",
	BAR_SNAPTO_ENABLED = "SnapTo ingeschakeld voor ",
	BAR_SHOWGRID_DISABLED = "ShowGrid uitgeschakeld voor ",
	BAR_SHOWGRID_ENABLED = "ShowGrid ingeschakeld voor ",
	BAR_HIDDEN_DISABLED	= "Huidige balk word weer gegeven",
	BAR_HIDDEN_ENABLED	= "Huidige balk word verborgen",
	BAR_DUALSPEC_DISABLED = "DualSpec disabled for ",
	BAR_DUALSPEC_ENABLED = "DualSpec enabled for ",
	BAR_SHAPES = "\n1=Horizontaal\n2=Verticaal\n3=Multi-Column\n4=Cirkel\n5=Cirkel+Een",
	BAR_STRATAS = "\n1=ACHTERGROND\n2=LAAG\n3=GEMIDDELD\n4=HOOG\n5=DIALOOG",
	BAR_ALPHA = "Waarde alpha moet tussen 0 en een 1 zijn",
	BAR_ARCSTART = "Start boog moet tussen 0 en 359 zijn",
	BAR_ARCLENGTH = "Lengte boog moet tussen 0 en 359 zijn ",
	BAR_COLUMNS = "Voer een getal voor het gewenste aantal kolommen voor de balk in (Hoger dan 0)",
	BAR_PADH = "Voer een geldig getal voor gewenste horizontale opvulling in",
	BAR_PADV = "Voer een geldig getal voor gewenste verticale opvulling in",
	BAR_PADHV = "Voer een geldig getal voor de gewenste horizontale en verticale opvulling in",

	INVALID_CHOICE = "Geen geldige keuze",
	INVALID_STATE = "Geen geldige status voor de balk",
	NO_BAR_SELECTED = "Geen balk geselecteerd",

	OPT1 = "Opt1:",
	VALUE = "Waarde:",
	APPLY = "Toepassen",
	COPY = "Kopiëren",
	DONE = "Dismiss",
	DELETE = "Wissen",
	CHARGES = "Charge",

	CREATE_BUTTON = "Knop maken",
	DELETE_BUTTON = "Knop wissen",
	STORED_BUTTONS = "Number of stored buttons:",
	OVERFLOW = "Storage Overflow:",
	LOCKROW = "Lock Row",

	MACRO_EDIT = "Macro Editor",
	MACRO_NAME = "-naam macro-",
	MACRO_MASTER = "Macro Master",
	MACRO_EDITNOTE = "Klik hier om de macro notitie te veranderen",
	MACRO_ICON = "Klik om het icoon te veranderen",
	MACRO_EXPAND = "Uitvouwen",
	ACTION_EDIT = "Action ID Editor",
	ACTION_PROP = "Propagate Action ID's on Bar  ",

	BUTTON_OPTIONS = "Knop opties",

	CLICK_ANCHOR = "Click Anchor",
	MOUSE_ANCHOR = "Mouse Anchor",
	ANCHOR_DELAY = "Delay: ",

	BTNOPTION_EDIT_BUTTON_1 = "Scale",
	BTNOPTION_EDIT_BUTTON_2 = "X Offset",
	BTNOPTION_EDIT_BUTTON_3 = "Y Offset",

	BTNOPTION_EDIT_CHECK_1 = "Up Clicks",
	BTNOPTION_EDIT_CHECK_2 = "Down Clicks",
	BTNOPTION_EDIT_CHECK_3 = "Spell Counts",
	BTNOPTION_EDIT_CHECK_4 = "Combo Counts",

	BAR_EDIT_ADD = "Toevoegen",
	BAR_EDIT_REMOVE = "Verijderen",
	BAR_EDIT_BARLINK = "Balk koppelen",
	BAR_EDIT_NAME = "Naam van de balk",

	BAR_EDIT_BUTTON_1 = "Schaal",
	BAR_EDIT_BUTTON_2 = "Vorm",
	BAR_EDIT_BUTTON_3 = "Kolommen",
	BAR_EDIT_BUTTON_4 = "Laag",
	BAR_EDIT_BUTTON_5 = "Alpha",
	BAR_EDIT_BUTTON_6 = "AlphaUp",
	BAR_EDIT_BUTTON_7 = "Begin boog",
	BAR_EDIT_BUTTON_8 = "Lengte boog",
	BAR_EDIT_BUTTON_9 = "Vooraf ingestelde boog ",
	BAR_EDIT_BUTTON_10 = "Horizontale opvulling",
	BAR_EDIT_BUTTON_11 = "Verticale opvulling",
	BAR_EDIT_BUTTON_12 = "Horizontale en verticale opvulling",
	BAR_EDIT_BUTTON_13 = "Aantal knoppen",

	BAR_MESSAGE = "LKlik/RKlik/Muiswieltje om aan te passen: |cffffffff",

	BAR_EDIT_BUTTON_TEXT_1 = "Schaal",
	BAR_EDIT_BUTTON_TEXT_2 = "Vorm",
	BAR_EDIT_BUTTON_TEXT_3 = "Aantal kolommen",
	BAR_EDIT_BUTTON_TEXT_4 = "Laag van frame",
	BAR_EDIT_BUTTON_TEXT_5 = "Alpha (transparency)",
	BAR_EDIT_BUTTON_TEXT_6 = "Voorwaarde(n) voor \'alpha-up\'",
	BAR_EDIT_BUTTON_TEXT_7 = "Startpunt van boog",
	BAR_EDIT_BUTTON_TEXT_8 = "Lengte boog",
	BAR_EDIT_BUTTON_TEXT_9 = "Vooraf ingestelde vorm van boog",
	BAR_EDIT_BUTTON_TEXT_10 = "Horizontale opvulling",
	BAR_EDIT_BUTTON_TEXT_11 = "Verticale opvulling",
	BAR_EDIT_BUTTON_TEXT_12 = "Horizontale en verticale opvulling",
	BAR_EDIT_BUTTON_TEXT_13 = "Aantal knoppen",

	CHECK_101 = "Blizzard basis balk",
	CHECK_102 = "Tooltips van knoppen",
	CHECK_103 = "Tooltips verbergen tijdens gevecht",
	CHECK_104 = "Bindings tekst",
	CHECK_105 = "Macro tekst",
	CHECK_106 = "’Aantal’ tekst",
	CHECK_107 = "Rechter-sleep knop kopie",
	CHECK_108 = "Mac toelaten tassen aan te passen",
	CHECK_109 = "Knoppen slot",
	CHECK_110 = "Shift-sleep",
	CHECK_111 = "Ctrl-sleep",
	CHECK_112 = "Alt-sleep",
	CHECK_113 = "Cooldown tijd (tekst)",
	CHECK_114 = "Buff/Debuff tijd (tekst)",
	CHECK_115 = "Buff/Debuff markering",
	CHECK_116 = "Knop neer-klik",
	CHECK_117 = "Enable Blizzard Vehicle Bar",

	SLIDER_1 = "Tas X verschuiving",
	SLIDER_2 = "Tas Y verschuiving ",
	SLIDER_3 = "Tas Schaal",
	SLIDER_4 = "Ideale vrije tas Ruimte",
	SLIDER_5 = "Cooldown Alpha",
	SLIDER_6 = "Pet Autocast Alpha",
	SLIDER_7 = "Alpha-Up vervaag snelheid",
	SLIDER_8 = "SnapTo Tolerantie",

	FLOAT_EDITORS = "Zwevende editors",
	ANIMATED = "Geanimeerde menu’s",
	DUALSPEC = "Enable Dual Spec",
	BEGINNER = "Beginner Tooltips",

	CHECK_MACRO = "Gebruik notitie \nals tooltip ",

	EMPTY_BUTTON = "Lege knop",

        MINIMAP_CHECK = "Minimap knop",
	MINIMAP_TOOLTIP0 = "Macaroon\n",
	MINIMAP_TOOLTIP1 = "|cffffffffRechter-Klik|r voor mini-menu\n\n|cffffffffLinker-Klik|r voor balk aanp. modus\n|cffffffffShift-Klik|r voor bindings modus\n|cffffffffAlt-Klik|r voor knop aanp. modus\n|cffffffffCtrl-Klik|r voor hoofdmenu\n\n|cffffffff/mac|r voor handmatige opties",
	MINIMAP_TOOLTIP2 = "\nKnoppen slot",

	MINIMAP_ACTION_1 = "Knoppen slot",
	MINIMAP_ACTION_1_FUNC = "ButtonLock", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_2 = "Knoppen aanp.",
	MINIMAP_ACTION_2_FUNC = "ButtonEdit", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_3 = "Balken aanp.",
	MINIMAP_ACTION_3_FUNC = "ConfigBars", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_4 = "Bindingen aanp.",
	MINIMAP_ACTION_4_FUNC = "ButtonBind", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_5 = "Hoofdmenu",
	MINIMAP_ACTION_5_FUNC = "OpenMainMenu", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_6 = "Nieuwe balk\n",
	MINIMAP_ACTION_6_FUNC = "CreateNewBar", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_6_ARG = "bar", -- function args, do not tranlsate, leave in English
	MINIMAP_ACTION_7 = "Balk verwijderen\n",
	MINIMAP_ACTION_7_FUNC = "DeleteBar", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_8 = "» Close «",
	MINIMAP_ACTION_8_FUNC = "MinimapMenuClose", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_9 = "Storage",
	MINIMAP_ACTION_9_FUNC = "OpenStorage", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_10 = "Profiles",
	MINIMAP_ACTION_10_FUNC = "OpenProfiles", -- function call, do not tranlsate, leave in English

	BINDFRAME_BIND = "bind",
	BINDFRAME_LOCKED = "Op slot",
	BINDFRAME_PRIORITY = "priority",

	BINDINGS_LOCKED	= "Bindingen van deze knop zijn op slot.\nLinker-Klik knop om te ontgrendelen",

	BARTOOLTIP_1 = "Aan",
	BARTOOLTIP_2 = "Uit",
	BARTOOLTIP_3 = "Schaal: ",
	BARTOOLTIP_4 = "Laag: ",
	BARTOOLTIP_5 = "Alpha: ",
	BARTOOLTIP_6 = "AlphaUp: ",
	BARTOOLTIP_7 = "Vorm: ",
	BARTOOLTIP_8 = "Kolommen: ",
	BARTOOLTIP_9 = "BoogS: ",
	BARTOOLTIP_10 = "BoogL: ",
	BARTOOLTIP_11 = "OpvH: ",
	BARTOOLTIP_12 = "OpvV: ",
	BARTOOLTIP_13 = "SnapTo: ",
	BARTOOLTIP_14 = "Raster: ",
	BARTOOLTIP_15 = "Autom. Verbergen: ",
	BARTOOLTIP_16 = "Doel: ",
	BARTOOLTIP_17 = "|cffffffffHuidige status: |r",
	BARTOOLTIP_18 = "|cffffffffActieve staten: |r",
	BARTOOLTIP_19 = "|cffffffffKnoppen: |r",
	BARTOOLTIP_20 = "Point: ",
	BARTOOLTIP_21 = "  X:",
	BARTOOLTIP_22 = "  Y:",

	BARTOOLTIP_23 = "|cff00ff00Huidige balk|r",

	BARTOOLTIP_24 = "\n|cffffffffLinker-Klik|r om door actieve staten te circuleren",
	BARTOOLTIP_25 = "\n|cffffffffLinker-Klik|r om balk te selecteren",

	BARTOOLTIP_26 = "|cffffffffRechter-Klik|r voor balk aanp. modus",
	BARTOOLTIP_27 = "|cffffffffMiddelste-Klik|r voor verborgen status",
	BARTOOLTIP_275 = "|cffffffffShift-Click|r to adjust position using arrow keys",

	BARTOOLTIP_28 = "|cffffffffLinker-Klik|r om waarde te verhogen",
	BARTOOLTIP_29 = "|cffffffffRechter-Klik|r om waarde te verlagen",
	BARTOOLTIP_30 = "|cffffffffMuiswiel|r om waarde te verhogen/verlagen",
	BARTOOLTIP_31 = "\nOm waarde aanp. Modus te verlaten: |cffffffffMiddelste-Klik|r\n of verplaats |cffffffffmuis|r uit balk frame",

	KEYBIND_TOOLTIP1 = "\nDruk op een toets om te binden aan |cff00ff00%s ",
	KEYBIND_TOOLTIP2 = "Linker-Klik om bindingen van %s’s te vergrendelen\nDruk op |cfff00000ESC|r om huidige binding(en) van %s’s te wissen",
	KEYBIND_TOOLTIP3 = "|cffffffffHuidige binding(en): |r|cff00ff00",
	KEYBIND_NONE = "Geen",

	BUTTONEDIT_TOOLTIP1 = "Linker-Klik om knop type te veranderen\nRechter-Klik |cff00ff00Knop|r aan te passen",
	BUTTONEDIT_TOOLTIP2 = "Om door knop types te circuleren",

	BARSHAPE_1 = "Lineair",
	BARSHAPE_2 = "Cirkel",
	BARSHAPE_3 = "Cirkel + Een",

	BARSTATE_1 = "Wisselbare balk",
	BARSTATE_2 = "Stand",
	BARSTATE_3 = "Pet",
	BARSTATE_4 = "Control Bar",
	BARSTATE_5 = "Stealth",
	BARSTATE_6 = "Reactie",
	BARSTATE_7 = "Gevecht",
	BARSTATE_8 = "Groep",
	BARSTATE_9 = "Alt Toets",
	BARSTATE_10 = "Ctrl Toets",
	BARSTATE_11 = "Shift Toets",
	BARSTATE_12 = "Aangepast",

	BARSTATE_AH = "Autom. Verbergen",
	BARSTATE_SG = "Raster",
	BARSTATE_ST = "SnapTo",
	BARSTATE_HD = "Verborgen",
	BARSTATE_DS = "Dual Spec",

	TEXTEDIT_NAME = "Naam balk:",
        TEXTEDIT_TARGET = "Doel balk:",
        TEXTEDIT_LSTATE = "Status:",
        TEXTEDIT_LTO = "Verbonden met:",
        TEXTEDIT_BSTATE = "Balk status:",
        TEXTEDIT_REMAP = "Toewijzen aan:",
        TEXTEDIT_CUSTOM = "Aangepaste staten:",

	ALPHAUP_NONE = "Geen",
	ALPHAUP_BATTLE = "Gevecht",
	ALPHAUP_MOUSEOVER = "Muisover",
	ALPHAUP_BATTLEMOUSE = "Gevecht+Muisover",
	ALPHAUP_RETREAT = "Terugtrekken",
	ALPHAUP_RETREATMOUSE = "Terugtrek.+Muisover",

	ARC_PRESET_1 = "Bovenkant Boog",
	ARC_PRESET_2 = "Onderkant Boog",
	ARC_PRESET_3 = "Linker Boog",
	ARC_PRESET_4 = "Rechter Boog",
	ARC_PRESET_5 = "Volle Cirkel",

	STATES = {
		homestate = "Normaal",
		laststate = "Should not see!",
		pagedbar1 = "Pagina 1",
		pagedbar2 = "Pagina 2",
		pagedbar3 = "Pagina 3",
		pagedbar4 = "Pagina 4",
		pagedbar5 = "Pagina 5",
		pagedbar6 = "Pagina 6",
		stance0 = "Stand 0",
		companion0 = "Geen Pet",
		companion1 = "Pet",
		stealth1 = "Stealth",
		reaction1 = "Vijandelijk",
		combat1 = "Gevecht",
		group1 = "Groep: Raid",
		group2 = "Groep: Partij",
		control1 = "Controls: Vehicle/Possess",
		possess1 = "Bezit",
		vehicle1 = "Vehicle",
		alt1 = "Alt Neer",
		ctrl1 = "Ctrl Neer",
		shift1 = "Shift Neer",
		custom = "Aangepaste staten",
	},

	--class specific state names
	DRUID_STANCE0 = "Caster Vorm",
	DRUID_PROWL = "Prowl",
	PRIEST_HEALER = "Heler Vorm",
	ROGUE_ATTACK = "Aanval",
	WARLOCK_CASTER = "Caster Vorm",

	PETATTACK = "Aanvallen",
	PETFOLLOW = "Volg",
	PETSTAY = "Blijven",
	PETAGGRESSIVE = "Agressief",
	PETDEFENSIVE = "Defensief",
	PETPASSIVE = "Passief",

	CUSTOM_OPTION = "\n\Voor aangepaste staten, voeg de gewilde status 'string' (/mac state custom <state string>) waar <state string> een lijst, gescheiden door puntkomma's, van staten is\n\n|cff00ff00Voorbeeld:|r [actionbar:1];[stance:1];[stance3,stealth];[mounted]\n\n|cff00ff00Note:|r de eerste status word gezien als de \"basis stand\". Als de 'Status manager' ooit in verwarring raakt, zal hij op deze status terugvallen.",

}

-- Some languages Blizzard is now making a distinction on class names based on gender.
if (UnitSex("player") == 2) then

	MACAROON_STRINGS.DRUID = "Druid"
	MACAROON_STRINGS.WARRIOR = "Warrior"
	MACAROON_STRINGS.ROGUE = "Rogue"
	MACAROON_STRINGS.PRIEST = "Priest"
	MACAROON_STRINGS.HUNTER = "Hunter"
	MACAROON_STRINGS.PALADIN = "Paladin"
	MACAROON_STRINGS.SHAMAN = "Shaman"
	MACAROON_STRINGS.MAGE = "Mage"
	MACAROON_STRINGS.WARLOCK = "Warlock"
	MACAROON_STRINGS.DEATHKNIGHT = "Death Knight"

else

	MACAROON_STRINGS.DRUID = "Druid"
	MACAROON_STRINGS.WARRIOR = "Warrior"
	MACAROON_STRINGS.ROGUE = "Rogue"
	MACAROON_STRINGS.PRIEST = "Priest"
	MACAROON_STRINGS.HUNTER = "Hunter"
	MACAROON_STRINGS.PALADIN = "Paladin"
	MACAROON_STRINGS.SHAMAN = "Shaman"
	MACAROON_STRINGS.MAGE = "Mage"
	MACAROON_STRINGS.WARLOCK = "Warlock"
	MACAROON_STRINGS.DEATHKNIGHT = "Death Knight"

end

BINDING_HEADER_MACAROON_BARS = "Macaroon"

end

MacaroonLocale.Macaroon.nlNL = load_localization

if ( GetLocale() == "nlNL" ) then
  load_localization()
end