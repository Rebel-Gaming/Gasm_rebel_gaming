﻿-- Traducido por Beo <Recios of Shen'dralar>
-- Para cualquier sugerencia o corrección: beogrog@gmail.com


local function load_localization()

MACAROON_STRINGS = {

	TITLE = "Macaroon!",
	DESC = "An unlimted number of highly configurable macro bars and buttons",

	SLASH1 = "/macaroon",
	SLASH2 = "/mac",

	SLASH_COMMAND_1 = "men\195\186",
	SLASH_COMMAND_1_DESC = "Abre el Men\195\186 Principal",
	SLASH_COMMAND_1_FUNC = "OpenMainMenu", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_2 = "crear",
	SLASH_COMMAND_2_DESC = "Crea una barra en blanco",
	SLASH_COMMAND_2_FUNC = "CreateNewBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_3 = "borrar",
	SLASH_COMMAND_3_DESC = "Borra la barra seleccionada",
	SLASH_COMMAND_3_FUNC = "DeleteBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_4 = "config",
	SLASH_COMMAND_4_DESC = "Cambia al modo configuración para todas las barras",
	SLASH_COMMAND_4_FUNC = "ConfigBars", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_5 = "a\195\177adir",
	SLASH_COMMAND_5_DESC = "A\195\177ade botones de la barra seleccionada (a\195\177adir o a\195\177adir #)",
	SLASH_COMMAND_5_FUNC = "AddButton", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_6 = "quitar",
	SLASH_COMMAND_6_DESC = "Quita botones de la barra seleccionada (quitar o quitar #)",
	SLASH_COMMAND_6_FUNC = "RemoveButton", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_7 = "edit",
	SLASH_COMMAND_7_DESC = "Cambia al modo edicion para todos los botones",
	SLASH_COMMAND_7_FUNC = "ButtonEdit", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_8 = "bind",
	SLASH_COMMAND_8_DESC = "Cambia al modo 'binding' para todos los botones",
	SLASH_COMMAND_8_FUNC = "ButtonBind", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_9 = "escala",
	SLASH_COMMAND_9_DESC = "Escala una barra al tama\195\177o deseado",
	SLASH_COMMAND_9_FUNC = "ScaleBar", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_10 = "snapto",
	SLASH_COMMAND_10_DESC = "Cambia la alineaci\195\179n de la barra activa",
	SLASH_COMMAND_10_FUNC = "SnapToBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_11 = "aocultar",
	SLASH_COMMAND_11_DESC = "Cambia a auto-ocultado la barra activa",
	SLASH_COMMAND_11_FUNC = "AutohideBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_12 = "ocultar",
	SLASH_COMMAND_12_DESC = "Cambia esta barra entre visible y oculta",
	SLASH_COMMAND_12_FUNC = "HideBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_13 = "forma",
	SLASH_COMMAND_13_DESC = "Cambia la forma de la barra activa",
	SLASH_COMMAND_13_FUNC = "ShapeBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_14 = "nombre",
	SLASH_COMMAND_14_DESC = "Cambia el nombre de la barra activa",
	SLASH_COMMAND_14_FUNC = "NameBar",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_15 = "estrato",
	SLASH_COMMAND_15_DESC = "Cambia el estrato de la barra activa",
	SLASH_COMMAND_15_FUNC = "StrataSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_16 = "alpha",
	SLASH_COMMAND_16_DESC = "Cambia el alpha de la barra activa (transparencia)",
	SLASH_COMMAND_16_FUNC = "AlphaSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_17 = "alphaup",
	SLASH_COMMAND_17_DESC = "Establece las condiciones para 'alpha up'",
	SLASH_COMMAND_17_FUNC = "AlphaUpSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_18 = "arcini",
	SLASH_COMMAND_18_DESC = "Establece el inicio del arco de la barra activa (en grados)",
	SLASH_COMMAND_18_FUNC = "ArcStartSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_19 = "arclong",
	SLASH_COMMAND_19_DESC = "Establece la longitud del arco de la barra activa (en grados)",
	SLASH_COMMAND_19_FUNC = "ArcLengthSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_20 = "columnas",
	SLASH_COMMAND_20_DESC = "Establece el n\195\186mero de columnas de la barra activa (para forma Multi-Columna)",
	SLASH_COMMAND_20_FUNC = "ColumnsSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_21 = "padh",
	SLASH_COMMAND_21_DESC = "Establece el relleno (padding) horizontal de la barra activa",
	SLASH_COMMAND_21_FUNC = "PadHSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_22 = "padv",
	SLASH_COMMAND_22_DESC = "Establece el relleno (padding) vertical de la barra activa",
	SLASH_COMMAND_22_FUNC = "PadVSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_23 = "padhv",
	SLASH_COMMAND_23_DESC = "Aumenta o disminuye el relleno (padding) tanto horizontal como vertical de la barra activa",
	SLASH_COMMAND_23_FUNC = "PadHVSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_24 = "rejilla",
	SLASH_COMMAND_24_DESC = "Muestra u oculta la rejilla de la barra activa",
	SLASH_COMMAND_24_FUNC = "ShowgridSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_25 = "x",
	SLASH_COMMAND_25_DESC = "Cambia la posicion horizontal de la barra activa",
	SLASH_COMMAND_25_FUNC = "XAxisSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_26 = "y",
	SLASH_COMMAND_26_DESC = "Cambia la posicion vertical de la barra activa",
	SLASH_COMMAND_26_FUNC = "YAxisSet",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_27 = "estancia",
	SLASH_COMMAND_27_DESC = "Cambia las entancias de la barra activa (/mac state <state>). Escribe '/mac lestancias' para ver la estancias v\195\161lidas.",
	SLASH_COMMAND_27_FUNC = "SetBarStates",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_28 = "lestancias",
	SLASH_COMMAND_28_DESC = "Muestra una lista con las estancias v\195\161lidas",
	SLASH_COMMAND_28_FUNC = "PrintStateList",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_29 = "candado",
	SLASH_COMMAND_29_DESC = "Activa o desactiva el candado de botones",
	SLASH_COMMAND_29_FUNC = "ButtonLock",	 -- function call, do not tranlsate, leave in English
	SLASH_COMMAND_30 = "load",
	SLASH_COMMAND_30_DESC = "Load a profile",
	SLASH_COMMAND_30_FUNC = "LoadFromProfile",	 -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_31 = "storage",
	SLASH_COMMAND_31_DESC = "Open the button storage area",
	SLASH_COMMAND_31_FUNC = "OpenStorage", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_32 = "profiles",
	SLASH_COMMAND_32_DESC = "Open Profile Options",
	SLASH_COMMAND_32_FUNC = "OpenProfiles", -- function call, do not tranlsate, leave in English

	SLASH_COMMAND_33 = "timerlimit",
	SLASH_COMMAND_33_DESC = "Sets the minimum time in seconds to show on text timers",
	SLASH_COMMAND_33_FUNC = "SetTimerLimit", -- function call, do not tranlsate, leave in English

	SLASH_HINT1 = "\n/macaroon or /mac |cff00ff00<command>|r",
	SLASH_HINT2 = "\nCommand List -\n",

	BAR_SNAPTO_DISABLED = "SnapTo desactivado para ",
	BAR_SNAPTO_ENABLED = "SnapTo activado para ",
	BAR_SHOWGRID_DISABLED = "Rejilla desactivada para	 ",
	BAR_SHOWGRID_ENABLED = "Rejilla activada para ",
	BAR_HIDDEN_DISABLED	= "Barra actual visible",
	BAR_HIDDEN_ENABLED	= "Barra actual oculta",
	BAR_DUALSPEC_DISABLED = "DualSpec disabled for ",
	BAR_DUALSPEC_ENABLED = "DualSpec enabled for ",
	BAR_SHAPES = "\n1=Horizontal\n2=Vertical\n3=Multi-Columna\n4=C\195\173rculo\n5=C\195\173rculo+Uno",
	BAR_STRATAS = "\n1=FONDO\n2=BAJO\n3=MEDIO\n4=ALTO\n5=DIALOGO",
	BAR_ALPHA = "El valor del alpha debe estar entre cero(0) y uno(1)",
	BAR_ARCSTART = "El inicio del arco debe estar entre 0 y 359",
	BAR_ARCLENGTH = "La longitud del arco debe estar entre 0 y 359",
	BAR_COLUMNS = "Introduce el n\195\186mero de columnas deseadas para esta barra, mayor que cero(0)",
	BAR_PADH = "Introduce un n\195\186mero para el relleno (padding) horizontal deseado",
	BAR_PADV = "Introduce un n\195\186mero para el relleno (padding) vertical deseado",
	BAR_PADHV = "Introduce un n\195\186mero para aumentar o disminuir el relleno (padding) tanto horizontal como vertical",

	INVALID_CHOICE = "Opci\195\179n no v\195\161lida",
	INVALID_STATE = "Estancia no v\195\161lida",
	NO_BAR_SELECTED = "No hay ninguna barra seleccionada",

	OPT1 = "Opt1:",
	VALUE = "Valor:",
	APPLY = "Aplicar",
	COPY = "Copiar",
	DONE = "Dismiss",
	DELETE = "Borrar",
	CHARGES = "Cargar",

	CREATE_BUTTON = "Crear Bot\195\179n",
	DELETE_BUTTON = "Borrar Bot\195\179n",
	STORED_BUTTONS = "Number of stored buttons:",
	OVERFLOW = "Storage Overflow:",
	LOCKROW = "Lock Row",

	MACRO_EDIT = "Editor de Macros",
	MACRO_NAME = "-nombre de macro-",
	MACRO_MASTER = "Macro Master",
	MACRO_EDITNOTE = "Click aqu\195\173 para editar la nota de la macro",
	MACRO_ICON = "Click para cambiar el icono",
	MACRO_EXPAND = "Expandir",
	ACTION_EDIT = "Editor de ID de acci\195\179n",
	ACTION_PROP = "Propagar ID de acci\195\179n en la Barra  ",

	BUTTON_OPTIONS = "Opciones de bot\195\179n",

	CLICK_ANCHOR = "Click Anchor",
	MOUSE_ANCHOR = "Mouse Anchor",
	ANCHOR_DELAY = "Delay: ",

	BTNOPTION_EDIT_BUTTON_1 = "Scale",
	BTNOPTION_EDIT_BUTTON_2 = "X Offset",
	BTNOPTION_EDIT_BUTTON_3 = "Y Offset",

	BTNOPTION_EDIT_CHECK_1 = "Up Clicks",
	BTNOPTION_EDIT_CHECK_2 = "Down Clicks",
	BTNOPTION_EDIT_CHECK_3 = "Spell Counts",
	BTNOPTION_EDIT_CHECK_4 = "Combo Counts",

	BAR_EDIT_ADD = "A\195\177adir",
	BAR_EDIT_REMOVE = "Borrar",
	BAR_EDIT_BARLINK = "Enlace Barra",
	BAR_EDIT_NAME = "Nombre Barra",

	BAR_EDIT_BUTTON_1 = "Escala",
	BAR_EDIT_BUTTON_2 = "Forma",
	BAR_EDIT_BUTTON_3 = "Columnas",
	BAR_EDIT_BUTTON_4 = "Estrato",
	BAR_EDIT_BUTTON_5 = "Alpha",
	BAR_EDIT_BUTTON_6 = "AlphaUp",
	BAR_EDIT_BUTTON_7 = "Inicio del Arco",
	BAR_EDIT_BUTTON_8 = "Longitud del Arco",
	BAR_EDIT_BUTTON_9 = "Arco Preset",
	BAR_EDIT_BUTTON_10 = "Pad Horz",
	BAR_EDIT_BUTTON_11 = "Pad Vert",
	BAR_EDIT_BUTTON_12 = "Pad Horz+Vert",
	BAR_EDIT_BUTTON_13 = "Botones",

	BAR_MESSAGE = "Click Izquierdo/Derecho/Rueda de Rat\195\179n para ajustar: |cffffffff",

	BAR_EDIT_BUTTON_TEXT_1 = "escala",
	BAR_EDIT_BUTTON_TEXT_2 = "forma",
	BAR_EDIT_BUTTON_TEXT_3 = "n\195\186mero de columnas",
	BAR_EDIT_BUTTON_TEXT_4 = "estrato del marco",
	BAR_EDIT_BUTTON_TEXT_5 = "alpha (transparencia)",
	BAR_EDIT_BUTTON_TEXT_6 = "condici\195\179n para \'alpha-up\'",
	BAR_EDIT_BUTTON_TEXT_7 = "punto de inicio del arco",
	BAR_EDIT_BUTTON_TEXT_8 = "longitud del arco",
	BAR_EDIT_BUTTON_TEXT_9 = "arco preset y forma",
	BAR_EDIT_BUTTON_TEXT_10 = "relleno (padding) horizontal",
	BAR_EDIT_BUTTON_TEXT_11 = "relleno (padding) vertical",
	BAR_EDIT_BUTTON_TEXT_12 = "relleno (padding) vertical y horizontal",
	BAR_EDIT_BUTTON_TEXT_13 = "Botones",

	CHECK_101 = "Barra Principal de Blizzard",
	CHECK_102 = "Tooltips en botones",
	CHECK_103 = "Tooltips en Combate",
	CHECK_104 = "Ver texto en teclas bindeadas",
	CHECK_105 = "Activar texto en macros",
	CHECK_106 = "Activar texto de contador",
	CHECK_107 = "Bot\195\179n der+arratre para copiar",
	CHECK_108 = "Permitir al addon mover bolsas",
	CHECK_109 = "Candado de Botones",
	CHECK_110 = "Shift+Arrastre",
	CHECK_111 = "Control+Arrastre",
	CHECK_112 = "Alt+Arrastre",
	CHECK_113 = "Texto de temporizadores de CD",
	CHECK_114 = "Texto de temp. de Buff/Debuff",
	CHECK_115 = "Sobresalte de Buff/Debuff",
	CHECK_116 = "Enable Button Down Clicks", --ver en contexto
	CHECK_117 = "Enable Blizzard Vehicle Bar",

	SLIDER_1 = "Posici\195\179n X de Bolsa",
	SLIDER_2 = "Posici\195\179n Y de Bolsa",
	SLIDER_3 = "Escala de Bolsa",
	SLIDER_4 = "Espacio libre ideal de Bolsa",
	SLIDER_5 = "Cooldown Alpha",
	SLIDER_6 = "Alpha de Autocast de Mascota",
	SLIDER_7 = "Desvanecimiento de Alpha-Up",
	SLIDER_8 = "Tolerancia de SnapTo",

	FLOAT_EDITORS = "Editores Flotantes",
	ANIMATED = "Menus Animados",
	DUALSPEC = "Enable Dual Spec",
	BEGINNER = "Beginner Tooltips",

	CHECK_MACRO = "Usar nota \nas tooltip ",

	EMPTY_BUTTON = "Bot\195\179n Vac\195\173o",

        MINIMAP_CHECK = "Bot\195\179n de Minimapa",
	MINIMAP_TOOLTIP0 = "Macaroon\n",
	MINIMAP_TOOLTIP1 = "|cffffffffClick-Derecho|r para mini-men\195\186\n\n|cffffffffClick-Izquierdo|r para cambiar a edici\195\179n de barra\n|cffffffffShift-Click|r para cambiar abrir/cerrar candado\n|cffffffffAlt-Click|r para cambiar a edici\195\179n de bot\195\179n\n|cffffffffCtrl-Click|r para abrir el men\195\186 principal\n\n|cffffffff/mac|r para opciones de l\195\173nea de comandos",
	MINIMAP_TOOLTIP2 = "\nCandado de Botones: ",

	MINIMAP_ACTION_1 = "Button Lock",
	MINIMAP_ACTION_1_FUNC = "ButtonLock", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_2 = "Button Edit",
	MINIMAP_ACTION_2_FUNC = "ButtonEdit", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_3 = "Bar Edit",
	MINIMAP_ACTION_3_FUNC = "ConfigBars", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_4 = "Bind Edit",
	MINIMAP_ACTION_4_FUNC = "ButtonBind", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_5 = "Men\195\186 Principal",
	MINIMAP_ACTION_5_FUNC = "OpenMainMenu",
	MINIMAP_ACTION_6 = " Crear Barra\n",
	MINIMAP_ACTION_6_FUNC = "CreateNewBar", -- function call, do not tranlsate, leave in English
	MINIMAP_ACTION_6_ARG = "bar", -- function args, do not tranlsate, leave in English
	MINIMAP_ACTION_7 = " Borrar Barra\n",
	MINIMAP_ACTION_7_FUNC = "DeleteBar", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_8 = "» Close «",
	MINIMAP_ACTION_8_FUNC = "MinimapMenuClose", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_9 = "Storage",
	MINIMAP_ACTION_9_FUNC = "OpenStorage", -- function call, do not tranlsate, leave in English
 	MINIMAP_ACTION_10 = "Profiles",
	MINIMAP_ACTION_10_FUNC = "OpenProfiles", -- function call, do not tranlsate, leave in English

	BINDFRAME_BIND = "bindeado",
	BINDFRAME_LOCKED = "cerrado",
	BINDFRAME_PRIORITY = "priority",

	BINDINGS_LOCKED	= "Candado de bot\195\179n cerrado.\nClick-Izquierdo para abrir candado.",

	BARTOOLTIP_1 = "Activo",
	BARTOOLTIP_2 = "Desactivo",
	BARTOOLTIP_3 = "Escala: ",
	BARTOOLTIP_4 = "Estrato: ",
	BARTOOLTIP_5 = "Alpha: ",
	BARTOOLTIP_6 = "AlphaUp: ",
	BARTOOLTIP_7 = "Forma: ",
	BARTOOLTIP_8 = "Columnas: ",
	BARTOOLTIP_9 = "ArcoI: ",
	BARTOOLTIP_10 = "ArcoL: ",
	BARTOOLTIP_11 = "PadH: ",
	BARTOOLTIP_12 = "PadV: ",
	BARTOOLTIP_13 = "SnapTo: ",
	BARTOOLTIP_14 = "Rejilla: ",
	BARTOOLTIP_15 = "AutoOcultado: ",
	BARTOOLTIP_16 = "Objetivo: ",
	BARTOOLTIP_17 = "|cffffffffEstancia Actual: |r",
	BARTOOLTIP_18 = "|cffffffffEstancias Activas: |r",
	BARTOOLTIP_19 = "|cffffffffBotones: |r",
	BARTOOLTIP_20 = "Punto: ",
	BARTOOLTIP_21 = "  x:",
	BARTOOLTIP_22 = "  y:",

	BARTOOLTIP_23 = "|cff00ff00Barra Actual|r",

	BARTOOLTIP_24 = "\n|cffffffffClick-Izquierdo|r Para rotar entre las estancias activas",
	BARTOOLTIP_25 = "\n|cffffffffClick-Izquierdo|r para seleccionar Barra",

	BARTOOLTIP_26 = "|cffffffffClick-Derecho|r para cambiar a Editor de Barra",
	BARTOOLTIP_27 = "|cffffffffClick-Central|r para cambiar a estancia oculta",
	BARTOOLTIP_275 = "|cffffffffShift-Click|r to adjust position using arrow keys",

	BARTOOLTIP_28 = "|cffffffffClick-Izquierdo|r para aumentar el valor actual",
	BARTOOLTIP_29 = "|cffffffffClick-Detrecho|r para disminuir el valor actual",
	BARTOOLTIP_30 = "|cffffffffRueda de Rat\195\179n|r para aumentar/disminuir el valor actual",
	BARTOOLTIP_31 = "\nTo leave value edit mode: |cffffffffMiddle-Click|r\n  or move |cffffffffmouse|r out of bar frame", -- ver en contexto


	KEYBIND_TOOLTIP1 = "\nPresiona una tecla para 'bindearla' a |cff00ff00%s ",
	KEYBIND_TOOLTIP2 = "Click-Izquierdo para to lock this %s's bindings\nHit |cfff00000ESC|r to clear this %s's current binding(s)", --ver en contexto
	KEYBIND_TOOLTIP3 = "|cffffffffCurrent Binding(s): |r|cff00ff00", --ver en contexto
	KEYBIND_NONE = "vac\195\173o",

	BUTTONEDIT_TOOLTIP1 = "Click-Izquierdo para cambiar el tipo de bot\195\179n\nClick-Derecho para Editar |cff00ff00Bot\195\179n ",
	BUTTONEDIT_TOOLTIP2 = " para rotar entre los tipos de boton",

	BARSHAPE_1 = "Linear",
	BARSHAPE_2 = "C\195\173rculo",
	BARSHAPE_3 = "C\195\173rculo + Uno",

	BARSTATE_1 = "PagedBarra",
	BARSTATE_2 = "Estancia",
	BARSTATE_3 = "Mascota",
	BARSTATE_4 = "Control Bar",
	BARSTATE_5 = "Sigilo",
	BARSTATE_6 = "Reacci\195\179n",
	BARSTATE_7 = "Combate",
	BARSTATE_8 = "Grupo",
	BARSTATE_9 = "TeclaAlt",
	BARSTATE_10 = "TeclaCtrl",
	BARSTATE_11 = "TeclaShift",
	BARSTATE_12 = "Personalizado",

	BARSTATE_AH = "AutoOcultar",
	BARSTATE_SG = "Rejilla",
	BARSTATE_ST = "SnapTo",
	BARSTATE_HD = "Oculto",
	BARSTATE_DS = "Dual Spec",

	TEXTEDIT_NAME = "Nombre:",
        TEXTEDIT_TARGET = "Objetivo:",
        TEXTEDIT_LSTATE = "Estancia:",
        TEXTEDIT_LTO = "Enlazado a:",
        TEXTEDIT_BSTATE = "Estancia:",
        TEXTEDIT_REMAP = "Remap a:",
        TEXTEDIT_CUSTOM = "E. Personalizadas:",

	ALPHAUP_NONE = "vac\195\173o",
	ALPHAUP_BATTLE = "Batalla",
	ALPHAUP_MOUSEOVER = "Puntero",
	ALPHAUP_BATTLEMOUSE = "Batalla+Puntero",
	ALPHAUP_RETREAT = "Retreat", --ver en contexto
	ALPHAUP_RETREATMOUSE = "Retreat+Puntero",  -- ver en contexto

	ARC_PRESET_1 = "Arco Superior",
	ARC_PRESET_2 = "Arco Inferior",
	ARC_PRESET_3 = "Arco Izquierdo",
	ARC_PRESET_4 = "Arco Derecho",
	ARC_PRESET_5 = "C\195\173rculo Completo",

	STATES = {
		homestate = "Normal",
		laststate = "Should not see!", --ver en contexto
		pagedbar1 = "P\195\161gina 1",
		pagedbar2 = "P\195\161gina 2",
		pagedbar3 = "P\195\161gina 3",
		pagedbar4 = "P\195\161gina 4",
		pagedbar5 = "P\195\161gina 5",
		pagedbar6 = "P\195\161gina 6",
		stance0 = "Estancia 0",
		companion0 = "Sin Mascota",
		companion1 = "Mascota",
		stealth1 = "Sigilo",
		reaction1 = "Host\195\173l",
		combat1 = "Batalla",
		group1 = "Gr\195\186po: Banda",
		group2 = "Gr\195\186po: Gr\195\186po",
		control1 = "Controls: Vehicle/Possess",
		possess1 = "Posesi\195\179n",
		vehicle1 = "Vehicle",
		alt1 = "Alt Down", --Ver en contexto
		ctrl1 = "Control Down",  --Ver en contexto
		shift1 = "Shift Down",    --Ver en contexto
		custom = "Estancia personalizada",
	},

	--class specific state names
	DRUID_STANCE0 = "Forma de Caster",
	DRUID_PROWL = "Acecho",
	PRIEST_HEALER = "Forma de Sanador",
	ROGUE_ATTACK = "Atacar",
	WARLOCK_CASTER = "Forma de Caster",

	PETATTACK = "Atacar",
	PETFOLLOW = "Segu\195\173r",
	PETSTAY = "Permanecer",
	PETAGGRESSIVE = "Agresiva",
	PETDEFENSIVE = "Defensiva",
	PETPASSIVE = "Pasiva",

	CUSTOM_OPTION = "\n\nPara la estancias personalizadas, a\195\177ade la cadena de estancia deseada (/mac state custom <state string>) donde <state string> es una lista de condiciones de estancias separadas por una coma\n\n|cff00ff00Ejemplo:|r [actionbar:1];[stance:1];[stance3,stealth];[mounted]\n\n|cff00ff00Nota:|r la primera estancia listada sera considerada la \"home state\". Si el editor de estancias no entendiera esta cadena, esta estancia ser\195\173a considerada por defecto.",

}

-- Some languages Blizzard is now making a distinction on class names based on gender.
if (UnitSex("player") == 2) then

	MACAROON_STRINGS.DRUID = "Druida"
	MACAROON_STRINGS.WARRIOR = "Guerrero"
	MACAROON_STRINGS.ROGUE = "P\195\173caro"
	MACAROON_STRINGS.PRIEST = "Sacerdote"
	MACAROON_STRINGS.HUNTER = "Cazador"
	MACAROON_STRINGS.PALADIN = "Palad\195\173n"
	MACAROON_STRINGS.SHAMAN = "Cham\195\161n"
	MACAROON_STRINGS.MAGE = "Mago"
	MACAROON_STRINGS.WARLOCK = "Brujo"
	MACAROON_STRINGS.DEATHKNIGHT = "Death Knight"

else

	MACAROON_STRINGS.DRUID = "Druida"
	MACAROON_STRINGS.WARRIOR = "Guerrera"
	MACAROON_STRINGS.ROGUE = "P\195\173cara"
	MACAROON_STRINGS.PRIEST = "Sacerdotisa"
	MACAROON_STRINGS.HUNTER = "Cazadora"
	MACAROON_STRINGS.PALADIN = "Palad\195\173n"
	MACAROON_STRINGS.SHAMAN = "Cham\195\161n"
	MACAROON_STRINGS.MAGE = "Maga"
	MACAROON_STRINGS.WARLOCK = "Bruja"
	MACAROON_STRINGS.DEATHKNIGHT = "Death Knight"

end

BINDING_HEADER_MACAROON_BARS = "Macaroon"

end

MacaroonLocale.Macaroon.esES = load_localization

if ( GetLocale() == "esES" ) then
  load_localization()
end