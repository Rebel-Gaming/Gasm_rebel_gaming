﻿--Macaroon, a World of Warcraft® user interface addon.
--Copyright© 2009 Connor H. Chenoweth, aka Maul - All rights reserved.
--License is given to copy, distribute and to make derivative works.

local bindMode, ss = false

local find = string.find
local match = string.match
local lower = string.lower
local gsub = string.gsub

local spellIndex = Macaroon.spellIndex
local MACAROON_STRINGS = MACAROON_STRINGS

local function getModifier()

	local modifier

	if (IsAltKeyDown()) then
		modifier = "ALT-"
	end

	if (IsControlKeyDown()) then
		if (modifier) then
			modifier = modifier.."CTRL-";
		else
			modifier = "CTRL-";
		end
	end

	if (IsShiftKeyDown()) then
		if (modifier) then
			modifier = modifier.."SHIFT-";
		else
			modifier = "SHIFT-";
		end
	end

	return modifier
end

local function getBindkeyList(button)

	if (not button.config) then return MACAROON_STRINGS.KEYBIND_NONE end

	local bindkeys = gsub(button.config.hotKeyText, ":", ", ")

	bindkeys = gsub(bindkeys, "^, ", "")
	bindkeys = gsub(bindkeys, ", $", "")

	if (strlen(bindkeys) < 1) then
		bindkeys = MACAROON_STRINGS.KEYBIND_NONE
	end

	return bindkeys
end

local function setBindframeTooltip(bindFrame, button)

	GameTooltip:SetOwner(bindFrame, "ANCHOR_RIGHT")

	if (bindFrame.bindType == "button") then

		if (button.config.type == "action") then

			local action = button.config.action

			if (action and action ~= "") then
				GameTooltip:SetAction(action)
			else
				GameTooltip:SetText(MACAROON_STRINGS.EMPTY_BUTTON)
			end

		elseif (button.config.type == "macro") then

			local spell, item, link = button.macrospell, button.macroitem

			spell = lower(spell or "")

			if (spell and spell ~= "") then

				if (spellIndex[spell]) then

					GameTooltip:SetSpell(spellIndex[spell][1], spellIndex[spell][4])

				elseif (type(button.config.macroIcon) == "table") then

					GameTooltip:SetHyperlink("spell:"..button.config.macroIcon[5])
				end

			elseif (item and item ~= "") then

				_, link = GetItemInfo(item)

				if (link) then
					GameTooltip:SetHyperlink(link)
				end
			else
				if (strlen(button.config.macro) > 0) then
					GameTooltip:SetText(button.config.macro)
				else
					GameTooltip:SetText(MACAROON_STRINGS.EMPTY_BUTTON)
				end
			end

		elseif (button.config.type == "pet") then

			local action = button.config.action

			if (button.isToken or not button.UberTooltips) then

				if (button.tooltipName) then
					GameTooltip:SetText(button.tooltipName, 1.0, 1.0, 1.0)

				end

				if ( button.tooltipSubtext ) then
					GameTooltip:AddLine(button.tooltipSubtext, "", 0.5, 0.5, 0.5)
				end
			else

				GameTooltip:SetPetAction(action)
			end

		end

		if (ss.checkButtons[205]) then
			GameTooltip:AddLine(format(MACAROON_STRINGS.KEYBIND_TOOLTIP1, bindFrame.bindType..button.id).."|r", 1.0, 1.0, 1.0)
			GameTooltip:AddLine(format(MACAROON_STRINGS.KEYBIND_TOOLTIP2, bindFrame.bindType, bindFrame.bindType), 1.0, 1.0, 1.0)
		end
		GameTooltip:AddLine(MACAROON_STRINGS.KEYBIND_TOOLTIP3..getBindkeyList(button).."|r")

	elseif (bindFrame.bindType == "spell") then

		if (_G[bindFrame:GetParent():GetName().."IconTexture"]:IsVisible()) then
			local id = SpellBook_GetSpellID(bindFrame:GetID())
			GameTooltip:SetSpell(id, SpellBookFrame.bookType)
		end

		local button = { config = bindFrame.bindTable[bindFrame[bindFrame.bindType]] }

		if (ss.checkButtons[205]) then
			GameTooltip:AddLine(format(MACAROON_STRINGS.KEYBIND_TOOLTIP1, bindFrame.bindType).."|r", 1.0, 1.0, 1.0)
			GameTooltip:AddLine(format(MACAROON_STRINGS.KEYBIND_TOOLTIP2, bindFrame.bindType, bindFrame.bindType), 1.0, 1.0, 1.0)
		end
		GameTooltip:AddLine(MACAROON_STRINGS.KEYBIND_TOOLTIP3..getBindkeyList(button).."|r")

	elseif (bindFrame.bindType == "macro") then

		local name, _, body, _ = GetMacroInfo(MacroFrame.macroBase + bindFrame:GetID())
		if (name and body) then
			name = "|cffffffff"..name.."|r"
			GameTooltip:AddLine(name.."\n\n"..body)
		end

		local button = { config = bindFrame.bindTable[bindFrame[bindFrame.bindType]] }

		if (ss.checkButtons[205]) then
			GameTooltip:AddLine(format(MACAROON_STRINGS.KEYBIND_TOOLTIP1, bindFrame.bindType).."|r", 1.0, 1.0, 1.0)
			GameTooltip:AddLine(format(MACAROON_STRINGS.KEYBIND_TOOLTIP2, bindFrame.bindType, bindFrame.bindType), 1.0, 1.0, 1.0)
		end
		GameTooltip:AddLine(MACAROON_STRINGS.KEYBIND_TOOLTIP3..getBindkeyList(button).."|r")
	end

	GameTooltip:Show()
end

function Macaroon.ButtonBind(off)

	if (not off) then
		--Macaroon.ConfigBars(true)
		Macaroon.ButtonEdit(true)
	end

	if (not bindMode and off) then
		return
	end

	if (bindMode or off) then

		bindMode = false

		for k,v in pairs(Macaroon.Buttons) do

			v[1].bindframe:Hide()
			v[1].bindframe:SetFrameStrata("LOW")

			v[1].editmode = false
		end

		MacaroonButtonEditor:Hide()

		if (not off) then

			for k,v in pairs(Macaroon.BarIndex) do
				v.updateBarTarget(v)
				v.updateBarLink(v)
				v.updateBarHidden(v)
			end

			for k,v in pairs(Macaroon.HideGrids) do
				v(nil, nil, true)
			end
		end

		Macaroon.Save()

		collectgarbage()

	else

		bindMode = true

		for k,v in pairs(Macaroon.Buttons) do

			v[1].bindframe:Show()
			v[1].bindframe:SetFrameStrata(v[1].bar:GetFrameStrata())
			v[1].bindframe:SetFrameLevel(v[1].bar:GetFrameLevel()+4)

			v[1].editmode = true
		end

		if (not off) then

			for k,v in pairs(Macaroon.BarIndex) do
				v.updateBarHidden(v, true)
				v.updateBarTarget(v, true)
			end

			for k,v in pairs(Macaroon.ShowGrids) do
				v(nil, nil, true)
			end
		end
	end
end

function Macaroon.BindFrame_OnLoad(self)

	self:EnableMouseWheel(true)
	self:RegisterForClicks("AnyUp")
	self:RegisterForClicks("AnyDown")
	self:Hide()
	self:SetFrameLevel(6)
	self.action = "action"
	self.type = _G[self:GetName().."Type"]
end

function Macaroon.BindFrame_OnClick(self, action, down, button)

	if (action == "LeftButton") then

		if (self.bindType == "spell") then



		elseif (self.bindType == "macro") then



		elseif (self.bindType == "button") then

			if (button.config.hotKeyLock) then
				button.config.hotKeyLock = false
			else
				button.config.hotKeyLock = true
			end
		end

		Macaroon.BindFrame_OnShow(self, button)

		return
	end

	if (action == "RightButton") then

		if (self.bindType == "spell") then



		elseif (self.bindType == "macro") then



		elseif (self.bindType == "button") then

			if (button.config.hotKeyPri) then
				button.config.hotKeyPri = false
			else
				button.config.hotKeyPri = true
			end

			Macaroon.ApplyBindings(button)
		end

		Macaroon.BindFrame_OnShow(self, button)

		return
	end

	local modifier, key = getModifier()

	if (action == "MiddleButton") then
		key = "BUTTON3"
	elseif (action == "Button4") then
		key = "BUTTON4"
	elseif (action == "Button5") then
		key = "BUTTON5"
	else
		key = action
	end

	if (modifier) then
		key = modifier..key
	end

	Macaroon.ProcessBinding(self, key, button)

end

function Macaroon.BindFrame_OnShow(self, button)

	if (self.bindType == "spell") then



	elseif (self.bindType == "macro") then



	elseif (self.bindType == "button") then

		local priority = ""

		if (button.config.hotKeyPri) then
			priority = "|cff00ff00"..MACAROON_STRINGS.BINDFRAME_PRIORITY.."|r\n"
		end

		if (button.config.hotKeyLock) then
			self.type:SetText(priority.."|cfff00000"..MACAROON_STRINGS.BINDFRAME_LOCKED.."|r")
		else
			self.type:SetText(priority.."|cffffffff"..MACAROON_STRINGS.BINDFRAME_BIND.."|r")
		end
	end
end

function Macaroon.BindFrame_OnMouseWheel(self, delta, button)

	local modifier, key, action = getModifier()

	if (delta > 0) then
		key = "MOUSEWHEELUP"
		action = "MousewheelUp"
	else
		key = "MOUSEWHEELDOWN"
		action = "MousewheelDown"
	end

	if (modifier) then
		key = modifier..key
	end

	Macaroon.ProcessBinding(self, key, button)

end

function Macaroon.BindFrame_OnKeyDown(self, key, button)

	if (find(key,"ALT") or find(key,"SHIFT") or find(key,"CTRL") or find(key, "PRINTSCREEN")) then
		return
	end

	local modifier = getModifier()

	if (modifier) then
		key = modifier..key
	end

	Macaroon.ProcessBinding(self, key, button)
end

function Macaroon.BindFrame_OnEnter(self, button)

	MacaroonButtonEditSelect:SetScale(button:GetEffectiveScale())

	MacaroonButtonEditSelect:SetFrameStrata(self:GetFrameStrata())

	MacaroonButtonEditSelect:SetFrameLevel(self:GetFrameLevel()+1)

	MacaroonButtonEditSelect:SetPoint("TOPLEFT", button, "TOPLEFT")

	MacaroonButtonEditSelect:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT")

	MacaroonButtonEditSelect:Show()

	setBindframeTooltip(self, button)
end

function Macaroon.BindFrame_OnLeave(self, button)

	MacaroonButtonEditSelect:Hide()

	self.UpdateTooltip = nil

	GameTooltip:Hide()
end

function Macaroon.BindFrame_OnUpdate(self, elapsed)

	if (self:IsMouseOver()) then
		self:EnableKeyboard(true)
	else
		self:EnableKeyboard(false)
	end
end

function Macaroon.ProcessBinding(self, key, button)

	if (self[self.bindType]) then

		if (not self.bindTable[self[self.bindType]]) then
			self.bindTable[self[self.bindType]] = { hotKeys = ":", hotKeyText = ":", hotKeyLock = false }
		end

		button = { config = self.bindTable[self[self.bindType]] }
	end

	if (button and button.config and button.config.hotKeyLock) then
		MacaroonMessageFrame:AddMessage(MACAROON_STRINGS.BINDINGS_LOCKED, 1.0, 1.0, 1.0, 1.0, UIERRORS_HOLD_TIME)
		return
	end

	if (key == "ESCAPE") then

		if (self.bindType == "spell") then

			Macaroon.ClearSpellBinding(self[self.bindType])

		elseif (self.bindType == "macro") then

			Macaroon.ClearMacroBinding(self[self.bindType])

		elseif (self.bindType == "button") then

			local found

			for index,btn in pairs(Macaroon.Buttons) do

				if (button ~= btn[1] and not btn[1].config.hotKeyLock) then

					found = false

					if (btn[1]:GetAttribute("showstates")) then

						for showstate in gmatch(btn[1]:GetAttribute("showstates"), "[^;]+") do

							if (find(button:GetAttribute("showstates"), showstate)) then

								found = true
							end
						end

						if (not found and button.config.barPos == btn[1].config.barPos) then
							Macaroon.ClearBindings(btn[1])
						end
					end
				end
			end

			Macaroon.ClearBindings(button)
		end

	elseif (key) then

		for index,btn in pairs(Macaroon.Buttons) do

			if (button ~= btn[1] and not btn[1].config.hotKeyLock) then

				if (button.bar ~= btn[1].bar) then

					gsub(btn[1].config.hotKeys, "[^:]+", function(binding)

						if (key == binding) then

							Macaroon.ClearBindings(btn[1], binding)
							Macaroon.ApplyBindings(btn[1])
						end

					end)

				else
					for showstate in gmatch(btn[1]:GetAttribute("showstates"), "[^;]+") do

						if (find(button:GetAttribute("showstates"), showstate)) then

							gsub(btn[1].config.hotKeys, "[^:]+", function(binding)

								if (key == binding) then

									Macaroon.ClearBindings(btn[1], binding)
									Macaroon.ApplyBindings(btn[1])
								end
							end)
						else
							if (button.config.barPos == btn[1].config.barPos) then
								Macaroon.SetBinding(btn[1], key)
							end
						end
					end
				end
			end
		end

		if (MacaroonBoundSavedState) then

			for k,v in pairs(MacaroonBoundSavedState.spells) do

				gsub(v.hotKeys, "[^:]+", function(binding)
					if (key == binding) then
						Macaroon.ClearSpellBinding(k, binding)
					end
				end)
			end

			for k,v in pairs(MacaroonBoundSavedState.macros) do

				gsub(v.hotKeys, "[^:]+", function(binding)
					if (key == binding) then
						Macaroon.ClearMacroBinding(k, binding)
					end
				end)
			end
		end

		if (self.bindType == "spell") then

			Macaroon.SetSpellBinding(self[self.bindType], key)

		elseif (self.bindType == "macro") then

			Macaroon.SetMacroBinding(self[self.bindType], key)

		elseif (self.bindType == "button") then

			Macaroon.SetBinding(button, key)
		end
	end

	if (self:IsVisible()) then
		setBindframeTooltip(self, button)
	end
end

function Macaroon.SetBinding(button, key)

	local found = false

	gsub(button.config.hotKeys, "[^:]+", function(binding) if(binding == key) then found = true end end)

	if (not found) then

		local keytext = Macaroon.GetKeyText(key)

		button.config.hotKeys = button.config.hotKeys..key..":"
		button.config.hotKeyText = button.config.hotKeyText..keytext..":"
	end

	Macaroon.ApplyBindings(button)
end

function Macaroon.SetSpellBinding(spell, key)

	local bound, found = MacaroonBoundSavedState.spells[spell]

	if (bound) then
		gsub(bound.hotKeys, "[^:]+", function(binding) if(binding == key) then found = true end end)
	end

	if (not found and bound) then

		local keytext = Macaroon.GetKeyText(key)

		bound.hotKeys = bound.hotKeys..key..":"
		bound.hotKeyText = bound.hotKeyText..keytext..":"
	end

	Macaroon.ApplySpellBindings(spell)
end

function Macaroon.SetMacroBinding(macro, key)

	local bound, found = MacaroonBoundSavedState.macros[macro]

	if (bound) then
		gsub(bound.hotKeys, "[^:]+", function(binding) if(binding == key) then found = true end end)
	end

	if (not found and bound) then

		local keytext = Macaroon.GetKeyText(key)

		bound.hotKeys = bound.hotKeys..key..":"
		bound.hotKeyText = bound.hotKeyText..keytext..":"
	end

	Macaroon.ApplyMacroBindings(macro)
end

function Macaroon.ClearBindings(button, key)

	if (key) then

		SetOverrideBinding(button, true, key, nil)

		local newkey = gsub(key, "%-", "%%-")

		button.config.hotKeys = gsub(button.config.hotKeys, newkey..":", "")

		local keytext = Macaroon.GetKeyText(key)

		button.config.hotKeyText = gsub(button.config.hotKeyText, keytext..":", "")

	else
		local bindkey = "CLICK "..button:GetName()..":LeftButton"

		while (GetBindingKey(bindkey)) do

			SetBinding(GetBindingKey(bindkey), nil)

		end

		ClearOverrideBindings(button)

		button.config.hotKeys = ":"

		button.config.hotKeyText = ":"
	end

	Macaroon.ApplyBindings(button)
end

function Macaroon.ClearSpellBinding(spell, key)

	local bound = MacaroonBoundSavedState.spells[spell]

	if (key and bound) then

		SetOverrideBinding(MacaroonSpellBinder, true, key, nil)

		local newkey = gsub(key, "%-", "%%-")

		bound.hotKeys = gsub(bound.hotKeys, newkey..":", "")

		local keytext = Macaroon.GetKeyText(key)

		bound.hotKeyText = gsub(bound.hotKeyText, keytext..":", "")

	elseif (bound) then

		local bindkey = "SPELL "..spell

		while (GetBindingKey(bindkey)) do

			SetBinding(GetBindingKey(bindkey), nil)

		end

		gsub(bound.hotKeys, "[^:]+", function(key) SetOverrideBinding(MacaroonSpellBinder, true, key, nil) end)

		bound.hotKeys = ":"

		bound.hotKeyText = ":"
	end

	Macaroon.ApplySpellBindings(spell)
end

function Macaroon.ClearMacroBinding(macro, key)

	local bound = MacaroonBoundSavedState.macros[macro]

	if (key and bound) then

		SetOverrideBinding(MacaroonMacroBinder, true, key, nil)

		local newkey = gsub(key, "%-", "%%-")

		bound.hotKeys = gsub(bound.hotKeys, newkey..":", "")

		local keytext = Macaroon.GetKeyText(key)

		bound.hotKeyText = gsub(bound.hotKeyText, keytext..":", "")

	elseif (bound) then

		local bindkey = "MACRO "..macro

		while (GetBindingKey(bindkey)) do

			SetBinding(GetBindingKey(bindkey), nil)

		end

		gsub(bound.hotKeys, "[^:]+", function(key) SetOverrideBinding(MacaroonMacroBinder, true, key, nil) end)

		bound.hotKeys = ":"

		bound.hotKeyText = ":"
	end

	Macaroon.ApplyMacroBindings(macro)
end

function Macaroon.ApplyBindings(button)

	button:SetAttribute("hotkeypri", button.config.hotKeyPri)

	if (button:IsShown() or button.config.stored) then
		gsub(button.config.hotKeys, "[^:]+", function(key) SetOverrideBindingClick(button, button.config.hotKeyPri, key, button:GetName()) end)
	end

	button:SetAttribute("hotkeys", button.config.hotKeys)

	button.hotkey:SetText(match(button.config.hotKeyText, "^:([^:]+)") or "")

	if (ss.checkButtons[104]) then
		button.hotkey:Show()
	else
		button.hotkey:Hide()
	end

	if (GetCurrentBindingSet() > 0 and GetCurrentBindingSet() < 3) then SaveBindings(GetCurrentBindingSet()) end
end

function Macaroon.ApplySpellBindings(spell)

	local bound = MacaroonBoundSavedState.spells[spell]

	if (bound) then
		gsub(bound.hotKeys, "[^:]+", function(key) SetOverrideBindingSpell(MacaroonSpellBinder, false, key, spell) end)
	end

	Macaroon.SpellBinder_OnEvent(nil, "UPDATE_BINDINGS")

	if (GetCurrentBindingSet() > 0 and GetCurrentBindingSet() < 3) then SaveBindings(GetCurrentBindingSet()) end
end

function Macaroon.ApplyMacroBindings(macro)

	local bound = MacaroonBoundSavedState.macros[macro]

	if (bound) then
		gsub(bound.hotKeys, "[^:]+", function(key) SetOverrideBindingMacro(MacaroonMacroBinder, false, key, macro) end)
	end

	Macaroon.MacroBinder_OnEvent()

	if (GetCurrentBindingSet() > 0 and GetCurrentBindingSet() < 3) then SaveBindings(GetCurrentBindingSet()) end
end


function Macaroon.GetKeyText(key)

	local keytext

	if (find(key, "BUTTON")) then

		keytext = gsub(key,"(BUTTON)(%d+)","m%2")

	elseif (find(key, "NUMPAD")) then

		keytext = gsub(key,"NUMPAD","n")
		keytext = gsub(keytext,"DIVIDE","/")
		keytext = gsub(keytext,"MULTIPLY","*")
		keytext = gsub(keytext,"MINUS","-")
		keytext = gsub(keytext,"PLUS","+")
		keytext = gsub(keytext,"DECIMAL",".")

	elseif (find(key, "MOUSEWHEEL")) then

		keytext = gsub(key,"MOUSEWHEEL","mw")
		keytext = gsub(keytext,"UP","U")
		keytext = gsub(keytext,"DOWN","D")
	else
		keytext = key
	end

	keytext = gsub(keytext,"ALT%-","a")
	keytext = gsub(keytext,"CTRL%-","c")
	keytext = gsub(keytext,"SHIFT%-","s")
	keytext = gsub(keytext,"INSERT","Ins")
	keytext = gsub(keytext,"DELETE","Del")
	keytext = gsub(keytext,"HOME","Home")
	keytext = gsub(keytext,"END","End")
	keytext = gsub(keytext,"PAGEUP","PgUp")
	keytext = gsub(keytext,"PAGEDOWN","PgDn")
	keytext = gsub(keytext,"BACKSPACE","Bksp")


	return keytext
end

local function controlOnEvent(self, event, ...)

	if (event == "ADDON_LOADED" and ... == "Macaroon") then

		ss = MacaroonSavedState

	elseif (event == "ACTIONBAR_SHOWGRID") then

		if (bindMode) then
			for k,v in pairs(Macaroon.Buttons) do
				if (v[1].bindframe:IsVisible()) then
					v[1].editmode = nil
					v[1].bindframe.showgrid = true
					v[1].bindframe:Hide()
				end
			end
		end

	elseif (event == "ACTIONBAR_HIDEGRID") then

		if (bindMode) then
			for k,v in pairs(Macaroon.Buttons) do
				if (v[1].bindframe.showgrid) then
					v[1].bindframe:Show()
					v[1].bindframe.showgrid = nil
					v[1].editmode = true
				end
			end
		end
	end
end

local frame = CreateFrame("Frame", nil, UIParent)
frame:SetScript("OnEvent", controlOnEvent)
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("ACTIONBAR_SHOWGRID")
frame:RegisterEvent("ACTIONBAR_HIDEGRID")