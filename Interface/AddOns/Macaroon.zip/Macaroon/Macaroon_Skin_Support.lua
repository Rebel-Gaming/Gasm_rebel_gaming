﻿--Macaroon, a World of Warcraft® user interface addon.
--Copyright© 2009 Connor H. Chenoweth, aka Maul - All rights reserved.
--License is given to copy, distribute and to make derivative works.

local groups, group, bf, ss = {}
local gmatch = string.gmatch

local function createBF()

	if (LibStub) then

		bf = LibStub("LibButtonFacade", true)

		if (bf) then

			bf:RegisterSkinCallback("Macaroon", Macaroon.BFskinCallback, Macaroon)

			-- because my version is prettier
			bf:AddSkin("Blizzard",{

				-- Skin data start.
				Normal = {
					Width = 56,
					Height = 56,
					Texture = [[Interface\Buttons\UI-Quickslot2]],
					EmptyTexture = [[Interface\Buttons\UI-Quickslot]],
				},
				Pushed = {
					Width = 32,
					Height = 32,
					Texture = [[Interface\Buttons\UI-Quickslot-Depress]],
				},
				Checked = {
					Width = 32,
					Height = 32,
					Texture = [[Interface\Buttons\CheckButtonHilight]],
					BlendMode = "ADD",
				},
				Highlight = {
					Width = 32,
					Height = 32,
					Texture = [[Interface\Buttons\ButtonHilight-Square]],
					BlendMode = "ADD",
				},
				Border = {
					Width = 31,
					Height = 31,
					Texture = [[Interface\Buttons\UI-ActionButton-Border]],
					BlendMode = "ADD",
				},
				Gloss = {
					Width = 31,
					Height = 31,
					Texture = [[]],
				},
				Disabled = {
					Hide = true,
				},
				Icon = {
					Width = 31,
					Height = 31,
					TexCoords = {0.07,0.93,0.07,0.93},
				},
				Cooldown = {
					Width = 31,
					Height = 31,
				},
				Backdrop = {
					Width = 31,
					Height = 31,
					Texture = [[Interface\Buttons\UI-EmptySlot]],
					OffsetY = -0.5,
					TexCoords = {0.2,0.8,0.2,0.8},
					Red = 1,
					Green = 1,
					Blue = 1,
					Alpha = 1,
				},
				HotKey = {
					Width = 36,
					Height = 10,
					OffsetX = -2,
					OffsetY = 11,
				},
				Count = {
					Width = 36,
					Height = 10,
					OffsetX = -2,
					OffsetY = -11,
				},
				Name = {
					Width = 36,
					Height = 10,
					OffsetY = -11,
				},
				AutoCast = {
					Width = 27,
					Height = 27,
				},
				AutoCastable = {
					Width = 54,
					Height = 54,
					Texture = [[Interface\Buttons\UI-AutoCastableOverlay]],
				},
				Flash = {
					Width = 32,
					Height = 32,
					Texture = [[Interface\Buttons\UI-QuickslotRed]],
				},
				-- Skin data end.

			},true)
		end
	end
end

function Macaroon.SkinBar(bar)

	print(bar:GetName())

	if (not ss) then ss = MacaroonSavedState end

	if (not ss.bfskin) then ss.bfskin = {} end

	if (not bf) then print("hit2") createBF() end

	if (bf) then

		group = bar.config.name

		if (not ss.bfskin[group]) then
			ss.bfskin[group] = {}
		end

		groups[group] = bar

		if (bar.config.buttonList) then

			for state, btnIDs in pairs(bar.config.buttonList) do

				for btnID in gmatch(btnIDs, "[^;]+") do

					button = _G[bar.btnType..btnID]

					if (button and not button.skinset) then

						if (button.bagelement) then

							local btnData = {
								Normal = button.normaltexture,
								Icon = button.icontexture,
								Count = button.count,
							}

							bf:Group("Macaroon", group):AddButton(button.bagelement, btnData)

						elseif (button.menuelement) then

							--local menuRatios = { w = 0.71, h = 0.95 }

							--button.menuelement.icontexture:SetDrawLayer("BACKGROUND")
							--button.menuelement.icontexture:SetTexCoord(-0.1, 1.1, 0.3, 1.07)
							--button.menuelement:SetWidth(button:GetWidth())
							--button.menuelement:SetHeight(button:GetHeight())
							--button.menuelement:SetHitRectInsets(0,0,0,0)

							--local btnData = {
							--	Normal = button.menuelement.normaltexture,
							--}

							--bf:Group("Macaroon", group):AddButton(button.menuelement, btnData)

						elseif (button.config.type == "macro" or
						        button.config.type == "action" or
						        button.config.type == "pet") then

							local btnData = {
								Normal = button.normaltexture,
								Icon = button.iconframeicon,
								Cooldown = button.iconframecooldown,
								HotKey = button.hotkey,
								Count = button.count,
								Name = button.name,
								AutoCast = false,
							}

							bf:Group("Macaroon", group):AddButton(button, btnData)
						end

						button.skinset = true
					end
				end
			end
		end

		if (bar.buttonCountChanged) then

			bf:Group("Macaroon", group):Skin(ss.bfskin[group].Skin,
				      ss.bfskin[group].Gloss,
				      ss.bfskin[group].Backdrop,
				      ss.bfskin[group].Colors)

			bar.buttonCountChanged = nil
		end
	end
end

function Macaroon.BFskinCallback(arg, skin, gloss, backdrop, group, button, colors)

	if (not group) then return end

	if (not ss.bfskin[group]) then ss.bfskin[group] = {} end

	ss.bfskin[group].Skin = skin
	ss.bfskin[group].Gloss = gloss
	ss.bfskin[group].Backdrop = backdrop
	ss.bfskin[group].Colors = colors

	if (groups[group]) then

		local bar, skins, button = groups[group], bf:GetSkins()

		if (skins[skin] and skins[skin].Normal.Texture ~= "Interface\\Buttons\\UI-Quickslot2") then

			bar.hasAction = false
			bar.noAction = false

		elseif (skins[skin]) then

			bar.hasAction = skins[skin].Normal.Texture
			bar.noAction = skins[skin].Normal.EmptyTexture
		end

		for state, btnIDs in pairs(bar.config.buttonList) do

			for btnID in gmatch(btnIDs, "[^;]+") do

				button = _G[bar.btnType..btnID]

				if (button and button.updateButtonData) then
					button.updateButtonData(button, bar, state)
				end
			end
		end
	end

	Macaroon.Save()
end