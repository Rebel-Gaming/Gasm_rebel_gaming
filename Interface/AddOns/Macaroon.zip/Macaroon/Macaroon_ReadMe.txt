Macaroon, a World of Warcraft� user interface addon.
Copyright� 2009 Connor H. Chenoweth, aka Maul - All rights reserved.
License is given to copy, distribute and to make derivative works.

Macaroon! - A macro-based action bar addon. It can stand on its own or supplement any other action bar addon or even the default Blizzard UI.

"Feel the power of the macro side..." -  A WoW 3.0 Wrath of the Lich King addon.

Visit this thread for more information on Macaroon! - http://www.wowinterface.com/forums/showthread.php?t=18454

A Macaroon FAQ is contained in the official thread here - http://www.wowinterface.com/portal.php?id=221&a=faq

Report bugs here - http://www.wowinterface.com/portal.php?id=221&a=bugreport

Request features here - http://www.wowinterface.com/portal.php?id=221&a=featurereq

Be sure to check out the "Xtras" addon for Macaroon. Gives you all the extra bar addon goodies if you so desire -
http://www.wowinterface.com/downloads/info10933-MacaroonXtras.html


Features -


	An unlimited number of macros, create as many bars/buttons as you want/need per character!
	
	Are you a keybinder extreme? Use the button storage area for all your macros/keybinds! No buttons on screen needed!
	
	Are you a clicker extrodanaire? As many buttons on the screen you want where you want, when you want!
	
	Macros the size of Texas! Up to 1024 characters in length!
	
	Maul's unique mouseover key-binding system - where the mouseover binding system was born!
	
	Many other of the favorite desired bar addon features and then some!
	
	Button Facade support!

	Every button in Macaroon is a macro button by default and in many ways they behave like normal action buttons. Buttons can also be set to be "action" or "pet" buttons.	

		
Commands - 


	Type /macaroon or /mac alone to display a list of available commands, which are:
	
		menu:		Toggle the main menu
		storage: 	Open the button storage area
		create:		Create a blank bar
		delete:		Delete the currently selected bar
		config:		Toggle configuration mode for all bars
		add:		Adds buttons to the currently selected bar (add or add #)
		remove:		Removes buttons from the currently selected bar (remove or remove #)
		edit:		Toggle edit mode for all buttons
		bind:		Toggle binding mode for all buttons
		scale:		Scale a bar to the desired size.
		snapto:		Toggle SnapTo for current bar	
		autohide:	Toggle AutoHide for current bar		
		shape:		Change current bar's shape	
		name:		Change current bar's name
		strata:		Change current bar's frame strata
		alpha:		Change current bar's alpha (transparency)
		alphaup:	Set current bar's conditions to 'alpha up'
		arcstart:	Set current bar's starting arc location (in degrees)
		arclen:		Set current bar's arc length (in degrees)
		columns:	Set the number of columns for the current bar
		padh:		Set current bar's horizontal padding
		padv:		Set current bar's vertical padding
		padhv:		Adjust both horizontal and vertical padding of the current bar incrementally
		showgrid:	Toggle the current bar's showgrid flag
		x:		Change current bar's horizontal axis position
		y:		Change current bar's vertical axis position			
		state:		Toggle states for the current bar (/mac state <state>). Type /mac statelist for vaild states
		statelist:	Print a list of valid states
		load:		Load a profile
		lock:		Lock buttons


	Just remember:
	
		"With great flexibility comes great configuration..." - Maul

Trinity/Trinity Bars Note:

Read Of mages, multiboxing and macros...mmm? - http://www.wowinterface.com/forums/showpost.php?p=104167&postcount=12