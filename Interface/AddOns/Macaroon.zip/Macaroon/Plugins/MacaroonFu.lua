﻿--MacaroonFu, a World of Warcraft® user interface addon.
--Copyright© 2009 Connor H. Chenoweth, aka Maul - All rights reserved.
--License is given to copy, distribute and to make derivative works.

if (IsAddOnLoaded("FuBar")) then

	MacaroonFu = AceLibrary("AceAddon-2.0"):new("AceDB-2.0", "AceConsole-2.0", "FuBarPlugin-2.0")

	MacaroonFu:RegisterDB("MacaroonFuSavedState")

	MacaroonFu.title = MACAROON_STRINGS.TITLE
	MacaroonFu.description = MACAROON_STRINGS.DESC
	MacaroonFu.version = "30000.2"
	MacaroonFu.hasIcon = "Interface\\Icons\\INV_Misc_Orb_05"
	MacaroonFu.defaultPosition  = "RIGHT"
	MacaroonFu.hasNoColor = true
	MacaroonFu.cannotAttachToMinimap = true
	MacaroonFu.independentProfile = true
	MacaroonFu.blizzardTooltip = true

	MacaroonFu.OnMenuRequest = {

		type = 'group',

		args = {

			blankLine = {
				type = 'header',
				order = 1,
				desc = " ",
			},

			barConfig = {
				order = 10,
				name = MACAROON_STRINGS.MINIMAP_ACTION_3,
				desc = MACAROON_STRINGS.SLASH_COMMAND_4_DESC,
				type = "toggle",
				get = function() end,
				set = function(v) Macaroon.ConfigBars() end,
			},

			buttonEdit = {
				 order = 20,
				 name = MACAROON_STRINGS.MINIMAP_ACTION_2,
				 desc = MACAROON_STRINGS.SLASH_COMMAND_7_DESC,
				 type = "toggle",
				 get = function() end,
				 set = function(v) Macaroon.ButtonEdit() end,
			},

			bindEdit = {
				 order = 30,
				 name = MACAROON_STRINGS.MINIMAP_ACTION_4,
				 desc = MACAROON_STRINGS.SLASH_COMMAND_8_DESC,
				 type = "toggle",
				 get = function() end,
				 set = function(v) Macaroon.ButtonBind() end,
			},

			buttonLock = {
				 order = 40,
				 name = MACAROON_STRINGS.MINIMAP_ACTION_1,
				 desc = MACAROON_STRINGS.SLASH_COMMAND_29_DESC,
				 type = "toggle",
				 get = function() end,
				 set = function(v) Macaroon.ButtonLock() end,
			},

			mainMenu = {
				 order = 50,
				 name = MACAROON_STRINGS.MINIMAP_ACTION_5,
				 desc = MACAROON_STRINGS.SLASH_COMMAND_1_DESC,
				 type = "toggle",
				 get = function() end,
				 set = function(v) Macaroon.OpenMainMenu() end,
			},

			storageOpen = {
				 order = 60,
				 name = MACAROON_STRINGS.MINIMAP_ACTION_9,
				 desc = MACAROON_STRINGS.SLASH_COMMAND_31_DESC,
				 type = "toggle",
				 get = function() end,
				 set = function(v) Macaroon.OpenStorage() end,
			},

			createBar = {
				 order = 70,
				 name = MACAROON_STRINGS.MINIMAP_ACTION_6,
				 desc = MACAROON_STRINGS.SLASH_COMMAND_2_DESC,
				 type = "toggle",
				 get = function() end,
				 set = function(v) Macaroon.CreateNewBar("bar") end,
			},

			deleteBar = {
				 order = 80,
				 name = MACAROON_STRINGS.MINIMAP_ACTION_7,
				 desc = MACAROON_STRINGS.SLASH_COMMAND_3_DESC,
				 type = "toggle",
				 get = function() end,
				 set = function(v) Macaroon.DeleteBar() end,
			},
		}
	}

	function MacaroonFu:OnEnable()

		-- do nothing
	end


	function MacaroonFu:OnClick(button)

	end

	function MacaroonFu:OnTooltipUpdate()

		GameTooltip:AddLine(MACAROON_STRINGS.TITLE)

		if (MacaroonSavedState.checkButtons[109]) then
			GameTooltip:AddLine(MACAROON_STRINGS.MINIMAP_TOOLTIP2.."|cff00ff00"..MACAROON_STRINGS.BARTOOLTIP_1.."|r")
		else
			GameTooltip:AddLine(MACAROON_STRINGS.MINIMAP_TOOLTIP2.."|cfff00000"..MACAROON_STRINGS.BARTOOLTIP_2.."|r")
		end

	end
end