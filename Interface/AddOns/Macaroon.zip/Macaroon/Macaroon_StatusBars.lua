﻿--Macaroon, a World of Warcraft® user interface addon.
--Copyright© 2009 Connor H. Chenoweth, aka Maul - All rights reserved.
--License is given to copy, distribute and to make derivative works.

Macaroon.BarTextures = {
	[1] = { "Default", "Interface\\TargetingFrame\\BarFill2" },
	[2] = { "Contrast", "Interface\\AddOns\\Macaroon\\Images\\BarFill_contrast" },
	-- Following textures by Tonedef of WoWInterface
	[3] = { "Carpaint", "Interface\\AddOns\\Macaroon\\Images\\BarFill_Carpaint" },
	[4] = { "Gel", "Interface\\AddOns\\Macaroon\\Images\\BarFill_Gel" },
	[5] = { "Glassed", "Interface\\AddOns\\Macaroon\\Images\\BarFill_Glassed" },
	[6] = { "Soft", "Interface\\AddOns\\Macaroon\\Images\\BarFill_Soft" },
	[7] = { "Velvet", "Interface\\AddOns\\Macaroon\\Images\\BarFill_Velvet" },
}

Macaroon.BarBorders = {
	[1] = { "Tooltip", "Interface\\Tooltips\\UI-Tooltip-Border", 2, 2, 3, 3, 12, 12, -2, 3, 2, -3 },
	[2] = { "Slider", "Interface\\Buttons\\UI-SliderBar-Border", 3, 3, 6, 6, 8, 8 , -1, 5, 1, -5 },
	[3] = { "Dialog", "Interface\\AddOns\\Macaroon\\Images\\Border_Dialog", 11, 12, 12, 11, 26, 26, -7, 7, 7, -7 },
	[4] = { "None", "", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
}

function Macaroon.StatusBars_SetOrientation(parent, statusbar, dummy)

	if (statusbar) then

		if (parent) then
			statusbar:SetOrientation(parent.config.orientation)
			statusbar:SetStatusBarTexture(Macaroon.BarTextures[parent.config.texture][2])

			if (dummy) then
				dummy:SetStatusBarTexture(Macaroon.BarTextures[parent.config.texture][2])
			end
		else
			if (statusbar.config.orientation == "HORIZONTAL" or statusbar.config.orientation == "VERTICAL") then
				statusbar:SetOrientation(statusbar.config.orientation)
			end
			statusbar:SetStatusBarTexture(Macaroon.BarTextures[statusbar.config.texture][2])

			if (dummy) then
				dummy:SetStatusBarTexture(Macaroon.BarTextures[statusbar.config.texture][2])
			end
		end
	end
end

function Macaroon.Orient_OnShow(self)

	local statusbar = Macaroon.CurrentButton

	if (statusbar) then

		local data = { ["Horizontal"] = "HORIZONTAL", ["Vertical"] = "VERTICAL" }

		Macaroon.EditBox_PopUpInitialize(self.popup, data)
	end

end

function Macaroon.Orient_OnTextChanged(self)

	local statusbar = Macaroon.CurrentButton

	if (statusbar) then
		statusbar.config.orientation = self.value

		Macaroon.StatusBars_SetOrientation(statusbar)
	end
end