﻿ButtonFacade skin : simpleSquare
Author : MoonWitch (Marillian on Tanaris US)
Version: 1.0
Required Addons: ButtonFacade

Description
-----------
Original skin: http://www.wowinterface.com/downloads/info7893-cyCircled_SimpleSquare.html
Phanx requested a port, I have not modified the textures, I merely added a backdrop for beauty reasons. Plainly put, there was a demand, the porting of skins goes fast, I did it really fast. Nothing more to say. :) Enjoy the skin, but all credits go to ScythXIII

Installation
------------
1. If you don't have ButtonFacade, be sure to grab it from http://files.wowace.com/ButtonFacade/ButtonFacade.zip
2. Unzip the provided zip into "World of Warcraft\Interface\Addons\" (without quotes)
3. Verify if the path INTO the skin folder is "World of Warcraft\Interface\Addons\ButtonFacade_simpleSquare" (without quotes)
4. While in-game, select the skin through ButtonFacade and enjoy.

Feedback? Need Support?
-----------------------
Feel free to pm me on the WoWace forums, I am MoonWitch there too. You can leave a note in WoWInterface as well.