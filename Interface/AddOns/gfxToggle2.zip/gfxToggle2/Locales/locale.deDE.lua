﻿
local L = AceLibrary("AceLocale-2.2"):new("gfxToggle")

L:RegisterTranslations("deDE", function() return {

["gfxToggle2 Options"] = "gfxToggle Optionen",
["Attention! Don't touch the RestartGx toggle if you're running WoW on a linux box. It might crash your client!"] =
	"Achtung! Nicht den RestartGx Befehl verwenden, wenn du WoW unter Linux spielst. Es k\195\182nnte den Client zum Absturz bringen!",
["Save"] = "Einstellungen speichern",
["Saves your custom settings."]= "Speichert deine pers\195\182nlichen Einstellungen.",
["Low"] = "Niedrig",
["Medium"] = "Mittel",
["High"] = "Hoch",
["Saves settings for: "] = "Speichert Einstellungen f\195\188r: ",
["Saved settings for: "] = "Einstellungen gespeichert f\195\188r: ",
["Change settings in WoW Graphic-Options (World Appearance, Shaders and Misc). After that click on the Ok-Button and save settings."] =
	"Weltdarstellungs-, Shader- und Misc-Einstellungen im WoW-Grafikmen\195\188 vornehmen und mit Klick auf den OK-Button best\195\164tigen. Danach Einstellungen speichern.",
["Auto"] = "Auto",
["Auto-Mode is set to: %s"] = "Auto-Modus ist nun: %s",
["Checks your zone database and toggles the saved settings automatically."] = "Schaltet beim Zonenwechsel automatisch zwischen den gespeicherten Einstelllungen um.",
["Does allow the use of the settings: %s."] = "Aktiviert das Benutzen der Einstellung: %s.",
["Toggle"] = "Grafik umschalten",
["Toggles between %s, %s (if turned on by '/gfxt medium') and %s."] =
	"Manuelles Umschalten zwischen %s, %s (wenn aktiviert mit '/gfxt medium') und %s.",
["Add "] = "Speicher ",
["zone"] = "Zone",
["Adds zone for setting: "] = "Speichert Zone f\195\188r Einstellung: ",
["Adds zone for selected setting."] = "Speichert Zone f\195\188r Einstellung: ",
["Adds the specified zone."] = "Speichert angegebene Zone.",
["Adds the current zone. "] = "Speichert aktuelle Zone.",
["name"] = "Name",
["this"] = "this",
["Delete "] = "Entferne ",
["All"] = "Alle",
["Deletes a zone from database."] = "Entfernt eine Zone aus der Datenbank.",
["Deletes current zone."] = "Entfernt aktuelle Zone.",
["Deletes specified zone."] = "Entfernt angegebene Zone.",
["current"] = "aktuelle",
["Deletes all zones."] = "Entfernt alle Zonen.",
["List"] = "Zonenliste",
["Lists all saved zones."] = "Zeigt alle gespeicherten Zonen an.",
["Mute"] = "Stumm",
["Toggles screen messages."] = "Schaltet Meldungen an/aus.",
["M2Faster"] = "M2Faster",
["Toggle Blizzard's M2Faster-Function to improve performance in crowded areas. Default is: |cff00ff00On|r"] =
	"Aktivieren der Blizzard M2Faster-Funktion zur Verbesserung der Performance in \195\188berf\195\188llten Gegenden. Grundeinstellung ist: |cff00ff00An|r",
["Delay"] = "Verz\195\182gerung",
["Sets a delay for the Auto-Mode. (Default: [|cfff5f5305|r] seconds)"] =
	"Stellt Verz\195\182gerung f\195\188r das automatische Umschalten ein. (Grundeinstellung: [|cfff5f5305|r] Sekunden)",
["RestartGx"] = "RestartGx",
["Allows re-initializing of the graphics driver (needed for VSync)."] = "Erlaubt Reset des Grafiktreibers (ben\195\182tigt f\195\188r VSync).",
["To switch VSync, Tripplebuffer and Smooth Mouse the game has to restart the graphics. While it does the restart, it'll switch to the desktop and back to game after a duration of 1-2 seconds. By using this command you allow switching these settings. Default is: |cffff5050Off|r."] =
	"F\195\188r das Umschalten von VSync, Tripplebuffer und Weiche Maussteuerung muss der Grafikkarten-Treiber neu initialisiert werden. Bei Initialisierung wird kurz vom Spiel auf den Desktop und wieder zur\195\188ck ins Spiel gewechselt. Der Vorgang dauert ca. 1-2 Sekunden. Mit diesem Befehl wird das Umschalten dieser Einstellungen generell erlaubt oder verboten. Grundeinstellung ist: |cffff5050Aus|r",
["Reset"] = "Reset",
["Resets all settings to their defaults."] = "Setzt alle Einstellungen auf ihre Standardwerte zur\195\188ck.",
["All settings have been reset to their defaults."] = "Alle Einstellungen wurden auf ihre Standardwerte zur\195\188ckgesetzt.",

-- Chat Options --
["GFX set to:"] = "GFX umgeschaltet auf:",
["|cff00ff00Low|r"] = "|cff00ff00Niedrig|r",
["|cffffff00Medium|r"] = "|cffffff00Mittel|r",
["|cffff0000High|r"] = "|cffff0000Hoch|r",
["(default) \nUse '/gfxt save' to save custom settings."] = "(default) \n'/gfxt save' eingeben um pers\195\182nliche Einstellungen zu speichern.",
["Chat_Exists"] = "Eintrag existiert bereits, bitte vorher entfernen.",
["Chat_NotThere"] = "Eintrag nicht gefunden.",
["Chat_NoEntry"] = "Es wurden keine Eintr\195\164ge gefunden.",
["Chat_Added"] = "' wurde hinzugef\195\188gt.",
["Chat_MedAdd"] = "Bitte beachten: Auto-Modus wird nur auf Mittel umstellen, wenn die Option 'medium' aktiviert ist.",
["Chat_Deleted"] = "' wurde entfernt.",
["Chat_DelAll"] = "Alle Eintr\195\164ge wurden entfernt.",
["Chat_Found"] = " Eintr\195\164ge gefunden.",
["Chat_FoundOne"] = " Eintrag gefunden.",
["Chat_ZoneDb"] = "Saved Zones",
["settings"] = "Einstellungen",
["zones"] = "Zonen",

-- FuBar Plug locals
["Are you sure you want to reset all your %s for %s"] =
	"Bist Du wirklich sicher, da\195\159 Du alle %s f\195\188r %s zur\195\188cksetzen willst?",

["- Auto"] = "- Auto",
["- A"] = "- A",
[" - M"] = " - M",
["|cffffffffN|r"] = "|cffffffffN|r",
["|cffffffffNormal|r"] = "|cffffffffNormal|r",
["|cffff0000H|r"] = "|cffff0000H|r",
["|cff00ff00L|r"] = "|cff00ff00L|r",
["|cffffff00M|r"] = "|cffffff00M|r",
["Manual"] = "Manuell",
["Current zone:"] = "Aktuelle Zone:",
["Zones: "] = "Zonen: ",
["Short Text"] = "Kurzer Text",
["Left mousebutton for low/(medium)/high. Shift + left mousebutton for auto/manual."] =
	"Linksklick f\195\188r Niedrig/(Mittel)/Hoch. Umschalten + Linksklick f\195\188r auto/manuell.",
["Left-click on current zone adds zone to 'Low', Shift + left-click adds zone to 'Medium'. Left-click on 'Low' or 'Medium' zone deletes it."] =
	"Linksklick auf aktuelle Zone speichert diese f\195\188r 'Niedrig'. Shift + Linksklick speichert Zone f\195\188r 'Mittel'.\n Zum L\195\182schen der Zonen Linksklick auf Zonen bei 'Niedrig' oder 'Mittel'.",

-- Bindings
["gfxToggle2"] = "gfxToggle2",
["Toggle graphics"] = "Grafik umschalten",
["Auto-Mode"] = "Auto-Modus",

-- Ace Globals
["|cff00ff00On|r"] = "|cff00ff00An|r",
["|cffff5050Off|r"] = "|cffff5050Aus|r",
["|cfff5f530%s|r"] = "|cfff5f530%s|r",

} end)
