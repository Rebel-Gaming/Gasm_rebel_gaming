
if GetLocale() == 'koKR' then
	local L = OMNICC_LOCALS
	L.Thin = '얇게'
	L.Thick = '두껍게'
	L.ShowModels = '재사용 대기시간 모델 표시'
	L.ShowPulse = '반짝임 효과 표시'
	L.UseMMSS = '시간 형식 MM:SS 사용'
	L.MinDuration = '최소 지속시간'
	L.MinScale = '최소 크기'
	L.Display = '표시'
	L.FontFace = '글꼴체'
	L.FontOutline = '글꼴 외각선'
	L.FontSize = '글꼴 크기'
	L.Font = '글꼴'
	L.ColorsAndScaling = '색상 및 크기'
	L.UnderFiveSeconds = '5초 미만'
	L.OptionsTitle = 'OmniCC 옵션'
	L.MinEffectDuration = '완료 효과 최소 표시 수치'
	L.ShowTenthsOfSeconds = '완료 3초전 0.1초 단위 표시'
end
