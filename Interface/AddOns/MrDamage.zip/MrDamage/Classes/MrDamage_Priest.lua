
----
-- Table Creation w/ Static Entries
---
function MrD_Priest_Static()

	--MrDamage_UpdateTalents()
	
	MrD.Info = {
		["Attack"] = {
			melee=true,
			armor= true,
		},
		["Shoot"] = {
			ranged=true,
		},
		["Heal"] = { 
			type="direct",
			range = true,
			["low"] = { "295", "429", "566", "712" },
			["high"] = { "341", "491", "642", "804" },
			coeff = 1,
			smult = 1 + T["Focused Power"] * .02,
		},
		["Lesser Heal"] = { 
			type="direct", 
			range=true,
			["low"] = { "46", "71", "135" },
			["high"] = { "56", "85", "157" },
			coeff = .8086,
			smult = 1 + T["Focused Power"] * .02,
		},
		["Smite"] = {
			type="direct",
			school=2,
			range=true,
			["low"] = { "14", "25", "54", "91", "150", "212", "287", "371", "405", "545", "604", "707" },
			["high"] = { "18", "31", "62", "105", "170", "240", "323", "415", "453", "611", "676", "793" },
			coeff = .7140,
			smult = 1 + T["Focused Power"] * .02 + T["Searing Light"] * .05,
		},
		["Renew"] = { 
			type="ot",
			ticks=5,
			int=3,
			["avg"] = { "45"/5, "100"/5, "175"/5, "245"/5, "315"/5, "400"/5, "510"/5, "650"/5, "810"/5, "970"/5, "1010"/5, "1110"/5, "1235"/5, "1400"/5 },
			coeff = 1.88/5,
			smult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02 + T["Improved Renew"] * .05,
		},
		["Lightwell"] = { 
			type="ot",
			ticks=3,
			int=2,
			["avg"] = { "801", "1164", "1599", "2361", "3915", "4620" },
			coeff = 1,
			smult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02,
		},
		["Flash Heal"] = { 
			type="direct",
			range=true,
			["low"] = { "193", "258", "327", "400", "518", "644", "812", "913", "1101", "1578", "1887" },
			["high"] = { "237", "314", "393", "478", "616", "764", "958", "1059", "1279", "1832", "2193" },
			coeff = .8086 + T["Empowered Healing"] * .08,
			smult = 1 + T["Focused Power"] * .02,
		},
		["Holy Fire"] = { 
			type="hybrid",
			school=2,
			range=true,
			ticks = 7,
			int = 1,
			["low"] = { "102", "137", "200", "267", "348", "430", "529", "639", "705", "732", "890" },
			["high"] = { "128", "173", "252", "339", "440", "546", "671", "811", "895", "928", "1130" },
			["add"] = { "21"/7, "28"/7, "42"/7, "56"/7, "70"/7, "91"/7, "112"/7, "126"/7, "147"/7, "287"/7, "350"/7 },
			coeff = .5711 + T["Focused Power"] * .02 + T["Searing Light"] * .05,
			coeffadd = .0240 + T["Focused Power"] * .02 + T["Searing Light"] * .05,
			smult = 1,
		},
		["Holy Nova"] = { 
			type="direct",
			both=true,
			rangeheal=true,
			rangedmg=true,
			["dlow"] = { "28", "50", "76", "106", "140", "181", "242", "333", "398" },
			["dhigh"] = { "32", "58", "88", "122", "162", "209", "280", "387", "462" },
			["hlow"] = { "52", "86", "121", "161", "235", "302", "384", "611", "713" },
			["hhigh"] = { "60", "98", "139", "187", "271", "350", "446", "709", "827" },
			dcoeff = .1606,
			hcoeff = .3035,
			dsmult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02 + T["Searing Light"] * .05,
			hsmult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02 + T["Divine Providence"] * .02,
		},
		["Desperate Prayer"] = {
			type="direct",
			range=true,
			["low"] = { "263", "447", "588", "834", "1101", "1324", "1601", "3111", "3716" },
			["high"] = { "325", "543", "708", "994", "1305", "1562", "1887", "3669", "4384" },
			coeff = .8086,
			smult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02,
		},
		["Prayer of Healing"] = { 
			type="direct",
			range=true,
			["low"] = { "301", "444", "657", "939", "997", "1246", "2091" },
			["high"] = { "321", "472", "695", "991", "1053", "1316", "2209" },
			coeff = .8086,
			smult = 1 + T["Focused Power"] * .02 + T["Divine Providence"] * .02,
		},
		["Greater Heal"] = {
			type="direct",
			range=true,
			["low"] = { "899", "1149", "1437", "1798", "1966", "2074", "2396", "3395", "3950" },
			["high"] = { "1013", "1289", "1609", "2006", "2194", "2410", "2784", "3945", "4590" },
			coeff = 1.61 + T["Empowered Healing"] * .08,
			smult = 1 + T["Focused Power"] * .02,
		},
		["Circle of Healing"] = {
			type="direct",
			range=true,
			["low"] = { "343", "403", "458", "518", "572", "825", "958" },
			["high"] = { "379", "445", "506", "572", "632", "911", "1058" },
			coeff = .4020,
			smult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02 + T["Divine Providence"] * .02,
		},
		["Binding Heal"] = {
			type="direct",
			range=true,
			["low"] = { "1042", "1619", "1952" },
			["high"] = { "1338", "2081", "2508" },
			coeff = .8068 + T["Empowered Healing"] * .08,
			smult = 1 + T["Focused Power"] * .02 + T["Divine Providence"] * .02,
		},
		["Prayer of Mending"] = {
			type="ot",
			ticks=6,
			int=30,
			["avg"] = { "800", "905", "1043" },
			coeff = .8068,
			smult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02 + T["Divine Providence"] * .02,
		},
		["Divine Hymn"] = {
			type="channel",
			ticks=4,
			int=2,
			range=true,
			["low"] = { "4320" },
			["high"] = { "4774" },
			coeff = .376,
			smult = 1 + T["Focused Power"] * .02 + T["Divine Providence"] * .02,
		},
		["Power Word: Shield"] = {
			type="absorb",
			["avg"] = { "44", "88", "158", "234", "301", "381", "484", "605", "763", "942", "1125", "1265", "1920", "2230" },
			coeff = .8068 * (1 + T["Borrowed Time"] * .08),
			smult = 1 + T["Improved Power Word: Shield"] * .05,
		},
		["Penance"] = {
			type="channel",
			both=true,
			rangeheal=true,
			ticks = 2,
			int = 1,
			["davg"] = { "240", "292", "333", "375" },
			["hlow"] = { "670", "805", "1278", "1484" },
			["hhigh"] = { "756", "909", "1442", "1676" },
			dcoeff = .687,
			hcoeff = 1.61,
			dsmult = 1 + T["Focused Power"] * .02 + T["Searing Light"] * .05,
			hsmult = 1 + T["Focused Power"] * .02,
		},
		["Shadow Word: Pain"] = {
			type="ot",
			school=6,
			ticks = 6,
			int = 3,
			["avg"] = { "30"/6, "60"/6, "120"/6, "210"/6, "330"/6, "462"/6, "606"/6, "768"/6, "906"/6, "1116"/6, "1176"/6, "1380"/6 },
			coeff = .1829,
			smult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02 + T["Darkness"] * .2 + T["Improved Shadow Word: Pain"] * .03,
		},
		["Devouring Plague"] = {
			type="ot",
			school=6,
			ticks = 8,
			int = 3,
			["avg"] = { "152"/8, "272"/8, "400"/8, "544"/8, "712"/8, "904"/8, "1088"/8, "1144"/8, "1376" },
			coeff = .1849,
			smult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02 + T["Darkness"] * .2 + T["Improved Devouring Plague"] * .05,
		},
		["Mind Flay"] = {
			type="channel",
			school=6,
			ticks = 3,
			int = 1,
			["avg"] = { "45", "108", "159", "222", "282", "363", "450", "492", "588" },
			coeff = .2570 * (1 + T["Misery"] * .05),
			smult = 1 + T["Focused Power"] * .02 + T["Darkness"] * .2,
		},
		["Vampiric Touch"] = {
			type="ot",
			school=6,
			ticks = 5,
			int = 3,
			["avg"] = { "450"/5, "600"/5, "650"/5, "735"/5, "850"/5 },
			coeff = .4,
			smult = 1 + T["Focused Power"] * .02 + T["Darkness"] * .2,
		},
		["Shadow Word: Death"] = {
			type="direct",
			school=6,
			range=true,
			["low"] = { "450", "572", "639", "750" },
			["high"] = { "522", "664", "741", "870" },
			coeff = .4296,
			smult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02 + T["Darkness"] * .2,
		},
		["Mind Sear"] = {
			type="channel",
			school=6,
			range=true,
			ticks = 5,
			int = 1,
			["low"] = { "183", "212" },
			["high"] = { "197", "228" },
			coeff = .7143 * (1 + T["Misery"] * .05),
			smult = 1 + T["Focused Power"] * .02 + T["Darkness"] * .2,
		},
		["Mind Blast"] = {
			type="direct",
			school=6,
			range=true,
			["low"] = { "39", "72", "112", "167", "217", "279", "346", "425", "503", "557", "708", "837", "992" },
			["high"] = { "73", "78", "120", "177", "231", "297", "366", "449", "531", "587", "748", "883", "1048" },
			coeff = .4280 * (1 + T["Misery"] * .05),
			smult = 1 + T["Focused Power"] * .02 + T["Darkness"] * .2,
		},
	}
	local info = MrD.Info
	local glyph = MrDamage.Glyphs
	if T["Empowered Renew"] > 0 then -- Rewrite renew as hybrid spell
		local t = T["Empowered Renew"] * .05
		info.Renew = {
			type="hybrid",
			ticks = 5,
			int = 3,
			["avg"] = { "45"*t, "100"*t, "175"*t, "245"*t, "315"*t, "400"*t, "510"*t, "650"*t, "810"*t, "970"*t, "1010"*t, "1110"*t, "1235"*t, "1400"*t },
			["add"] = { "45"/5, "100"/5, "175"/5, "245"/5, "315"/5, "400"/5, "510"/5, "650"/5, "810"/5, "970"/5, "1010"/5, "1110"/5, "1235"/5, "1400"/5 },
			coeff = 1.88*t,
			coeffadd = 1.88/5,
			smult = 1 + T["Twin Disciplines"] * .01 + T["Focused Power"] * .02 + T["Improved Renew"] * .05,
		}
	end
	-- Glyphs --
	if glyph[55680] then -- Rewrite Prayer of healing as hybrid spell
		info["Prayer of Healing"]["type"]="hybrid"
		info["Prayer of Healing"]["ticks"]=2
		info["Prayer of Healing"]["int"]=3
		info["Prayer of Healing"]["add"] = {}
		for i = 1, 7 do
			info["Prayer of Healing"]["add"][i] = ( (info["Prayer of Healing"]["low"][i] + info["Prayer of Healing"]["high"][i])/2 ) * .2
		end
		info["Prayer of Healing"]["coeffadd"] = .16172
	end
	if glyph[55672] then
		info.special = true
	end
	if glyph[55683] then info["Holy Nova"]["dsmult"] = info["Holy Nova"]["dsmult"] * .4; info["Holy Nova"]["hsmult"] = info["Holy Nova"]["hsmult"] * 1.4 end
	if glyph[55673] then info.Lightwell.smult = info.Lightwell.smult + .2 end
	if glyph[55674] then info.Renew.ticks = 6; info.Renew.smult = info.Renew.smult + .25 end
end

----
-- Dynamic Entries
----
function MrD_Priest_Dynamic()
	local ud = UnitDebuff
	local info = MrD.Info
	local allheal = 0; local alldmg = 0
	for k,v in pairs(info) do
		if v.both then
			if UnitIsEnemy("player", "target") then v.mult = v.hsmult
			else v.mult = v.dsmult end
		else v.mult = v.smult end
	end
	-- Test of Faith --
	if UnitHealth("target")/UnitHealthMax("target") < .5 then
		allheal = T["Test of Faith"] * .04
	end
	-- Curse of Elements/Ebon Plauge/Earth and Moon --
	if ud("target", "Curse of the Elements") or ud("target", "Ebon Plague") or ud("player", "Earth and Moon") then
		alldmg = .13
	end
	for k,v in pairs(info) do
		if not v.melee and not v.ranged then
			if v.both then 
				if UnitIsEnemy("player", "target") then v.mult = v.mult + alldmg
				else v.mult = v.mult + allheal end
			elseif v.school then 
				v.mult = v.mult + alldmg	
			else v.mult = v.mult + allheal end
		end
	end
	-- Twisted Faith --
	if select(7, UnitDebuff("target", "Shadow Word: Pain") == "player") then
		info["Mind Flay"]["mult"] = info["Mind Flay"]["mult"] + T["Twisted Faith"] * .02
		info["Mind Blast"]["mult"] = info["Mind Blast"]["mult"] + T["Twisted Faith"] * .02
	end
	-- Shadow Word: Death Glyph --
	if UnitHealth("target")/UnitHealthMax("target") < .35 then
		info["Shadow Word: Death"]["mult"] = info["Shadow Word: Death"]["mult"] + .1
	end
	-- Shadow Form --
	if GetShapeshiftForm() == 1 then
		for k,v in pairs(info) do
			if v.school == 6 then
				v.mult = v.mult + .15
			end
		end
	end
end
