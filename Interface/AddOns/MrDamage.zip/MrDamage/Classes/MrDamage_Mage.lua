
----
-- Table Creation w/ Static Entries
---
function MrD_Mage_Static()

	Snares = { "Slow", "Frostbolt", "Frostfire Bolt", "Blast Wave", "Cone of Cold", "Thunder Clap", "Icy Chains", "Icy Touch", "Judgement of the Just", "Infected Wounds" }

	MrD.Info = {
		["Attack"] = {
			melee=true,
			armor= true,
		},
		["Shoot"] = {
			ranged=true
		},
		["Arcane Missiles"] = {
			type="channel",
			school=7,
			ticks =5,
			int=1,
			["avg"] = { "24", "36", "56", "83", "115", "151", "192", "230", "240", "260", "280", "320", "360" },
			coeff = .2857 + T["Arcane Empowerment"] * .03,
			smult = 1 + T["Arcane Instability"] * .01,
		},
		["Mana Shield"] = {
			type="absorb",
			school=7,
			["avg"] = { "120", "210", "300", "390", "480", "570", "715", "1080", "1330" },
			coeff = .8053,
			smult = 1,
		},
		["Arcane Explosion"] = {
			type="direct",
			school=7,
			range=true,
			["low"] = { "32", "57", "97", "139", "186", "243", "306", "377", "481", "538" },
			["high"] = { "36", "63", "105", "151", "202", "263", "330", "407", "519", "582" },
			coeff = .2128,
			smult = 1 + T["Arcane Instability"] * .01 + T["Spell Impact"] * .02,
		},
		["Arcane Blast"] = {
			type="direct",
			school=7,
			range=true,
			["low"] = { "842", "897", "1047", "1185" },
			["high"] = { "978", "1040", "1215", "1377" },
			coeff = .7143 + T["Arcane Empowerment"] * .03,
			smult = 1 + T["Arcane Instability"] * .01 + T["Spell Impact"] * .02,
		},
		["Arcane Barrage"] = {
			type="direct",
			school=7,
			range=true,
			["low"] = { "386", "709", "936" },
			["high"] = { "470", "865", "1144" },	
			coeff = .7143,
			smult = 1 + T["Arcane Instability"] * .01,
		},
		["Fire Ward"] = {
			type="absorb",
			school=3,
			["avg"] = { "165", "290", "470", "675", "875", "1125", "1950" },
			coeff = .8053,
			smult = 1,
		},
		["Living Bomb"] = {
			type="hybrid",
			school=3,
			ticks= 4,
			int= 3,
			["avg"] = { "306", "512", "690" },
			["add"] = { "612"/4, "1024"/4, "1380"/4 },
			coeff = .4,
			coeffadd = .2,
			smult =  1 + T["Arcane Instability"] * .01 + T["Fire Power"] * .02,
			smultadd = 1 + T["Arcane Instability"] * .01 + T["Fire Power"] * .02,
		},
		["Fireball"] = {
			type="hybrid",
			school=3,
			ticks=3,
			int=2,
			range=true,
			["low"] = { "14", "31", "53", "84", "139", "199", "255", "318", "392", "475", "561", "596", "633", "717", "783", "888" },
			["high"] = { "22", "45", "73", "116", "187", "265", "335", "414", "506", "609", "715", "760", "805", "913", "997", "1132" },
			["add"] = { "2"/3, "3"/3, "6"/3, "12"/3, "20"/3, "28"/3, "32"/3, "40"/3, "52"/3, "60"/3, "72"/3, "76"/3, "84"/3, "92"/3, "100"/3, "116"/3 },
			coeff = T["Empowered Fire"] * .05,
			coeffadd = 0,
			smult =  1 + T["Arcane Instability"] * .01 + T["Spell Impact"] * .02 + T["Fire Power"] * .02,
			smultadd = 1 + T["Arcane Instability"] * .01 + T["Spell Impact"] * .02 + T["Fire Power"] * .02,
		},
		["Fire Blast"] = {
			type="direct",
			school=3,
			range=true,
			["low"] = { "24", "57", "103", "168", "242", "332", "431", "539", "664", "760", "925" },
			["high"] = { "32", "71", "127", "202", "290", "394", "509", "637", "786", "900", "1095" },
			coeff = .4286,
			smult = 1 + T["Arcane Instability"] * .01 + T["Spell Impact"] * .02 + T["Fire Power"] * .02,
		},
		["Flamestrike"] = {
			type="hybrid",
			school=3,
			ticks=4,
			int=2,
			range=true,
			["low"] = { "52", "96", "154", "220", "291", "375", "471", "688", "873" },
			["high"] = { "68", "122", "192", "272", "359", "459", "575", "842", "1067" },
			["add"] = { "48"/4, "88"/4, "140"/4, "196"/4, "264"/4, "340"/4, "424"/4, "620"/4, "780"/4 },
			coeff = .2357,
			coeffadd = .1212,
			smult =  1 + T["Arcane Instability"] * .01 + T["Fire Power"] * .02,
			smultadd = 1 + T["Arcane Instability"] * .01 + T["Fire Power"] * .02,
		},
		["Scorch"] = {
			type="direct",
			school=3,
			range=true,
			["low"] = { "53", "77", "100", "133", "162", "200", "233", "269", "305", "321", "376" },
			["high"] = { "65", "93", "120", "159", "192", "239", "275", "317", "361", "376", "444" },
			coeff = .4286,
			smult = 1 + T["Arcane Instability"] * .01 + T["Spell Impact"] * .02 + T["Fire Power"] * .02,
		},
		["Pyroblast"] = {
			type="hybrid",
			school=3,
			ticks=4,
			int=2,
			range=true,
			["low"] = { "141", "180", "255", "329", "407", "503", "600", "708", "846", "939", "1014", "1190" },
			["high"] = { "187", "236", "327", "419", "515", "631", "750", "898", "1074", "1191", "1286", "1510" },
			["add"] = { "56", "72", "96", "124", "156", "188", "228", "268", "312", "356", "384", "452" },
			coeff = 1.15,
			coeffadd = 0,
			smult = 1 + T["Arcane Instability"] * .01 + T["Fire Power"] * .02,
			smultadd = 1 + T["Arcane Instability"] * .01 + T["Fire Power"] * .02,
		},
		["Blast Wave"] = {
			type="direct",
			school=3,
			range=true,
			["low"] = { "154", "201", "277", "365", "462", "533", "616", "882", "1047" },
			["high"] = { "186", "241", "329", "433", "544", "627", "724", "1038", "1233" },
			coeff = .1936,
			smult = 1 + T["Arcane Instability"] * .01 + T["Fire Power"] * .02,
		},
		["Dragon's Breath"] = {
			type="direct",
			school=3,
			range=true,
			["low"] = { "370", "454", "574", "680", "935", "1101" },
			["high"] = { "430", "526", "666", "790", "1085", "1279" },
			coeff = .1936,
			smult = 1 + T["Arcane Instability"] * .01 + T["Fire Power"] * .02,
		},
		["Frostfire Bolt"] = {
			type="hybrid",
			school=3,
			ticks=4,
			int=2,
			range=true,
			["low"] = { "629", "722" },
			["high"] = { "731", "838" },
			["add"] = { "60", "90" },
			coeff = .8573 + T["Empowered Fire"] * .05,
			coeffadd = 0,
			smult =  1 + T["Arcane Instability"] * .01 + T["Piercing Ice"] * .02 + T["Fire Power"] * .02 + T["Chilled to the Bone"] * .01,
			smultadd = 1 + T["Arcane Instability"] * .01 + T["Piercing Ice"] * .02 + T["Fire Power"] * .02 + T["Chilled to the Bone"] * .01,
		},
		["Blizzard"] = {
			type="channel",
			school=5,
			ticks =8,
			int=1,
			["avg"] = { "288", "504", "736", "1024", "1328", "1696", "2184", "2800", "3408" },
			coeff = .1437,
			smult = 1 + T["Arcane Instability"] * .01 + T["Piercing Ice"] * .02 + T["Arctic Winds"] * .01,
		},
		["Frost Ward"] = {
			type="absorb",
			school=5,
			["avg"] = { "165", "290", "470", "675", "875", "1125", "1950" },
			coeff = .8053,
			smult = 1,
		},
		["Cone of Cold"] = {
			type="direct",
			school=5,
			range=true,
			["low"] = { "98", "146", "203", "264", "335", "410", "559", "707" },
			["high"] = { "108", "160", "223", "290", "365", "448", "611", "773" },
			coeff = .214,
			smult =  1 + T["Arcane Instability"] * .01 + T["Spell Impact"] * .02 + T["Piercing Ice"] * .02 + T["Arctic Winds"] * .01,
		},
		["Frostbolt"] = {
			type="direct",
			school=5,
			range=true,
			["low"] = { "18", "31", "51", "74", "126", "174", "227", "292", "353", "429", "515", "536", "597", "630", "702", "799" },
			["high"] = { "20", "35", "57", "82", "138", "190", "247", "316", "383", "463", "555", "578", "643", "680", "758", "861" },
			coeff = .8143 + T["Empowered Frostbolt"],
			smult = 1 + T["Arcane Instability"] * .01 + T["Piercing Ice"] * .02 + T["Arctic Winds"] * .01 + T["Chilled to the Bone"] * .01,
		},
		["Frost Nova"] = {
			type="direct",
			school=5,
			range=true,
			["low"] = { "19", "33", "52", "70", "230", "365" },
			["high"] = { "21", "37", "58", "80", "260", "415" },
			coeff = .01986,
			smult = 1 + T["Arcane Instability"] * .01 + T["Piercing Ice"] * .02 + T["Arctic Winds"] * .01,
		},
		["Ice Lance"] = {
			type="direct",
			school=5,
			range=true,
			["low"] = { "161", "182", "221" },
			["high"] = { "187", "210", "255" },
			coeff = .1429,
			smult = 1 + T["Arcane Instability"] * .01 + T["Spell Impact"] * .02 + T["Piercing Ice"] * .02 + T["Arctic Winds"] * .01 + T["Chilled to the Bone"] * .01,
		},
	}
	-- Glyphs --
	if MrDamage.Glyphs[56368] == true then MrD.Info.Fireball.type = "direct" end
	if MrDamage.Glyphs[61205] == true then MrD.Info["Frostfire Bolt"]["smult"] = MrD.Info["Frostfire Bolt"]["smult"] + .02 end
	if MrDamage.Glyphs[56370] == true then MrD.Info["Frostbolt"]["smult"] = MrD.Info["Frostbolt"]["smult"] + .05 end
end

----
-- Dynamic Entries
----
function MrD_Mage_Dynamic()
	local info = MrD.Info
	local ud = UnitDebuff
	local allfire = 0; local allfrost = 0; allarcane = 0
	for k,v in pairs(info) do
		v.mult = v.smult
	end
	-- Curse of Elements/Ebon Plauge/Earth and Moon --
	if ud("target", "Curse of the Elements") or ud("target", "Ebon Plague") or ud("player", "Earth and Moon") then
		allfrost = allfrost + .13
		allfire = allfire + .13
		allarcane = allarcane + .13
	end
	-- Ice Lance 3x/4x damage on frozen targets --
	if ud("target", "Frost Nova") or ud("target", "Deep Freeze") or ud("target", "Freeze") or ud("target", "Frostbite") then
		local m
		if MrDamage.Glyphs[56377] then m = 3 else m = 2 end
		info["Ice Lance"]["mult"] = info["Ice Lance"]["mult"] + m
	end
	-- Torment the Weak Talent --
	if T["Torment the Weak"] > 0 then
		for index,value in pairs(Snares) do
			if UnitDebuff("target", index) then 
				info["Frostbolt"]["mult"] = info["Frostbolt"]["mult"] + T["Torment the Weak"] * .04
				info["Fireball"]["mult"] = info["Fireball"]["mult"] + T["Torment the Weak"] * .04
				info["Frostfire Bolt"]["mult"] = info["Frostfire Bolt"]["mult"] + T["Torment the Weak"] * .04
				info["Arcane Missiles"]["mult"] = info["Arcane Missiles"]["mult"] + T["Torment the Weak"] * .04
				info["Arcane Barrage"]["mult"] = info["Arcane Barrage"]["mult"] + T["Torment the Weak"] * .04
				info["Arcane Blast"]["mult"] = info["Arcane Blast"]["mult"] + T["Torment the Weak"] * .04
				do break end
			end
		end
	end
	-- Arcane Blast --
	local name, _, _, count = UnitBuff("player", "Arcane Blast")
	if name then
		local p
		if MrDamage.Glyphs[62210] then p = .18 else p = .15 end
		info["Arcane Blast"]["mult"] = info["Arcane Blast"]["mult"] + p * count
	end
	-- Molten Fury --
	if T["Molten Fury"] > 0 and UnitHealth("target") / UnitHealthMax("target") < .35 then
		for k,v in pairs(info) do
			if v.type ~= "absorb" then v.mult = v.mult + T["Molten Fury"] * .06 end
		end
	end
	-- Arcane Power --
	if UnitBuff("player", "Arcane Power") then
		for k,v in pairs(info) do
			if v.type ~= "absorb" then v.mult = v.mult + .2 end
		end
	end
end
