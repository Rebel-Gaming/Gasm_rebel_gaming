
----
-- Special Abilities
----
function MrD_LavaLash(rank, plusspellpower)
	if OffhandHasWeapon() then
		offlowDmg, offhiDmg = select(3, UnitDamage("player"))
		
		local f = CreateFrame( "GameTooltip", "MrDamage_Shaman_ItemScanTooltip" ); 
		f:SetOwner( WorldFrame, "ANCHOR_NONE" );
		f:AddFontStrings(
			f:CreateFontString( "$parentTextLeft1", nil, "GameTooltipText" ),
			f:CreateFontString( "$parentTextRight1", nil, "GameTooltipText" ) );
		f:ClearLines()
		f:SetInventoryItem("player", 17)
		
		for i = 1, f:NumLines() do
			local mytext = getglobal("MrDamage_Shaman_ItemScanTooltipTextLeft"..i)
			local text = mytext:GetText()
			
			if string.find(text, "Flametongue") then
				offlowDmg = offlowDmg * 1.25
				offhiDmg = offhiDmg * 1.25
			end
		end
		return (offlowDmg + offhiDmg)/2, offlowDmg, offhiDmg
	else
		return 0
	end
end

----
-- Dynamic Entries
----
function MrD_Shaman_Dynamic()
	local info = MrD.Info; local ud = UnitDebuff; local alldmg = 0;
	for k,v in pairs(info) do
		v.mult = v.smult
	end
	-- Stormstrike Debuff -- 
	if select(8, ud("target", "Stormstrike")) == "player" then
		for k,v in pairs(info) do
			if v.school == 4 then v.mult = v.mult + .2 end
		end
	end
	-- Flame Shock/Lava Burst --
	if select(9, ud("target", "Flame Shock")) == "player" then
		info["Lava Burst"]["mult"] = info["Lava Burst"]["mult"] + 1
	end
	-- Healing Way --
	local count, _, _, _, mine = select(4, UnitBuff("target", "Healing Way")) 
	if mine == "player" then
		info["Healing Wave"]["mult"] = info["Healing Wave"]["mult"] + 1 + count * .18
	end
	-- Lesser Healing Wave Glyph --
	if MrDamage.Glyphs[55438] == true and select(8, UnitBuff("target", "Earth Shield")) == "player" then 
		info["Lesser Healing Wave"]["mult"] = info["Lesser Healing Wave"]["mult"] + .2
	end
	-- Chain Heal/Riptide --
	if select(8, UnitBuff("target", "Riptide")) == "player" then 
		info["Chain Heal"]["mult"] = info["Chain Heal"]["mult"] + .25
	end
	-- Elemental Oath --
	if T["Elemental Oath"] > 0 and UnitBuff("player", "Clearcasting") then
		for k,v in pairs(info) do
			if v.school then v.mult = v.mult + T["Elemental Oath"] * .05 end
		end
	end
	-- Curse of Elements/Ebon Plauge/Earth and Moon --
	if ud("target", "Curse of the Elements") or ud("target", "Ebon Plague") or ud("player", "Earth and Moon") then
		alldmg = alldmg + .13
	end
	-- Frozen Power --
	if T["Frozen Power"] > 0 and select(8, UnitDebuff("target", "Frostbrand Attack")) == "player" then
		alldmg = alldmg + T["Frozen Power"] * .05
	end
	for k,v in pairs(info) do
		if v.school then v.mult = v.mult + alldmg end
	end
end

----
-- Table Creation w/ Static Entries
---
function MrD_Shaman_Static()

	MrD.Info = {
		["Attack"] = {
			melee=true,
			armor= true,
		},
		["Earth Shield"] = {
			type="ot",
			ticks= 6 + T["Improved Earth Shield"],
			["avg"] = { "150", "205", "270", "300", "337" },
			coeff= 2.857/6,
			smult= 1 + T["Improved Earth Shield"] * .1 + T["Purification"] * .02 + T["Improved Shields"] * .05,
		},
		["Lava Burst"] = {
			type="direct",
			range=true,
			school=3,
			["low"] = { "1012", "1192" },
			["high"] = { "1290", "1518" },
			coeff= .5714 + T["Shamanism"] * .04,
			smult= 1 + T["Concussion"] * .01 + T["Call of Flame"] * .02,
		},
		["Flame Shock"] = {
			type="hybrid",
			school=3,
			ticks= 4,
			int=3,
			["avg"] = { "21", "45", "86", "152", "230", "309", "377", "425", "500" },
			["add"] = { "28", "48", "96", "168", "256", "344", "420", "476", "556" },
			coeff= .2142,
			coeffadd= .1,
			smult= 1 + T["Concussion"] * .01 + T["Booming Echoes"],
			smultadd= 1 + T["Concussion"] * .01,
		},
		["Lightning Bolt"] = {
			type="direct",
			range=true,
			school=4,
			["low"] = { "13", "26", "45", "83", "125", "172", "227", "282", "347", "418", "495", "563", "595", "715"},
			["high"] = { "15", "30", "53", "95", "143", "194", "255", "316", "389", "467", "565", "643", "679", "815" },
			coeff= .7143 + T["Shamanism"] * .02,
			smult= 1 + T["Concussion"] * .01,
		},
		["Chain Lightning"] = {
			type="direct",
			range=true,
			school=4,
			["low"] = { "191", "277", "378", "493", "603", "734", "806", "973" },
			["high"] = { "217", "311", "424", "551", "687", "838", "920", "1111" },
			coeff= .57,
			smult= 1 + T["Concussion"] * .01,
		},
		["Healing Wave"] = {
			type="direct",
			range=true,
			["low"] = { "34", "64", "129", "268", "376", "536", "740", "1017", "1367", "1620", "1725", "2134", "2624", "3034" },
			["high"] = { "44", "78", "155", "316", "440", "622", "854", "1167", "1561", "1850", "1969", "2436", "2996", "3466" },
			coeff= 1.6106 + T["Tidal Waves"] * .04,
			smult= 1 + T["Purification"] * .02,
		},
		["Lesser Healing Wave"] = {
			type="direct",
			range=true,
			["low"] = { "162", "247", "337", "458", "631", "832", "1039", "1382", "1606" },
			["high"] = { "186", "281", "381", "514", "705", "928", "1185", "1578", "1834" },
			coeff= .8082 + T["Tidal Waves"] * .02,
			smult= 1 + T["Purification"] * .02,
		},
		["Chain Heal"] = {
			type="direct",
			range=true,
			["low"] = { "320", "405", "551", "605", "826", "906", "1055" },
			["high"] = { "368", "465", "629", "691", "942", "1034", "1205" },
			coeff= 1.34,
			smult= 1 + T["Purification"] * .02 + T["Improved Chain Heal"] * .1,
		},
		["Riptide"] = {
			type="hybrid",
			range=true,
			ticks=5,
			int=3,
			["low"] = { "639", "849", "1378", "1604" },
			["high"] = { "691", "919", "1492", "1736" },
			["add"] = { "665", "885", "1435", "1670" },
			coeff= .4,
			coeffadd= .18,
			smult= 1 + T["Purification"] * .02,
			smultadd= 1 + T["Purification"] * .02,
		},
		["Earth Shock"] = {
			type="direct",
			range=true,
			school= 4,
			["low"] = { "17", "32", "60", "119", "225", "359", "517", "658", "723", "849" },
			["high"] = { "19", "34", "64", "127", "239", "381", "545", "692", "761", "895" },
			coeff= .3858,
			smult= 1 + T["Concussion"] * .01,
		},
		["Frost Shock"] = {
			type="direct",
			range=true,
			school= 5,
			["low"] = {  "89", "206", "333", "486", "640", "681", "802" },
			["high"] = { "95", "220", "353", "514", "676", "719", "848" },
			coeff= .3858,
			smult= 1 + T["Concussion"] * .01,
		},
		["Thunderstorm"] = {
			type="direct",
			range=true,
			school= 4,
			["low"] = {  "551", "1074", "1226", "1450" },
			["high"] = { "629", "1226", "1400", "1656" },
			coeff= .193,
			smult= 1,
		},
		["Stormstrike"] = {
			melee=true,
			armor= true,
			type="both",
			perc= 1,
			smult= 1,
		},
		["Lava Lash"] = {
			type="special",
			armor= true,
		},
	}
	
	-- Glyphs --
	local info = MrD.Info
	if MrDamage.Glyphs[63273] then info.Riptide.ticks = 7 end
	if MrDamage.Glyphs[55453] then info["Lightning Bolt"]["smult"] = info["Lightning Bolt"]["smult"] + .04 end
	if MrDamage.Glyphs[63279] then info["Earth Shield"]["smult"] = info["Earth Shield"]["smult"] + .2 end
	if MrDamage.Glyphs[55447] then info["Flame Shock"]["ticks"] = info["Flame Shock"]["ticks"] + .2 end
end

--[[
-- Update Damage/Display Arrays
function Shaman:UpdateStatInfo()

	-- Spell Hit
	local moblevel = UnitLevel("target") -- Mob level
	if moblevel == 0 then moblevel = UnitLevel("player") -- If we dont have a target, we'll say an equal level mob
	elseif moblevel == -1 then moblevel = UnitLevel("player") + 3 end -- Skulls will be assumed to be 3 levels above
	if moblevel - UnitLevel("player") <=2 then
		basechancetomiss = moblevel - UnitLevel("player") + 4
	else
		basechancetomiss = 17
	end
	local spellmisschance = basechancetomiss - GetCombatRating(8)/26.25
	if UnitBuff("player", "Heroic Presence") == "Heroic Presence" then spellmisschance = spellmisschance - 1 end
	if UnitDebuff("target", "Misery") == "Misery" then spellmisschance = spellmisschance - 3 end
	spellmisschance = spellmisschance - T["Elemental Precision"]
	if spellmisschance <= 0 then
		spellonetohit = 0	-- Hit Capped
	elseif spellmisschance > 1 then
		spellonetohit = .01 -- Outside of 1% from hit capped
	else
		spellonetohit = spellmisschance/100 -- At or above 1% from hit capped
	end
	-- Spell Crit
	critchancemod = .5 + T["Elemental Fury"] * .1
	
	-- Melee Hit
	local weaplink = GetInventoryItemLink("player", 16)
	if weaplink then
		local weaptype = select(7, GetItemInfo(GetInventoryItemLink("player", 16))) -- Get our Weapon Type
	else
		weaptype = ""
	end
	for skillIndex = 1, GetNumSkillLines() do 
		local skillname, _, _, skillrank = GetSkillLineInfo(skillIndex)
		if skillname == weaptype then -- Scan our skill until we get a match
			currentweapskill = skillrank
		end
	end
	if not currentweapskill then currentweapskill = UnitLevel("player") * 5 end
	local moblevel = UnitLevel("target")
	if moblevel == 0 then moblevel = UnitLevel("player")
	elseif moblevel == -1 then moblevel = UnitLevel("player") + 3 end
	
	local weapontodef = (moblevel * 5) - currentweapskill -- Compare our weapon skill with the mobs defense
	if weapontodef > 10 then
		basechancetomiss = 6 + ((moblevel * 5) - currentweapskill - 10) * .4
	elseif weapontodef <= 0 then
		basechancetomiss = 5
	else
		basechancetomiss = 5 + ((moblevel * 5) - currentweapskill)*.1
	end
	local hitchance = GetCombatRating(6) / 32.8
	if UnitBuff("player", "Heroic Presence") == "Heroic Presence" then hitchance = hitchance + 1 end
	hitchance = hitchance + T["Dual Wield Specialization"]*2
	hitchance = basechancetomiss - hitchance
	if hitchance <= 0 then
		meleeonetohit = 0
	elseif hitchance > 1 then
		meleeonetohit = .01
	else
		meleeonetohit = hitchance/100
	end
end
--]]
