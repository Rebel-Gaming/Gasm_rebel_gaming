

----
-- Special Abilities
----
-- Heroic Strike --
function MrD_HeroicStrike(rank)
	local attack = MrD.Info["Heroic Strike"]
	local low, high = UnitDamage("player")
	local lowDamage; local highDamage;
	lowDamage = Armor( low * attack.perc + attack.avg[rank], attack )
	highDamage = Armor( high * attack.perc + attack.avg[rank], attack )
	if UnitDebuff("target", "Dazed") then
		lowDamage = lowDamage + attack.add[rank]
		highDamage = highDamage + attack.add[rank]
	end
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
-- Rend --
function MrD_Rend(rank)
	local attack = MrD.Info["Rend"]
	local ticks
	if GetInventoryItemLink("player", 16) then
		local f = CreateFrame( "GameTooltip", "MrDamage_Warrior_ItemScanTooltip" ); --F'n Rend! I hate Parsing tooltips!
		f:SetOwner( WorldFrame, "ANCHOR_NONE" );
		f:AddFontStrings(
			f:CreateFontString( "$parentTextLeft1", nil, "GameTooltipText" ),
			f:CreateFontString( "$parentTextRight1", nil, "GameTooltipText" ) );
		f:ClearLines()
		f:SetInventoryItem("player", 16)
		
		for i = 1, f:NumLines() do
			local mytext = getglobal("MrDamage_Warrior_ItemScanTooltipTextLeft"..i)
			local text = mytext:GetText()
			if string.find(text, "damage per second") then
				dps = string.sub(text, 2, string.find(text, "damage") - 2)
			end
		end
		for i = 1, f:NumLines() do
			local mytext = getglobal("MrDamage_Warrior_ItemScanTooltipTextRight"..i)
			local text = mytext:GetText()
			if text and string.find(text, "Speed") then				
				speed = string.sub(text, 7)
			end
		end
		avgweapondmg = dps * speed
		
		if MrDamage.Glyphs[58385] then ticks = 7 else ticks = 5 end
		pertick = ( (attack.avg[rank] + (avgweapondmg + AP()/14 * speed))/5 ) * attack.mult
		return pertick*ticks, ticks
	else
		return 0
	end
end
-- Execute --
function MrD_Execute(rank)
	if MrDamage.Glyphs[58367] then rage = UnitPower("player") + 10 else rage = UnitPower("player") end
	if rank <= 7 then fromrage = 3 * rank elseif rank == 8 then fromrage = 30 elseif rank == 9 then fromrage = 38 end
	totalDamage = Armor( ( (MrD.Info.Execute.avg[rank]+AP()*.2) + (rage * fromrage) ) * MrD.Info.Execute.mult, MrD.Info.Execute )
	return totalDamage
end
-- Bladestorm --
function MrD_Bladestorm(rank, plusap)
	lowDamage, highDamage, ohlowDamage, ohhighDamage = UnitDamage("player")
	lowDamage = Armor( (lowDamage + ohlowDamage) * MrD.Info.Bladestorm.mult, MrD.Info.Bladestorm )
	highDamage = Armor( (highDamage + ohhighDamage) * MrD.Info.Bladestorm.mult, MrD.Info.Bladestorm )
	return (lowDamage + highDamage)/2 * 6, lowDamage * 6, highDamage * 6
end
function MrD_Tooltip_Bladestorm(rank)
	local damage, low, high = MrD_Bladestorm(rank)
	GameTooltip:AddDoubleLine("Per Whirlwind (Each Second):", sf("%.0f", damage/6), 1,1,1,1,0,0)
	GameTooltip:AddDoubleLine("Lasts for:", "6 Secs", 1,1,1,1,0,0)
	GameTooltip:AddDoubleLine("DP Rage:", sf("%.2f", damage/25), 1,1,1,1,0,0)
	GameTooltip:AddDoubleLine("DPS:", sf("%.2f", damage/6), 1,1,1,1,0,0)
end

----
-- Dynamic Entries
----
function MrD_Warrior_Dynamic()
	local info = MrD.Info
	for k,v in pairs(info) do
		v.mult = v.smult
	end
end

----
-- Table Creation w/ Static Entries
---
function MrD_Warrior_Static()

	MrD.Info = {
		["Attack"] = {
			melee=true,
			armor= true,
		},
		["Shoot"] = {
			ranged=true,
			armor= true,
		},
		["Throw"] = {
			ranged=true,
			armor= true,
		},
		["Devastate"] = {
			melee=true,
			type="weap",
			armor= true,
			perc=.5,
			["avg"] = { "24", "40", "56", "85", "101" },
			smult = 1,
		},
		["Mortal Strike"] = {
			melee=true,
			type="weap",
			perc=1,
			armor= true,
			["avg"] = { "85", "110", "135", "160", "185", "210", "320", "380" },
			smult = 1 + T["Improved Mortal Strike"]*.03,
		},
		["Shield Slam"] = {
			melee=true,
			type="shield",
			perc=1,
			armor= true,
			["low"] = { "294", "346", "396", "447", "499", "549", "837", "990" },
			["high"] = { "308", "362", "416", "469", "523", "577", "879", "1040" },
			smult = 1,
		},
		["Slam"] = {
			melee=true,
			type="weap",
			perc=1,
			armor= true,
			["avg"] = { "32", "43", "68", "87", "105", "140", "220", "250" },
			smult = 1 + T["Unending Fury"]*.02,
		},
		["Cleave"] = {
			melee=true,
			type="weap",
			perc=1,
			armor= true,
			["avg"] = { "15", "30", "50", "70", "95", "135", "189", "222" },
			smult=1 + T["Improved Cleave"]*.4,
		},
		["Revenge"] = {
			melee=true,
			type="ap",
			perc=.207,
			range=true,
			armor= true,
			["low"] = { "89", "129", "175", "320", "498", "643", "699", "855", "1454" },
			["high"] = { "107", "157", "213", "390", "608", "785", "853", "1045", "1176" },
			smult = 1 + T["Improved Revenge"]*.1,
		},
		["Thunder Clap"] = {
			melee=true,
			type="ap",
			perc=.12,
			["avg"] = { "15", "34", "55", "82", "123", "154", "184", "247", "300" },
			smult = 1 + T["Improved Thunder Clap"]*.1,
		},
		["Heroic Strike"] = {
			melee=true,
			type="special",
			perc=1,
			armor= true,
			["avg"] = { "11", "21", "32", "44", "60", "93", "136", "178", "201", "234", "317", "432", "495" },
			["add"] = { "0", "0", "0", "0", "0", "0", "0", "0", "0", "81.9", "110.95", "151.2", "173.25" },
			smult=1,
		},
		["Overpower"] = {
			melee=true,
			type="weap",
			perc=1,
			armor= true,
			smult=1,
		},
		["Bloodthirst"] = {
			melee=true,
			type="ap",
			perc=.5,
			armor= true,
			smult= 1 + T["Unending Fury"] * .02,
		},
		["Victory Rush"] = {
			melee=true,
			type="ap",
			perc=.45,
			armor= true,
			smult= 1,
		},
		["Shockwave"] = {
			melee=true,
			type="ap",
			perc=.75,
			armor= true,
			smult= 1,
		},
		["Concussion Blow"] = {
			melee=true,
			type="ap",
			perc=.75,
			armor= true,
			smult= 1,
		},
		["Heroic Throw"] = {
			melee=true,
			type="ap",
			perc=.5,
			add=12,
			armor= true,
			smult=1,
		},
		["Whirlwind"] = {
			melee=true,
			type="both",
			perc=1,
			armor= true,
			smult= 1 + T["Improved Whirlwind"]*.1 + T["Unending Fury"]*.02,
		},
		["Bladestorm"] = {
			melee=true,
			armor= true,
			type="special",
			smult= 1,
		},
		["Rend"] = {
			melee=true,
			type="special",
			["avg"] = { "25", "40", "50", "70", "115", "150", "185", "215", "315", "380" },
			smult=1 + T["Improved Rend"]*.1,
		},
		["Execute"] = {
			melee=true,
			armor= true,
			type="special",
			["avg"] = { "93", "159", "282", "404", "554", "687", "865", "1142", "1456" },
			smult=1,
		},
	}
	if MrDamage.Glyphs[58368] then MrD.Info["Mortal Strike"]["smult"] = MrD.Info["Mortal Strike"]["smult"] + .1 end
end

