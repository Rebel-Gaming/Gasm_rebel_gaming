
----
-- Special Abilities
----
-- Conflagrate --
function MrD_Conflagrate(rank, plusspellpower)
	_, rankImmo, _, _, _, _, expirationTimeImmo, isMineImmo = UnitDebuff("target", "Immolate")
	_, rankSf, _, _, _, _, expirationTimeSf, isMineSf = UnitDebuff("target", "Shadowflame")
	local spell; local rank;
	if isMineImmo == "player" and ( isMineSf ~= "player" or expirationTimeImmo < expirationTimeSf ) then -- Immolate
		spell = MrD.Info["Immolate"]
		rank = tonumber(string.sub(rankImmo, 6))	
	elseif isMineSf == "player" and ( isMineImmo ~= "player" or expirationTimeSf < expirationTimeImmo ) then -- Shadow Flame
		spell = MrD.Info["Shadowflame"]
		rank = tonumber(string.sub(rankSf, 6))
	else
		return 0
	end
	local dmg = ( (spell.add[rank] + (GetSpellBonusDamage(3) + plusspellpower) * spell.coeffadd) * spell.mult ) * spell.ticks
	return dmg
end
function MrD_Tooltip_Conflagrate()
	_, rankImmo, _, _, _, _, expirationTimeImmo, isMineImmo = UnitDebuff("target", "Immolate")
	_, rankSf, _, _, _, _, expirationTimeSf, isMineSf = UnitDebuff("target", "Shadowflame")
	local spell; local rank;
	if isMineImmo == "player" and ( isMineSf ~= "player" or expirationTimeImmo < expirationTimeSf ) then -- Immolate
		GameTooltip:AddDoubleLine("Damage based on:", "Immolate (5 ticks)", 1,1,1,1,0,0)
		if MrDamage.Glyphs[56235] then
			GameTooltip:AddDoubleLine("Consumes:", "(None)", 1,1,1,1,0,0)
		else
			GameTooltip:AddDoubleLine("Consumes:", "Immolate", 1,1,1,1,0,0)
		end
	elseif isMineSf == "player" and ( isMineImmo ~= "player" or expirationTimeSf < expirationTimeImmo ) then -- Shadow Flame
		GameTooltip:AddDoubleLine("Damage based on:", "Shadowflame (4 ticks)", 1,1,1,1,0,0)
		if MrDamage.Glyphs[56235] then
			GameTooltip:AddDoubleLine("Consumes:", "(None)", 1,1,1,1,0,0)
		else
			GameTooltip:AddDoubleLine("Consumes:", "Shadowflame", 1,1,1,1,0,0)
		end
	else
		GameTooltip:AddDoubleLine("Damage based on:", "(No Spell Up)", 1,1,1,1,0,0)
	end
	GameTooltip:Show()
end
-- Life Tap --
function MrD_LifeTap(rank)
	local spell = MrD.Info["Life Tap"]
	totalGained = (spell["avg"][rank] + select(2, UnitStat("player", 5)) * spell["add"][rank]) * (1 + T["Improved Life Tap"]*.1)
	return totalGained
end
function MrD_Tooltip_LifeTap(rank)
	local spell = MrD.Info["Life Tap"]
	GameTooltip:AddDoubleLine("% Increase from Talents:", (T["Improved Life Tap"] * 10).."%", 1,1,1,0,1,1)
end

----
-- Dynamic Entries
----
function MrD_Warlock_Dynamic()
	local info = MrD.Info; local ud = UnitDebuff
	local allshadow = 0; local allfire = 0; alldot = 0
	for k,v in pairs(info) do
		v.mult = v.smult
	end
	-- Curse of Elements/Ebon Plauge/Earth and Moon --
	if ud("target", "Curse of the Elements") or ud("target", "Ebon Plague") or ud("player", "Earth and Moon") then
		allshadow = allshadow + .13
		allfire = allfire + .13
	end
	-- Death's Embrace --
	if UnitHealth("target")/UnitHealthMax("target") < .35 then
		allshadow = T["Death's Embrace"] * .04
	end
	-- Master Demonologist --
	if UnitCreatureFamily("pet") == "Succubus" or UnitCreatureFamily("pet") == "Felguard" then -- Master Demonologist
		allshadow = allshadow + T["Master Demonologist"] * .01
	elseif UnitCreatureFamily("pet") == "Imp" or UnitCreatureFamily("pet") == "Felguard" then
		allfire = allfire + T["Master Demonologist"] * .01 -- Master Demonologist
	end
	-- Molten Core --
	if UnitBuff("player", "Molten Core") then allfire = allfire + .1 end -- Molten Core
	for k,v in pairs(info) do
		if v.school == 6 then
			v.mult = v.mult + allshadow
		elseif v.school == 3 then
			v.mult = v.mult + allfire
		end
	end
	-- Shadow Embrace --
	local name, _, _, count = UnitDebuff("target", "Shadow Embrace")
	if name then alldot = alldot + count * .01 end
	-- Haunt --
	if select(8, UnitDebuff("target", "Haunt")) == "player" then alldot = alldot + .20 end
	for k,v in pairs(info) do
		if v.type == "ot" then
			v.mult = v.mult + alldot
		end
	end
	-- Drain Soul
	if UnitHealth("target")/UnitHealthMax("target") < .25 then
		info["Drain Soul"]["mult"] = info["Drain Soul"]["mult"] + 3
	end
end

----
-- Table Creation w/ Static Entries
---
function MrD_Warlock_Static()

	MrDamage_UpdateTalents()

	MrD.Info = {
		["Attack"] = {
			melee=true,
			armor= true,
		},
		["Shoot"] = {
			ranged=true
		},
		["Corruption"] = { 
			type="ot",
			school=6,
			ticks=6,
			int=3,
			["avg"] = { "40"/6, "90"/6, "222"/6, "324"/6, "486"/6, "666"/6, "822"/6, "900"/6, "984"/6, "1080"/6 },
			coeff = .2 * (1 + T["Empowered Corruption"] * .12) + T["Everlasting Affliction"] * .01,
			smult = 1 + T["Improved Corruption"] * .02 + T["Shadow Mastery"] * .03 + T["Siphon Life"] * .05 + T["Contagion"] * .01 + T["Malediction"] * .01,
		},
		["Curse of Agony"] = { 
			type="ot",
			school=6,
			ticks=12,
			int=2,
			["avg"] = { "84"/12, "180"/12, "324"/12, "504"/12, "780"/12, "1044"/12, "1356"/12, "1440"/12, "1740"/12 },
			coeff = .1,
			smult = 1 + T["Improved Curse of Agony"] * .02 + T["Shadow Mastery"] * .03 + T["Contagion"] * .01 + T["Malediction"] * .01,
		},
		["Curse of Doom"] = { 
			type="ot",
			school=6,
			ticks=1,
			int=60,
			["avg"] = { "3200", "4200", "7300" },
			coeff = 2,
			smult = 1,
		},
		["Unstable Affliction"] = { 
			type="ot",
			school=6,
			ticks=5,
			int=3,
			["avg"] = { "550"/5, "700"/5, "875"/5, "985"/5, "1150"/5 },
			coeff = .2 + T["Everlasting Affliction"] * .01,
			smult = 1 + T["Siphon Life"]/100 + T["Shadow Mastery"]/33.3333 + T["Contagion"]/100 + T["Malediction"] * .01,
		},
		["Immolate"] = { 
			type="hybrid",
			school=3,
			ticks=5,
			int=3,
			["avg"] = { "8", "19", "45", "90", "134", "192", "258", "279", "331.5", "370", "460" },
			["add"] = { "20"/5, "40"/5, "90"/5, "165"/5, "255"/5, "365"/5, "485"/5, "510"/5, "615"/5, "695"/5, "785"/5 },
			coeff = .2 + T["Fire and Brimstone"] * .03,
			coeffadd = .2 + T["Fire and Brimstone"] * .03,
			smult = 1 + T["Improved Immolate"] * .1 + T["Emberstorm"] * 03 + T["Malediction"] * .01,
			smultadd = 1 + T["Aftermath"] * .03 + T["Emberstorm"] * .03 + T["Improved Immolate"] * .1 + T["Malediction"] * .01,
		},
		["Hellfire"] = {
			type="channel",
			school=3,
			ticks=15,
			int=1,
			["avg"] = { "83", "139", "208", "306", "451"},
			coeff = .1427 ,
			smult = 1 + T["Emberstorm"] * .03 + T["Malediction"] * .01,
		},
		["Rain of Fire"] = {
			type="channel",
			school=3,
			ticks=4,
			int=2,
			["avg"] = { "240"/4, "544"/4, "880"/4, "1284"/4, "1808"/4, "2152"/4, "2700"/4 },
			coeff = .29,
			smult = 1 + T["Emberstorm"] * .03 + T["Malediction"] * .01,
		},
		["Drain Life"] = {
			type="channel",
			school=6,
			ticks=5,
			int=1,
			["avg"] = { "10", "17", "29", "41", "55", "71", "87", "108", "133" },
			coeff = .1430,
			smult = 1 + T["Shadow Mastery"] * .03 + T["Malediction"] * .01,
		},
		["Death Coil"] = {
			type="direct",
			school=6,
			["avg"] = { "244", "319", "400", "519", "670", "790" },
			coeff = .2140,
			smult = 1 + T["Shadow Mastery"] * .03 + T["Malediction"] * .01,
		},
		["Seed of Corruption"] = {
			type="hybrid",
			school=6,
			range=true,
			ticks = 6,
			int = 3,
			["low"] = { "1044", "1296", "1518" },
			["high"] = { "1290", "1607", "1897" },
			["add"] = { "1044"/6, "1296"/6, "1518"/6 },
			coeff = .2129,
			coeffadd = .25,
			smult = 1 + T["Shadow Mastery"] * .03 + T["Contagion"] * .01 + T["Malediction"] * .01,
			smultadd = 1 + T["Shadow Mastery"] * .03 + T["Contagion"] * .01 + T["Siphon Life"] * .05 + T["Malediction"] * .01,
		},
		["Shadowflame"] = {
			type="hybrid",
			school=6,
			schooladd=3,
			range=true,
			ticks=4,
			int=2,
			["low"] = { "520", "615" },
			["high"] = { "568", "671" },
			["add"] = { "544"/4, "644"/4 },
			coeff = .143,
			coeffadd = .28,
			smult = 1 + T["Shadow Mastery"] * .03 + T["Malediction"] * .01,
			smultadd = 1 + T["Emberstorm"] * .03 + T["Malediction"] * .01,
		},
		["Shadow Bolt"] = {
			type="direct",
			school=6,
			range=true,
			["low"] = { "12", "23", "48", "86", "142", "204", "281", "360", "455", "482", "541", "596", "690" },
			["high"] = { "16", "29", "56", "98", "162", "230", "315", "402", "507", "538", "603", "664", "770" },
			coeff = .8569 + T["Shadow and Flame"]*.04,
			smult = 1 + T["Shadow Mastery"] * .03 + T["Improved Shadow Bolt"] * .01 + T["Malediction"] * .01,
		},
		["Searing Pain"] = {
			type="direct",
			school=3,
			range=true,
			["low"] = { "34", "59", "86", "122", "158", "204", "243", "270", "295", "343" },
			["high"] = { "42", "71", "104", "146", "188", "240", "287", "320", "349", "405" },
			coeff = .4293,
			smult = 1 + T["Emberstorm"] * .03 + T["Malediction"] * .01,
		},
		["Soul Fire"] = {
			type="direct",
			school=3,
			range=true,
			["low"] = { "623", "703", "839", "1003", "1137", "1323" },
			["high"] = { "783", "881", "1051", "1257", "1423", "1657" },
			coeff = 1.15,
			smult = 1 + T["Emberstorm"] * .03 + T["Malediction"] * .01,
		},
		["Shadowfury"] = {
			type="direct",
			school=6,
			range=true,
			["low"] = { "343", "459", "612", "822", "968" },
			["high"] = { "407", "547", "728", "978", "1152" },
			coeff = .1932,
			smult = 1 + T["Shadow Mastery"] * .03 + T["Malediction"] * .01,
		},
		["Shadowburn"] = {
			type="direct",
			school=6,
			range=true,
			["low"] = { "87", "115", "186", "261", "350", "450", "518", "597", "662", "775" },
			["high"] = { "99", "131", "210", "293", "392", "502", "578", "665", "738", "775" },
			coeff = .4293,
			smult = 1 + T["Shadow Mastery"] * .03 + T["Malediction"] * .01,
		},
		["Incinerate"] = {
			type="direct",
			school=3,
			range=true,
			["low"] = { "87", "115", "186", "261", "350", "450", "518", "597", "662", "775" },
			["high"] = { "99", "131", "210", "293", "392", "502", "578", "665", "738", "775" },
			coeff = .7139 + T["Shadow and Flame"] * .04,
			smult = 1 + T["Emberstorm"] * .03 + T["Malediction"] * .01,
		},
		["Chaos Bolt"] = {
			type="direct",
			school=3,
			range=true,
			["low"] = { "837", "1077", "1217", "1429" },
			["high"] = { "1061", "1367", "1545", "1813" },
			coeff = .7139 + T["Shadow and Flame"] * .04,
			smult = 1 + T["Emberstorm"] * .03 + T["Malediction"] * .01,
		},
		["Haunt"] = {
			type="direct",
			school=6,
			range=true,
			["low"] = { "405", "487", "550", "645" },
			["high"] = { "473", "569", "642", "753" },
			coeff = .4793,
			smult = 1 + T["Shadow Mastery"] * .03 + T["Malediction"] * .01,
		},
		["Drain Soul"] = {
			type="channel",
			school=6,
			ticks=5,
			int=3,
			["avg"] = { "55"/5, "155"/5, "295"/5, "455"/5, "620"/5, "710"/5 },
			coeff = .420,
			smult = 1 + T["Shadow Mastery"] * .03 + T["Malediction"] * .01,
		},
		["Shadow Ward"] = {
			type="absorb",
			["avg"] = { "290", "470", "675", "875", "2750", "3300" },
			coeff = .3,
			smult = 1,
		},
		-- Special Abilities -- Abilites that will have their own calculations.
		["Life Tap"] = {
			type="special",
			["avg"] = { "0", "6", "24", "37", "42", "500", "710", "1490" },
			["add"] = { "1", "1.5", "2", "2.5", "3", "3", "3", "3"},
		},
		["Conflagrate"] =  {
			type="special",
		},	
	}
end

