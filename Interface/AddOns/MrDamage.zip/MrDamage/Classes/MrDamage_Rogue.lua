
----
-- Special Abilities
----
-- Envenom --
function MrD_Envenom()
	local info = MrD.Info.Envenom
	numdeadly = 0
	for i = 1, 40 do
		name, _, _, count, _, _, _, caster = UnitDebuff("target", i)
		if name and string.sub(name, 1, 13) == "Deadly Poison" and caster == "player" then numdeadly = count end
	end
	if GetComboPoints("player", "target") == 0 or numdeadly == 0 then
		return 0
	elseif numdeadly > ComboPoints() then
		totalDamage = ((GetComboPoints("player", "target") * 75) + AP() * (.07 * ComboPoints())) * info.mult
	else
		totalDamage = ((numdeadly * 75) + AP() * (.07 * numdeadly)) * info.mult
	end
	return totalDamage
end
-- Fan of Knives --
function MrD_FanofKnives(rank)
	local info = MrD.Info["Fan of Knives"]
	lowDmg, hiDmg, offlowDmg, offhiDmg = UnitDamage("player");
	mainhand = GetInventoryItemLink("player", 16)
	offhand = GetInventoryItemLink("player", 17)
	if mainhand then if select(7, GetItemInfo(mainhand)) == "Daggers" then mainmod = 1.5 else mainmod = 1 end else mainmod = 0 end
	if offhand then if select(7, GetItemInfo(offhand)) == "Daggers" then offmod = 1.5 else offmod = 1 end else offmod = 0 end
	lowDamage =  Armor( ((lowDmg * mainmod) + (offlowDmg * offmod)) * info.mult, info )
	highDamage =  Armor( ((hiDmg * mainmod) + (offhiDmg * offmod)) * info.mult, info )
	if MrDamage.Glyphs[63254] then
		lowDamage = lowDamage * 1.2
		highDamage = highDamage * 1.2
	end
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end

----
-- Table Creation w/ Static Entries
---
function MrD_Rogue_Static()

	MrD.Info = {
		["Attack"] = {
			melee=true,
			armor= true,
			smult= 1,
		},
		["Shoot"] = {
			ranged=true,
			armor= true,
			smult= 1,
		},
		["Throw"] = {
			ranged=true,
			armor= true,
			smult= 1,
		},
		["Sinister Strike"] = {
			melee=true,
			type="weap",
			perc=1,
			armor= true,
			["avg"] = { "3", "6", "10", "15", "22", "33", "52", "68", "80", "98", "150", "180" },
			smult = 1 + T["Aggression"] * .02 + T["Surprise Attacks"] * .1 + T["Find Weakness"] * .02,
		},
		["Backstab"] = {
			melee=true,
			type="weap",
			armor= true,
			perc=1.5 + T["Sinister Calling"] *.02,
			["avg"] = { "15", "30", "48", "69", "90", "135", "165", "210", "225", "225", "382.5", "465" },
			smult = 1 + T["Aggression"] * .03 + T["Opportunity"] * .1 + T["Blade Twisting"] * .05 + T["Surprise Attacks"] * .1,
		},
		["Ambush"] = {
			melee=true,
			armor= true,
			type="weap",
			perc=2.75,
			["avg"] = { "77", "110", "137.5", "203.5", "253", "319", "368.5", "508.75", "770", "907.5" },
			smult = 1 + T["Opportunity"] * .1,
		},
		["Gouge"] = {
			melee=true,
			type="ap",
			perc=.21,
			["avg"] = { "1" },
			smult = 1 + T["Surprise Attacks"] * .1,
		},
		["Garrote"] = {
			melee=true,
			type="ap",
			dot=true,
			perc=.07,
			ticks=6,
			int=3,
			["avg"] = { "20", "27", "37", "45", "57", "71", "85", "102", "110", "119" },
			smult = 1 + T["Opportunity"] * .1,
		},
		["Rupture"] = {
			melee=true,
			type="ap",
			dot=true,
			perc = { ".015", ".024", ".03", ".03428571", ".0375" },
			ticks = { "4", "5", "6", "7", "8" },
			int=3,
			["combo"] = { 
				[1] = { "10", "15", "22", "32", "44", "68", "81", "122", "145" },
				[2] = { "12", "18", "26", "37", "51", "76", "92", "137", "163" },
				[3] = { "14", "21", "30", "42", "58", "84", "103", "152", "181" },
				[4] = { "16", "24", "34", "47", "65", "92", "114", "167", "119" },
				[5] = { "18", "27", "38", "52", "72", "100", "125", "182", "217" },
			},
			smult = 1 + T["Serrated Blades"] * .1 + T["Blood Spatter"] * .15,
		},
		["Eviscerate"] = {
			melee=true,
			armor= true,
			type="ap",
			range=true,
			percl = { ".03", ".06", ".03", ".09", ".12" },
			perch = { ".07", ".14", ".21", ".28", ".35" },
			combo=true,
			["combol"] = { 
				[1] = { "6", "14", "25", "41", "60", "93", "114", "199", "224", "245", "405", "497" },
				[2] = { "11", "25", "44", "72", "105", "164", "254", "350", "394", "430", "706", "867" },
				[3] = { "16", "36", "63", "103", "150", "235", "364", "501", "564", "615", "1007", "1237" },
				[4] = { "21", "47", "82", "134", "195", "306", "474", "652", "734", "800", "1308", "1607" },
				[5] = { "26", "58", "101", "165", "240", "377", "584", "803", "904", "985", "1609", "1977" },
			},
			["comboh"] = { 
				[1] = { "10", "22", "39", "61", "90", "137", "212", "295", "332", "365", "613", "751" },
				[2] = { "15", "33", "58", "92", "135", "208", "322", "446", "502", "550", "914", "1121" },
				[3] = { "20", "44", "77", "123", "180", "279", "432", "597", "672", "735", "1215", "1491" },
				[4] = { "25", "55", "96", "154", "225", "350", "542", "748", "842", "920", "1516", "1861" },
				[5] = { "30", "66", "115", "185", "270", "421", "652", "899", "1012", "1105", "1817", "2231" },
			},
			smult = 1 + T["Opportunity"] * .1 + T["Serrated Blades"] * .15,
		},
		["Mutilate"] = {
			melee=true,
			armor= true,
			perc=1,
			type="both",
			["add"] = { "44"*2, "63"*2, "88"*2, "101"*2, "153"*2, "181"*2 },
			smult = 1 + T["Opportunity"] * .1,
		},
		["Riposte"] = {
			type="weap",
			armor= true,
			melee = true,
			perc=1.5,
			smult=1,
		},
		["Ghostly Strike"] = {
			type="weap",
			armor= true,
			melee = true,
			perc=1.25,
			smult=1,
		},
		["Hemorrhage"] = {
			type="weap",
			armor= true,
			melee = true,
			perc= 1.1+T["Sinister Calling"]*.02,
			smult = 1 + T["Surprise Attacks"] * .1,
		},
		["Envenom"] = {
			type="special",
			smult = 1 + T["Vile Poisons"] * .07
		},
		["Fan of Knives"] = {
			type="special",
			armor= true,
			smult=1,
		},
		--[[
			Rank.Low["Deadly Throw"] = { "164", "223", "350" }
			Rank.High["Deadly Throw"] = { "180", "245", "386" }	
		--]]
		
	}
	if MrDamage.Glyphs[56814] then MrD.Info["Ghostly Strike"]["smult"] = MrD.Info["Ghostly Strike"]["smult"] + .4 end
	if MrDamage.Glyphs[56812] then MrD.Info.Garrote.ticks = 5; MrD.Info.Garrote.smult = MrD.Info.Garrote.smult + .2 end
end

----
-- Dynamic Entries
----
function MrD_Rogue_Dynamic()
	local creature = UnitCreatureType
	local info = MrD.Info
	local alldmg = 0
	for k,v in pairs(info) do
		v.mult = v.smult
	end
	-- Improved Kidney Shot --
	if select(8, UnitDebuff("target", "Kidney Shot")) == "player" then
		alldmg = alldmg + T["Improved Kidney Shot"] *.03
	end
	-- Murder --
	if creature("target") == "Humanoid" or creature("target") == "Beast" or creature("target") == "Dragonkin" or creature("target") == "Giant" then
		alldmg = alldmg + T["Murder"] * .02
	end
	-- Diry Deeds --
	if UnitHealth("target") / UnitHealthMax("target") < .35 then
		alldmg = alldmg + T["Dirty Deeds"] * .1
	end
	-- Hunger for Blood --
	if UnitBuff("player", "Hunger for Blood") then
		if MrDamage.Glyph[63249] then
			alldmg = alldmg + .18
		else
			alldmg = alldmg + .15
		end
	end
	-- Find Weakness --
	alldmg = alldmg + T["Find Weakness"] * .02
	for k,v in pairs(info) do
		v.mult = v.mult + alldmg
	end
	-- Mutilate --
	for i = 1, 40 do 
		if select(5, UnitDebuff("target", i)) == "Poison" then
			info.Mutilate.mult = info.Mutilate.mult + .2
		end
	end
end
