
----
-- Special Abilities
----
-- Judgements --
function MrD_Judgement()
	local name; local base; local attack;
	for i = 1, 40 do
		for k,v in pairs(Judgements) do
			if UnitBuff("player", i) == k then
				name = k
				base = v
				attack = MrD.Info[k]
			end
		end
	end
	if attack then
		if base == "weap" then
			local lowDamage, highDamage = UnitDamage("player"); 
			local low; local high;
			low = (attack.jperc * lowDamage + attack.jcoeffa * AP() + attack.jcoeffs * GetSpellBonusDamage(2)) * attack.jmult
			high = (attack.jperc * highDamage + attack.jcoeffa * AP() + attack.jcoeffs * GetSpellBonusDamage(2)) * attack.jmult
			return (low + high)/2, low, high
		else
			local dmg = (base + attack.jcoeffa * AP() + attack.jcoeffs * GetSpellBonusDamage(2)) * attack.jmult
			return dmg
		end
	else
		return 0
	end
end
-- Updates Tooltips for Judjements --
function MrD_Tooltip_Judgement()
	local name; local base; local attack;
	for i = 1, 40 do
		for k,v in pairs(Judgements) do
			if UnitBuff("player", i) == k then
				name = k
				base = v
				attack = MrD.Info[k]
			end
		end
	end
	if name then
		GameTooltip:AddDoubleLine("Seal:", name, 1,1,1,1,0,0)
		
		local avg, low, high = MrD_Judgement()
		if low then
			GameTooltip:AddDoubleLine("Damage:", sf("%.0f", low).." to "..sf("%.0f", high), 1,1,1,1,0,0)
		end
		GameTooltip:AddDoubleLine("DP Mana:", sf("%.2f", avg/select(4, GetSpellInfo("Jusdgement of Light"))), 1,1,1,1,0,0)
	end
	GameTooltip:Show()
end
-- Damage Functions --
function MrD_JudgementofJustice()
	return MrD_Judgement()
end
function MrD_JudgementofWisdom()
	return MrD_Judgement()
end
function MrD_JudgementofLight()
	return MrD_Judgement()
end
-- Tooltip Function --
function MrD_Tooltip_JudgementofWisdom()
	MrD_Tooltip_Judgement()
end
function MrD_Tooltip_JudgementofJustice()
	return MrD_Tooltip_Judgement()
end
function MrD_Tooltip_JudgementofLight()
	MrD_Tooltip_Judgement()
end
-- Seal of Righteousness --
function MrD_SealofRighteousness(rank)
	local attack = MrD.Info["Seal of Righteousness"]
	local dmg = UnitAttackSpeed("player") * (attack.coeffa * AP() + attack.coeffs * GetSpellBonusDamage(2)) * attack.mult
	return dmg
end

----
-- Table Creation w/ Static Entries
---
function MrD_Paladin_Static()

	-- 1 is ap/sp based, 2 = weap/ap/sp
	Judgements = { 
		["Seal of Righteousness"] = 1,
		["Seal of Justice"] = 1,
		["Seal of Light"] = 1,
		["Seal of Wisdom"] =  1,
		["Seal of Vengeance"] = 1,
		["Seal of Blood"] = "weap",
		["Seal of the Martyr"] = "weap",
	}
	MrD.Info = {
		["Attack"] = {
			melee= true,
			armor= true,
		},
		["Consecration"] = {
			type="ot",
			school= 2,
			ticks= 8,
			spandap= true,
			["avg"] = { "9", "17", "28", "42", "56", "72", "87", "113" },
			coeffs= .04,
			coeffa= .04,
			smult= 1 + T["Crusade"] * .01,
		},
		["Holy Light"] = {
			type="direct",
			range= true,
			["low"] = { "50", "96", "203", "397", "628", "894", "1209", "1595", "2034", "2232", "2818", "4199", "4888" },
			["high"] = { "60", "116", "239", "455", "708", "998", "1349", "1777", "2266", "2486", "3138", "4677", "5444" },
			coeff= 1.66,
			smult= 1 + T["Healing Light"] * .04 + T["Divinity"]*.01,
		},
		["Exorcism"] = {
			type="direct",
			school= 2,
			range= true,
			spandap= true,
			["low"] = { "96", "173", "250", "350", "452", "564", "687", "787", "1028" },
			["high"] = { "110", "195", "282", "394", "506", "628", "765", "877", "1146" }, -- 9
			coeffs= .15,
			coeffa= .15,
			smult= 1 + T["Sanctity of Battle"] * .05 + T["Crusade"] * .01,
		},
		["Flash of Light"] = {
			type="direct",
			range= true,
			["low"] = { "81", "124", "189", "256", "346", "445", "588", "682", "785" },
			["high"] = { "93", "144", "211", "288", "390", "499", "658", "764", "879" }, -- 9
			coeff= 1,
			smult= 1 + T["Healing Light"] * .04 + T["Divinity"]*.01,
		},
		["Holy Wrath"] = {
			type="direct",
			school= 2,
			range= true,
			spandap= true,
			["low"] = { "399", "551", "777", "857", "1050" },
			["high"] = { "471", "649", "913", "1007", "1234" }, -- 5
			coeffs= .07,
			coeffa= .07,
			smult= 1 + T["Crusade"] * .01,
		},
		["Holy Shock"] = {
			type="direct",
			both= true,
			rangeheal= true,
			rangedmg= true,
			["dlow"] = { "314", "431", "562", "693", "904", "1043", "1296" },
			["dhigh"] = { "340", "465", "608", "749", "978", "1129", "1402" },
			["hlow"] = { "481", "644", "845", "1061", "1258", "2065", "2401" },
			["hhigh"] = { "519", "696", "915", "1149", "1362", "2235", "2599" },	
			dcoeff= .4286,
			hcoeff= .81,
			dsmult= 1 + T["Healing Light"] * .04 + T["Crusade"] * .01,
			hsmult= 1 + T["Healing Light"] * .04 + T["Divinity"]*.01,
		},
		["Holy Shield"] = {
			type="ot",
			school= 2,
			ticks= 8,
			int= 2,
			["avg"] = { "79", "116", "157", "208", "235", "274" },
			spandap= true,
			coeffs= .09,
			coeffa= .056,
			smult= 1 + T["Crusade"] * .01,
		},
		["Avenger's Shield"] = {
			type="direct",
			school= 2,
			range= true,
			spandap= true,
			["low"] = { "440", "601", "796", "913", "1100" }, -- 5
			["high"] = { "536", "733", "972", "1115", "1344" },
			coeffs= .07,
			coeffa= .07,
			smult= 1 + T["Crusade"] * .01,
		},
		["Shield of Righteousness"] = {
			melee= true,
			school= 2,
			type="shield",
			school=2,
			perc=1.3,
			["avg"] = { "390", "520" },
			smult= 1 + T["Crusade"] * .01,
		},
		["Hammer of Wrath"] = {
			type="direct",
			school= 2,
			range= true,
			spandap= true,
			["low"] = { "351", "459", "570", "733", "878", "1139" },
			["high"] = { "387", "507", "628", "809", "970", "1257" },
			coeffs= .15,
			coeffa= .15,
			smult= 1 + T["Crusade"] * .01,
		},
		["Crusader Strike"] = {
			melee= true,
			type="weap",
			perc= 1.1,
			smult= 1 + T["The Art of War"]*.05 + T["Sanctity of Battle"] * .05 + T["Crusade"] * .01,
		},
		["Divine Storm"] = {
			melee= true,
			type="weap",
			perc= 1.1,
			smult= 1 + T["The Art of War"]*.05 + T["Crusade"] * .01,
		},
		["Seal of Blood"] = {
			melee= true,
			type= "weap",
			perc= .48,
			jperc= .26,
			jcoeffs= .18,
			jcoeffa= .11,
			smult= 1 + T["Judgements of the Pure"]*.05 + T["Crusade"] * .01,
			jsmult= 1 + T["Judgements of the Pure"]*.05 + T["Crusade"] * .01,
		},
		["Seal of the Martyr"] = {
			melee= true,
			type= "weap",
			perc= .48,
			jperc= .26,
			jcoeffs= .18,
			jcoeffa= .11,
			smult= 1 + T["Judgements of the Pure"]*.05 + T["Crusade"] * .01,
			jsmult= 1 + T["Judgements of the Pure"]*.05 + T["Crusade"] * .01,
		},
		["Seal of Vengeance"] = {
			type= "ot",
			school= 2,
			ticks= 5,
			int= 3,
			spandap= true,
			avg= { "0" },
			coeffs= .013,
			coeffa= .025,
			jcoeffs= .22,
			jcoeffa= .14,
			smult= 1 + T["Seals of the Pure"]*.03 + T["Judgements of the Pure"] * .05 + T["Crusade"] * .01,
			jsmult= 1 + T["Seals of the Pure"]*.03 + T["Judgements of the Pure"] * .05 + T["The Art of War"] * .05 + T["Crusade"] * .01,
		},
		["Seal of Corruption"] = {
			type= "ot",
			school= 2,
			ticks= 5,
			int= 3,
			spandap= true,
			avg= { "0" },
			coeffs= .013,
			coeffa= .025,
			jcoeffs= .22,
			jcoeffa= .14,
			smult= 1 + T["Seals of the Pure"]*.03 + T["Judgements of the Pure"] * .05 + T["Crusade"] * .01,
			jsmult= 1 + T["Seals of the Pure"]*.03 + T["Judgements of the Pure"] * .05 + T["The Art of War"] * .05 + T["Crusade"] * .01,
		},
		["Seal of Righteousness"] = {
			type="special",
			school= 2,
			coeffs= .044,
			coeffa= .022,
			jcoeffs= .2,
			jcoeffa= .32,
			smult= 1 + T["Seals of the Pure"]*.03 + T["Judgements of the Pure"] * .05 + T["Crusade"] * .01,
			jsmult= 1 + T["Seals of the Pure"]*.03 + T["Judgements of the Pure"] * .05 + T["The Art of War"] * .05 + T["Crusade"] * .01,
		},
		["Judgement of Justice"] = {
			type="special",
		},
		["Judgement of Wisdom"] = {
			type="special",
		},
		["Judgement of Light"] = {
			type="special",
		},
	}
	-- Glyphs --
	local info = MrD.Info
	if MrDamage.Glyphs[56414] then 
		info["Seal of Righteousness"]["mult"] = info["Seal of Righteousness"]["mult"] + .1
		info["Seal of Righteousness"]["jmult"] = info["Seal of Righteousness"]["jmult"] + .1
	end
	if MrDamage.Glyphs[54930] then info["Avenger's Shield"] = info["Avenger's Shield"] + 1 end
	if MrDamage.Glyphs[54928] then info.Consecration.ticks = 10 end
	if MrDamage.Glyphs[54934] then info.Exorcism.mult = info.Exorcism.mult + .2 end
	if MrDamage.Glyphs[54922] then 
		for k,v in pairs(info) do
			if v.jmult then v.jmult = v.jmult + .2 end
		end
	end
end

----
-- Dynamic Entries
----
function MrD_Paladin_Dynamic()
	local info = MrD.Info
	local alldmg = 0;
	for k,v in pairs(info) do
		if v.both then
			if UnitIsEnemy("player", "target") then v.mult = v.hsmult
			else v.mult = v.dsmult end
		else v.mult = v.smult end
	end
	if T["One-Handed Weapon Specialization"] > 0 then
		itemLink = GetInventoryItemLink("player", 16)
		if itemLink then
			weaponType = select(7, GetItemInfo(itemLink))
			if string.find(weaponType, "One") then
				alldmg = alldmg + T["One-Handed Weapon Specialization"] * .04
			end
		end
	end
	local c = UnitCreatureType
	if c("target") == "Humanoid" or c("target") == "Demon" or c("target") == "Undead" or c("target") == "Elemental" then
		alldmg = alldmg + T["Crusade"] * .01
	end
	if UnitBuff("player", "Divine Favor") then
		info["Holy Light"]["mult"] = info["Holy Light"]["mult"] + 1
		info["Flash of Light"]["mult"] = info["Flash of Light"]["mult"] + 1
		info["Holy Shock"]["mult"] = info["Holy Shock"]["mult"] + 1
	end
	for k,v in pairs(info) do
		if v.both then 
			if UnitIsEnemy("player", "target") then v.mult = v.mult + alldmg end
		elseif v.school then
			v.mult = v.mult + alldmg
		end
	end
end


			

