
function MrDamage_UpdateRankData()
	Rank = { Low = {}, Average = {}, High = {}, Heal = {}, Special = {} }
	RankAdd = { Low = {}, Average = {}, High = {} }
	
	-- Removes spaces --
	local class = UnitClass("player")
	classname = ""
	for word in string.gmatch(class, "%a+") do classname = classname..word end

	local func = _G["MrDamage_UpdateRank_"..classname]
	func()
end

function GetSpellBase(spell, rank)
	if Rank.Low[spell] then
		return Rank.Low[spell][rank], Rank.High[spell][rank]
	elseif Rank.Average[spell][rank] then
		return Rank.Average[spell][rank]
	end
end
function MrDamage_UpdateRank_Priest()
	MrD_Priest_Static()
end
function MrDamage_UpdateRank_DeathKnight()

	Rank.Low["Icy Touch"] = { "127", "144", "161", "187", "227" }
	Rank.High["Icy Touch"] = { "137", "156", "173", "203", "245" }
	Rank.Average["Plague Strike"] = { "62.5", "75.5", "89", "108", "157", "189" }
	Rank.Average["Blood Strike"] = { "104", "118", "138.8", "164.4", "250", "305.6" }
	Rank.Average["Death Coil"] = { "167", "208", "275", "381", "443" }
	Rank.Average["Heart Strike"] = { "125", "142", "167", "197.5", "300.5", "368" }
	Rank.Average["Scourge Strike"] = { "151.875", "186.75", "291.375", "357.188" }
	Rank.Average["Death Strike"] = { "84", "97.5", "123.75", "187.5", "222.75" }
	Rank.Average["Obliterate"] = { "198.4", "244", "381.6", "467.2" }
	Rank.Low["Howling Blast"] = { "198", "324", "441", "518" }
	Rank.High["Howling Blast"] = { "214", "352", "479", "562" }
	Rank.Average["Frost Strike"] = { "52.2", "61.8", "69", "85.2", "120.6", "150" }
	Rank.Average["Unholy Blight"] = { "21", "30", "40", "48" }
	Rank.Average["Corpse Explosion"] = { "166", "192", "262", "383", "443" }
	Rank.Low["Blood Boil"] = { "89", "116", "149", "180" }
	Rank.High["Blood Boil"] = { "107", "140", "181", "220" }
	Rank.Average["Death and Decay"] = { "26", "34", "49", "62" }

end

function MrDamage_UpdateRank_Druid()
	MrD_Druid_Static()
end
function MrDamage_UpdateRank_Warlock()
	MrD_Warlock_Static()
end
function MrDamage_UpdateRank_Shaman()
	MrD_Shaman_Static()
end
function MrDamage_UpdateRank_Warrior()
	MrD_Warrior_Static()
end
function MrDamage_UpdateRank_Paladin()
	MrD_Paladin_Static()
end
function MrDamage_UpdateRank_Mage()
	MrD_Mage_Static()
end
function MrDamage_UpdateRank_Rogue()
	MrD_Rogue_Static()
end
function MrDamage_UpdateRank_Hunter()

	-- Beast Mastery --
	Rank.Average["Mend Pet"] = { "125", "250", "450", "700", "1000", "1400", "1825", "2375", "4250", "5250" }
	-- Marksmanship --
	Rank.Average["Serpent Sting"] = { "20", "40", "80", "140", "210", "290", "385", "490", "555", "660", "990", "1210" }
	Rank.Average["Arcane Shot"] = { "15", "23", "36", "65", "91", "125", "158", "200", "273", "402", "492" }
	Rank.Average["Mult-Shot"] = { "0", "40", "80", "120", "150", "205", "333", "408" }
	Rank.Average["Volley"] = { "52", "79", "105", "168", "290", "353" }
	Rank.Average["Steady Shot"] = { "45", "108", "198", "252" }
	Rank.Average["Kill Shot"] = { "410", "500", "650" }
	Rank.Average["Aimed Shot"] = { "5", "35", "55", "90", "110", "150", "205", "345", "408" }
	-- Survival
	Rank.Average["Raptor Strike"] = { "5", "11", "21", "34", "50", "80", "110", "140", "170", "275", "335" }
	Rank.Average["Immolation Trap"] = { "105", "215", "340", "510", "690", "985", "1540", "1885" }
	Rank.Average["Mongoose Bite"] = { "25", "45", "75", "115", "150", "280" }
	Rank.Average["Black Arrow"] = { "785", "940", "1205", "1480", "2240", "2765" }
	Rank.Average["Wyvern Sting"] = { "300", "420", "600", "942", "2082", "2460" }
	Rank.Average["Counterattack"] = { "48", "84", "132", "196", "288", "342" }
	Rank.Low["Explosive Shot"] = { "144", "221", "325", "386" }
	Rank.High["Explosive Shot"] = { "172", "265", "391", "464" }
	Rank.Low["Explosive Trap"] = { "100", "139", "201", "263", "434", "523" }
	Rank.High["Explosive Trap"] = { "130", "187", "257", "337", "556", "670" }
end
