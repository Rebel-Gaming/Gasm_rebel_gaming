
----
-- Special Abilities
----
-- Ferocious Bite --
function MrD_FerociousBite(rank)
	if GetComboPoints("player", "target") > 0 then
		local energy; local attack = MrD.Info["Ferocious Bite"]
		if UnitPower("player") > 65 then  energy = 30  elseif UnitPower("player") > 35 then energy = UnitPower("player") - 35 else energy = 0 end
		local EnergyDamage = energy * (attack.add[rank] + AP()/410)
		local low = Armor( (attack.combol[GetComboPoints("player", "target")][rank] + .07*GetComboPoints("player", "target")*AP() + EnergyDamage) * attack.mult )
		local high = Armor( (attack.comboh[GetComboPoints("player", "target")][rank] + .07*CGetComboPoints("player", "target")*AP() + EnergyDamage) * attack.mult )
		return (lowDamage + highDamage)/2, lowDamage, highDamage
	else
		return 0
	end
end
-- Swiftmend --
function MrD_Swiftmend(rank, plusspellpower)
	_, rankRejuv, _, _, _, _, expirationTimeRejuv, isMineRejuv = UnitDebuff("target", "Rejuvenation")
	_, rankRegrow, _, _, _, _, expirationTimeRegrow, isMineRegrow = UnitDebuff("target", "Regrowth")
	local spell; local rank; local mult;
	if isMineRejuv == "player" and ( isMineRegrow ~= "player" or expirationTimeRejuv < expirationTimeRegrow ) then -- Rejuvanation
		spell = MrD.Info["Rejuvenation"]
		mult = spell.mult
		rank = tonumber(string.sub(rankRejuv, 6))	
	elseif isMineRegrow == "player" and ( isMineRejuv ~= "player" or expirationTimeRegrow < expirationTimeRejuv ) then -- Shadow Flame
		spell = MrD.Info["Regrowth"]
		mult = spell.multadd
		rank = tonumber(string.sub(rankRegrow, 6))
	else
		return 0
	end
	local heal = ( (spell.add[rank] + (GetSpellBonusHealing() + plusspellpower) * spell.coeffadd) * mult ) * spell.ticks
	return heal
end

----
-- Dynamic Entries
----
function MrD_Druid_Dynamic()
	local info = MrD.Info; local ub = UnitBuff; local ud = UnitDebuff
	local allheal = 0; local alldmg = 0; allspell = 0; alldot = 0
	-- Curse of Elements/Ebon Plauge/Earth and Moon (Debuff) --
	if ud("target", "Curse of the Elements") or ud("target", "Ebon Plague") or ud("player", "Earth and Moon") then
		allspell = allspell + .13
	end
	-- Owlkin Frenzy --
	if UnitBuff("player", "Owlkin Frenzy") then
		alldmg = alldmg + .1
	end
	-- Tree of Life --
	if UnitBuff("target", "Tree of Life") then
		allheal = allheal + .06
	end
	-- Master Shapeshifter
	if T["Master Shapeshifter"] > 0 then
		for i = 1, GetNumShapeshiftForms() do
			name, _, active = GetShapeshiftFormInfo(i)
			if name == "Tree of Life Form" and active then
				allheal = allheal + T["Master Shapeshifter"] * .02
			end
		end
	end
	-- Extra bleed dmg
	if UnitDebuff("target", "Mangle") or UnitDebuff("target", "Trauma") then 
		alldot = alldot + .3
	end
	-- Rend and Tear --
	if UnitDebuff("target", "Rake") or UnitDebuff("target", "Rip") or UnitDebuff("target", "Lacerate") or UnitDebuff("target", "Pounce") then
		info.Shred.mult = info.Shred.mult + T["Rend and Tear"] * .04
		info.Mault.mult = info.Maul.mult + T["Rend and Tear"] * .04
	end
	-- Regrowth Glyph -- 
	if MrDamage.Glyphs[40912] == true and select(8, UnitBuff("target", "Regrowth")) == "player" then
		info.Regrowth.mult = info.Regrowth.mult + .2
	end
	-- Rejuvenation Glyph --
	if MrDamage.Glyphs[40913] == true and UnitHealth("target") / UnitHealthMax("target") <= .5 then
		info.Rejuvenation.mult = info.Rejuvenation.mult + .5
	end
	-- Nourish --
	if select(8, ub("target", "Regrowth")) == "player" or select(8, ub("target", "Rejuvenation")) == "player" or select(8, ub("target", "Wild Growth")) == "player" or select(8, ub("target", "Lifebloom")) == "player" then
		info.Nourish.mult = info.Nourish.mult + .2
	end
	-- Add in our "all" variables
	for k,v in pairs(info) do
		if v.melee then v.mult = v.mult + alldmg
		elseif v.school then v.mult = v.mult + allspell + alldmg
		else v.mult = v.mult + allheal end
		
		if v.dot or k == "Shred" then v.mult = v.mult + alldot end
	end
end

----
-- Table Creation w/ Static Entries
---
function MrD_Druid_Static()

	MrD.Info = {
		["Attack"] = {
			melee= true,
			armor= true,
			mult= 1,
		},
		["Healing Touch"] = {
			type= "direct",
			range= true,
			["low"] = { "37", "88", "195", "363", "490", "636", "802", "1199", "1299", "1620", "1944", "2026", "2321", "3223", "3750"	},
			["high"] = { "51", "112", "243", "445", "594", "766", "960", "1427", "1539", "1912", "2294", "2392", "2739", "3805", "4428" },
			coeff= 1.61 + T["Empowered Touch"] * .2,
			mult= 1 + T["Gift of Nature"] * .02,
		},
		["Lifebloom"] = {
			type= "hybrid",
			ticks = 7 + T["Nature's Splendor"]*2,
			int= 1,
			["avg"] = { "600", "770", "970" },
			["add"] = { "224"/7, "287"/7, "371"/7 },
			coeff= .6453 * (1 + T["Empowered Rejuvenation"] * .04),
			coeffadd= .09518 * (1 + T["Empowered Rejuvenation"] * .04),
			mult= 1 + T["Gift of Nature"] * .02,
			multadd= 1 + T["Genesis"] * .01 + T["Gift of Nature"] * .02,
		},
		["Rejuvenation"] = {
			type= "ot",
			ticks = 5 + T["Nature's Splendor"],
			int= 1,
			["avg"] = { "32"/5, "56"/5, "116"/5, "180"/5, "244"/5, "304"/5, "388"/5, "488"/5, "608"/5, "756"/5, "888"/5, "932"/5, "1060"/5, "1192"/5, "1690"/5 },
			coeff= .37604 * (1 + T["Empowered Rejuvenation"] * .04),
			mult= 1 + T["Improved Rejuvenation"] * .04 + T["Genesis"] * .01 + T["Gift of Nature"] * .02,
		},
		["Regrowth"] = {
			type= "hybrid",
			range= true,
			ticks = 7 + T["Nature's Splendor"]*2,
			int= 3,
			["low"] = { "84", "164", "240", "318", "405", "511", "646", "809", "1003", "1215", "1710", "2234" },
			["high"] = { "98", "188", "274", "360", "457", "575", "724", "905", "1119", "1355", "1908", "2494" },
			["add"] = { "98"/7, "175"/7, "259"/7, "343"/7, "427"/7, "546"/7, "686"/7, "861"/7, "1064"/7, "1274"/7, "1792"/7, "2345"/7 },
			coeff= .5390 * (1 + T["Empowered Rejuvenation"] * .04),
			coeffadd= .1880 * (1 + T["Empowered Rejuvenation"] * .04),
			mult= 1 + T["Gift of Nature"] * .02,
			multadd= 1 + T["Gift of Nature"] * .02 + T["Genesis"] * .01,
		},
		["Nourish"] = {
			type= "direct",
			range= true,
			["low"] = { "1883" },
			["high"] = { "2187" },
			coeff= .67305,
			mult= 1 + T["Gift of Nature"] * .02,
		},
		["Wild Growth"] = {
			type= "ot",
			ticks= 7,
			int= 1,
			["avg"] = { "686", "861", "1239", "1442" },
			coeff= .11505,
			mult= 1 + T["Gift of Nature"] * .02 + T["Genesis"] * .01,
		},
		["Tranquility"] = {
			type= "channel",
			ticks = 4,
			int= 2,
			["avg"] = { "351", "515", "765", "1097", "1518", "2598", "3035" },
			coeff= .5380,
			mult= 1 + T["Gift of Nature"] * .02  + T["Genesis"] * .01,
		},
		["Typhoon"] = {
			type= "direct",
			school= 4,
			["avg"] = { "400", "550", "735", "1010", "1190" },
			coeff= .193,
			mult= 1 + T["Gale Winds"] * .15 + T["Earth and Moon"] * .01,
		},
		["Moonfire"] = {
			type= "hybrid",
			ticks = 4 + T["Nature's Splendor"],
			int= 3,
			school= 7,
			range= true,
			["low"] = { "7", "13", "25", "40", "61", "81", "105", "130", "157", "189", "220", "305", "347", "406" },
			["high"] = { "9", "17", "31", "48", "73", "97", "125", "154", "185", "221", "258", "357", "407", "476" },
			["add"] = { "12"/4, "32"/4, "52"/4, "80"/4, "124"/4, "164"/4, "212"/4, "264"/4, "320"/4, "384"/4, "444"/4, "600"/4, "684"/4, "800"/4 },
			coeff= .1515,
			coeffadd= .13,
			mult= 1 + T["Improved Moonfire"] * .04 + T["Moonfury"] * .03 + T["Earth and Moon"] * .01,
			multadd= 1 + T["Improved Moonfire"] * .04 + T["Moonfury"] * .03 + T["Genesis"] * .01 + T["Earth and Moon"] * .01,
		},
		["Starfire"] = {
			type= "direct",
			school= 7,
			range= true,
			["low"] = { "121", "189", "272", "370", "484", "615", "693", "818", "854", "1028" },
			["high"] = { "149", "231", "328", "442", "575", "725", "817", "964", "1006", "1212" },
			coeff= 1 * (1 + T["Wrath of Cenarius"] * .04),
			mult= 1 + T["Moonfury"] * .03 + T["Earth and Moon"] * .01,
		},
		["Starfall"] = {
			type= "ot",
			ticks= 20,
			int= 1,
			school= 7,
			range= true,
			["low"] = { "111", "250", "366", "433" },
			["high"] = { "129", "290", "424", "503" },
			coeff= .0458,
			mult= 1+ T["Genesis"] * .01 + T["Earth and Moon"] * .01,
		},
		["Insect Swarm"] = {
			type= "ot",
			ticks= 6 + T["Nature's Splendor"] * 2,
			int= 2,
			school= 4,
			["avg"] = { "114"/6, "234"/6, "372"/6, "540"/6, "744"/6, "1032"/6, "1290"/6 },
			coeff= .2,
			mult= 1+ T["Genesis"] * .01 + T["Earth and Moon"] * .01,
		},
		["Entangling Roots"] = {
			type= "ot",
			school= 4,
			ticks= 9,
			int= 3,
			["avg"] = { "20"/9, "50"/9, "90"/9, "140"/9, "200"/9, "270"/9, "351"/9, "423"/9 },
			coeff= .1,
			mult= 1+ T["Genesis"] * .01+ T["Brambles"] *.25 + T["Earth and Moon"] * .01,
		},
		["Wrath"] = {
			type= "direct",
			range= true,
			school= 4,
			["low"] = { "17", "32", "49", "68", "130", "169", "215", "306", "397", "431", "504", "553" },
			["high"] = { "19", "36", "57", "78", "148", "191", "241", "344", "447", "485", "568", "623" },
			coeff= .5714 * (1 + T["Wrath of Cenarius"] * .04),
			mult= 1 + T["Moonfury"] * .03 + T["Earth and Moon"] * .01,
		},
		["Hurricane"] = {
			type= "channel",
			school= 4,
			ticks= 10,
			int= 1,
			["avg"] = { "100", "142", "190", "303", "451" },
			coeff= .12898,
			mult= 1+ T["Genesis"] * .01 + T["Gale Winds"] * .15 + T["Earth and Moon"] * .01,
		},
		["Mangle (Cat)"] = {
			melee= true,
			armor= true,
			type= "weap",
			["avg"] = { "198", "256", "330", "536", "634" },
			perc= 2,
			mult= 1 + T["Savage Fury"] * .1,
		},
		["Mangle (Bear)"] = {
			melee= true,
			armor= true,
			type= "weap",
			["avg"] = { "86.25", "120.75", "155.25", "251.85", "299" },
			perc= 1.15,
			mult= 1 + T["Savage Fury"] * .1,
		},
		["Rake"] = {
			melee= true,
			type= "hybrid",
			ap= true,
			ticks= 3,
			int= 3,
			perc= .18,
			["avg"] = { "17", "26", "46", "64", "90", "150", "190" },
			["add"] = { "90", "135", "207", "297", "414", "963", "1161" },
			mult= 1 + T["Savage Fury"] * .1,
		},
		["Shred"] = {
			melee= true,
			armor= true,
			type= "weap",
			["avg"] = { "54", "72", "99", "144", "180", "236", "405", "630", "742.5" },
			perc= 2.25,
			mult= 1,
		},
		["Claw"] = {
			melee= true,
			armor= true,
			type= "weap",
			["avg"] = { "27", "39", "57", "88", "115", "190", "300", "370" },
			perc= 1,
			mult= 1 + T["Savage Fury"] * .1,
		},
		["Lacerate"] = {
			melee= true,
			type= "ap",
			dot= true,
			perc= .05,
			ticks= 5,
			int= 3,
			["avg"] = { "31", "70", "88" },
			["add"] = { "155", "255", "320" },
			mult= 1,
		},
		["Rip"] = {
			melee= true,
			type= "ap",
			dot= true,
			perc = { ".01", ".02", ".03", ".04", ".05" },
			["combo"] = {
				[1] = { "7", "11", "15", "23", "32", "45", "71", "104", "138" },
				[2] = { "11", "18", "24", "37", "52", "73", "118", "176", "237" },
				[3] = { "15", "25", "33", "51", "72", "101", "165", "248", "336" },
				[4] = { "19", "32", "42", "65", "92", "129", "212", "320", "435" },
				[5] = { "23", "39", "51", "79", "112", "157", "259", "392", "534" },
			},
			mult= 1,
		},
		["Swipe (Bear)"] = {
			melee= true,
			armor= true,
			type= "ap",
			perc= .07,
			["avg"] = { "9", "13", "19", "37", "54", "76", "95", "108" },
			mult= 1+ T["Feral Instinct"] *.1,
		},
		["Swipe (Cat)"] = {
			melee= true,
			armor= true,
			type= "weap",
			perc= 2.6,
			mult= 1+ T["Feral Instinct"] *.1,
		},
		["Pounce"] = {
			melee= true,
			type= "ap",
			dot= true,
			ticks= 6,
			int= 3,
			perc= 0,
			["avg"] = { "270", "330", "450", "600", "2100" },
			mult= 1,
		},
		["Ravage"] = {
			melee= true,
			armor= true,
			type= "weap",
			perc= 3.85,
			["avg"] = { "161.7", "238.7", "300.3", "377.3", "565.95", "1405.25", "1771" },
			mult= 1,
		},
		["Maim"] = {
			melee= true,
			armor= true,
			type= "weap",
			perc= 1,
			["combo"] = {
				[1] = { "129", "224" },
				[2] = { "213", "382" },
				[3] = { "297", "540" },
				[4] = { "381", "698" },
				[5] = { "465", "856" },
			},
			mult= 1,
		},
		["Maul"] = {
			melee= true,
			armor= true,
			type= "weap",
			perc= 1,
			["avg"] = { "18", "27", "37", "64", "103", "145", "192", "290", "472", "578" },
			mult= 1 + T["Savage Fury"] * .1,
		},--[[
		["Faerie Fire |(Feral|)") = {
			melee= true,
			type= "ap",
			perc= .15,
			add= 1,
			mult= 1,
		},--]]
		["Ferocious Bite"] = {
			melee= true,
			armor= true,
			type= "special",
			perc= { ".07", ".14", ".21", ".28", ".35" },
			range= true,
			["combol"] = {
				[1] = { "50", "79", "122", "173", "199", "226", "334", "410" },
				[2] = { "86", "138", "214", "301", "346", "395", "570", "700" },
				[3] = { "122", "197", "306", "429", "493", "564", "506", "990" },
				[4] = { "158", "256", "398", "557", "640", "733", "1042", "1280" },
				[5] = { "194", "315", "490", "685", "787", "902", "1278", "1570" },
			},
			["comboh"] = {
				[1] = { "66", "103", "162", "223", "259", "292", "446", "550" },
				[2] = { "66", "103", "162", "223", "259", "292", "446", "550" },
				[3] = { "66", "103", "162", "223", "259", "292", "446", "550" },
				[4] = { "66", "103", "162", "223", "259", "292", "446", "550" },
				[5] = { "66", "103", "162", "223", "259", "292", "446", "550" },
			},
			["add"] = { ".7", "1.1", "1.5", "2", "2.1", "3.4", "7.7", "9.4" },
			mult= 1,
		},
		["Swiftmend"] = {
			type= "special",
			mult= 1,
		},
	}
	-- Glyphs --
	local info = MrD.Info;
	if MrDamage.Glyphs[54829] then info.Moonfire.mult = info.Moonfire.mult * .15; info.Moonfire.multadd = info.Moonfire.multadd + .7 end
	if MrDamage.Glyphs[54830] then info["Insect Swarm"]["mult"] = info["Insect Swarm"]["mult"] + .3 end
	if MrDamage.Glyphs[54826] then info.Lifebloom.ticks = info.Lifebloom.ticks + 1 end
	if MrDamage.Glyphs[40902] then info.Rip.ticks = 8 else info.Rip.ticks = 6 end

end
