
----
-- Functions for Death Knight Calculations
----
-- Spell Damage
function MrDamage_DeathKnight_SpellDamage(dmg)
	if UnitDebuff("target", "Blood Plague") == "Blood Plague" then
		dmg = dmg * (1 + T["Rage of Rivendare"]/50)
	end
	if UnitDebuff("target", "Frost Fever") == "Frost Fever" then
		dmg = dmg * (1 + T["Tundra Stalker"]/33.3333)
	end
	if UnitBuff("player", "Blood Presence") == "Blood Presence" then 
		dmg = dmg * 1.15
	end
	if UnitHealth("player") / UnitHealthMax("player") > .75 then
		dmg = dmg * (1 + T["Blood Gorged"]/50)
	end
	dmg = dmg * (1 + (T["Black Ice"] / 50) )
	if UnitBuff("player", "Desecration") then
		dmg = dmg * (1 + T["Desecration"]/100)
	end
	if UnitDebuff("target", "Ebon Plague") or UnitDebuff("target", "Curse of the Elements") then
		dmg = dmg * 1.13
	end
	return dmg
end
-- AP
function AttackPower()
	local base, posBuff, negBuff = UnitAttackPower("player");
	return base + posBuff + negBuff;
end
-- Sigil
function Sigil()
	local itemLink = GetInventoryItemLink("player", 18)
	if itemLink then
		return GetItemInfo(itemLink)
	else
		return ""
	end
end
-- Frost Talents
function MrDamage_DeathKnight_FrostTalents(currentDamage)
	if currentDamage then
		local diseased = false
		for i=1,40 do 
			local debuffname = UnitDebuff("target", i)
			if debuffname == "Blood Plague" or debuffname == "Frost Fever" or debuffname == "Devouring Plague" then
				diseased = true
				do break end
			end
		end
		if diseased == true then currentDamage = currentDamage * (1 + (T["Glacier Rot"] / 15) ) end
		if ( (UnitHealth("target") / UnitHealthMax("target")  <= .35 ) ) then
			currentDamage = currentDamage * (1 + (T["Merciless Combat"] / 16.67) )
		end
		return currentDamage
	end
end
-- Weapon Damage
function MrDamage_DeathKnight_WeaponDamage(perc, add, range)
	if add and perc and range then
		local lowend, highend = UnitDamage("player")
		lowend = lowend * perc + add
		highend = highend * perc + add
		local averageend = lowend + ( (highend - lowend)/2 )
	
		if range == "high" then
			totalDamage = highend
		elseif range == "low" then
			totalDamage = lowend
		elseif range == "average" then
			totalDamage = averageend
		end
	end
	return totalDamage
end
-- Armor
function MrDamage_DeathKnight_PhysicalDamage(amount)
	if MrDSettings["armor"] == false then return amount end
	local playerlevel = UnitLevel("player")
	local targetlevel = UnitLevel("target")
	if targetlevel == -1 then 
		baseReduction = .5649 
	else
		baseReduction = .42 + (targetlevel - playerlevel) * .007 -- This is the formula that I cam up with through testing for average armor pen.
	end
	local name, _,_, count = UnitDebuff("target", "Sunder Armor")
	if UnitDebuff("target", "Expose Armor") == "Expose Armor" then
		baseReduction = baseReduction * .8	-- Expose Armor
	elseif name == "Sunder Armor" and count then
		baseReduction = baseReduction * (1 - .04 *count) -- Sunder Armor
	elseif UnitDebuff("target", "Acid Spit") == "Acid Spit" then
		baseReduction = baseReduction * .9	-- Acid Spit
	end
	if UnitDebuff("target", "Faerie Fire") == "Faerie Fire" or UnitDebuff("target", "Faerie Fire (Feral)") == "Faerie Fire (Feral)" or UnitDebuff("target", "Sting") == "Sting" or UnitDebuff("target", "Curse of Recklessness") == "Curse of Recklessness" then
		baseReduction = baseReduction * .95	-- Faerie Fire, Sting, CoR
	end
	baseReduction = baseReduction * (1 - T["Blood Gorged"]/50) -- Blood Gorged Talent
	baseReduction = baseReduction * (1 - (GetCombatRating(25) / 12.31) / 100) -- Armor Pen Gear
	if baseReduction > 0 then
		amount = amount * (1 - baseReduction)
	end
	return amount
end
-- Number of Diseases
function Diseases()
	local frost = UnitDebuff("target", "Frost Fever");
	local blood = UnitDebuff("target", "Blood Plague");
	local crypt = UnitDebuff("target", "Crypt Fever");
	local ebon = UnitDebuff("target", "Ebon Plague");
	local num = 0
	if not (frost==nil) then
		num = num + 1
	end
	if not (blood==nil) then
		num = num + 1
	end
	if not (crypt==nil) or not (ebon==nil) then
		num = num + 1
	end
	return num
end
-- % multipliers on damage
function MrDamage_DeathKnight_DamageMultiplier(dmg)
	if UnitDebuff("target", "Blood Plague") == "Blood Plague" then
		dmg = dmg * (1 + T["Rage of Rivendare"]/50)
	end
	if UnitDebuff("target", "Frost Fever") == "Frost Fever" then
		dmg = dmg * (1 + T["Tundra Stalker"]/33.3333)
	end
	return dmg
end

----				----
-- Spell Calculations --
----				----
-- Attack --
function MrDamage_Rogue_Attack(rank, plusspellpower)
	lowEnd, highEnd = UnitDamage("player")
	lowEnd = Armor( lowEnd )
	highEnd = Armor( highEnd )
	return (lowEnd + highEnd)/2, lowEnd, highEnd
end
-- Icy Touch
function MrDamage_DeathKnight_IcyTouch(rank, plusattackpower)
	spellDamage = (AttackPower() + plusattackpower) * (.1 * (1 + T["Impurity"]/25))
	lowDamage = MrDamage_DeathKnight_SpellDamage( MrDamage_DeathKnight_FrostTalents( (Rank.Low["Icy Touch"][rank] + spellDamage) * (1 + T["Improved Icy Touch"]/20)) )
	highDamage = MrDamage_DeathKnight_SpellDamage( MrDamage_DeathKnight_FrostTalents( (Rank.High["Icy Touch"][rank] + spellDamage) * (1 + T["Improved Icy Touch"]/20)) )
	if Sigil() == "Sigil of the Frozen Conscience" then 
		lowDamage = lowDamage + 111
		highDamage = highDamage + 111
	end
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
-- Death Coil
function MrDamage_DeathKnight_DeathCoil(rank, plusattackpower)
	spellDamage = (AttackPower() + plusattackpower) * (.15 * (1 + T["Impurity"]/25))
	totalDamage = MrDamage_DeathKnight_SpellDamage( (Rank.Average["Death Coil"][rank] + spellDamage) * (1 + T["Morbidity"] / 20) )
	if MrDamage.Glyphs[63333] == true then totalDamage = totalDamage * 1.15 end -- Glyph
	if Sigil() == "Sigil of the Vengeful Heart" then 
		return totalDamage + 380
	elseif Sigil() == "Sigil of the Wild Buck" then
		return totalDamage + 80
	else
		return totalDamage
	end
end
-- Howling Blast
function MrDamage_DeathKnight_HowlingBlast(rank, plusattackpower)
	spellDamage = (AttackPower() + plusattackpower) * (.2 * (1 + T["Impurity"]/25))
	lowDamage = MrDamage_DeathKnight_SpellDamage( MrDamage_DeathKnight_FrostTalents( (Rank.Low["Howling Blast"][rank] + spellDamage) ) )
	highDamage = MrDamage_DeathKnight_SpellDamage( MrDamage_DeathKnight_FrostTalents( (Rank.High["Howling Blast"][rank] + spellDamage) ) )
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
-- Unholy Blight
function MrDamage_DeathKnight_UnholyBlight(rank, plusattackpower)
	if MrDamage.Glyphs[63332] == true then ticks = 30 else ticks = 20 end
	spellDamage = (AttackPower() + plusattackpower) * (.013 * (1 + T["Impurity"]/25))
	pertick = MrDamage_DeathKnight_SpellDamage( Rank.Average["Unholy Blight"][rank] + spellDamage )
	return pertick*ticks, nil, nil, nil, pertick, ticks, 1		
end
-- Summon Gargoyle
function MrDamage_DeathKnight_SummonGargoyle(rank, plusattackpower)
	spellDamage = (AttackPower() + plusattackpower) * .4
	pertick = 150 + spellDamage
	return pertick * 15, nil, nil, nil, pertick, 15, 2
end
-- Corpse Explosion
function MrDamage_DeathKnight_CorpseExplosion(rank, plusattackpower)
	spellDamage = (AttackPower() + plusattackpower) * (.105 * (1 + T["Impurity"]/25)) 
	totalDamage = MrDamage_DeathKnight_SpellDamage( Rank.Average["Corpse Explosion"][rank] + spellDamage )
	return totalDamage
end
-- Death and Decay
function MrDamage_DeathKnight_DeathandDecay(rank, plusattackpower)
	spellDamage = (AttackPower() + plusattackpower) * (.0475 * (1 + T["Impurity"]/25))
	pertick = MrDamage_DeathKnight_SpellDamage( (Rank.Average["Death and Decay"][rank] + spellDamage) * (1 + T["Morbidity"]/20) )
	if MrDamage.Glyphs[58629] == true then pertick = pertick * 1.20 end
	return pertick*10, nil, nil, nil, pertick, 10, 1
end
-- Blood Boil
function MrDamage_DeathKnight_BloodBoil(rank, plusattackpower)
	spellDamage = (AttackPower() + plusattackpower) * (.0475 * (1 + T["Impurity"]/25))
	if Diseases() > 0 then coeff = .095 else coeff = .06 end
	spellDamage = (AttackPower() + plusattackpower) * (coeff * (1 + T["Impurity"]/25))
	lowDamage = MrDamage_DeathKnight_SpellDamage( (Rank.Low["Blood Boil"][rank] + spellDamage) * (1 + T["Bloody Strikes"]/10) )
	highDamage = MrDamage_DeathKnight_SpellDamage( (Rank.High["Blood Boil"][rank] + spellDamage) * (1 + T["Bloody Strikes"]/10) )
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
----				   ----
-- Physical Calculations --
----				   ----
-- Attack
function MrDamage_DeathKnight_Attack(rank)
	lowDamage, highDamage = UnitDamage("player")
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
-- Plague Strike
function MrDamage_DeathKnight_PlagueStrike(rank)
	lowDamage, highDamage = UnitDamage("player")
	lowDamage = MrDamage_DeathKnight_PhysicalDamage( (lowDamage * .5 + Rank.Average["Plague Strike"][rank]) * (1 + T["Outbreak"]/10) )
	highDamage = MrDamage_DeathKnight_PhysicalDamage( (highDamage * .5 + Rank.Average["Plague Strike"][rank]) * (1 + T["Outbreak"]/10) )
	if MrDamage.Glyphs[58657] == true then 
		lowDamage = lowDamage * 1.20 
		highDamage = highDamage * 1.20 
	end
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
-- Blood Strike
function MrDamage_DeathKnight_BloodStrike(rank)
	lowDamage, highDamage = UnitDamage("player")
	lowDamage = MrDamage_DeathKnight_PhysicalDamage( (lowDamage * .4 + Rank.Average["Blood Strike"][rank]) * (1 + T["Bloody Strikes"]/6.666667 + .125*Diseases()) )
	highDamage = MrDamage_DeathKnight_PhysicalDamage( (highDamage * .4 + Rank.Average["Blood Strike"][rank]) * (1 + T["Bloody Strikes"]/6.666667 + .125*Diseases()) )
	if Sigil() == "Sigil of the Dark Rider" then 
		lowDamage = lowDamage + 90
		highDamage = highDamage + 90
	end
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
-- Obliterate
function MrDamage_DeathKnight_Obliterate(rank)
	if Sigil() == "Sigil of Awareness" then 
		base = Rank.Average["Obliterate"][rank] + 336
	else
		base = Rank.Average["Obliterate"][rank]
	end
	lowDamage, highDamage = UnitDamage("player")
	lowDamage = MrDamage_DeathKnight_PhysicalDamage( (lowDamage * .8 + base) )
	highDamage = MrDamage_DeathKnight_PhysicalDamage( (highDamage * .8 + base) )
	if MrDamage.Glyphs[58671] then 
		lowDamage = lowDamage * 1.20
		highDamage = highDamage * 1.20
	end
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
-- Death Strike
function MrDamage_DeathKnight_DeathStrike(rank)
	if MrDamage.Glyphs["Sigil of Awareness"] then 
		base = Rank.Average["Death Strike"][rank] + 315
	else
		base = Rank.Average["Death Strike"][rank]
	end
	lowDamage, highDamage = UnitDamage("player")
	lowDamage = MrDamage_DeathKnight_PhysicalDamage( (lowDamage * .75 + base) * (1 + T["Improved Death Strike"]/6.666666667) )
	highDamage = MrDamage_DeathKnight_PhysicalDamage( (highDamage * .75 + base) * (1 + T["Improved Death Strike"]/6.666666667) )
	if MrDamage.Glyphs[59336] == true then 
		local damageincrease = 1 + UnitPower("player")/100
		if damageincrease > 1.25 then damageincrease = 1.25 end
		lowDamage = lowDamage * damageincrease
		highDamage = highDamage * damageincrease
	end
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
-- Heart Strike
function MrDamage_DeathKnight_HeartStrike(rank)
	lowDamage, highDamage = UnitDamage("player");
	lowDamage = MrDamage_DeathKnight_PhysicalDamage( (lowDamage * .5 + Rank.Average["Heart Strike"][rank]) * (1 + T["Bloody Strikes"]/6.666667 + .125*Diseases()) )
	highDamage = MrDamage_DeathKnight_PhysicalDamage( (highDamage * .5 + Rank.Average["Heart Strike"][rank]) * (1 + T["Bloody Strikes"]/6.666667 + .125*Diseases()) )
	if Sigil() == "Sigil of the Dark Rider" then 
		lowDamage = lowDamage + 90
		highDamage = highDamage + 90
	end
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
-- Frost Strike
function MrDamage_DeathKnight_FrostStrike(rank)
	lowDamage, highDamage = UnitDamage("player")
	lowDamage = MrDamage_DeathKnight_PhysicalDamage( MrDamage_DeathKnight_FrostTalents( (lowDamage * .6 + Rank.Average["Frost Strike"][rank]) * (1 + T["Black Ice"]/50) ) )
	highDamage = MrDamage_DeathKnight_PhysicalDamage( MrDamage_DeathKnight_FrostTalents( (lowDamage * .6 + Rank.Average["Frost Strike"][rank]) * (1 + T["Black Ice"]/50) ) )
	if Sigil() == "Sigil of the Vengeful Heart" then 
		lowDamage = lowDamage + 380
		highDamage = highDamage + 380
	end
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
-- Scourge Strike
function MrDamage_DeathKnight_ScourgeStrike(rank)
	if Sigil() == "Sigil of Awareness" then
		base = Rank.Average["Scourge Strike"][rank] + 189
	else
		base = Rank.Average["Scourge Strike"][rank]
	end
	lowDamage, highDamage = UnitDamage("player")
	lowDamage = MrDamage_DeathKnight_PhysicalDamage( (lowDamage * .6 + base) * (1 + T["Black Ice"]/50 + T["Outbreak"]/20 + .11 * Diseases()) ) 
	highDamage = MrDamage_DeathKnight_PhysicalDamage( (lowDamage * .6 + base) * (1 + T["Black Ice"]/50 + T["Outbreak"]/20 + .11 * Diseases()) )
	if Sigil() == "Sigil of Arthritic Binding" then 
		lowDamage = lowDamage + 91.35
		highDamage = highDamage + 91.35
	end
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end

function MrDamage_DeathKnight_RuneStrike()
	lowDamage, highDamage = UnitDamage("player")
	lowDamage = MrDamage_DeathKnight_PhysicalDamage( lowDamage + (150 * AttackPower() * .001) )
	highDamage = MrDamage_DeathKnight_PhysicalDamage( highDamage + (150 * AttackPower() * .001) )
	return (lowDamage + highDamage)/2, lowDamage, highDamage
end
--[[
-- Updates Tooltip Arrays
function DeathKnight:UpdateStatInfo()
	
	-- Melee Hit
	local weaplink = GetInventoryItemLink("player", 16)
	if weaplink then
		local weaptype = select(7, GetItemInfo(GetInventoryItemLink("player", 16))) -- Get our Weapon Type
	else
		weaptype = ""
	end
	for skillIndex = 1, GetNumSkillLines() do 
		local skillname, _, _, skillrank = GetSkillLineInfo(skillIndex)
		if skillname == weaptype then -- Scan our skill until we get a match
			currentweapskill = skillrank
		end
	end
	if not currentweapskill then currentweapskill = UnitLevel("player") * 5 end
	local moblevel = UnitLevel("target")
	if moblevel == 0 then moblevel = UnitLevel("player")
	elseif moblevel == -1 then moblevel = UnitLevel("player") + 3 end
	
	local weapontodef = (moblevel * 5) - currentweapskill -- Compare our weapon skill with the mobs defense
	if weapontodef > 10 then
		basechancetomiss = 6 + ((moblevel * 5) - currentweapskill - 10) * .4
	elseif weapontodef <= 0 then
		basechancetomiss = 5
	else
		basechancetomiss = 5 + ((moblevel * 5) - currentweapskill)*.1
	end
	hitchance = GetCombatRating(6) / 32.8
	if UnitBuff("player", "Heroic Presence") == "Heroic Presence" then hitchance = hitchance + 1 end
	hitchance = basechancetomiss - hitchance
	if hitchance <= 0 then
		meleeonetohit = 0
	elseif hitchance > 1 then
		meleeonetohit = .01
	else
		meleeonetohit = hitchance/100
	end
	
	-- Spell Hit
	local moblevel = UnitLevel("target") -- Mob level
	if moblevel == 0 then moblevel = UnitLevel("player") -- If we dont have a target, we'll say an equal level mob
	elseif moblevel == -1 then moblevel = UnitLevel("player") + 3 end -- Skulls will be assumed to be 3 levels above
	
	if moblevel - UnitLevel("player") <=2 then
		basechancetomiss = moblevel - UnitLevel("player") + 4
	else
		basechancetomiss = 17
	end
	
	local spellmisschance = basechancetomiss - GetCombatRating(8)/26.25
	if UnitBuff("player", "Heroic Presence") == "Heroic Presence" then spellmisschance = spellmisschance - 1 end
	if UnitDebuff("target", "Misery") == "Misery" then spellmisschance = spellmisschance - 3 end
	spellmisschance = spellmisschance - T["Morbidity"]
	if spellmisschance <= 0 then
		spellonetohit = 0	-- Hit Capped
	elseif spellmisschance > 1 then
		spellonetohit = .01 -- Outside of 1% from hit capped
	else
		spellonetohit = spellmisschance/100 -- At or above 1% from hit capped
	end
	
	-- Expertise
	local expertchanceadd = GetExpertise() * .25
	local moblevel = UnitLevel("target") -- Mob level
	if moblevel == -1 then
		onetoexp = 6.25 - expertchanceadd 
	else
		onetoexp = 5 - expertchanceadd 
	end
	if onetoexp <= 0 then
		onetoexp = 0
	elseif onetoexp > 1 then
		onetoexp = .01
	else
		onetoexp = onetoexp/100
	end
	meleechancetohit = (100 - hitchance)/100
	spellchancetohit = (100 - spellmisschance)/100
	
end
--]]
function MrDamage_DeathKnight_UpdateCoefficients()
	C["Icy Touch"] = sf("%.2f", 10 * (1 + T["Impurity"]/25)).."%"
	C["Death Coil"] = sf("%.2f", 15 * (1 + T["Impurity"]/25)).."%"
	if Diseases() > 0 then coeff = 9.5 else coeff = 6 end
	C["Blood Boil"] = sf("%.2f", coeff * (1 + T["Impurity"]/25)).."%"
	C["Howling Blast"] = sf("%.2f", 20 * (1 + T["Impurity"]/25)).."%"
	C["Corpse Explosion"] = sf("%.2f", 10.5 * (1 + T["Impurity"]/25)).."%"
	C["Unholy Blight"] = sf("%.2f", 1.3 * (1 + T["Impurity"]/25)).."%"
	C["Death and Decay"] = sf("%.2f", 4.75 * (1 + T["Impurity"]/25)).."%"
	C["Summon Gargoyle"] = sf("%.2f", 40 * (1 + T["Impurity"]/25)).."%"
end
