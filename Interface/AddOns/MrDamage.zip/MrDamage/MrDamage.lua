
-- r811 
-- fixed a few issues with priest channeling spells
-- fixed issue with PW:S

MrD_Class = UnitClass("player")
if MrD_Class == "Death Knight" then MrD_Class = "DeathKnight" end

----
-- Addon Initilization Function
----
-- On Event
function MrDamage_OnEvent(self, event, ...)
	if event == "PLAYER_ENTERING_WORLD" then MrDamage_LoadAddon() end
	if event == "CHARACTER_POINTS_CHANGED" then MrDamage_UpdateTalents(); MrDamage_UpdateRankData() end
	if event == "ACTIONBAR_PAGE_CHANGED" or event == "ACTIONBAR_SLOT_CHANGED" then MrDamage.ThrottleTime = .26 end -- Makes it smoother when switching pages or changing actions
	if event == "GLYPH_ADDED" or event == "GLYPH_REMOVED" or event == "GLYPH_UPDATED" then MrDamage_UpdateGlyphs(); MrDamage_UpdateRankData() end
end
-- On Update (With Talents)
function MrDamage_OnUpdate(self, elapsed)
	MrDamage.ThrottleTime = MrDamage.ThrottleTime + elapsed
	if MrDamage.ThrottleTime > .25 then
		MrDamage.ThrottleTime = 0
		if GetActiveTalentGroup() ~= MrDamage.ActiveTalentGroup then
			MrDamage.ActiveTalentGroup = GetActiveTalentGroup()
			MrDamage_UpdateTalents()
			MrDamage_UpdateGlyphs()
			MrDamage_UpdateRankData()
		end
		MrDamage_UpdateDamageText()
	end
end
-- On Update (Without Talents)
function MrDamage_AwaitingTalents(self, elapsed)
	if MrDamage.TalentsAvailable == true then
		MrDamageFrame:SetScript("OnUpdate", MrDamage_OnUpdate)
	elseif GetNumTalents(1) then
		MrDamage.TalentsAvailable = true
		MrDamage_UpdateTalents()
		MrDamage_UpdateGlyphs()
		MrDamage_UpdateRankData()
		MrDamage.ActiveTalentGroup = GetActiveTalentGroup()
		DEFAULT_CHAT_FRAME:AddMessage(MrDamage["Version"].." |cFFFFFFFF Loaded! '/mrd' for Options", .4,0,.6)
	else
		MrDamageFrame:SetScript("OnUpdate", function(self) end)
	end
end
-- Load Main Addon
function MrDamage_LoadAddon()
	-- Global Variables
	MrDamage = {
		["Version"] = "MrDamage"..GetAddOnMetadata("MrDamage", "Version"),
		["Talents"] = {},
		["Ranks"] = {},
		["RanksAdd"] = {},
		["Glyphs"] = {},
		["ThrottleTime"] = 0,
		["TalentsAvailable"] = false,
		["InfoAdded"] = false,
	}
	MrD = { Coeffs = {}, Talents = {} } -- Standard Array
	MrD.Info = {}
	T = {} -- Talents
	C = {} -- Coefficients
	M = {} -- Multiplier
	
	if not MrDSettings then
		MrDSettings = { ["on"] = true, ["x"] = 0, ["y"] = 5, ["font"] = 12, ["r"] = 1, ["g"] = .82, ["b"] = 0, ["show"] = 0, ["armor"] = true }
	end
	sf = string.format
	Damage = {}
	Damage_Low = {}
	Damage_High = {}
	Damage_Direct = {}
	Damage_PerTick = {}
	Damage_Ticks = {}
	Damage_TickInterval = {}
	
	SLASH_MRDAMAGE1 = "/mrd";
	SlashCmdList["MRDAMAGE"] = MrDamage_SlashCommand;

	MrDamageFrame:UnregisterEvent("PLAYER_ENTERING_WORLD")
	MrDamageFrame:RegisterEvent("CHARACTER_POINTS_CHANGED")
	MrDamageFrame:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
	MrDamageFrame:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
	MrDamageFrame:RegisterEvent("GLYPH_ADDED");
	MrDamageFrame:RegisterEvent("GLYPH_REMOVED");
	MrDamageFrame:RegisterEvent("GLYPH_UPDATED");
	MrDamage_CreateDisplay()
	MrDamage_CreateOptions()
	MrDamage_SetDisplay()
	if MrDSettings["on"] then
		MrDamageFrame:SetScript("OnUpdate", MrDamage_AwaitingTalents)
	end
end
-- Addon Load: Creates Frame And sets up load-up event
local f = CreateFrame("Frame", "MrDamageFrame", UIParent)
f:SetScript("OnEvent", MrDamage_OnEvent)
f:RegisterEvent("PLAYER_ENTERING_WORLD")

-- Update Talent Information
function MrDamage_UpdateTalents()
	local tabs = GetNumTalentTabs()
	for i = 1, tabs do
		local talents = GetNumTalents(i)
		for t = 1, talents do
			local name, _, _, _, points = GetTalentInfo(i,t);
			T[name] = points
		end
	end
	
	MrDamage.UpdateIn = 0
end

-- Updates Glyph Information
function MrDamage_UpdateGlyphs()

	MrDamage.Glyphs = {}
	for i = 1, 6  do
		local id = select(3, GetGlyphSocketInfo(i))
		if id then
			MrDamage.Glyphs[id] = true
		end
	end
end

function MrDamage_UpdateDamageText()
	local dyn = _G["MrD_"..MrD_Class.."_Dynamic"]
	if dyn then dyn() end;
	for i = 1, 120 do
		local s = _G["MrDString"..i]
		if s then s:SetText(MrDamage_Frame_UpdateButton(s:GetParent())) end
	end
end

-- Creates Strings on each button
function MrDamage_CreateDisplay()

	if IsAddOnLoaded("Bartender4") then
		MrDamage.TooltipOnEnter = BT4Button1:GetScript("OnEnter")
		for i = 1,120 do
			local f = _G["BT4Button"..i] 
			if f then
				local s = f:CreateFontString("MrDString"..i, "OVERLAY", "GameFontNormal")
				s:SetPoint("BOTTOM", 0, 5)
				s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
			end
		end
	elseif IsAddOnLoaded("nUI") then
		MrDamage.TooltipOnEnter = nUI_ActionBar_Button1:GetScript("OnEnter")
		for i = 1,12 do
			local f = _G["nUI_ActionBar_Button"..i] 
			local s = f:CreateFontString("MrDString"..i, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
			local f = _G["nUI_TopLeftBar_Button"..i]
			local s = f:CreateFontString("MrDString"..i+12, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
			local f = _G["nUI_RightUnitBar_Button"..i]
			local s = f:CreateFontString("MrDString"..i+24, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
			local f = _G["nUI_LeftUnitBar_Button"..i]
			local s = f:CreateFontString("MrDString"..i+36, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
			local f = _G["nUI_BottomRightBar_Button"..i]
			local s = f:CreateFontString("MrDString"..i+48, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
		end
	else
		if IsAddOnLoaded("Dominos") then
			MrDamage.TooltipOnEnter = DominosActionButton1:GetScript("OnEnter")
			for i = 1, 48 do
				local f = _G["DominosActionButton"..i]
				if f then
					local s = f:CreateFontString("MrDString"..i+72, "OVERLAY", "GameFontNormal")
					s:SetPoint("BOTTOM", 0, 5)
					s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
				end
			end
		end
		for i = 1,12 do
			-- Default Action Bars
			local f = _G["ActionButton"..i]
			local s = f:CreateFontString("MrDString"..i, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
			local f = _G["MultiBarBottomLeftButton"..i]
			local s = f:CreateFontString("MrDString"..i+12, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
			local f = _G["MultiBarBottomRightButton"..i]
			local s = f:CreateFontString("MrDString"..i+24, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
			local f = _G["MultiBarRightButton"..i]
			local s = f:CreateFontString("MrDString"..i+36, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
			local f = _G["MultiBarLeftButton"..i]
			local s = f:CreateFontString("MrDString"..i+48, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
			local f = _G["BonusActionButton"..i]
			local s = f:CreateFontString("MrDString"..i+60, "OVERLAY", "GameFontNormal")
			s:SetPoint("BOTTOM", 0, 5)
			s:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE, MONOCHROME")
		end	
	end
	
	GameTooltip:HookScript("OnUpdate", function(s,e) MrDamage_SetTooltip(GetMouseFocus()) end)
	GameTooltip:HookScript("OnHide", function(self) MrDamage.InfoAdded = false end)
end
-- AP
function AP()
	local base, posBuff, negBuff = UnitAttackPower("player");
	local effective = base + posBuff + negBuff;
	return base + posBuff + negBuff;
end
-- Spell Calculations --
function MrD_Spell_Calculate(spellname, rank, plus)

	local spell = MrD.Info[spellname] -- Assign a variable to make it easier
	if spell then
		if spell.type == "special" then
			local name = "" 
			for word in string.gmatch(spellname, "%a+") do name = name..word end
			local calc = _G["MrD_"..name]
			return calc(rank)
		elseif spell.ranged then
			local low, high = select(2, UnitRangedDamage("player"))
			return (low + high)/2, low, high
		elseif spell.melee then
			local low, high = UnitDamage("player")
			return (low + high)/2, low, high
		else
			local fromspellpower			
			if spell.school then fromspellpower = GetSpellBonusDamage(spell.school) + plus else fromspellpower = GetSpellBonusHealing() + plus end
			if spell.both then -- First do our Damage or Heal spells based on target
				if UnitIsFriend("player", "target") == nil then -- Damage calculation
					spell.heal = true
					if spell.rangedmg then -- Damage spell has a range (xx to yy)
						low = ( spell.dlow[rank] + (GetSpellBonusDamage(2) * spell.dcoeff) ) * spell.mult
						high = ( spell.dhigh[rank] + (GetSpellBonusDamage(2) * spell.dcoeff) ) * spell.mult
						return (low + high)/2, low, high
					else -- Damage spell is not ranged (xx)
						avg = ( spell.davg[rank] + (GetSpellBonusDamage(2) * spell.dcoeff) ) * spell.mult
						return avg
					end
				else -- Healing Calculation
					spell.heal = false
					if spell.rangeheal then
						low = ( spell.hlow[rank] + (GetSpellBonusHealing() * spell.hcoeff) ) * spell.mult
						high = ( spell.hhigh[rank] + (GetSpellBonusHealing() * spell.hcoeff) ) * spell.mult
						return (low + high)/2, low, high
					else
						avg = ( spell.havg[rank] + (GetSpellBonusHealing() * spell.hcoeff) ) * spell.mult
					end
				end
			elseif spell.spandap then
				if spell.type == "direct" then
					low = ( spell.low[rank] + spell.coeffs * GetSpellBonusDamage(2) + spell.coeffa * AP() ) * spell.mult
					high = ( spell.high[rank] + spell.coeffs * GetSpellBonusDamage(2) + spell.coeffa * AP() ) * spell.mult
					return (low + high)/2, low, high
				elseif spell.type == "ot" then
					avg = ( spell.avg[rank] + spell.coeffs * GetSpellBonusDamage(2) + spell.coeffa * AP() ) * spell.mult
					return avg * spell.ticks, avg
				end	
			elseif spell.type == "direct" then
				if spell.range == true then
					low = ( spell.low[rank] + (fromspellpower * spell.coeff) ) * spell.mult
					high = ( spell.high[rank] + (fromspellpower * spell.coeff) ) * spell.mult
					return (low + high)/2, low, high
				else
					avg = ( spell.avg[rank] + (fromspellpower * spell.coeff) ) * spell.mult
					return avg
				end
			elseif spell.type == "ot" or spell.type == "channel" then
				if spell.range == true then
					low = ( spell.low[rank] + (fromspellpower * spell.coeff) ) * spell.mult
					high = ( spell.high[rank] + (fromspellpower * spell.coeff) ) * spell.mult
					return (low + high)/2 * spell.ticks, low * spell.ticks, high * spell.ticks
				else
					avg = ( spell.avg[rank] + (fromspellpower * spell.coeff) ) * spell.mult
					return avg * spell.ticks, avg
				end
			elseif spell.type == "hybrid" then
				local mult
				if spell.range then
					if spell.multadd then mult = spell.multadd else mult = spell.mult end
					low = ( spell.low[rank] + (fromspellpower * spell.coeff) ) * spell.mult
					high = ( spell.high[rank] + (fromspellpower * spell.coeff) ) * spell.mult
					dot = ( spell.add[rank] + (fromspellpower * spell.coeffadd) ) * mult
					return (low + high + dot*2)/2, low + dot, high + dot, dot
				else
					if spell.multadd then mult = spell.multadd else mult = spell.mult end
					avg = ( spell.avg[rank] + (fromspellpower * spell.coeff) ) * spell.mult
					dot = ( spell.add[rank] + (fromspellpower * spell.coeffadd) ) * mult
					return avg + dot*spell.ticks, avg, dot
				end
			elseif spell.type == "absorb" then
				avg = ( spell.avg[rank] + (fromspellpower * spell.coeff) ) * spell.mult
				return avg			
			end
		end
	else
		return ""
	end
end
-- Physical Calculations --
function MrD_Physical_Calculate(name, rank)
	local attack = MrD.Info[name]
	local lowDamage; local highDamage;
	if attack then
		if attack.type == "special" then
			local abilname = "" 
			for word in string.gmatch(name, "%a+") do abilname = abilname..word end
			local calc = _G["MrD_"..abilname]
			return calc(rank)
		elseif attack.ranged then
			lowDamage, highDamage = select(2, UnitRangedDamage("player"))
		elseif attack.melee then
			lowDamage, highDamage = UnitDamage("player")
		end

		if attack.combo then
			if GetComboPoints("player", "target") == 0 then
				return 0, 0 ,0
			elseif attack.dot then
				avg = ( attack.combo[GetComboPoints("player", "target")][rank] + attack.perc[GetComboPoints("player", "target")] * AP() ) * attack.mult
				return avg * attack.ticks[GetComboPoints("player", "target")], avg
			elseif attack.range then
				low = Armor( (attack.combol[GetComboPoints("player", "target")][rank] + attack.percl[GetComboPoints("player", "target")] * AP()) * attack.mult, attack )
				high = Armor( (attack.comboh[GetComboPoints("player", "target")][rank] + attack.perch[GetComboPoints("player", "target")] * AP() ) * attack.mult, attack )
				return (low + high)/2, low, high
			else
				avg = Armor( (attack.combo[GetComboPoints("player", "target")][rank] + attack.perc[GetComboPoints("player", "target")] * AP() ) * attack.mult, attack )
				return avg
			end		
		elseif attack.type == "both" then
			local add
			if attack.add then add = attack.add[rank] else add = 0 end
			lowMain, highMain, lowOff, highOff = UnitDamage("player")
			low = ( (lowMain + lowOff) * attack.perc + add ) * attack.mult
			high = ( (highMain + highOff) * attack.perc + add ) * attack.mult
			return (low + high)/2, low, high
		elseif attack.type == "weap" then
			local add
			if attack.avg then add = attack.avg[rank] else add = 0 end
			low = Armor( ( attack.perc * lowDamage + add ) * attack.mult, attack )
			high = Armor( ( attack.perc * highDamage + add ) * attack.mult, attack )
			return (low + high)/2, low, high
		elseif attack.type == "ap" then
			local ticks; local add;
			if attack.dot then ticks = attack.ticks else ticks = 1 end
			if attack.range then
				local low = Armor( (attack.perc * AP() + attack.low[rank]), attack )
				local high = Armor( (attack.perc * AP() + attack.high[rank]), attack )
				return (low + high)/2, low, high
			else
				if attack.avg then add = attack.avg[rank] elseif attack.add then add = attack.add else add = 0 end
				avg = Armor( ( attack.perc * AP() + add ) * attack.mult, attack )
				return avg *ticks, avg
			end
		elseif attack.type == "shield" then
			local add
			if attack.avg then add = attack.avg[rank] else add = 0 end
			local avg = Armor( ( GetShieldBlock() * attack.perc + add ) * attack.mult, attack )
			return avg
		elseif attack.type == "hybrid" then
			if attack.ap then
				local ticks = attack.ticks
				local direct = Armor( AP()/100 + attack.avg[rank], attack )
				local dot = (attack.add[rank] + AP() * attack.perc) / attack.ticks
				return direct + dot*attack.ticks, direct, dot
			end
		else
			return 0
		end
	else
		return 0
	end
end
-- Armor Reduction --
function Armor(dmg, attack)
	if MrDSettings["armor"] == false or not attack.armor then return dmg else
		local armorpenpercent; local mainhand; local MobLevel; local MobArmor; local ArmorMitigation;
		if UnitLevel("player") <=60 then armorpenpercent = GetCombatRating(25)/3.75 
		elseif UnitLevel("player") <= 70 then armorpenpercent = GetCombatRating(25)/(3.75 + .217*(UnitLevel("player")-60)) -- First, determine what our Armor Pen % is at
		elseif UnitLevel("player") <= 80 then armorpenpercent = GetCombatRating(25)/(5.92 + .639*(UnitLevel("player")-70)) end
		if GetShapeshiftForm() == 1 then armorpenpercent = armorpenpercent + 10 end-- Battle Stance end
		if T["Mace Specialization"] and GetInventoryItemLink("player", 16) then
			mainhand = GetInventoryItemLink("player", 16)
			if select(7, GetItemInfo(mainhand)) == "One-Handed Maces" or select(7, GetItemInfo(mainhand)) == "Two-Handed Maces" then -- Mace Specialization
				armorpenpercent = armorpenpercent + T["Mace Specialization"]*3
			end
		end
		if T["Blood Gorged"] then
			armorpenpercent = armorpenpercent + T["Blood Gorged"]*2
		end
		if UnitLevel("target") == -1 then MobLevel = UnitLevel("player") + 3 -- Skull Mob we'll just put as 3 levels above us
		elseif MobLevel == 0 then MobLevel = UnitLevel("player") -- No target = same level mob
		else MobLevel = UnitLevel("target")	end
		if (UnitClassification("target") == "worldboss" or UnitClassification("target") == "elite") and MobLevel == UnitLevel("player") + 3 then
			MobArmor = 98 * MobLevel + 3483 -- Also really arbitrary except against Raid Bosses
		else
			MobArmor = 98 * MobLevel -- This is really, really, really, arbitrary.
		end
		local name, _,_, count = UnitDebuff("target", "Sunder Armor")
		if UnitDebuff("target", "Expose Armor") == "Expose Armor" then
			armorpenpercent = armorpenpercent + 20-- Expose Armor
		elseif name == "Sunder Armor" and count then
			armorpenpercent = armorpenpercent + 4*count -- Sunder Armor
		elseif UnitDebuff("target", "Acid Spit") == "Acid Spit" then
			armorpenpercent = armorpenpercent + 10	-- Acid Spit
		end
		if UnitDebuff("target", "Faerie Fire") == "Faerie Fire" or UnitDebuff("target", "Faerie Fire (Feral)") == "Faerie Fire (Feral)" or UnitDebuff("target", "Sting") == "Sting" or UnitDebuff("target", "Curse of Recklessness") == "Curse of Recklessness" then
			armorpenpercent = armorpenpercent + 5	-- Faerie Fire, Sting, CoR
		end
		MobArmor = MobArmor * (1 - armorpenpercent/100)
		if MobLevel < 60 then 
			ArmorMitigation = MobArmor / (MobArmor + 400 + 85 * UnitLevel("player")) 
		else
			ArmorMitigation = MobArmor / (MobArmor + 400 + 85 * (UnitLevel("player") + 4.5 * (UnitLevel("player") - 59)))
		end
		if ArmorMitigation > .75 then ArmorMitigation = .75 end
		dmg = dmg * (1 - ArmorMitigation)
		return dmg
	end
end

-- Update Text
function MrDamage_Frame_UpdateButton(button, DEBUG1, DEBUG2)
	local name
	local rank
	
	if DEBUG1 then
		name = DEBUG1;
		rank = DEBUG2;
	else
		local type, id, _, spellid = GetActionInfo(ActionButton_GetPagedID(button))
		if spellid == nil and type == "macro" then
			name, rank = GetMacroSpell(id)
		elseif spellid ~= nil then
			name, rank = GetSpellInfo(spellid)
		end
	end
	
	if name and rank then
		if MrD_Class == "DeathKnight" then
			if string.find(name, "(Cat)") then
				form = 3
				wospaces = string.sub(name, 1, string.find(name, "%s") - 1)	
			elseif string.find(name, "(Bear)") then
				form = 1
				wospaces = string.sub(name, 1, string.find(name, "%s") - 1)
			elseif string.find(name, "(Feral)") then
				wospaces = "FaerieFire"
			elseif name == "Dragon's Breath" then
				wospaces = "DragonsBreath"
			elseif name == "Avenger's Shield" then
				wospaces = "AvengersShield"
			else
				wospaces = "" 
				for word in string.gmatch(name, "%a+") do wospaces = wospaces..word end
			end
			rank = tonumber(string.sub(rank, 6))
			if rank == nil then rank = 0 end
			local damage = _G["MrDamage_"..MrD_Class.."_"..wospaces]
			if damage and rank then
				Damage[name..rank], Damage_Low[name..rank], Damage_High[name..rank], Damage_Direct[name..rank], Damage_PerTick[name..rank], Damage_Ticks[name..rank], Damage_TickInterval[name..rank] = damage(rank, 0, 0, form)
				if MrDSettings["show"] == 0 then
					return sf("%.0f", Damage[name..rank])
				elseif MrDSettings["show"] == 1 then
					if select(4, GetSpellInfo(name, rank)) > 0 then
						return sf ("%.0f", Damage[name..rank]/select(4, GetSpellInfo(name, rank)))
					else
						return sf("%.0f", Damage[name..rank])
					end
				elseif MrDSettings["show"] == 2 then
					if Damage_TickInterval[name..rank] then
						return sf("%.0f", Damage[name..rank]/(Damage_Ticks[name..rank] * Damage_TickInterval[name..rank]))
					elseif select(7, GetSpellInfo(name, rank)) > 0 then
						return sf("%.2f", Damage[name..rank]/(select(7, GetSpellInfo(name, rank))/1000))
					else
						return sf("%.0f", Damage[name..rank])
					end
				else
					return sf("%.0f", Damage[name..rank])
				end
			else
				return ""
			end
		elseif MrD_Class ~= "Hunter" then
			if MrD.Info[name] then
				if name == "Attack" then
					local low, high = UnitDamage("player")
					return sf("%.0f", Armor( (low + high)/2, MrD.Info.Attack ))
				elseif name == "Shoot" or name == "Throw" then
					local low, high = select(2, UnitRangedDamage("player"))
					return sf("%.0f", Armor( (low + high)/2, MrD.Info.Shoot ))
				end
				rank = tonumber(string.sub(rank, 6))
				if MrD.Info[name]["melee"] then
					return sf( "%.0f", MrD_Physical_Calculate(name, rank) )
				else
					local amt = MrD_Spell_Calculate(name, rank, 0)
					if amt then return sf( "%.0f", amt ) else return "" end
				end
			else
				return ""
			end
		end
	else
		return ""
	end
end

-- Updates Tooltip
function MrDamage_SetTooltip(self, DEBUG1, DEBUG2)

	if MrDSettings["on"] == true and MrDamage.InfoAdded == false and GetMouseFocus() and ActionButton_GetPagedID(GetMouseFocus()) and MrD_Class == "DeathKnight" then
		local name, rank, numrank
		local classcoeffs = _G["MrDamage_"..MrD_Class.."_UpdateCoefficients"]
		if select(4, GetActionInfo( ActionButton_GetPagedID(GetMouseFocus()))) and GetSpellInfo(select(4, GetActionInfo( ActionButton_GetPagedID(GetMouseFocus())))) == "Attack" then
			name = "Attack"
			numrank = 0
		else
			name, rank, id = GameTooltip:GetSpell();
			if rank == "" then numrank = 0 elseif rank then numrank = tonumber(string.sub(rank, 6)) end
		end
		if name then
			if numrank and Damage[name..numrank] then
				MrDamage.InfoAdded = true
				local cost, _, powerType, castTime = select(4, GetSpellInfo(name, rank))
				
				-- Determine if Heal or Damage --
				local text, r, g
				if Rank.Heal[name] then
					text = "Healing"
					r = 0
					g = 1
				else
					text = "Damage"
					r = 1
					g = 0
				end
				
				-- Damage --
				if Damage_PerTick[name..numrank] then	-- First, check for DoT/Hot
					GameTooltip:AddDoubleLine(text..":", sf("%.0f", Damage[name..numrank]).." (~"..sf("%.0f", Damage_PerTick[name..numrank]).." for "..sf("%.0f", Damage_Ticks[name..numrank]).." ticks)", 1,1,1,r,g,0)
				elseif Damage_Low[name..numrank] then -- No? How about range?
					GameTooltip:AddDoubleLine(text..":", sf("%.0f", Damage[name..numrank]).." ("..sf("%.0f", Damage_Low[name..numrank]).." to "..sf("%.0f", Damage_High[name..numrank])..")", 1,1,1,r,g,0)
				elseif Rank.Special[name] then -- Special Ability?
					GameTooltip:AddDoubleLine(Rank.Special[name], sf("%.0f", Damage[name..numrank]), 1,1,1,0,1,1)
				else -- Ok fine, just plain ole' damage
					GameTooltip:AddDoubleLine(text..":", sf("%.0f", Damage[name..numrank]), 1,1,1,r,g,0)
				end
				GameTooltip:Show()
				if not Rank.Special[name] and name ~= "Attack" then
					-- Resources --
					if powerType == 0 and spellid ~= 6603 and spellid ~= 2764 and spellid ~= 3018 then
						GameTooltip:AddDoubleLine(text.." Per Mana:", sf("%.2f", Damage[name..numrank]/cost), 1,1,1,r,g,0)
					elseif powerType == 1 then
						GameTooltip:AddDoubleLine(text.." Per Rage:", sf("%.2f", Damage[name..numrank]/cost), 1,1,1,r,g,0)
					elseif powerType == 3 then
						GameTooltip:AddDoubleLine(text.." Per Energy:", sf("%.2f", Damage[name..numrank]/cost), 1,1,1,r,g,0)
					elseif powerType == 6 then
						GameTooltip:AddDoubleLine(text.." Per Runic Power:", sf("%.2f", Damage[name..numrank]/cost), 1,1,1,r,g,0)
					end
					-- Time --
					if Damage_TickInterval[name..numrank] then
						GameTooltip:AddDoubleLine(text.." per DoT Time:", sf("%.2f", Damage[name..numrank]/(Damage_Ticks[name..numrank] * Damage_TickInterval[name..numrank])), 1,1,1,r,g,0)
					elseif select(7, GetSpellInfo(name, rank)) > 0 and spellid ~= 2764 and spellid ~= 3018 then
						GameTooltip:AddDoubleLine(text.." per Cast Time:", sf("%.2f", Damage[name..numrank]/(castTime/1000)), 1,1,1,r,g,0)
					end
					-- Casts --
					if powerType == 0 and spellid ~= 6603 and spellid ~= 2764 and spellid ~= 3018 then
						GameTooltip:AddDoubleLine("Until Oom:", sf("%.0f", UnitMana("player")/cost).." casts/"..sf("%.0f", tonumber(sf("%.0f", UnitMana("player")/cost)) * Damage[name..numrank]).." "..text, 1,1,1,0,1,1)
					end
				end
				-- Coefficient --
				if C[GetSpellInfo(name, rank)] then
					GameTooltip:AddDoubleLine("Coefficient(s):", C[GetSpellInfo(name, rank)], 1,1,1,0,1,1)
				end
				GameTooltip:Show()
			end
		end
	elseif MrDamage.InfoAdded == false and MrD_Class ~= "Hunter" then
		MrDamage.InfoAdded = true
		local name; local rank
		if DEBUG1 then
			name = DEBUG1
			rank = DEBUG2
		else
			name, rank= GameTooltip:GetSpell()
		end
		if rank == "" then numrank = 0 elseif rank then numrank = tonumber(string.sub(rank, 6)) end
		local spell = MrD.Info[name]
		if spell then
			if spell.special then
				local nospaces = "" 
				for word in string.gmatch(name, "%a+") do nospaces = nospaces..word end
				local tool = _G["MrD_Tooltip_"..nospaces]
				tool(rank)
			else
				if not spell.melee and not spell.ranged and spell.type ~= "absorb" then
					local damage = MrD_Spell_Calculate(name, numrank, 0)
					-- Damage or Heal --
					local r; local g; local b; local text; local effecttype;
					if spell.school or (spell.both and spell.heal == false) then
						r = 1; g = 0; b = 0;
						text = "D"
						effecttype = "Damage"
					else
						r = 0; g = 1; b = 0;
						text = "H"
						effecttype = "Healing"
					end
					-- Damage Breakdown --
					if spell.type == "ot" then
						local dot = select(2, MrD_Spell_Calculate(name, numrank, 0))
						GameTooltip:AddDoubleLine("DoT:", "~"..sf("%.0f", dot).." for "..spell.ticks.." ticks", 1,1,1,r,g,b)
					elseif spell.type == "hybrid" then
						if spell.range then
							local low, high, dot = select(2, MrD_Spell_Calculate(name, numrank, 0))
							GameTooltip:AddDoubleLine("Direct:", sf( "%.0f", low).." to "..sf( "%.0f", high), 1,1,1,r,g,b)
							GameTooltip:AddDoubleLine(text.."oT:", "~"..sf("%.0f", dot).." for "..spell.ticks.." ticks", 1,1,1,r,g,b)
						else
							local direct, dot = select(2, MrD_Spell_Calculate(name, numrank, 0))
							GameTooltip:AddDoubleLine("Direct:", sf( "%.0f", direct), 1,1,1,r,g,b)
							GameTooltip:AddDoubleLine(text.."oT:", "~"..sf("%.0f", dot).." for "..spell.ticks.." ticks", 1,1,1,r,g,b)
						end
					elseif spell.type == "channel" then
						local low, high, dot = MrD_Spell_Calculate(name, numrank, 0)
						if spell.range then
							GameTooltip:AddDoubleLine(effecttype..":", sf( "%.0f", low).." to "..sf( "%.0f", high), 1,1,1,r,g,b)
							GameTooltip:AddDoubleLine("Channeled:", "~"..sf("%.0f", dot).." every "..spell.int.." secs", 1,1,1,r,g,b)
						else
							dot = select(2, MrD_Spell_Calculate(name, numrank, 0))
							GameTooltip:AddDoubleLine("Channeled:", sf("%.0f", dot).." every "..spell.int.." secs", 1,1,1,r,g,b)
						end
					elseif spell.range then
						local low, high = select(2, MrD_Spell_Calculate(name, numrank, 0))
						GameTooltip:AddDoubleLine(effecttype..":", sf( "%.0f", low).." to "..sf( "%.0f", high), 1,1,1,r,g,b)
					end
					local cost, _, powerType, castTime = select(4, GetSpellInfo(name, rank))
					-- Resource --
					if powerType == 0 and spellid ~= 6603 and spellid ~= 2764 and spellid ~= 3018 then
						GameTooltip:AddDoubleLine(text.."PM:", sf("%.2f", damage/cost), 1,1,1,r,g,b)
					elseif powerType == 6 then
						GameTooltip:AddDoubleLine(text.."PRP:", sf("%.2f", damage/cost), 1,1,1,r,g,b)
					end
					-- Time (Spell Time, Cast Time, Cooldown Time) --
					if spell.type == "ot" then
						GameTooltip:AddDoubleLine(text.."PST", sf("%.2f", damage/(spell.ticks * spell.int)), 1,1,1,r,g,b)
					elseif select(7, GetSpellInfo(name, rank)) > 0 then
						GameTooltip:AddDoubleLine(text.."PCT", sf("%.2f", damage/(castTime/1000)), 1,1,1,r,g,b)
					elseif spell.cd then
						GameTooltip:AddDoubleLine(text.."PCD", sf("%.2f", damage/spell.cd), 1,1,1,r,g,b)
					end
					-- Casts --
					if powerType == 0 then
						GameTooltip:AddDoubleLine("Until Oom:", sf("%.0f", UnitMana("player")/cost).." casts/"..sf("%.0f", floor(UnitMana("player")/cost) * damage).." "..effecttype, 1,1,1,0,.5,1)
					end
					-- Coefficient --
					if spell.coeff then
						GameTooltip:AddDoubleLine("Spell Coefficient:", sf("%.2f", spell.coeff*100).."%", 1,1,1,0,1,1)
					elseif spell.both then
						GameTooltip:AddDoubleLine("Coefficient (Damage/Heal):", sf("%.2f", spell.dcoeff*100).."% / "..sf("%.2f", spell.hcoeff*100).."%", 1,1,1,0,1,1)
					end
				elseif spell.melee then
					local param1, param2, param3 = MrD_Physical_Calculate(name, numrank)
					if param1 > 0 then
						if spell.range then
							GameTooltip:AddDoubleLine("Damage:", sf( "%.0f", param2).." to "..sf( "%.0f", param3), 1,1,1,1,0,0)
						elseif spell.dot then
							local ticks 
							if spell.combo then 
								if GetComboPoints("player", "target") > 0 then
									GameTooltip:AddDoubleLine("DoT:", "~"..sf("%.0f", param2).." for "..spell.ticks[GetComboPoints("player", "target")].." ticks", 1,1,1,1,0,0)
								end
							else
								GameTooltip:AddDoubleLine("DoT:", "~"..sf("%.0f", param2).." for "..spell.ticks.." ticks", 1,1,1,1,0,0)
							end
						end
						local cost, _, powerType, castTime = select(4, GetSpellInfo(name, rank))
						
						-- Resource --
						if powerType == 1 then
							GameTooltip:AddDoubleLine("DP Rage:", sf("%.2f", param1/cost), 1,1,1,1,0,0)
						elseif powerType == 3 then
							GameTooltip:AddDoubleLine("DP Energy:", sf("%.2f", param1/cost), 1,1,1,1,0,0)
						end
						-- Time (Spell Time, Cast Time, Cooldown Time) --
						if spell.dot then
							if spell.combo and GetComboPoints("player", "target") > 0 then
								GameTooltip:AddDoubleLine("DP Debuff Time:", sf("%.2f", param1/(spell.ticks[GetComboPoints("player", "target")] * spell.int)), 1,1,1,1,0,0)
							elseif spell.combo == nil then 
								GameTooltip:AddDoubleLine("DP Debuff Time:", sf("%.2f", param1/(spell.ticks * spell.int)), 1,1,1,1,0,0)
							end
						elseif select(7, GetSpellInfo(name, rank)) > 0 then
							GameTooltip:AddDoubleLine("DP Cast Time:", sf("%.2f", param1/(castTime/1000)), 1,1,1,r,g,b)
						elseif spell.cd then
							GameTooltip:AddDoubleLine("DP Cooldown:", sf("%.2f", param1/spell.cd), 1,1,1,r,g,b)
						end
						-- Combo Point --
						if spell.combo then
							GameTooltip:AddDoubleLine("DP Combo Point:", sf("%.2f", param1/GetComboPoints("player", "target")),1,1,1,1,0,0)
						end
					end
				end
			end
		end
		GameTooltip:Show()
	end
end
----
-- GUI Function
----
-- Create GUI --
function MrDamage_CreateOptions()

	local panel = CreateFrame("FRAME", "MrDamageOptions");
	panel.name = "Mr Damage"
	local s1 = panel:CreateFontString("$parent_Title","OVERLAY","GameFontNormalLarge")
	s1:SetText("Mr Damage")
	s1:SetPoint("TOPLEFT", 16, -16	)
	local s2 = panel:CreateFontString("$parent_Description","OVERLAY","GameFontHighlightSmall")
	s2:SetText("Mr Damage displays damage and healing calulations for the spells on the corresponding buttons. Additional information is also displayed within the tooltips.")
	s2:SetPoint("TOPLEFT", 16, -35)
	s2:SetJustifyH("Left")
	s2:SetWidth(390)
	local c1 = CreateFrame("CheckButton", "$parent_EnableCheck", panel, "OptionsCheckButtonTemplate")
	c1:SetWidth(28)
	c1:SetHeight(28)
	c1:SetChecked(MrDSettings["on"])
	c1:SetScript("OnClick", MrDamage_ToggleEnable)
	c1:SetPoint("TOPLEFT", "$parent_Description", "BOTTOMLEFT", 0, -10)
	local s3 = panel:CreateFontString("$parent_EnabledString","OVERLAY","GameFontNormal")
	s3:SetText("Enabled")
	s3:SetPoint("LEFT", "$parent_EnableCheck", "RIGHT", 5, 0)
	local s4 = panel:CreateFontString("$parent_HorizontalString","OVERLAY","GameFontNormal")
	s4:SetText("Horizontal:")
	s4:SetPoint("TOPLEFT", "$parent_EnableCheck", "BOTTOMLEFT", 0, -10)
	local sliderH = CreateFrame("Slider", "$parent_Horizontal", panel, "OptionsSliderTemplate")
	sliderH:SetMinMaxValues(-50, 50)
	sliderH:SetValue(MrDSettings["x"])
	sliderH:SetValueStep(1)
	sliderH:SetScript("OnValueChanged", MrDamage_PositionUpdate)
	getglobal(sliderH:GetName() .. "Low"):SetText("Left +50")
	getglobal(sliderH:GetName() .. "High"):SetText("Right +50")
	getglobal(sliderH:GetName() .. "Text"):SetText(MrDSettings["x"])
	sliderH:SetPoint("LEFT", "$parent_HorizontalString", "RIGHT", 15, 0)
	local sliderV = CreateFrame("Slider", "$parent_Vertical", panel, "OptionsSliderTemplate")
	sliderV:SetMinMaxValues(-50, 50)
	sliderV:SetValue(MrDSettings["y"])
	sliderV:SetValueStep(1)
	sliderV:SetScript("OnValueChanged", MrDamage_PositionUpdate)
	getglobal(sliderV:GetName() .. "Low"):SetText("Down +50")
	getglobal(sliderV:GetName() .. "High"):SetText("Up +50")
	getglobal(sliderV:GetName() .. "Text"):SetText(MrDSettings["y"])
	sliderV:SetPoint("TOP", "$parent_Horizontal", "BOTTOM", 0, -20)
	local s5 = panel:CreateFontString("$parent_VerticalString","OVERLAY","GameFontNormal")
	s5:SetText("Vertical:")
	s5:SetPoint("RIGHT", "$parent_Vertical", "LEFT", -15, 0)
	local s6 = panel:CreateFontString("$parent_DropDownString","OVERLAY","GameFontNormal")
	s6:SetText("Display on Buttons:")
	s6:SetPoint("LEFT", "$parent_EnabledString", "RIGHT", 165, 0)
	local drop1 = CreateFrame("FRAME", "$parent_ButtonDisplay", panel, "UIDropDownMenuTemplate")
	drop1:SetPoint("TOPLEFT", "$parent_DropDownString", "BOTTOMLEFT", -20, -5)
	UIDropDownMenu_Initialize(MrDamageOptions_ButtonDisplay, ButtonDisplayDropDown_Initialise)
	local sliderS = CreateFrame("Slider", "$parent_Scale", panel, "OptionsSliderTemplate")
	sliderS:SetMinMaxValues(1, 24)
	sliderS:SetValue(MrDSettings["font"])
	sliderS:SetValueStep(1)
	sliderS:SetScript("OnValueChanged", MrDamage_ScaleUpdate)
	getglobal(sliderS:GetName() .. "Low"):SetText("1")
	getglobal(sliderS:GetName() .. "High"):SetText("24")
	getglobal(sliderS:GetName() .. "Text"):SetText(MrDSettings["font"])
	sliderS:SetPoint("TOP", "$parent_Vertical", "BOTTOM", 0, -20)
	local s7 = panel:CreateFontString("$parent_ScaleString","OVERLAY","GameFontNormal")
	s7:SetText("Size:")
	s7:SetPoint("RIGHT", "$parent_Scale", "LEFT", -15, 0)
	local s8 = panel:CreateFontString("$parent_ColorString","OVERLAY","GameFontNormal")
	s8:SetText("Color:")
	s8:SetPoint("TOPLEFT", "$parent_ButtonDisplay", "BOTTOM", 0, -5)
	local sliderR = CreateFrame("Slider", "$parent_SliderRed", panel, "OptionsSliderTemplate")
	sliderR:SetMinMaxValues(0, 1)
	sliderR:SetValue(MrDSettings["r"])
	sliderR:SetValueStep(.01)
	sliderR:SetWidth(120)
	sliderR:SetScript("OnValueChanged", MrDamage_ColorUpdate)
	getglobal(sliderR:GetName() .. "Low"):SetText("0")
	getglobal(sliderR:GetName() .. "High"):SetText("1")
	getglobal(sliderR:GetName() .. "Text"):SetText("Red")
	sliderR:SetPoint("TOPLEFT", "$parent_ColorString", "BOTTOMLEFT", 0, -15)
	local sliderG = CreateFrame("Slider", "$parent_SliderGreen", panel, "OptionsSliderTemplate")
	sliderG:SetMinMaxValues(0, 1)
	sliderG:SetValue(MrDSettings["g"])
	sliderG:SetValueStep(.01)
	sliderG:SetWidth(120)
	sliderG:SetScript("OnValueChanged", MrDamage_ColorUpdate)
	getglobal(sliderG:GetName() .. "Low"):SetText("0")
	getglobal(sliderG:GetName() .. "High"):SetText("1")
	getglobal(sliderG:GetName() .. "Text"):SetText("Green")
	sliderG:SetPoint("TOP", "$parent_SliderRed", "BOTTOM", 0, -10)
	local sliderB = CreateFrame("Slider", "$parent_SliderBlue", panel, "OptionsSliderTemplate")
	sliderB:SetMinMaxValues(0, 1)
	sliderB:SetValue(MrDSettings["b"])
	sliderB:SetValueStep(.01)
	sliderB:SetWidth(120)
	sliderB:SetScript("OnValueChanged", MrDamage_ColorUpdate)
	getglobal(sliderB:GetName() .. "Low"):SetText("0")
	getglobal(sliderB:GetName() .. "High"):SetText("1")
	getglobal(sliderB:GetName() .. "Text"):SetText("Blue")
	sliderB:SetPoint("TOP", "$parent_SliderGreen", "BOTTOM", 0, -10)
	local default = CreateFrame("Button", "$parent_Default", panel, "OptionsButtonTemplate")
	default:SetPoint("BOTTOMRIGHT", "$parent", "BOTTOMRIGHT", -10, 10)
	default:SetText("Default")
	default:SetScript("OnClick", MrDamage_SetDefault)
	local c2 = CreateFrame("CheckButton", "$parent_Armor", panel, "OptionsCheckButtonTemplate")
	c2:SetWidth(28)
	c2:SetHeight(28)
	c2:SetChecked(MrDSettings["armor"])
	c2:SetScript("OnClick", MrDamage_ToggleArmor)
	c2:SetPoint("LEFT", "$parent", "LEFT", 10, -10)
	local s9 = panel:CreateFontString("$parent_ArmorString","OVERLAY","GameFontNormal")
	s9:SetText("Account for Armor")
	s9:SetPoint("LEFT", "$parent_Armor", "RIGHT", 5, 0)

	InterfaceOptions_AddCategory(panel);
end
-- Load Settings
function MrDamage_SetDisplay()
	MrDamageOptions_EnableCheck:SetChecked(MrDSettings["on"])
	MrDamageOptions_Armor:SetChecked(MrDSettings["armor"])
	MrDamageOptions_ButtonDisplayButton:Click()
	b = _G["DropDownList1Button"..MrDSettings.show+1]
	b:Click()
	for i = 1, 120 do
		local s = _G["MrDString"..i]
		if s then
			s:SetTextColor(MrDSettings["r"], MrDSettings["g"], MrDSettings["b"])
			s:SetFont("Fonts\\FRIZQT__.TTF", MrDSettings["font"], "OUTLINE, MONOCHROME")
			s:SetPoint("BOTTOM", MrDSettings["x"], MrDSettings["y"])
		end
	end
	MrDamageOptions_Horizontal:SetValue(MrDSettings["x"])
	MrDamageOptions_Vertical:SetValue(MrDSettings["y"])
	MrDamageOptions_Scale:SetValue(MrDSettings["font"])
	MrDamageOptions_SliderRed:SetValue(MrDSettings["r"])
	MrDamageOptions_SliderGreen:SetValue(MrDSettings["g"])
	MrDamageOptions_SliderBlue:SetValue(MrDSettings["b"])
end
-- Initialize Dropdown Menu
function ButtonDisplayDropDown_Initialise()
	level = level or 1 
	
	local info = UIDropDownMenu_CreateInfo();
	
	info.text = "Damage/Healing"; 
	info.value = 0; 
	info.func = function() ButtonDisplayDropDown_OnClick() end; 
	info.owner = MrDamageOptions_ButtonDisplay 
	info.checked = nil; 
	info.icon = nil; 
	UIDropDownMenu_AddButton(info, level);

	info.text = "Per Resource";
	info.value = 1;
	info.func = function() ButtonDisplayDropDown_OnClick() end;
	info.owner = this:GetParent();
	info.checked = nil;
	info.icon = nil;
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Per Cast/DoT Time";
	info.value = 2;
	info.func = function() ButtonDisplayDropDown_OnClick() end;
	info.owner = this:GetParent();
	info.checked = nil;
	info.icon = nil;
	UIDropDownMenu_AddButton(info, level);
	
end
function ButtonDisplayDropDown_OnClick()
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	MrDSettings["show"] = this.value
end
-- Slash Command
function MrDamage_SlashCommand(cmd)
	InterfaceOptionsFrame_OpenToCategory(getglobal("MrDamageOptions"))
end
-- Enable/Disable
function MrDamage_ToggleArmor(self)
	if self:GetChecked() then
		MrDSettings["armor"] = true
	else
		MrDSettings["armor"] = false
	end
end
function MrDamage_ToggleEnable(self)
	if self:GetChecked() then
		MrDamageFrame:SetScript("OnUpdate", MrDamage_AwaitingTalents)
		MrDSettings["on"] = true
	else
		MrDamageFrame:SetScript("OnUpdate", nil)
		MrDSettings["on"] = false
		for i = 1, 120 do
			local s = _G["MrDString"..i]
			if s then s:SetText("") end
		end
	end
end
-- Position Update
function MrDamage_PositionUpdate(self)
	getglobal(self:GetName() .. "Text"):SetText(string.format("%.0f", self:GetValue()))
	for i = 1, 120 do
		local s = _G["MrDString"..i]
		if s then s:SetPoint("BOTTOM", MrDamageOptions_Horizontal:GetValue(), MrDamageOptions_Vertical:GetValue()) end
	end
	MrDSettings["x"] = MrDamageOptions_Horizontal:GetValue()
	MrDSettings["y"] = MrDamageOptions_Vertical:GetValue()
end
-- Scale Update
function MrDamage_ScaleUpdate(self)
	getglobal(self:GetName() .. "Text"):SetText(string.format("%.0f", self:GetValue()))
	for i = 1, 120 do
		local s = _G["MrDString"..i]
		if s then s:SetFont("Fonts\\FRIZQT__.TTF", self:GetValue(), "OUTLINE, MONOCHROME") end
	end
	MrDSettings["font"] = self:GetValue()
end
-- Color Update
function MrDamage_ColorUpdate(self)
	for i = 1, 120 do
		local s = _G["MrDString"..i]
		if s then s:SetTextColor(MrDamageOptions_SliderRed:GetValue(), MrDamageOptions_SliderGreen:GetValue(), MrDamageOptions_SliderBlue:GetValue() ) end
	end
	MrDSettings["r"] = MrDamageOptions_SliderRed:GetValue()
	MrDSettings["g"] = MrDamageOptions_SliderGreen:GetValue()
	MrDSettings["b"] = MrDamageOptions_SliderBlue:GetValue()
end
-- Set Defaults
function MrDamage_SetDefault()
	MrDSettings = { ["on"] = true, ["x"] = 0, ["y"] = 5, ["font"] = 12, ["r"] = 1, ["g"] = .82, ["b"] = 0, ["show"] = 0, ["armor"] = true }
	MrDamage_SetDisplay()
end

-- :::DEBUGG FUNCTION::: --
function MrD_Debug()
	for i = 1, GetNumTalentTabs() do
		local talents = GetNumTalents(i)
		for t = 1, talents do
			local name, _, _, _, points = GetTalentInfo(i,t);
			T[name] = 1
		end
	end
	for i = 40000, 70000 do
		MrDamage.Glyphs[i] = true
	end
	for k,v in pairs(MrD.Info) do
		print(k)
		print(": "..MrDamage_Frame_UpdateButton(nil, k, "Rank 1"))
	end
end
