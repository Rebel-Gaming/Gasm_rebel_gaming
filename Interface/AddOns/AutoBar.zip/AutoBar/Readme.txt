Support is at http://code.google.com/p/autobar/

*Read the FAQ and Usage wikis on the site for help with common tasks
*For Cooldown counts please use Omni Cooldown Count
*For skinning install the ButtonFacade mod
