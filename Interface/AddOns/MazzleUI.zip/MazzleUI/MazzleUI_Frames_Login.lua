-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--
MazzleUI.FrameInfo_Login = {}
MazzleUI.FrameInfo_Login[1] = {
	["ChatFrameEditBox"] = {
		["location"] = {
			["y"] = 231,
			["x"] = -2,
			["point"] = "BOTTOMLEFT",
			["frame"] = "UIParent",
			["to"] = "BOTTOMLEFT",
		},
		["height"] = 34,
		["texture"] = {
			["inset3"] = 5,
			["inset1"] = 5,
			["tilewidth"] = 32,
			["border"] = "Interface\\AddOns\\MazzleUI\\Art\\MazzleUIChatBoxBorder",
			["inset4"] = 5,
			["background"] = "Interface\\AddOns\\MazzleUI\\Art\\MazzleUIChatBoxBackground",
			["inset2"] = 5,
			["tileheight"] = 16,
		},
		["width"] = 390,
	},
	["CastingBarFrame"] = {
		["location"] = {
			["y"] = -72,
			["x"] = 0,
			["point"] = "BOTTOM",
			["frame"] = "MazzleUIArt_TargetCave",
			["to"] = "TOP",
		},
		["strata"] = "MEDIUM",
	},
	["CastingBarFrameFlash"] = {
		["border"] = "Interface\\AddOns\\MazzleUI\\Art\\MazzleUICastingBarFlash",
	},
	["CastingBarFrameBorder"] = {
		["border"] = "Interface\\AddOns\\MazzleUI\\Art\\MazzleUICastingBarBorder",
	},
	["MiniMapBattlefieldFrame"] = {
		["scale"] = 1.02,
		["location"] = {
			["y"] = -15,
			["x"] = -5,
			["to"] = "TOPLEFT",
			["frame"] = "Minimap",
			["point"] = "RIGHT",
		},
	},
	["MiniMapTracking"] = {
		["scale"] = 0.82,
		["location"] = {
			["y"] = -15,
			["x"] = 8,
			["point"] = "LEFT",
			["frame"] = "Minimap",
			["to"] = "TOPRIGHT",
		},
	},
	["TemporaryEnchantFrame"] = {
		["location"] = {
			["y"] = 312.13,
			["x"] = -39,
			["to"] = "BOTTOMLEFT",
			["frame"] = "UIParent",
			["point"] = "BOTTOMLEFT",
		},
	},
	["TempEnchant1"] = {
		["strata"] = "HIGH",
		["location"] = {
			["y"] = 316,
			["x"] = 3,
			["point"] = "BOTTOMLEFT",
			["frame"] = "UIParent",
			["to"] = "BOTTOMLEFT",
		},
	},
	["TempEnchant2"] = {
		["strata"] = "HIGH",
		["location"] = {
			["y"] = 270,
			["x"] = 3,
			["point"] = "BOTTOMLEFT",
			["frame"] = "UIParent",
			["to"] = "BOTTOMLEFT",
		},
	},
	["WorldStateAlwaysUpFrame"] = {
		["strata"] = "BACKGROUND",
		["framelevel"] = 1,
		["location"] = {
			["y"] = 175,
			["x"] = 55,
			["point"] = "LEFT",
			["frame"] = "UIParent",
			["to"] = "LEFT",
		},
	},
----------------------------------------------------
	["QuestTimerFrame"] = {
		["parent"] = "UIParent",
		["location"] = {
			["y"] = -74,
			["x"] = 0,
			["to"] = "TOP",
			["frame"] = "UIParent",
			["point"] = "TOP",
		},
	},
}

MazzleUI.FrameInfo_Login[2] = {
	["ChatFrame1ScrollDownReminder"] = {
		["height"] = 32,
		["location"] = {
			["y"] = -10,
			["x"] = 21,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "ChatFrame1",
			["point"] = "BOTTOMRIGHT",
		},
		["width"] = 32,
		["post"] = function() ChatFrame1ScrollDownReminderFlash:SetAllPoints(); end,
	},
	["ChatFrame2ScrollDownReminder"] = {
		["height"] = 32,
		["location"] = {
			["y"] = -10,
			["x"] = 21,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "ChatFrame1",
			["point"] = "BOTTOMRIGHT",
		},
		["width"] = 32,
		["post"] = function() ChatFrame2ScrollDownReminderFlash:SetAllPoints(); end,
	},
	["ChatFrame3ScrollDownReminder"] = {
		["height"] = 32,
		["location"] = {
			["y"] = -10,
			["x"] = 21,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "ChatFrame1",
			["point"] = "BOTTOMRIGHT",
		},
		["width"] = 32,
		["post"] = function() ChatFrame3ScrollDownReminderFlash:SetAllPoints(); end,
	},
	["ChatFrame4ScrollDownReminder"] = {
		["height"] = 32,
		["location"] = {
			["y"] = -10,
			["x"] = 21,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "ChatFrame1",
			["point"] = "BOTTOMRIGHT",
		},
		["width"] = 32,
		["post"] = function() ChatFrame4ScrollDownReminderFlash:SetAllPoints(); end,
	},
	["ChatFrame5ScrollDownReminder"] = {
		["height"] = 32,
		["location"] = {
			["y"] = -10,
			["x"] = 21,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "ChatFrame1",
			["point"] = "BOTTOMRIGHT",
		},
		["width"] = 32,
		["post"] = function() ChatFrame5ScrollDownReminderFlash:SetAllPoints(); end,
	},
	["ChatFrame6ScrollDownReminder"] = {
		["height"] = 16,
		["location"] = {
			["y"] = -8,
			["x"] = 4,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "ChatFrame6",
			["point"] = "BOTTOMRIGHT",
		},
		["width"] = 16,
		["post"] = function() ChatFrame6ScrollDownReminderFlash:SetAllPoints(); end,
	},
	["ChatFrame7ScrollDownReminder"] = {
		["height"] = 16,
		["location"] = {
			["y"] = -8,
			["x"] = 4,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "ChatFrame7",
			["point"] = "BOTTOMRIGHT",
		},
		["width"] = 16,
		["post"] = function() ChatFrame7ScrollDownReminderFlash:SetAllPoints(); end,
	},
	["MazzleHUD_Target_RangeText"] = {
		["parent"] = "DUF_TargetFrame",
		["location"] = {
			["y"] = 0,
			["x"] = 0,
			["to"] = "TOP",
			["frame"] = "DUF_TargetFrame_TextBox_10",
			["point"] = "BOTTOM",
		},
		["post"] = function() if (UnitExists("target")) then MazzleUI:Handle_TargetChange(); end; end,
	},
}
MazzleUI.FrameInfo_Minimap = {
	["SmartBuff_MiniMapButton"] = {
		["location"] = {
			["x"] = 2,
			["y"] = 0,
			["point"] = "RIGHT",
			["frame"] = "MazzleUI_RecapButton",
			["to"] = "LEFT",
		},
	},
	["MiniMapMeetingStoneFrame"] = {
		["location"] = {
			["y"] = 0,
			["x"] = 3,
			["point"] = "RIGHT",
			["frame"] = "MazzleUI_RecapButton",
			["to"] = "LEFT",
		},
	},
	["MazzleUI_RecapButton"] = {
		["location"] = {
			["y"] = 0,
			["x"] = 0,
			["to"] = "LEFT",
			["frame"] = "MazzleUI_EfficiencyButton",
			["point"] = "RIGHT",
		},
	},
	["MazzleUI_EfficiencyButton"] = {
		["location"] = {
			["y"] = 0,
			["x"] = 0,
			["to"] = "LEFT",
			["frame"] = "MazzleUI_OptionsButton",
			["point"] = "RIGHT",
		},
	},
	["MazzleUI_OptionsButton"] = {
		["location"] = {
			["y"] = 183,
			["x"] = -14,
			["point"] = "BOTTOMRIGHT",
			["frame"] = "UIParent",
			["to"] = "BOTTOMRIGHT",
		},
	},
--	["ShardAceFire"] = {
--		["location"] = {
--			["y"] = 0,
--			["x"] = -2,
--			["point"] = "RIGHT",
--			["frame"] = "MazzleUI_RecapButton",
--			["to"] = "LEFT",
--		},
--	},
	["ShardAceCount"] = {
		["location"] = {
			["y"] = 0,
			["x"] = -2,
			["point"] = "RIGHT",
			["frame"] = "ShardAceHealth",
			["to"] = "LEFT",
		},
	},
	["ShardAceSoul"] = {
		["location"] = {
			["y"] = 0,
			["x"] = -2,
			["point"] = "RIGHT",
			["frame"] = "ShardAceFire",
			["to"] = "LEFT",
		},
	},
	["ShardAceSpell"] = {
		["location"] = {
			["y"] = 0,
			["x"] = -2,
			["point"] = "RIGHT",
			["frame"] = "MazzleUI_OptionsButton",
			["to"] = "LEFT",
		},
	},
	["ShardAceHealth"] = {
		["location"] = {
			["y"] = 0,
			["x"] = -2,
			["point"] = "RIGHT",
			["frame"] = "ShardAceSoul",
			["to"] = "LEFT",
		},
	},
	["PoisonerMinimapButton"] = {
		["scale"] = 1.062,
		["location"] = {
			["y"] = 0,
			["x"] = 2,
			["point"] = "RIGHT",
			["frame"] = "MazzleUI_OptionsButton",
			["to"] = "LEFT",
		},
	},
}