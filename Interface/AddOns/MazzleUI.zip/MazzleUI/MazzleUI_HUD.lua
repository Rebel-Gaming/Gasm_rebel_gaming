function MazzleUI:ShowHUDNumbers()
    self.HUD.player.healthText.textString:Show()
    self.HUD.player.manaText.textString:Show()
    self.HUD.target.healthText.textString:Show()
    self.HUD.target.manaText.textString:Show()
    self.HUD.target.rangeText.textString:Show()
    if (DUF_Settings and DUF_INDEX) then
        DUF_Settings[DUF_INDEX].target.TextBox[10].alpha = MazzleUI_Settings.HUD.Transparency_ToT
        DUF_TargetFrame_TextBox_10:SetAlpha(MazzleUI_Settings.HUD.Transparency_ToT)
    end
end

function MazzleUI:HideHUDNumbers()
    self.HUD.player.healthText.textString:Hide()
    self.HUD.player.manaText.textString:Hide()
    self.HUD.target.healthText.textString:Hide()
    self.HUD.target.manaText.textString:Hide()
    self.HUD.target.rangeText.textString:Hide()
    if (DUF_Settings and DUF_INDEX) then
        DUF_Settings[DUF_INDEX].target.TextBox[10].alpha = 0
        DUF_TargetFrame_TextBox_10:SetAlpha(0)
    end
end

function MazzleUI:ThinHUD(fg, bg)
    self.HUD.player.background:SetAlpha(bg)
    self.HUD.player.health:SetAlpha(fg)
    self.HUD.player.mana:SetAlpha(fg)
    self.HUD.target.background:SetAlpha(bg)
    self.HUD.target.health:SetAlpha(fg)
    self.HUD.target.mana:SetAlpha(fg)
end

function MazzleUI:ShowHUD()
    self.HUD.player.background:Show()
    self.HUD.player.health:Show()
    self.HUD.player.mana:Show()
    self.HUD.target.background:Show()
    self.HUD.target.health:Show()
    self.HUD.target.mana:Show()
    self.HUD.visible = true;
end

function MazzleUI:HideHUD()
    self.HUD.player.background:Hide()
    self.HUD.player.health:Hide()
    self.HUD.player.mana:Hide()
    self.HUD.target.background:Hide()
    self.HUD.target.health:Hide()
    self.HUD.target.mana:Hide()
    self.HUD.visible = false;
end

function MazzleUI:InstantiateHUDSettings()
    --self:Print("Instantiating HUD Settings")
    if (MazzleUI_Settings.HUD.UseHUD) then
        if (MazzleUI_Settings.HUD.Transparency_OOC > 0) then
            self:ShowHUDNumbers()
            self:HUD_PlayerHealthEvent()
            self:HUD_TargetHealthEvent()
            self:HUD_PlayerManaEvent()
            self:HUD_TargetManaEvent()
        else
            self:HideHUDNumbers()
        end
        self:ShowHUD()
        if (UnitAffectingCombat("player")) then
            self:Handle_PlayerEnterCombat()
        else
            self:Handle_PlayerLeaveCombat()
        end
        self:RegisterHUDEvents()
    else
        self:UnRegisterHUDEvents()
        self:HideHUDNumbers()
        self:HideHUD()
    end
    self:ScheduleLeaveCombatAction(function() DUF_Initialize_AllFrames() end);    
    self:ScheduleLeaveCombatAction(function() DUF_Main_UpdatePartyMembers() end);
end

function MazzleUI:InitHUD()
    if (Mazzifier_Progress == 2) then
        if (DUF_INITIALIZED and DUF_Settings and DUF_INDEX) then
            MazzleUI:InstantiateHUDSettings()
        else
        	MazzleUI:ScheduleEvent(MazzleUI.InitHUD, 1, self)
        end
    end
end

function MazzleUI:HUD_PlayerHealthEvent()
    local p, health, maxHealth = 0, UnitHealth("player"), UnitHealthMax("player")
    if (maxHealth == 0) then p = 0.001; else p = (health/maxHealth); end
    if p == 0 then p = 0.001; end;
    local h = 256 * p;
    self.HUD.player.health.tex:SetHeight(h)
    self.HUD.player.health.tex:SetTexCoord(0,1,1-p,1)
    if (MazzleUI_Settings.HUD.SelfFormat) then
         self.HUD.player.healthText.textString:SetText(health)
    else self.HUD.player.healthText.textString:SetText(math.floor(100*p).."%"); end;
end

function MazzleUI:HUD_TargetHealthEvent()
    local p, health, maxHealth = 0, UnitHealth("target"), UnitHealthMax("target")
    if MobHealth3 then
		health, maxHealth, _ = MobHealth3:GetUnitHealth("target", health, maxHealth)
	end
    if (maxHealth == 0) then p = 0.001 else p = (health/maxHealth); end
    if p == 0 then p = 0.001; end;
    local h = 256 * p;
    self.HUD.target.health.tex:SetHeight(h)
    self.HUD.target.health.tex:SetTexCoord(1,0,1-p,1)
    if (MazzleUI_Settings.HUD.TargetFormat) then
         self.HUD.target.healthText.textString:SetText(health)
    elseif (maxHealth>0) then self.HUD.target.healthText.textString:SetText(math.floor(100*p).."%"); 
    else self.HUD.target.healthText.textString:SetText(""); end;
end

function MazzleUI:HUD_PlayerManaEvent()
    local p, mana, maxMana = 0, UnitMana("player"), UnitManaMax("player")
    if (maxMana == 0) then p = 0 else p = (.453125 + (.546875 * (mana/maxMana))); end
    local h = 256 * p;
    self.HUD.player.mana.tex:SetHeight(h)
    self.HUD.player.mana.tex:SetTexCoord(0,1,1-p,1)
    if (MazzleUI_Settings.HUD.SelfFormat) then
         self.HUD.player.manaText.textString:SetText(mana)
    elseif (mana>0) then self.HUD.player.manaText.textString:SetText(math.floor(100*(mana/maxMana)).."%"); 
    else self.HUD.player.manaText.textString:SetText(""); end;
end

function MazzleUI:HUD_TargetManaEvent()
    local p, mana, maxMana = 0, UnitMana("target"), UnitManaMax("target")
    if (maxMana == 0) then p = 0 else p = (.453125 + (.546875 * (mana/maxMana))); end
    local h = 256 * p;
    self.HUD.target.mana.tex:SetHeight(h)
    self.HUD.target.mana.tex:SetTexCoord(1,0,1-p,1)
    if (MazzleUI_Settings.HUD.TargetFormat) then
         self.HUD.target.manaText.textString:SetText(mana)
    elseif (mana>0) then self.HUD.target.manaText.textString:SetText(math.floor(100*(mana/maxMana)).."%");
    else self.HUD.target.manaText.textString:SetText(""); end;
end

