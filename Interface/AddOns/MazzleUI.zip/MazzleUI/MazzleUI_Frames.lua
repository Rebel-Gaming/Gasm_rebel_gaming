-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

-- Frames that don't exist when Mazzifying:  oraResurrection, BattlefieldMinimapTab, XRS

function MazzleUI:LoadSkin(skinName)
    local name, title, notes, enabled, loadable, reason, security
    name, title, notes, enabled, loadable, reason, security = GetAddOnInfo(skinName or "")
    if (reason == "MISSING" ) then
        if (skinName ~= "") then self:Print("Cannot find your chosen MazzleUI skin!  Attempting to load default skin."); end;
        name, title, notes, enabled, loadable, reason, security = GetAddOnInfo("MazzleUI_Default_Skin")
        if (reason == "MISSING" ) then
            self:Print("Cannot find default MazzleUI skin!  Make sure MazzleUI_Settings directory exists in your add-ons folder.  Exiting.")
            return false;
        else
            LoadAddOn("MazzleUI_Default_Skin")
        end
    else
        LoadAddOn(MazzleUI_Settings.Skin)
    end
    MazzleUI:InitializeSkin()
    MazzleUI.FrameInfo_Login[1].ChatFrameEditBox.texture.border = MazzleUI_Status.skin.art.chatborder
    MazzleUI.FrameInfo_Login[1].CastingBarFrameBorder.border = MazzleUI_Status.skin.art.castborder
    return true
end

function MazzleUI:CreateViewport(bottom)
    -- Based on cr_Viewport post in the Ace forums http://www.wowace.com/forums/index.php?topic=2056.0

    self.ViewportOverlay = WorldFrame:CreateTexture(nil, "BACKGROUND")
    self.ViewportOverlay:SetTexture(0, 0, 0, 1)
    self.ViewportOverlay:SetPoint("TOPLEFT", UIParent, "TOPLEFT", -1, 1)
    self.ViewportOverlay:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", 1, -1)
    
    local currentXResolution, currentYResolution = self:GetCurrentResolution(GetScreenResolutions())
    bottom = (bottom*(currentYResolution/1200))
    WorldFrame:SetPoint("TOPLEFT", 0, 0)
    WorldFrame:SetPoint("BOTTOMRIGHT", 0, (bottom * (768 / currentYResolution)))

end

local function HIE(f) local tf = getglobal(f); if (tf) then tf:Hide(); end; end;
function MazzleUI:Frames_HideUnnecessary()
    -- Chatframe oddities with locked frames
    HIE("ChatFrame1ResizeBottom")
    HIE("ChatFrame1ResizeBottomLeft")
    HIE("ChatFrame1ResizeBottomRight")
    HIE("ChatFrame1ResizeLeft")
    HIE("ChatFrame1ResizeRight")
    HIE("ChatFrame1ResizeTop")
    HIE("ChatFrame1ResizeTopLeft")
    HIE("ChatFrame1ResizeTopRight")
    -- Minimap frames
    HIE("GameTimeFrame")
    HIE("MinimapBorderTop")
    HIE("MiniMapMailFrame")
    HIE("MinimapToggleButton")
    --HIE("MiniMapTrackingFrame")
    HIE("MiniMapWorldMapButton")
    HIE("MinimapZoneTextButton")
    HIE("MinimapZoomIn")
    HIE("MinimapZoomOut")
    HIE("MiniMapVoiceChatFrame")
    -- Add-On buttons
    HIE("SW_IconFrame_Button")
    HIE("ItemSync_CountFrame")
    HIE("ShardAceFire")
end

function MazzleUI:Frames_HideUnnecessary_Delayed()
    HIE("ShardAceFire")
end

function MazzleUI:Frames_ConfigureMinimap()
    Minimap:SetParent("UIParent")
    Minimap:SetMaskTexture("Interface\\AddOns\\MazzleUI\\Art\\MazzleUIMinimapMask")
	MinimapBorder:SetTexture(MazzleUI_Status.skin.art.mapborder);
	MinimapBorderTop:SetTexture(MazzleUI_Status.skin.art.mapborder);
	MinimapNorthTag:Hide()
    Minimap:SetWidth(129)
    Minimap:SetHeight(128)
    Minimap:ClearAllPoints()
	Minimap:SetPoint("BOTTOM", "UIParent", "BOTTOM", 0, 9);
    Minimap:SetFrameStrata("LOW")
    MinimapCluster:ClearAllPoints()
	MinimapCluster:SetPoint("CENTER", "Minimap", "CENTER", -8, -8);
end

function MazzleUI:MoveAndUserPlace(frameName, anchorFrame, sourcePoint, targetPoint, x, y)
    theFrame = getglobal(frameName)
    if (theFrame and getglobal(anchorFrame)) then
        theFrame:SetMovable(true)
        theFrame:ClearAllPoints()
        theFrame:SetPoint(sourcePoint, anchorFrame, targetPoint, x, y)
        theFrame:SetUserPlaced(true)
    end
end

function MazzleUI:Frame_Modify(theFrame, frameInfo, shouldPlace)
    for property, value in pairs(frameInfo) do
        if ((property == "location") and shouldPlace and getglobal(value.frame)) then 
            theFrame:SetMovable(true)
            theFrame:ClearAllPoints()
            theFrame:SetPoint(value.point, value.frame, value.to, value.x, value.y)
            theFrame:SetUserPlaced(true)
        elseif (property == "height") then theFrame:SetHeight(value)
        elseif (property == "width") then theFrame:SetWidth(value)
        elseif (property == "hide") then theFrame:Hide()
        elseif (property == "parent") then theFrame:SetParent(value)
        elseif (property == "scale") then theFrame:SetScale(value)
        elseif (property == "alpha") then theFrame:SetAlpha(value)
        elseif (property == "strata") then theFrame:SetFrameStrata(value)
        elseif (property == "framelevel") then theFrame:SetFrameLevel(value)
        elseif (property == "backgroundcolor") then theFrame:SetBackdropColor(value.color.r, value.color.g, value.color.b, value.alpha)
        elseif (property == "border") then theFrame:SetTexture(value)
        elseif (property == "bordercolor") then theFrame:SetBackdropBorderColor(value.color.r, value.color.g, value.color.b, value.alpha)
        elseif (property == "texture") then 
            theFrame:SetBackdrop({bgFile = value.background, edgeFile = value.border, tile = nil, 
                                  tileSize = value.tilewidth, edgeSize = value.tileheight, 
                                  insets = { left = value.inset1, right = value.inset2, 
                                  top = value.inset3, bottom = value.inset4 }})
        end
    end
end

function MazzleUI:Frames_ConfigureFrameList(theList)
    theList = theList or {}
    local newPlaceList, numLeft, rcount, circularDependency, referencePoints, theFrame = {}, 0, 0, false, {}, nil
    for frameName, frameInfo in pairs(theList) do
        if (frameInfo.pre) then frameInfo.pre(); end
    end
    for frameName, frameInfo in pairs(theList) do
        theFrame = getglobal(frameName)
        if (theFrame) then
            if (frameInfo.location) then
                newPlaceList[frameName] = frameInfo
                theFrame:ClearAllPoints()
            end
            self:Frame_Modify(theFrame, frameInfo, false)
        else
            --self:Print("Frame ", frameName, " does not exist.  Cannot place.")
        end
    end
    
    for frameName, frameInfo in pairs(newPlaceList) do numLeft = numLeft+1; end;

    while (numLeft > 0) do
        if (circularDependency) then
            self:Print("Error!  Circular dependency in layout. ", numLeft, " not placed.")
            for frameName, frameInfo in pairs(newPlaceList) do
                rcount = rcount + 1
                if (not referencePoints[frameName]) then self:Print(frameName, " did not get placed.")
                else self:Print(frameName, " is placed. ", rcount); end
            end
            return
        end
        circularDependency = true
        for frameName, frameInfo in pairs(newPlaceList) do
            if (((not theList[frameInfo.location.frame]) or referencePoints[frameInfo.location.frame]) and (not referencePoints[frameName])) then
                self:MoveAndUserPlace(frameName, frameInfo.location.frame, frameInfo.location.point, frameInfo.location.to, frameInfo.location.x, frameInfo.location.y)
                referencePoints[frameName] = 1
                circularDependency = false
                numLeft = numLeft -1
            end
        end
    end
    for frameName, frameInfo in pairs(theList) do
        if (frameInfo.post) then frameInfo.post(); end
    end
end

function MazzleUI:CheckExternalAnchors(frameList)
    local u = {UIParent=1, ChatFrame1=1, ChatFrame6=1, ChatFrame7=1, Minimap=1}
    for frameName, frameInfo in pairs(frameList) do
        if (frameInfo.location and (not u[frameInfo.location.frame]) and (not frameList[frameInfo.location.frame])) then
            self:Print("Frame ", frameName, "requires an external frame: ", frameInfo.location.frame)
        end
    end
end

function MazzleUI:CheckFrameLists()
    self:Print("Checking user place list...")
    MazzleUI:CheckExternalAnchors(MazzleUI.FrameInfo_Placed[1])
    MazzleUI:CheckExternalAnchors(MazzleUI.FrameInfo_Placed[2])
    self:Print("Checking login list...")
    MazzleUI:CheckExternalAnchors(MazzleUI.FrameInfo_Login)
end

function MazzleUI:SetWHP(frame, width, height, p1, relative, p2, x, y)
	if width then frame:SetWidth(width); end
	if height then frame:SetHeight(height); end
	if (p1) then
		frame:ClearAllPoints()
		frame:SetPoint(p1 or "CENTER", relative or "UIParent", p2 or "CENTER", x or 0, y or 0)
	end
end

function MazzleUI:MakeFrameInert(f)
    f:SetFrameStrata("BACKGROUND")
    f:EnableMouse(false)
    f:EnableMouseWheel(false)
    f:SetMovable(false)
end

function MazzleUI:CreateInertFrame(frameName, textureName, x, y)
    local f = CreateFrame("Frame", frameName, UIParent)
    self:MakeFrameInert(f)
    f.tex = f:CreateTexture("$parentArt","BACKGROUND")
    if (textureName) then
        f.tex:SetTexture(textureName)
        self:SetWHP(f.tex, (x or 512), (y or 256))
    	f.tex:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0);
    	f.tex:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0);
    end
    return f
end
function MazzleUI:LinkTargetCave()
    if (DUF_TargetFrame) then 
        self.panelTextures.cave:SetParent(DUF_TargetFrame); 
        self.panelTextures.cave:SetFrameLevel(4)
    end;
end
function MazzleUI:CreatePanel(theAspect)
    if (not self.panelTextures) then
        local midpanelWidth = {319, 377, 558}
        local caveY = {149, 149, 143}
        self.panelTextures = {}
        self.panelTextures.l  = self:CreateInertFrame("MazzleUIArt_Left", MazzleUI_Status.skin.art.l)
        self.panelTextures.ml = self:CreateInertFrame("MazzleUIArt_MidLeft", MazzleUI_Status.skin.art.ml)
        self.panelTextures.mr = self:CreateInertFrame("MazzleUIArt_MidRight", MazzleUI_Status.skin.art.mr)
        self.panelTextures.r  = self:CreateInertFrame("MazzleUIArt_Right", MazzleUI_Status.skin.art.r)
        self.panelTextures.cave  = self:CreateInertFrame("MazzleUIArt_TargetCave", MazzleUI_Status.skin.art.cave)
        self:SetWHP(self.panelTextures.l, 470, 238, "BOTTOMLEFT", "UIParent", "BOTTOMLEFT")
        self:SetWHP(self.panelTextures.ml, midpanelWidth[theAspect], 238, "BOTTOMLEFT", self.panelTextures.l, "BOTTOMRIGHT")
        self:SetWHP(self.panelTextures.mr, midpanelWidth[theAspect], 238, "BOTTOMLEFT", self.panelTextures.ml, "BOTTOMRIGHT")
        self:SetWHP(self.panelTextures.r, 470, 238, "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT")
        self:SetWHP(self.panelTextures.cave, 256, 256, "BOTTOM", "UIParent", "BOTTOM", 0, caveY[theAspect])
        self.panelTextures.cave:SetScale(0.81)
        self.panelTextures.l:SetFrameLevel(2)
        self.panelTextures.r:SetFrameLevel(2)
        self:LinkTargetCave()
    end
end

function MazzleUI:CreateHUD(dontCreate)
    if (dontCreate or (not self.HUD)) then
        local hudBaseY = {63, 40, 40}
        if (not dontCreate) then
            self.HUD = {player = {}, target = {}}
            self.HUD.player.background = self:CreateInertFrame("MazzleHUD_Player_BG", "Interface\\AddOns\\MazzleUI\\Art\\HBL", 128, 256)
            self.HUD.player.health = self:CreateInertFrame("MazzleHUD_Player_Health", "Interface\\AddOns\\MazzleUI\\Art\\HL", 128, 256)
            self.HUD.player.mana = self:CreateInertFrame("MazzleHUD_Player_Mana", "Interface\\AddOns\\MazzleUI\\Art\\ML", 64, 256)
            self.HUD.player.healthText = self:CreateInertFrame("MazzleHUD_Player_HealthText")
            self.HUD.player.manaText = self:CreateInertFrame("MazzleHUD_Player_ManaText")
            self.HUD.target.background = self:CreateInertFrame("MazzleHUD_Target_BG", "Interface\\AddOns\\MazzleUI\\Art\\HBL", 128, 256)
            self.HUD.target.health = self:CreateInertFrame("MazzleHUD_Target_Health", "Interface\\AddOns\\MazzleUI\\Art\\HL", 128, 256)
            self.HUD.target.mana = self:CreateInertFrame("MazzleHUD_Target_Mana", "Interface\\AddOns\\MazzleUI\\Art\\ML", 64, 256)
            self.HUD.target.healthText = self:CreateInertFrame("MazzleHUD_Target_HealthText")
            self.HUD.target.manaText = self:CreateInertFrame("MazzleHUD_Target_ManaText")
            self.HUD.target.rangeText = self:CreateInertFrame("MazzleHUD_Target_RangeText")
        end
        self.HUD.player.background:SetScale(MazzleUI_Settings.HUD.Scale)
        self.HUD.player.health:SetScale(MazzleUI_Settings.HUD.Scale)
        self.HUD.player.mana:SetScale(MazzleUI_Settings.HUD.Scale)
        self.HUD.player.healthText:SetScale(MazzleUI_Settings.HUD.Scale)
        self.HUD.player.manaText:SetScale(MazzleUI_Settings.HUD.Scale)
        
        self:SetWHP(self.HUD.player.background, 128, 256, "CENTER", "UIParent", "CENTER", (-1*(MazzleUI_Settings.HUD.separation/2)), (hudBaseY[MazzleUI_LastAspect] + MazzleUI_Settings.HUD.YAdjust))
        self:SetWHP(self.HUD.player.health, 128, 256, "CENTER", self.HUD.player.background, "CENTER")
        self:SetWHP(self.HUD.player.mana, 64, 256, "BOTTOM", self.HUD.player.background, "BOTTOM", -6, -73)
        self:SetWHP(self.HUD.player.healthText, 128, 256, "CENTER", self.HUD.player.background, "CENTER")
        self:SetWHP(self.HUD.player.manaText, 64, 256, "BOTTOM", self.HUD.player.background, "BOTTOM", -6, -73)
        self.HUD.player.health:SetFrameLevel(2)
        self.HUD.player.mana:SetFrameLevel(2)
        self.HUD.player.healthText:SetFrameLevel(3)
        self.HUD.player.manaText:SetFrameLevel(3)
    
        self.HUD.target.background:SetScale(MazzleUI_Settings.HUD.Scale)
        self.HUD.target.health:SetScale(MazzleUI_Settings.HUD.Scale)
        self.HUD.target.mana:SetScale(MazzleUI_Settings.HUD.Scale)
        self.HUD.target.healthText:SetScale(MazzleUI_Settings.HUD.Scale)
        self.HUD.target.manaText:SetScale(MazzleUI_Settings.HUD.Scale)
        self.HUD.target.rangeText:SetScale(MazzleUI_Settings.HUD.Scale)
        self:SetWHP(self.HUD.target.background, 128, 256, "CENTER", "UIParent", "CENTER", (MazzleUI_Settings.HUD.separation/2), (hudBaseY[MazzleUI_LastAspect] + MazzleUI_Settings.HUD.YAdjust))
        self:SetWHP(self.HUD.target.health, 128, 256, "CENTER", self.HUD.target.background, "CENTER")
        self:SetWHP(self.HUD.target.mana, 64, 256, "BOTTOM", self.HUD.target.background, "BOTTOM", 6, -73)
        self:SetWHP(self.HUD.target.healthText, 128, 256, "CENTER", self.HUD.target.background, "CENTER")
        self:SetWHP(self.HUD.target.manaText, 64, 256, "BOTTOM", self.HUD.target.background, "BOTTOM", 6, -73)
        if (getglobal("DUF_TargetFrame_TextBox_10")) then
            self:SetWHP(self.HUD.target.rangeText, 256, 24, "BOTTOM", "DUF_TargetFrame_TextBox_10", "TOP", 0, 0)
        else
            self:SetWHP(self.HUD.target.rangeText, 256, 24, "CENTER", UIParent, "CENTER", 0, -100)
        end
        self.HUD.target.health:SetFrameLevel(2)
        self.HUD.target.mana:SetFrameLevel(2)
        self.HUD.target.healthText:SetFrameLevel(3)
        self.HUD.target.manaText:SetFrameLevel(3)

        if (not dontCreate) then
        
            self.HUD.player.health.tex:SetTexCoordModifiesRect(true)
            self.HUD.player.background.tex:SetTexCoordModifiesRect(true)
            self.HUD.player.mana.tex:SetTexCoordModifiesRect(true)
            self.HUD.target.health.tex:SetTexCoordModifiesRect(true)
            self.HUD.target.background.tex:SetTexCoordModifiesRect(true)
            self.HUD.target.mana.tex:SetTexCoordModifiesRect(true)
        
            self.HUD.target.background.tex:SetTexCoord(1, 0, 0, 1)
            self.HUD.target.health.tex:SetTexCoord(1, 0, 0, 1)
            self.HUD.target.mana.tex:SetTexCoord(1, 0, 0, 1)
        
            self.HUD.player.health.tex:SetVertexColor(1, 0, 0); 
            self.HUD.player.background.tex:SetVertexColor(1, 1, 1); 
            self.HUD.player.mana.tex:SetVertexColor(1, 1, 1); 
            self.HUD.target.health.tex:SetVertexColor(1, 0, 1); 
            self.HUD.target.background.tex:SetVertexColor(1, 1, 1); 
            self.HUD.target.mana.tex:SetVertexColor(1, 1, 1); 
        
        	self.HUD.player.healthText.textString = self.HUD.player.healthText:CreateFontString("MazzleHUD_Player_HealthText", "OVERLAY");
        	self.HUD.player.healthText.textString:SetFontObject(GameFontNormal);
        	self.HUD.player.healthText.textString:SetPoint("BOTTOM", self.HUD.player.healthText, "BOTTOM", 7, 26);
            self.HUD.player.healthText.textString:SetFont("Fonts\\FRIZQT__.TTF", 14);
            self.HUD.player.healthText.textString:SetTextColor(1, 1, 1)
        
        	self.HUD.player.manaText.textString = self.HUD.player.manaText:CreateFontString("MazzleHUD_Player_ManaText", "OVERLAY");
        	self.HUD.player.manaText.textString:SetFontObject(GameFontNormal);
        	self.HUD.player.manaText.textString:SetPoint("CENTER", self.HUD.player.manaText, "CENTER", -15, 54);
            self.HUD.player.manaText.textString:SetFont("Fonts\\FRIZQT__.TTF", 12);
            self.HUD.player.manaText.textString:SetTextColor(1, 1, 1)
        
        	self.HUD.target.healthText.textString = self.HUD.target.healthText:CreateFontString("MazzleHUD_Target_HealthText", "OVERLAY");
        	self.HUD.target.healthText.textString:SetFontObject(GameFontNormal);
        	self.HUD.target.healthText.textString:SetPoint("BOTTOM", self.HUD.target.healthText, "BOTTOM", -7, 26);
            self.HUD.target.healthText.textString:SetFont("Fonts\\FRIZQT__.TTF", 14);
            self.HUD.target.healthText.textString:SetTextColor(1, 1, 1)
        
        	self.HUD.target.manaText.textString = self.HUD.target.manaText:CreateFontString("MazzleHUD_Target_ManaText", "OVERLAY");
        	self.HUD.target.manaText.textString:SetFontObject(GameFontNormal);
        	self.HUD.target.manaText.textString:SetPoint("CENTER", self.HUD.target.manaText, "CENTER", 15, 54);
            self.HUD.target.manaText.textString:SetFont("Fonts\\FRIZQT__.TTF", 12);
            self.HUD.target.manaText.textString:SetTextColor(1, 1, 1)

        	self.HUD.target.rangeText.textString = self.HUD.target.manaText:CreateFontString("MazzleHUD_Target_RangeText", "OVERLAY");
        	self.HUD.target.rangeText.textString:SetFontObject(GameFontNormal);
        	self.HUD.target.rangeText.textString:SetPoint("BOTTOM", self.HUD.target.rangeText, "BOTTOM", 0, 0);
            self.HUD.target.rangeText.textString:SetFont("Fonts\\FRIZQT__.TTF", 14);
            self.HUD.target.rangeText.textString:SetTextColor(1, 1, 1)
        end
    end
end

function MazzleUI:CreateHotSpot(frameName, id, p1, relative, p2, x, y, width, height)
    local f = CreateFrame("Button", frameName, UIParent)
    f:SetID(id)
    f:EnableMouse(true)
    f:SetFrameStrata("HIGH")
	f:RegisterForClicks("LeftButtonUp")
	f:SetScript("OnEnter", function() MazzleUI:HotSpot_Tooltip_Handle(id, f); end)
	f:SetScript("OnClick", function(theButton, side) MazzleUI:HotSpot_Click_Handle(id, theButton, side); end)
	f:SetScript("OnLeave", function() GameTooltip:Hide(); end)
	self:SetWHP(f, (width or 25), (height or 25), p1, relative, p2, x, y)
	return f
end

function MazzleUI:ShowTooltip(owner, toolText)
    GameTooltip:SetOwner(owner,"ANCHOR_CURSOR")
	GameTooltip:AddLine(toolText)
    GameTooltip:Show()
end

function MazzleUI:CreateTargetButtons()
    if (not self.Buttons) then
        self.Buttons = {}
        
        if (RecapFrame) then
            self.Buttons.Recap = CreateFrame("Button", "MazzleUI_RecapButton", UIParent, "MazzleUIButtonTemplate")
            MazzleUI_RecapButton_Icon:SetTexture("Interface\\AddOns\\MazzleUI\\Art\\MazzleUI_RecapOn")
            self.Buttons.Recap:SetID(1)
        end
        
        self.Buttons.Efficiency = CreateFrame("Button", "MazzleUI_EfficiencyButton", UIParent, "MazzleUIButtonTemplate")
        MazzleUI_EfficiencyButton_Icon:SetTexture("Interface\\AddOns\\MazzleUI\\Art\\MazzleUI_EfficiencyOff")
        self.Buttons.Efficiency:SetID(2)
        self.Buttons.Options = CreateFrame("Button", "MazzleUI_OptionsButton", UIParent, "MazzleUIButtonTemplate")
        MazzleUI_OptionsButton_Icon:SetTexture("Interface\\AddOns\\MazzleUI\\Art\\MazzleUI_Options")
        self.Buttons.Options:SetID(10)

        self.Buttons.Follow = CreateFrame("Button", "MazzleUI_Follow_Button", MazzleUIArt_TargetCave, "MazzleUITargetButtonTemplate")
        MazzleUI_Follow_Button_Icon:SetTexture("Interface\\Icons\\Ability_Spy")
    	self.Buttons.Follow:SetAlpha(0.8)
    	self.Buttons.Follow:SetScript("OnClick", function() MazzleUI:HandleTargetButton("Follow"); end)
    	self.Buttons.Follow:SetScript("OnEnter", function() MazzleUI:ShowTooltip(MazzleUI_Follow_Button, "Follow"); end)
    	--self:SetWHP(self.Buttons.Follow, nil, nil, "BOTTOMLEFT", "MazzleUIArt_TargetCave", "BOTTOMLEFT", 26, 24)
    	self:SetWHP(self.Buttons.Follow, nil, nil, "BOTTOMLEFT", "MazzleUIArt_TargetCave", "BOTTOMLEFT", 27, 24)

        self.Buttons.Inspect = CreateFrame("Button", "MazzleUI_Inspect_Button", MazzleUIArt_TargetCave, "MazzleUITargetButtonTemplate")
        MazzleUI_Inspect_Button_Icon:SetTexture("Interface\\Icons\\Ability_DualWield")
    	self.Buttons.Inspect:SetAlpha(0.8)
    	self.Buttons.Inspect:SetScript("OnClick", function() MazzleUI:HandleTargetButton("Inspect"); end)
    	self.Buttons.Inspect:SetScript("OnEnter", function() MazzleUI:ShowTooltip(MazzleUI_Inspect_Button, "Inspect"); end)
--    	self:SetWHP(self.Buttons.Inspect, nil, nil, "TOPLEFT", "MazzleUIArt_TargetCave", "TOPLEFT", 39, -76)
    	self:SetWHP(self.Buttons.Inspect, nil, nil, "TOPLEFT", "MazzleUIArt_TargetCave", "TOPLEFT", 40, -77)

        self.Buttons.Whisper = CreateFrame("Button", "MazzleUI_Whisper_Button", MazzleUIArt_TargetCave, "MazzleUITargetButtonTemplate")
        MazzleUI_Whisper_Button_Icon:SetTexture("Interface\\Icons\\INV_Letter_10")
    	self.Buttons.Whisper:SetAlpha(0.8)
    	self.Buttons.Whisper:SetScript("OnClick", function() MazzleUI:HandleTargetButton("Whisper"); end)
    	self.Buttons.Whisper:SetScript("OnEnter", function() MazzleUI:ShowTooltip(MazzleUI_Whisper_Button, "Whisper"); end)
--    	self:SetWHP(self.Buttons.Whisper, nil, nil, "TOPRIGHT", "MazzleUIArt_TargetCave", "TOPRIGHT", -39, -76)
    	self:SetWHP(self.Buttons.Whisper, nil, nil, "TOPRIGHT", "MazzleUIArt_TargetCave", "TOPRIGHT", -39, -77)
        self.Buttons.Whisper:Enable();
        
        self.Buttons.Trade = CreateFrame("Button", "MazzleUI_Trade_Button", MazzleUIArt_TargetCave, "MazzleUITargetButtonTemplate")
        MazzleUI_Trade_Button_Icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_02")
    	self.Buttons.Trade:SetAlpha(0.8)
    	self.Buttons.Trade:SetScript("OnClick", function() MazzleUI:HandleTargetButton("Trade"); end)
    	self.Buttons.Trade:SetScript("OnEnter", function() MazzleUI:ShowTooltip(MazzleUI_Trade_Button, "Trade"); end)
--    	self:SetWHP(self.Buttons.Trade, nil, nil, "BOTTOMRIGHT", "MazzleUIArt_TargetCave", "BOTTOMRIGHT", -26, 24)
    	self:SetWHP(self.Buttons.Trade, nil, nil, "BOTTOMRIGHT", "MazzleUIArt_TargetCave", "BOTTOMRIGHT", -28, 24)
    end
end

function MazzleUI:CreateHotSpots()
    if (not self.HotSpots) then
        self.HotSpots = {}
        self.HotSpots.logo = self:CreateHotSpot("MazzleUI_Logo", 0, "BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -17, 209, 76, 23)
        self.HotSpots.w = self:CreateHotSpot("MazzleUI_Hotspot_w", 1, "BOTTOMLEFT", UIParent, "BOTTOMLEFT", -3, 215)
        self.HotSpots.nw = self:CreateHotSpot("MazzleUI_Hotspot_nw", 2, "BOTTOMLEFT", UIParent, "BOTTOMLEFT", 364, 215)
        --self.HotSpots.ne = self:CreateHotSpot("MazzleUI_Hotspot_ne", 3, "BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -363, 215)
        self.HotSpots.ne = CreateFrame("Button", "MazzleUI_Hotspot_ne", UIParent)
        self.HotSpots.ne:SetID(3)
        self.HotSpots.ne:SetFrameStrata("BACKGROUND")
    	self.HotSpots.ne:SetScript("OnEnter", function() MazzleUI:HotSpot_Tooltip_Handle(3, self.HotSpots.ne); end)
    	self.HotSpots.ne:SetScript("OnLeave", function() GameTooltip:Hide(); end)
        self:SetWHP(self.HotSpots.ne, 40, 40, "BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -358, 210)
        self.HotSpots.e = self:CreateHotSpot("MazzleUI_Hotspot_e", 4, "BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", 4, 215)
        self.HotSpots.sw = self:CreateHotSpot("MazzleUI_Hotspot_sw", 5, "BOTTOMLEFT", UIParent, "BOTTOMLEFT", -4, -5)
        self.HotSpots.minimap = self:CreateHotSpot("MazzleUI_Hotspot_minimap", 6, "BOTTOM", UIParent, "BOTTOM", 0, -5, 60, 18)
        self.HotSpots.se = self:CreateHotSpot("MazzleUI_Hotspot_se", 7, "BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", 4, -4)
    	self.HotSpots.logo:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    	self.HotSpots.se:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    	self.HotSpots.w:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    	self.HotSpots.e:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    	self.HotSpots.logo.textOverlay = self.HotSpots.logo:CreateFontString("MazzleUI_Logo_Text", "OVERLAY");
    	self.HotSpots.logo.textOverlay:SetFontObject(GameFontNormal);
    	self.HotSpots.logo.textOverlay:SetPoint("CENTER", self.HotSpots.logo, "CENTER", 0, 0);
        self.HotSpots.logo.textOverlay:SetFont("Fonts\\FRIZQT__.TTF", 16);
        self.HotSpots.logo.textOverlay:SetTextColor(0.67, 0.67, 0.73)
        self.HotSpots.logo.textOverlay:SetText("MazzleUI")
    end
end

function MazzleUI:CreateCharmButtons()
    if (not self.CharmButtons) then
        self.CharmButtons = {}
        local f
        for i=0, 8, 1 do
            f = CreateFrame("Button", "MazzleUI_CharmButton_"..i, UIParent, "MazzleUICharmButtonTemplate")
            f:SetID(i)
            f:EnableMouse(true)
        	f:RegisterForClicks("LeftButtonUp")
            getglobal("MazzleUI_CharmButton_"..i.."_Icon"):SetTexture("Interface\\AddOns\\MazzleUI\\Art\\charm"..i)
            self.CharmButtons[i] = f
        end
        self:LinkPlaceCharmButtons()
    end
end

function MazzleUI:LinkPlaceCharmButtons()
    if (DUF_TargetFrame) then 
        MazzleUI:SetWHP(self.CharmButtons[3], nil, nil, "BOTTOMLEFT", getglobal("DUF_TargetFrame_HealthBar"), "BOTTOMRIGHT", 11, 12)
        MazzleUI:SetWHP(self.CharmButtons[4], nil, nil, "TOPLEFT", self.CharmButtons[3], "TOPRIGHT", 1, 0)
        MazzleUI:SetWHP(self.CharmButtons[1], nil, nil, "BOTTOMLEFT", self.CharmButtons[3], "TOPLEFT", 0, 1)
        MazzleUI:SetWHP(self.CharmButtons[2], nil, nil, "TOPLEFT", self.CharmButtons[1], "TOPRIGHT", 1, 0)
        MazzleUI:SetWHP(self.CharmButtons[8], nil, nil, "BOTTOMRIGHT", getglobal("DUF_TargetFrame_ManaBar"), "BOTTOMLEFT", -11, 12)
        MazzleUI:SetWHP(self.CharmButtons[7], nil, nil, "TOPRIGHT", self.CharmButtons[8], "TOPLEFT", -1, 0)
        MazzleUI:SetWHP(self.CharmButtons[6], nil, nil, "BOTTOMRIGHT", self.CharmButtons[8], "TOPRIGHT", 0, 1)
        MazzleUI:SetWHP(self.CharmButtons[5], nil, nil, "TOPRIGHT", self.CharmButtons[6], "TOPLEFT", -1, 0)
        MazzleUI:SetWHP(self.CharmButtons[0], nil, nil, "BOTTOMLEFT", self.CharmButtons[5], "TOPLEFT", 8, 1)
    
        for i=0, 8, 1 do
            self.CharmButtons[i]:SetParent(DUF_TargetFrame); 
            self.CharmButtons[i]:Show()
            self.CharmButtons[i]:SetFrameStrata("HIGH")
            self.CharmButtons[i]:SetAlpha(0.5)
        end
        MazzleUI:Handle_LeaderChange()
    end
end

function MazzleUI:ShowCharmIcons()
    if (self.CharmButtons) then
        for i=0, 8, 1 do
            self.CharmButtons[i]:Show()
        end
    end
end

function MazzleUI:HideCharmIcons()
    if (self.CharmButtons) then
        for i=0, 8, 1 do
            self.CharmButtons[i]:Hide()
        end
    end
end

function MazzleUI:CreateToTFrame()
    if (not MazzleUI.TOTFrame) then
        MazzleUI.TOTFrame = CreateFrame("Button", "MazzleUIToTFrame", UIParent, "SecureUnitButtonTemplate")      
    	self:SetWHP(MazzleUI.TOTFrame, 244, 27, "BOTTOM", UIParent,"BOTTOM", 0, 137)
        MazzleUI.TOTFrame:SetFrameStrata("HIGH")
    	MazzleUI.TOTFrame:RegisterForClicks("AnyDown")
        MazzleUI.TOTFrame:SetAttribute("unit", "targettarget")
        MazzleUI.TOTFrame:SetAttribute("*type1", "target")
        MazzleUI.TOTFrame:SetAttribute("*type3", "assist")
        RegisterUnitWatch(MazzleUI.TOTFrame, false)
        ClickCastFrames = ClickCastFrames or {}
        ClickCastFrames[MazzleUI.TOTFrame] = true

    	-- Create string for ToT in HUD
--    	MazzleUI.TOTFrame.HUDText = MazzleUI.TOTFrame:CreateFontString("MazzleUI_HudToT_Text", "OVERLAY");
--    	MazzleUI.TOTFrame.HUDText:SetFontObject(GameFontNormal);
--    	MazzleUI.TOTFrame.HUDText:SetPoint("CENTER", "UIParent", "BOTTOM", 0, MazzleUI.HUD.player.background:GetBottom()-10);
--        MazzleUI.TOTFrame.HUDText:SetFont("Fonts\\FRIZQT__.TTF", 16);
--        MazzleUI.TOTFrame.HUDText:SetTextColor(1, 1, 1)
--        MazzleUI.TOTFrame.HUDText:SetText("MazzleUI")
    end
end

function MazzleUI:CreateContextMenu()
    if (not MazzleContextMenu) then
        -- name, cols, rows, startID, show on create, debug
        MazzleUI.ContextMenu:Create("MazzleContextMenu",nil,nil,nil, not MazzleUI_Settings.HideContext, MazzleUI_Settings.MoveContext)
        MazzleUI.ContextMenu:SetCloseOnClick(MazzleUI_Settings.HideContextOnClick)
	    MazzleUI.ContextMenu:CreateClickButton("BOTTOMRIGHT", UIParent,"BOTTOMRIGHT", -366, 215,25,25)
        MazzleUI.ContextMenu:SetPageUpBinding("MOUSEWHEELUP")
        MazzleUI.ContextMenu:SetPageDownBinding("MOUSEWHEELDOWN")
    --MazzleUI.ContextMenu:OnSetPosition(function(...) y="" for x=1,select("#",...) do y=y..(select(x,...) or "NIL").."," end ChatFrame1:AddMessage("SetPosition Called:"..y) end)
	end;
    MazzleUI.ContextMenu:SetPosition("BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -250, 550)
end

function MazzleUI:CheckUserPlacedList(theList, rl)
    for frameName, frameInfo in pairs(theList) do
        theFrame = getglobal(frameName)
        if (theFrame and frameInfo.layoutCached and (not theFrame:IsUserPlaced())) then
            rl[frameName] = frameInfo
            self:Print("Frame ", frameName, " has lost its position.  Restore default MazzleUI position.")
        end
    end
    return rl
end

function MazzleUI:CheckUserPlaced()
    local flist 
    flist = MazzleUI:CheckUserPlacedList(MazzleUI.FrameInfo_Placed[1], {})
    flist = MazzleUI:CheckUserPlacedList(MazzleUI.FrameInfo_Placed[2], flist)
    if (flist ~= {}) then MazzleUI:Frames_ConfigureFrameList(flist); end;
end


function MazzleUI:UpdateBarPositions()
    if (MazzleUI_Settings.SnapToLayout) then
        local MazzleUI_BarPositions = {}
        local theBar
        for bar, barInfo in pairs(MazzleUI_BarConfig) do
            theBar = getglobal(barInfo.name)
            if (theBar) then
                MazzleUI_BarPositions[barInfo.name] = {location = barInfo.anchor}
            end
        end
        MazzleUI:Frames_ConfigureFrameList(MazzleUI_BarPositions)
        for bar, barInfo in pairs(MazzleUI_BarConfig) do
            theBar = getglobal(barInfo.name)
            if (theBar and theBar.sets) then
                BBar.SavePosition(theBar)
            end
        end
    end
end

function MazzleUI:RegenerateBars(n)
    n = n or BActionBar.GetNumber()
    local lastScale, newBars, newPositions = 1, 0, nil
    MazzleUI:CreateSet("BongosProfiles.MazzleUI", {})
    BongosProfiles.MazzleUI.BongosSets = BongosSets
    BongosProfiles.MazzleUI["BActionSets.g"] = BActionSets.g
    BongosProfiles.MazzleUI["BActionSets.g"].numActionBars = n
    BongosProfiles.MazzleUI["BActionSets.key"] = BActionSets.key
    BongosProfiles.MazzleUI["BActionSets.menu"] = BActionSets.menu
    BongosProfiles.MazzleUI["BActionSets.bags"] = BActionSets.bags
    BongosProfiles.MazzleUI["BActionSets.class"] = BActionSets.class
    BongosProfiles.MazzleUI["BActionSets.pet"] = BActionSets.pet
    for i=1, n, 1 do
        if (BActionSets[i]) then
            BongosProfiles.MazzleUI["BActionSets."..i] = BActionSets[i]
            if (BActionSets[i].scale and (BActionSets[i].scale>0)) then lastScale = BActionSets[i].scale; end;
        else
            BongosProfiles.MazzleUI["BActionSets."..i] = { y=0, x=0, scale=lastScale, vis=1, showEmpty=true, size=1 }
        end
        if ((BongosProfiles.MazzleUI["BActionSets."..i].x == 0) and (BongosProfiles.MazzleUI["BActionSets."..i].y == 0)) then
            newPositions = newPositions or {}
            newBars = newBars + 1
            newPositions["BActionBar"..i] = { location = { frame = "BongosOptions", point = "TOPRIGHT", to = "BOTTOMRIGHT", y = -5, x = (-1*50*newBars)}}
        end
    end
    if (BProfile.ResetOld) then BProfile.ResetOld(); end
    BProfile.Load("MazzleUI", true)
    MazzleUI:Frames_ConfigureFrameList(newPositions)
    BProfile.Delete("MazzleUI", true)
    local theBar
    for i=1, n, 1 do
        theBar = getglobal("BActionBar"..i)
        if (theBar and theBar.sets) then
            BBar.SavePosition(theBar)
        end
    end
    BActionSets_SetShowGrid(globalShowGrid)
    Bongos_SetStickyBars(false)
    MazzleUI:UpdateBarPositions()
    MazzleUI:Execute("/bongos unlock")
end

function MazzleUI:GetActionID(br, p, bn)
    if (bn>(BActionSets[br].size or 0)) then return nil; end;
    if (p>(BActionSets[br].numPages or 1)) then return nil; end;
    local id = 0
    for i=1, br-1, 1 do
        id = id + BActionSets[i].size*(BActionSets[i].numPages or 1)
    end
    id = id + (p-1)*BActionSets[br].size + bn
    return id
end

function MazzleUI:GetActionInfo( id )
    -- Adapted from SimpleActionSets

    local actionType, typeId = GetActionInfo(id);
    if ( actionType == "spell" ) then
        local name, rank = GetSpellName(typeId,"spell");
        rank = self:TruncateRank(rank)
        if (rank) then return (name.."�"..rank); else return name; end;
    elseif ( actionType == "item" ) then
        return ("item�"..GetItemInfo(typeId)..typeId);
    end
    return nil
end

function MazzleUI:GetNumFreeSlots()
    local totalCount, freeCount = 0, 0
    for i=1, (BActionSets.g.numActionBars or 0), 1 do
        for j=1, (BActionSets[i].numPages or 1), 1 do
            totalCount = totalCount + (BActionSets[i].size or 0)
        end
    end
    if (totalCount < 89) then freeCount = 89 - totalCount; end;
    return freeCount
end

function MazzleUI:SetMaxBars()
    local nfs = MazzleUI:GetNumFreeSlots()
    if (BongosOptionsPanelActionBarNumActionBars) then
    	BongosOptionsPanelActionBarNumActionBars:SetMinMaxValues(1, nfs)
    	BongosOptionsPanelActionBarNumActionBarsHigh:SetText(nfs)
    end
end

function MazzleUI:GetMaxPages(barNum)
    local mp = math.floor((MazzleUI:GetNumFreeSlots() + ((BActionSets[barNum].size or 0) * (BActionSets[barNum].numPages or 1)))/(BActionSets[barNum].size or 1))
    if (mp > (BActionSets[barNum].numPages or 1)) then return mp; else return (BActionSets[barNum].numPages or 1); end
end

function MazzleUI:GetMaxBarSize(barNum)
    return ((BActionSets[barNum].size or 0) + math.floor(MazzleUI:GetNumFreeSlots()/(BActionSets[barNum].numPages or 1)))
end

function MazzleUI:GetAllBindings(actionID)
    local tb = getglobal("BActionButton"..actionID)
    local rv = tb and Binder_GetAllBindings(tb, true)
    return rv
end

function MazzleUI:SetAllBindings(actionID, bindingString)
    local tb = getglobal("BActionButton"..actionID)
    if (not bindingString) then
        Binder_Unbind(tb)
    else
        for _,nb in pairs(MazzleUI:Split(bindingString, '[,]+')) do
            Binder_Unbind(tb)
            Binder_SetBinding(tb, nb, true)
        end
    end
end

local actionMapping
local lastID

function MazzleUI:SaveActionMapping(barNum, newNumButtons, newPagesNum)
    ClearCursor();
    actionMapping, lastID = {}, 0
    local cbarSize, cPageSize, content_action, content_binding = 0, 0, nil, nil
    for i=1, BActionSets.g.numActionBars, 1 do
        if (i==barNum) then
            cBarSize = newNumButtons
            cPageSize = (newPagesNum or 1)
        else
            cBarSize = BActionSets[i].size
            cPageSize = (BActionSets[i].numPages or 1)
        end
        for j=1, cPageSize, 1 do
            for k=1, cBarSize, 1 do
                lastID = lastID + 1
                mappedID = MazzleUI:GetActionID(i, j, k)
                if (mappedID) then 
                    content_action = MazzleUI:GetActionInfo(mappedID); 
                    content_binding = MazzleUI:GetAllBindings(mappedID); 
                else 
                    content_action = nil; 
                    content_binding = nil
                end;
                if (mappedID and (content_action or content_binding)) then 
                    actionMapping[lastID] = { action = content_action, binding = content_binding};
                end
            end
        end
    end
end
function MazzleUI:RestoreActionMapping()
    for i=1, lastID, 1 do
        if (actionMapping[i]) then
            content_action = MazzleUI:GetActionInfo(i)
            content_binding = MazzleUI:GetAllBindings(i); 
            if (content_action ~= actionMapping[i].action) then
                MazzleUI:ActionPlace(i, actionMapping[i].action)
            end
            if (content_binding ~= actionMapping[i].binding) then
                MazzleUI:SetAllBindings(i, actionMapping[i].binding)
            end
        else
            PickupAction(i);
            ClearCursor()
        end
    end
end

function MazzleUI:ActionPlace(actionID, theAction)
    -- Same as the Mazzifier version except no handling list of actions, no closed list and no translating (not needed)
	ClearCursor();
	local a = {}
	local actionPlaced, spellID
	if (theAction) then
    	spellID = 0
        if (not string.find(theAction, "�")) then
            spellID = self:GetMaxRank(theAction);
        else
            a = {}
        	for v in string.gmatch( theAction, "(.-)�" ) do if (v == "") then tinsert(a, nil); else tinsert(a, v); end; end;
            if (a[1] == "item") then
    			if (self:PlaceItem(actionID, a[2], a[3], doNotPlace)) then actionPlaced = true; end
            else
                spellID = self:GetMaxRank(a[1], a[2]);
            end
        end
    	if (spellID>0) then
			PickupSpell( spellID, BOOKTYPE_SPELL );
			PlaceAction(actionID);
    	end
	end
	ClearCursor();
	return actionPlaced;
end

