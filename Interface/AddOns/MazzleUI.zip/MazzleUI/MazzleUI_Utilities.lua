-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

function MazzleUI:Execute(theCommand)
	MazzleUI_EditBox:SetText(theCommand);
	local editBox = MazzleUI_EditBox;
	ChatEdit_SendText(editBox);
end

function MazzleUI:StartEditCommand(theCommand)
	ChatFrameEditBox:SetText(theCommand);
    ChatFrameEditBox:Show();
end

function MazzleUI:GetValue(variableName)
	if ( type(variableName) ~= "string" ) then return; end

	local sstart = 2;
	local value;
	local match = strfind(variableName, '.', sstart, true);
	if ( match ) then value = getglobal(strsub(variableName, 0, match-1));
	else return getglobal(variableName); end
		
	while true do
		if (type(value) ~= "table") then return; end
        sstart = match + 1;
		match = strfind(variableName, '.', sstart, true);
		if ( match ) then value = value[strsub(variableName, sstart, match-1)];
		else return value[strsub(variableName, sstart)]; end
   	end
end

function MazzleUI:SetValue( variableName, newValue ) 

	if ( type(variableName) ~= "string" ) then return; end
	local sstart = 2;
	local value;
	local match = strfind(variableName, '.', sstart, true);
	if ( match ) then value = getglobal(strsub(variableName, 0, match-1));
	else setglobal(variableName, newValue); return true; end
		
	while true do
		if (type(value) ~= "table") then return false; end
        sstart = match + 1;
		match = strfind(variableName, '.', sstart, true);
		if ( match ) then value = value[strsub(variableName, sstart, match-1)];
		else value[strsub(variableName, sstart)] = newValue; return true; end
   	end
	return false;
end

function MazzleUI:CreateSet( variableName, newValue)
    self:CreatePath(variableName)
    self:SetValue( variableName, newValue ) 
end

function MazzleUI:CreatePath( variableName ) 

    if ( type(variableName) ~= "string" ) then return; end
    
    local _G = getfenv(0)
    local strfind = strfind; 
    local strsub = strsub;
    local sstart = 2;
    local value,newValue
    
    local match = strfind(variableName, '.', sstart, true);
    if ( match ) then
        value = getglobal(strsub(variableName, 0, match-1));
        if (type(value) == "table") then
        elseif (type(value) == "nil") then _G[strsub(variableName, 0, match-1)] = {}
        else return false; end
    else return true end
    
    while true do
        sstart = match + 1;
        match = strfind(variableName, '.', sstart, true);
        
        if ( match ) then value = self:GetValue(strsub(variableName, 0, match-1));
        else return true; end
        
        if (type(value) == "table") then
        elseif (type(value) == "nil") then
            newValue = self:GetValue(strsub(variableName, 0, sstart-2))
            newValue[strsub(variableName, sstart, match-1)] = self:MakeNestedTable(strsub(variableName, match+1))
            return true
        else return false; end
    end
end

function MazzleUI:MakeNestedTable( variableName ) 

    local returnTable = {}
    local match = strfind(variableName, '.', 2, true);
    if ( match ) then
        local subTable = self:MakeNestedTable(strsub(variableName, match+1))
        if (subTable) then returnTable[strsub(variableName, 0, match-1)] = subTable
        else returnTable[strsub(variableName, 0, match-1)] = {} end
        return returnTable
    end
    return returnTable
end

function MazzleUI:IsAddOnEnabled( addonName )
    local returnVal, reason
    _, _, _, returnVal, _, reason, _ = GetAddOnInfo(addonName)
    if (returnVal and (reason ~= "NOT_DEMAND_LOADED")) then return true; else return false; end;
end

function MazzleUI:Split(str, pat)
    -- Copied from lua wiki
    local t = {}
    local fpat = "(.-)"..pat
    local last_end = 1
    local s,e,cap = string.find(str, fpat, 1)
    while s ~= nil do
        if s~=1 or cap~="" then
            table.insert(t,cap)
        end
        last_end = e+1
        s,e,cap = string.find(str, fpat, last_end)
    end
    if last_end<=string.len(str) then
        cap = string.sub(str,last_end)
        table.insert(t,cap)
    end
    return t
end

function MazzleUI:SplitPath(str)
    return MazzleUI:Split(str,'[\\/]+')
end

function MazzleUI:CloneTable(t)   -- Copied from lua users mailing list faq
    local new = {}             
    local i, v = next(t, nil)
    while i do
        if type(v)=="table" then v=self:CloneTable(v) end
        new[i] = v
        i, v = next(t, i)
    end
    return new
end

function MazzleUI:Return1or0(theBoolean)
    if (theBoolean) then return "1"; else return "0"; end;
end

function MazzleUI:DebugPrint(debugStr, forceLog, debugHeader)
    if MazzleUI_Settings.debugPrint then 
        self:Print(TEXT(debugStr))
    end
    if (MazzleUI_Settings.debugLogOn or forceLog) then 
        table.insert(MazzleUI_DebugLog, debugStr)
    end
end

function MazzleUI:PrintError(...)
	self:DebugPrint(table.concat({...}," "))
end

function MazzleUI:GetCurrentResolution(...)
    -- Copied from CT_Viewport_GetCurrentResolution
	local currRes = select(GetCurrentResolution(), ...);
	if ( currRes ) then
		local useless, useless, x, y = string.find(currRes, "(%d+)x(%d+)");
		if ( x and y ) then
			return tonumber(x), tonumber(y);
		end
	end
	return nil;
end

function MazzleUI:MouseClickEffect()
    -- Idea for following function borrowed from Sprocket.  Implementation changed.
    local x2, y2 = GetCursorPosition();
    x2 = x2 / UIParent:GetScale();
    y2 = y2 / UIParent:GetScale();
    MazzleUI_MouseClick:ClearAllPoints();
    MazzleUI_MouseClick:SetPoint( "CENTER", "UIParent", "BOTTOMLEFT", x2, y2);
    MazzleUI_MouseClick:SetSequence(0);
    MazzleUI_MouseClick:SetSequenceTime(0, 0);
    MazzleUI_MouseClick:Show();
end


function MazzleUI:GetUnitNum(unitType)
    if (unitType == "player") then return 0
    elseif (unitType == "target") then return 1
    elseif (unitType == "party1") then return 2
    elseif (unitType == "party2") then return 3
    elseif (unitType == "party3") then return 4
    elseif (unitType == "party4") then return 5
    elseif (unitType == "partypet1") then return 6
    elseif (unitType == "partypet2") then return 7
    elseif (unitType == "partypet3") then return 8
    elseif (unitType == "partypet4") then return 9
    elseif (unitType == "pet") then return 10 end
end

function MazzleUI:GetAspect()
    local screenX, screenY = self:GetCurrentResolution(GetScreenResolutions())
    local screenRatio = math.floor((screenX/screenY)*10)
    if (screenRatio == 16) then return 3;
    elseif (screenRatio == 12) then return 1;
    else return 2; end 
end

function MazzleUI:MirrorTable(t)
    local rt = {}
    for i,v in pairs(t) do rt[i] = v; rt[v] = i; end
    return rt
end

function MazzleUI:TruncateRank( rank )
	-- truncate ranks to just numerical data
	if ( not rank ) then return; end
	for i in string.gmatch( rank, "%d+" ) do return tonumber(i); end
end

function MazzleUI:GetMaxRank(spell, desiredMax)
	if ( not spell ) then return; end
	local i, max_r, r, max_i = 1, 0, 0, 0;
	local spellName, spellRank = GetSpellName( i, BOOKTYPE_SPELL );
	while spellName do
		if ( spellName == spell ) then
			r = self:TruncateRank(spellRank);
			if (r == desiredMax) then return i; end
			if (r > max_r) then max_r = r; max_i = i; end;
		end
		i = i+1;
		spellName, spellRank = GetSpellName( i, BOOKTYPE_SPELL );
	end
	return max_i;
end

function MazzleUI:ClearSlot(id)
	if ( HasAction(id)) then
		PickupAction(id);
		ClearCursor();
	end
end

function MazzleUI:PlaceItem( actionID, name, link, doNotPlace)
	local itemLink, bag, slot, inv;
	if (not link) then
		itemLink, bag, slot, inv = self:FindItem( name );
		itemLink = self:FindLink(itemLink)
	else
		itemLink, bag, slot, inv = self:FindItem( link );
	end
	if ( bag ) then
	    if (not doNotPlace) then
    		PickupContainerItem( bag, slot );
    		PlaceAction(actionID);
    	end
		return true;
	elseif ( inv ) then
	    if (not doNotPlace) then
    		PickupInventoryItem( inv );
    		PlaceAction(actionID);
    	end
		return true;
	end
	return false;
end

function MazzleUI:FindLink( item )
	-- Find an item's link number from it's item link
	-- Adapted from SimpleActionSets
	if ( item ) then
		for link in string.gmatch( item, "(%d+:%d+:%d+:%d+)" ) do
			return self:TruncateLink(link);
		end
	end
end

function MazzleUI:TruncateLink( itemLink )
	-- truncate item links to item ids
	-- Adapted from SimpleActionSets
	if ( not itemLink ) then return; end
	for num in string.gmatch( itemLink, "(%d+):0:0:0" ) do return num; end
	return itemLink;
end

function MazzleUI:FindItem( item )
	-- Iterate over items the player has and return it's link and location --
	-- Adapted from SimpleActionSets
	if ( not item ) then return; end
	item = tostring(item);
	-- Iterate over bags
	for i=0, 4 do
		local bagSlots = GetContainerNumSlots(i);
		if ( bagSlots ) then
			for j=1, bagSlots do
				local itemLink = GetContainerItemLink(i,j);
				if ( itemLink ) then
					if ( item == self:FindLink( itemLink ) or item == self:FindName( itemLink ) ) then
						return itemLink, i, j;
					end
				end
			end
		end
	end
	-- Iterate over paper doll
	for i=0, 23 do
		local itemLink = GetInventoryItemLink("player",i);
		if ( itemLink ) then
			if ( itemLink ) then
				if ( item == self:FindLink( itemLink ) or item == self:FindName( itemLink ) ) then
					return itemLink, nil, nil, i;
				end
			end
		end
	end
end

function MazzleUI:FindName( item )
	-- Adapted from SimpleActionSets
	-- Find an item's name from it's item link
	if ( item ) then
		for name in string.gmatch( item, "%[(.+)%]") do
			return name;
		end
	end
end
