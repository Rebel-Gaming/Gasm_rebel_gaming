﻿TourGuide:RegisterGuide("Fishing 1-75 (lvl 5-10)", "Fishing 75-150 (lvl 10-20)", "Alliance", function() return [[

N Reach lvl 5 |LVL|5| |N|Reach lvl 5 since we can't train fishing before we are lvl 5.|

B [Fishing Pole] |R|Human| |SKILL|Fishing 2| |Z|Elwynn Forest| |N|Buy a Fishing Pole from Tharynn Bouden at Goldshire in Elwynn Forest. (41.82, 67.17)|
B Buy 2 Shiny Baubles |R|Human| |SKILL|Fishing 2| |L|6529 2| |Z|Elwynn Forest| |N|Buy 2 Shiny Bauble from Tharynn Bouden at Goldshire. (41.82, 67.17)|
B Train Apprentice Fishing |R|Human| |TRAINSKILL|Fishing 75| |Z|Elwynn Forest| |N|Train Apprentice Fishing from Lee Brown just east from Goldshire.(47.61, 62.33)|
N Fish to skill 50 |R|Human| |SKILL|Fishing 50| |Z|Elwynn Forest| |U|6529| |N|Fish anywhere in Elwynn Forest. Apply only one Shiny Bauble to your fishing pole in this area.|
R Stormwind City |R|Human| |SKILL|Fishing 76| |T| |Z|Stormwind City| |N|Travel to Stormwind City. (74.77, 93.25)|
N Fish to skill 75 |R|Human| |SKILL|Fishing 75| |T| |Z|Stormwind City| |U|6529| |N|Fish anywhere in Stormwind City. Apply a Shiny Bauble to your fishing pole.|

B [Fishing Pole] |R|Gnome, Dwarf| |SKILL|Fishing 2| |Z|Dun Morogh| |N|Buy a Fishing Pole from Gretta Ganter at Brewnal Village in Dun Morogh. (31.54, 44.66)|
B Buy 2 Shiny Baubles |R|Gnome, Dwarf| |L|6529 2| |Z|Dun Morogh| |N|Buy 2 Shiny Bauble from Gretta Ganter at Brewnal Village. (31.54, 44.66)|
B Train Apprentice Fishing |R|Gnome, Dwarf| |TRAINSKILL|Fishing 75| |Z|Dun Morogh| |N|Train Apprentice Fishing from Paxton Ganter just north east from Brewnal Village.(35.48, 40.24)|
N Fish to skill 50 |R|Gnome, Dwarf| |SKILL|Fishing 50| |Z|Dun Morogh| |U|6529| |N|Fish at this lake until skill 50. Apply only one Shiny Bauble to your fishing pole in this area.|
R Ironforge |R|Gnome, Dwarf| |SKILL|Fishing 76| |T| |Z|Ironforge| |N|Travel to Ironforge. (15.03, 85.94)|
N Fish to skill 75 |R|Gnome, Dwarf| |SKILL|Fishing 75| |T| |Z|Ironforge| |U|6529| |N|Fish inside The Forlorn Cavern in Ironforge. Apply a Shiny Bauble to your fishing pole.(46.93, 14.14)|

B Train Apprentice Fishing |R|Night Elf| |TRAINSKILL|Fishing 75| |T| |Z|Darnassus| |N|Train Apprentice Fishing from Astaia in Darnassus. (47.85, 56.67)|
B [Fishing Pole] |R|Night Elf| |SKILL|Fishing 2| |T| |Z|Darnassus| |N|Buy a Fishing Pole from Voloren in Darnassus. Just next to Astaia. (47.01, 56.89)|
B Buy 3 Shiny Baubles |R|Night Elf| |SKILL|Fishing 2| |L|6529 3| |T| |Z|Darnassus| |N|Buy 3 Shiny Bauble from Voloren in Darnassus. Just next to Astaia. (47.01, 56.89)|
N Fish to skill 75 |R|Night Elf| |SKILL|Fishing 75| |Z|Darnassus| |T| |U|6529| |N|Fish anywhere in Darnassus. Apply a Shiny Bauble to your fishing pole. Reapply if runs out. When you reach skill 50 + 25 from bauble you will have no junk catch in Danassus.|

A Red Snapper - Very Tasty |QID|9452| |R|Draenei| |SKILL|Fishing 2| |Z|Azuremyst Isle| |N|Accept: Red Snapper - Very Tasty from Diktynna at Ammen Ford on Azuremyst Isle. You will get a Fishing Pole and a bauble in quest reward. (61.05, 54.25)|
C Red Snapper - Very Tasty |QID|9452| |R|Draenei| |SKILL|Fishing 2| |Z|Azuremyst Isle| |U|23654| |N|Find any School of Red Snapper in the water and use the Draenei Fishing Net on top of them.|
T Red Snapper - Very Tasty |QID|9452| |R|Draenei| |SKILL|Fishing 2| |Z|Azuremyst Isle| |N|Turn in the quest at Diktynna. (61.05, 54.25)|
B Train Apprentice Fishing |R|Gnome| |TRAINSKILL|Fishing 75| |Z|Azuremyst Isle| |N|Train Apprentice Fishing from Diktynna.(61.05, 54.25)|
N Fish to skill 75 |R|Draenei| |SKILL|Fishing 75| |Z|Azuremyst Isle| |U|6529| |N|Fish anywhere on Azuremyst Isle. Apply the Shiny Bauble to your fishing pole you got from the quest.|

]]
end)