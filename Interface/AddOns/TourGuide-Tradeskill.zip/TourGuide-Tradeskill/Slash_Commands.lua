﻿SLASH_ITEMID1="/itemid"
function SlashCmdList.ITEMID(msg, editbox)
  local _,link=GetItemInfo(msg)
  if link then
    ChatFrame1:AddMessage(msg .. " has item ID: " .. link:match("item:(%d+):"));
  end
end

SLASH_SKILLISTINFO1="/skillinfo"
function SlashCmdList.SKILLISTINFO(msg, editbox)
  for skillIndex = 1, GetNumSkillLines() do
    local skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier,
      skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType,
      skillDescription = GetSkillLineInfo(skillIndex)
    if not isHeader then
       print(string.format("Skill: %s - %s - Max: %s", skillName, skillRank, skillMaxRank))
    end
  end
end

SLASH_TGGUIDE1="/tguide"
function SlashCmdList.TGGUIDE(msg, editbox)
  print("Not Used");
end