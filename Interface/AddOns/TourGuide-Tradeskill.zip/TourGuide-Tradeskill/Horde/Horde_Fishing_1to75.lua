﻿TourGuide:RegisterGuide("Fishing 1-75 (lvl 5-10)", nil, "Horde", function() return [[

N Empty Guide |N|This is an empty guide just for template|
]]
end)

------------------------------------------------------------------------------------
-- More detailed info can be found here:
-- http://github.com/tekkub/TourGuide/blob/docs/writing_guides.markdown
------------------------------------------------------------------------------------
-- Headlines and Objective icens
------------------------------------------------------------------------------------
-- A QuestName |QID|12593| ---------- Accept quest
-- C QuestName |QID|8325| ----------- Kill stuff (?)
-- T QuestName |N|note| |QID|12593| - Turnin quest
-- b Stormwind City ----------------- Boat to Stormwind City
-- f Stormwind City ----------------- Get flight point
-- F Ironforge ---------------------- Fly to Ironforge
-- h Falconwing Square -------------- Set hearth loc to Falconwing Square
-- H Falconwing Square -------------- Use hearth to go to loc Falconwing Square
-- R Dawning Lane ------------------- Go to Dawning Lane
-- N Kill any cats you come across -- Note entry
-- B [Suntouched Special Reserve]---- Buy something
-- U Orb of Returning |U|24335| ----- Use item
-- K Nightsaber --------------------- Kill stuff entry(?)
--'
------------------------------------------------------------------------------------
-- Sub objectives
------------------------------------------------------------------------------------
-- |N|Somthins is wrong here| ---------------- Note: Note shown when mouse over objective frame
-- |N|Somthins is wrong here (34.43, 53.23)| - Note: Same as abow, just with a cordinate that will be send to TomTom or Cartographer
-- |QID|458| --------------------------------- Quest ID: Used with A, C, T Headlines to tell witch quest it is.
-- |O| --------------------------------------- Optional: Tells that this quest is optional
-- |L|1234| ---------------------------------- Loot Item ID: Complete when you loot an item
-- |L|1234 10| ------------------------------- Loot Item ID: Same as abow, just that it will first complete then there have been looted 10 of the item
-- |U|1234| ---------------------------------- Use Item ID: Pops up a button that you can use to use the specifik item
-- |PRE|Quest Name| |O| ---------------------- Prerequsite: Prerequsite quest that need to be done before showing. NOTE: must be optional as well
-- |C|Priest,..| ----------------------------- Class Limit: Objective is limited to one or more classes. multiclass is splited with a ","
--    Classes: Death Knight, Druid, Hunter, Mage, Paladin, Priest, Rogue, Shaman, Warlock, Warrior
-- |R|Human,..| ------------------------------ Race Limit: Objective is limited to one or more races. multirace is splited with a ","
--    Alliance Races: Human, Dwarf, Night Elf, Gnome, Draenei
--    Horde Races: Orc, Undead, Tauren, Troll, Blood Elf
-- |Z|Darnassus| ----------------------------- Zone: Used to specifi another zone is the objective is on another zone
-- |Q|Quest Name| |QO|Some Mob slain: 10/10| - Sub-objective: must match the quest log text EXACTLY. Completes when a sub-objective of the quest matches the QO tag. Both values must be specified.
-- |T| --------------------------------------- Town: Signifies that an objective takes place in a "town". Will only change baground color of queue
--'
------------------------------------------------------------------------------------
-- Added functions (Only works if Tour Guide - Trade Skill addon is installed)
------------------------------------------------------------------------------------
-- |SKILL|Fishing 2| ------- Skillname and Rank: NOTE: case-sensitive. Complete if skill rank is reached.
-- |TRAINSKILL|Fishing 75| - Skillname and MaxRank: NOTE: case-sensitive. Complete when training a skill. The number must be the max rank that the skill will be after training
-- |LOC|Ironforge| --------- Location: NOTE: case-sensitive. Complete when you go into that zone or sub-zone. Use the text from minimap.
-- |LVL|43| ---------------- Level requirement: Complete when a level exact or higher that specified.
--'
------------------------------------------------------------------------------------
-- Added slasch commands (Only works if Tour Guide - Trade Skill addon is installed)
------------------------------------------------------------------------------------
-- /itemid [Name of item] - Show item id in chat window. Use: open chatbox, type in /itemid and the shift + click on that item to get item id from and press enter.
-- /skillinfo ------------- Show all your skills in chat window. will show all skills both trade skills and non-trade skills