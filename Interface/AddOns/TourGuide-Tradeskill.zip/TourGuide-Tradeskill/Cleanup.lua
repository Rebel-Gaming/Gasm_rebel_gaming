﻿-- Objective Cleanup
if not Cleanup then
  Cleanup = true;

  local frame, events = CreateFrame("Frame"), {};

--  function events:QUEST_QUERY_COMPLETE()
--    print("Pulling Complete Quests: Done!");
--    SavedVar["completedquest"] = GetQuestsCompleted();
--    print("Complete Quests Saved!");
--  end
    
  -- Fire this script when Tour Guide - Trade Skill addon is loaded
  function events:ADDON_LOADED(addon)
    if (addon == "TourGuide-Tradeskill") then
      print("TG - Fishing: Loaded");
      if (SavedVar == nil) then
        SavedVar = {};
      end
      CurentGuide = SavedVar["guide"];
      if (CurentGuide == nil) then
        CurentGuide = "No Guide";
      end
--      print("Pulling Complete Quests: Startet!");
--      QueryQuestsCompleted();
    end
  end

  frame:SetScript("OnEvent",
    function(self, event, ...)
      events[event](self, ...)
    end
  )

  frame:SetScript("OnUpdate",
    function(LastUpdate)
      if not (CurentGuide == TourGuide.db.char.currentguide) then
        local timerstart = time();
        --print("Guide Changed!");
        SavedVar["guide"] = TourGuide.db.char.currentguide;
        CurentGuide = SavedVar["guide"];
        
        -- Cleanup
        --print("Guide Cleanup: Started");
        for i, t in ipairs(TourGuide.tags) do
          -- Cleanup level opjectives that is done
          if (t:match("|LVL|(%d+)|")) then
            lvl = tonumber(t:match("|LVL|(%d+)|"))
            if lvl and lvl <= UnitLevel("Player") then TourGuide:SetTurnedIn(i, true) end
          
          -- Cleanup skills
          elseif (t:match("|SKILL|([%a:%s]+)%s?(%d*)|")) then
            -- Get Skill info to check
            local _, _, SkillName, SkillLevel = t:find("|SKILL|([%a:%s]+)%s?(%d*)|");
            SkillName = trim(SkillName);
            SkillLevel = tonumber(SkillLevel) or 1;
      
            -- Loop all curent skill and check if the skill match
            for sIndex = 1, GetNumSkillLines() do
              local sName, isHeader, _, sRank, _, _, _, _, _, _, _, _, _ = GetSkillLineInfo(sIndex);
      
              -- Only check those that is not headers
              if not isHeader then
                -- If all requirement is set then complete objective
                if SkillName == sName and SkillLevel <= sRank then
                  TourGuide:SetTurnedIn(i, true);
                end
              end
            end
      
          -- Cleanup Tradeskill
          elseif t:match("|TRAINSKILL|([%a:%s]+)%s?(%d*)|") then
            -- Get Skill info to check
            local _, _, SkillName, MaxSkillLevel = t:find("|TRAINSKILL|([%a:%s]+)%s?(%d*)|");
            SkillName = trim(SkillName);
            MaxSkillLevel = tonumber(MaxSkillLevel) or 75;
      
            -- Loop all curent skill and check if the skill match
            for sIndex = 1, GetNumSkillLines() do
              local sName, isHeader, _, _, _, _, sMaxRank, _, _, _, _, _, _ = GetSkillLineInfo(sIndex);
      
              -- Only check those that is not headers
              if not isHeader then
                -- If all requirement is set then complete objective
                if SkillName == sName and MaxSkillLevel <= sMaxRank then
                  TourGuide:SetTurnedIn(i, true);
                end
              end
            end
          end
        end
        local timerstop = time();
        local cleanuptime = timerstop-timerstart;
        print("Guide Cleanup Done: "..tostring(cleanuptime).."sec");
      end
    end
  )

  for k, v in pairs(events) do
    frame:RegisterEvent(k)
  end
end