﻿if not globalfunctions then
  globalfunctions = true;

  -- Function to trim end spaces in a string
  -- Return trimmed string
  function trim(s)
    local a = s:match("^%s*()")
    local b = s:match("()%s*$", a)
    return s:sub(a,b-1)
  end
end