﻿-- Compleater
if not Completer then
  Completer = true;

  local frame, events = CreateFrame("Frame"), {};

  -- check skill level and skill training
  function events:CHAT_MSG_SKILL()
    -- Check if there is a SKILL tag
    if TourGuide.tags[TourGuide.current]:match("|SKILL|([%a:%s]+)%s?(%d*)|") then
      -- Get Skill info to check
      local _, _, SkillName, SkillLevel = TourGuide.tags[TourGuide.current]:find("|SKILL|([%a:%s]+)%s?(%d*)|");
      SkillName = trim(SkillName);
      SkillLevel = tonumber(SkillLevel) or 1;

      -- Loop all curent skill and check if the skill match
      for sIndex = 1, GetNumSkillLines() do
        local sName, isHeader, _, sRank, _, _, _, _, _, _, _, _, _ = GetSkillLineInfo(sIndex);
 
        -- Only check those that is not headers
        if not isHeader then
          -- If all requirement is set then complete objective
          if SkillName == sName and SkillLevel <= sRank then
            TourGuide:SetTurnedIn(TourGuide.current, true);
            CurentGuide = "Update";
          end
        end
      end
    end
  
    -- Check if there is a TRAINSKILL tag
    if TourGuide.tags[TourGuide.current]:match("|TRAINSKILL|([%a:%s]+)%s?(%d*)|") then
      -- Get Skill info to check
      local _, _, SkillName, MaxSkillLevel = TourGuide.tags[TourGuide.current]:find("|TRAINSKILL|([%a:%s]+)%s?(%d*)|");
      SkillName = trim(SkillName);
      MaxSkillLevel = tonumber(MaxSkillLevel) or 75;

      -- Loop all curent skill and check if the skill match
      for sIndex = 1, GetNumSkillLines() do
        local sName, isHeader, _, _, _, _, sMaxRank, _, _, _, _, _, _ = GetSkillLineInfo(sIndex);
 
        -- Only check those that is not headers
        if not isHeader then
          -- If all requirement is set then complete objective
          if SkillName == sName and MaxSkillLevel <= sMaxRank then
            TourGuide:SetTurnedIn(TourGuide.current, true);
            CurentGuide = "Update";
          end
        end
      end
    end
  end

  -- Check location
  function events:ZONE_CHANGED()
    -- Check if there is a LOC tag
    if TourGuide.tags[TourGuide.current]:match("|LOC|([%w:'%s]+)|") then
      -- Get LOC location name
      local Location = TourGuide.tags[TourGuide.current]:match("|LOC|([%w:'%s]+)|");
      Location = trim(Location);

      -- Get current zone or subzone name
      NewLocation = GetMinimapZoneText();

      -- If location and new location match, update objectives
      if (Location == NewLocation) then
        TourGuide:SetTurnedIn(TourGuide.current, true);
      end
    end
  end

  function events:PLAYER_LEVEL_UP(level)
    for i, t in ipairs(TourGuide.tags) do
      lvl = tonumber(t:match("|LVL|(%d+)|"))
      if lvl and lvl <= tonumber(level) then TourGuide:SetTurnedIn(i, true) end
    end
  end

  frame:SetScript("OnEvent",
    function(self, event, ...)
      events[event](self, ...)
    end
  )

  for k, v in pairs(events) do
    frame:RegisterEvent(k)
  end
end