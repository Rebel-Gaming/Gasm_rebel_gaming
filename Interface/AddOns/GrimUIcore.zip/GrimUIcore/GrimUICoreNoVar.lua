--------------------------------------
-- Start Blizzard AddOn Option Panel--
--------------------------------------

local GrimUIOptions = CreateFrame( "Frame", nil , UIParent ); 
	GrimUIOptions.name = "GrimUI";
	InterfaceOptions_AddCategory(GrimUIOptions);
  
------------------------------------
-- End Blizzard AddOn Option Panel--
------------------------------------

----------------------------------
-- Start Hidden Blizzard Frames --
----------------------------------
MainMenuBar:Hide();
RuneFrame:Hide();

--------------------------------
-- End Hidden Blizzard Frames --
--------------------------------

-------------------------------
-- Start Hidden AddOn Frames --
-------------------------------



-------------------------------
-- Start Hidden AddOn Frames --
-------------------------------


------------------------
-- Start Castbar Hide --
------------------------

CastingBarFrame:SetScript("OnUpdate", nil)
CastingBarFrame:SetScript("OnEvent", nil)
CastingBarFrame:Hide()

----------------------
-- End Castbar Hide --
----------------------

-----------------------------------
-- Start Movable Blizzard Frames --
-----------------------------------

local addon = CreateFrame("Frame")
-- These frames are hooked on login.
local frames = {
  -- ["FrameName"] = true (the parent frame should be moved) or false (the frame itself should be moved)
  
  -- Blizzard Frames
  ["RuneFrame"] = false,
  ["SpellBookFrame"] = false,
  ["QuestLogFrame"] = false,
  ["FriendsFrame"] = false,
  ["LFGParentFrame"] = false,
  ["KnowledgeBaseFrame"] = true,
  ["HelpFrame"] = false,
  ["GossipFrame"] = false,
  ["MerchantFrame"] = false,
  ["MailFrame"] = false,
  ["OpenMailFrame"] = false,
  ["GuildRegistrarFrame"] = false,
  ["DressUpFrame"] = false,
  ["TabardFrame"] = false,
  ["TaxiFrame"] = false,
  ["QuestFrame"] = false,
  ["TradeFrame"] = false,
  ["LootFrame"] = false,
  ["PetStableFrame"] = false,
  ["StackSplitFrame"] = false,
  ["PetitionFrame"] = false,
  ["WorldStateScoreFrame"] = false,
  ["BattlefieldFrame"] = false,
  ["ArenaFrame"] = false,
  ["ItemTextFrame"] = false,
  ["GameMenuFrame"] = false,
  ["InterfaceOptionsFrame"] = false,
  ["MacOptionsFrame"] = false,
  ["PetPaperDollFrame"] = true,
  ["PetPaperDollFrameCompanionFrame"] = "CharacterFrame",
  ["PetPaperDollFramePetFrame"] = "CharacterFrame",
  ["PaperDollFrame"] = true,
  ["ReputationFrame"] = true,
  ["SkillFrame"] = true,
  ["PVPFrame"] = true,
  ["PVPBattlegroundFrame"] = true,
  ["SendMailFrame"] = true,
  ["TokenFrame"] = true,
  ["InterfaceOptionsFrame"] = false,
  ["VideoOptionsFrame"] = false,
  ["AudioOptionsFrame"] = false,
  ["BankFrame"] = false,

  -- AddOns
  ["LudwigFrame"] = false,
}

-- Frames provided by load on demand addons, hooked when the addon is loaded.
local lodFrames = {
  -- AddonName = { list of frames, same syntax as above }
  Blizzard_AuctionUI = { ["AuctionFrame"] = false },
  Blizzard_BindingUI = { ["KeyBindingFrame"] = false },
  Blizzard_CraftUI = { ["CraftFrame"] = false },
  Blizzard_GMSurveyUI = { ["GMSurveyFrame"] = false },
  Blizzard_InspectUI = { ["InspectFrame"] = false, ["InspectPVPFrame"] = true, ["InspectTalentFrame"] = true },
  Blizzard_ItemSocketingUI = { ["ItemSocketingFrame"] = false },
  Blizzard_MacroUI = { ["MacroFrame"] = false },
  Blizzard_TalentUI = { ["PlayerTalentFrame"] = false },
  Blizzard_TradeSkillUI = { ["TradeSkillFrame"] = false },
  Blizzard_TrainerUI = { ["ClassTrainerFrame"] = false },
  Blizzard_GuildBankUI = { ["GuildBankFrame"] = false, ["GuildBankEmblemFrame"] = true },
  Blizzard_TimeManager = { ["TimeManagerFrame"] = false },
  Blizzard_AchievementUI = { ["AchievementFrame"] = false, ["AchievementFrameHeader"] = true, ["AchievementFrameCategoriesContainer"] = "AchievementFrame" },
  Blizzard_TokenUI = { ["TokenFrame"] = true },
  Blizzard_ItemSocketingUI = { ["ItemSocketingFrame"] = false },
  Blizzard_GlyphUI = { ["GlyphFrame"] = "PlayerTalentFrame" },
  Blizzard_BarbershopUI = { ["BarberShopFrame"] = false },
  Blizzard_Calendar = { ["CalendarFrame"] = false, ["CalendarCreateEventFrame"] = true },
}

local parentFrame = {}
local hooked = {}

local function print(msg)
  DEFAULT_CHAT_FRAME:AddMessage("GrimUI" .. msg)
end

function addon:PLAYER_LOGIN()
  self:HookFrames(frames)
  -- Bugfix for 3.1+ Battleground frame (wrong anchor)
  if PVPBattlegroundFrameFrameLabel and PVPBattlegroundFrame then
    PVPBattlegroundFrameFrameLabel:ClearAllPoints()
    PVPBattlegroundFrameFrameLabel:SetPoint("TOP", PVPBattlegroundFrame, "TOP", 0, -17)
  end
  -- Bugfix for 3.2 Battleground frame -.-
  if PVPBattlegroundFrameNameHeader and PVPBattlegroundFrame then
    PVPBattlegroundFrameNameHeader:ClearAllPoints()
    PVPBattlegroundFrameNameHeader:SetPoint("TOPLEFT", PVPBattlegroundFrame, "TOPLEFT", 70, -55)
    PVPBattlegroundFrameNameHeader2:ClearAllPoints()
    PVPBattlegroundFrameNameHeader2:SetPoint("TOPLEFT", PVPBattlegroundFrame, "TOPLEFT", 70, -172)
  end
end

function addon:ADDON_LOADED(name)
  local frameList = lodFrames[name]
  if frameList then
    self:HookFrames(frameList)
  end
end

local function MouseDownHandler(frame, button)
  frame = parentFrame[frame] or frame
  if frame and button == "LeftButton" then
    frame:StartMoving()
    frame:SetUserPlaced(false)
  end
end

local function MouseUpHandler(frame, button)
  frame = parentFrame[frame] or frame
  if frame and button == "LeftButton" then
    frame:StopMovingOrSizing()
  end
end

function addon:HookFrames(list)
  for name, child in pairs(list) do
    self:HookFrame(name, child)
  end
end

function addon:HookFrame(name, moveParent)
  local frame = _G[name]
  local parent
  if frame and not hooked[name] then
    if moveParent then
      if type(moveParent) == "string" then
        parent = _G[moveParent]
      else
        parent = frame:GetParent()
      end
      if not parent then
        print("Parent frame not found: " .. name)
        return
      end
      parentFrame[frame] = parent
    end
    if parent then
      parent:SetMovable(true)
      parent:SetClampedToScreen(false)
    end
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:SetClampedToScreen(false)
    self:HookScript(frame, "OnMouseDown", MouseDownHandler)
    self:HookScript(frame, "OnMouseUp", MouseUpHandler)
    hooked[name] = true
  end
end

function addon:HookScript(frame, script, handler)
  if not frame.GetScript then return end
  local oldHandler = frame:GetScript(script)
  if oldHandler then
    frame:SetScript(script, function(...)
      handler(...)
      oldHandler(...)
    end)
  else
    frame:SetScript(script, handler)
  end
end

addon:SetScript("OnEvent", function(f, e, ...) f[e](f, ...) end)
addon:RegisterEvent("PLAYER_LOGIN")
addon:RegisterEvent("ADDON_LOADED")

-- Hook bag frames
hooksecurefunc("ContainerFrame_GenerateFrame", function(frame, size, id)
  if id <= NUM_BAG_FRAMES or id == KEYRING_CONTAINER then
    addon:HookFrame(frame:GetName())
  end
end)
----------------------------------
-- End Moveable Blizzard Frames --
----------------------------------

------------------------------
-- Start ToolTip Item Icons --
------------------------------
 
local DEFAULT_ICON_SIZE = 24

local function AddIcon(self, icon)
	if icon then
		local title = _G[self:GetName() .. 'TextLeft1']
		if title and not title:GetText():find('|T' .. icon) then
			title:SetFormattedText('|T%s:%d|t %s', icon, _G['GrimUIcoreSize'] or DEFAULT_ICON_SIZE, title:GetText())
		end
	end
end
-- Item --
local function hookItem(tip)
	tip:HookScript('OnTooltipSetItem', function(self, ...)
		local name, link = self:GetItem()
		local icon = link and GetItemIcon(link)
		AddIcon(self, icon)
	end)
end
hookItem(_G['GameTooltip'])
hookItem(_G['ItemRefTooltip'])

-- Spell --
local function hookSpell(tip)
	tip:HookScript('OnTooltipSetSpell', function(self, ...)
		local name, rank, icon = GetSpellInfo(self:GetSpell())
		AddIcon(self, icon)
	end)
end
hookSpell(_G['GameTooltip'])
hookSpell(_G['ItemRefTooltip']) 

---------------------------
-- End ToolTip Item Icon --
---------------------------