-- Start WorldFrame/Viewport --
WorldFrame:ClearAllPoints(); WorldFrame:SetPoint("TOPLEFT", 0, -15); WorldFrame:SetPoint("BOTTOMRIGHT", 0, 95);
-- End WorldFrame/Viewport --

-- Start Latency Frame --
function LatencyDisplay_OnLoad()
	LATENCYDISPLAY_LOW_LATENCY = 150;
	LATENCYDISPLAY_MEDIUM_LATENCY = 420;
	LATENCYDISPLAY_UPDATE_INTERVAL = 1;
	this.updateInterval = 0;
end

function LatencyDisplay_OnUpdate()
	if (this.updateInterval > 0) then
		this.updateInterval = this.updateInterval - arg1;
	else
		this.updateInterval = LATENCYDISPLAY_UPDATE_INTERVAL;
		local bandwidthIn, bandwidthOut, latency = GetNetStats();
		if (latency > LATENCYDISPLAY_MEDIUM_LATENCY) then
			LatencyDisplay_Text:SetTextColor(1, 0, 0);									
		elseif (latency > LATENCYDISPLAY_LOW_LATENCY) then
			LatencyDisplay_Text:SetTextColor(1, 1, 0);
		else
			LatencyDisplay_Text:SetTextColor(0, 1, 0);
		end
		if (latency > 9999) then
			LatencyDisplay_Text:SetText("HIGH  ");
		else
			LatencyDisplay_Text:SetText(""..latency.."ms");
		end
	end

end
-- End Latency Frame --
-- Start FPS Frame
function FPSDisplay_OnLoad()
	FPSDISPLAY_LOW_FPS = 40;
	FPSDISPLAY_MEDIUM_FPS = 20;
	FPSDISPLAY_UPDATE_INTERVAL = 1;
	this.updateInterval = 0;
end

function FPSDisplay_OnUpdate()
	if (this.updateInterval > 0) then
		this.updateInterval = this.updateInterval - arg1;
	else
		this.updateInterval = FPSDISPLAY_UPDATE_INTERVAL;
		local FPS = GetFramerate();
		if (FPS < FPSDISPLAY_MEDIUM_FPS) then
			FPSDisplay_Text:SetTextColor(1, 0, 0);									
		elseif (FPS < FPSDISPLAY_LOW_FPS) then
			FPSDisplay_Text:SetTextColor(1, 1, 0);
		else
			FPSDisplay_Text:SetTextColor(0, 1, 0);
		end
		if (FPS < 3) then
			FPSDisplay_Text:SetText("WTF");
		else
			FPSDisplay_Text:SetText("".. floor(FPS) .."fps");
		end
	end

end
-- End FPS Frame --