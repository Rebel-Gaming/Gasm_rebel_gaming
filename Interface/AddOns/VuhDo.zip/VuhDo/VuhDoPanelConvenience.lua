local VUHDO_GLOBAL = getfenv();

-- Fast caches
local VUHDO_HEALTH_BAR = { };
local VUHDO_HEAL_BUTTON = { };
local VUHDO_GROUP_ORDER_BARS_LEFT = { };
local VUHDO_GROUP_ORDER_BARS_RIGHT = { };
local VUHDO_BUFF_SWATCHES = { };
local VUHDO_BUFF_PANELS = { };

VUHDO_BUTTON_CACHE = { };
local VUHDO_BUTTON_CACHE = VUHDO_BUTTON_CACHE;



--
function VUHDO_getBarIconFrame(aHealthBar, anIconNumber)
  return VUHDO_GLOBAL[aHealthBar:GetName() .. "Ic" .. anIconNumber];
end






--
function VUHDO_getBarRoleIcon(aButton, anIconNumber)
  return VUHDO_GLOBAL[aButton:GetName() .. "BgBarIcBarHlBarIc" .. anIconNumber];
end



--
function VUHDO_getTargetBarRoleIcon(aButton, anIconNumber)
  return VUHDO_GLOBAL[aButton:GetName() .. "BgBarHlBarIc" .. anIconNumber];
end



-- Returns the Bar-Object appropriate for given Button-Object
function VUHDO_getBarIcon(aHealthBar, anIconNumber)
  return VUHDO_GLOBAL[aHealthBar:GetName() .. "Ic" .. anIconNumber .. "I"];
end



--
function VUHDO_getBarIconTimer(aHealthBar, anIconNumber)
	return VUHDO_GLOBAL[aHealthBar:GetName() .. "Ic" .. anIconNumber .. "T"];
end



--
function VUHDO_getBarIconCounter(aHealthBar, anIconNumber)
	return VUHDO_GLOBAL[aHealthBar:GetName() .. "Ic" .. anIconNumber .. "C"];
end



--
function VUHDO_getBarIconCharge(aHealthBar, anIconNumber)
	return VUHDO_GLOBAL[aHealthBar:GetName() .. "Ic" .. anIconNumber .. "A"];
end



--
function VUHDO_getRaidTargetTexture(aTargetBar)
	return VUHDO_GLOBAL[aTargetBar:GetName() .. "TgTxu"];
end



--
function VUHDO_getRaidTargetTextureFrame(aTargetBar)
	return VUHDO_GLOBAL[aTargetBar:GetName() .. "Tg"];
end



--
function VUHDO_getGroupOrderLabel2(aGroupOrderPanel)
  return VUHDO_GLOBAL[aGroupOrderPanel:GetName() .. "DrgLbl2Lbl"];
end



--
function VUHDO_getPanelNumLabel(aPanel)
  return VUHDO_GLOBAL[aPanel:GetName() .. "GrpLblLbl"];
end



--
function VUHDO_getConfigOrderBarRight(aPanelNum, anOrderNum)
	local tIndex = aPanelNum * 100 + anOrderNum;
	if (VUHDO_GROUP_ORDER_BARS_RIGHT[tIndex] == nil) then
		local tPanel = VUHDO_getOrCreateGroupOrderPanel(aPanelNum, anOrderNum);
		VUHDO_GROUP_ORDER_BARS_RIGHT[tIndex] = VUHDO_GLOBAL[tPanel:GetName() .. "InsTxuR"];
	end

	return VUHDO_GROUP_ORDER_BARS_RIGHT[tIndex];
end



--
function VUHDO_getConfigOrderBarLeft(aPanelNum, anOrderNum)
	local tIndex = aPanelNum * 100 + anOrderNum;
	if (VUHDO_GROUP_ORDER_BARS_LEFT[tIndex] == nil) then
		local tPanel = VUHDO_getOrCreateGroupOrderPanel(aPanelNum, anOrderNum);
		VUHDO_GROUP_ORDER_BARS_LEFT[tIndex] = VUHDO_GLOBAL[tPanel:GetName() .. "InsTxuL"];
	end

	return VUHDO_GROUP_ORDER_BARS_LEFT[tIndex];
end



--
function VUHDO_getGroupOrderPanel(aParentPanelNum, aPanelNum)
	return VUHDO_GLOBAL["VdAc" .. aParentPanelNum .. "GrpOrd" .. aPanelNum];
end



--
function VUHDO_getGroupSelectPanel(aParentPanelNum, aPanelNum)
	return VUHDO_GLOBAL["VdAc" .. aParentPanelNum .. "GrpSel" .. aPanelNum];
end




--
function VUHDO_getOrCreateGroupOrderPanel(aParentPanelNum, aPanelNum)
	local tName = "VdAc" .. aParentPanelNum .. "GrpOrd" .. aPanelNum;
	if (VUHDO_GLOBAL[tName] == nil) then
		CreateFrame("Frame", tName, VUHDO_GLOBAL["VdAc" .. aParentPanelNum], "VuhDoGrpOrdTemplate");
	end

	return VUHDO_GLOBAL[tName];
end



--
function VUHDO_getOrCreateGroupSelectPanel(aParentPanelNum, aPanelNum)
	local tName = "VdAc" .. aParentPanelNum .. "GrpSel" .. aPanelNum;
	if (VUHDO_GLOBAL[tName] == nil) then
		CreateFrame("Frame", tName, VUHDO_GLOBAL["VdAc" .. aParentPanelNum], "VuhDoGrpSelTemplate");
	end

	return VUHDO_GLOBAL[tName];
end



--
function VUHDO_getActionPanel(aPanelNum)
  return VUHDO_GLOBAL["VdAc" .. aPanelNum];
end



-- Returns the Bar-Object appropriate for given Button-Object
function VUHDO_getHealthBar(aButton, aBarNumber)
	return VUHDO_HEALTH_BAR[aButton:GetName()][aBarNumber];
end



--
function VUHDO_getHeaderBar(aButton)
  return VUHDO_GLOBAL[aButton:GetName() .. "Bar"];
end



--
function VUHDO_getPlayerTargetFrame(aButton)
  return VUHDO_GLOBAL[VUHDO_HEALTH_BAR[aButton:GetName()][1]:GetName() .. "PlTg"];
end


--
function VUHDO_getPlayerTargetFrameTarget(aButton)
  return VUHDO_GLOBAL[aButton:GetName() .. "TgPlTg"];
end



--
function VUHDO_getPlayerTargetFrameToT(aButton)
  return VUHDO_GLOBAL[aButton:GetName() .. "TotPlTg"];
end




--
function VUHDO_getClusterBorderFrame(aButton)
  return VUHDO_GLOBAL[VUHDO_HEALTH_BAR[aButton:GetName()][1]:GetName() .. "Clu"];
end



--
function VUHDO_getTargetButton(aButton)
	return VUHDO_GLOBAL[aButton:GetName() .. "Tg"];
end



--
function VUHDO_getTotButton(aButton)
	return VUHDO_GLOBAL[aButton:GetName() .. "Tot"];
end



--
function VUHDO_getHealButton(aButtonNum, aPanelNum)
	return VUHDO_HEAL_BUTTON[aPanelNum][aButtonNum];
end



--
function VUHDO_getTextPanel(aBar)
	return VUHDO_GLOBAL[aBar:GetName() .. "TxPnl"];
end



--
function VUHDO_getBarText(aBar)
	return VUHDO_GLOBAL[aBar:GetName() .. "TxPnlUnN"];
end



--
function VUHDO_getHeaderTextId(aHeader)
	return VUHDO_GLOBAL[aHeader:GetName() .. "BarUnN"];
end



--
function VUHDO_getLifeText(aBar)
	return VUHDO_GLOBAL[aBar:GetName() .. "TxPnlLife"];
end



--
function VUHDO_getOverhealPanel(aBar)
	return VUHDO_GLOBAL[aBar:GetName() .. "OvhPnl"];
end



--
function VUHDO_getOverhealText(aBar)
	return VUHDO_GLOBAL[aBar:GetName() .. "OvhPnlT"];
end



--
function VUHDO_getHeader(aHeaderNo, aPanelNum)
	return VUHDO_GLOBAL["VdAc" .. aPanelNum .. "Hd" .. aHeaderNo];
end



--
local tButton;
function VUHDO_getOrCreateBuffSwatch(aName, aParent)

	if (VUHDO_BUFF_SWATCHES[aName] == nil) then
		VUHDO_BUFF_SWATCHES[aName] = CreateFrame("Frame", aName, aParent, "VuhDoBuffSwatchPanelTemplate");
		tButton = VUHDO_GLOBAL[aName .. "GlassButton"];

		tButton:SetAttribute("_onleave", [=[
			self:ClearBindings();
		]=]);

		tButton:SetAttribute("_onshow", [=[
			self:ClearBindings();
		]=]);

		tButton:SetAttribute("_onhide", [=[
			self:ClearBindings();
		]=]);
	else
		tButton = VUHDO_GLOBAL[aName .. "GlassButton"];
	end

	if (VUHDO_BUFF_SETTINGS["CONFIG"]["WHEEL_SMART_BUFF"]) then
		tButton:SetAttribute("_onenter", [=[
				self:ClearBindings();
				self:SetBindingClick(0, "MOUSEWHEELUP" , "VuhDoSmartCastGlassButton", "LeftButton");
				self:SetBindingClick(0, "MOUSEWHEELDOWN" , "VuhDoSmartCastGlassButton", "LeftButton");
		]=]);
	else
		tButton:SetAttribute("_onenter", [=[
			self:ClearBindings();
		]=]);
	end

	return VUHDO_BUFF_SWATCHES[aName];
end



--
function VUHDO_getOrCreateBuffPanel(aName)
	if (VUHDO_BUFF_PANELS[aName] == nil) then
		VUHDO_BUFF_PANELS[aName] = CreateFrame("Frame", aName, VuhDoBuffWatchMainFrame, "VuhDoBuffWatchBuffTemplate");
	end

	return VUHDO_BUFF_PANELS[aName];
end



--
function VUHDO_resetAllBuffPanels()
	VUHDO_resetAllBuffSwatches();

	local tPanel;

	for _, tPanel in pairs(VUHDO_BUFF_SWATCHES) do
		tPanel:Hide();
		tPanel:ClearAllPoints();
	end

	for _, tPanel in pairs(VUHDO_BUFF_PANELS) do
		tPanel:Hide();
		tPanel:ClearAllPoints();
	end
end



--
function VUHDO_resetAllBuffSwatches()
	local tSwatch;
	for _, tSwatch in pairs(VUHDO_BUFF_SWATCHES) do
		tSwatch:Hide();
		tSwatch:ClearAllPoints();
	end
end



--
function VUHDO_getAllBuffSwatches()
	return VUHDO_BUFF_SWATCHES;
end



--
function VUHDO_getAggroTexture(aHealthBar)
	return VUHDO_GLOBAL[aHealthBar:GetName() .. "Aggro"];
end



--
local VUHDO_STATUSBAR_LEFT_TO_RIGHT = 1;
local VUHDO_STATUSBAR_RIGHT_TO_LEFT = 2;
local VUHDO_STATUSBAR_BOTTOM_TO_TOP = 3;
local VUHDO_STATUSBAR_TOP_TO_BOTTOM = 4;
function VUHDO_repairStatusbar(tBar)
	tBar.texture = tBar:CreateTexture(nil, "ARTWORK");
	tBar.txOrient = VUHDO_STATUSBAR_LEFT_TO_RIGHT;
	tBar.value = 0;
	tBar.isInverted = false;



	tBar.SetStatusBarColor = function(self, r, g, b, a)
		self.texture:SetVertexColor(r, g, b, a);
	end



	tBar.GetStatusBarColor = function(self)
		return self.texture:GetVertexColor();
	end


	tBar.SetAlpha = function(self, a)
		self.texture:SetAlpha(a);
	end


	tBar.SetValue = function(self, aValue)
		if ((aValue or -1) < 0) then
			aValue = 0;
		elseif (aValue > 100) then
			aValue = 100;
		end

		self["value"] = aValue;
		aValue = aValue * 0.01;
		if (self["isInverted"]) then
			aValue = 1 - aValue;
		end

		if (1 == self["txOrient"]) then -- VUHDO_STATUSBAR_LEFT_TO_RIGHT
			self["texture"]:SetTexCoord(0, aValue, 0, 1);
			self["texture"]:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", (aValue - 1) * self:GetWidth(), 0);

		elseif (2 == self["txOrient"]) then -- VUHDO_STATUSBAR_RIGHT_TO_LEFT
			self["texture"]:SetTexCoord(1 - aValue, 1, 0, 1);
			self["texture"]:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", (1 - aValue) * self:GetWidth(), 0);

		elseif (3 == self["txOrient"]) then -- VUHDO_STATUSBAR_BOTTOM_TO_TOP
			self["texture"]:SetTexCoord(0, 1, 1 - aValue, 1);
			self["texture"]:SetPoint("TOPLEFT", self, "TOPLEFT", 0, (aValue - 1) * self:GetHeight());

		else --if (VUHDO_STATUSBAR_TOP_TO_BOTTOM == self["txOrient"]) then
			self["texture"]:SetTexCoord(0, 1, 0, aValue);
			self["texture"]:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 0, (1 - aValue) * self:GetHeight());
		end
	end



	tBar.GetValue = function(self)
		return self.value;
	end



	tBar.SetStatusBarTexture = function(self, aTexture)
		self.texture:SetTexture(aTexture);
	end



	tBar.SetMinMaxValues = function(self, aMinValue, aMaxValue)
		-- Dummy
	end



	tBar.SetOrientation = function(self, anOrientation)
		self.texture:ClearAllPoints();

		if ("HORIZONTAL" == anOrientation) then
			self.texture:SetPoint("TOPLEFT", self, "TOPLEFT", 0, 0);
			self.txOrient = VUHDO_STATUSBAR_LEFT_TO_RIGHT;
		elseif ("HORIZONTAL_INV" == anOrientation) then
			self.texture:SetPoint("TOPRIGHT", self, "TOPRIGHT", 0, 0);
			self.txOrient = VUHDO_STATUSBAR_RIGHT_TO_LEFT;
		elseif ("VERTICAL" == anOrientation) then
			self.texture:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", 0, 0);
			self.txOrient = VUHDO_STATUSBAR_BOTTOM_TO_TOP;
		else -- VERTICAL_INV
			self.texture:SetPoint("TOPRIGHT", self, "TOPRIGHT", 0, 0);
			self.txOrient = VUHDO_STATUSBAR_TOP_TO_BOTTOM;
		end

		self:SetValue(self.value);
	end



	tBar.SetIsInverted = function(self, anIsInverted)
		self.isInverted = anIsInverted;
	end



	tBar.SetOrientation(tBar, "HORIZONTAL");
	return tBar;
end



--
local function VUHDO_fastCacheInitButton(aPanelNum, aButtonNum)
	local tButtonName = "VdAc" .. aPanelNum .. "HlU" .. aButtonNum;
	local tButtonTgName = tButtonName .. "Tg";
	local tButtonTotName = tButtonName .. "Tot";
	local tButton = VUHDO_GLOBAL[tButtonName];

	VUHDO_HEALTH_BAR[tButtonName] = { };
	VUHDO_HEALTH_BAR[tButtonTgName] = { };
	VUHDO_HEALTH_BAR[tButtonTotName] = { };

	--Health
	VUHDO_HEALTH_BAR[tButtonName][1] = VUHDO_GLOBAL[tButtonName .. "BgBarIcBarHlBar"];
	-- Mana
	VUHDO_HEALTH_BAR[tButtonName][2] = VUHDO_GLOBAL[tButtonName .. "BgBarIcBarHlBarMaBar"];
	-- Background
	VUHDO_HEALTH_BAR[tButtonName][3] = VUHDO_GLOBAL[tButtonName .. "BgBar"];
	-- Aggro
	VUHDO_HEALTH_BAR[tButtonName][4] = VUHDO_GLOBAL[tButtonName .. "BgBarIcBarHlBarAgBar"];
	-- Target Health
	VUHDO_HEALTH_BAR[tButtonName][5] = VUHDO_GLOBAL[tButtonName .. "TgBgBarHlBar"];
	VUHDO_HEALTH_BAR[tButtonTgName][1] = VUHDO_GLOBAL[tButtonName .. "TgBgBarHlBar"];
	-- Incoming
	VUHDO_HEALTH_BAR[tButtonName][6] = VUHDO_GLOBAL[tButtonName .. "BgBarIcBar"];
	VUHDO_HEALTH_BAR[tButtonTgName][6] = VuhDoDummyStatusBar;
	VUHDO_HEALTH_BAR[tButtonTotName][6] = VuhDoDummyStatusBar;
	-- Threat
	VUHDO_HEALTH_BAR[tButtonName][7] = VUHDO_GLOBAL[tButtonName .. "ThBar"];
	-- Group Highlight
	VUHDO_HEALTH_BAR[tButtonName][8] = VUHDO_GLOBAL[tButtonName .. "BgBarIcBarHlBarHiBar"];
	VUHDO_HEALTH_BAR[tButtonTgName][8] = VuhDoDummyStatusBar;
	VUHDO_HEALTH_BAR[tButtonTotName][8] = VuhDoDummyStatusBar;
	-- HoT 1
	VUHDO_HEALTH_BAR[tButtonName][9] = VUHDO_GLOBAL[tButtonName .. "BgBarIcBarHlBarHotBar1"];
	-- HoT 2
	VUHDO_HEALTH_BAR[tButtonName][10] = VUHDO_GLOBAL[tButtonName .. "BgBarIcBarHlBarHotBar2"];
	-- HoT 3
	VUHDO_HEALTH_BAR[tButtonName][11] = VUHDO_GLOBAL[tButtonName .. "BgBarIcBarHlBarHotBar3"];

	-- Target Background
	VUHDO_HEALTH_BAR[tButtonName][12] = VUHDO_GLOBAL[tButtonName .. "TgBgBar"];
	VUHDO_HEALTH_BAR[tButtonTgName][3] = VUHDO_GLOBAL[tButtonName .. "TgBgBar"];
	-- Target Mana
	VUHDO_HEALTH_BAR[tButtonName][13] = VUHDO_GLOBAL[tButtonName .. "TgBgBarHlBarMaBar"];
	VUHDO_HEALTH_BAR[tButtonTgName][2] = VUHDO_GLOBAL[tButtonName .. "TgBgBarHlBarMaBar"];

	-- Tot Health
	VUHDO_HEALTH_BAR[tButtonName][14] = VUHDO_GLOBAL[tButtonName .. "TotBgBarHlBar"];
	VUHDO_HEALTH_BAR[tButtonTotName][1] = VUHDO_GLOBAL[tButtonName .. "TotBgBarHlBar"];
	-- Tot Background
	VUHDO_HEALTH_BAR[tButtonName][15] = VUHDO_GLOBAL[tButtonName .. "TotBgBar"];
	VUHDO_HEALTH_BAR[tButtonTotName][3] = VUHDO_GLOBAL[tButtonName .. "TotBgBar"];
	-- Tot Mana
	VUHDO_HEALTH_BAR[tButtonName][16] = VUHDO_GLOBAL[tButtonName .. "TotBgBarHlBarMaBar"];
	VUHDO_HEALTH_BAR[tButtonTotName][2] = VUHDO_GLOBAL[tButtonName .. "TotBgBarHlBarMaBar"];

	VUHDO_HEAL_BUTTON[aPanelNum][aButtonNum] = tButton;
	VUHDO_BUTTON_CACHE[tButtonName] = aPanelNum;
	VUHDO_BUTTON_CACHE[tButtonTgName] = aPanelNum;
	VUHDO_BUTTON_CACHE[tButtonTotName] = aPanelNum;
end



--
function VUHDO_getOrCreateHealButton(aButtonNum, aPanelNum)
	if (VUHDO_HEAL_BUTTON[aPanelNum][aButtonNum] == nil) then
		local tNewButton = CreateFrame("Button", "VdAc" .. aPanelNum .. "HlU" .. aButtonNum, VUHDO_GLOBAL["VdAc" .. aPanelNum], "VuhDoButtonSecureTemplate");
		VUHDO_fastCacheInitButton(aPanelNum, aButtonNum);
		VUHDO_initLocalVars(aPanelNum);
		VUHDO_initHealButton(tNewButton, aPanelNum);
		VUHDO_positionHealButton(tNewButton);
	end
	return VUHDO_HEAL_BUTTON[aPanelNum][aButtonNum];
end



--
function VUHDO_getPanelButtons(aPanelNum)
  return VUHDO_HEAL_BUTTON[aPanelNum];
end



--
function VUHDO_initFastCache()
	local tCnt;
	for tCnt = 1, VUHDO_MAX_PANELS do
		VUHDO_HEAL_BUTTON[tCnt] = { };
	end
end
