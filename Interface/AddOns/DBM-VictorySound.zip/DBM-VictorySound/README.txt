This mod does one thing, upon a wipe or kill of a DBM recognized boss it plays a sound, that simple. DBM-Core is required to be installed for this to work. It works similar to BigWigs' victory music.

This is now 100% configurable ingame. Simply open the DBM GUI (via /dbm, etc) and goto the options tab. Click on "Victory Sound" and configure it to your liking. If you wish to add your own songs, just drag
the .wav or .mp3 file to the "sounds" folder and type the name of the file in the provided edit box.

Again, if you encounter any errors feel free to post them so I can take a stab at them. This has been tested with DBM 4.05, 4.10 remains untested.

Enjoy!

Known Issues:
None!

Plans for next patch:
Make the process of adding additional songs less annoying, perhaps an integration with SharedMedia or something.

Change Log:
1.1 - Added the a GUI configuration within DBM's configuration panel. Just type /dbm and click Options --> Victory Sound. Also a few bug fixes and tweaks.
1.2 - Added more GUI config!  Added a bunch of new victory and defeat songs to choose from and a handy dandy dropdown menu for choosing them.  Fixed a bug with file names going lowercase, etc.