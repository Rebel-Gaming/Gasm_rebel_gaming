﻿if not DominosFu_revision then DominosFu_revision = {} end
DominosFu_revision.enUS = ("$Revision: 41 $"):match("(%d+)")


local L = AceLibrary("AceLocale-2.2"):new("FuBar_DominosFu")

L:RegisterTranslations("enUS", function() return {
	["DominosFu"] = true,
	["DominosFu (v%s r%d)"] = true,
   ["Bars locked:"] = true,
   ["Configuration"] = true,
   ["Disable Key Bindings Mode"] = true,
   ["Enable Key Bindings Mode"] = true,
   ["Enable interactive key bindings mode allowing keys to be assigned to Dominos action bar buttons."] = true,
   ["Key bindings mode:"] = true,
   ["Lock Bar Positions"] = true,
   ["No"] = true,
   ["Off"] = true,
   ["On"] = true,
   ["Open Dominos configuration window"] = true,
   ["Range Color"] = true,
   ["Show Button Tooltips"] = true,
   ["Show Hotkeys"] = true,
   ["Show Macro Text"] = true,
   ["Tooltips shown:"] = true,
   ["When set, Dominos' bars are locked in place."] = true,
   ["When set, a button's key binding, if any, will be displayed on the button itself."] = true,
   ["When set, button tooltips will be displayed."] = true,
   ["When set, buttons containing macros will display the macro name on the button itself."] = true,
   ["Yes"] = true,
   ["|cffffff00Alt-Click|r to disable key bindings mode."] = true,
   ["|cffffff00Alt-Click|r to enable key bindings mode."] = true,
   ["|cffffff00Click|r to open Dominos Options."] = true,
   ["|cffffff00Control-Click|r to hide button tooltips."] = true,
   ["|cffffff00Control-Click|r to show button tooltips."] = true,
   ["|cffffff00Right-Click|r to change Fubar settings."] = true,
   ["|cffffff00Shift-Click|r to lock bars."] = true,
   ["|cffffff00Shift-Click|r to unlock bars."] = true,
   ["|cffffff00Right-Click on a bar|r to change bar settings."] = true,
} end)
