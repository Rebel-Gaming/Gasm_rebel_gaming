local L = LibStub("AceLocale-3.0"):NewLocale("TitanPets","enUS",true)

if L then
	L["TITAN_PETS_BUTTON_LABEL_CRITTER"] = "Critter: ";
	L["TITAN_PETS_BUTTON_LABEL_MOUNT"] = "Mount: ";
	L["TITAN_PETS_BUTTON_LABEL_COMPANION"] = "Companion: ";
	L["TITAN_PETS_MENU_TEXT"] = "Critters and Mounts";
	L["TITAN_PETS_TOOLTIP_TITLE"] = "Critters and Mounts Info";
	L["TITAN_PETS_HINT_1"] = "Left-click to summon a random non-combat companion";
	L["TITAN_PETS_HINT_2"] = "Right-click to summon a random mount (EXPERIMENTAL)";
	L["TITAN_PETS_NONE"] = "None";
end
