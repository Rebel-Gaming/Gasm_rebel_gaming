-- ************************************************************************** --
-- * TitanPets.lua                                                         
-- *                                                                        
-- * By: Rothpada                                                           
-- * Acknowledgements: Azime (for the idea)
-- ************************************************************************** --

local TITAN_PETS_ID = "TitanPets";
local AceTimer = LibStub("AceTimer-3.0");
local L = LibStub("AceLocale-3.0"):GetLocale("TitanPets", true)

local IS_DEBUGGING = false;

-- ************************************************************************** --
-- ******************************** Titan Functions ************************* --
-- ************************************************************************** --

function TitanPanelTitanPetsButton_OnLoad(self)
	self.registry = {
		id = TITAN_PETS_ID,
		menuText = L["TITAN_PETS_MENU_TEXT"],
		buttonTextFunction = "TitanPanelTitanPetsButton_GetButtonText",
		tooltipTitle = L["TITAN_PETS_TOOLTIP_TITLE"],
		tooltipTextFunction = "TitanPanelTitanPetsButton_GetTooltipText",
		frequency = 1.0,
		savedVariables = {
			ShowLabelText = 1,
		}	
	};
	
--	math.randomseed(time());
	AceTimer.ScheduleRepeatingTimer("TitanPanel"..TITAN_PETS_ID, TitanPanelPluginHandle_OnUpdate, 1, {TITAN_PETS_ID, TITAN_PANEL_UPDATE_BUTTON })
	TitanPets_output(TITAN_PETS_ID.." by Rothpada (Shadow Council)");
end

function TitanPanelTitanPetsButton_OnClick(self, button)
	if ( button == "LeftButton" ) then
		-- summon a random non-combat pet
		TitanPets_summonRandomCompanion("CRITTER");
	elseif ( button == "RightButton" ) then
		-- see if we can fly
			-- if so, summon a random flying mount that is fastest
			-- if not, summon a random land mount that is fastest 
	end
	TitanPanelPluginHandle_OnUpdate({TITAN_PETS_ID, TITAN_PANEL_UPDATE_ALL})
end

function TitanPanelTitanPetsButton_OnEvent(self, event, ...)
	TitanSpec_debug(event);
	TitanPanelPluginHandle_OnUpdate({TITAN_PETS_ID, TITAN_PANEL_UPDATE_ALL})
end

function TitanPanelTitanPetsButton_GetButtonText(id)	
	for i=1,GetNumCompanions("CRITTER") do
		_,creatureName,_,_,isSummoned = GetCompanionInfo("CRITTER", i);
		if isSummoned then
			return L["TITAN_PETS_BUTTON_LABEL_CRITTER"], creatureName;
		end
	end
	for i=1,GetNumCompanions("MOUNT") do
		_,creatureName,_,_,isSummoned = GetCompanionInfo("MOUNT", i);
		if isSummoned then
			return L["TITAN_PETS_BUTTON_LABEL_MOUNT"], creatureName;
		end
	end
	return L["TITAN_PETS_BUTTON_LABEL_COMPANION"], L["TITAN_PETS_NONE"];
end

function TitanPanelTitanPetsButton_GetTooltipText(self)
	return TitanPets_getColouredText(L["TITAN_PETS_HINT_1"], "green")..
				"\n"..TitanPets_getColouredText(L["TITAN_PETS_HINT_2"], "green");
end

-- ************************************************************************** --
-- ******************************** User Functions ************************** --
-- ************************************************************************** --

function TitanPets_debug(msg)
	if IS_DEBUGGING then
		TitanSpec_output(msg);
	end
end

function TitanPets_output(msg)
    DEFAULT_CHAT_FRAME:AddMessage(msg, 1, 1, 1);
end


function TitanPets_getColouredText(msg, colour)
	local colourCode = "";
	
	if ( colour == nil or colour == "default" ) then
		return msg;
	elseif ( colour == "red" ) then
		colourCode = "|cffff0000";
	elseif ( colour == "green" ) then
		colourCode = "|cff00ff00";
	elseif ( colour == "blue" ) then
		colourCode = "|cff0000ff";
	elseif ( colour == "yellow" ) then
		colourCode = "|cffffff00";
	elseif ( colour == "white" ) then
		colourCode = "|cffffffff";
	elseif ( colour == "black" ) then
		colourCode = "|cff000000";
	else
		colourCode = "|cff"..colour;
	end
        
	return colourCode..msg..FONT_COLOR_CODE_CLOSE;
end

function TitanPets_summonRandomCompanion(typeID)
	local numCompanions = GetNumCompanions(typeID);
	local slotID = math.random(numCompanions);
	CallCompanion(typeID, slotID);
	_,creatureName,_,_,isSummoned = GetCompanionInfo(typeID, slotID);
	
	if isSummoned then
		currentCompanion = creatureName;
	end
end
