﻿local polShift= 0;
local elapsedTime = 0;
local arrow = 0;
local currentCharge = "none";
local etTest =0;
local thaddColor = "|c0000ff00EasyThadius|r";
local etVersion = 1.24;


function EasyThadd_OnLoad()
	if( DEFAULT_CHAT_FRAME ) then
		DEFAULT_CHAT_FRAME:AddMessage(thaddColor.." Loaded.");
	end
	UIErrorsFrame:AddMessage(thaddColor.." Loaded.", 1.0, 1.0, 1.0, 1.0, UIERRORS_HOLD_TIME);

	this:RegisterEvent("PLAYER_REGEN_ENABLED");
	this:RegisterEvent("CHAT_MSG_MONSTER_EMOTE");
    this:RegisterEvent("CHAT_MSG_RAID_BOSS_EMOTE");
    
   	SlashCmdList["EasyThaddCOMMAND"] = EasyThadd_Handler;
   	SLASH_EasyThaddCOMMAND1 = "/et";
   	SLASH_EasyThaddCOMMAND2 = "/easythaddius";


	EasyThaddRightFrame:ClearAllPoints();
	EasyThaddRightFrame:SetPoint("CENTER", UIParent, "CENTER", 0/5, 300/5)

	EasyThaddLeftFrame:ClearAllPoints();
	EasyThaddLeftFrame:SetPoint("CENTER", UIParent, "CENTER", 0/5, 300/5)

end



function EasyThadd_OnUpdate(elapse)

   elapsedTime = elapsedTime + elapse;

   if (elapsedTime > .2)  then

	elapsedTime = elapsedTime -.2;
	if (arrow >0) then
		arrow = arrow -1;
		if (arrow == 0) then
			EasyThaddRightFrame:Hide();
			EasyThaddLeftFrame:Hide();
			if (etTest >0) then
				etTest = etTest -1;
				if (etTest==1) then
					EasyThaddRightFrame:Show();
					chatmsg("Testing Right Arrow.");
				end
				if (etTest==2) then
					EasyThaddLeftFrame:Show();
					chatmsg("Testing Left Arrow.");
				end
				if (etTest==0) then
					chatmsg("Test concluded.");
				end
				arrow = 20;
			end

		end
	end

	if (polShift>0) then
		polShift = polShift- 1;
		if (polShift== 0) then
            local foundCharge = false;
			--chatmsg("Timer");
			for n=1,40 do
				name, rank, iconTexture, count, debuffType, duration, timeLeft  =  UnitDebuff("player", n);
				if (name==nil) then
                    if (foundCharge == false) then
                        polShift = 2;
                    end
					return;
				end
                
				if (name~=nil) then
					--chatmsg(name)
					if (name == "Negative Charge" or name =="Positive Charge") then
                        foundCharge = true;
                        --if (currentCharge ~= "none") then
                            if ((timeLeft-GetTime())<40) then
                                polShift= 2;
                                return;
                            end
                        --end
                        --chatmsg("charge "..name);
                        if (currentCharge =="none") then
                            if (name == "Negative Charge") then
                                --chatmsg("First Charge - Negative - Left")
                                EasyThaddRightFrame:Show();
                            elseif (name == "Positive Charge") then
                                --chatmsg("First Charge - Positive - Right")
                                EasyThaddLeftFrame:Show();
                            end
                        else
                            if (currentCharge == name) then
                                --chatmsg("Same - Right");
                                EasyThaddRightFrame:Show();
                            else
                                --chatmsg("Change - Left");
                                EasyThaddLeftFrame:Show();
                            end
                        end
                        currentCharge = name;
                        arrow = 20;
					end
				end
			end
		end
	end
   end
end


function EasyThadd_OnEvent()
    if (event == "CHAT_MSG_RAID_BOSS_EMOTE") then
        if (arg1 == "The polarity has shifted!") then
            polShift= 2;
        end
    end
    
	if (event == "PLAYER_REGEN_ENABLED") then
		currentCharge = "none";
	end
end

function chatmsg(a)
	DEFAULT_CHAT_FRAME:AddMessage(a);
end

function EasyThadd_Handler(msg) 
	--if (msg == "db") then
		--for n=1,40 do
			--name, rank, iconTexture, count, debuffType, duration, timeLeft  =  UnitDebuff("player", n);
			--if (name~=nil) then
			--	chatmsg("-    "..name.." "..rank.." "..iconTexture.." "..count.." "..duration.." "..timeLeft-GetTime());
			--end
		--end
	--else
    
    if (msg == "test") then
		arrow = 5;
		etTest = 3;
		chatmsg(thaddColor..", test begining.");
	elseif (msg == "version") then
		chatmsg("Version: "..etVersion);
    elseif (msg == "phonehome" or msg =="phone home") then
        chatmsg("Not enough gold to phone home.");
    else
        chatmsg(thaddColor.." Commands")
        chatmsg("/et {test | version}");
    end
end
