﻿--[[
    Name:           Titan Carbonite
	Description:	Titan Panel interface for Carbonite.
       Carbonite is Copyright (c) 2007-2009 Carbon Based Creations, LLC
	Author:         Suddendeath2000
	Version:        3.3.1
    --]]

TPCarbonID = "Carbonite"
TPCarbonVersion = "3.3.1"
TPCarbonC1 = "|cffffffff"
TPCarbonC2 = "|cffccccff"
TPCarbonC3 = "|cff00ff00"
TPCarbonC4 = "|cffffcc00"
TitanCarboniteMinimap = true

function TitanPanelCarboniteButton_OnLoad(self)
    DEFAULT_CHAT_FRAME:AddMessage(TPCarbonC1.."Titan Panel "..TPCarbonC2.."["..TPCarbonID.."] "..TPCarbonC1.."v"..TPCarbonC2..TPCarbonVersion.." "..TPCarbonC1.."by |cff999999Suddendeath2000")
    
    this:RegisterEvent("ADDON_LOADED")
    this:RegisterEvent("PLAYER_LOGOUT")
       
    self.registry = {
		id = TPCarbonID,
	    version = TPCarbonVersion,
        menuText = TPCarbonID,        
        category = "Interface",
        tooltipTitle = TPCarbonC4..TPCarbonID,
		tooltipTextFunction = "TitanPanelCarboniteButton_GetTooltipText",
        icon = "Interface\\AddOns\\TitanCarbonite\\TitanCarbonite",
        iconButtonWidth = 16,        
        iconWidth = 16,        
        savedVariables = {
			ShowIcon = 1,
			ShowLabelText = 1,  
            ShowTooltipText = 1,
            ShowMenuOptions = 1,
            ShowAdvancedMenus = 1,  
            DisplayOnRightSide = 1,
    }} 
end

function TitanPanelCarboniteButton_GetTooltipText()   
    return TPCarbonC3.."Double Left-Click to Toggle Map\n"..TPCarbonC3.."Shift Double Left-Click to Toggle Minimize\n"..TPCarbonC3.."Alt Double Left-Click to Toggle Watch List\n"..TPCarbonC3.."Double Middle-Click to Toggle Guide\n"..TPCarbonC3.."Right-Click for Options"
  end

function TitanPanelCarboniteButton_OnDoubleClick(button)
    if button == "LeftButton" then       
      if IsShiftKeyDown() then
        Nx:GGO()["MMButWinMinimize"]=not Nx:GGO()["MMButWinMinimize"] Nx.Map.Doc:UpO()
        elseif IsAltKeyDown() then
          Nx.Que.Wat.Win1:Show(not Nx.Que.Wat.Win1:IsShown())
          else Nx.Map:ToS1(0)
    end
  end
    if button == "MiddleButton" then
      Nx.Map:GeM(1).Gui:ToS()
   end
end   

function TitanPanelCarboniteButton_MinimapButtonToggle()
    if TitanCarboniteMinimap == true then TitanCarboniteMinimap = false
      else TitanCarboniteMinimap = true
  end
    if NXMiniMapBut:IsVisible() then NXMiniMapBut:Hide()
      else NXMiniMapBut:Show()
  end      
end

function TitanPanelCarboniteButton_OnEvent(event, arg1)  
    if event == "ADDON_LOADED" and arg1 == "TitanCarbonite" then      
      TitanCarboniteMinimap = TitanCarboniteMinimapOver
  end
    if event == "PLAYER_LOGOUT" then     
      TitanCarboniteMinimapOver = TitanCarboniteMinimap
  end
end

function TitanPanelRightClickMenu_PrepareCarboniteMenu()
    local info = {}
    TitanPanelRightClickMenu_AddTitle(TPCarbonID)
    TitanPanelRightClickMenu_AddSpacer()
   
    info.text = "Help"
    info.func = function () NxOpts:Show() end
    UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
    
    info.text = "Options"
    info.func = function () Nx.Opt:Ope() end
    UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
  
    info.text = "Show Map"
    info.func = function () Nx.Map:ToS1(1) end
    UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
    
    info.text = "Show Combat Graph"
    info.func = function () Nx.NXMiniMapBut:M_OSC() end
    UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
  
    info.text = "Show Events"
    info.func = function () Nx.NXMiniMapBut:M_OSE() end
    UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
    
    info.text = "Show Favorites"
    info.func = function () Nx:NXFavKeyToggleShow() end
    UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
  
    info.text = "Show Info 1 2"
    info.func = function () Nx.Inf:ToS() end
    UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
    
    info.text = "Show Warehouse"
    info.func = function () Nx.War:ToS() end
    UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
  
    info.text = "Start Demo"
    info.func = function () Nx.NXMiniMapBut:M_OSD() end
    UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
     
    TitanPanelRightClickMenu_AddSpacer()
   
    info.text = "Show Minimap Button"
    info.checked = NXMiniMapBut:IsVisible()
    info.func = function () TitanPanelCarboniteButton_MinimapButtonToggle() end
    UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
end
    
function TitanPanelCarboniteButton_OnUpdate()
    if TitanCarboniteMinimap == true then return
      elseif NXMiniMapBut:IsVisible() then NXMiniMapBut:Hide() end
    TitanPanelButton_UpdateButton(TPCarbonID)
end