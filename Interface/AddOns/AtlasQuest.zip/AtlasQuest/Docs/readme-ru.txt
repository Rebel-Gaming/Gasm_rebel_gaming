﻿
AtlasQuest (Атлас [Задания])
Разработано Thandrenn (aka Mystery8)
Email: mystery8@gmail.com
Forum: http://www.atlasmod.com/phpBB3/viewforum.php?f=7



О Атлас [Задания]:
=================

AtlasQuest это дополнение к Atlas или AlphaMap, которое показывает список
заданий для подземелий, полей сражений и внешних рейдовых схваток с
указанием информации по прохождению и наградами за это задание. 

AtlasQuest был создан Asurn. В настоящий момент разрабатывается и
поддерживается Thandrenn (aka Mystery8).

Информация для AtlasQuest собирается "из первых рук" в игре, либо с
ресурсов: WoWhead.com (ru.WoWhead.com), Thottbot.com или WoWwiki.com.



Переводы:
=============

EN: Thandrenn  (ранее Asurn и Lothaer)
DE: Telchar и Nalumis  (ранее Asurn и Nihlo)
CN: yeachan (ранее DIY)
TW: Jill
RU: EvgeshaH (перевод до WotLK от lorientalas)



Лицензия:
========

AtlasQuest распространяется по лицензии GNU General Public License (GPL).
Для прочтения полного текста лицензии см.: GPL-v2-ru.txt