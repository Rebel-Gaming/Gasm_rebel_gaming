-- Change: Override minimap button placement

MazzleUI_Preloader["TrinketMenu"] = function()
	if (TrinketMenu and TrinketMenu.MoveMinimapButton) then
		TrinketMenu.MoveMinimapButton = function ()
    		TrinketMenu_IconFrame:ClearAllPoints()
        	TrinketMenu_IconFrame:SetPoint("LEFT","TrinketMenu_MainFrame","RIGHT",-1, -2)
        	if TrinketMenuOptions.ShowIcon=="ON" then
        		TrinketMenu_IconFrame:Show()
        	else
        		TrinketMenu_IconFrame:Hide()
        	end
        end
    end
end