MazzleUI_Preloader["AutoBar"] = function()
	if AutoBar and AutoBar.dockingFrames then
		AutoBar.dockingFrames["ChatFrame7"] = {
			text = "MazzleUI Combat Log",
			offset = { x = 0, y = 25, point = "CENTER", relative = "TOPLEFT" },
		}
	end
end