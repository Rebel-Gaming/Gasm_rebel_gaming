MazzleUI_Preloader["Antagonist"]= function()
    Antagonist.CreateAnchor = function (self, id, cRed, cGreen, cBlue, yoff)
    	local f = CreateFrame("Button", "AntagonistBar"..id, UIParent)
    	f:SetWidth(100)
    	f:SetHeight(25)
    	
    	f.owner = self
    	
    	if not self.db.profile.positions[id] then self.db.profile.positions[id] = {} end
    
    	if self.db.profile.positions[id].x and self.db.profile.positions[id].y then
    		f:ClearAllPoints()
    		f:SetPoint("TOPLEFT", UIParent, "TOPLEFT", self.db.profile.positions[id].x, self.db.profile.positions[id].y)
    	else
    		f:SetPoint("TOP", UIErrorsFrame, "BOTTOM", 0, yoff)
    	end
    	
    	f:SetScript("OnDragStart", function() this:StartMoving() end )
    	f:SetScript("OnDragStop",
    		function()
    			this:StopMovingOrSizing()
    			local _, _, _, x, y = this:GetPoint()
    			this.owner.db.profile.positions[id].x = math.floor(x)
    			this.owner.db.profile.positions[id].y = math.floor(y)
            end)
    
    	f:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background",
                                                edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
                                                tile = false, tileSize = 16, edgeSize = 16,
                                                insets = { left = 5, right =5, top = 5, bottom = 5 }})
    	f:SetBackdropColor(cRed,cGreen,cBlue,.6)
    	f:SetMovable(true)
    	f:RegisterForDrag("LeftButton")
    
    	f.Text = f:CreateFontString(nil, "OVERLAY")
    	f.Text:SetFontObject(GameFontNormalSmall)
    	f.Text:ClearAllPoints()
    	f.Text:SetTextColor(1, 1, 1, 1)
    	f.Text:SetWidth(100)
    	f.Text:SetHeight(25)
    	f.Text:SetPoint("TOPLEFT", f, "TOPLEFT")
    	f.Text:SetJustifyH("CENTER")
    	f.Text:SetJustifyV("MIDDLE")
    	f.Text:SetText("Antagonist : "..id)
    	
    	f:Hide()
    
    	return f
    end
end