MazzleUI_Preloader["ColorComboPoints"] = function()
    function CCP_QuickInitCP(name,x,y,id)
    	local buffbutton = getglobal(name);
    	local texture = getglobal(name.."_Texture");	
    	texture:SetAlpha(1);	
    	buffbutton:Hide();
    	buffbutton:SetHeight(CCP_TEXTURE_CP["CCP_TEXTURE_CP"..id.."_HEIGHT"]);
    	buffbutton:SetWidth(CCP_TEXTURE_CP["CCP_TEXTURE_CP"..id.."_WIDTH"]);
    	buffbutton:EnableMouse(false);
    	texture:SetTexture("Interface\\AddOns\\ColorComboPoints\\CustomTextures\\Cp"..id);
    end
end