MazzleUI_Preloader["sRaidFrames"] = function()
    sRaidFrames.options.args.positioning.args.predefined.validate["mazzle"] = "Mazzle"
    sRaidFrames.options.args.positioning.args.predefined.validate["mazzle125"] = "Mazzle125"
    sRaidFrames.options.args.positioning.args.predefined.validate["mazzle20"] = "Mazzle20Man"
    sRaidFrames.options.args.positioning.args.predefined.validate["mazzle20125"] = "Mazzle20Man2"
    
    sRaidFrames.PositionLayout = function (self, layout, xBuffer, yBuffer)

    	local xMod, yMod, i = 0, 0, -1
    	local frameHeight = self:GetLayout().unitframeHeight+3+self.opt.Spacing
    
    	for k,v in pairs(self.groupframes) do
    		i = i + 1
    		if layout == "horizontal" then
    			yMod = (i) * v:GetWidth()
    			xMod = 0
    			xBuffer = MazzleUI_Settings.sRaidFrames.xAnchor
    			yBuffer = MazzleUI_Settings.sRaidFrames.yAnchor
    		elseif layout == "vertical" then
    			if i ~= 0 and math.fmod(i, 2) == 0 then
    				xMod = xMod + (-1*MEMBERS_PER_RAID_GROUP*frameHeight)
    				yMod = 0
    				i = 0
    			else
    				yMod = i * v:GetWidth()
    			end
    		elseif layout == "ctra" then
    			if i ~= 0 and math.fmod(i, 2) == 0 then
    				yMod = yMod + v:GetWidth()
    				xMod = 0
    				i = 0
    			else
    				xMod = i * (-1*MEMBERS_PER_RAID_GROUP*frameHeight)
    			end
    		elseif layout == "mazzle20" then
    		    if ((i==1) or (i==3)) then yMod = MazzleUI_Settings.sRaidFrames.targetAdjust; else yMod = 0 end
    		    if (i>1)then xMod = v:GetHeight() + MazzleUI_Settings.sRaidFrames.groupSpacing; else xMod = 0 end
    			xBuffer = MazzleUI_Settings.sRaidFrames.xAnchor
    			yBuffer = MazzleUI_Settings.sRaidFrames.yAnchor
    		elseif layout == "mazzle20125" then
    		    if (i>1) then mazzleAdjust = MazzleUI_Settings.sRaidFrames.targetAdjust; else mazzleAdjust = 0 end
    			yMod = (i * v:GetWidth()) + (i * MazzleUI_Settings.sRaidFrames.groupSpacing) + mazzleAdjust
    			xMod = 0
    			xBuffer = MazzleUI_Settings.sRaidFrames.xAnchor
    			yBuffer = MazzleUI_Settings.sRaidFrames.yAnchor
    		elseif layout == "mazzle" then
    		    if (i>3) then mazzleAdjust = MazzleUI_Settings.sRaidFrames.targetAdjust; else mazzleAdjust = 0 end
    			yMod = (i * v:GetWidth()) + (i * MazzleUI_Settings.sRaidFrames.groupSpacing) + mazzleAdjust
    			xMod = 0
    			xBuffer = MazzleUI_Settings.sRaidFrames.xAnchor
    			yBuffer = MazzleUI_Settings.sRaidFrames.yAnchor
    		elseif layout == "mazzle125" then
    		    if ((i>2) and (i<=5)) then 
    		        mazzleAdjust = MazzleUI_Settings.sRaidFrames.targetAdjust; 
    		        --ace:print("group 4+ :", mazzleAdjust);
    		    elseif (i>5) then 
    		        --ace:print("group 7+")
    		        mazzleAdjust = MazzleUI_Settings.sRaidFrames.targetAdjust + MazzleUI_Settings.sRaidFrames.adjust125x; 
    		        mazzleAdjusty = MazzleUI_Settings.sRaidFrames.adjust125y; 
    		        --ace:print("group 4+ :", mazzleAdjust);
    		    else mazzleAdjust = 0; mazzleAdjusty = 0 end
    		    
    			yMod = (i * v:GetWidth()) + (i * MazzleUI_Settings.sRaidFrames.groupSpacing) + mazzleAdjust
    			xMod = mazzleAdjusty
    			xBuffer = MazzleUI_Settings.sRaidFrames.xAnchor
    			yBuffer = MazzleUI_Settings.sRaidFrames.yAnchor
    			--ace:print("Laying out at ", xMod, " ", yMod)
    		end
    
    		v:ClearAllPoints()
    		v:SetPoint("TOPLEFT", UIParent, "TOPLEFT", xBuffer+yMod, yBuffer+xMod)
    	end
    
    	self:SavePosition()
    end
    
    sRaidFrames.CreateGroupFrame = function (self, id)
    	local f = CreateFrame("Frame", "sRaidFramesGroupBase".. id, self.master)
    	f:SetHeight(self:GetLayout().headerHeight)
    	f:SetWidth(self:GetLayout().headerWidth)
    	f:SetMovable(true)
    	f:SetID(id)
    
    	f.header = CreateFrame("Frame", "sRaidFramesGroupHeader" .. id, f, "SecureRaidGroupHeaderTemplate")
    	f.header:SetAttribute("template", "sRaidFrameUnitSecure")
    	f.header.initialConfigFunction = sRaidFrames_initialHeaderConfigFunction
    
    	f.anchor = CreateFrame("Button", "sRaidFramesAnchor"..id, self.master)
    	f.anchor:SetHeight(self:GetLayout().headerHeight)
    	f.anchor:SetWidth(self:GetLayout().headerWidth)
    	f.anchor:SetScript("OnDragStart", function() if self.opt.Locked then return end if IsAltKeyDown() then self:StartMovingAll(f) end f:StartMoving() end)
    	f.anchor:SetScript("OnDragStop", function() if this.multidrag == 1 then self:StopMovingOrSizingAll() end f:StopMovingOrSizing(f) self:SavePosition() end)
    	f.anchor:EnableMouse(true)
    	f.anchor:RegisterForDrag("LeftButton")
    	f.anchor:RegisterForClicks("LeftButtonUp","RightButtonUp","MiddleButtonUp","Button4Up","Button5Up")
    	f.anchor:SetPoint("CENTER", f)
    
    	f.title = f.anchor:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    	f.title:SetJustifyH("CENTER")
    	f.title:ClearAllPoints()
    	f.title:SetPoint("CENTER", f.anchor)
    	self:SetWHP(f.title, 80, f:GetHeight(), "TOPLEFT", f, "TOPLEFT",  0, 4)
    
    	self.groupframes[id] = f
    end
end