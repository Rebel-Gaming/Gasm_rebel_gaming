MazzleUI_Preloader["sct_cooldowns"] = function()
    function sctc_OnLoad()
    	this:RegisterEvent("VARIABLES_LOADED");
    	this:RegisterEvent("PLAYER_ENTERING_WORLD");
    
    	SLASH_SCTCCHAT1 = "/sctcooldowns";
    	SLASH_SCTCCHAT2 = "/sctc";
    	SlashCmdList["SCTCCHAT"] = function(msg)
    		sctc_ChatHandler(msg);
    	end
    	sctc_Enable()
    end
    function sctc_Enable()
    	sctcFrame:RegisterEvent("SPELL_UPDATE_COOLDOWN");
    	sctcFrame:RegisterEvent("SPELLS_CHANGED");
        sctcFrame:SetScript("OnUpdate", sctc_OnUpdate)
    end
    
    function sctc_Disable()
    	sctcFrame:UnregisterEvent("SPELL_UPDATE_COOLDOWN");
    	sctcFrame:UnregisterEvent("SPELLS_CHANGED");
        sctcFrame:SetScript("OnUpdate", nil)
    end
    
    function sctc_OnUpdate(elapse)

        elapsed = arg1
    	if ((sctcVars.elapsed or 1) >= 1) then
    		sctcVars.elapsed = 0
    
        	for key, val in pairs(sctcVars.spells) do
        		local name = GetSpellName(val, BOOKTYPE_SPELL);
        		if (sctcVars["cooldowns"][name] and not sctcOptions["disabled"][name]) then
        			local startTime, duration, flag = GetSpellCooldown(val, BOOKTYPE_SPELL);
        			local found = false;
        			local group;
        			for key in pairs(SCTC_GROUPS) do	sctc_debugp("Checking for match in group: "..key);
        				for val in pairs(SCTC_GROUPS[key]) do
        					if (name == SCTC_GROUPS[key][val]) then	sctc_debugp("Match found: "..SCTC_GROUPS[key][val]);
        						found = true;
        						group = key;
        					end
        				end
        			end
        			if (sctcOptions["warning"] ~= nil) then
        				local timeleft;
        				timeleft = floor(sctcVars["cooldowns"][name] + duration - GetTime());
        				if (timeleft == sctcOptions["warning"] and sctcVars["warnings"][name]) then sctc_debugp("Time left: "..timeleft);
        					if (found) then
        						--SCT_Display(string.format(sctcOptions["wformat"], group), sctcOptions["color"], sctcOptions["crit"]);
        						SCT:DisplayMessage(string.format(sctcOptions["wformat"], group), sctcOptions["color"])
        						for key, val in pairs(SCTC_GROUPS[group]) do	sctc_debugp("Clearing warning: "..val);
        							sctcVars["warnings"][val] = nil;
        						end
        					else
        						--SCT_Display(string.format(sctcOptions["wformat"], name), sctcOptions["color"], sctcOptions["crit"]);
        						SCT:DisplayMessage(string.format(sctcOptions["wformat"], name), sctcOptions["color"])
        						sctcVars["warnings"][name] = nil;
        					end
        				end
        			end
        			if (duration == 0) then	sctc_debugp(name.."'s duration is 0");
        				if (found) then
        					--SCT_Display(string.format(sctcOptions["format"], group), sctcOptions["color"], sctcOptions["crit"]);
    						SCT:DisplayMessage(string.format(sctcOptions["format"], group), sctcOptions["color"])
        					for key, val in pairs(SCTC_GROUPS[group]) do	sctc_debugp("Clearing cooldown: "..val);
        						sctcVars["cooldowns"][val] = nil;
        					end
        				else
        					--SCT_Display(string.format(sctcOptions["format"], name), sctcOptions["color"], sctcOptions["crit"]);
    						SCT:DisplayMessage(string.format(sctcOptions["format"], name), sctcOptions["color"])
        					sctcVars["cooldowns"][name] = nil;
        				end
        				sctcVars.numCds = sctcVars.numCds - 1;
        			end
        		end
        	end
    	else
    		sctcVars.elapsed = sctcVars.elapsed + elapsed
    	end
    end

end