MazzleUI_Preloader["MovableBags"] = function()
	MovableBags_DefaultPositions = {
	    [-2] = { "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -255, 895 },
	    [0] = { "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -70, 520 },
	    [1] = { "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -255, 520 },
	    [2] = { "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -440, 520 },
	    [3] = { "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -70, 760 },
	    [4] = { "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -255, 760 },
	    [5] = { "TOPLEFT", "UIParent", "TOPLEFT", 400, -120 },
	    [6] = { "TOPLEFT", "UIParent", "TOPLEFT", 590, -120 },
	    [7] = { "TOPLEFT", "UIParent", "TOPLEFT", 400, -340 },
	    [8] = { "TOPLEFT", "UIParent", "TOPLEFT", 590, -340 },
	    [9] = { "TOPLEFT", "UIParent", "TOPLEFT", 400, -560 },
	    [10] = { "TOPLEFT", "UIParent", "TOPLEFT", 590, -560 },
	    [11] = { "TOPLEFT", "UIParent", "TOPLEFT", 780, -120 },
	};
    function MovableBags_SlashHandler(arg)
    	arg = string.lower(arg);
    	
    	if (arg == "lock") then
    		MovableBags_Config[MovableBags_CurrentChar].Mode = "Locked";
    		MovableBags_UpdateVisible();
    		DEFAULT_CHAT_FRAME:AddMessage("Bags are now LOCKED");
    	elseif (arg == "unlock") then
    		MovableBags_Config[MovableBags_CurrentChar].Mode = "Movable";
    		MovableBags_UpdateVisible();
    		DEFAULT_CHAT_FRAME:AddMessage("Bags are now UNLOCKED");
    	elseif (arg == "reset") then
    		for i=MOVABLEBAGS_LOWID,MOVABLEBAGS_HIGHID,1 do
    			local mover = getglobal("Bag"..i.."Mover");
    			local pos = MovableBags_DefaultPositions[i];
    			mover:ClearAllPoints();
    			mover:SetPoint(pos[1],pos[2],pos[3],pos[4],pos[5],pos[6], pos[7]);
    			mover:SetUserPlaced(true)
    		end
    	elseif (arg == "lockall") then
    		for char_name in MovableBags_Config do
    			MovableBags_Config[char_name].Mode = "Locked";
    			MovableBags_UpdateVisible();
    		end
    		DEFAULT_CHAT_FRAME:AddMessage("Bags for all chars are now LOCKED");
    	elseif (arg == "unlockall") then
    		for char_name in MovableBags_Config do
    		  MovableBags_Config[char_name].Mode = "Movable";
    			MovableBags_UpdateVisible();
    		end
    		DEFAULT_CHAT_FRAME:AddMessage("Bags for all chars are now UNLOCKED");
    	else
    		DEFAULT_CHAT_FRAME:AddMessage("Usage: /movablebags unlock | lock | unlockall | lockall | reset");
    		DEFAULT_CHAT_FRAME:AddMessage("unlock lets you move the bags around independantly of each other (default)");
    		DEFAULT_CHAT_FRAME:AddMessage("lock locks the bags into the position you last moved them to");
    		DEFAULT_CHAT_FRAME:AddMessage("(un)lockall locks/unlocks bags for all characters, including the default for new chars");
    		DEFAULT_CHAT_FRAME:AddMessage("Reset will return all bags to the default positions");
    		DEFAULT_CHAT_FRAME:AddMessage("Bags are currently "..MovableBags_Config[MovableBags_CurrentChar].Mode);
    	end
    
    end
end
