MazzleUI_Preloader["cyCircled"] = function()
    local addonName = "MazzleUI"
    
    cyCircled_MazzleUI = cyCircled:NewModule(addonName)
    
    function cyCircled_MazzleUI:AddonLoaded(addon)
    	self.db = cyCircled:AcquireDBNamespace(addonName)
    	cyCircled:RegisterDefaults(addonName, "profile", {
    		["Main"] = true,
    	})
    	
    	self:SetupElements()
    	self:OnEnable()
    end
    
--    function cyCircled_MazzleUI:ApplyCustom()
--    	
--    end
    
    function cyCircled_MazzleUI:GetElements()
    	return {
    		["Main"] = true,
    	}
    end
    
    function cyCircled_MazzleUI:SetupElements()
    	self.elements = {
    		["Main"] = { 
   			args = {
    				button = { width = 35, height = 35, },
    			},
    			elements = {},
    		},
    	}
    	
    	for i=1, 32, 1 do
    		table.insert(self.elements["Main"].elements, format("MazzleContextMenuButton%d", i))
    	end
    	
    end
end