MazzleUI_Preloader["AMP"] = function()
	AMPFrame:SetScale(3);
	AMPFrame:ClearAllPoints();
	AMPFrame:SetPoint("TOP", "UIParent", "TOP", 0, -50);
	AMP_Text:SetText("You have no missed messages.")
    function AMP_Clear()
    	AMP_Missed_Tells = { }
    	AMP_Missed_Auctions = { }
    	AMP_Missed_Authors = { }
    	AMP_Text:SetText("You have no missed messages.")
    end
end