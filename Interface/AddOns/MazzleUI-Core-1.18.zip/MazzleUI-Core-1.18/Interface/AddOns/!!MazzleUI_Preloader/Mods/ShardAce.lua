MazzleUI_Preloader["ShardAce"] = function()
    function ShardAce:MoveButtons()
    	ShardAceCount:ClearAllPoints()
    	ShardAceSoul:ClearAllPoints()
    	ShardAceSpell:ClearAllPoints()
    	ShardAceFire:ClearAllPoints()
    	ShardAceHealth:ClearAllPoints()
        ShardAceFire:Hide()
    end
    ShardAce.DoButtonsOriginal = ShardAce.DoButtons
    ShardAce.DoButtons = function()
        ShardAce:DoButtonsOriginal()
        ShardAceFire:Hide()
        ShardAceFireGlow:Hide()
    end
end