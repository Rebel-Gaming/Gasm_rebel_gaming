MazzleUI_Preloader["oRA2_Optional"] = function()
	if (oRAOMainTank and oRAOMainTank.SetupFrames) then
		local L = AceLibrary("AceLocale-2.2"):new("oRAOMainTank")
		oRAOMainTank.SetupFrames = function (self)
        	local f = CreateFrame("Frame", "oRA_MainTankFrameMtMain", UIParent)
        	f:Hide()
        	f:SetMovable(true)
        	f:SetScript("OnUpdate", function() self:OnUpdate() end)
        	f:SetWidth(150)
        	f:SetHeight(13)
        	f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
        	f:SetAlpha(self.db.profile.alpha)
        	f:SetScale(self.db.profile.scale)
        	f:EnableMouse(true)
        	f:SetMovable(true)
        	f:RegisterForDrag("LeftButton")
        	f:SetScript("OnDragStart", function() if not InCombatLockdown() and IsAltKeyDown() then this:StartMoving() end end)
        	f:SetScript("OnDragStop", function() if not InCombatLockdown() then this:StopMovingOrSizing() self:SavePosition() end end)
        
        	f.text = f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        	f.text:SetText(L["MainTank"])
        	f.text:SetAllPoints(f)
        
        	f.update = 0
        	self.mainframe = f
        	
        	self.header = CreateFrame("Frame", "oRAMainTank",self.mainframe,"SecureRaidGroupHeaderTemplate")
        	
        	local f = self.header
        	
        	f:SetFrameStrata("BACKGROUND")
        	f:SetWidth(150)
        	f:SetHeight(13)
        	f:SetAttribute("minheight",13)
        	f:SetAttribute("template","oRAOMainTankTemplate")
        	
        	self:SetSecureAttributes( f )
        	
        	f:Show()
        	
        	self:RestorePosition()
        end
    end
end