MazzleUI_Preloader["oCD"] = function()
	--[[ Vars - Shared
	]]
	local cd, bar, tex, name
	local G = AceLibrary("Gratuity-2.0")
	
	--[[ Whitelist - Shared
	]]
	local Shared = {
		["PaperDollFrame"] = function(a1)
			local sName, _, _, _, _, _, _, _, _, sTexture = GetItemInfo(select(3, string.find(GetInventoryItemLink("player", a1:GetParent():GetID()), "(%d+):")))
			return sName, sTexture
		end,
		["SpellBookFrame"] = function(a1)
			return GetSpellName(SpellBook_GetSpellID(a1:GetParent():GetID()), BOOKTYPE_SPELL)
		end
	}

	if(IsAddOnLoaded("Bongos_ActionBar")) then
	--[[ Support - Bongos
		Functions
	]]
		local BongosAction = function(a1)
				G:SetAction(a1:GetParent():GetPagedID())
				return G:GetLine(1)
		end
	
	--[[ Support - Bongos
		Whitelist
	]]
		local Bongos = {
			["BClassBar"] = function(a1)
				G:SetShapeshift(a1:GetParent():GetPagedID())
				return G:GetLine(1)
			end,
			["BPetBar"] = function(a1)
				return GetPetActionInfo(a1:GetParent():GetID())
			end
		}
	
		for i=1, ActionBar.GetNumber() do
			Bongos["ActionBar"..i] = BongosAction
		end
	
	--[[ Support - Bongos
		Hook
	]]
		function oCD:CooldownFrame_SetTimer(this, start, duration, enable)
			if(start > 0 and duration > 0 and enable > 0) then
				bar = tostring(this:GetParent():GetParent():GetParent():GetName())
				if(Shared[bar]) then
					name, tex = Shared[bar](this)
					cd = duration - (GetTime() - start)
					oCD:StartBar(name, cd, name, tex)
				elseif(Bongos[bar]) then
					name = Bongos[bar](this)
					if(name and self.spells[name]) then
						cd = duration - (GetTime() - start)
						self:StartBar(name, cd, name, self.spells[name])
					end
				end
			end
		end
	end
end