MazzleUI_Preloader["SmartDebuff"] = function()
    function SMARTDEBUFF_OnLoad()
    
        SMARTDEBUFF_OnEnable()
        --One of them allows SmartDebuff to be closed with the Escape key
        tinsert(UISpecialFrames, "SmartDebuffOF");
        UIPanelWindows["SmartDebuffOF"] = nil;
        
        SlashCmdList["SMARTDEBUFF"] = SMARTDEBUFF_command;
        SLASH_SMARTDEBUFF1 = "/sdb";
        SLASH_SMARTDEBUFF2 = "/smartdebuff";
        
        SlashCmdList["SMARTDEBUFFOPTIONS"] = SMARTDEBUFF_ToggleOF;
        SLASH_SMARTDEBUFFOPTIONS1 = "/sdbo";
        
        SlashCmdList["SMARTDEBUFFRELOAD"] = function(msg) ReloadUI(); end;
        SLASH_SMARTDEBUFFRELOAD1 = "/rui";  
    end

    function SMARTDEBUFF_OnEnable()
        SmartDebuffFrame:RegisterEvent("ADDON_LOADED");
        SmartDebuffFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
        SmartDebuffFrame:RegisterEvent("UNIT_NAME_UPDATE");
        
        SmartDebuffFrame:RegisterEvent("PARTY_MEMBERS_CHANGED");
        SmartDebuffFrame:RegisterEvent("RAID_ROSTER_UPDATE");
        SmartDebuffFrame:RegisterEvent("PLAYER_REGEN_ENABLED");
        SmartDebuffFrame:RegisterEvent("PLAYER_REGEN_DISABLED");
        
        SmartDebuffFrame:RegisterEvent("LEARNED_SPELL_IN_TAB");
        SmartDebuffFrame:RegisterEvent("UNIT_PET");
        SmartDebuffFrame:SetScript("OnUpdate", SMARTDEBUFF_OnUpdate)
    end

    function SMARTDEBUFF_OnDisable()
        SmartDebuffFrame:UnregisterEvent("ADDON_LOADED");
        SmartDebuffFrame:UnregisterEvent("PLAYER_ENTERING_WORLD");
        SmartDebuffFrame:UnregisterEvent("UNIT_NAME_UPDATE");
        
        SmartDebuffFrame:UnregisterEvent("PARTY_MEMBERS_CHANGED");
        SmartDebuffFrame:UnregisterEvent("RAID_ROSTER_UPDATE");
        SmartDebuffFrame:UnregisterEvent("PLAYER_REGEN_ENABLED");
        SmartDebuffFrame:UnregisterEvent("PLAYER_REGEN_DISABLED");
        
        SmartDebuffFrame:UnregisterEvent("LEARNED_SPELL_IN_TAB");
        SmartDebuffFrame:UnregisterEvent("UNIT_PET");
        SmartDebuffFrame:SetScript("OnUpdate", nil)
    end
end