MazzleUI_Preloader["SimpleCombatLog"] = function()
    local dewdrop = AceLibrary("Dewdrop-2.0")
    function SimpleCombatLog:LoadSettingMenu_Mazzle(id, moveFrame)
    
    	--dewdrop:Register(moveFrame, 'dontHook', true, 'children', function(level, value) SimpleCombatLog:OptionOpen(id, level, value) end )
    	dewdrop:Register(moveFrame, 
    		'children', function(level, value) self:MenuSettings(id, level, value) end, 
    		'dontHook', true
    	)
    	dewdrop:Open(moveFrame)
    end

end