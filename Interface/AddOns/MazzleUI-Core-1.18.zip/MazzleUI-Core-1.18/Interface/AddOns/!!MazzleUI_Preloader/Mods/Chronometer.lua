MazzleUI_Preloader["Chronometer"]= function()
    local BS = AceLibrary("Babble-Spell-2.2")

    function Chronometer:MageSetup2()
    	local _, eclass = UnitClass("player")
    	if eclass ~= "MAGE" then return end
    
    	self:AddGroup(1, true, "MAGENTA")
    	self:AddTimer(self.SPELL, BS["Summon Water Elemental"], 45, 0,0,1)
    end
    table.insert(Chronometer.dataSetup, Chronometer.MageSetup2)
end