local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")

f:SetScript("OnEvent", function(self, event, addon)
	if MazzleUI_Preloader[addon] then MazzleUI_Preloader[addon]() end
end)

local lao = function (addon, ...)
--	local rv={lao(addon)}
	if MazzleUI_Preloader[addon] then MazzleUI_Preloader[addon]() end
--	return unpack(rv)
end
hooksecurefunc("LoadAddOn", lao)