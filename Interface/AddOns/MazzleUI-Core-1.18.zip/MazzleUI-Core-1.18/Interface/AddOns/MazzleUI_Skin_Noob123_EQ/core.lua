function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Skin_Noob123_EQ\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Skin_Noob123_EQ\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Skin_Noob123_EQ\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Skin_Noob123_EQ\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Skin_Noob123_EQ\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Skin_Noob123_EQ\\MazzleUICastingBarBorder",
            chatborder = "Interface\\AddOns\\MazzleUI_Skin_Noob123_EQ\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Skin_Noob123_EQ\\MazzleUIMinimapBorder",
        },
    }
end