function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_BloodElf\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_BloodElf\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_BloodElf\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_BloodElf\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_BloodElf\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_BloodElf\\MazzleUICastingBarBorder",
            chatborder = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_BloodElf\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_BloodElf\\MazzleUIMinimapBorder",
        },
    }
end