﻿
local L = AceLibrary("AceLocale-2.2"):new("gfxToggle")

L:RegisterTranslations("esES", function() return {

["gfxToggle2 Options"] = "Opciones de gfxToggle2",
["Attention! Don't touch the RestartGx toggle if you're running WoW on a linux box. It might crash your client!"] =
	"\194\161Atenci\195\179n! No uses la opci\195\179n de Reinciar Gr\195\161ficos si est\195\161s haciendo funcionar WoW en linux. \194\161Puede colgar tu cliente!",
["Save"] = "Guardar",
["Saves your custom settings."]= "Guarda tus ajustes personalizados",
["Low"] = "Bajo",
["Medium"] = "Medio",
["High"] = "Alto",
["Saves settings for: "] = "Guardar ajustes para: ",
["Saved settings for: "] = "Ajustes guardados para: ",
["Change settings in WoW Graphic-Options (World Appearance, Shaders and Misc). After that click on the Ok-Button and save settings."] =
	"Cambia los ajustes en las Opciones de Video de WoW (Apariencia del Mundo, Shaders y otros). Despu\195\169s pulsa en el bot\195\179n de Aceptar y guarda los ajustes.",
["Auto"] = "Autom\195\161tico",
["Auto-Mode is set to: %s"] = "Modo Autom\195\161tico est\195\161 establecido en: %s",
["Checks your zone database and toggles the saved settings automatically."] =
	"Comprueba tu base de datos de zonas y activa de forma autom\195\161tica los ajustes guardados",
["Does allow the use of the settings: %s."] = "Permite usar los ajustes: %s",
["Toggle"] = "Cambiar gr\195\161ficos",
["Toggles between %s, %s (if turned on by '/gfxt medium') and %s."] =
	"Cambia entre %s, %s (si se activa con '/gfxt medium') y %s",
["Add "] = "A\195\177adir ",
["zone"] = "zona",
["Adds zone for setting: "] = "A\195\177ade la zona a los ajustes: ",
["Adds zone for selected setting."] = "A\195\177ade la zona a los ajustes seleccionados",
["Adds the specified zone."] = "A\195\177ade la zona especificada",
["Adds the current zone. "] = "A\195\177ade la zona actual",
["name"] = "nombre",
["this"] = "\195\169sta",
["Delete "] = "Eliminar ",
["All"] = "Todo",
["Deletes a zone from database."] = "Elimina una zona de la base de datos",
["Deletes current zone."] = "Elimina la zona actual",
["Deletes specified zone."] = "Elimina la zona especificada",
["current"] = "actual",
["Deletes all zones."] = "Elimina todas las zonas",
["List"] = "Lista de Zonas",
["Lists all saved zones."] = "Muestra una lista con todas las zonas guardadas",
["Mute"] = "Enmudecer",
["Toggles screen messages."] = "Determina si se muestran los mensajes en la pantalla",
["M2Faster"] = "M2Faster",
["Toggle Blizzard's M2Faster-Function to improve performance in crowded areas. Default is: |cff00ff00On|r"] =
	"Determina si se usa la funci\195\179n M2Faster de Blizzard para mejora el rendimiento en \195\161reas muy pobladas. El valor por defecto es: |cff00ff00Activado|r",
["Delay"] = "Retraso",
["Sets a delay for the Auto-Mode. (Default: [|cfff5f5305|r] seconds)"] =
	"Establece el retraso para el Modo Autom\195\161tico. (El valor por defecto es: [|cfff5f5305|r] segundos)",
["RestartGx"] = "Reiniciar Gr\195\161ficos",
["Allows re-initializing of the graphics driver (needed for VSync)."] =
	"Permite reinicializar el driver de gr\195\161ficos (necesario para Sincronizaci\195\179n Vertical).",
["To switch VSync, Tripplebuffer and Smooth Mouse the game has to restart the graphics. While it does the restart, it'll switch to the desktop and back to game after a duration of 1-2 seconds. By using this command you allow switching these settings. Default is: |cffff5050Off|r."] =
	"Para activar Sincronizaci\195\179n Vertical, Memoria buffer triple y Fluidez de rat\195\179n el juego ha de reiniciar los gr\195\161ficos. Mientras reinicia, cambiar\195\161 al escritorio y volver\195\161 al juego tras 1 o 2 segundos. Al usar esta opci\195\179n permites cambiar esos ajustes. El valor por defecto es: |cffff5050Desactivado|r.",
["Reset"] = "Reestablecer",
["Resets all settings to their defaults."] = "Reestablece todos los ajustes a sus valores por defecto",
["All settings have been reset to their defaults."] =
	"Todos los ajustes han sido reestablecidos a sus valores por defecto",
["Short Text"] = "Texto Abreviado",
["Toggles text display"] = "Determina c\195\179mo se muestra el texto",

-- Chat Options --
["GFX set to:"] = "Gr\195\161ficos establecidos a:",
["|cff00ff00Low|r"] = "|cff00ff00Bajo|r",
["|cffffff00Medium|r"] = "|cffffff00Medio|r",
["|cffff0000High|r"] = "|cffff0000Alto|r",
["(default) \nUse '/gfxt save' to save custom settings."] =
	"(por defecto) \nUsa '/gfxt save' para guardar ajustes personalizados",
["Chat_Exists"] = "La entrada ya existe. Por favor, elim\195\173nala antes.",
["Chat_NotThere"] = "Entrada no encontrada.",
["Chat_NoEntry"] = "No se han encontrado entradas.",
["Chat_Added"] = "' ha sido a\195\177adido.",
["Chat_MedAdd"] = "Por favor, ten en cuenta que: Auto-Cambiar tan solo cambiar\195\161 a Medio cuando hayas activado previamente la opci\195\179n 'medio'.",
["Chat_Deleted"] = "' se ha eliminado.",
["Chat_DelAll"] = "Todas las entradas han sido eliminadas.",
["Chat_Found"] = " Entradas encontradas.",
["Chat_FoundOne"] = " Entrada encontrada.",
["Chat_ZonesRestored"] = "Base de datos de zonas recuperada.",
["Chat_ZoneDb"] = "Zonas guardadas",
["settings"] = "ajustes",
["zones"] = "zonas",

-- FuBar Plug locals
["Are you sure you want to reset all your %s for %s"] =
	"\194\191Est\195\161s seguro de querer reestablecer todos tus %s para %s?",
["- Auto"] = "- Auto",
["- A"] = "- A",
[" - M"] = " - M",
["|cffffffffN|r"] = "|cffffffffN|r",
["|cffffffffNormal|r"] = "|cffffffffNormal|r",
["|cff00ff00L|r"] = "|cff00ff00B|r",
["|cffffff00M|r"] = "|cffffff00M|r",
["|cffff0000H|r"] = "|cffff0000A|r",
["Manual"] = "Manual",
["Current zone:"] = "Zona actual:",
["Zones: "] = "Zonas: ",
["Short Text"] = "Texto Abreviado",
["Left mousebutton for low/(medium)/high. Shift + left mousebutton for auto/manual."] =
	"Clic para bajo/(medio)/alto. Clic+May\195\186sculas para autom\195\161tico/manual",
["Left-click on current zone adds zone to 'Low', Shift + left-click adds zone to 'Medium'. Left-click on 'Low' or 'Medium' zone deletes it."] =
	"Clic a\195\177ade la zona actual a 'Bajo', Clic+May\195\186sculas a\195\177ade la zona a 'Medio'. Hacer clic en una zona en 'Bajo' o 'Medio' la elimina.",

-- Bindings
["gfxToggle2"] = "gfxToggle2",
["Toggle graphics"] = "Cambiar gr\195\161ficos",
["Auto-Mode"] = "Modo autom\195\161tico",

-- Ace Globals
["|cff00ff00On|r"] = "|cff00ff00Activado|r",
["|cffff5050Off|r"] = "|cffff5050Desactivado|r",
["|cfff5f530%s|r"] = "|cfff5f530%s|r",

} end)
