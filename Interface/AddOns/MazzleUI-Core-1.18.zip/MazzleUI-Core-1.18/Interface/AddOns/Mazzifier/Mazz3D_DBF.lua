-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

Mazz3D_ImportVersion = 1.1

function Mazzifier:Mazzify_MazzleUI()

Mazz3D_ModelDB = {
	["creature.dragonspawn.dragonspawnoverlord"] = 433,
	["creature.twinemperor.twinemperor"] = 2,
	["creature.medivh.medivh"] = 3,
	["creature.highelf.highelffemale_mage"] = 4,
	["creature.trex.trex"] = 5,
	["creature.spells.sentrytotem"] = 6,
	["creature.murloc.babymurloc"] = 7,
	["creature.skeletonnaked.skeletonnaked"] = 8,
	["creature.orcmalekid.orcmalekid"] = 9,
	["creature.rockflayer.rockflayercrystal"] = 388,
	["creature.invisiblestalker.invisiblestalker"] = 11,
	["creature.moarg.moarg4"] = 12,
	["creature.ghoul.ghoul"] = 13,
	["creature.zippelin.zippelin"] = 14,
	["creature.reindeer.reindeer"] = 15,
	["creature.humanmalewarriorheavy.humanmalewarriorheavy_ghost"] = 16,
	["creature.netherdrakonidboss.netherdrakonidboss"] = 17,
	["creature.darkhound.darkhound"] = 18,
	["creature.mounteddeathknight.mounteddeathknight_zeliek"] = 19,
	["creature.satyr.satyr"] = 485,
	["creature.horderider.horderider"] = 21,
	["creature.parrot.parrot"] = 22,
	["character.bloodelf.male.bloodelfmale"] = 474,
	["creature.rockflayer.rockflayer"] = 24,
	["creature.dwarfmalewarriorlight.dwarfmalewarriorlight_ghost"] = 25,
	["creature.arakkoa.arakkoa_sage02"] = 26,
	["creature.voidlord.voidlord"] = 27,
	["creature.gnomerocketcar.gnomerocketcar"] = 28,
	["creature.felbat.batrider"] = 469,
	["creature.orca.orca"] = 30,
	["creature.ancientofarcane.ancientofarcane"] = 31,
	["creature.spiritofredemption.spiritofredemption"] = 32,
	["creature.cryptscarab.crypt_scarab"] = 33,
	["creature.dragonfootsoldier.dragonfootsoldier"] = 34,
	["creature.shivan.shivanred"] = 35,
	["creature.snowman.snowman"] = 36,
	["creature.crackelf.crackelfmale"] = 37,
	["creature.cloud.cloudswampgas"] = 38,
	["creature.gorilla.gorilla"] = 39,
	["creature.centaur.centaurcaster"] = 40,
	["creature.humanmalepirateswashbuckler.humanmalepirateswashbuckler"] = 41,
	["creature.highelf.highelfmale_priest"] = 42,
	["creature.gorilla.gorillapet"] = 43,
	["creature.sporeling.sporeling"] = 44,
	["creature.felorc.felorc_sword"] = 45,
	["creature.rabbit.rabbitgold"] = 46,
	["creature.humanmalewarriorlight.humanmalewarriorlight"] = 456,
	["creature.ghost.ghost"] = 48,
	["creature.lostone.lostone"] = 441,
	["creature.warpstorm.warpstorm_xlarge"] = 50,
	["creature.fungalgiant.fungalgiantgreen"] = 51,
	["creature.silithid.silithid"] = 52,
	["creature.ogre.ogremage"] = 472,
	["creature.diemetradon.diemetradon"] = 54,
	["creature.diablo.diablofunsized"] = 436,
	["creature.shade.shade"] = 56,
	["creature.windserpentoutland.windserpentoutland"] = 57,
	["creature.ancientofwar.ancientofwar"] = 58,
	["creature.etherial.etherialblack"] = 59,
	["creature.ent.ent"] = 60,
	["creature.moth.moth"] = 61,
	["creature.snake.snake"] = 62,
	["character.felorc.male.felorcmaleaxe"] = 63,
	["creature.hyena.hyena"] = 64,
	["creature.titanfemale.titanfemale"] = 65,
	["creature.ravengod.ravengod"] = 66,
	["character.nightelf.female.nightelffemale"] = 67,
	["creature.humanmalewarriormedium.humanmalewarriormedium"] = 68,
	["creature.stormcrowdruid.stormcrowdruid"] = 69,
	["creature.kodobeast.kodobeastpvpt2"] = 70,
	["creature.gryphon.gryphon"] = 71,
	["creature.bonegolem.bonegolem"] = 72,
	["creature.humlcitizenmid.humlcitizenmid"] = 73,
	["creature.tarantula.tarantula"] = 74,
	["creature.questobjects.creature_nagadistiller"] = 75,
	["creature.bear.bear"] = 76,
	["creature.demonhunter.demonhunter"] = 429,
	["creature.cockatrice.cockatricemount"] = 78,
	["creature.mounteddeathknight.mounteddeathknight"] = 79,
	["creature.spells.airelementaltotem"] = 80,
	["creature.quirajprophet.quirajprophet"] = 81,
	["creature.band.bandbloodelfmale"] = 399,
	["creature.rat.rat"] = 457,
	["creature.kaelthas.kaelthas"] = 84,
	["creature.boneworm.boneworm"] = 85,
	["creature.epicdruidflightalliance.epicdruidflightalliance"] = 86,
	["creature.spells.serpent_totem"] = 87,
	["creature.ridingnetherray.ridingnetherray"] = 389,
	["creature.cocoon.cocoon"] = 89,
	["creature.etherialrobeb.etherialrobeb"] = 90,
	["creature.chimeraoutland.chimeraoutland"] = 467,
	["creature.undeadhorse.undeadhorse"] = 92,
	["creature.felreaver.bloodreaver"] = 93,
	["character.draenei.female.draeneifemale"] = 94,
	["creature.humanmalecaster.humanmalecaster"] = 95,
	["creature.skunk.skunk"] = 96,
	["character.naga_.male.naga_male"] = 97,
	["creature.firefly.fireflypurple"] = 98,
	["creature.spells.draeneitotem_water"] = 99,
	["creature.giantspider.giantspider"] = 440,
	["creature.beholder.beholder"] = 101,
	["creature.spells.manatotem"] = 102,
	["creature.humanmalekid.humanmalekid_ghost"] = 103,
	["creature.questobjects.creature_powercrystal"] = 104,
	["creature.direwolf.pvpridingdirewolf"] = 105,
	["character.draenei.male.draeneimale"] = 106,
	["creature.bogbeast.bogbeast"] = 107,
	["creature.ram.pvpridingram"] = 108,
	["creature.crab.crab"] = 109,
	["creature.velen.velen"] = 110,
	["creature.basiliskoutland.basilisk_outland"] = 111,
	["creature.nagalordmale.nagalordmale"] = 112,
	["creature.madscientist.madscientist"] = 113,
	["creature.kodobeastpack.kodobeastpack"] = 114,
	["creature.shade.shadewhite"] = 115,
	["creature.illidan.illidan"] = 116,
	["creature.ridinghorse.ridinghorsepvpt2"] = 117,
	["creature.zombie.zombiesword"] = 118,
	["creature.felreaver.felreaver"] = 119,
	["creature.titanmale.titanmale"] = 120,
	["creature.mountaingiantcrystalogrila.mountaingiantcrystalogrila"] = 121,
	["creature.goblin.goblinshredder"] = 122,
	["creature.dragonwhelpoutland.dragonwhelpoutland"] = 123,
	["creature.etherial.etherialwhite"] = 124,
	["creature.spells.eyeofkilrog"] = 125,
	["creature.spells.firelighttotem"] = 126,
	["creature.waterelemental.waterelemental"] = 127,
	["creature.firefly.fireflygreen"] = 128,
	["creature.epicdruidflighthorde.epicdruidflighthorde"] = 129,
	["creature.hufmmerchant.hufmmerchant"] = 130,
	["creature.threshadon.threshadon"] = 131,
	["creature.voidwraith.voidwraith"] = 132,
	["creature.warhorse.pvpwarhorseevil"] = 133,
	["creature.clawofkathune.clawofkathune"] = 422,
	["creature.boar.boartruesilver"] = 135,
	["creature.netherdrake.netherdrakeoutland"] = 136,
	["creature.haremmatron.haremmatron"] = 395,
	["creature.lessermanafiend.lessermanafiend_red"] = 138,
	["creature.shark.hammerhead"] = 139,
	["character.tauren.female.taurenfemale"] = 140,
	["creature.arcanetitan.arcanetitan"] = 141,
	["creature.humanmaleblacksmith.humanmaleblacksmith"] = 142,
	["creature.babyhawkstrider.babyhawkstrider"] = 143,
	["creature.troll.troll"] = 144,
	["character.dwarf.female.dwarffemale"] = 145,
	["creature.deer.deer"] = 146,
	["creature.draeneifemalekid.draeneifemalekid"] = 147,
	["creature.serpent.serpentruby"] = 148,
	["creature.humanmalepirateswashbuckler.humanmalepirateswashbuckler_ghost"] = 149,
	["creature.impoutland.impoutland"] = 150,
	["creature.gnomespidertank.gnomebombot"] = 151,
	["creature.voidterror.voidterror"] = 152,
	["creature.moargminion.moargminion"] = 153,
	["creature.dragonspawn.dragonspawngreater"] = 154,
	["creature.shivan.shivan"] = 155,
	["creature.broom.be_broom01"] = 156,
	["creature.cockatrice.cockatriceelite"] = 157,
	["creature.lessermanafiend.lessermanafiend_white"] = 158,
	["creature.elementalearth.elementalearth"] = 159,
	["creature.obsidiandestroyer.obsidiandestroyer"] = 160,
	["creature.felorc.felorc_axe"] = 427,
	["creature.wrathguard.wrathguard"] = 162,
	["creature.quillboar.quillboarcaster"] = 163,
	["creature.gnollcaster.gnollcaster"] = 164,
	["creature.mounteddeathknight.unmounteddeathknight"] = 165,
	["character.dwarf.male.dwarfmale"] = 166,
	["creature.lord kezzak.lordkezzak"] = 167,
	["creature.humanmaleguard.humanmaleguard"] = 403,
	["creature.naaru.naarublue"] = 169,
	["character.skeleton.female.skeletonfemale"] = 170,
	["creature.airelemental.airelemental"] = 171,
	["creature.direwolf.direwolf"] = 172,
	["creature.felorcboss.felorcwarriorboss"] = 173,
	["creature.dragondarkshade.dragondarkshade"] = 174,
	["creature.horse.horse"] = 175,
	["creature.spells.flameturret"] = 176,
	["creature.pig.pig"] = 393,
	["creature.anubisath.anubisath"] = 178,
	["creature.dreadlord.dreadlord"] = 179,
	["creature.mechastrider.mechastrider"] = 180,
	["creature.sandreaver.sandreaver"] = 181,
	["creature.nagamale.nagamale"] = 182,
	["creature.band.bandundeadmale"] = 183,
	["creature.mounteddeathknight.mounteddeathknight_mograine"] = 184,
	["creature.netherdragon.netherdragon"] = 185,
	["creature.wisp.wisp"] = 186,
	["creature.serpent.serpent"] = 187,
	["creature.firefly.fireflyblue"] = 188,
	["creature.turtle.turtle"] = 189,
	["creature.spells.battlestandard_stormpike_a_01"] = 190,
	["creature.gryphon.gryphon_skeletal"] = 191,
	["creature.lobstrok.lobstrok"] = 192,
	["creature.salamander.salamandermale"] = 193,
	["creature.terongorefiend_mounted.terongorefiend_mounted"] = 194,
	["creature.harpy.harpy"] = 195,
	["creature.talbuk.talbuk"] = 196,
	["creature.terongorefiend.terongorefiend"] = 197,
	["creature.humscitizenmid.humscitizenmid"] = 198,
	["creature.troglodyte.troglodyte"] = 199,
	["creature.drakeadon.drakeadon"] = 200,
	["creature.tigon.tigonmale"] = 201,
	["creature.eaglegod.eaglegod"] = 202,
	["creature.skeleton.skeleton"] = 203,
	["creature.etherial.etherialblue"] = 204,
	["creature.undeadbeast.undeadbeast"] = 205,
	["creature.bloodelfmalekid.bloodelfmalekid"] = 206,
	["creature.mountaingiantoutland.mountaingiant_zangarmarsh"] = 207,
	["creature.eyestalkofkathune.eyestalkofkathune"] = 208,
	["creature.eredar.archimonde"] = 209,
	["creature.alliancerider.alliancerider"] = 210,
	["creature.basilisk.basilisk"] = 211,
	["creature.spells.invisibilitytotem"] = 212,
	["creature.felhound.felhound"] = 213,
	["creature.zergling.zerglingpet"] = 214,
	["creature.bodyofkathune.bodyofkathune"] = 215,
	["creature.highelf.highelffemale_hunter"] = 216,
	["creature.necromancer.necromancer"] = 217,
	["creature.gnomespidertank.gnomebot"] = 218,
	["creature.gnomespidertank.gnomealertbot"] = 219,
	["creature.slime.slime"] = 220,
	["creature.mechastrider.gnomemechastrider"] = 221,
	["creature.bloodelffemalekid.bloodelffemalekid"] = 222,
	["creature.kodobeast.kodobeast"] = 223,
	["creature.fungalgiant.fungalgiantyellow"] = 224,
	["creature.furbolg.furbolg"] = 225,
	["creature.golemstone.golemcannonstone"] = 226,
	["creature.quillboar.quillboar"] = 227,
	["creature.humanmalepeasant.humanmalepeasantpick"] = 228,
	["creature.questobjects.creature_scourgecrystal"] = 229,
	["creature.spells.battlestandard_horde"] = 230,
	["creature.dragonwhelpdarkshade.dragonwhelpdarkshade"] = 231,
	["creature.dragonfootsoldierdarkshade.dragonfootsoldierdarkshade"] = 232,
	["creature.arcanegolem.arcanegolembroken"] = 233,
	["creature.spells.waterelementaltotem"] = 234,
	["creature.tree.ashenvaletreefalling01"] = 235,
	["creature.stormcrow.stormcrow"] = 236,
	["creature.tiger.tigergem"] = 237,
	["creature.portalofkathune.portalofkathune"] = 238,
	["creature.lobstrokoutland.lobstrokoutland"] = 239,
	["creature.hippogryph.hippogryphpet"] = 240,
	["creature.arakkoa.arakkoa_sage03"] = 241,
	["creature.humanfemalewarriorlight.humanfemalewarriorlight"] = 242,
	["creature.orcmalemerchantlight.orcmalemerchantlight"] = 243,
	["creature.nagafemale.siren"] = 244,
	["creature.egg.eggcreature"] = 245,
	["creature.murmur.murmur"] = 246,
	["creature.etherial.etherialred"] = 247,
	["creature.ridinghorse.ridinghorse"] = 248,
	["creature.tallstrider.tallstrider"] = 249,
	["creature.spells.monsterlure01"] = 250,
	["creature.ragnaros.ragnaros"] = 251,
	["creature.mothpet.mothpet"] = 252,
	["creature.cat.cat"] = 253,
	["creature.orcmalekidbrown.orcmalekidbrown"] = 254,
	["creature.imp.fireimp"] = 255,
	["creature.draeneimalekid.draeneimalekid"] = 256,
	["creature.humanmalepeasant.humanmalepeasant"] = 257,
	["creature.cow.cow"] = 258,
	["creature.kodobeast.kodobeasttame"] = 259,
	["creature.wyvern.wyvern_armored"] = 260,
	["creature.rockflayer.rockflayerelite"] = 261,
	["creature.humanfemalekid.humanfemalekid"] = 262,
	["creature.band.bandorcmale"] = 263,
	["creature.lord kezzak.lordkezzak_armored"] = 264,
	["creature.humanfemalefarmer.humanfemalefarmer"] = 265,
	["creature.felbat.battaxi"] = 266,
	["creature.skeletonmage.skeletonmage"] = 267,
	["character.nightelf.male.nightelfmale"] = 268,
	["creature.hufmcitizenlow.hufmcitizenlow"] = 376,
	["creature.succubus.succubus"] = 270,
	["creature.waterbubblecreature.waterbubblecreature"] = 271,
	["creature.fungalmonster.fungalmonster"] = 272,
	["creature.pitlord.magtheridon"] = 273,
	["creature.chicken.chicken"] = 274,
	["creature.lasher.lasher"] = 275,
	["creature.firefly.fireflyblack"] = 499,
	["creature.humanfemalemerchantfat.humanfemalemerchantfat"] = 277,
	["creature.band.bandtaurenmale"] = 278,
	["creature.hufmcitizenmid.hufmcitizenmid"] = 279,
	["creature.ridingelekk.ridingelekkelite"] = 280,
	["creature.mountaingiantoutland.mountaingiant_netherstorm"] = 281,
	["creature.gryphon.gryphon_mount"] = 282,
	["creature.ridingraptor.ridingraptor"] = 283,
	["creature.carrionbirdoutland.carrionbirdoutland"] = 284,
	["creature.eredar.eredar"] = 285,
	["creature.spells.earthelementaltotem"] = 286,
	["character.scourge.male.scourgemale"] = 287,
	["creature.fleshbeast.fleshbeast"] = 288,
	["creature.doomguard.doomguard"] = 289,
	["creature.dragonhawkgod.dragonhawkgod"] = 290,
	["creature.fleshgiant.fleshgiant"] = 291,
	["creature.spells.battlestandard_alliance"] = 292,
	["creature.ridingwyvern.ridingwyvern"] = 293,
	["creature.centaur.centaurwarrior"] = 294,
	["creature.pitlord.pitlord"] = 295,
	["creature.felcannon.felcannon"] = 296,
	["creature.ancientoflore.ancientoflore"] = 297,
	["creature.spells.draeneitotem_air"] = 298,
	["creature.ridinghorse.packmule"] = 299,
	["creature.fireelemental.fireelemental"] = 300,
	["creature.windserpent.windserpent"] = 462,
	["creature.silithidwaspboss.silithidwaspboss"] = 302,
	["creature.fish.fish"] = 303,
	["creature.ogreking.ogreking"] = 304,
	["creature.quillboar.quillboarwarrior"] = 305,
	["creature.wight.wight"] = 306,
	["creature.crystalportal.crystalportal"] = 307,
	["creature.druidowlbear.druidowlbear"] = 308,
	["creature.seaturtle.seaturtle"] = 309,
	["creature.humanthief.humanthief"] = 310,
	["creature.etherial.etherialpurple"] = 311,
	["creature.nightmare.gorgon101"] = 312,
	["creature.akama.akama"] = 313,
	["character.gnome.male.gnomemale"] = 314,
	["creature.centaur.centaurkhan"] = 315,
	["creature.mobat.mobat"] = 316,
	["creature.druidowlbear.druidowlbeartauren"] = 317,
	["creature.felorcwarlord.felorcwarlord"] = 318,
	["creature.dragonspawnoverlorddarkshade.dragonspawnoverlorddarkshade"] = 319,
	["creature.dryder.dryder"] = 320,
	["creature.gryphon.gryphon_ghost"] = 321,
	["creature.zombie.zombie"] = 322,
	["creature.netherdrake.netherdrakeelite"] = 323,
	["creature.tiger.tigercub"] = 324,
	["creature.humanmalenoble.humanmalenoble"] = 325,
	["creature.humanmalekid.humanmalekid"] = 326,
	["creature.faeriedragon.faeriedragon"] = 327,
	["creature.zombie.zombiearm"] = 328,
	["creature.felorcaxe.felorcwarrioraxe"] = 384,
	["creature.gnomespidertank.gnomespidertank"] = 330,
	["creature.sandworm.sandworm"] = 331,
	["creature.krakken.krakken"] = 332,
	["creature.humanmalemarshal.humanmalemarshal"] = 333,
	["creature.prariedog.prariedog"] = 334,
	["character.goblin.male.goblinmale"] = 335,
	["creature.troll.trolljungleboss"] = 336,
	["creature.etherialrobea.etherialrobea"] = 337,
	["creature.humanfemalewarriorheavy.humanfemalewarriorheavy"] = 338,
	["creature.dragonhawk.dragonhawk"] = 339,
	["creature.wisp.wispred"] = 340,
	["creature.chimera.chimera"] = 341,
	["creature.gnomespidertank.gnomepounder"] = 342,
	["creature.babybeholder.babybeholder"] = 343,
	["creature.spells.creature_spellportal"] = 344,
	["creature.abyssaloutland.abyssal_outland"] = 345,
	["creature.crawler.crawler"] = 346,
	["creature.larvaoutland.larvaoutland"] = 347,
	["creature.kargath.kargath"] = 348,
	["character.human.male.humanmale"] = 349,
	["creature.chinesedragon.chinesedragon"] = 350,
	["creature.ridingelekk.ridingelekk"] = 351,
	["creature.felorc.felorc"] = 352,
	["creature.sealion.sealion"] = 353,
	["creature.warpstalker.warpstalker"] = 354,
	["creature.dragon.dragonazurgoz"] = 355,
	["creature.cryptfiend.cryptfiend"] = 356,
	["creature.hippogryph.hippogryph"] = 357,
	["creature.slime.slimelesser"] = 358,
	["creature.arakkoa.arakkoa"] = 359,
	["creature.troll.trollforestboss"] = 360,
	["creature.druidbear.druidbeartauren"] = 361,
	["creature.pterrordax.pterrordax"] = 362,
	["creature.elekk.elekkwild"] = 363,
	["creature.humanfemalemerchantthin.humanfemalemerchantthin"] = 364,
	["creature.waterelemental.waterelemental_red"] = 365,
	["creature.slimegiant.giantslime"] = 366,
	["creature.bloodelfguard.bloodelfmale_guard"] = 367,
	["creature.babyelekk.babyelekk"] = 368,
	["creature.wolf.wolf_ghost"] = 369,
	["creature.tigon.tigonfemale"] = 370,
	["creature.abyssalillidan.abyssal_illidan"] = 371,
	["creature.cockroach.cockroach"] = 372,
	["creature.arakkoa.arakkoa_sage01"] = 373,
	["character.felorc.male.felorcmalesword"] = 447,
	["creature.gnoll.gnoll"] = 375,
	["creature.cratecreature.cratecreaturebasic"] = 677,
	["creature.warpstorm.warpstorm_large"] = 377,
	["creature.steamtonk.steamtonk"] = 378,
	["creature.orcfemalekidbrown.orcfemalekidbrown"] = 676,
	["creature.wolf.wolf"] = 380,
	["creature.frog.frog"] = 381,
	["creature.troll.trollmelee"] = 392,
	["creature.dragonspawndarkshade.dragonspawndarkshade"] = 383,
	["creature.lasherorchid.lasherorchid"] = 674,
	["creature.troll.trollwhelp"] = 385,
	["creature.cryptlord.cryptlord_underground"] = 386,
	["creature.wellofsouls.wellofsoulsseduction"] = 387,
	["character.naga_.female.naga_female"] = 673,
	["creature.crocodile.crocodile"] = 672,
	["creature.dragonspawncasterdarkshade.dragonspawncasterdarkshade"] = 390,
	["creature.kobold.kobold"] = 391,
	["creature.humanfemalecaster.humanfemalecaster"] = 177,
	["creature.arakkoa.arakkoa_sage"] = 670,
	["creature.orcfemalekid.orcfemalekid"] = 394,
	["creature.timerift.time_rift1"] = 669,
	["creature.mechastrider.pvpmechastrider"] = 668,
	["creature.nightmare.nightmare"] = 397,
	["creature.shivan.shivanblue"] = 398,
	["creature.humsmerchant.humsmerchant"] = 667,
	["creature.illidan.illidandark"] = 416,
	["creature.rexxar.rexxar"] = 401,
	["creature.firesprite.firesprite"] = 400,
	["creature.minespider.minespider"] = 168,
	["creature.arcanegolem.arcanegolempurple"] = 664,
	["creature.landro.landro"] = 663,
	["creature.voidcaller.voidcaller"] = 662,
	["creature.spells.draeneitotem_fire"] = 409,
	["creature.seagiant.seagiant"] = 408,
	["creature.druidcattauren.druidcattauren"] = 661,
	["creature.tharazun.tharazun"] = 660,
	["creature.stonekeeper.stonekeeper"] = 411,
	["creature.carrionbird.carrionbird"] = 659,
	["creature.moarg.moarg1"] = 658,
	["creature.tempscourgemalenpc.scourgemalenpc"] = 657,
	["creature.humanmalepiratecaptain.humanmalepiratecaptain"] = 415,
	["creature.humnguardbig.humnguardbig"] = 656,
	["creature.sporebat.sporebat"] = 434,
	["creature.humlblacksmith.humlblacksmith"] = 418,
	["creature.flyingmachinecreature.flyingmachinecreature"] = 134,
	["character.troll.female.trollfemale"] = 654,
	["creature.ridingwyvernarmored.ridingwyvernarmored"] = 421,
	["creature.skeletalserpent.skeletalserpent"] = 465,
	["creature.slith.slith"] = 423,
	["creature.spirithealer.spirithealer"] = 652,
	["creature.spells.fireelementaltotem"] = 425,
	["creature.questobjects.creature_burningash"] = 426,
	["creature.faeriedragon.faeriedragon_ghost"] = 651,
	["creature.manawurm.manawurm"] = 650,
	["creature.panda.pandacub"] = 100,
	["creature.orcmalewarriorlight.orcmalewarriorlight"] = 648,
	["creature.mountaingiantcrystal.mountaingiantcrystal"] = 647,
	["creature.elementalpoison.poisonelemental"] = 432,
	["creature.rabbit.rabbit"] = 646,
	["creature.gnome.gnome"] = 431,
	["creature.netherdrake.netherdrake"] = 644,
	["creature.clefthoove.clefthoove"] = 83,
	["creature.ogre02.ogre02"] = 642,
	["creature.gryphon.gryphon_armored"] = 641,
	["character.broken.male.brokenmale"] = 640,
	["creature.questobjects.creature_etherealstorm"] = 77,
	["creature.drakedarkshade.drakedarkshade"] = 482,
	["creature.phoenix.phoenix"] = 637,
	["creature.naaru.naaruwhite"] = 443,
	["creature.wyvern.wyvern"] = 636,
	["creature.highelf.highelffemale_warrior"] = 445,
	["creature.mountaingiantcrystal.mountaingiantcrystal_boss"] = 446,
	["creature.kodobeast.ridingkodo"] = 635,
	["creature.felorcnetherdrake.felorcnetherdrake"] = 448,
	["creature.ridingphoenix.ridingphoenix"] = 449,
	["creature.mounteddemonknight.mounteddemonknight"] = 487,
	["creature.grell.grell"] = 633,
	["creature.frostwurm.frostwurm"] = 452,
	["creature.tripod.tripod"] = 632,
	["creature.netherray.netherray"] = 55,
	["creature.halfbodyofkathune.halfbodyofkathune"] = 455,
	["creature.manafiend.manafiend"] = 630,
	["creature.warhorse.warhorse"] = 629,
	["creature.frostwurm.frostwurm_nofrost"] = 458,
	["character.goblin.female.goblinfemale"] = 419,
	["creature.silithidwasp.silithidwasp"] = 460,
	["creature.silithidtankboss.silithidtankboss_damaged"] = 461,
	["creature.invisiblestalker.invisiblestalkernoname"] = 627,
	["creature.moarg.moarg5"] = 463,
	["creature.dragonspawncaster.dragonspawncaster"] = 464,
	["creature.felhorse.felhorseepic"] = 626,
	["creature.highelf.highelfmale_mage"] = 466,
	["creature.illidanglaive.creature_illidansglaive"] = 496,
	["creature.fireelemental.fireelementalgreen"] = 624,
	["creature.cupid.cupid"] = 623,
	["creature.spells.stasistotem"] = 622,
	["creature.cratecreature.cratecreature"] = 471,
	["creature.lessermanafiend.lessermanafiend_blue"] = 621,
	["creature.cloud.cloudswampgas_shadowmoon"] = 620,
	["creature.dryad.dryad"] = 500,
	["creature.elekk.elekk"] = 475,
	["creature.dragonspawnarmoreddarkshade.dragonspawnarmoreddarkshade"] = 476,
	["creature.unicorn.unicorn"] = 618,
	["creature.gnollmelee.gnollmelee"] = 478,
	["creature.felorcnetherdrake.felorcnetherdrakemounted"] = 479,
	["creature.banshee.banshee"] = 480,
	["creature.cloud.cloudswampgas_zangarmarsh"] = 481,
	["creature.humanmalepeasant.humanmalepeasantwood"] = 617,
	["creature.shivan.shivanblack"] = 616,
	["creature.troll.trollforestcaster"] = 615,
	["creature.nefarian.dragonnefarian"] = 504,
	["creature.turkey.turkey"] = 486,
	["creature.fleshtitan.fleshtitan"] = 23,
	["creature.forceofnature.forceofnature"] = 488,
	["creature.druidcat.druidcat"] = 489,
	["character.gnome.female.gnomefemale"] = 612,
	["creature.squirrel.squirrel"] = 491,
	["creature.dragonwhelpoutlandcute.dragonwhelpoutlandcute"] = 492,
	["creature.raccoon.raccoon"] = 493,
	["creature.frenzy.frenzy"] = 611,
	["creature.sporeling.sporelingorange"] = 495,
	["creature.gargoyle.gargoyle"] = 483,
	["creature.zigguratcrystal.zigguratcrystal"] = 497,
	["creature.felbat.felbat"] = 610,
	["creature.goblinrocketcar.goblinrocketcar"] = 276,
	["creature.warpstorm.warpstorm"] = 608,
	["creature.ogre.ogre"] = 501,
	["creature.felreaver.temporalreaver"] = 607,
	["creature.humsguardbig.humsguardbig"] = 606,
	["character.human.female.humanfemale"] = 605,
	["creature.wellofsouls.wellofsouls"] = 511,
	["creature.dragonspawn.dragonspawnarmored"] = 603,
	["creature.naaru.naaruwhiteevil"] = 602,
	["creature.lessermanafiend.lessermanafiend"] = 505,
	["creature.mountaingiantoutland.mountaingiant_bladesedge"] = 509,
	["creature.lich.lich"] = 510,
	["creature.voidwalkeroutland.voidwalker_outland"] = 506,
	["creature.golemharveststage2.golemharveststage2"] = 512,
	["creature.worgen.worgen"] = 600,
	["creature.kodobeasttame.kodobeasttame"] = 514,
	["creature.raptor.raptor"] = 599,
	["creature.troll.trolljunglecaster"] = 598,
	["creature.giraffe.giraffe"] = 597,
	["creature.orcmalewarriorheavy.orcmalewarriorheavy"] = 520,
	["creature.murloc.murloc"] = 521,
	["creature.bear.polarbearcub"] = 518,
	["creature.netherdrakonid.netherdrakonid"] = 519,
	["creature.boar.boar"] = 594,
	["creature.silithidtank.silithidtank"] = 523,
	["creature.humanfemaleblacksmith.humanfemaleblacksmith"] = 524,
	["creature.thunderaan.thunderaan"] = 593,
	["creature.humluppercitizen.humluppercitizen"] = 526,
	["creature.humanmalewarriorheavy.humanmalewarriorheavy"] = 527,
	["creature.felcannon.felcannon_02"] = 528,
	["creature.dragon.dragononyxia"] = 529,
	["creature.hakkar.hakkar"] = 530,
	["creature.etherial.etherial"] = 531,
	["creature.highelf.highelfmale_hunter"] = 591,
	["creature.drake.orcdrakerider"] = 533,
	["creature.dwarfmalewarriorlight.dwarfmalewarriorlight"] = 590,
	["creature.wellofsouls.wellofsoulsgrief"] = 535,
	["creature.object.woodendummy"] = 589,
	["creature.mountaingiant.mountaingiant"] = 588,
	["creature.tigon.tigon"] = 587,
	["creature.frostsabre.pvpridingfrostsabre"] = 539,
	["creature.questobjects.creature_scourgecrystaldamaged"] = 540,
	["creature.infernal.infernal"] = 541,
	["creature.humlmagicsmith.humlmagicsmith"] = 585,
	["creature.cloud.cloudswampgas_netherstorm"] = 543,
	["creature.keeperofthegrove.keeperofthegrove"] = 584,
	["creature.humlmerchant.humlmerchant"] = 545,
	["creature.object.archerytarget"] = 583,
	["creature.ridingtalbuk.ridingtalbuk"] = 547,
	["creature.kodobeast.kodobeastpack"] = 548,
	["creature.ancientprotector.ancientprotector"] = 549,
	["creature.ogre.ogrewarlord"] = 582,
	["creature.felbeastshadowmoon.felbeastshadowmoon"] = 551,
	["creature.tempdeathguard.deathguard"] = 552,
	["character.scourge.female.scourgefemale"] = 553,
	["creature.felbeast.felbeast"] = 580,
	["creature.spells.firetotem"] = 555,
	["creature.dragon.dragonnefarian"] = 556,
	["creature.cryptlord.cryptlord"] = 557,
	["creature.humanfemalewarriormedium.humanfemalewarriormedium"] = 578,
	["creature.mouthofkathune01.mouthofkathune01"] = 559,
	["creature.gazelle.gazelle"] = 577,
	["creature.silithidtankboss.silithidtankboss"] = 558,
	["creature.wendigo.wendigo"] = 562,
	["creature.spells.battlestandard_frostwolf_a_01"] = 560,
	["creature.dragon.lethon"] = 576,
	["creature.fleshgolem.fleshgolem"] = 565,
	["creature.ram.ram"] = 566,
	["creature.mounteddeathknight.mounteddeathknight_blaumeux"] = 564,
	["creature.titanmale.titanmale_ghost"] = 568,
	["creature.thunderlizard.thunderlizard"] = 569,
	["creature.naaru.naarured"] = 570,
	["creature.cloud.cloudradioactive"] = 572,
	["creature.golemharvest.golemharvest"] = 571,
	["creature.reindeer.reindeermount"] = 574,
	["creature.humanfemalepeasant.humanfemalepeasant"] = 573,
	["creature.mountedknight.mountedknight"] = 575,
	["creature.gronn.gronn"] = 567,
	["creature.dragon.taerar"] = 563,
	["creature.spells.valentinesdummy"] = 561,
	["creature.felorcsword.felorcwarriorsword"] = 579,
	["creature.felguard.felguard"] = 554,
	["creature.quirajbattleguard.battleguard"] = 581,
	["creature.ram.ridingram"] = 550,
	["character.orc.male.orcmale"] = 546,
	["creature.undeadhorse.ridingundeadhorse"] = 544,
	["creature.tiger.tiger_ghost"] = 542,
	["creature.hydra.hydra"] = 586,
	["creature.druidbear.druidbear"] = 538,
	["character.felorc.male.felorcmale"] = 537,
	["creature.questobjects.creature_burninglegioncannon"] = 536,
	["creature.ogremagelord.ogremagelord"] = 534,
	["creature.etherial.etherialgray"] = 532,
	["creature.larva.larva"] = 592,
	["creature.owl.owl"] = 525,
	["creature.humanmalepiratecrewman.humanmalepiratecrewman"] = 522,
	["creature.etherial.etherialgold"] = 595,
	["creature.humanmalepeasant.humanmalepeasantaxe"] = 596,
	["creature.shark.shark"] = 517,
	["creature.raptoroutland.raptor_outland"] = 516,
	["creature.warhorse.pvpwarhorse"] = 515,
	["creature.ridingtalbuk.ridingtalbukepic"] = 513,
	["creature.felorcdire.felorcdire"] = 601,
	["creature.humanmalepiratecaptain.humanmalepiratecaptain_ghost"] = 507,
	["creature.scorpion.scorpion"] = 1,
	["character.broken.female.brokenfemale"] = 604,
	["creature.sheep.sheep"] = 407,
	["creature.mounteddeathknight.ridingundeadwarhorse"] = 269,
	["creature.mounteddeathknight.mounteddeathknight_korthazz"] = 10,
	["character.troll.male.trollmale"] = 508,
	["creature.centaur.centaur"] = 609,
	["creature.imp.imp"] = 20,
	["creature.bearcub.bearcub"] = 406,
	["creature.arakkoa.arakkoa_warrior"] = 490,
	["creature.dragonspawn.dragonspawn"] = 613,
	["creature.humanmalewizard.humanmalewizard"] = 614,
	["creature.silithidscarab.silithidscarab"] = 503,
	["creature.sporecreature.sporecreature"] = 29,
	["creature.felboar.felboar"] = 502,
	["creature.stag.stag"] = 412,
	["creature.highelf.highelffemale_priest"] = 619,
	["creature.frostsabre.ridingfrostsabre"] = 473,
	["creature.humanmalefarmer.humanmalefarmer"] = 301,
	["character.skeleton.male.skeletonmale"] = 459,
	["creature.lion.lion"] = 498,
	["creature.orcfemalewarriorlight.orcfemale"] = 47,
	["creature.shivan.shivangreen"] = 625,
	["creature.humanmalepeasant.humanmalepeasantgold"] = 49,
	["creature.wyvern.wyvern_mount"] = 494,
	["creature.ogremage02.ogremage02"] = 628,
	["creature.miev.miev"] = 420,
	["creature.humanmalepiratecrewman.humanmalepiratecrewman_ghost"] = 53,
	["creature.highelf.highelfmale_warrior"] = 631,
	["creature.minespider.minespiderboss"] = 424,
	["creature.ridingsilithid.ridingsilithid"] = 451,
	["creature.cloud.cloudfire"] = 634,
	["creature.tempscarletcrusaderlight.scarletcrusaderlight"] = 484,
	["creature.quirajgladiator.quirajgladiator"] = 329,
	["creature.eyeofkathune.eyeofkathune"] = 442,
	["creature.drake.drake"] = 638,
	["creature.gryphon.gryphon_armoredmount"] = 639,
	["creature.dragonwhelp.dragonwhelp"] = 439,
	["creature.tiger.tiger"] = 82,
	["creature.frostsabre.frostsabre"] = 435,
	["creature.voidwalker.voidwalker"] = 643,
	["creature.ridingraptor.pvpridingraptor"] = 430,
	["creature.direwolf.ridingdirewolf"] = 645,
	["character.orc.female.orcfemale"] = 477,
	["creature.goblin.goblin"] = 88,
	["creature.worm.worm"] = 91,
	["creature.golemstone.golemstone"] = 649,
	["creature.doomguardoutland.doomguardoutland"] = 470,
	["creature.dragon.dragon"] = 374,
	["creature.horisath.horisath"] = 468,
	["character.bloodelf.female.bloodelffemale"] = 653,
	["creature.nian.nian"] = 417,
	["creature.kelthuzad.kelthuzad"] = 655,
	["creature.sandvortex.sandvortex"] = 137,
	["creature.arcanegolem.arcanegolem"] = 454,
	["creature.moarg.moarg6"] = 453,
	["creature.spells.landmine01"] = 450,
	["creature.invisibleman.invisibleman"] = 444,
	["creature.trolldire.trolldire"] = 161,
	["creature.crawlerelite.crawlerelite"] = 438,
	["creature.ridingturtle.ridingturtle"] = 437,
	["creature.moarg.moarg2"] = 428,
	["creature.wellofsouls.wellofsoulspain"] = 665,
	["character.felorc.female.felorcfemale"] = 666,
	["creature.object.cannon"] = 414,
	["creature.lessermanafiend.lessermanafiend_violet"] = 396,
	["creature.manafiendgreen.manafiendgreen"] = 413,
	["creature.moarg.moarg3"] = 410,
	["creature.spells.healingtotem"] = 671,
	["creature.nightbane.nightbane"] = 405,
	["creature.hydraoutland.hydraoutland"] = 404,
	["creature.ladyvashj.ladyvashj"] = 402,
	["creature.tempscarletcrusaderheavy.scarletcrusaderheavy"] = 675,
	["creature.spells.draeneitotem_earth"] = 382,
	["creature.fungalgiant.fungalgiant"] = 379,
	["character.tauren.male.taurenmale"] = 678,
}
Mazz3D_CameraDB = {
	{
		["rotation"] = 0.02749719656658324,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.02562815137813397,
			["panV"] = -0.1793750856613136,
		},
	}, -- [1]
	{
		["rotation"] = 0,
		["zoom"] = 0.991666847372075,
		["scale"] = 0.2999999999999996,
		["position"] = {
			["panH"] = 0.2050021563516147,
			["panV"] = 2.562501017887735,
		},
	}, -- [2]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562238770977086,
			["panV"] = -0.1793747254320403,
		},
	}, -- [3]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -4.555383847915095e-015,
			["panV"] = 0.1024999974879967,
		},
	}, -- [4]
	{
		["rotation"] = 0.4749973995673926,
		["zoom"] = 0,
		["scale"] = 0.2999999999999996,
		["position"] = {
			["panH"] = -0.9993739848774684,
			["panV"] = 3.279998838928076,
		},
	}, -- [5]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 0.05125342092209091,
			["panV"] = 1.050625244423919,
		},
	}, -- [6]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 1.3,
		["position"] = {
			["panH"] = -0.1537487354295465,
			["panV"] = -0.1281252670319519,
		},
	}, -- [7]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.1025010781758141,
			["panV"] = -0.07687472794404364,
		},
	}, -- [8]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.800000000000001,
		["position"] = {
			["panH"] = 0.02562815137813395,
			["panV"] = -0.3843750806373059,
		},
	}, -- [9]
	{
		["rotation"] = -0.2199992214333624,
		["zoom"] = -0.4375000917822993,
		["scale"] = 0.2104167432743444,
		["position"] = {
			["panH"] = 0.281875083149299,
			["panV"] = 0.9993736246481964,
		},
	}, -- [10]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = 0,
		},
	}, -- [11]
	{
		["rotation"] = -0.3850025033834947,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = 0.5893739949254834,
			["panV"] = 1.973125221815889,
		},
	}, -- [12]
	{
		["rotation"] = 0.3575006677667704,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.02562526954394785,
			["panV"] = 0.4868757985838461,
		},
	}, -- [13]
	{
		["rotation"] = 0.3849978643333539,
		["zoom"] = 0,
		["scale"] = 1.900000000000001,
		["position"] = {
			["panH"] = 0.1793768868076715,
			["panV"] = -0.4356248992666683,
		},
	}, -- [14]
	{
		["rotation"] = 0.385000957033451,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -1.025002136255606,
			["panV"] = 1.588750141178584,
		},
	}, -- [15]
	{
		["rotation"] = -0.08250550685018286,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.02562526954395693,
			["panV"] = 0.794375430818564,
		},
	}, -- [16]
	{
		["rotation"] = 1.072502003300311,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.358752332698261,
			["panV"] = -0.05125017885863552,
		},
	}, -- [17]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1.35,
		["position"] = {
			["panH"] = -0.07687292679768475,
			["panV"] = 0.3075007129225327,
		},
	}, -- [18]
	{
		["rotation"] = 0.3024969965333071,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.2562555772737103,
			["panV"] = 0.7943747103600184,
		},
	}, -- [19]
	{
		["rotation"] = 0.9075002677002128,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.05125342092208637,
			["panV"] = -0.3843754408665807,
		},
	}, -- [20]
	{
		["rotation"] = 0.1649986428999963,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 0.02562238770976618,
			["panV"] = 0.9481248867066495,
		},
	}, -- [21]
	{
		["rotation"] = 0.1924989321666769,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.1025010781758142,
			["panV"] = 0.563750886757163,
		},
	}, -- [22]
	{
		["rotation"] = 0.3575006677667705,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.02562815137813395,
			["panV"] = 0.3843739999494866,
		},
	}, -- [23]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.1024981963416326,
			["panV"] = -0.2818750831493097,
		},
	}, -- [24]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = -0.174999790702685,
		["scale"] = 0.7999999999999996,
		["position"] = {
			["panH"] = -0.02562959229522466,
			["panV"] = -0.07687580863186042,
		},
	}, -- [25]
	{
		["rotation"] = 0.7425016248002214,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.0256252695439524,
			["panV"] = -0.1281252670319508,
		},
	}, -- [26]
	{
		["rotation"] = 0.3575006677667705,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.0256252695439478,
			["panV"] = -0.1281245465734054,
		},
	}, -- [27]
	{
		["rotation"] = 0.6124988459008054,
		["zoom"] = 0,
		["scale"] = 0.3499999999999996,
		["position"] = {
			["panH"] = -0.05124909817081916,
			["panV"] = 2.895623758290769,
		},
	}, -- [28]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.02562526954395695,
			["panV"] = 0.1281245465734042,
		},
	}, -- [29]
	{
		["rotation"] = 0.2749997999667237,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.4356238185788506,
			["panV"] = -0.3843750806373058,
		},
	}, -- [30]
	{
		["rotation"] = 0.3575006677667756,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.5893754358425694,
			["panV"] = -0.640624534013388,
		},
	}, -- [31]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.3999999999999996,
		["position"] = {
			["panH"] = -0.07687869046604791,
			["panV"] = 2.613749035370733,
		},
	}, -- [32]
	{
		["rotation"] = 0.3575006677667655,
		["zoom"] = 0,
		["scale"] = 3.199999999999997,
		["position"] = {
			["panH"] = -0.1025039600100002,
			["panV"] = -0.3074999924639905,
		},
	}, -- [33]
	{
		["rotation"] = 1.292498132033575,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.179374004973499,
			["panV"] = -0.3074992720054451,
		},
	}, -- [34]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.1024981963416326,
			["panV"] = 0.3587508917811702,
		},
	}, -- [35]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 2.050000000000001,
		["position"] = {
			["panH"] = 0.02562815137812939,
			["panV"] = -0.6406248942426619,
		},
	}, -- [36]
	{
		["rotation"] = 0.1650017356000935,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.153749816117359,
		},
	}, -- [37]
	{
		["rotation"] = -0.8249993999001667,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.1025010781758088,
			["panV"] = -0.1024999974879964,
		},
	}, -- [38]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -4.53109771925142e-015,
			["panV"] = -0.1281249068026781,
		},
	}, -- [39]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 0.8200057435723362,
			["panV"] = 1.050625244423919,
		},
	}, -- [40]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -0.05125053908790934,
			["panV"] = 0.7431245315013841,
		},
	}, -- [41]
	{
		["rotation"] = -0.5774967965000306,
		["zoom"] = -4.229167690567909,
		["scale"] = 1.3,
		["position"] = {
			["panH"] = 3.22875226236216,
			["panV"] = 0.07687508817331473,
		},
	}, -- [42]
	{
		["rotation"] = -0.1100005791006197,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.02562314329199075,
			["panV"] = -0.1281224871416197,
		},
	}, -- [43]
	{
		["rotation"] = 0.2749997999667238,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.1024981963416372,
			["panV"] = -0.07687508817331637,
		},
	}, -- [44]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 4.510281037539698e-017,
			["panV"] = -0.1537498161173589,
		},
	}, -- [45]
	{
		["rotation"] = 0.3025031819335067,
		["zoom"] = 0,
		["scale"] = 4.099999999999993,
		["position"] = {
			["panH"] = 0.1793740049734943,
			["panV"] = -0.5124992669814386,
		},
	}, -- [46]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = 0.1024981963416326,
			["panV"] = 0.3331245415493975,
		},
	}, -- [47]
	{
		["rotation"] = 0.1099996107166738,
		["zoom"] = 0,
		["scale"] = 0.8499999999999996,
		["position"] = {
			["panH"] = 0.02562238770977541,
			["panV"] = 3.971876433634278,
		},
	}, -- [48]
	{
		["rotation"] = 0.3850009570334464,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.128120584051408,
			["panV"] = 0.1537508968051737,
		},
	}, -- [49]
	{
		["rotation"] = -0.08249777509994952,
		["zoom"] = -1.749999547095079,
		["scale"] = 0.1,
		["position"] = {
			["panH"] = -0.0256310332123194,
			["panV"] = -11.17250337351302,
		},
	}, -- [50]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.02562238770977085,
			["panV"] = -0.2049999949759933,
		},
	}, -- [51]
	{
		["rotation"] = 0.1925020248667791,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = -0.2306303077297623,
			["panV"] = 1.768124866610624,
		},
	}, -- [52]
	{
		["rotation"] = -0.08250550685018286,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -0.1281249068026758,
			["panV"] = 0.7431252519599297,
		},
	}, -- [53]
	{
		["rotation"] = 0.08249777509994952,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = 0.8968772294529255,
			["panV"] = 1.486250143690586,
		},
	}, -- [54]
	{
		["rotation"] = 0.3850009570334511,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.2306245440613992,
			["panV"] = -0.7687505215038849,
		},
	}, -- [55]
	{
		["rotation"] = -0.02749719656658849,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.2306187803930497,
			["panV"] = -0.2818747229200381,
		},
	}, -- [56]
	{
		["rotation"] = 0.3299972857999878,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.07687580863185724,
			["panV"] = -0.4356248992666685,
		},
	}, -- [57]
	{
		["rotation"] = 0,
		["zoom"] = -0.6125002925020425,
		["scale"] = 0.2999999999999997,
		["position"] = {
			["panH"] = 1.332498166197595,
			["panV"] = 4.279376065868996,
		},
	}, -- [58]
	{
		["rotation"] = 0.3025000892334037,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562526954395696,
			["panV"] = -0.1537501763466328,
		},
	}, -- [59]
	{
		["rotation"] = 0.2474995107000384,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.02562238770976633,
			["panV"] = -0.02562562977322718,
		},
	}, -- [60]
	{
		["rotation"] = 0.05500057853336614,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -0.02562526954395696,
			["panV"] = 1.435000325061224,
		},
	}, -- [61]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.3,
		["position"] = {
			["panH"] = 0.05125053908790479,
			["panV"] = -0.07687508817331637,
		},
	}, -- [62]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 6.938893903907228e-018,
			["panV"] = -0.1281249068026787,
		},
	}, -- [63]
	{
		["rotation"] = 0.02750338196677767,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.02561950587560294,
			["panV"] = 0.1024989168001769,
		},
	}, -- [64]
	{
		["rotation"] = 0,
		["zoom"] = -2.304166302684853,
		["scale"] = 0.3999999999999996,
		["position"] = {
			["panH"] = 0.5893682312571157,
			["panV"] = 3.587499191621336,
		},
	}, -- [65]
	{
		["rotation"] = 0.2200017361673526,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 0.4356300928211978,
			["panV"] = 1.665626453246097,
		},
	}, -- [66]
	{
		["rotation"] = -0.05500057853336134,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.02562238770977538,
			["panV"] = -0.1281245465734065,
		},
	}, -- [67]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.07687580863185264,
			["panV"] = 0.8200003401332464,
		},
	}, -- [68]
	{
		["rotation"] = 0.2749967072666317,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.07687508817331637,
		},
	}, -- [69]
	{
		["rotation"] = 0.275002892666821,
		["zoom"] = 0,
		["scale"] = 0.3999999999999996,
		["position"] = {
			["panH"] = 0.1281234658855897,
			["panV"] = 1.614374690263994,
		},
	}, -- [70]
	{
		["rotation"] = 0.3850009570334511,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.05125053908790934,
			["panV"] = 1.768124866610624,
		},
	}, -- [71]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = 0.5124996272107124,
			["panV"] = 0.9225003376212411,
		},
	}, -- [72]
	{
		["rotation"] = -0.1099949716665281,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.1025039600099913,
			["panV"] = 0.1025003577172688,
		},
	}, -- [73]
	{
		["rotation"] = 0.02750028926668554,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.0768786904660433,
			["panV"] = -0.5637505265278897,
		},
	}, -- [74]
	{
		["rotation"] = 0.4400015355668225,
		["zoom"] = 0,
		["scale"] = 0.3999999999999996,
		["position"] = {
			["panH"] = -0.05124909817081859,
			["panV"] = 1.896249773413302,
		},
	}, -- [75]
	{
		["rotation"] = 0.164995550199899,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -2.881834186070631e-006,
			["panV"] = -0.05125017885863553,
		},
	}, -- [76]
	{
		["rotation"] = 0.05500057853336619,
		["zoom"] = 0,
		["scale"] = 0.2499999999999997,
		["position"] = {
			["panH"] = 0.6662512444744311,
			["panV"] = 4.919999519194566,
		},
	}, -- [77]
	{
		["rotation"] = 0.1375045390335102,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 7.632783294297951e-017,
			["panV"] = -0.2562498136053559,
		},
	}, -- [78]
	{
		["rotation"] = 0.4949990214000812,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.2562498136053606,
			["panV"] = 0.8712501587626075,
		},
	}, -- [79]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = 0.02562526954395239,
			["panV"] = 1.716874327522715,
		},
	}, -- [80]
	{
		["rotation"] = 0.08250086780004175,
		["zoom"] = -1.049999974267283,
		["scale"] = 0.3999999999999996,
		["position"] = {
			["panH"] = -0.1793682413051358,
			["panV"] = 2.972500287381176,
		},
	}, -- [81]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = 0,
		},
	}, -- [82]
	{
		["rotation"] = 0.4400046282669098,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0.2050007154345375,
			["panV"] = -0.3843747204080332,
		},
	}, -- [83]
	{
		["rotation"] = 0.3575037604668678,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 6.938893903907228e-018,
			["panV"] = -0.15374981611736,
		},
	}, -- [84]
	{
		["rotation"] = -0.4400015355668122,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = 0.1025010781758187,
			["panV"] = 0.9225010580797863,
		},
	}, -- [85]
	{
		["rotation"] = 0.2474971209982308,
		["zoom"] = 0,
		["scale"] = 1.650000000000001,
		["position"] = {
			["panH"] = 1.387778780781446e-017,
			["panV"] = -1.921873871319828,
		},
	}, -- [86]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.02562815137812941,
			["panV"] = 1.614374330034718,
		},
	}, -- [87]
	{
		["rotation"] = 0.3025000892334092,
		["zoom"] = 0,
		["scale"] = 1.550000000000001,
		["position"] = {
			["panH"] = -0.07687580863186173,
			["panV"] = -0.2306256247492206,
		},
	}, -- [88]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -0.0512505390879139,
			["panV"] = -0.3331256222372168,
		},
	}, -- [89]
	{
		["rotation"] = 0.4949990214000806,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562526954395696,
			["panV"] = -0.1537501763466328,
		},
	}, -- [90]
	{
		["rotation"] = 0.3850009570334565,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -1.040834085586084e-017,
			["panV"] = 0.07687544840258678,
		},
	}, -- [91]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.7431241712721115,
			["panV"] = 1.306875418258547,
		},
	}, -- [92]
	{
		["rotation"] = 0.04750036474831774,
		["zoom"] = 0,
		["scale"] = 0.1999999999999997,
		["position"] = {
			["panH"] = -0.102503960009995,
			["panV"] = 8.046249982922367,
		},
	}, -- [93]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.05125053908790941,
			["panV"] = -0.2049996347467217,
		},
	}, -- [94]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0.07687580863186173,
			["panV"] = 0.7431252519599304,
		},
	}, -- [95]
	{
		["rotation"] = 0.2475026034001404,
		["zoom"] = 0,
		["scale"] = 1.800000000000001,
		["position"] = {
			["panH"] = 0.02562526954395708,
			["panV"] = -0.7431245315013844,
		},
	}, -- [96]
	{
		["rotation"] = 0.4400015355668172,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.07687292679768021,
			["panV"] = 0.05124981862936169,
		},
	}, -- [97]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.128123465885585,
			["panV"] = 1.870625584557164,
		},
	}, -- [98]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 0.02562526954395695,
			["panV"] = 0.614999624698706,
		},
	}, -- [99]
	{
		["rotation"] = 0.3575006677667703,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.0512476572537187,
			["panV"] = -0.02562454908540815,
		},
	}, -- [100]
	{
		["rotation"] = 0.1375014463334081,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.1537530581808141,
			["panV"] = -1.46062559460518,
		},
	}, -- [101]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0.05125053908790481,
			["panV"] = -0.02562490931468198,
		},
	}, -- [102]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.750000000000001,
		["position"] = {
			["panH"] = -0.02562558708248111,
			["panV"] = -0.4868752077677513,
		},
	}, -- [103]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 2.000000000000001,
		["position"] = {
			["panH"] = -0.02562526954395696,
			["panV"] = 1.153124881682643,
		},
	}, -- [104]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.2049992745174514,
			["panV"] = 0.1024996372587223,
		},
	}, -- [105]
	{
		["rotation"] = -0.08250241415009524,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.1024981963416372,
			["panV"] = -0.1281256272612236,
		},
	}, -- [106]
	{
		["rotation"] = -0.3575006677667753,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.384374720408032,
			["panV"] = 0.7943757910478365,
		},
	}, -- [107]
	{
		["rotation"] = 0.4399984428667151,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.8968729067016532,
			["panV"] = 1.665624508893355,
		},
	}, -- [108]
	{
		["rotation"] = 6.185400194327895e-006,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0.05125342092208181,
			["panV"] = -0.461251609727714,
		},
	}, -- [109]
	{
		["rotation"] = -0.220000767783411,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.05125053908790934,
			["panV"] = -0.2818750831493095,
		},
	}, -- [110]
	{
		["rotation"] = 0.3025000892334092,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.7687494408160689,
			["panV"] = 2.280625574509151,
		},
	}, -- [111]
	{
		["rotation"] = 0.3300016337218676,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.1793766657868773,
			["panV"] = 0.07687487814675795,
		},
	}, -- [112]
	{
		["rotation"] = 0.2749997999667236,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.025628151378134,
			["panV"] = -0.1537505365759044,
		},
	}, -- [113]
	{
		["rotation"] = 0.3025000892334094,
		["zoom"] = 0,
		["scale"] = 0.3499999999999996,
		["position"] = {
			["panH"] = 0.3587494508640796,
			["panV"] = 2.357500302453197,
		},
	}, -- [114]
	{
		["rotation"] = 0.2749997999667237,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.4099985490348936,
			["panV"] = -0.1024999974879972,
		},
	}, -- [115]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.07687676124744322,
			["panV"] = 0.05125051295952214,
		},
	}, -- [116]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.9225010580797873,
			["panV"] = 1.409374695287998,
		},
	}, -- [117]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.35,
		["position"] = {
			["panH"] = 0.2562526954395377,
			["panV"] = 0.307500352693262,
		},
	}, -- [118]
	{
		["rotation"] = 0.2474995107000427,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.2562498136053561,
			["panV"] = 0.256249813605354,
		},
	}, -- [119]
	{
		["rotation"] = 0,
		["zoom"] = -1.866667440953728,
		["scale"] = 0.3775001604041775,
		["position"] = {
			["panH"] = -0.05125342092209544,
			["panV"] = 4.02312661249292,
		},
	}, -- [120]
	{
		["rotation"] = 0,
		["zoom"] = 0.991666847372075,
		["scale"] = 0.2499999999999996,
		["position"] = {
			["panH"] = 0.3587532350560108,
			["panV"] = 2.536875430805253,
		},
	}, -- [121]
	{
		["rotation"] = -0.137501446333408,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = 0.5637516072157123,
			["panV"] = 2.357499942223923,
		},
	}, -- [122]
	{
		["rotation"] = 1.402505474500493,
		["zoom"] = 0,
		["scale"] = 2.100000000000001,
		["position"] = {
			["panH"] = 6.14999840836271,
			["panV"] = -0.02562490931468185,
		},
	}, -- [123]
	{
		["rotation"] = 0.377499196898357,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.02562526954395231,
			["panV"] = -0.1281252670319508,
		},
	}, -- [124]
	{
		["rotation"] = 0.1100011570667272,
		["zoom"] = 0,
		["scale"] = 2.449999999999999,
		["position"] = {
			["panH"] = -0.02562526954395245,
			["panV"] = -1.460625954834452,
		},
	}, -- [125]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 2.881834181529125e-006,
			["panV"] = 1.537500322549221,
		},
	}, -- [126]
	{
		["rotation"] = 0.05499748583326893,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.2049992745174422,
			["panV"] = 0.3075014333810821,
		},
	}, -- [127]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.1024981963416373,
			["panV"] = 1.844998153637576,
		},
	}, -- [128]
	{
		["rotation"] = 0.302501003682131,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -3.469446951953614e-018,
			["panV"] = -0.07687436771477035,
		},
	}, -- [129]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.1537487354295465,
			["panV"] = -0.1281252670319519,
		},
	}, -- [130]
	{
		["rotation"] = 0.275002892666821,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = 0.307497470859084,
			["panV"] = 1.127499612138692,
		},
	}, -- [131]
	{
		["rotation"] = 0.4400015355668175,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.1025010781758188,
			["panV"] = -0.3843754408665793,
		},
	}, -- [132]
	{
		["rotation"] = 0.3575006677667804,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.2049949517661745,
			["panV"] = -0.1537501763466304,
		},
	}, -- [133]
	{
		["rotation"] = 0.6325004677334891,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = -2.126875758391792,
			["panV"] = 2.101250488847839,
		},
	}, -- [134]
	{
		["rotation"] = 0.1650048283001909,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -0.05124765725372323,
			["panV"] = -0.02562526954395463,
		},
	}, -- [135]
	{
		["rotation"] = 0.1099949716665328,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.1024953145074511,
			["panV"] = -0.666250524015889,
		},
	}, -- [136]
	{
		["rotation"] = 0.2749997999667237,
		["zoom"] = 0,
		["scale"] = 0.2499999999999997,
		["position"] = {
			["panH"] = 0.435618054910482,
			["panV"] = 2.049999949759933,
		},
	}, -- [137]
	{
		["rotation"] = 0.1650017356000932,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.07687292679768024,
			["panV"] = 2.408749760853285,
		},
	}, -- [138]
	{
		["rotation"] = 0.2199992214333575,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = 0.05124189358535551,
			["panV"] = 0.07687508817331354,
		},
	}, -- [139]
	{
		["rotation"] = -0.1100011570667324,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -4.524158825347513e-015,
			["panV"] = -0.1537494558880896,
		},
	}, -- [140]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.2050021563516282,
			["panV"] = -0.5637501662986183,
		},
	}, -- [141]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.05124477541955083,
			["panV"] = 0.3587494508640761,
		},
	}, -- [142]
	{
		["rotation"] = 0.02749994849363074,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.05124873037447174,
			["panV"] = 1.332500541597692,
		},
	}, -- [143]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.0256252695439613,
			["panV"] = 0.5381252569839351,
		},
	}, -- [144]
	{
		["rotation"] = 0.02750028926668063,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562526954395695,
			["panV"] = -0.07687508817331637,
		},
	}, -- [145]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1.35,
		["position"] = {
			["panH"] = -0.4612490881228074,
			["panV"] = 0.1537501763466294,
		},
	}, -- [146]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 2.000000000000001,
		["position"] = {
			["panH"] = -0.02562526954395696,
			["panV"] = -0.5124996272107111,
		},
	}, -- [147]
	{
		["rotation"] = 0.4674987321334054,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -6.938893903907228e-018,
			["panV"] = -0.2049999949759944,
		},
	}, -- [148]
	{
		["rotation"] = 0.08250086780005199,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -0.1024981963416326,
			["panV"] = 0.7431245315013839,
		},
	}, -- [149]
	{
		["rotation"] = 0.8799999784335316,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.05125053908790933,
			["panV"] = -0.4868754383545764,
		},
	}, -- [150]
	{
		["rotation"] = 0.2749997999667237,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = -0.2818750831493085,
			["panV"] = 1.998750491359843,
		},
	}, -- [151]
	{
		["rotation"] = 0.330003471200187,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = 0.128129229553939,
			["panV"] = 2.844376101037042,
		},
	}, -- [152]
	{
		["rotation"] = 0.1375014463334129,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.05124765725372783,
			["panV"] = -0.1793758061198585,
		},
	}, -- [153]
	{
		["rotation"] = 0.1650017356000935,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.1793725640563945,
			["panV"] = 1.460624874146634,
		},
	}, -- [154]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.1537487354295374,
			["panV"] = 0.4356252594959401,
		},
	}, -- [155]
	{
		["rotation"] = 0.5774998892001281,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = -0.05124765725372326,
			["panV"] = -0.3843743601787603,
		},
	}, -- [156]
	{
		["rotation"] = 0.3299972857999925,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.1537487354295374,
			["panV"] = -0.2562501738346277,
		},
	}, -- [157]
	{
		["rotation"] = 0.02750338196678301,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562238770977086,
			["panV"] = 2.51124975834128,
		},
	}, -- [158]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.128123465885585,
			["panV"] = 3.280000640074438,
		},
	}, -- [159]
	{
		["rotation"] = 0.02749719656658343,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.5125025090448846,
			["panV"] = 1.716873607064172,
		},
	}, -- [160]
	{
		["rotation"] = -0.1100011570667225,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.1793682413051268,
			["panV"] = 1.101875063053283,
		},
	}, -- [161]
	{
		["rotation"] = 0.1375014463334131,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.1281205840514035,
			["panV"] = -0.3331245415493991,
		},
	}, -- [162]
	{
		["rotation"] = 0.02749719656658325,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 2.881834176932108e-006,
			["panV"] = 0.3587498110933499,
		},
	}, -- [163]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1.3,
		["position"] = {
			["panH"] = -0.4099985490349026,
			["panV"] = 0.2562505340638993,
		},
	}, -- [164]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 6.938893903907228e-018,
			["panV"] = -0.1793750856613135,
		},
	}, -- [165]
	{
		["rotation"] = 0.1100042497668247,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -6.938893903907228e-018,
			["panV"] = -0.07687544840258909,
		},
	}, -- [166]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.2499999999999997,
		["position"] = {
			["panH"] = 0.5893667903400247,
			["panV"] = 5.022500597370379,
		},
	}, -- [167]
	{
		["rotation"] = 0.1374983536333205,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.02562815137813839,
			["panV"] = -0.6918743526427499,
		},
	}, -- [168]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.07687508817331637,
		},
	}, -- [169]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.07687508817331637,
		},
	}, -- [170]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.179374004973499,
			["panV"] = 1.22999996985596,
		},
	}, -- [171]
	{
		["rotation"] = 0.2200023141334598,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.0768786904660433,
			["panV"] = -0.1537505365759043,
		},
	}, -- [172]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -3.469446951953614e-018,
			["panV"] = -0.1281245465734067,
		},
	}, -- [173]
	{
		["rotation"] = 0.8249993999001709,
		["zoom"] = 0,
		["scale"] = 0.1999999999999997,
		["position"] = {
			["panH"] = 0.7174960198939776,
			["panV"] = 9.635000124100952,
		},
	}, -- [174]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.7431241712721115,
			["panV"] = 1.383751226890408,
		},
	}, -- [175]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = 0.2049963926832607,
			["panV"] = 0.1793750856613114,
		},
	}, -- [176]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 0.07687869046603875,
			["panV"] = -3.60229273813073e-007,
		},
	}, -- [177]
	{
		["rotation"] = 0.2475026034001355,
		["zoom"] = 1.5166674495313,
		["scale"] = 0.2499999999999997,
		["position"] = {
			["panH"] = 0.02562238770976643,
			["panV"] = 3.946251524319601,
		},
	}, -- [178]
	{
		["rotation"] = 0.08249777509994957,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.3843819249934859,
			["panV"] = -0.1281256272612223,
		},
	}, -- [179]
	{
		["rotation"] = 0.2475026034001404,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.128123465885585,
			["panV"] = 1.101874702824009,
		},
	}, -- [180]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.05124765725372778,
			["panV"] = -0.05125089931718091,
		},
	}, -- [181]
	{
		["rotation"] = 0.5224993106667618,
		["zoom"] = -0.1458332272550794,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.1024953145074511,
			["panV"] = 0.07687400748549585,
		},
	}, -- [182]
	{
		["rotation"] = 0.1650004760878807,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.1024974607489436,
			["panV"] = -0.2049998593366855,
		},
	}, -- [183]
	{
		["rotation"] = 0.4949990214000812,
		["zoom"] = 0.4083331183176366,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = -0.281875083149313,
			["panV"] = 1.050625604653192,
		},
	}, -- [184]
	{
		["rotation"] = 0.5225054960669608,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.07687508817331637,
		},
	}, -- [185]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = 0,
		},
	}, -- [186]
	{
		["rotation"] = 0.6324973750333918,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.05124765725372781,
			["panV"] = -0.2562501738346288,
		},
	}, -- [187]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.1793797686418529,
			["panV"] = 2.178125216791881,
		},
	}, -- [188]
	{
		["rotation"] = 0.2474995107000333,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -2.881834186153898e-006,
			["panV"] = -0.1537508968051776,
		},
	}, -- [189]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = -0.02562526954395693,
			["panV"] = 3.971874992717191,
		},
	}, -- [190]
	{
		["rotation"] = 0.3024969965333073,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.05124477541954171,
			["panV"] = 0.8456245289893816,
		},
	}, -- [191]
	{
		["rotation"] = 0.4950021141001835,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.2562469317711747,
			["panV"] = 0.691875073101294,
		},
	}, -- [192]
	{
		["rotation"] = 0.4400015355668171,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.07687869046604776,
			["panV"] = 0.6662498035573411,
		},
	}, -- [193]
	{
		["rotation"] = 0.4950001687514242,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.4612532361131883,
			["panV"] = 0.76874984473556,
		},
	}, -- [194]
	{
		["rotation"] = 0.5774983428500791,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.02562526954395239,
			["panV"] = 0.7687501612746094,
		},
	}, -- [195]
	{
		["rotation"] = 0.3300034712001823,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.07687508817331637,
		},
	}, -- [196]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.05125117416496218,
			["panV"] = -0.1537499070669686,
		},
	}, -- [197]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 0.1537458535953558,
			["panV"] = 0.05125053908790597,
		},
	}, -- [198]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -4.548444954011188e-015,
			["panV"] = -0.02562490931468206,
		},
	}, -- [199]
	{
		["rotation"] = 0.1100011570667324,
		["zoom"] = 0,
		["scale"] = 0.3999999999999996,
		["position"] = {
			["panH"] = 0.2049963926832652,
			["panV"] = 2.485625929714418,
		},
	}, -- [200]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -4.551914400963142e-015,
			["panV"] = -0.1281252670319508,
		},
	}, -- [201]
	{
		["rotation"] = 0.02750257109805914,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -0.02562314329199064,
			["panV"] = -0.2049998593366856,
		},
	}, -- [202]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.02562526954395246,
			["panV"] = 0.5893750756132982,
		},
	}, -- [203]
	{
		["rotation"] = 0.2200023141334548,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.2562469317711746,
			["panV"] = -1.665625229351901,
		},
	}, -- [204]
	{
		["rotation"] = 0.2749997999667145,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.2818779649834946,
			["panV"] = -0.07687472794404425,
		},
	}, -- [205]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.800000000000001,
		["position"] = {
			["panH"] = 0.025625269543957,
			["panV"] = -0.3331249017786715,
		},
	}, -- [206]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.2999999999999997,
		["position"] = {
			["panH"] = -0.7943732694429301,
			["panV"] = -0.3075003526932633,
		},
	}, -- [207]
	{
		["rotation"] = 0.330000378500085,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.3331256222372223,
			["panV"] = 1.973124141128072,
		},
	}, -- [208]
	{
		["rotation"] = 6.185400199022056e-006,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.05125198000500006,
			["panV"] = -0.2818750831493087,
		},
	}, -- [209]
	{
		["rotation"] = 0.330000378500085,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.05125053908790034,
			["panV"] = 1.665624148664082,
		},
	}, -- [210]
	{
		["rotation"] = 0.4399999892167686,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.7175061063136128,
			["panV"] = 2.306249763365289,
		},
	}, -- [211]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 6.938893903907228e-018,
			["panV"] = 1.153125602141188,
		},
	}, -- [212]
	{
		["rotation"] = 0.8799999784335368,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.1537516172637189,
			["panV"] = 0.02562454908540816,
		},
	}, -- [213]
	{
		["rotation"] = 0.3025000892334043,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.07687580863186173,
			["panV"] = 1.076250513967874,
		},
	}, -- [214]
	{
		["rotation"] = -0.08249777509994952,
		["zoom"] = -1.749999547095079,
		["scale"] = 0.1,
		["position"] = {
			["panH"] = -0.02562815137813884,
			["panV"] = -1.742501398213035,
		},
	}, -- [215]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -4.558853294867049e-015,
			["panV"] = 0.1024999974879955,
		},
	}, -- [216]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.0256223877097663,
			["panV"] = -0.153749816117359,
		},
	}, -- [217]
	{
		["rotation"] = 0.1374983536333157,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.1025039600099958,
			["panV"] = 0.2562498136053559,
		},
	}, -- [218]
	{
		["rotation"] = 0.1299950471481713,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = -4.600486658290492e-015,
			["panV"] = 1.434998884144131,
		},
	}, -- [219]
	{
		["rotation"] = 0.632500467733494,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.2818722013151224,
			["panV"] = 1.640000320037219,
		},
	}, -- [220]
	{
		["rotation"] = 0.1374983536333111,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.2818837286518531,
			["panV"] = 1.563124871634628,
		},
	}, -- [221]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 2.000000000000001,
		["position"] = {
			["panH"] = -0.02562526954395695,
			["panV"] = -0.4612501688106223,
		},
	}, -- [222]
	{
		["rotation"] = 0.275002892666821,
		["zoom"] = 0,
		["scale"] = 0.3499999999999996,
		["position"] = {
			["panH"] = 0.3587508917811748,
			["panV"] = 1.819375405698532,
		},
	}, -- [223]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.1024999974879984,
		},
	}, -- [224]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -0.05125053908790936,
			["panV"] = -1.131039706336878e-015,
		},
	}, -- [225]
	{
		["rotation"] = 0.2749997999667237,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.2050021563516283,
			["panV"] = 1.383750866661136,
		},
	}, -- [226]
	{
		["rotation"] = -0.1099980643666301,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.1024981963416371,
			["panV"] = 0.2306252645199473,
		},
	}, -- [227]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 1.25,
		["position"] = {
			["panH"] = -0.1281263477197711,
			["panV"] = 0.1537498161173578,
		},
	}, -- [228]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = 2.881834181574228e-006,
			["panV"] = -1.229999969855961,
		},
	}, -- [229]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = -0.1025010781758188,
			["panV"] = 5.048124786226515,
		},
	}, -- [230]
	{
		["rotation"] = 0.4674987321334006,
		["zoom"] = 0,
		["scale"] = 1.4,
		["position"] = {
			["panH"] = -0.1025010781758141,
			["panV"] = 0.4612498085813487,
		},
	}, -- [231]
	{
		["rotation"] = 1.127502581833678,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.07687292679767571,
			["panV"] = -0.2306256247492205,
		},
	}, -- [232]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.2050079200199869,
			["panV"] = 1.076249793509328,
		},
	}, -- [233]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -3.469446951953614e-018,
			["panV"] = 1.768124866610621,
		},
	}, -- [234]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -4.305000614954406,
			["panV"] = -3.664375360482472,
		},
	}, -- [235]
	{
		["rotation"] = 0.2474979643499895,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.05124765725372778,
			["panV"] = -0.05124909817081629,
		},
	}, -- [236]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.0256252695439524,
			["panV"] = -0.1024999974879972,
		},
	}, -- [237]
	{
		["rotation"] = 0.1649986428999959,
		["zoom"] = -11.22916710899941,
		["scale"] = 0.1,
		["position"] = {
			["panH"] = -0.9993725439603769,
			["panV"] = -1.66562631003972,
		},
	}, -- [238]
	{
		["rotation"] = 0.1925020248667791,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.2306274258955808,
			["panV"] = 0.7943747103600192,
		},
	}, -- [239]
	{
		["rotation"] = 0.1650017356000936,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.05125630275627252,
			["panV"] = 2.664999934687913,
		},
	}, -- [240]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.128123465885585,
			["panV"] = -0.1024999974879973,
		},
	}, -- [241]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.07687292679768476,
			["panV"] = 0.6406259749304782,
		},
	}, -- [242]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -4.551914400963142e-015,
			["panV"] = 0.02562490931468086,
		},
	}, -- [243]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.07687580863186169,
			["panV"] = -0.02562526954395484,
		},
	}, -- [244]
	{
		["rotation"] = 0.5224962179666646,
		["zoom"] = 0,
		["scale"] = 1.9,
		["position"] = {
			["panH"] = -0.205007920019996,
			["panV"] = -5.176249693029193,
		},
	}, -- [245]
	{
		["rotation"] = 0.109998064366635,
		["zoom"] = 0,
		["scale"] = 0.2499999999999997,
		["position"] = {
			["panH"] = -0.8199956571526943,
			["panV"] = -27.57250449130972,
		},
	}, -- [246]
	{
		["rotation"] = 0.3299972857999926,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.05124765725372769,
			["panV"] = -0.153750896805177,
		},
	}, -- [247]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.9225010580797873,
			["panV"] = 1.409374695287997,
		},
	}, -- [248]
	{
		["rotation"] = 0.5499995999334473,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.0256252695439524,
			["panV"] = -0.1793754458905851,
		},
	}, -- [249]
	{
		["rotation"] = 0.08250086780004678,
		["zoom"] = 0,
		["scale"] = 1.900000000000001,
		["position"] = {
			["panH"] = -0.07687580863185718,
			["panV"] = -0.4868747178960305,
		},
	}, -- [250]
	{
		["rotation"] = 0.1099980643666302,
		["zoom"] = -8.458336201169939,
		["scale"] = 0.2,
		["position"] = {
			["panH"] = -1.94749743066703,
			["panV"] = 17.21999957798343,
		},
	}, -- [251]
	{
		["rotation"] = 0.192501787673722,
		["zoom"] = 0.4083331183176366,
		["scale"] = 5.399999999999989,
		["position"] = {
			["panH"] = 0.10249883141869,
			["panV"] = -0.5124995734547275,
		},
	}, -- [252]
	{
		["rotation"] = 0.3024969965333118,
		["zoom"] = 0,
		["scale"] = 2.599999999999999,
		["position"] = {
			["panH"] = 0.2562440499369885,
			["panV"] = -0.4868754383545756,
		},
	}, -- [253]
	{
		["rotation"] = 0.1925020248667743,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0.02562526954394787,
			["panV"] = -0.153749816117359,
		},
	}, -- [254]
	{
		["rotation"] = 0.852499689166847,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.1025068418441727,
			["panV"] = -0.3075007129225366,
		},
	}, -- [255]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.850000000000001,
		["position"] = {
			["panH"] = 0.0256252695439524,
			["panV"] = -0.3587501713226248,
		},
	}, -- [256]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 1.3,
		["position"] = {
			["panH"] = -0.1793768868076804,
			["panV"] = 0.02562490931467972,
		},
	}, -- [257]
	{
		["rotation"] = 0.4399984428667199,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.07687292679768487,
			["panV"] = 0.1793750856613113,
		},
	}, -- [258]
	{
		["rotation"] = 0.275002892666821,
		["zoom"] = 0,
		["scale"] = 0.3999999999999996,
		["position"] = {
			["panH"] = 0.4099985490349026,
			["panV"] = 1.793750496383851,
		},
	}, -- [259]
	{
		["rotation"] = 0.2474964179999458,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = -0.05124765725372778,
			["panV"] = 1.306875058029275,
		},
	}, -- [260]
	{
		["rotation"] = 0.02750338196678281,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 0.0256252695439477,
			["panV"] = -0.230625264519948,
		},
	}, -- [261]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 2.100000000000001,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.4356252594959389,
		},
	}, -- [262]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.05124873037447177,
			["panV"] = -0.153749296119346,
		},
	}, -- [263]
	{
		["rotation"] = 0.05500057853336619,
		["zoom"] = 0,
		["scale"] = 0.2499999999999997,
		["position"] = {
			["panH"] = 0.6662512444744311,
			["panV"] = 4.919999519194566,
		},
	}, -- [264]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.2306245440614083,
			["panV"] = -7.204585459677504e-007,
		},
	}, -- [265]
	{
		["rotation"] = 0.4124981536000345,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.2049963926832698,
			["panV"] = 0.3074996322347178,
		},
	}, -- [266]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0.02562526954394787,
			["panV"] = -0.2050007154345398,
		},
	}, -- [267]
	{
		["rotation"] = 3.092700097184764e-006,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.02561950587558929,
			["panV"] = -0.1025007179465432,
		},
	}, -- [268]
	{
		["rotation"] = 0.2749967072666265,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -0.02562526954395695,
			["panV"] = -1.137978600240786e-015,
		},
	}, -- [269]
	{
		["rotation"] = 1.072502003300306,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0.05124621633662785,
			["panV"] = -0.1024985565709076,
		},
	}, -- [270]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.3331285040713994,
			["panV"] = 0.640625974930479,
		},
	}, -- [271]
	{
		["rotation"] = -0.1100011570667225,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.2818693194809409,
			["panV"] = 1.127499972367962,
		},
	}, -- [272]
	{
		["rotation"] = 0.3300034712001871,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.1025010781758141,
			["panV"] = -0.5381256172132113,
		},
	}, -- [273]
	{
		["rotation"] = 0.08250241415009138,
		["zoom"] = 0,
		["scale"] = 5.04999999999999,
		["position"] = {
			["panH"] = 0.05125342092209096,
			["panV"] = -0.6406259749304776,
		},
	}, -- [274]
	{
		["rotation"] = -0.1100011570667225,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 0.4099927853665304,
			["panV"] = 0.845624889218654,
		},
	}, -- [275]
	{
		["rotation"] = 0.1650017356000934,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = -0.2562469317711837,
			["panV"] = 0.5893743551547531,
		},
	}, -- [276]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -5.763668372200242e-006,
			["panV"] = 0.07687400748549658,
		},
	}, -- [277]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 2.775557561562891e-017,
			["panV"] = -0.2306242245239213,
		},
	}, -- [278]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 1.3,
		["position"] = {
			["panH"] = -0.1537487354295465,
			["panV"] = -0.1281252670319519,
		},
	}, -- [279]
	{
		["rotation"] = 0.3849978643333588,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.358752332698261,
			["panV"] = -0.1537501763466328,
		},
	}, -- [280]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.2999999999999997,
		["position"] = {
			["panH"] = -0.7431270531062928,
			["panV"] = -0.333125622237218,
		},
	}, -- [281]
	{
		["rotation"] = 0.6049955394166675,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.2818750831493084,
			["panV"] = 2.331875393138514,
		},
	}, -- [282]
	{
		["rotation"] = 0.4399984428667198,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.4356252594959368,
			["panV"] = 1.768124866610622,
		},
	}, -- [283]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.02562526954395695,
			["panV"] = 0.3843750806373046,
		},
	}, -- [284]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.07687292679768021,
			["panV"] = -0.1537498161173589,
		},
	}, -- [285]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 0.05124765725372779,
			["panV"] = 1.511874692775994,
		},
	}, -- [286]
	{
		["rotation"] = 0.2199992214333625,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.02563103321231096,
			["panV"] = -0.1024996372587258,
		},
	}, -- [287]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -0.05125342092209084,
			["panV"] = -0.07687508817331637,
		},
	}, -- [288]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -6.938893903907228e-018,
			["panV"] = 0.02562454908540702,
		},
	}, -- [289]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.07687676124744328,
			["panV"] = 0.4612513530125031,
		},
	}, -- [290]
	{
		["rotation"] = 0,
		["zoom"] = -12.39583404818044,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 1.204376141229096,
			["panV"] = 3.126250463727808,
		},
	}, -- [291]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = 0.02562526954395237,
			["panV"] = 3.792500627514422,
		},
	}, -- [292]
	{
		["rotation"] = 0.3024969965333073,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -2.881834176966802e-006,
			["panV"] = 0.999374705336013,
		},
	}, -- [293]
	{
		["rotation"] = 0.302496996533307,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.8200014208210548,
			["panV"] = 0.9481256071651942,
		},
	}, -- [294]
	{
		["rotation"] = 0.4400015355668172,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.02562238770977099,
			["panV"] = -0.5381252569839379,
		},
	}, -- [295]
	{
		["rotation"] = 0.2199992214333574,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.153748735429542,
			["panV"] = -0.2306252645199478,
		},
	}, -- [296]
	{
		["rotation"] = 0,
		["zoom"] = 0.1458324072209628,
		["scale"] = 0.2499999999999997,
		["position"] = {
			["panH"] = 1.050628846716641,
			["panV"] = 3.561875723223746,
		},
	}, -- [297]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.1281234658855896,
			["panV"] = 0.7431245315013841,
		},
	}, -- [298]
	{
		["rotation"] = 0.467501824833498,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.6406288567646693,
			["panV"] = 1.306875778487819,
		},
	}, -- [299]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.2306245440613992,
			["panV"] = 1.614374330034721,
		},
	}, -- [300]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.6406245340133879,
			["panV"] = 0.3331252620079429,
		},
	}, -- [301]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.05124765725372778,
			["panV"] = -0.05125089931718091,
		},
	}, -- [302]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 1.25,
		["position"] = {
			["panH"] = 1.383747264368404,
			["panV"] = 0.2306245440613982,
		},
	}, -- [303]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.1281177022172219,
			["panV"] = -0.07687508817331637,
		},
	}, -- [304]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.1793740049734898,
			["panV"] = 0.743125251959929,
		},
	}, -- [305]
	{
		["rotation"] = -0.9075018140502611,
		["zoom"] = -2.216666612342041,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = 2.280620171070067,
			["panV"] = 0.6662501637866118,
		},
	}, -- [306]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -2.881834186084509e-006,
			["panV"] = -2.178124856562611,
		},
	}, -- [307]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0.07687580863185263,
			["panV"] = -0.128125267031952,
		},
	}, -- [308]
	{
		["rotation"] = 0.1099980643666248,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.05125342092208636,
			["panV"] = -0.2049999949759927,
		},
	}, -- [309]
	{
		["rotation"] = 0.6325004677334941,
		["zoom"] = 0,
		["scale"] = 1.3,
		["position"] = {
			["panH"] = 0.1793740049734898,
			["panV"] = 0.384375440866578,
		},
	}, -- [310]
	{
		["rotation"] = 0.577499889200128,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.05125053908790483,
			["panV"] = -0.1024999974879972,
		},
	}, -- [311]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.6918765140183837,
			["panV"] = 1.845000675242484,
		},
	}, -- [312]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562526954395239,
			["panV"] = -0.3074999924639905,
		},
	}, -- [313]
	{
		["rotation"] = 0.02750028926668063,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -4.544975507059235e-015,
			["panV"] = -0.07687472794404365,
		},
	}, -- [314]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.871256282660241,
			["panV"] = 0.9481241662481046,
		},
	}, -- [315]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.05125342092208629,
			["panV"] = 0.3843747204080308,
		},
	}, -- [316]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 0.07687580863186175,
			["panV"] = 0.2050003552052648,
		},
	}, -- [317]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.02562314329199068,
			["panV"] = -0.1537505180145911,
		},
	}, -- [318]
	{
		["rotation"] = 0.3574975750666731,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.2306245440614037,
			["panV"] = 0.5893757960718433,
		},
	}, -- [319]
	{
		["rotation"] = 0.330000378500085,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = 0.153751617263728,
			["panV"] = 2.2293743149627,
		},
	}, -- [320]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.07687292679767574,
			["panV"] = 1.6656252293519,
		},
	}, -- [321]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.25,
		["position"] = {
			["panH"] = 0.3075061163616285,
			["panV"] = 0.2818747229200352,
		},
	}, -- [322]
	{
		["rotation"] = 0.137501446333413,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.05125053908790479,
			["panV"] = -0.5381245365253919,
		},
	}, -- [323]
	{
		["rotation"] = 0.1924989321666769,
		["zoom"] = 0,
		["scale"] = 2.449999999999999,
		["position"] = {
			["panH"] = 0.2562469317711746,
			["panV"] = -0.4868747178960302,
		},
	}, -- [324]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.05124477541955083,
			["panV"] = 0.4356252594959379,
		},
	}, -- [325]
	{
		["rotation"] = 0.3025000892334042,
		["zoom"] = 0,
		["scale"] = 1.750000000000001,
		["position"] = {
			["panH"] = 0.02562526954395697,
			["panV"] = -0.3587494508640785,
		},
	}, -- [326]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1.35,
		["position"] = {
			["panH"] = -0.07687292679768475,
			["panV"] = 0.3331259824664862,
		},
	}, -- [327]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.3,
		["position"] = {
			["panH"] = 0.05124765725372781,
			["panV"] = 0.3843754408665785,
		},
	}, -- [328]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = -0.768755204484431,
			["panV"] = 1.896249773413303,
		},
	}, -- [329]
	{
		["rotation"] = 0.2750028926668161,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.07687580863186176,
			["panV"] = 0.3331241813201246,
		},
	}, -- [330]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.02562526954394773,
			["panV"] = 0.6149999849279781,
		},
	}, -- [331]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 5,
		["scale"] = 6.099999999999986,
		["position"] = {
			["panH"] = 1.255626680317004,
			["panV"] = -16.78437700894988,
		},
	}, -- [332]
	{
		["rotation"] = 0.1650017356000935,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -4.551914400963142e-015,
			["panV"] = 0.2306252645199457,
		},
	}, -- [333]
	{
		["rotation"] = 0.5500042389835892,
		["zoom"] = 0,
		["scale"] = 5.949999999999987,
		["position"] = {
			["panH"] = 0.1281263477197619,
			["panV"] = -0.8968757885358337,
		},
	}, -- [334]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -2.881834186101856e-006,
			["panV"] = -0.0512498186293628,
		},
	}, -- [335]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.128129229553957,
			["panV"] = 0.6662498035573404,
		},
	}, -- [336]
	{
		["rotation"] = 0.3575022141168189,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.1025010781758142,
			["panV"] = -0.1024999974879972,
		},
	}, -- [337]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.02561950587559378,
			["panV"] = 0.5637498060693436,
		},
	}, -- [338]
	{
		["rotation"] = 0.1650001892500402,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.1024953145074511,
			["panV"] = -0.589374715384026,
		},
	}, -- [339]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = 0,
		},
	}, -- [340]
	{
		["rotation"] = 0.2749997999667237,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = -0.1281292295539481,
			["panV"] = 2.04999958953066,
		},
	}, -- [341]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = 0.1793768868076805,
			["panV"] = 3.023751546927629,
		},
	}, -- [342]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.1793766657868772,
			["panV"] = -2.613750059803875,
		},
	}, -- [343]
	{
		["rotation"] = -0.08249777509994952,
		["zoom"] = -1.749999547095079,
		["scale"] = 0.8500000000000002,
		["position"] = {
			["panH"] = 0.05124765725372289,
			["panV"] = -2.58812628743169,
		},
	}, -- [344]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = 0.1537516172637235,
			["panV"] = 2.101248687701475,
		},
	}, -- [345]
	{
		["rotation"] = 0.3575006677667706,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.0256252695439524,
			["panV"] = -0.2562508942931742,
		},
	}, -- [346]
	{
		["rotation"] = 0.3849978643333537,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -1.51187505300527,
			["panV"] = 1.973125582045162,
		},
	}, -- [347]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.02562526954395241,
			["panV"] = -0.1281252670319507,
		},
	}, -- [348]
	{
		["rotation"] = 0.014528039190842,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.09573002853579703,
		},
	}, -- [349]
	{
		["rotation"] = 0.5224962179666646,
		["zoom"] = 0,
		["scale"] = 1.55,
		["position"] = {
			["panH"] = 0.2049935108490836,
			["panV"] = -1.870624864098622,
		},
	}, -- [350]
	{
		["rotation"] = 0.467501824833498,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.2562498136053561,
			["panV"] = -0.1537498161173601,
		},
	}, -- [351]
	{
		["rotation"] = 0.1649955501998993,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.1281263477197666,
			["panV"] = 1.332499967343955,
		},
	}, -- [352]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 0.05125342092208639,
			["panV"] = -0.0768754484025902,
		},
	}, -- [353]
	{
		["rotation"] = 0.2199992214333628,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -6.938893903907228e-018,
			["panV"] = -0.2818747229200367,
		},
	}, -- [354]
	{
		["rotation"] = 1.622501603233753,
		["zoom"] = -1.48750047606664,
		["scale"] = 0.1999999999999997,
		["position"] = {
			["panH"] = 0.3074989117761626,
			["panV"] = 11.58250043660216,
		},
	}, -- [355]
	{
		["rotation"] = 0.330000378500085,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = 0.2306245440614082,
			["panV"] = 2.254998864048107,
		},
	}, -- [356]
	{
		["rotation"] = 0.2200023141334548,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.1024981963416371,
			["panV"] = 1.537500322549221,
		},
	}, -- [357]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = 0.1025007179465426,
		},
	}, -- [358]
	{
		["rotation"] = 0.6600007570001745,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.1025010781758142,
			["panV"] = -0.1281249068026781,
		},
	}, -- [359]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.1793711231393129,
			["panV"] = 0.6149999849279788,
		},
	}, -- [360]
	{
		["rotation"] = 0.2749997999667236,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.02562526954395696,
			["panV"] = -0.1793750856613113,
		},
	}, -- [361]
	{
		["rotation"] = 0.330000378500085,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.05125053908790034,
			["panV"] = 1.358124156200091,
		},
	}, -- [362]
	{
		["rotation"] = 0.522502403366864,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.3587508917811704,
			["panV"] = -0.07687472794404369,
		},
	}, -- [363]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = 0.05124189358536029,
			["panV"] = 0.1281252670319495,
		},
	}, -- [364]
	{
		["rotation"] = -0.02749410386648606,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.2562498136053563,
			["panV"] = 0.8712501587626083,
		},
	}, -- [365]
	{
		["rotation"] = 0.4400015355668124,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.4868743576667506,
			["panV"] = 0.1024999974879961,
		},
	}, -- [366]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.02562238770977088,
			["panV"] = -0.1793754458905851,
		},
	}, -- [367]
	{
		["rotation"] = 0.2750003736423952,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.05124873037447178,
			["panV"] = 0.128124830416475,
		},
	}, -- [368]
	{
		["rotation"] = 0.08249777509994936,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.3331256222372132,
			["panV"] = 0.614999624698705,
		},
	}, -- [369]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.409998549034898,
			["panV"] = 1.51187541323454,
		},
	}, -- [370]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = -0.3587508877832641,
			["panV"] = 2.536876863726532,
		},
	}, -- [371]
	{
		["rotation"] = 0,
		["zoom"] = 2.012500668208809,
		["scale"] = 4.199999999999993,
		["position"] = {
			["panH"] = 0.2818779649834901,
			["panV"] = 1.306875058029274,
		},
	}, -- [372]
	{
		["rotation"] = 0.4675018248334977,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.1025010781758097,
			["panV"] = -0.05125053908790755,
		},
	}, -- [373]
	{
		["rotation"] = 1.622501603233753,
		["zoom"] = -1.48750047606664,
		["scale"] = 0.1999999999999997,
		["position"] = {
			["panH"] = 0.2562483726882626,
			["panV"] = 11.1468755373355,
		},
	}, -- [374]
	{
		["rotation"] = 0.2750028926668161,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.07687580863185721,
			["panV"] = -0.02562490931468084,
		},
	}, -- [375]
	{
		["rotation"] = -0.1100042497668247,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.1537544990979051,
			["panV"] = -0.1281245465734059,
		},
	}, -- [376]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.1,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.07687508817331637,
		},
	}, -- [377]
	{
		["rotation"] = 0.6325004677334893,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -0.05124765725372781,
			["panV"] = -0.2818750831493085,
		},
	}, -- [378]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.02562526954395696,
			["panV"] = -0.1793754458905857,
		},
	}, -- [379]
	{
		["rotation"] = 0.1374998999833594,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.05125342092209551,
			["panV"] = 0.02562454908540816,
		},
	}, -- [380]
	{
		["rotation"] = 0.5224993106667667,
		["zoom"] = 0,
		["scale"] = 4.099999999999993,
		["position"] = {
			["panH"] = 0.2050021563516238,
			["panV"] = -0.1793747254320408,
		},
	}, -- [381]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.05124765725372325,
			["panV"] = 0.8712508792211529,
		},
	}, -- [382]
	{
		["rotation"] = 0.4124981536000393,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.3075003526932609,
			["panV"] = 0.3075003526932618,
		},
	}, -- [383]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.0256252695439524,
			["panV"] = -0.1537501763466316,
		},
	}, -- [384]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562526954395696,
			["panV"] = 0.5381252569839355,
		},
	}, -- [385]
	{
		["rotation"] = 0.06249924596736332,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = 1.127504655348506,
			["panV"] = -2.1525003074772,
		},
	}, -- [386]
	{
		["rotation"] = 0.1925011061276166,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.2050022528693583,
			["panV"] = -0.8199995920470994,
		},
	}, -- [387]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.1024981963416326,
			["panV"] = -0.2818750831493097,
		},
	}, -- [388]
	{
		["rotation"] = 0.1925011061276164,
		["zoom"] = 0,
		["scale"] = 1.25,
		["position"] = {
			["panH"] = 0.4612507923226979,
			["panV"] = -0.871248933369195,
		},
	}, -- [389]
	{
		["rotation"] = 0.3850009570334561,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.02562238770977083,
			["panV"] = 0.3843750806373049,
		},
	}, -- [390]
	{
		["rotation"] = 0.05500367123346341,
		["zoom"] = 0,
		["scale"] = 1.800000000000001,
		["position"] = {
			["panH"] = 0.02562526954394786,
			["panV"] = -0.2050007154345399,
		},
	}, -- [391]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.3587508917811746,
			["panV"] = 0.6150003451572514,
		},
	}, -- [392]
	{
		["rotation"] = 0.1100011570667372,
		["zoom"] = 0,
		["scale"] = 1.950000000000001,
		["position"] = {
			["panH"] = 0.07687292679767567,
			["panV"] = -0.3587498110933522,
		},
	}, -- [393]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 2.000000000000001,
		["position"] = {
			["panH"] = -0.05125053908790935,
			["panV"] = -0.4099999899519854,
		},
	}, -- [394]
	{
		["rotation"] = 0.08250120857310196,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.1793742219963869,
			["panV"] = 0.2049997588210505,
		},
	}, -- [395]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -7.979727989493313e-017,
			["panV"] = 2.485625209255872,
		},
	}, -- [396]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.05125630275626786,
			["panV"] = 0.6918736321842031,
		},
	}, -- [397]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.07687869046603878,
			["panV"] = 0.2818750831493086,
		},
	}, -- [398]
	{
		["rotation"] = 0.1650004760878807,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.05125117416496221,
			["panV"] = -0.2306242245239214,
		},
	}, -- [399]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.07687508817331637,
		},
	}, -- [400]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.02562815137813395,
			["panV"] = -0.1537498161173589,
		},
	}, -- [401]
	{
		["rotation"] = 0.2749967072666264,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.07687580863186176,
			["panV"] = -0.1024999974879972,
		},
	}, -- [402]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -4.551914400963142e-015,
			["panV"] = 0.3074996322347156,
		},
	}, -- [403]
	{
		["rotation"] = 0.6875025926168992,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = 0.9481220048724672,
			["panV"] = 1.742500677754489,
		},
	}, -- [404]
	{
		["rotation"] = 1.284997918248523,
		["zoom"] = 0,
		["scale"] = 0.2499999999999997,
		["position"] = {
			["panH"] = -0.07687148588059443,
			["panV"] = 11.09562679939396,
		},
	}, -- [405]
	{
		["rotation"] = 0.2750059853669182,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 2.881834186101856e-006,
			["panV"] = 0.05125125954645135,
		},
	}, -- [406]
	{
		["rotation"] = 0.2475026034001451,
		["zoom"] = 0,
		["scale"] = 1.900000000000001,
		["position"] = {
			["panH"] = -2.881834181529125e-006,
			["panV"] = -0.3587508917811703,
		},
	}, -- [407]
	{
		["rotation"] = -0.1374983536333108,
		["zoom"] = -6.504167839822218,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = 0.7943747103600207,
			["panV"] = 4.40749917152531,
		},
	}, -- [408]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.1025010781758142,
			["panV"] = 0.7943757910478378,
		},
	}, -- [409]
	{
		["rotation"] = -0.3849994106834024,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.9737501562506015,
			["panV"] = 2.255000304965197,
		},
	}, -- [410]
	{
		["rotation"] = 0.2200023141334597,
		["zoom"] = -2.01250107822587,
		["scale"] = 0.3999999999999996,
		["position"] = {
			["panH"] = 0.07687580863185262,
			["panV"] = 4.048750080890503,
		},
	}, -- [411]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -1.153125602141187,
			["panV"] = 1.434999604602679,
		},
	}, -- [412]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.07687292679768018,
			["panV"] = 1.691250498895853,
		},
	}, -- [413]
	{
		["rotation"] = 0.6124988459008054,
		["zoom"] = 0,
		["scale"] = 0.3499999999999996,
		["position"] = {
			["panH"] = -0.5381248967546651,
			["panV"] = 3.151873571896125,
		},
	}, -- [414]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.05124189358536471,
			["panV"] = 0.7431245315013841,
		},
	}, -- [415]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0.3587484439927741,
			["panV"] = 0.25625032203839,
		},
	}, -- [416]
	{
		["rotation"] = 0.3575006677667615,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = -0.2562469317711745,
			["panV"] = 2.485624128568053,
		},
	}, -- [417]
	{
		["rotation"] = -0.1650017356000935,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.1024981963416371,
			["panV"] = 0.1024996372587257,
		},
	}, -- [418]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 2.881834177022313e-006,
			["panV"] = -0.05125089931718092,
		},
	}, -- [419]
	{
		["rotation"] = 0.02750028926668038,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02563247412941526,
			["panV"] = -0.3587490906348084,
		},
	}, -- [420]
	{
		["rotation"] = 0.2474995107000431,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.02562815137813847,
			["panV"] = 1.05062524442392,
		},
	}, -- [421]
	{
		["rotation"] = 0.2199961287332651,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.2306274258955853,
			["panV"] = 1.306874337570729,
		},
	}, -- [422]
	{
		["rotation"] = 0.4400046282669048,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.07687292679767566,
			["panV"] = -0.3843754408665784,
		},
	}, -- [423]
	{
		["rotation"] = 2.742499332232235,
		["zoom"] = 0.4958344487286827,
		["scale"] = 0.15,
		["position"] = {
			["panH"] = 0.9993711030432793,
			["panV"] = 12.09500078427141,
		},
	}, -- [424]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1.35,
		["position"] = {
			["panH"] = -0.02562526954395694,
			["panV"] = 1.691251219354397,
		},
	}, -- [425]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.07687676124744317,
			["panV"] = 3.04937516452846,
		},
	}, -- [426]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -2.42861286636753e-017,
			["panV"] = -0.1281252670319517,
		},
	}, -- [427]
	{
		["rotation"] = -0.2750028926668213,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = 0.384373279490941,
			["panV"] = 1.9218757634158,
		},
	}, -- [428]
	{
		["rotation"] = 0.1099980643666305,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.1281263477197667,
			["panV"] = 1.819374325010711,
		},
	}, -- [429]
	{
		["rotation"] = 0.4124981536000346,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.2818693194809455,
			["panV"] = 1.716874327522716,
		},
	}, -- [430]
	{
		["rotation"] = 0.3025000892334042,
		["zoom"] = 0,
		["scale"] = 2.3,
		["position"] = {
			["panH"] = -0.02562238770976627,
			["panV"] = -0.3587498110933511,
		},
	}, -- [431]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.6406230930962972,
			["panV"] = -0.6406256147012096,
		},
	}, -- [432]
	{
		["rotation"] = 0.1649986428999963,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = 0.6149963826352543,
			["panV"] = 1.921874682727981,
		},
	}, -- [433]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.128123465885585,
			["panV"] = 0.02562454908540701,
		},
	}, -- [434]
	{
		["rotation"] = 0.05499748583326879,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = 0.1793725640563946,
			["panV"] = 0.6406256147012053,
		},
	}, -- [435]
	{
		["rotation"] = 0.3300003785000895,
		["zoom"] = -1.633333703321719,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -0.07687580863186175,
			["panV"] = -0.4099999899519872,
		},
	}, -- [436]
	{
		["rotation"] = 0.0550005785333612,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.02562526954394784,
			["panV"] = -0.2306245440614026,
		},
	}, -- [437]
	{
		["rotation"] = 0.2474995107000429,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.02562526954395239,
			["panV"] = -0.2818754433785825,
		},
	}, -- [438]
	{
		["rotation"] = 0.5225024033668593,
		["zoom"] = 0,
		["scale"] = 1.5,
		["position"] = {
			["panH"] = 0.4356223776617553,
			["panV"] = -3.602292734036783e-007,
		},
	}, -- [439]
	{
		["rotation"] = 0.2200023141334547,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02561950587559384,
			["panV"] = -0.8712494383040635,
		},
	}, -- [440]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8499999999999996,
		["position"] = {
			["panH"] = -0.05125053908790939,
			["panV"] = 0.07687436771476836,
		},
	}, -- [441]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.128123465885585,
			["panV"] = 3.280000640074438,
		},
	}, -- [442]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.07687508817331637,
		},
	}, -- [443]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = 0,
		},
	}, -- [444]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 2.881834176994558e-006,
			["panV"] = 0.1024996372587228,
		},
	}, -- [445]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0.5250006021592286,
		["scale"] = 0.1999999999999997,
		["position"] = {
			["panH"] = 0.3843819249934858,
			["panV"] = 1.665625949810445,
		},
	}, -- [446]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.02562238770977084,
			["panV"] = -0.1281256272612235,
		},
	}, -- [447]
	{
		["rotation"] = 0.2475041497501938,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.1281234658855851,
			["panV"] = -0.6406252544719342,
		},
	}, -- [448]
	{
		["rotation"] = 0.1650017356000934,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.230624544061399,
			["panV"] = 1.716875768439805,
		},
	}, -- [449]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562526954395695,
			["panV"] = -0.07687508817331637,
		},
	}, -- [450]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.3587537736153518,
			["panV"] = 1.768125226839896,
		},
	}, -- [451]
	{
		["rotation"] = 1.155004417450402,
		["zoom"] = 0,
		["scale"] = 0.2499999999999997,
		["position"] = {
			["panH"] = -0.4099956672007163,
			["panV"] = 9.814376650679353,
		},
	}, -- [452]
	{
		["rotation"] = -0.4399984428667149,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.1024981963416326,
			["panV"] = 1.742501398213034,
		},
	}, -- [453]
	{
		["rotation"] = 0.2199992214333624,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.2818779649834946,
			["panV"] = 0.8456252494479269,
		},
	}, -- [454]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = 0.6149978235523452,
			["panV"] = -1.870624864098621,
		},
	}, -- [455]
	{
		["rotation"] = 0.1374983536333106,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.07687292679768029,
			["panV"] = 0.7687505215038835,
		},
	}, -- [456]
	{
		["rotation"] = 0.3850009570334511,
		["zoom"] = 0,
		["scale"] = 3.749999999999995,
		["position"] = {
			["panH"] = 0.1025010781758096,
			["panV"] = -0.3587498110933534,
		},
	}, -- [457]
	{
		["rotation"] = -0.7975006569835288,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 13.53000110933265,
			["panV"] = 1.844999954783938,
		},
	}, -- [458]
	{
		["rotation"] = 0.3025031819335065,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.07687580863186173,
			["panV"] = -0.1024999974879961,
		},
	}, -- [459]
	{
		["rotation"] = 0.2749997999667238,
		["zoom"] = 0,
		["scale"] = 0.5999999999999998,
		["position"] = {
			["panH"] = 0.3331299449884811,
			["panV"] = 2.613750116058551,
		},
	}, -- [460]
	{
		["rotation"] = 0.2749967072666266,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.2049992745174467,
			["panV"] = 1.204375780999824,
		},
	}, -- [461]
	{
		["rotation"] = 0.4125012463001317,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.1025010781758096,
			["panV"] = -0.5637501662986183,
		},
	}, -- [462]
	{
		["rotation"] = -0.4124981536000343,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.6662512444744312,
			["panV"] = 2.255000304965197,
		},
	}, -- [463]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 1.204381904897459,
			["panV"] = 1.255624879170639,
		},
	}, -- [464]
	{
		["rotation"] = 0.330000378500085,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.1281263477197621,
			["panV"] = 2.152499226789385,
		},
	}, -- [465]
	{
		["rotation"] = -0.4949990214000812,
		["zoom"] = -0.4375000917822993,
		["scale"] = 0.2604167432743444,
		["position"] = {
			["panH"] = 0.4100014308690703,
			["panV"] = 1.358123795970818,
		},
	}, -- [466]
	{
		["rotation"] = 0.1650001892500352,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.2306245440614085,
			["panV"] = 2.024375760903797,
		},
	}, -- [467]
	{
		["rotation"] = 0.3024969965333071,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.02563103321231123,
			["panV"] = 0.5893743551547523,
		},
	}, -- [468]
	{
		["rotation"] = 0.330000378500085,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.05125053908790031,
			["panV"] = 2.408749400624013,
		},
	}, -- [469]
	{
		["rotation"] = 0.2749997999667285,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.07687580863186175,
			["panV"] = -0.1025010781758164,
		},
	}, -- [470]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 3.122502256758253e-017,
			["panV"] = -0.2562505340639009,
		},
	}, -- [471]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -6.938893903907228e-018,
			["panV"] = 0.02562454908540702,
		},
	}, -- [472]
	{
		["rotation"] = 0.3025031819335016,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = 0.2049963926832652,
			["panV"] = 0.640624534013387,
		},
	}, -- [473]
	{
		["rotation"] = 0.3025000892334044,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562526954395681,
			["panV"] = -0.2818747229200369,
		},
	}, -- [474]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.2818750831493085,
			["panV"] = -0.05125017885863552,
		},
	}, -- [475]
	{
		["rotation"] = 0.4400015355668172,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.3331227404030318,
			["panV"] = 0.3074999924639895,
		},
	}, -- [476]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.05125053908790481,
			["panV"] = -0.1145867700446413,
		},
	}, -- [477]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1.35,
		["position"] = {
			["panH"] = -0.5381248967546646,
			["panV"] = 0.179375445890583,
		},
	}, -- [478]
	{
		["rotation"] = 0.2749967072666311,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.05125053908790937,
			["panV"] = -0.5381248967546654,
		},
	}, -- [479]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -4.551914400963142e-015,
			["panV"] = -0.2050003552052671,
		},
	}, -- [480]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.1025010781758231,
			["panV"] = 1.101875783511829,
		},
	}, -- [481]
	{
		["rotation"] = 0.3025000892334091,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = 0.05125342092209083,
			["panV"] = -0.3587505315518976,
		},
	}, -- [482]
	{
		["rotation"] = 0.4124981536000347,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.05125053908790935,
			["panV"] = 0.3843758010958501,
		},
	}, -- [483]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 0.2562483726882608,
			["panV"] = 0.2562501738346276,
		},
	}, -- [484]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.3843790431593041,
			["panV"] = 0.7431248917306546,
		},
	}, -- [485]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = 0,
		["scale"] = 2.050000000000001,
		["position"] = {
			["panH"] = 0.07687869046603875,
			["panV"] = -0.3331252620079452,
		},
	}, -- [486]
	{
		["rotation"] = 0.3025000892334093,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.2818750831493085,
			["panV"] = -1.94749923181339,
		},
	}, -- [487]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.02562526954395695,
			["panV"] = -3.602292726959111e-007,
		},
	}, -- [488]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = -0.174999790702685,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.230628866812676,
			["panV"] = -0.3587505315518963,
		},
	}, -- [489]
	{
		["rotation"] = 0.494999021400081,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.0768786904660433,
			["panV"] = -0.1537505365759036,
		},
	}, -- [490]
	{
		["rotation"] = 0.3575053068169123,
		["zoom"] = 0,
		["scale"] = 5.949999999999987,
		["position"] = {
			["panH"] = 0.2818750831493039,
			["panV"] = -0.9225010580797872,
		},
	}, -- [491]
	{
		["rotation"] = 1.595001313967073,
		["zoom"] = 0,
		["scale"] = 2.899999999999998,
		["position"] = {
			["panH"] = 6.124374579735843,
			["panV"] = -1.28124942825605,
		},
	}, -- [492]
	{
		["rotation"] = 0.3849963179833053,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = -2.881834181543003e-006,
			["panV"] = -7.204585459712198e-007,
		},
	}, -- [493]
	{
		["rotation"] = 0.2474964179999458,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = -0.05124765725372778,
			["panV"] = 1.306875058029275,
		},
	}, -- [494]
	{
		["rotation"] = 0.6874979535667577,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = -0.4868743576667552,
			["panV"] = 0.3074999924639904,
		},
	}, -- [495]
	{
		["rotation"] = 2.097498437706345,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.05125117416496215,
			["panV"] = -0.8199986756256664,
		},
	}, -- [496]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.1,
		["position"] = {
			["panH"] = 0.7431270531062885,
			["panV"] = -2.51125047879983,
		},
	}, -- [497]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.02562238770977538,
			["panV"] = -0.1025003577172699,
		},
	}, -- [498]
	{
		["rotation"] = 0.1374983536333107,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.1025010781758096,
			["panV"] = 1.460625234375909,
		},
	}, -- [499]
	{
		["rotation"] = 0.467501824833498,
		["zoom"] = -0.1166666638074765,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.2306259849784901,
			["panV"] = 0.6406245340133868,
		},
	}, -- [500]
	{
		["rotation"] = 0,
		["zoom"] = 0.3499999914224269,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.07687292679767566,
			["panV"] = 0.1024992770294507,
		},
	}, -- [501]
	{
		["rotation"] = 0.3574975750666682,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -0.1281249068026758,
			["panV"] = -0.02562490931468194,
		},
	}, -- [502]
	{
		["rotation"] = 0.1099949716665328,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.07687580863186175,
			["panV"] = -0.4100003501812594,
		},
	}, -- [503]
	{
		["rotation"] = 0.8250024926002675,
		["zoom"] = -1.48750047606664,
		["scale"] = 0.1999999999999997,
		["position"] = {
			["panH"] = 0.1537501763466302,
			["panV"] = 10.42937555491952,
		},
	}, -- [504]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.1024981963416326,
			["panV"] = 2.075624498845339,
		},
	}, -- [505]
	{
		["rotation"] = 0.5224946716166162,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -2.881834181615861e-006,
			["panV"] = -0.05124981862936394,
		},
	}, -- [506]
	{
		["rotation"] = 0.137499899983364,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -0.1537516172637279,
			["panV"] = 0.6918747128720231,
		},
	}, -- [507]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -0.05125053908791394,
			["panV"] = -0.05125053908790717,
		},
	}, -- [508]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.2499999999999997,
		["position"] = {
			["panH"] = -0.6406259749304787,
			["panV"] = 0.7943754308185641,
		},
	}, -- [509]
	{
		["rotation"] = 0.330000378500085,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.2049978336003515,
			["panV"] = 0.4356238185788496,
		},
	}, -- [510]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.1,
		["position"] = {
			["panH"] = -2.443790490316844e-006,
			["panV"] = 5.8424993960709,
		},
	}, -- [511]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.3331241813201271,
			["panV"] = 1.614375410722538,
		},
	}, -- [512]
	{
		["rotation"] = 0.3850009570334511,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.1024981963416326,
			["panV"] = -0.2050007154345398,
		},
	}, -- [513]
	{
		["rotation"] = 0.3025000892334092,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = 0.4356238185788409,
			["panV"] = 1.768125947298442,
		},
	}, -- [514]
	{
		["rotation"] = 0.43999844286672,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.2562498136053606,
			["panV"] = -0.07687508817331638,
		},
	}, -- [515]
	{
		["rotation"] = 0.3025000892334043,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -0.1025010781758142,
			["panV"] = 0.05124981862936055,
		},
	}, -- [516]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.02562238770977538,
			["panV"] = 0.3074985515468975,
		},
	}, -- [517]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = -1.283333301882234,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 0.05125053908790937,
			["panV"] = -0.4868754383545758,
		},
	}, -- [518]
	{
		["rotation"] = 1.320001514000349,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.2818765240663993,
			["panV"] = 0.1024996372587222,
		},
	}, -- [519]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562526954395695,
			["panV"] = 0.2818743626907621,
		},
	}, -- [520]
	{
		["rotation"] = 0.2474995107000381,
		["zoom"] = 0,
		["scale"] = 1.700000000000001,
		["position"] = {
			["panH"] = -0.02562526954395695,
			["panV"] = 0.05124981862936056,
		},
	}, -- [521]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -0.05125053908790934,
			["panV"] = 0.7174996221867033,
		},
	}, -- [522]
	{
		["rotation"] = 0.330000378500085,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 1.204374700312009,
			["panV"] = 1.17874907053878,
		},
	}, -- [523]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 1.25,
		["position"] = {
			["panH"] = 0.05124477541953718,
			["panV"] = 0.07687508817331411,
		},
	}, -- [524]
	{
		["rotation"] = 0.247499510700043,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.07687869046603871,
			["panV"] = 0.3587501713226238,
		},
	}, -- [525]
	{
		["rotation"] = -0.3300034712001823,
		["zoom"] = -0.7291661362754011,
		["scale"] = 1.25,
		["position"] = {
			["panH"] = 0.1537458535953513,
			["panV"] = -0.2818758036078563,
		},
	}, -- [526]
	{
		["rotation"] = 0.1374983536333106,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -0.0768758086318662,
			["panV"] = 0.7431252519599289,
		},
	}, -- [527]
	{
		["rotation"] = 0.6049974437015101,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.05125117416496233,
			["panV"] = 2.511251276644051,
		},
	}, -- [528]
	{
		["rotation"] = 1.622501603233753,
		["zoom"] = -1.48750047606664,
		["scale"] = 0.1999999999999997,
		["position"] = {
			["panH"] = 0.5893754358425667,
			["panV"] = 9.891249217247763,
		},
	}, -- [529]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 5,
		["scale"] = 6.099999999999986,
		["position"] = {
			["panH"] = -4.612499526730575,
			["panV"] = -2.946875738295768,
		},
	}, -- [530]
	{
		["rotation"] = 0.3025000892334043,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.1281263477197666,
			["panV"] = -0.2306249042906753,
		},
	}, -- [531]
	{
		["rotation"] = 0.4399984428667199,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.05125342092208635,
			["panV"] = -0.1793761663491311,
		},
	}, -- [532]
	{
		["rotation"] = 0.4949928359998918,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = 2.881834186126142e-006,
			["panV"] = 1.844999234325393,
		},
	}, -- [533]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.07687676124744328,
			["panV"] = 0.05125032606291975,
		},
	}, -- [534]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -3.469446951953614e-018,
			["panV"] = -0.07687436771477035,
		},
	}, -- [535]
	{
		["rotation"] = 0.5775060746003233,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = -1.230001410773053,
			["panV"] = 0.07687472794404267,
		},
	}, -- [536]
	{
		["rotation"] = -0.4949989092392064,
		["zoom"] = 0,
		["scale"] = 0.3083333299184841,
		["position"] = {
			["panH"] = 0.2562485394533398,
			["panV"] = 1.281250069329961,
		},
	}, -- [537]
	{
		["rotation"] = 0.2200023141334548,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = -0.05125053908790933,
			["panV"] = -0.1024992770294507,
		},
	}, -- [538]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = 0.2306259849784855,
			["panV"] = 0.8199999799039713,
		},
	}, -- [539]
	{
		["rotation"] = -1.347494071516785,
		["zoom"] = 0,
		["scale"] = 3.099999999999997,
		["position"] = {
			["panH"] = 0.1025082827612636,
			["panV"] = 11.88999970860762,
		},
	}, -- [540]
	{
		["rotation"] = 0.08999953523404433,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = -0.333125622237213,
			["panV"] = 1.639998879120129,
		},
	}, -- [541]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.3,
		["position"] = {
			["panH"] = 0.1281263477197712,
			["panV"] = 0.5893761563011161,
		},
	}, -- [542]
	{
		["rotation"] = 0.3574975750666729,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = -0.2050007154345381,
			["panV"] = 2.690625204231866,
		},
	}, -- [543]
	{
		["rotation"] = 0.522499310666762,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.6662570081428035,
			["panV"] = 1.281249068026776,
		},
	}, -- [544]
	{
		["rotation"] = -0.2200023141334548,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 0.1537458535953604,
			["panV"] = 0.02562599000249782,
		},
	}, -- [545]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.02562238770977085,
			["panV"] = -0.05125017885863663,
		},
	}, -- [546]
	{
		["rotation"] = 0.3850009570334511,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.1024981963416326,
			["panV"] = -0.2050007154345398,
		},
	}, -- [547]
	{
		["rotation"] = 0.3025031819335016,
		["zoom"] = 0,
		["scale"] = 0.3499999999999996,
		["position"] = {
			["panH"] = 0.3843732794909316,
			["panV"] = 2.357500302453195,
		},
	}, -- [548]
	{
		["rotation"] = 0.4950021141001831,
		["zoom"] = 0,
		["scale"] = 0.4499999999999994,
		["position"] = {
			["panH"] = -2.56249525421938,
			["panV"] = -2.280625214279881,
		},
	}, -- [549]
	{
		["rotation"] = 0.6049970857667113,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -1.229998528938867,
			["panV"] = 1.511876133693087,
		},
	}, -- [550]
	{
		["rotation"] = 0.3025031819335065,
		["zoom"] = 0,
		["scale"] = 1.35,
		["position"] = {
			["panH"] = -0.1281263477197666,
			["panV"] = -0.8712501587626091,
		},
	}, -- [551]
	{
		["rotation"] = 0.1374983536333059,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 5.763668363155394e-006,
			["panV"] = -0.02562454908540757,
		},
	}, -- [552]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 5.763668358575724e-006,
			["panV"] = -0.1537494558880885,
		},
	}, -- [553]
	{
		["rotation"] = 0.2475026034001402,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -8.645502549094186e-006,
			["panV"] = -0.1537505365759053,
		},
	}, -- [554]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.02562526954395238,
			["panV"] = 1.153125241911916,
		},
	}, -- [555]
	{
		["rotation"] = 1.622501603233753,
		["zoom"] = -1.48750047606664,
		["scale"] = 0.1999999999999997,
		["position"] = {
			["panH"] = 0.02562382862685894,
			["panV"] = 10.45499974377566,
		},
	}, -- [556]
	{
		["rotation"] = 0.3850009570334509,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.6662512444744266,
			["panV"] = -0.1537501763466327,
		},
	}, -- [557]
	{
		["rotation"] = 0.1924958394665797,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.02562815137813846,
			["panV"] = 0.1793747254320398,
		},
	}, -- [558]
	{
		["rotation"] = 0.1649986428999959,
		["zoom"] = -1.749999547095079,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.2818722013151316,
			["panV"] = -1.02500285671415,
		},
	}, -- [559]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.05125053908790932,
			["panV"] = 4.868750781253024,
		},
	}, -- [560]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.750000000000001,
		["position"] = {
			["panH"] = -2.881834190494176e-006,
			["panV"] = 1.588749420720039,
		},
	}, -- [561]
	{
		["rotation"] = 0.08250396050014404,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = 0.05124765725372325,
			["panV"] = 1.40937505551727,
		},
	}, -- [562]
	{
		["rotation"] = 1.622501603233753,
		["zoom"] = -1.48750047606664,
		["scale"] = 0.2,
		["position"] = {
			["panH"] = 0.230624544061401,
			["panV"] = 11.22374918459171,
		},
	}, -- [563]
	{
		["rotation"] = 0.8249963072000683,
		["zoom"] = -2.625001780744966,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -1.691250498895861,
			["panV"] = 0.6662505240158854,
		},
	}, -- [564]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.3587537736153427,
			["panV"] = 1.870625224327893,
		},
	}, -- [565]
	{
		["rotation"] = 0.4675018248334978,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -1.204376141229105,
			["panV"] = 1.486250143690586,
		},
	}, -- [566]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.1024981963416371,
			["panV"] = 7.204585441844547e-007,
		},
	}, -- [567]
	{
		["rotation"] = 0.1925020248667742,
		["zoom"] = 0.233332507580835,
		["scale"] = 0.2999999999999997,
		["position"] = {
			["panH"] = -0.6662541263086081,
			["panV"] = 2.99812555692513,
		},
	}, -- [568]
	{
		["rotation"] = 0.3025000892334043,
		["zoom"] = 0,
		["scale"] = 0.3499999999999996,
		["position"] = {
			["panH"] = -0.1025010781758187,
			["panV"] = 1.793749775925305,
		},
	}, -- [569]
	{
		["rotation"] = -2.812500338335683,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = -0.07687508817331637,
		},
	}, -- [570]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.02562815137813397,
			["panV"] = 1.076249793509327,
		},
	}, -- [571]
	{
		["rotation"] = 0.08250086780004175,
		["zoom"] = -7.204167194828455,
		["scale"] = 0.1,
		["position"] = {
			["panH"] = 0.1537516172637144,
			["panV"] = 6.713751096266237,
		},
	}, -- [572]
	{
		["rotation"] = 0,
		["zoom"] = 0.4083331183176366,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.05124765725372781,
			["panV"] = 0.3587505315518948,
		},
	}, -- [573]
	{
		["rotation"] = 0.385000957033451,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.9737515971676968,
			["panV"] = 1.640000680266491,
		},
	}, -- [574]
	{
		["rotation"] = 0.4125012463001365,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.8199999799039822,
			["panV"] = 1.332499967343956,
		},
	}, -- [575]
	{
		["rotation"] = 1.265000935466984,
		["zoom"] = -6.679167835533423,
		["scale"] = 0.3499999999999996,
		["position"] = {
			["panH"] = 0.3331227404030275,
			["panV"] = 15.75937722544171,
		},
	}, -- [576]
	{
		["rotation"] = 0.4949990214000811,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.9481292094579257,
			["panV"] = 1.665624869122625,
		},
	}, -- [577]
	{
		["rotation"] = 0,
		["zoom"] = -0.2041663541502892,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.07687292679768476,
			["panV"] = 0.5893754358425722,
		},
	}, -- [578]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.02562526954395238,
			["panV"] = -0.1281252670319521,
		},
	}, -- [579]
	{
		["rotation"] = 0.1724973103339891,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = -0.02562382862686221,
			["panV"] = 2.716248312400184,
		},
	}, -- [580]
	{
		["rotation"] = -4.878042414446782e-015,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.2306216622272269,
			["panV"] = 2.126875037933248,
		},
	}, -- [581]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.02562526954395695,
			["panV"] = 0.02562454908540702,
		},
	}, -- [582]
	{
		["rotation"] = 0.6600007570001698,
		["zoom"] = 0,
		["scale"] = 0.4999999999999996,
		["position"] = {
			["panH"] = 0.07687580863185722,
			["panV"] = 1.845001035471759,
		},
	}, -- [583]
	{
		["rotation"] = 0.3025000892334043,
		["zoom"] = -0.7875004932217861,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -1.691244735227498,
			["panV"] = 1.409377216892907,
		},
	}, -- [584]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.230624544061399,
			["panV"] = 0.3331249017786703,
		},
	}, -- [585]
	{
		["rotation"] = 0.4949897432997798,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = 1.1018721812191,
			["panV"] = 1.53750140323704,
		},
	}, -- [586]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.9224981762456063,
			["panV"] = 1.537499962319948,
		},
	}, -- [587]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.2999999999999997,
		["position"] = {
			["panH"] = -0.2306245440614037,
			["panV"] = 4.253751516783588,
		},
	}, -- [588]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.05125053908791392,
			["panV"] = 0.4099999899519853,
		},
	}, -- [589]
	{
		["rotation"] = 0.5775029819002252,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.05124765725373236,
			["panV"] = 0.02562490931467914,
		},
	}, -- [590]
	{
		["rotation"] = -0.5774967965000306,
		["zoom"] = -2.158334715498007,
		["scale"] = 0.7604167432743446,
		["position"] = {
			["panH"] = 1.691251939812928,
			["panV"] = 0.7687490805867946,
		},
	}, -- [591]
	{
		["rotation"] = 0.3574975750666729,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -1.229999969855958,
			["panV"] = 2.12687539816252,
		},
	}, -- [592]
	{
		["rotation"] = 1.155002871100348,
		["zoom"] = 0,
		["scale"] = 0.1499999999999997,
		["position"] = {
			["panH"] = -9.91687124472827,
			["panV"] = 18.06562698880701,
		},
	}, -- [593]
	{
		["rotation"] = 0.2200023141334548,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.0768786904660432,
			["panV"] = -0.05124837771227208,
		},
	}, -- [594]
	{
		["rotation"] = 0.4674987321334005,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.1025010781758142,
			["panV"] = -0.1281249068026781,
		},
	}, -- [595]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.1281263477197711,
			["panV"] = 0.07687508817331409,
		},
	}, -- [596]
	{
		["rotation"] = 0.4124981536000345,
		["zoom"] = -0.1458336372721389,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.1281292295539526,
			["panV"] = -0.3587505315518976,
		},
	}, -- [597]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.2562498136053605,
			["panV"] = 0.5637501662986182,
		},
	}, -- [598]
	{
		["rotation"] = 0.3300003785000849,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.02562526954395695,
			["panV"] = 0.1793743652027659,
		},
	}, -- [599]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.358755214532438,
			["panV"] = 0.6406248942426597,
		},
	}, -- [600]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = 0.05124873037447177,
			["panV"] = -0.819999897520912,
		},
	}, -- [601]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.0256281513781338,
			["panV"] = 0.05124981862936176,
		},
	}, -- [602]
	{
		["rotation"] = 0.3299972857999877,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = 0.8712505189918738,
			["panV"] = 1.076249433280055,
		},
	}, -- [603]
	{
		["rotation"] = -0.1925020248667746,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 2.88183418156035e-006,
			["panV"] = 0.2562483726882631,
		},
	}, -- [604]
	{
		["rotation"] = -0.02749719656659319,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -4.53109771925142e-015,
			["panV"] = -0.1025003577172711,
		},
	}, -- [605]
	{
		["rotation"] = -0.2200007677834012,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.05124765725372781,
			["panV"] = 0.128124906802677,
		},
	}, -- [606]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.02562959229522896,
			["panV"] = -0.6662505240158886,
		},
	}, -- [607]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.1,
		["position"] = {
			["panH"] = -0.8968757885358346,
			["panV"] = -1.46062559460518,
		},
	}, -- [608]
	{
		["rotation"] = 0.4399984428667151,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 0.8199970980697873,
			["panV"] = 0.9737497960213304,
		},
	}, -- [609]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.02562238770977538,
			["panV"] = -0.1281252670319519,
		},
	}, -- [610]
	{
		["rotation"] = 0.2475026034001352,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 2.881834177008436e-006,
			["panV"] = -0.2050003552052681,
		},
	}, -- [611]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -3.469446951953614e-018,
			["panV"] = -0.07687436771477035,
		},
	}, -- [612]
	{
		["rotation"] = 0.1924989321666769,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 0.8712461962406105,
			["panV"] = 1.02499925442142,
		},
	}, -- [613]
	{
		["rotation"] = 0.1924958394665795,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -0.05124477541954628,
			["panV"] = 0.3843761613251216,
		},
	}, -- [614]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.3331227404030364,
			["panV"] = 0.6150007053865243,
		},
	}, -- [615]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = -0.1537458535953559,
			["panV"] = 0.3331249017786701,
		},
	}, -- [616]
	{
		["rotation"] = 0.3300003785000898,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -0.6662541263086219,
			["panV"] = 0.3331249017786714,
		},
	}, -- [617]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.02562238770977538,
			["panV"] = -0.1281252670319519,
		},
	}, -- [618]
	{
		["rotation"] = 0,
		["zoom"] = -0.1166674838415919,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 2.881834176994558e-006,
			["panV"] = 0.07687400748549655,
		},
	}, -- [619]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = -0.4099999899519792,
			["panV"] = 1.639999959807945,
		},
	}, -- [620]
	{
		["rotation"] = -0.027498742916632,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 1.734723475976807e-017,
			["panV"] = 2.383125211767876,
		},
	}, -- [621]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 2.881834181546472e-006,
			["panV"] = 1.306875058029274,
		},
	}, -- [622]
	{
		["rotation"] = 0.7149982428334435,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.1537516172637189,
			["panV"] = 0.02562454908540816,
		},
	}, -- [623]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.3331227404030319,
			["panV"] = -1.460624513917361,
		},
	}, -- [624]
	{
		["rotation"] = 0.1374983536333158,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.1537487354295374,
			["panV"] = 0.2818750831493085,
		},
	}, -- [625]
	{
		["rotation"] = 0.2200023141334596,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 1.734723475976807e-017,
			["panV"] = -0.07687508817331637,
		},
	}, -- [626]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0,
			["panV"] = 0,
		},
	}, -- [627]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.07687580863186175,
			["panV"] = 0.05124945840008903,
		},
	}, -- [628]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.02562238770977538,
			["panV"] = -0.05125017885863666,
		},
	}, -- [629]
	{
		["rotation"] = 0.2749997999667236,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 2.42861286636753e-017,
			["panV"] = -0.8968743476187439,
		},
	}, -- [630]
	{
		["rotation"] = -0.6050001784668035,
		["zoom"] = -2.829166904844084,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 2.17812917931388,
			["panV"] = 0.5637505265278885,
		},
	}, -- [631]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.128123465885585,
			["panV"] = -0.589375435842572,
		},
	}, -- [632]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.2,
		["position"] = {
			["panH"] = -0.3331256222372224,
			["panV"] = 1.768125226839897,
		},
	}, -- [633]
	{
		["rotation"] = 0.385000957033451,
		["zoom"] = 0,
		["scale"] = 0.1499999999999997,
		["position"] = {
			["panH"] = 0.538123455837568,
			["panV"] = 3.895000264773147,
		},
	}, -- [634]
	{
		["rotation"] = 0.275002892666821,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = 0.4099985490348981,
			["panV"] = 1.409375055517273,
		},
	}, -- [635]
	{
		["rotation"] = 0.3575006677667704,
		["zoom"] = 0,
		["scale"] = 0.5999999999999996,
		["position"] = {
			["panH"] = -0.1025010781758233,
			["panV"] = 1.435000325061225,
		},
	}, -- [636]
	{
		["rotation"] = 0.3300034712001876,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.2049963926832653,
			["panV"] = 0.9737497960213322,
		},
	}, -- [637]
	{
		["rotation"] = 0.494999021400086,
		["zoom"] = 0,
		["scale"] = 0.4499999999999996,
		["position"] = {
			["panH"] = -9.083012120214562e-015,
			["panV"] = 2.075624859074612,
		},
	}, -- [638]
	{
		["rotation"] = 0.3575022637616027,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -0.1793717782058965,
			["panV"] = 2.255000904347845,
		},
	}, -- [639]
	{
		["rotation"] = 0.1650001892500496,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.05125053908790925,
			["panV"] = -0.1281241863441315,
		},
	}, -- [640]
	{
		["rotation"] = 0.3850040497335484,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.2562526954395377,
			["panV"] = 2.30625048382383,
		},
	}, -- [641]
	{
		["rotation"] = 0.247499510700043,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = 0.05125053908790934,
			["panV"] = -1.110223024625157e-015,
		},
	}, -- [642]
	{
		["rotation"] = 0.467501824833498,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.05123901175117414,
			["panV"] = -0.02562599000250002,
		},
	}, -- [643]
	{
		["rotation"] = 0.1099949716665328,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.1024953145074511,
			["panV"] = -0.666250524015889,
		},
	}, -- [644]
	{
		["rotation"] = 0.3024969965333069,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.2049992745174514,
			["panV"] = 0.1281245465734031,
		},
	}, -- [645]
	{
		["rotation"] = 0.4124981536000343,
		["zoom"] = 0,
		["scale"] = 1.650000000000001,
		["position"] = {
			["panH"] = -0.02562526954395696,
			["panV"] = -0.2562498136053549,
		},
	}, -- [646]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0.5250006021592286,
		["scale"] = 0.1999999999999997,
		["position"] = {
			["panH"] = -0.1793653594709497,
			["panV"] = 2.28062665519697,
		},
	}, -- [647]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = 0.02562238770976629,
			["panV"] = 0.02562526954395241,
		},
	}, -- [648]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = 0.2050021563516238,
			["panV"] = 1.665625589581171,
		},
	}, -- [649]
	{
		["rotation"] = 0.1924989321666815,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = -2.081668171172169e-017,
			["panV"] = -0.3331249017786725,
		},
	}, -- [650]
	{
		["rotation"] = 0.4125012463001316,
		["zoom"] = 0,
		["scale"] = 1.3,
		["position"] = {
			["panH"] = -0.2306274258955853,
			["panV"] = 0.4868750781253021,
		},
	}, -- [651]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.3999999999999996,
		["position"] = {
			["panH"] = -0.05124765725372324,
			["panV"] = 2.562499216741369,
		},
	}, -- [652]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.0512534209220909,
			["panV"] = -0.07687508817331522,
		},
	}, -- [653]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.1024981963416372,
			["panV"] = -0.10250035771727,
		},
	}, -- [654]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.1537516172637234,
			["panV"] = 5.227499511658556,
		},
	}, -- [655]
	{
		["rotation"] = 0.1924989321666769,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = 0.1025010781758051,
			["panV"] = 0.1793754458905835,
		},
	}, -- [656]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.1024981963416326,
			["panV"] = 0.02562526954395241,
		},
	}, -- [657]
	{
		["rotation"] = -0.4124981536000343,
		["zoom"] = 0,
		["scale"] = 0.6499999999999997,
		["position"] = {
			["panH"] = -0.1793740049734943,
			["panV"] = 1.640001400725036,
		},
	}, -- [658]
	{
		["rotation"] = 0.3849978643333538,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = -0.02562815137813846,
			["panV"] = -0.1537494558880863,
		},
	}, -- [659]
	{
		["rotation"] = 0,
		["zoom"] = -3.062499822441977,
		["scale"] = 0.7499999999999998,
		["position"] = {
			["panH"] = -0.0256310332123155,
			["panV"] = 0.6406259749304776,
		},
	}, -- [660]
	{
		["rotation"] = 0.1924989321666768,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -0.02562238770977538,
			["panV"] = -0.1281252670319519,
		},
	}, -- [661]
	{
		["rotation"] = 0.6600007570001745,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 3.469446951953614e-018,
			["panV"] = -0.1024996372587256,
		},
	}, -- [662]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1.700000000000001,
		["position"] = {
			["panH"] = -0.05125053908790934,
			["panV"] = -0.3075003526932632,
		},
	}, -- [663]
	{
		["rotation"] = 0.2474964179999458,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.2562498136053563,
			["panV"] = 0.7943747103600184,
		},
	}, -- [664]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = -3.469446951953614e-018,
			["panV"] = -0.07687436771477035,
		},
	}, -- [665]
	{
		["rotation"] = 0.02749719656658824,
		["zoom"] = 0,
		["scale"] = 0.8999999999999999,
		["position"] = {
			["panH"] = -2.081668171172169e-017,
			["panV"] = -0.1281252670319508,
		},
	}, -- [666]
	{
		["rotation"] = -0.3300034712001823,
		["zoom"] = 0,
		["scale"] = 1.15,
		["position"] = {
			["panH"] = 0.1793740049734852,
			["panV"] = 0.076874007485496,
		},
	}, -- [667]
	{
		["rotation"] = 0.3025000892334093,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 0.3843747204080274,
			["panV"] = 1.28125086917314,
		},
	}, -- [668]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.5499999999999996,
		["position"] = {
			["panH"] = -0.7431270531062885,
			["panV"] = -1.614375410722539,
		},
	}, -- [669]
	{
		["rotation"] = 0.5224993106667667,
		["zoom"] = 0,
		["scale"] = 0.8499999999999999,
		["position"] = {
			["panH"] = 0.07687580863185731,
			["panV"] = -0.1024996372587251,
		},
	}, -- [670]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = 0.05125053908790024,
			["panV"] = 1.20437542077055,
		},
	}, -- [671]
	{
		["rotation"] = -0.05500057853336596,
		["zoom"] = 0,
		["scale"] = 0.7999999999999998,
		["position"] = {
			["panH"] = 0.1024953145074419,
			["panV"] = -0.4100007104105321,
		},
	}, -- [672]
	{
		["rotation"] = 0.3575037604668678,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 6.938893903907228e-018,
			["panV"] = -0.15374981611736,
		},
	}, -- [673]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 0.6999999999999997,
		["position"] = {
			["panH"] = 0.3843732794909412,
			["panV"] = 1.025000335109238,
		},
	}, -- [674]
	{
		["rotation"] = 0.1650017356000886,
		["zoom"] = 0,
		["scale"] = 1.1,
		["position"] = {
			["panH"] = 0.1281205840514035,
			["panV"] = 0.2562498136053539,
		},
	}, -- [675]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1.05,
		["position"] = {
			["panH"] = -6.938893903907228e-018,
			["panV"] = -0.1793754458905851,
		},
	}, -- [676]
	{
		["rotation"] = 0.05500057853336616,
		["zoom"] = 0,
		["scale"] = 1,
		["position"] = {
			["panH"] = -0.02562526954395696,
			["panV"] = -0.2818747229200371,
		},
	}, -- [677]
	{
		["rotation"] = 0,
		["zoom"] = 0,
		["scale"] = 0.95,
		["position"] = {
			["panH"] = 2.881834181546472e-006,
			["panV"] = -0.1281245465734055,
		},
	}, -- [678]
}

end