-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

function Mazzifier:Setup_Bindings()
    if ((not Mazzifier_LastInstalledVersion) or (Mazzifier_LastInstalledVersion == Mazzifier_Version) or (Mazzifier_LastInstalledVersion < 0.90)) then
        Mazzifier:Bind_BaseBindings()
    elseif ((Mazzifier_LastInstalledVersion or 0) < 0.96) then
        Mazzifier:InstallBinding("TARGETFOCUS", "ALT-F")
    end
    
    local loadable
    for addonIndexName, addonInfo in pairs(Mazzifier_AddOnInfo) do
        if (not addonInfo.noRequirement) then
            _, _, _, _, loadable, _, _= GetAddOnInfo(addonIndexName)
            if (Mazzifier["Bind_"..string.gsub(addonIndexName, "!", "")] and loadable) then
                Mazzifier:Print("Adding bindings for add-on: ", addonInfo.name)
                Mazzifier["Bind_"..string.gsub(addonIndexName, "!", "")]()
            end
        end
    end

    for _, addonName in pairs({"TinyPad"}) do
        _, _, _, _, loadable, _, _= GetAddOnInfo(addonName)
        if (Mazzifier["Bind_"..string.gsub(addonName, "!", "")] and loadable) then
            Mazzifier:Print("Adding bindings for add-on: ", addonName)
            Mazzifier["Bind_"..string.gsub(addonName, "!", "")]()
        end
    end

	SaveBindings(2)
    if (myBindings2) then myBindings2CharacterButton:SetChecked(true); myBindings2:SaveBindings(); end
    
end

function Mazzifier:InstallClickBinding(frameName, bind)
    local theBinding = 'CLICK ' .. frameName .. ':LeftButton'
	while GetBindingKey(theBinding) do
		SetBinding(GetBindingKey(theBinding), nil)
	end
	if bind then
		SetBindingClick(bind, frameName)
	end
end

function Mazzifier:InstallBinding(theCommand, bind1, bind2)
    local oldbind1, oldbind2 = GetBindingKey(theCommand)
    if (oldbind1) then SetBinding(oldbind1); end;
    if (oldbind2) then SetBinding(oldbind2); end;
    if (bind1) then SetBinding(bind1, theCommand); end;
    if (bind2) then SetBinding(bind2, theCommand); end;
end

function Mazzifier:AddBindings_Mage()
    Mazzifier:Print("Adding extra mage key bindings.")
    SetBindingSpell("F1", "Shoot")
	SaveBindings(2)
end

function Mazzifier:AddBindings_Priest()
    Mazzifier:Print("Adding extra priest key bindings.")
    SetBindingSpell("ALT-`", "Shoot")
	SaveBindings(2)
end

function Mazzifier:AddBindings_Hunter()
    Mazzifier:Print("Adding extra hunter key bindings.")
    Mazzifier:InstallBinding("ASSISTTARGET", "CTRL-F")
    Mazzifier:InstallBinding("PREVIOUSACTIONPAGE", "SHIFT-MOUSEWHEELUP", "F")
	SaveBindings(2)
end

function Mazzifier:AddBindings_Warlock()
    Mazzifier:Print("Adding extra warlock key bindings.")
    SetBindingSpell("F1", "Shoot")
	SaveBindings(2)
end

function Mazzifier:AddBindings_Druid()
    Mazzifier:Print("Adding extra druid key bindings.")
    Mazzifier:UnbindPaging()
    Mazzifier:InstallClickBinding("BClassBarButton1", "SHIFT-1")
    Mazzifier:InstallClickBinding("BClassBarButton2", "SHIFT-2")
    Mazzifier:InstallClickBinding("BClassBarButton3", "SHIFT-3")
    Mazzifier:InstallClickBinding("BClassBarButton4", "SHIFT-4")
    Mazzifier:InstallClickBinding("BClassBarButton5", "SHIFT-5")
	SaveBindings(2)
end

function Mazzifier:AddBindings_Rogue()
    Mazzifier:Print("Adding extra rogue key bindings.")
    Mazzifier:UnbindPaging()
    Mazzifier:InstallClickBinding("BClassBarButton1", "`")
	SaveBindings(2)
end

function Mazzifier:AddBindings_Warrior()
    Mazzifier:Print("Adding extra warrior key bindings.")
    Mazzifier:UnbindPaging()
    Mazzifier:InstallClickBinding("BClassBarButton1", "Z")
    Mazzifier:InstallClickBinding("BClassBarButton2", "X")
    Mazzifier:InstallClickBinding("BClassBarButton3", "C")
    SetBindingSpell("F1", "Shoot")
	SaveBindings(2)
end

function Mazzifier:UnbindPaging()
    Mazzifier:InstallBinding("ACTIONPAGE1", nil)
    Mazzifier:InstallBinding("ACTIONPAGE2",  nil)
    Mazzifier:InstallBinding("ACTIONPAGE3",  nil)
    Mazzifier:InstallBinding("ACTIONPAGE4",  nil)
    Mazzifier:InstallBinding("ACTIONPAGE5",  nil)
    Mazzifier:InstallBinding("ACTIONPAGE6",  nil)
    Mazzifier:InstallBinding("PREVIOUSACTIONPAGE",  nil)
    Mazzifier:InstallBinding("NEXTACTIONPAGE",  nil)
end

function Mazzifier:Bind_BaseBindings()
    Mazzifier:Print("Setting up base key bindings.")
    Mazzifier:InstallBinding("ACTIONBUTTON1", "1")
    Mazzifier:InstallBinding("ACTIONBUTTON10", "0")
    Mazzifier:InstallBinding("ACTIONBUTTON11", "-")
    Mazzifier:InstallBinding("ACTIONBUTTON12", "=")
    Mazzifier:InstallBinding("ACTIONBUTTON2", "2")
    Mazzifier:InstallBinding("ACTIONBUTTON3", "3")
    Mazzifier:InstallBinding("ACTIONBUTTON4", "4")
    Mazzifier:InstallBinding("ACTIONBUTTON5", "5")
    Mazzifier:InstallBinding("ACTIONBUTTON6", "6")
    Mazzifier:InstallBinding("ACTIONBUTTON7", "7")
    Mazzifier:InstallBinding("ACTIONBUTTON8", "8")
    Mazzifier:InstallBinding("ACTIONBUTTON9", "9")
    Mazzifier:InstallBinding("ACTIONPAGE1", "SHIFT-1")
    Mazzifier:InstallBinding("ACTIONPAGE2", "SHIFT-2")
    Mazzifier:InstallBinding("ACTIONPAGE3", "SHIFT-3")
    Mazzifier:InstallBinding("ACTIONPAGE4", "SHIFT-4")
    Mazzifier:InstallBinding("ACTIONPAGE5", "SHIFT-5")
    Mazzifier:InstallBinding("ACTIONPAGE6", "SHIFT-6")
    Mazzifier:InstallBinding("ALLNAMEPLATES", "ALT-SHIFT-V", "CTRL-V")
    Mazzifier:InstallBinding("ASSISTTARGET", "F")
    Mazzifier:InstallBinding("ATTACKTARGET", "T")
    Mazzifier:InstallBinding("BONUSACTIONBUTTON1", "CTRL-1", "ALT-1")
    Mazzifier:InstallBinding("BONUSACTIONBUTTON10", "CTRL-0", "ALT-0")
    Mazzifier:InstallBinding("BONUSACTIONBUTTON2", "CTRL-2", "ALT-2")
    Mazzifier:InstallBinding("BONUSACTIONBUTTON3", "CTRL-3", "ALT-3")
    Mazzifier:InstallBinding("BONUSACTIONBUTTON4", "CTRL-4", "ALT-4")
    Mazzifier:InstallBinding("BONUSACTIONBUTTON5", "CTRL-5", "ALT-5")
    Mazzifier:InstallBinding("BONUSACTIONBUTTON6", "CTRL-6", "ALT-6")
    Mazzifier:InstallBinding("BONUSACTIONBUTTON7", "CTRL-7", "ALT-7")
    Mazzifier:InstallBinding("BONUSACTIONBUTTON8", "CTRL-8", "ALT-8")
    Mazzifier:InstallBinding("BONUSACTIONBUTTON9", "CTRL-9", "ALT-9")
    Mazzifier:InstallBinding("CAMERAZOOMIN", "MOUSEWHEELUP")
    Mazzifier:InstallBinding("CAMERAZOOMOUT", "MOUSEWHEELDOWN")
    Mazzifier:InstallBinding("CHATBOTTOM", "SHIFT-PAGEDOWN")
    Mazzifier:InstallBinding("CHATPAGEDOWN", "PAGEDOWN")
    Mazzifier:InstallBinding("CHATPAGEUP", "PAGEUP")
    Mazzifier:InstallBinding("COMBATLOGBOTTOM", "CTRL-SHIFT-PAGEDOWN")
    Mazzifier:InstallBinding("COMBATLOGPAGEDOWN", "CTRL-PAGEDOWN")
    Mazzifier:InstallBinding("COMBATLOGPAGEUP", "CTRL-PAGEUP")
    Mazzifier:InstallBinding("FOCUSTARGET", "SHIFT-F")
    Mazzifier:InstallBinding("FOLLOWTARGET", "'")
    Mazzifier:InstallBinding("FRIENDNAMEPLATES", "SHIFT-V")
    Mazzifier:InstallBinding("JUMP", "NUMPAD0", "SPACE")
    Mazzifier:InstallBinding("MASTERVOLUMEDOWN", "CTRL--")
    Mazzifier:InstallBinding("MASTERVOLUMEUP", "CTRL-=")
    Mazzifier:InstallBinding("MINIMAPZOOMIN", "NUMPADPLUS")
    Mazzifier:InstallBinding("MINIMAPZOOMOUT", "NUMPADMINUS")
    Mazzifier:InstallBinding("MOVEANDSTEER", "BUTTON3")
    Mazzifier:InstallBinding("MOVEBACKWARD", "DOWN", "S")
    Mazzifier:InstallBinding("MOVEFORWARD", "UP", "W")
    Mazzifier:InstallBinding("NAMEPLATES", "ALT-V", "V")
    Mazzifier:InstallBinding("NEXTACTIONPAGE", "SHIFT-MOUSEWHEELDOWN", "SHIFT-DOWN")
    Mazzifier:InstallBinding("NEXTVIEW", "END")
    Mazzifier:InstallBinding("OPENALLBAGS", "B", "ALT-B")
    Mazzifier:InstallBinding("OPENCHAT", "ENTER")
    Mazzifier:InstallBinding("OPENCHATSLASH", "/")
    Mazzifier:InstallBinding("PETATTACK", "`", "SHIFT-T")
    Mazzifier:InstallBinding("PITCHDOWN", "DELETE")
    Mazzifier:InstallBinding("PITCHUP", "INSERT")
    Mazzifier:InstallBinding("PREVIOUSACTIONPAGE", "SHIFT-MOUSEWHEELUP", "SHIFT-UP")
    Mazzifier:InstallBinding("PREVVIEW", "HOME")
    Mazzifier:InstallBinding("REPLY", "ALT-R", "R")
    Mazzifier:InstallBinding("REPLY2", "SHIFT-R")
    Mazzifier:InstallBinding("SCREENSHOT", "PRINTSCREEN")
    Mazzifier:InstallBinding("SHAPESHIFTBUTTON1", "CTRL-F1")
    Mazzifier:InstallBinding("SHAPESHIFTBUTTON10", "CTRL-F10")
    Mazzifier:InstallBinding("SHAPESHIFTBUTTON2", "CTRL-F2")
    Mazzifier:InstallBinding("SHAPESHIFTBUTTON3", "CTRL-F3")
    Mazzifier:InstallBinding("SHAPESHIFTBUTTON4", "CTRL-F4")
    Mazzifier:InstallBinding("SHAPESHIFTBUTTON5", "CTRL-F5")
    Mazzifier:InstallBinding("SHAPESHIFTBUTTON6", "CTRL-F6")
    Mazzifier:InstallBinding("SHAPESHIFTBUTTON7", "CTRL-F7")
    Mazzifier:InstallBinding("SHAPESHIFTBUTTON8", "CTRL-F8")
    Mazzifier:InstallBinding("SHAPESHIFTBUTTON9", "CTRL-F9")
    Mazzifier:InstallBinding("SITORSTAND", "X", "CTRL-X")
    Mazzifier:InstallBinding("STRAFELEFT", "Q")
    Mazzifier:InstallBinding("STRAFERIGHT", "E")
    Mazzifier:InstallBinding("TARGETFOCUS", "ALT-F")
    Mazzifier:InstallBinding("TARGETLASTHOSTILE", "G", "CTRL-G")
    Mazzifier:InstallBinding("TARGETNEARESTENEMY", "TAB")
    Mazzifier:InstallBinding("TARGETNEARESTFRIEND", "CTRL-TAB")
    Mazzifier:InstallBinding("TARGETPARTYMEMBER1", "F2")
    Mazzifier:InstallBinding("TARGETPARTYMEMBER2", "F3")
    Mazzifier:InstallBinding("TARGETPARTYMEMBER3", "F4")
    Mazzifier:InstallBinding("TARGETPARTYMEMBER4", "F5")
    Mazzifier:InstallBinding("TARGETPARTYPET1", "SHIFT-F2")
    Mazzifier:InstallBinding("TARGETPARTYPET2", "SHIFT-F3")
    Mazzifier:InstallBinding("TARGETPARTYPET3", "SHIFT-F4")
    Mazzifier:InstallBinding("TARGETPARTYPET4", "SHIFT-F5")
    Mazzifier:InstallBinding("TARGETPET", "SHIFT-F1")
    Mazzifier:InstallBinding("TARGETPREVIOUSENEMY", "SHIFT-TAB")
    Mazzifier:InstallBinding("TARGETPREVIOUSFRIEND", "CTRL-SHIFT-TAB")
    Mazzifier:InstallBinding("TARGETSELF", "F1")
    Mazzifier:InstallBinding("TOGGLEAUTORUN", "SHIFT-\\", "NUMLOCK")
    Mazzifier:InstallBinding("TOGGLEBACKPACK", "F12")
    Mazzifier:InstallBinding("TOGGLEBAG1", "F8")
    Mazzifier:InstallBinding("TOGGLEBAG2", "F9")
    Mazzifier:InstallBinding("TOGGLEBAG3", "F10")
    Mazzifier:InstallBinding("TOGGLEBAG4", "F11")
    Mazzifier:InstallBinding("TOGGLEBATTLEFIELDMINIMAP", "SHIFT-M")
    Mazzifier:InstallBinding("TOGGLECHARACTER0", "C","CTRL-C")
    Mazzifier:InstallBinding("TOGGLECHARACTER1", "K")
    Mazzifier:InstallBinding("TOGGLECHARACTER2", "U")
    Mazzifier:InstallBinding("TOGGLECHARACTER3", "SHIFT-P")
    Mazzifier:InstallBinding("TOGGLECHARACTER4", "H")
    Mazzifier:InstallBinding("TOGGLECOMBATLOG", "SHIFT-C")
    Mazzifier:InstallBinding("TOGGLEFPS", "CTRL-R")
    Mazzifier:InstallBinding("TOGGLEFRIENDSTAB", "SHIFT-O")
    Mazzifier:InstallBinding("TOGGLEGAMEMENU", "ESCAPE")
    Mazzifier:InstallBinding("TOGGLEGUILDTAB", "CTRL-O")
    Mazzifier:InstallBinding("TOGGLELFGPARENT", "I")
    Mazzifier:InstallBinding("TOGGLELFGTAB", "CTRL-L")
    Mazzifier:InstallBinding("TOGGLEMUSIC", "CTRL-M")
    Mazzifier:InstallBinding("TOGGLEPETBOOK", "SHIFT-I")
    Mazzifier:InstallBinding("TOGGLEQUESTLOG", "L")
    Mazzifier:InstallBinding("TOGGLERAIDTAB", "ALT-O")
    Mazzifier:InstallBinding("TOGGLERUN", "NUMPADDIVIDE")
    Mazzifier:InstallBinding("TOGGLESHEATH", "Z", "CTRL-Z")
    Mazzifier:InstallBinding("TOGGLESOCIAL", "O")
    Mazzifier:InstallBinding("TOGGLESOUND", "CTRL-S")
    Mazzifier:InstallBinding("TOGGLESPELLBOOK", "P")
    Mazzifier:InstallBinding("TOGGLETALENTS", "N")
    Mazzifier:InstallBinding("TOGGLEUI", "ALT-Z")
    Mazzifier:InstallBinding("TOGGLEWORLDMAP", "M")
    Mazzifier:InstallBinding("TOGGLEWORLDSTATESCORES", "SHIFT-SPACE")
    Mazzifier:InstallBinding("TURNLEFT", "LEFT", "A")
    Mazzifier:InstallBinding("TURNRIGHT", "RIGHT", "D")

    Mazzifier:Bind_MazzleUI_Core()
end

function Mazzifier:Bind_CharacterInfo()
    Mazzifier:InstallBinding("TOGGLE_CHARACTERINFO", "ALT-C")
end

function Mazzifier:Bind_oRA2()
    Mazzifier:InstallBinding("Set MT1", "ALT-CTRL-SHIFT-1")
    Mazzifier:InstallBinding("Set MT2", "ALT-CTRL-SHIFT-2")
    Mazzifier:InstallBinding("Set MT3", "ALT-CTRL-SHIFT-3")
    Mazzifier:InstallBinding("Set MT4", "ALT-CTRL-SHIFT-4")
    Mazzifier:InstallBinding("Set MT5", "ALT-CTRL-SHIFT-5")
    Mazzifier:InstallBinding("Set MT6", "ALT-CTRL-SHIFT-6")
    Mazzifier:InstallBinding("Set MT7", "ALT-CTRL-SHIFT-7")
    Mazzifier:InstallBinding("Set MT8", "ALT-CTRL-SHIFT-8")
    Mazzifier:InstallBinding("Set MT9", "ALT-CTRL-SHIFT-9")
    Mazzifier:InstallBinding("Set MT10", "ALT-CTRL-SHIFT-0")
end

function Mazzifier:Bind_sRaidFrames()
    Mazzifier:InstallBinding("ToggleBuffDebuffview", "CTRL-B")
    Mazzifier:InstallBinding("Toggledisplayofonlydispellabledebuffs", "SHIFT-B")
end

function Mazzifier:Bind_Baggins()
    Mazzifier:InstallBinding("BAGGINS_TOGGLEALL", "B")
end

function Mazzifier:Bind_GoGoMount()
    Mazzifier:InstallBinding("GOGOBINDING", "SHIFT-`")
end

function Mazzifier:Bind_MazzleUI_Core()
        Mazzifier:InstallBinding("MAZZLEUICONTEXT", "SHIFT-BUTTON4", "SHIFT-BUTTON3")
        Mazzifier:InstallBinding("MAZZLEUIDEBUG", "CTRL-.")
        Mazzifier:InstallBinding("MAZZLEUINEXTVIEW", "CTRL-[")
        Mazzifier:InstallBinding("MAZZLEUIPREVVIEW", "CTRL-]")
        Mazzifier:InstallBinding("MAZZLEUIVIEW1", "CTRL-F1")
        Mazzifier:InstallBinding("MAZZLEUIVIEW2", "CTRL-F2")
        Mazzifier:InstallBinding("MAZZLEUIVIEW3", "CTRL-F3")
        Mazzifier:InstallBinding("MAZZLEUIMT1", "CTRL-F4")
        Mazzifier:InstallBinding("MAZZLEUIMT2", "CTRL-F5")
        Mazzifier:InstallBinding("MAZZLEUIMT3", "CTRL-F6")
        Mazzifier:InstallBinding("MAZZLEUIPARTYSHOW", "CTRL-F7")
        Mazzifier:InstallBinding("MAZZLEUIPARTYHIDE", "CTRL-SHIFT-F7")
        if (MazzleUI.SetupDevBindings) then MazzleUI:SetupDevBindings(); end;
end

function Mazzifier:Bind_nQuestLog()
    Mazzifier:InstallBinding("MAZZLEUIQUEST", "L")
end

function Mazzifier:Bind_SmartBuff()
    Mazzifier:InstallBinding("SMARTBUFF_BIND_TRIGGER", "CTRL-D")
end

function Mazzifier:Bind_Prat()
    Mazzifier:InstallBinding("TellTarget", "ALT-T")
end

function Mazzifier:Bind_Examiner()
    Mazzifier:InstallBinding("EXAMINER_TARGET", "I")
end

function Mazzifier:Bind_TinyPad()
    Mazzifier:InstallBinding("TinyPad Toggle", "J")
end

function Mazzifier:Bind_ItemRack()
    Mazzifier:InstallBinding("Toggle ItemRack", "SHIFT-I")
end
