Mazzifier_VERSION_MESSAGE			= Mazzifier_Version or "Beta";
Mazzifier_LOADED_MESSAGE			= "|CFFFF0000Mazzifier v|CFFFFFFFF"..Mazzifier_VERSION_MESSAGE.."|CFFFF0000 loaded.";
Mazzifier_INSTALLED_MESSAGE			= "Woah!  I just had an intense Mazzlegasm!!!";
