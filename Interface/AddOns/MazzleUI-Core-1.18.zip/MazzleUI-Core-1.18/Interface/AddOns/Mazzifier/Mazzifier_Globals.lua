-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

Mazzifier_FrameCheckButtons = { };

Mazzifier_FrameCheckButtons["MAZZASPECT1"] = { index = 1, labelText = "1.25 (1280x1024, etc.)", tooltipText = "Divide your screen width by your screen height to get this value.  You can set and find this information in the video options."};
Mazzifier_FrameCheckButtons["MAZZASPECT2"] = { index = 2, labelText = "1.33 (1600x1200, 1024x768, 800x600, etc.)", tooltipText = "Divide your screen width by your screen height to get this value.  You can set and find this information in the video options."};
Mazzifier_FrameCheckButtons["MAZZASPECT3"] = { index = 3, labelText = "1.6 (1920x1200, 1680x1050, 1440x900, 1280x800, etc.)", tooltipText = "Divide your screen width by your screen height to get this value.  You can set and find this information in the video options."};

Mazzifier_FrameCheckButtons["MAZZPART1"] = { index = 4, labelText = "Add-Ons Settings", tooltipText = "Configure the settings of other add-ons.  You can customize in the next tab."};
Mazzifier_FrameCheckButtons["MAZZPART2"] = { index = 5, labelText = "Look'n'Feel: Window positions and UI skin", tooltipText = "Configure the positioning various UI elements and which set of artwork you want."};
Mazzifier_FrameCheckButtons["MAZZPART3"] = { index = 6, labelText = "Button Layout", tooltipText = "Configures your bars and the contents of your buttons.  You can override the default layout for you class in the Buttons tab."};

Mazzifier_FrameCheckButtons["MAZZCHATSIZE1"] = { index = 8, labelText = "Normal (may be too small for some people)", tooltipText = "Sets font size to 13pt for main chat windows, 12pt for Trade/Group windows and 10pt for combat windows."};
Mazzifier_FrameCheckButtons["MAZZCHATSIZE2"] = { index = 9, labelText = "Large", tooltipText = "Sets font size to 15pt for main chat windows, 14pt for Trade/Group windows and 13pt for combat windows. Scales other fonts to 115%."};
Mazzifier_FrameCheckButtons["MAZZCHATSIZE3"] = { index = 10, labelText = "Mr. Magoo", tooltipText = "Sets font size to 18pt for main chat windows, 16pt for Trade/Group windows and 15pt for combat windows. Scales other fonts to 130%."};
Mazzifier_FrameCheckButtons["MAZZMODE1"] = { index = 13, labelText = "Complete configuration.  I want a Mazzlegasm!", tooltipText = "Mazzifier will configure everything for a fresh install."};
Mazzifier_FrameCheckButtons["MAZZMODE2"] = { index = 14, labelText = "Upgrade mode", tooltipText = "Mazzifier will configure only those things that have changed since your last MazzleUI install or update."};
Mazzifier_FrameCheckButtons["MAZZMODE3"] = { index = 15, labelText = "Custom mode", tooltipText = "Mazzifier will configure based on options you set in this window."};
Mazzifier_FrameCheckButtons["MAZZSAS"] = { index = 74, labelText = "Also place spells and actions in the buttons?", tooltipText = ""};
Mazzifier_FrameCheckButtons["MAZZPART0"] = { index = 75, labelText = "Add-On Selection (i.e. which ones are enabled for this character)", tooltipText = "Configure which add-ons are enabled for this character, based on class, level and some questions in the following tabs of this window."};
Mazzifier_FrameCheckButtons["MAZZPART5"] = { index = 76, labelText = "Base Key Bindings", tooltipText = "Configure key bindings for your UI.  Note that there are multiple levels of keybingings (base, button, add-on, class).  This does not alter button bindings specified by your buttons, add-ons or class."};

Mazzifier_AddOnInfo = {}
local lastIndex = 15
local function Add_AddOnInfo(newName, newEntry)
    lastIndex = lastIndex + 1
    Mazzifier_AddOnInfo[newName] = newEntry
    Mazzifier_AddOnInfo[newName].index = lastIndex
end

Add_AddOnInfo("AdvancedTradeSkillWindow",   {name="Advanced Trade Skill Window", lastUpdate=0.91, global = true})
Add_AddOnInfo("AHsearch",                   {name="AHsearch", lastUpdate=1.1, global = true})
Add_AddOnInfo("Aloft",                      {name="Aloft (nameplate enhancements)", lastUpdate=1.1, global = true})
Add_AddOnInfo("Antagonist",                 {name="Antagonist (enemy timers)", lastUpdate=1.1, global = true})
Add_AddOnInfo("AutoBar",                    {name="Autobar", lastUpdate=1.1, global = false})
Add_AddOnInfo("Baggins",                    {name="Baggins", lastUpdate=0.92, global = true})
Add_AddOnInfo("BigWigs",                    {name="BigWigs Boss Warnings", lastUpdate=1.1, global = true})
Add_AddOnInfo("Blizzard",                   {name="Blizzard UI Options", lastUpdate=0.91, global = true, noRequirement = true})
Add_AddOnInfo("BugSack",                    {name="Bug Sack", lastUpdate=1.1, global = true,})
Add_AddOnInfo("Capping",                    {name="Capping (battleground timers)", lastUpdate=0.92, global = true})
Add_AddOnInfo("Cartographer",               {name="Cartographer", lastUpdate=1.1, global = true})
Add_AddOnInfo("Chronometer",                {name="Chronometer (spell effect timers)", lastUpdate=1.1, global = true})
Add_AddOnInfo("Clique",                     {name="Clique", lastUpdate=1.1, global = false})
Add_AddOnInfo("cyCircled",                  {name="cyCircled", lastUpdate=1.1, global = true})
Add_AddOnInfo("DBM_API",                    {name="Deadly Boss Mods", lastUpdate=1.1, global = false})
Add_AddOnInfo("Decursive",                  {name="Decursive", lastUpdate=1.1, global = true})
Add_AddOnInfo("DiscordUnitFrames",          {name="Discord Unit Frames", lastUpdate=1.1, global = false, posSettings = true})
Add_AddOnInfo("Examiner",                   {name="Examiner", lastUpdate=1.1, global = false})
Add_AddOnInfo("FuBar_FarmerFu",             {name="FarmerFu", lastUpdate=1.1, global = true})
Add_AddOnInfo("FuBar",                      {name="Fubar", lastUpdate=1.1, global = true})
Add_AddOnInfo("FubarAddOns",                {name="Fubar Add-Ons", lastUpdate=1.1, global = true, noRequirement = true})
Add_AddOnInfo("GoGoMount",                  {name="GoGo Mount", lastUpdate=0.91, global = false, })
Add_AddOnInfo("HitsMode",                   {name="HitsMode", lastUpdate=1.1, global = false})
Add_AddOnInfo("Hourglass",                  {name="Hourglass (cooldown timers)", lastUpdate=1.1, global = true, })
Add_AddOnInfo("Incubator",                  {name="Incubator (mob respawn timer)", lastUpdate=1.1, global = true})
Add_AddOnInfo("ItemRack",                   {name="Gello's ItemRack", lastUpdate=0.95, global = false})
Add_AddOnInfo("ItemSync",                   {name="ItemSync (loot database)", lastUpdate=0.95, global = false})
Add_AddOnInfo("KLHThreatMeter",             {name="KLH ThreatMeter", lastUpdate=1.1, global = false})
Add_AddOnInfo("MazzleUI",                   {name="Mazzlefizz's 3D Characters", lastUpdate=1.1, global = true})
Add_AddOnInfo("Mendeleev",                  {name="Mendeleev", lastUpdate=1.1, global = true})
Add_AddOnInfo("MobHealth",                  {name="MobHealth 3", lastUpdate=0.91, global = true})
Add_AddOnInfo("MovableBags",                {name="Movable Bags", lastUpdate=0.92, global = false})
Add_AddOnInfo("nQuestLog",                  {name="nQuestLog", lastUpdate=1.1, global = true})
Add_AddOnInfo("Omen",                       {name="Omen", lastUpdate=1.1, global = false})
Add_AddOnInfo("OmniCC",                     {name="Omni Cooldown Count", lastUpdate=1.1, global = true})
Add_AddOnInfo("oRA2",                       {name="oRA2 Raid Add-Ons", lastUpdate=0.99, global = true})
Add_AddOnInfo("Prat",                       {name="Prat", lastUpdate=1.1 , global = true})
Add_AddOnInfo("Quartz",                     {name="Quartz (casting/buff bars)", lastUpdate=1.1 , global = true})
Add_AddOnInfo("Recap",                      {name="Recap", lastUpdate=1.1, global = false})
Add_AddOnInfo("Recount",                    {name="Recount", lastUpdate=1.1, global = false})
Add_AddOnInfo("Sanity2",                    {name="Sanity2", lastUpdate=1.1, global = true})
Add_AddOnInfo("sct",                        {name="Scrolling Combat Text", lastUpdate=0.93, global = false})
Add_AddOnInfo("ShardAce",                   {name="ShardAce", lastUpdate=1.1, global = true})
Add_AddOnInfo("SimpleDruidBar",             {name="Simple Druid Bar", lastUpdate=0.99, global = true})
Add_AddOnInfo("SmartBuff",                  {name="SmartBuff", lastUpdate=1.1, global = false})
Add_AddOnInfo("sRaidFrames",                {name="sRaid Raid Frames", lastUpdate=1.1, global = false})
Add_AddOnInfo("StatusWindow",               {name="Status Windows", lastUpdate=0.94, global = false})
Add_AddOnInfo("SW_Stats",                   {name="SWStats Damage Meter", lastUpdate=1.1, global = false})
Add_AddOnInfo("TinyTip",                    {name="Tiny Tip", lastUpdate=0.91, global = false})
Add_AddOnInfo("TrinketMenu",                {name="TrinketMenu", lastUpdate=1.1, global = false})
Add_AddOnInfo("WitchHunt",                  {name="WitchHunt Spell Alerts", lastUpdate=0.92, global = true})
Add_AddOnInfo("xcalc",                      {name="XCalc Calculator", lastUpdate=0.99, global = true})
Add_AddOnInfo("XLoot",                      {name="XLoot", lastUpdate=0.99, global = true})
Add_AddOnInfo("XRS",                        {name="XRaid Status Monitor", lastUpdate=0.91, global = true})


Mazzifier_RemovedAddOns = {"TargetButtons", "!ImprovedErrorFrame", "ChatManager", "EasyCopy", "DiscordArt", "DiscordArtOptions", "OpenBags", "TipBuddy", "Lootster", "ChatFrameExtender", "CT_MailMod", "AuctionFilterPlus", "MarsQuestOrganizer", "BigWigs_KLHTMTarget", "rMCP"}
Mazzifier_ConflictAddOns = {}

Mazzifier_CurrentPartVersions = {}
Mazzifier_CurrentPartVersions.Layout = 1.1
Mazzifier_CurrentPartVersions.Buttons = 1.1
Mazzifier_CurrentPartVersions.Addons = 1.1
Mazzifier_CurrentPartVersions.AddonSelection = 1.1
Mazzifier_CurrentPartVersions.Bindings = 1.1

Mazzifier_ButtonInfo = {}
Mazzifier_ButtonInfo[1] = {name="Basic Layout", devname= "Generic", image="Simple", profileName = "MazzleUI-Generic", classes = "All", lastUpdate=0.95, bindingFunc="AddBindings_Mage",
                           setupFunc125="Setup_DAB125", setupFunc133="Setup_DAB133", setupFunc16="Setup_DAB16",
                           description="|CFFFFFFFFFour bars.  Top right bar has pages, somewhat similar to the default blizzard bar.  This layout is nice for users who would prefer a simple setup or are accustomed to the Blizzard one.  It's also a good starting point for making your own layout.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  Use Shift-~ to get on your mount.  Use Shift-Mousebutton 4 or Shift-MiddleMouseButton to access the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs.\n\nThis layout does not drop spells into the buttons, so you must organize and do that yourself."}

Mazzifier_ButtonInfo[2] = {name="Big Button Basic Layout", devname= "GenericBig", image="BigButton", profileName = "MazzleUI-GenericBig", classes = "All", lastUpdate=0.95, 
                           setupFunc125="Setup_DAB_Big_125", setupFunc133="Setup_DAB_Big_133", setupFunc16="Setup_DAB_Big_16",
                           description="|CFFFFFFFFThis layout is the same as the simple layout except with fewer buttons that are far larger.  This is especially useful for users on smaller screens or at 1.25 aspect ratio.  This layout has four bars.  The top right bars has pages, somewhat similar to the default blizzard bar.  This layout is nice for users who would prefer a simple setup or are accustomed to the Blizzard one.  It's also a good starting point for making your own layout.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  Use Shift-~ to get on your mount.  Use Shift-Mousebutton 4 or Shift-MiddleMouseButton to access the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.\n\nThis layout does not drop spells into the buttons, so you must organize and do that yourself."}

Mazzifier_ButtonInfo[3] = {name="Mazzlefizz's Mage Setup", devname= "MageMazzle", image="Mage", profileName = "MazzleUI-Mage", classes = "Mage", lastUpdate=0.99, bindingFunc="AddBindings_Mage",
                           setupFunc125="Setup_DABMage125", setupFunc133="Setup_DABMage133", setupFunc16="Setup_DABMage16", cmFunc="ContextMenu_MageMazzle",
                           description="|CFFFFFFFFMazzlefizz's setup for a mage.  Works for any spec and handles all talented abilities. You can access all of your combat abilities with your left hand staying the WASD keys.  Click the fire/frost button to quickly switch to your secondary element for vulnerability based mobs (just makes the actions in two bars switch, making the bindings easier).  The single bottom left button is to apply a wizard oil to your weapon in one click.  Do not put other items in there. \n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  F1 can be used to fire your wand (no button wasted on it :D).  Shift-~ will mount up. Shift-Mousebutton 4 or Shift-MiddleMouseButton accesses the context menu.  You'll find all of your portals and conjuring spells in the first page of the context menu.  You can put skills and so forth in the second page."}

Mazzifier_ButtonInfo[4] = {name="Mazzlefizz's Priest Setup", devname= "PriestMazzle", image="Priest", profileName = "MazzleUI-Priest", classes = "Priest", lastUpdate=0.95, bindingFunc="AddBindings_Priest",
                           setupFunc125="Setup_DABPriest125", setupFunc133="Setup_DABPriest133", setupFunc16="Setup_DABPriest16",
                           description="|CFFFFFFFFHealing/Damage on the right, buffs/psychic abilities on the left.  Automatic smart-targeting on healing and buff spells. Healing bar and damage bar quickly swappable depending on context of situations via the Offensive/Defensive buttons.  Handles all talent builds including shadow.  Also incorporates all priest racials.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  Alt-~ can be used to fire your wand (no button wasted on it :D).  Shift-~ will mount up.  Use Shift-Mousebutton 4 or Shift-MiddleMouseButton to access the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs."}

Mazzifier_ButtonInfo[5] = {name="Mazzlefizz's Warlock Layout", devname= "WarlockMazzle", image="Warlock", profileName = "MazzleUI-Warlock", classes = "Warlock", lastUpdate=0.95, bindingFunc="AddBindings_Warlock",
                           setupFunc125="Setup_DABWarlock125", setupFunc133="Setup_DABWarlock16", setupFunc16="Setup_DABWarlock16", cmFunc="ContextMenu_WarlockMazzle",
                           description="|CFFFFFFFFBar on the right categorized by offensive, drain, AOE, offensive specials requiring shards and curses.  Bars on the left categorized by buffs, fearing, demon CC, and hp/mana conversion.  Pet bar on the left.  Layout handles all talent specs.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  Shift-~ will summon your mount.  Use F1 to shoot your wand.  Shift-Mousebutton 4 or Shift-MiddleMouseButton accesses the context menu, where you'll find all of your conjuring and summon spells.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs."}

Mazzifier_ButtonInfo[6] = {name="Mazzlefizz's Hunter Layout", devname= "HunterMazzle", image="Hunter", profileName = "MazzleUI-Hunter", classes = "Hunter", lastUpdate=0.99, bindingFunc="AddBindings_Hunter",
                           setupFunc125="Setup_DABHunter125", setupFunc133="Setup_DABHunter133", setupFunc16="Setup_DABHunter16", cmFunc="ContextMenu_HunterMazzle",
                           description="|CFFFFFFFFIn this layout, the main bar has two pages.  One is for your ranged skills and one is for your melee ones.  Since Blizzard prohibited range-based paging, you must manually switch pages.  Handles all talent specs and racials.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  F switches between melee and ranged pages.  Alt-F will now assist target.  Use Alt 1-0 for your pet bar abilities. Use Shift-~ to mount up. Use Shift-Mousebutton 4 or Shift-MiddleMouseButton to access the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs."}

Mazzifier_ButtonInfo[7] = {name="Mazzlefizz's Druid Layout", devname= "DruidMazzle", image="Druid", profileName = "MazzleUI-Druid", classes = "Druid", lastUpdate=1.1, bindingFunc="AddBindings_Druid",
                           setupFunc125="Setup_DABDruid125", setupFunc133="Setup_DABDruid16", setupFunc16="Setup_DABDruid16",
                           description="|CFFFFFFFFThree main bars on the right that change based on form: Healing (1-5), Offensive (Alt-1 - Alt-5), Specials (Z, X, C).  Extra bar with lower level heals on right also.  Left bars contain crowd control, cleansing and buffing spells.  Handles all specs.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  Shift 1-4 to shift forms.  Shift-~ to mount up. ~ to root.  Shift-Mousebutton 4 or Shift-MiddleMouseButton to access the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs."}

Mazzifier_ButtonInfo[8] = {name="Mazzlefizz's Rogue Layout", devname= "RogueMazzle", image="Rogue", profileName = "MazzleUI-Rogue", classes = "Rogue", lastUpdate=0.95, bindingFunc="AddBindings_Rogue",
                           setupFunc125="Setup_DABRogue125", setupFunc133="Setup_DABRogue133", setupFunc16="Setup_DABRogue16",
                           description="|CFFFFFFFFFive combat bars on the right.  One bar changes based on stealth (F1-F4).  Main bar for all combo point generating moves (1-6).  Second combat bar below that with all finishing moves (Alt-1 - Alt-5).  One bar for base skills on cooldown like Evasion, Blind, Sprint (X, V, T, Z).  Another bar for talent-based skills on cooldown (R, C, G).  Miscellaneous skills in the left bars.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF ~ to stealth. Shift-1 to shoot weapon.  Shift-~ to mount. Shift-Mousebutton 4 or Shift-MiddleMouseButton accesses the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs."}

Mazzifier_ButtonInfo[9] = {name="Mazzlefizz's Paladin Layout", devname= "PaladinMazzle", image="Paladin", profileName = "MazzleUI-Paladin", classes = "Paladin", lastUpdate=0.95, 
                           setupFunc125="Setup_DABPaladin125", setupFunc133="Setup_DABPaladin16", setupFunc16="Setup_DABPaladin16",
                           description="|CFFFFFFFFBars categorized by Healing, Cleansing, Offensive, Offensive Undead, Self Buffs, Seals and Auras.  Includes three-paged blessings box with index buttons.  Also has an offensive/defensive buttons to quickly switch hotkeys for main spells depending on your current role.  Handles all talent specs.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF   Shift 1-7 for seals. Hit G to judge your seal.  Ctrl 1-6 for various blessings. 1-6 for healing/clean abilities, alt 1-6 for offensive abilities.  Hit offensive button to switch those bindings.  Use Shift-~ to mount up.  Use Shift-Mousebutton 4 or Shift-MiddleMouseButton to access the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs."}

Mazzifier_ButtonInfo[10] = {name="Mazzlefizz's Shaman Layout", devname= "ShamanMazzle", image="Shaman", profileName = "MazzleUI-Shaman", classes = "Shaman", lastUpdate=0.95, 
                           setupFunc125="Setup_DABShaman125", setupFunc133="Setup_DABShaman16", setupFunc16="Setup_DABShaman16", cmFunc="ContextMenu_Shaman",
                           description="|CFFFFFFFFOffensive and healing spells on the right.  Bars organized by attacks, shocks, heals, cleanses and buff.  Has an offensive/defensive buttons to quickly switch hotkeys for main spells depending on your current role.  Totems on the left organized by offensive, combat, heal/cleansing, and buffs.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  1-7 for attacks and shocks.  Alt 1-6 for heals and cleanses.  Use Shift-~ to mount up.  Shift-Mousebutton 4 or Shift-MiddleMouseButton accesses the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs."}

Mazzifier_ButtonInfo[11] = {name="Joypunk's Warrior Layout", devname= "WarriorJoyluck", image="Warrior", profileName = "MazzleUI-Warrior", classes = "Warrior", lastUpdate=0.95, bindingFunc="AddBindings_Warrior",
                           setupFunc125="Setup_DABWarriorJoyluck125", setupFunc133="Setup_DABWarriorJoyluck16", setupFunc16="Setup_DABWarriorJoyluck16",
                           description="|CFFFFFFFFThis layout was designed for quick and easy access to every ability that a Warrior has. Ideally, your left hand will never have to leave the WASD keys.\n- Overpower and Execute on one easy button. The Overpower ability will replace the Execute ability whenever your opponent Dodges an attack. The moment you use Overpower or 4 seconds after the opponent's Dodge, the button will return to the Execute ability.\n- Every bar in every stance arranged in use order.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  Stance changing is done with Z, X, C.  Shoot with F1. Use Shift-~ to mount up.  Use Shift-Mousebutton 4 or Shift-MiddleMouseButton to access the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there. It keeps your UI cleaner and reduces computational costs."}

Mazzifier_ButtonInfo[12] = {name="Simple Rogue Layout", devname= "RogueSimple", image="RogueSimple", profileName = "MazzleUI-SimpleRogue", classes = "Rogue", lastUpdate=0.95, bindingFunc="AddBindings_Rogue",
                           setupFunc125="Setup_DABRogueSimple125", setupFunc133="Setup_DABRogueSimple133", setupFunc16="Setup_DABRogueSimple16",
                           description="|CFFFFFFFFFour bar setup.  Main bar on top-right changes based on stealth (1-10).   Bottom left bar is a poison and sharpening stone bar.  Left-click items in that bar to apply to left weapon.  Right-click to apply to right.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF ~ to stealth. Shift-~ to mount. Shift-Mousebutton 4 or Shift-MiddleMouseButton to access the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs.\n\nThis layout does not drop spells into the buttons, so you must organize and do that yourself."}

Mazzifier_ButtonInfo[13] = {name="Simple Warrior Layout", devname= "WarriorSimple", image="WarriorSimple", profileName = "MazzleUI-SimpleWarrior", classes = "Warrior", lastUpdate=0.95, bindingFunc="AddBindings_Warrior",
                           setupFunc125="Setup_DABWarriorSimple125", setupFunc133="Setup_DABWarriorSimple133", setupFunc16="Setup_DABWarriorSimple16",
                           description="|CFFFFFFFFBasic four-bar setup.  Top right bar pages based on stance.  Racial buttons on the bottom left.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  Change stances with Z, X, C.  Main bar is 1-0, second bar is Alt-1 - Alt-0, third bar is F1-F12, and fourth bar is Shift-1 - Shift -0.  Racial skill is R. Shift-~ mounts.  Shift-Mousebutton 4 or Shift-MiddleMouseButton accesses the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs.\n\nThis layout does not drop spells into the buttons, so you must organize and do that yourself."}

Mazzifier_ButtonInfo[14] = {name="Simple Druid Layout", devname= "DruidSimple", image="DruidSimple", profileName = "MazzleUI-SimpleDruid", classes = "Druid", lastUpdate=0.95, bindingFunc="AddBindings_Druid",
                           setupFunc125="Setup_DABDruidSimple125", setupFunc133="Setup_DABDruidSimple133", setupFunc16="Setup_DABDruidSimple16",
                           description="|CFFFFFFFFSimple four bar setup. Top right bar pages based on form.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF  Shift 1-4 to shift forms.  Shift-~ mounts.  Shift-Mousebutton 4 or Shift-MiddleMouseButton accesses the context menu.  Put non-combat abilities, trade skills, miscellaneous items, etc. there.  It keeps your UI cleaner and reduces computational costs.\n\nThis layout does not drop spells into the buttons, so you must organize and do that yourself."}

Mazzifier_ButtonInfo[15] = {name="Durzil's Shaman Layout", devname= "ShamanDurzil", image="ShamanDurzil", profileName = "MazzleUI-Shaman", classes = "Shaman", lastUpdate=0.95, 
                           setupFunc125="Setup_DABShamanDurzil16", setupFunc133="Setup_DABShamanDurzil16", setupFunc16="Setup_DABShamanDurzil16", cmFunc="ContextMenu_Shaman",
                           description="|CFFFFFFFFAlternate version of Mazzlefizz's Shaman layout.  Layout organised by type of attack and then further organised by which element it uses or usefulness. Offensive and healing/cleansing spells on the right side of the layout along with pvp/damaging/misc totems spells along the bottem. The left side of the layout has your weapon buffs and totems.\n\n|CFF00FF00Key Binding Notes:|CFFFFFFFF 1-6 for attacks and shocks. Shift 1-6 for heals and cleanses. Ctrl-0 for common totems. Alt 1-6 for healing/cleansing totems. Hit ` for Ghostwolf, Z for Racial ability and F for Lighting Sheild. Use shift-~ to mount up. F1-F4 for weapon buffs. Shift-Mousebutton 4 or Shift-MiddleMouseButton to access the context menu. Put all non-combat abilities, trade skills, miscellanous items, ect there. It keeps your UI cleaner and reduces computational costs."}


Mazzifier_DefaultLayout = {}
Mazzifier_DefaultLayout["Mage"] = "MageMazzle"
Mazzifier_DefaultLayout["Priest"] = "PriestMazzle"
Mazzifier_DefaultLayout["Warlock"] = "WarlockMazzle"
Mazzifier_DefaultLayout["Rogue"] = "RogueMazzle"
Mazzifier_DefaultLayout["Druid"] = "DruidMazzle"
Mazzifier_DefaultLayout["Shaman"] = "ShamanMazzle"
Mazzifier_DefaultLayout["Hunter"] = "HunterMazzle"
Mazzifier_DefaultLayout["Paladin"] = "PaladinMazzle"
Mazzifier_DefaultLayout["Warrior"] = "WarriorJoyluck"

Mazzifier_SkinInfo = {}
Mazzifier_SkinInfo[1] = {name="Mazzlefizz's Arabian Elves Skin", devname= "default", image="default", lodName = "MazzleUI_Default_Skin", 
                           description="|CFF00FF00Skin Name|r: Mazzlefizz's Arabian Elves Skin\n\n|CFF00FF00Author|r:  Mazzlefizz of Argent Dawn\n\n|CFF00FF00Description|r: Dark arabian tile background to provide high contrast readability.  Border and hotspots are composed with elven metal textures.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border)."}
Mazzifier_SkinInfo[2] = {name="Noob123's Black Metal Skin", devname= "noobblack", image="blackmetal", lodName = "MazzleUI_Skin_Noob123_BlackMetal", 
                           description="|CFF00FF00Skin Name|r: Noob123's Black Metal Skin\n\n|CFF00FF00Author|r:  Noob123\n\n|CFF00FF00Description|r: A futuristic skin using a brushed black metal texture.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border).  "}
Mazzifier_SkinInfo[3] = {name="Noob123's Night Elf Skin", devname= "noobdruid", image="ne", lodName = "MazzleUI_Skin_Noob123_NE", 
                           description="|CFF00FF00Skin Name|r: Noob123's Night Elf Skin\n\n|CFF00FF00Author|r:  Noob123\n\n|CFF00FF00Description|r: Dark marbled background with leafy borders.  One of the most popular skins.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border)."}
Mazzifier_SkinInfo[4] = {name="Noob123's Everquest Skin", devname= "noobeq", image="eq", lodName = "MazzleUI_Skin_Noob123_EQ", 
                           description="|CFF00FF00Skin Name|r: Noob123's Everquest Skin\n|CFF00FF00Author|r:  Noob123\n\n|CFF00FF00Description|r: Sandy matte background with EQ art.  Golden border reminiscent of Everquest user interface.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border)."}
Mazzifier_SkinInfo[5] = {name="Noob123's Undead Skin", devname= "noobundead", image="undead", lodName = "MazzleUI_Skin_Noob123_Undead", 
                           description="|CFF00FF00Skin Name|r: Noob123's Undead Skin\n\n|CFF00FF00Author|r:  Noob123\n\n|CFF00FF00Description|r: Gray background with grisly textures imposed upon them.  Borders composed of bones.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border)."}
Mazzifier_SkinInfo[6] = {name="Minyaen's Dungeon Skin", devname= "dungeon", image="dungeon", lodName = "MazzleUI_Skin_Minyaen_Dungeon", 
                           description="|CFF00FF00Skin Name|r: Minyaen's Dungeon Skin\n\n|CFF00FF00Author|r:  Minyaen\n\n|CFF00FF00Description|r: Gray brick-like background with metal-hewn borders.  Target box and hotspots are a little larger than most other skins.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border).  "}
Mazzifier_SkinInfo[7] = {name="Kappatre's Slate Skin", devname= "slate", image="slate", lodName = "MazzleUI_Skin_Kappatre_Slate", 
                           description="|CFF00FF00Skin Name|r: Kappatre's Purple Slate Skin\n\n|CFF00FF00Author|r:  Kappatre\n\n|CFF00FF00Description|r: Purple skin with gradient texture.  Modeled to look similar to a Skinner look.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border).  "}
Mazzifier_SkinInfo[8] = {name="Dreadlorde's Discord Skin", devname= "discord", image="discord", lodName = "MazzleUI_Skin_Dreadlorde_Discord", 
                           description="|CFF00FF00Skin Name|r: Dreadlorde's Discord Skin\n\n|CFF00FF00Author|r:  Dreadlorde\n\n|CFF00FF00Description|r: Skin using textures from the Discord mods and web site.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border).  "}
Mazzifier_SkinInfo[9] = {name="Elcarath's Orc Skin", devname= "orc", image="ElcarathOrc", lodName = "MazzleUI_Skin_Elcarath_Orc", 
                           description="|CFF00FF00Skin Name|r: Elcarath's Orc Skin\n\n|CFF00FF00Author|r:  Elcarath\n\n|CFF00FF00Description|r: Orc skin based of a few images seen of another UI skin.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border).  "}                           
Mazzifier_SkinInfo[10] = {name="Elcarath's Draenei Skin", devname= "draenei", image="ElcarathDraenei", lodName = "MazzleUI_Skin_Elcarath_Draenei", 
                           description="|CFF00FF00Skin Name|r: Elcarath's Draenei Skin\n\n|CFF00FF00Author|r:  Elcarath\n\n|CFF00FF00Description|r: Based on the Draenei website on World of Warcraft. Very similar to the Blood Elf only in Blues.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border).  "}
Mazzifier_SkinInfo[11] = {name="Elcarath's Blood Elf Skin", devname= "bloodelf", image="ElcarathBloodElf", lodName = "MazzleUI_Skin_Elcarath_BloodElf", 
                           description="|CFF00FF00Skin Name|r: Kienara's Blood Elf Skin\n\n|CFF00FF00Author|r:  Elcarath\n\n|CFF00FF00Description|r: Based on the Blood Elf website on World of Warcraft. Red and gold theme using images from the website.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border).  "}
Mazzifier_SkinInfo[12] = {name="Geeskin's Diablo 2 Skin", devname= "Diablo", image="Geesdiablo", lodName = "MazzleUI_Skin_Diablo", 
                           description="|CFF00FF00Skin Name|r: Geeskins Diablo 2 Skin\n\n|CFF00FF00Author|r:  Geeskin\n\n|CFF00FF00Description|r: Diablo 2 based images.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border).  "}
Mazzifier_SkinInfo[13] = {name="Geeskin's Warhammer Skin", devname= "Warhammer", image="geeswarhammer", lodName ="MazzleUI_Skin_War",  
                           description="|CFF00FF00Skin Name|r: Geeskins Warhammer Skin\n\n|CFF00FF00Author|r:  Geeskin\n\n|CFF00FF00Description|r: Warhammer images.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border).  "}
Mazzifier_SkinInfo[14] = {name="Geeskin's LichKing Skin", devname= "LichKing", image="GeesLichKing", lodName = "MazzleUI_Skin_Lichking", 
                           description="|CFF00FF00Skin Name|r: Geeskins Lick King Skin\n\n|CFF00FF00Author|r:  Geeskin\n\n|CFF00FF00Description|r: Sking based on artwork for the Lich King.\n\n|CFF00FF00Provides|r: Bottom panel artwork and other basic artwork (castbar border, chatbox border, minimap border).  "}                           

Mazzifier_WelcomeText = "|CFFFFFFFFMazzlefizz of Argent Dawn here! \n\nPrepare to experience the latest in gnomish UI ingenuity.  Make absolutely sure you've read the instructions or this process may turn out a little more goblin-ish (think Boom!)\n\n|CFF00FF00(1) Make sure to change your resolution first in the video option.|CFFFFFFFF  Hit escape to access video options.\n|CFF00FF00(2) Answer every question in the Mazzifier honestly.|CFFFFFFFF  It has a built-in lie detector, so be careful.  You will be shocked if you answer dishonestly.\n|CFF00FF00(3) Hit the Mazzify button below|CFFFFFFFF In a few moments, a second button should appear.  Click that and wait until it reloads your UI.\n\nWhen you are done, you should repeat this process for every one of your characters.  Unmazzified characters tend to get jealous of mazzified ones and may pull pranks on their UI's.\n\nOnce all your characters are set up, I suggest reviewing your video settings and then getting to know your UI.  Read every FAQ entry in the MazzleOptions system and perhaps even browse the MazzleUI forums at |CFFFF8000http://Mazzlefizz.wowinterface.com|CFFFFFFFF.  Once you feel a little more comfortable with MazzleUI, start poking around and customizing it.  There's even a FAQ section to help you tweak things! When you're done, go to the MazzleUI forums and give Mazzlefizz some feedback.  Enjoy!\n\n|CFFFF0000Warning|CFFFFFFFF:  If for any reason you decide to go back to your old interface, you will lose your button layout when Mazzifying.  The only way to avoid this is to (a) unmark the 'Place Actions in Buttons' option in the Mazzifier or (b) use the included add-on |CFFFF8000SimpleActionSets|CFFFFFFFF to save your current buttons before Mazzifying.  There are insructions on how to do the latter option in the installation instructions.\n"

Mazzifier_MazzifyText = "|CFFFFFFFF\n\"a shiver ran through me and I stopped, intent upon the extraordinary thing that was happening to me. An exquisite pleasure had invaded my senses, something isolated, detached, with no suggestion of its origin. And at once the vicissitudes of life had become indifferent to me, its disasters innocuous, its brevity illusory - this new sensation having had the effect, which love has, of filling me with a precious essence; or rather this essence was not in me, it-was-me. I had ceased now to feel mediocre, contingent, mortal. When could it have come to me, this all-powerful joy?\"\n\n    - |CFFFF0000Proust|CFFFFFFFF, written immediately after installing MazzleUI\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n|CFF808080(He was actually talking about cookies, believe it or not.)|r"

Mazzifier_UpgradeText = "|CFFFFFFFFGreetings once again, brave MazzleUI user!  Mazzlefizz of Argent Dawn here with important news.  Things have changed!  Updates are needed!  Warlocks should be nerfed.  But don't worry.  My gnomish know-how will help you through this...well, maybe not the Warlock part.\n\n|CFFFF8000A couple things to remember:\n\n|CFF00FF00(1)|CFFFFFFFF Make sure you read and answer all of the questions I ask you in the following windows.  I don't run my mouth for no reason! Well...maybe I do...moving on.\n\n|CFF00FF00(2)|CFFFFFFFF Be careful with the buttons settings.  If you're absolutely certain you don't want to try the latest and greatest button layout that Gnomeregan has to offer, then uncheck the 'Buttons' option in the next tab.  People who do so will receive their goblin-lovers membership card in the mail in 6-8 weeks.\n\n|CFF00FF00(3)|CFFFFFFFF The Add-On tab of this window will tell you exactly which add-ons need updating.  If it says that an add-on needs updating this means either (a) Gnomeregan has discovered better initial settings or (b) the add-on author modified the format or content of the settings.  So, while you *can* uncheck items here so that they're not updated, it's probably better that you let them get updated in case the format changed.\n\nRemember, you can mouse-over many settings and see a tooltip with more information about it.\n\n"
