-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--
local BClass = AceLibrary("Babble-Class-2.2")

function Mazzifier:Mazzify_SW_Stats()
    local tempTable = {
		["HUNTER"] = {
			[1] = 0.66,
			[2] = 0.83,
			[3] = 0.45,
			[4] = 1,
		},
		["WARRIOR"] = {
			[1] = 0.78,
			[2] = 0.61,
			[3] = 0.43,
			[4] = 1,
		},
		["SHAMAN"] = {
			[1] = 0.96,
			[2] = 0.55,
			[3] = 0.73,
			[4] = 1,
		},
		["MAGE"] = {
			[1] = 0.41,
			[2] = 0.8,
			[3] = 0.94,
			[4] = 1,
		},
		["DRUID"] = {
			[1] = 1,
			[2] = 0.49,
			[3] = 0.04,
			[4] = 1,
		},
		["Damage"] = {
			[1] = 1,
			[2] = 0,
			[3] = 0,
			[4] = 1,
		},
		["TitleBarsFont"] = {
			[1] = 1,
			[2] = 1,
			[3] = 1,
			[4] = 1,
		},
		["MainWinBack"] = {
			[1] = 0,
			[2] = 0,
			[3] = 0,
			[4] = 0.6,
		},
		["PRIEST"] = {
			[1] = 0.8,
			[2] = 0.8,
			[3] = 0.8,
			[4] = 1,
		},
		["Heal"] = {
			[1] = 0,
			[2] = 1,
			[3] = 0,
			[4] = 1,
		},
		["WARLOCK"] = {
			[1] = 0.58,
			[2] = 0.51,
			[3] = 0.79,
			[4] = 1,
		},
		["ROGUE"] = {
			[1] = 1,
			[2] = 0.96,
			[3] = 0.41,
			[4] = 1,
		},
		["PALADIN"] = {
			[1] = 0.96,
			[2] = 0.55,
			[3] = 0.73,
			[4] = 1,
		},
		["TitleBars"] = {
			[1] = 0.6549019607843137,
			[2] = 0.6196078431372549,
			[3] = 0.6431372549019607,
			[4] = 1,
		},
		["Backdrops"] = {
			[1] = 0.7,
			[2] = 0.7,
			[3] = 1,
			[4] = 1,
		},
	}
    MazzleUI:CreateSet("SW_Settings.Colors", tempTable)
    MazzleUI:CreateSet("SW_Settings.OPT_ShowSyncB", 1)
    MazzleUI:CreateSet("SW_Settings.OPT_ShowConsoleB", false)
    MazzleUI:CreateSet("SW_Settings.OPT_ShowTLB", 1)
    MazzleUI:CreateSet("SW_Settings.SW_TL_AutoDelete", false)
    tempTable = {
		{
			["BFS"] = 10,
			["BT"] = 3,
			["OT"] = "D+",
			["BC"] = {
				0, -- [1]
				0.8, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["OTF"] = "Damage Done",
			["PF"] = "SW_PF_MB",
			["ShowRank"] = 1,
			["SF"] = "SW_Filter_Group",
			["ShowPercent"] = 1,
			["IN"] = 1,
			["ShowNumber"] = 1,
			["BFC"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["BH"] = 10,
			["COLC"] = 1,
			["OC"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["CF"] = 1,
		}, -- [1]
		{
			["IN"] = 2,
			["OT"] = "H+",
			["BC"] = {
				0, -- [1]
				0.8, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["HealEff"] = true,
			["ShowPercent"] = 1,
			["HealInF"] = true,
			["BH"] = 10,
			["SF"] = "SW_Filter_Group",
			["COLC"] = 1,
			["PF"] = "SW_PF_Ignore",
			["ShowRank"] = 1,
			["BFS"] = 10,
			["ShowNumber"] = 1,
			["BFC"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["BT"] = 3,
			["OTF"] = "Healing Done",
			["CF"] = 1,
			["OC"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
		}, -- [2]
		{
			["BFS"] = 10,
			["BT"] = 3,
			["OT"] = "D-",
			["BC"] = {
				0, -- [1]
				0.8, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["OTF"] = "Damage Taken",
			["PF"] = "SW_PF_MR",
			["ShowRank"] = 1,
			["SF"] = "SW_Filter_Group",
			["ShowPercent"] = 1,
			["CF"] = 1,
			["ShowNumber"] = 1,
			["BFC"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["IN"] = 3,
			["COLC"] = 1,
			["OC"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["BH"] = 10,
		}, -- [3]
		{
			["IN"] = 4,
			["OT"] = "H-",
			["BC"] = {
				0, -- [1]
				0.8, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["HealEff"] = true,
			["ShowPercent"] = 1,
			["HealInF"] = true,
			["BH"] = 10,
			["SF"] = "SW_Filter_Group",
			["COLC"] = 1,
			["PF"] = "SW_PF_MR",
			["ShowRank"] = 1,
			["OTF"] = "Healing Taken",
			["ShowNumber"] = 1,
			["BFC"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["BFS"] = 10,
			["BT"] = 3,
			["CF"] = 1,
			["OC"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
		}, -- [4]
		{
			["IN"] = 2,
			["OT"] = "OH",
			["BC"] = {
				0, -- [1]
				0.8, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["HealEff"] = false,
			["HealOH"] = true,
			["ShowPercent"] = 1,
			["HealInF"] = true,
			["BH"] = 10,
			["BFS"] = 10,
			["COLC"] = 1,
			["PF"] = "SW_PF_Ignore",
			["ShowRank"] = 1,
			["OTF"] = "Overhealing",
			["ShowNumber"] = 1,
			["BFC"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["SF"] = "SW_Filter_Group",
			["BT"] = 3,
			["CF"] = 1,
			["OC"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
		}, -- [5]
	}
    MazzleUI:CreateSet("SW_Settings.InfoSettings", tempTable)
end

function Mazzifier:Mazzify_Blizzard()
    TALENT_FRAME_WAS_SHOWN = nil
    SHOW_FULLSCREEN_STATUS = "1"
    SIMPLE_CHAT = "0"
    CHAT_LOCKED = "0"
    REMOVE_CHAT_DELAY = "1"
    SHOW_NEWBIE_TIPS = "0"
    LOCK_ACTIONBAR = "0"
    SHOW_BUFF_DURATIONS = "1"
    ALWAYS_SHOW_MULTIBARS = "0"
    SHOW_PARTY_PETS = "0"
    QUEST_FADING_DISABLE = "1"
    SHOW_PARTY_BACKGROUND = "0"
    HIDE_PARTY_INTERFACE = "1"
    SHOW_TARGET_OF_TARGET = "0"
    SHOW_TARGET_OF_TARGET_STATE = "5"
    HIDE_OUTDOOR_WORLD_STATE = "0"
    AUTO_QUEST_WATCH = "0"
    SHOW_COMBAT_TEXT = "0"
    COMBAT_TEXT_SHOW_LOW_HEALTH_MANA = "1"
    COMBAT_TEXT_SHOW_AURAS = "1"
    COMBAT_TEXT_SHOW_AURA_FADE = "1"
    COMBAT_TEXT_SHOW_COMBAT_STATE = "1"
    COMBAT_TEXT_SHOW_DODGE_PARRY_MISS = "1"
    COMBAT_TEXT_SHOW_RESISTANCES = "1"
    COMBAT_TEXT_SHOW_REPUTATION = "1"
    COMBAT_TEXT_SHOW_REACTIVES = "1"
    COMBAT_TEXT_SHOW_FRIENDLY_NAMES = "1"
    COMBAT_TEXT_SHOW_COMBO_POINTS = "0"
    COMBAT_TEXT_SHOW_MANA = "1"
    COMBAT_TEXT_FLOAT_MODE = "3"
    COMBAT_TEXT_SHOW_HONOR_GAINED = "1"
    NAMEPLATES_ON = nil
    SHOW_KEYRING = 1
    PARTYBACKGROUND_OPACITY = 0.5
    SHOW_OFFLINE_GUILD_MEMBERS = 0
    SHOW_DISPELLABLE_DEBUFFS = "0"
    SHOW_CASTABLE_BUFFS = "0"
    SHOW_BATTLEFIELD_MINIMAP = "0"
    SetCVar("cameraPitchMoveSpeed", "90")
    SetCVar("cameraYawMoveSpeed", "180")
    SetCVar("cameraPitchSmoothSpeed", "57.5")
    SetCVar("cameraYawSmoothSpeed", "230")
    SetCVar("cameraSmoothTrackingStyle", "0")
    SetCVar("cameraDistanceMaxFactor", "2")
    SetCVar("cameraView", "2")
    SetCVar("useUiScale", "1")
    SetCVar("targetNearestDistance", "45")
    SetCVar("ChatBubblesParty", "1")
    SetCVar("xpBarText", "1")
    SetCVar("playerStatusText", "1")
    SetCVar("partyStatusText", "1")
    SetCVar("petStatusText", "1")
    SetCVar("guildMemberNotify", "1")
    SetCVar("cameraTerrainTilt", "1")
    SetCVar("UnitNameFriendlyPlayerName","0")
    SetCVar("UnitNameEnemyPlayerName","0")
    SetCVar("UnitNameCompanionName","0")
    SetCVar("UnitNameEnemyPetName","0")
    SetCVar("UnitNameEnemyCreationName","0")
    SetCVar("UnitNameFriendlyPetName","0")
    SetCVar("UnitNameFriendlyCreationName","0")    
    SetCVar("UnitNamePlayerGuild", "0")
    SetCVar("UnitNamePlayerPVPTitle", "0")
    SetCVar("UnitNameNPC", "1")	
    SetCVar("checkAddonVersion","0")
    SetCVar("profanityFilter","0")
    SetCVar("Sound_EnableErrorSpeech","0")
    SetCVar("autoSelfCast","0")
    SetCVar("CombatDamage","1")
    SetCVar("CombatLogPeriodicSpells","1")
    ShowCloak(1)
    ShowHelm(1)
    SetGuildRecruitmentMode(0)

end

function Mazzifier:Mazzify_BugSack()
    MazzleUI:CreateSet("BugSackDB.save", false)
    MazzleUI:CreateSet("BugSackDB.profiles.Default.filterAddonMistakes", true)
    MazzleUI:CreateSet("BugSackDB.profiles.Default.soundMedia", "Link")
    MazzleUI:CreateSet("BugGrabberDB.save", false)
    MazzleUI:CreateSet("BugGrabberDB.profiles.Default.filterAddonMistakes", true)
end

function Mazzifier:Mazzify_OmniCC()
    OmniCC2DB = {
    	["vlong"] = {
    		["s"] = 0.6,
    		["r"] = 0.8,
    		["g"] = 0.8,
    		["b"] = 0.9,
    	},
    	["short"] = {
    		["s"] = 1.3,
    		["r"] = 1,
    		["g"] = 0,
    		["b"] = 0,
    	},
    	["long"] = {
    		["s"] = 0.8,
    		["r"] = 0.8,
    		["g"] = 0.8,
    		["b"] = 0.9,
    	},
    	["font"] = "Fonts\\ARIALN.ttf",
    	["version"] = "1.1",
    	["med"] = {
    		["s"] = 1,
    		["r"] = 1,
    		["g"] = 1,
    		["b"] = 0.4,
    	},
    	["pulse"] = 1,
    	["minDur"] = 3,
    	["fontSize"] = 20,
    }
end

function Mazzifier:Mazzify_Clique()
    MazzleUI:CreatePath("CliqueDB.profileKeys.dummy")
    CliqueDB.profileKeys[Mazzifier_PlayerName.." - "..Mazzifier_ServerName] = Mazzifier_PlayerName.." - "..Mazzifier_ServerName
    MazzleUI:CreatePath("CliqueDB.profiles.dummy")
    if (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Priest") then
        CliqueDB.profiles[Mazzifier_PlayerName.." - "..Mazzifier_ServerName] = {
			["clicksets"] = {
				["Default"] = {
					["Shift-5"] = {
						["type"] = "spell",
						["modifier"] = "Shift-",
						["button"] = 5,
						["delete"] = true,
						["arg1"] = "Inner Fire",
						["texture"] = "Interface\\Icons\\Spell_Holy_InnerFire",
					},
				},
				["Out of Combat"] = {
					["Ctrl-2"] = {
						["type"] = "spell",
						["modifier"] = "Ctrl-",
						["button"] = 2,
						["delete"] = true,
						["arg1"] = "Shadow Protection",
						["texture"] = "Interface\\Icons\\Spell_Shadow_AntiShadow",
					},
					["2"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = 2,
						["delete"] = true,
						["arg1"] = "Power Word: Fortitude",
						["texture"] = "Interface\\Icons\\Spell_Holy_WordFortitude",
					},
					["Shift-2"] = {
						["type"] = "spell",
						["modifier"] = "Shift-",
						["button"] = 2,
						["delete"] = true,
						["arg1"] = "Prayer of Fortitude",
						["texture"] = "Interface\\Icons\\Spell_Holy_PrayerOfFortitude",
					},
					["Ctrl-Shift-2"] = {
						["type"] = "spell",
						["modifier"] = "Ctrl-Shift-",
						["button"] = 2,
						["delete"] = true,
						["arg1"] = "Prayer of Shadow Protection",
						["texture"] = "Interface\\Icons\\Spell_Holy_PrayerofShadowProtection",
					},
					["Alt-2"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = 2,
						["delete"] = true,
						["arg1"] = "Resurrection",
						["texture"] = "Interface\\Icons\\Spell_Holy_Resurrection",
					},
				},
				["Helpful actions"] = {
					["Shift-helpbutton2"] = {
						["type"] = "spell",
						["modifier"] = "Shift-",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Dispel Magic",
						["texture"] = "Interface\\Icons\\Spell_Holy_DispelMagic",
					},
					["helpbutton5"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton5",
						["delete"] = true,
						["arg1"] = "Power Word: Shield",
						["texture"] = "Interface\\Icons\\Spell_Holy_PowerWordShield",
					},
					["Alt-helpbutton4"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton4",
						["delete"] = true,
						["arg1"] = "Fear Ward",
						["texture"] = "Interface\\Icons\\Spell_Holy_Excorcism",
					},
					["Alt-Shift-helpbutton2"] = {
						["type"] = "spell",
						["modifier"] = "Alt-Shift-",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Prayer of Healing",
						["texture"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Shift-helpbutton1"] = {
						["type"] = "spell",
						["modifier"] = "Shift-",
						["button"] = "helpbutton1",
						["delete"] = true,
						["arg1"] = "Abolish Disease",
						["texture"] = "Interface\\Icons\\Spell_Nature_NullifyDisease",
					},
					["Alt-helpbutton1"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton1",
						["delete"] = true,
						["arg1"] = "Flash Heal",
						["texture"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["helpbutton2"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Greater Heal",
						["texture"] = "Interface\\Icons\\Spell_Holy_GreaterHeal",
					},
					["Alt-helpbutton3"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton3",
						["delete"] = true,
						["arg1"] = "Power Word: Shield",
						["texture"] = "Interface\\Icons\\Spell_Holy_PowerWordShield",
					},
					["helpbutton4"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton4",
						["delete"] = true,
						["arg1"] = "Renew",
						["texture"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["helpbutton3"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton3",
						["delete"] = true,
						["arg1"] = "Flash Heal",
						["texture"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
				},
			},
		}
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Mage") then
        CliqueDB.profiles[Mazzifier_PlayerName.." - "..Mazzifier_ServerName] = {
			["clicksets"] = {
				["Helpful actions"] = {
					["Shift-helpbutton2"] = {
						["arg2"] = 1,
						["type"] = "spell",
						["modifier"] = "Shift-",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Arcane Brilliance",
						["texture"] = "Interface\\Icons\\Spell_Holy_ArcaneIntellect",
					},
					["Shift-helpbutton1"] = {
						["arg2"] = 4,
						["type"] = "spell",
						["modifier"] = "Shift-",
						["button"] = "helpbutton1",
						["delete"] = true,
						["arg1"] = "Dampen Magic",
						["texture"] = "Interface\\Icons\\Spell_Nature_AbolishMagic",
					},
					["Alt-helpbutton1"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton1",
						["delete"] = true,
						["arg1"] = "Remove Lesser Curse",
						["texture"] = "Interface\\Icons\\Spell_Nature_RemoveCurse",
					},
					["helpbutton2"] = {
						["arg2"] = 5,
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Arcane Intellect",
						["texture"] = "Interface\\Icons\\Spell_Holy_MagicalSentry",
					},
					["Alt-helpbutton2"] = {
						["arg2"] = 3,
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Amplify Magic",
						["texture"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
				},
			},
		}
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Druid") then
        CliqueDB.profiles[Mazzifier_PlayerName.." - "..Mazzifier_ServerName] = {
			["clicksets"] = {
				["Helpful actions"] = {
					["Shift-helpbutton2"] = {
						["type"] = "spell",
						["modifier"] = "Shift-",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Abolish Poison",
						["texture"] = "Interface\\Icons\\Spell_Nature_NullifyPoison_02",
					},
					["5"] = {
						["arg2"] = 5,
						["delete"] = true,
						["type"] = "spell",
						["modifier"] = "",
						["button"] = 5,
						["arg1"] = "Rebirth",
						["texture"] = "Interface\\Icons\\Spell_Nature_Reincarnation",
					},
					["Alt-4"] = {
						["arg2"] = 4,
						["delete"] = true,
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = 4,
						["arg1"] = "Tranquility",
						["texture"] = "Interface\\Icons\\Spell_Nature_Tranquility",
					},
					["Alt-helpbutton2"] = {
						["arg2"] = 9,
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Regrowth",
						["texture"] = "Interface\\Icons\\Spell_Nature_ResistNature",
					},
					["Shift-helpbutton1"] = {
						["type"] = "spell",
						["modifier"] = "Shift-",
						["button"] = "helpbutton1",
						["delete"] = true,
						["arg1"] = "Remove Curse",
						["texture"] = "Interface\\Icons\\Spell_Holy_RemoveCurse",
					},
					["Alt-helpbutton1"] = {
						["arg2"] = 11,
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton1",
						["delete"] = true,
						["arg1"] = "Rejuvenation",
						["texture"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["helpbutton2"] = {
						["arg2"] = 11,
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Healing Touch",
						["texture"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Alt-helpbutton3"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton3",
						["delete"] = true,
						["arg1"] = "Swiftmend",
						["texture"] = "Interface\\Icons\\INV_Relics_IdolofRejuvenation",
					},
					["helpbutton4"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton4",
						["delete"] = true,
						["arg1"] = "Innervate",
						["texture"] = "Interface\\Icons\\Spell_Nature_Lightning",
					},
					["helpbutton3"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton3",
						["delete"] = true,
						["arg1"] = "Nature's Swiftness",
						["texture"] = "Interface\\Icons\\Spell_Nature_RavenForm",
					},
				},
			},
		}
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Paladin") then
        CliqueDB.profiles[Mazzifier_PlayerName.." - "..Mazzifier_ServerName] = {
			["clicksets"] = {
				["Helpful actions"] = {
					["helpbutton3"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton3",
						["delete"] = true,
						["arg1"] = "Divine Intervention",
						["texture"] = "Interface\\Icons\\Spell_Nature_TimeStop",
					},
					["Alt-helpbutton3"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton3",
						["delete"] = true,
						["arg1"] = "Lay on Hands",
						["texture"] = "Interface\\Icons\\Spell_Holy_LayOnHands",
					},
					["Alt-helpbutton1"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton1",
						["delete"] = true,
						["arg1"] = "Cleanse",
						["texture"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["helpbutton2"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Flash of Light",
						["texture"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["4"] = {
						["delete"] = true,
						["type"] = "spell",
						["modifier"] = "",
						["button"] = 4,
						["arg1"] = "Blessing of Protection",
						["texture"] = "Interface\\Icons\\Spell_Holy_SealOfProtection",
					},
					["Alt-4"] = {
						["type"] = "spell",
						["delete"] = true,
						["modifier"] = "Alt-",
						["button"] = 4,
						["arg1"] = "Blessing of Freedom",
						["texture"] = "Interface\\Icons\\Spell_Holy_SealOfValor",
					},
					["Alt-helpbutton2"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Holy Light",
						["texture"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
				},
				["Out of Combat"] = {
					["2"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = 2,
						["delete"] = true,
						["arg1"] = "Redemption",
						["texture"] = "Interface\\Icons\\Spell_Holy_Resurrection",
					},
				},
			},
		}
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Shaman") then
        CliqueDB.profiles[Mazzifier_PlayerName.." - "..Mazzifier_ServerName] = {
			["clicksets"] = {
				["Helpful actions"] = {
					["helpbutton5"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton5",
						["delete"] = true,
						["arg1"] = "Cure Disease",
						["texture"] = "Interface\\Icons\\Spell_Nature_RemoveDisease",
					},
					["helpbutton2"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Healing Wave",
						["texture"] = "Interface\\Icons\\Spell_Nature_MagicImmunity",
					},
					["Alt-helpbutton4"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton4",
						["delete"] = true,
						["arg1"] = "Chain Heal",
						["texture"] = "Interface\\Icons\\Spell_Nature_HealingWaveGreater",
					},
					["helpbutton4"] = {
						["type"] = "spell",
						["modifier"] = "",
						["button"] = "helpbutton4",
						["delete"] = true,
						["arg1"] = "Cure Poison",
						["texture"] = "Interface\\Icons\\Spell_Nature_NullifyPoison",
					},
					["Alt-helpbutton2"] = {
						["type"] = "spell",
						["modifier"] = "Alt-",
						["button"] = "helpbutton2",
						["delete"] = true,
						["arg1"] = "Lesser Healing Wave",
						["texture"] = "Interface\\Icons\\Spell_Nature_HealingWaveLesser",
					},
				},
				["Out of Combat"] = {
					["2"] = {
						["arg2"] = 2,
						["type"] = "spell",
						["modifier"] = "",
						["button"] = 2,
						["delete"] = true,
						["arg1"] = "Ancestral Spirit",
						["texture"] = "Interface\\Icons\\Spell_Nature_Regenerate",
					},
				},
			},
		}
    end
end

function Mazzifier:Mazzify_Mendeleev()
    MazzleUI:CreateSet("MendeleevDB.profiles.Default.KCI", false)
    MazzleUI:CreateSet("MendeleevDB.profiles.Default.itemid", true)
    MazzleUI:CreateSet("MendeleevDB.profiles.Default.stacksize", false)
    MazzleUI:CreateSet("MendeleevDB.profiles.Default.showUsedInTree", true)
    MazzleUI:CreateSet("MendeleevDB.profiles.Default.limitUsedInTree", true)

end

function Mazzifier:Mazzify_Capping()
    MazzleUI:CreateSet("CappingDB.profiles.Default.scale", 1.1)
    MazzleUI:CreateSet("CappingDB.profiles.Default.mainup", true)
    MazzleUI:CreateSet("CappingDB.profiles.Default.wait", true)
end

function Mazzifier:Mazzify_Cartographer()
    MazzleUI:CreateSet("CartographerDB.namespaces.LookNFeel.profiles.Default.alpha", 0)
    MazzleUI:CreateSet("CartographerDB.namespaces.LookNFeel.profiles.Default.showMinimapButton", false)
    MazzleUI:CreateSet("CartographerDB.namespaces.Coordinates.profiles.Default.textG", 0.82)
    MazzleUI:CreateSet("CartographerDB.namespaces.Coordinates.profiles.Default.textSize", 1.2)
    MazzleUI:CreateSet("CartographerDB.namespaces.Waypoints.profiles.Default.waypointY", 280)
    MazzleUI:CreateSet("CartographerDB.namespaces.Waypoints.profiles.Default.waypointX", 0)
    MazzleUI:CreateSet("CartographerDB.namespaces.Waypoints.profiles.Default.corpsePoint", true)
    MazzleUI:CreateSet("CartographerDB.namespaces.Waypoints.profiles.Default.minimapShow", true)
end

function Mazzifier:Mazzify_Chatmanager()
    if (ChatmanagerState) then
        if ChatmanagerState.Servers[Mazzifier_ServerName].Characters then
            ChatmanagerState["Servers"][Mazzifier_ServerName]["Characters"][Mazzifier_PlayerName] = {
    					["Options"] = {
    						["HideChatButtons"] = 0,
    						["ChatLink"] = 0,
    						["ReplyLastTell"] = 0,
    						["EnableChatScroll"] = 1,
    						["SmartSticky"] = 0,
    						["ChatLog"] = 0,
    						["ShowButton"] = 1,
    						["ChatLinkFormat"] = 0,
    					},
    					["Sticky"] = {
    						["RAID"] = 1,
    						["GUILD"] = 1,
    						["SAY"] = 1,
    						["PARTY"] = 1,
    					},
                        ["Channels"] = {
    						["general"] = {
    							["index"] = 1,
    							["color"] = {
    								["r"] = 0.8823529933579266,
    								["g"] = 0.4980392451398075,
    								["b"] = 0.4705882631242275,
    							},
    							["name"] = "General",
    						},
    						["trade"] = {
    							["index"] = 2,
    							["color"] = {
    								["r"] = 1.000000059138984,
    								["g"] = 0.8078431850299239,
    								["b"] = 0.08627451490610838,
    							},
    							["name"] = "Trade",
    						},
    						["localdefense"] = {
    							["index"] = 10,
    							["color"] = {
    								["r"] = 1.000000059138984,
    								["g"] = 0.05098039517179132,
    								["b"] = 0.01960784429684281,
    							},
    							["name"] = "LocalDefense",
    						},
    						["lookingforgroup"] = {
    							["index"] = 3,
    							["color"] = {
    								["r"] = 1.000000059138984,
    								["g"] = 0.4627451254054904,
    								["b"] = 0,
    							},
    							["name"] = "LookingForGroup",
    						},
    					},
    				}
        Chatmanager_Initialize()
        end
    end
end

function Mazzifier:Mazzify_Incubator()
    MazzleUI:CreateSet("IncubatorDB.profiles.Default.baroptions.growup", true)
    MazzleUI:CreateSet("IncubatorDB.profiles.Default.baroptions.locked", true)
    MazzleUI:CreateSet("IncubatorDB.profiles.Default.baroptions.width", 200)
    MazzleUI:CreateSet("IncubatorDB.profiles.Default.baroptions.height", 20)
    MazzleUI:CreateSet("IncubatorDB.profiles.Default.baroptions.texture", "BantoBarReverse")
end

function Mazzifier:Mazzify_Baggins()

    MazzleUI:CreateSet("BagginsDB.profiles.Default.showused", false)
    MazzleUI:CreateSet("BagginsDB.profiles.Default.rightoffset", 49.99983988248869)
    MazzleUI:CreateSet("BagginsDB.profiles.Default.showammocount", false)
    MazzleUI:CreateSet("BagginsDB.profiles.Default.bottomoffset", 243.9999462994826)
    MazzleUI:CreateSet("BagginsDB.profiles.Default.showsoulcount", false)
    MazzleUI:CreateSet("BagginsDB.profiles.Default.topoffset", 49.9999838336139)
    MazzleUI:CreateSet("BagginsDB.profiles.Default.showspecialcount", false)
    MazzleUI:CreateSet("BagginsDB.profiles.Default.hidden", true)

end

function Mazzifier:Mazzify_KLHThreatMeter()

    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.lockwindow", false)
    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.columns.threat", true)
    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.columns.percent", true)
    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.columns.persecond", true)
    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.autohide.joinraid", true)
    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.autohide.joinraid", true)
    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.autohide.joinparty", true)
    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.tankregain", true)
    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.aggrogain", true)
    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.resize", true)
    MazzleUI:CreateSet("klhtmsavedvariables.raidtable.aggroloss", true)
    klhtmsavedvariables.raidtable[1] = {
			["scale"] = 1,
			["class"] = {
				["warrior"] = true,
				["paladin"] = true,
				["shaman"] = true,
				["rogue"] = true,
				["mage"] = true,
				["warlock"] = true,
				["priest"] = true,
				["hunter"] = true,
				["druid"] = true,
			},
			["alpha"] = 1,
			["textminorcolour"] = {
				["b"] = 0.5137254901960784,
				["g"] = 0.9450980392156863,
				["r"] = 1,
			},
			["position"] = {
				["y"] = -20.99967956542969,
				["x"] = -2.000150918960571,
			},
			["anchor"] = "topleft",
			["length"] = 10,
			["textmajorcolour"] = {
				["b"] = 1,
				["g"] = 0.9450980392156863,
				["r"] = 0.9490196078431372,
			},
			["colour"] = {
				["b"] = 0.5647058823529412,
				["g"] = 0.5843137254901961,
				["r"] = 0.5647058823529412,
			},
		}

end

function Mazzifier:Mazzify_BigWigs()

    MazzleUI:CreateSet("BigWigsDB.namespaces.Sounds.profiles.Default.sounds", true)
    MazzleUI:CreateSet("BigWigsDB.namespaces.BossBlock.profiles.Default.hidetells", false)
    MazzleUI:CreateSet("BigWigsDB.namespaces.BossBlock.profiles.Default.hideraidwarn", false)
    MazzleUI:CreateSet("BigWigsDB.namespaces.Messages.profiles.Default.display", "Scrolling Combat Text")
    MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.scale", 1)
    MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.emphasizeScale", 1)
    MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.emphasizeGrowup", true)
    MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.growup", true)
    MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("BigWigsDB.namespaces.Messages.profiles.Default.display", "BigWigs frame")
    MazzleUI:CreateSet("BigWigsFubarDB.profiles.Default.showText", false)

end

function Mazzifier:Mazzify_oRA2()

    MazzleUI:CreateSet("oRADB.namespaces.Optional/CoolDown.profiles.Default.hidden", true)
    MazzleUI:CreateSet("oRADB.namespaces.maintank.profiles.Default.notifydeath", true)
    MazzleUI:CreateSet("oRADB.namespaces.maintankoptional.profiles.Default.scale", 0.99)
    MazzleUI:CreateSet("oRADB.namespaces.maintankoptional.profiles.Default.posy", 168.9598367074508)
    MazzleUI:CreateSet("oRADB.namespaces.maintankoptional.profiles.Default.bartexture", "BantoBarReverse")
    MazzleUI:CreateSet("oRADB.namespaces.maintankoptional.profiles.Default.posx", 1077.760320599354)
    MazzleUI:CreateSet("oRADB.namespaces.maintankoptional.profiles.Default.growup", true)
    MazzleUI:CreateSet("oRADB.namespaces.maintankoptional.profiles.Default.showmttt", false)
    MazzleUI:CreateSet("oRADB.namespaces.maintankoptional.profiles.Default.numbers", false)
    MazzleUI:CreateSet("oRADB.profiles.Default.bartexture", "BantoBarReverse")
    MazzleUI:CreateSet("oRAFubarDB.profiles.Default.showText", false)

end

function Mazzifier:Mazzify_ItemSync()
    if (ISyncDB and ISyncDB.account and ISyncDB.account[Mazzifier_ServerName] and ISyncDB.account[Mazzifier_ServerName].options) then
        ISyncDB.account[Mazzifier_ServerName].options.database = {0}
        ISyncDB.account[Mazzifier_ServerName].options.showmoney = {1, 1, 1}
        ISyncDB.account[Mazzifier_ServerName].options.dropdown = {1}
        ISyncDB.account[Mazzifier_ServerName].options.minimapfloat = 0
    end
    MazzleUI:CreateSet("ItemSyncFuDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("ItemSyncFuDB.profiles.Default.hidden", true)
end

function Mazzifier:Mazzify_ItemRack()
    if ItemRack_Users then
        if ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName] then
            ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName]["Visible"] = "ON"
            ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName]["MainScale"] = 0.842002809047699
            ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName]["Sets"] = {
			    ["ItemRack-Queue"] = {
			        },
		    }
            ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName]["MainOrient"] = "VERTICAL"
            ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName]["Inv"] = {
    			[1] = 1,
    			[2] = 1,
    			[3] = 1,
    			[5] = 1,
    			[6] = 1,
    			[7] = 1,
    			[8] = 1,
    			[9] = 1,
    			[10] = 1,
    			[11] = 1,
    			[12] = 1,
    			[15] = 1,
    			[16] = 1,
    			[17] = 1,
    			[18] = 1,
    		}
            ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName]["Events"] = {
		    }
            ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName]["Spaces"] = {
		    }
            ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName]["Locked"] = "ON"
            ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName]["Ignore"] = {
       		}
            ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName]["Bar"] = {
    			[1] = 1,
    			[2] = 2,
    			[3] = 3,
    			[4] = 15,
    			[5] = 5,
    			[6] = 9,
    			[7] = 10,
    			[8] = 6,
    			[9] = 7,
    			[10] = 8,
    			[11] = 11,
    			[12] = 12,
    			[13] = 16,
    			[14] = 17,
    			[15] = 18,
    		}
        end
    end
    if (ItemRack_Settings) then
        ItemRack_Settings ["Notify"] = "ON"
        ItemRack_Settings ["AllowHidden"] = "ON"
        ItemRack_Settings ["Minimap"] = {}
        ItemRack_Settings ["ShowEmpty"] = "OFF"
        ItemRack_Settings ["SquareMinimap"] = "OFF"
        ItemRack_Settings ["ShowIcon"] = "OFF"
        ItemRack_Settings ["LargeFont"] = "OFF"
        ItemRack_Settings ["RotateMenu"] = "ON"
        ItemRack_Settings ["AutoToggle"] = "OFF"
        ItemRack_Settings ["BigCooldown"] = "ON"
        ItemRack_Settings ["ShowAllEvents"] = "OFF"
        ItemRack_Settings ["EnableEvents"] = "ON"
        ItemRack_Settings ["SetLabels"] = "ON"
        ItemRack_Settings ["Bindings"] = "ON"
        ItemRack_Settings ["FlipBar"] = "ON"
        ItemRack_Settings ["IconPos"] = 93.42504645808813
        ItemRack_Settings ["ShowTooltips"] = "ON"
        ItemRack_Settings ["RightClick"] = "ON"
        ItemRack_Settings ["DisableToggle"] = "ON"
        ItemRack_Settings ["FlipMenu"] = "OFF"
        ItemRack_Settings ["TinyTooltip"] = "OFF"
        ItemRack_Settings ["NotifyThirty"] = "ON"
        ItemRack_Settings ["TooltipFollow"] = "OFF"
        ItemRack_Settings ["CompactList"] = "OFF"
        ItemRack_Settings ["CooldownNumbers"] = "ON"
        ItemRack_Settings ["MenuShift"] = "OFF"
        ItemRack_Settings ["Soulbound"] = "ON"
    end
end

function Mazzifier:Mazzify_AutoBar()
    LoadAddOn("AutoBarConfig")
    AutoBarConfig:ResetSingle()
    local tempTable = {
			["gapping"] = 0,
			["columns"] = 24,
			["buttonHeight"] = 34,
			["rows"] = 1,
			["alpha"] = 10,
			["buttonWidth"] = 34,
			["dockShiftY"] = -15,
			["dockShiftX"] = -1,
			["popupToTop"] = true,
			["selectedTab"] = 1,
			["style"] = 3,
			["docking"] = "ChatFrame7",
			["hideDragHandle"] = 1,
		}
	MazzleUI:CreateSet("AutoBar_Config."..Mazzifier_PlayerName.."\32-\32"..Mazzifier_ServerName..".display", tempTable)
	tempTable = {
		["layoutProfile"] = Mazzifier_PlayerName.."\32-\32"..Mazzifier_ServerName,
		["useShared"] = false,
		["useClass"] = false,
		["useBasic"] = false,
		["edit"] = 3,
		["layout"] = 1,
		["useCharacter"] = true,
		["style"] = 3,
		["shared"] = "_SHARED1",
	}
	MazzleUI:CreateSet("AutoBar_Config."..Mazzifier_PlayerName.."\32-\32"..Mazzifier_ServerName..".profile", tempTable)
    for _,i in pairs({1, 2, 6, 8, 11, 12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24}) do
    	AutoBar_Config[Mazzifier_PlayerName.." - "..Mazzifier_ServerName].buttons[i] = { "AAACLEAR",}
    end    
end


function Mazzifier:Mazzify_FuBar_FarmerFu()
    local tempTable = {
				{
					["id"] = "21884",
					["hidden"] = false,
				}, -- [1]
				{
					["id"] = "22572",
					["hidden"] = false,
				}, -- [2]
				{
					["id"] = "22457",
					["hidden"] = false,
				}, -- [3]
				{
					["id"] = "21885",
					["hidden"] = false,
				}, -- [4]
				{
					["id"] = "22451",
					["hidden"] = false,
				}, -- [5]
				{
					["id"] = "23571",
					["hidden"] = false,
				}, -- [6]
				{
					["id"] = "21877",
					["hidden"] = false,
				}, -- [7]
				{
					["id"] = "21886",
					["hidden"] = false,
				}, -- [8]
			}
    MazzleUI:CreateSet("FarmerFu2DB.profiles.Default.items", tempTable)
    MazzleUI:CreateSet("FarmerFu2DB.profiles.Default.showText", false)
    MazzleUI:CreateSet("FarmerFu2DB.profiles.Default.showtooltip.bags", false)
    MazzleUI:CreateSet("FarmerFu2DB.profiles.Default.showtooltip.headers", false)
    MazzleUI:CreateSet("FarmerFu2DB.profiles.Default.showtooltip.bank", false)
end

function Mazzifier:Mazzify_FubarAddOns()
   
    MazzleUI:CreateSet("AnkhTimerFuDB.profiles.Default.showText", 0)
    MazzleUI:CreateSet("Auto_LootFuDB.profiles.Default.showText", 0)
    MazzleUI:CreateSet("AloftFuDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("AloftFuDB.profiles.Default.hidden", true)
    MazzleUI:CreateSet("BagginsDB.profiles.Default.hidden", true)
    MazzleUI:CreateSet("DurabilityFuDB.profiles.Default.showAverage", true)
    MazzleUI:CreateSet("ExperienceFuDB.profiles.Default.showText", true)
    MazzleUI:CreateSet("ExperienceFuDB.profiles.Default.showPercent.rest", false)
    MazzleUI:CreateSet("DrDamageDB.profiles.Default.hidden", true)
    MazzleUI:CreateSet("FuBar_AspectDB.profiles.default.showText", 0)
    MazzleUI:CreateSet("FuBar_CombatInfoFuDB.profiles.Default.showText", 0)
    MazzleUI:CreateSet("FuBar_FactionsFuDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("FuBar_FactionsFuDB.profiles.Default.text.show_standing", false)
    MazzleUI:CreateSet("FuBar_FactionsFuDB.profiles.Default.text.show_progress", false)
    MazzleUI:CreateSet("FuBar_FriendsFuDB.profiles.Default.text.show_displayed", false)
    MazzleUI:CreateSet("FuBar_GuildFuDB.profiles.Default.text.show_displayed", false)
    MazzleUI:CreateSet("FuBar_MailDB.profiles.Default.textformat", "number")
    MazzleUI:CreateSet("FuBar_NameToggleDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("FuBar_SWStats2FuDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("GarbageFuDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("gfxToggleDB.disabled.Default", true)
    MazzleUI:CreateSet("HonorFu2DB.profiles.Default.showText", true)
    MazzleUI:CreateSet("ItemSyncFuDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("ItemSyncFuDB.profiles.Default.hidden", true)
    MazzleUI:CreateSet("MoneyFuDB.profiles.Default.showIcon", false)
    MazzleUI:CreateSet("MoneyFuDB.profiles.Default.iconVisible", false)
    MazzleUI:CreateSet("NiagaraDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("OmnibusDB.profiles.Default.showIcon", false)
    MazzleUI:CreateSet("OmnibusDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("OmnibusDB.profiles.Default.hidden", true)
    MazzleUI:CreateSet("PratFuDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("PratFuDB.profiles.Default.hidden", true)
    MazzleUI:CreateSet("SkillsPlusFuDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("SanityDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("ToFuDB.profiles.Default.hook.oCD", false)
    MazzleUI:CreateSet("ToFuDB.profiles.Default.hook.Chronometer", false)
    MazzleUI:CreateSet("ToFuDB.profiles.Default.hook.Cartographer", true)
    MazzleUI:CreateSet("ToFuDB.profiles.Default.hidden", true)
    MazzleUI:CreateSet("TopScoreFuDB.profiles.Default.showText", false)


end

function Mazzifier:cyCircled()
    MazzleUI:CreateSet("cyCircledDB.namespaces.Bongos.profiles.Default.Class", false)
    MazzleUI:CreateSet("cyCircledDB.namespaces.Bongos.profiles.Default.Pet", false)
    MazzleUI:CreateSet("cyCircledDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("cyCircledDB.profiles.Default.hidden", true)
    MazzleUI:CreateSet("cyCircledDB.profiles.Default.skin", "Serenity: Gloss")
end

function Mazzifier:Mazzify_FuBar()

    MazzleUI:CreateSet("FuBar2DB.profiles.Default.fontSize", 13)
    MazzleUI:CreateSet("FuBar2DB.profiles.Default.transparency", 0)
    MazzleUI:CreateSet("FuBar2DB.profiles.Default.thickness", 7)
    MazzleUI:CreateSet("FuBar2DB.profiles.Default.leftSpacing", 7)
    MazzleUI:CreateSet("FuBar2DB.profiles.Default.centerSpacing", 8)
    MazzleUI:CreateSet("FuBar2DB.profiles.Default.rightSpacing", 7)
    MazzleUI:CreateSet("FuBar2DB.profiles.Default.adjust", false)
    MazzleUI:CreateSet("FuBar2DB.profiles.Default.autohideTop", true)
    MazzleUI:CreateSet("FuBar2DB.profiles.Default.overflow", true)
    MazzleUI:CreateSet("FuBar2DB.profiles.Default.hidingTooltipsInCombat", true)
    local tempTable = {
				[1] = {
					["xPercent"] = 0,
					["attachPoint"] = "TOP",
					["widthPercent"] = 1,
					["lock"] = true,
					["plugins"] = {
						["right"] = {
							[1] = "MazzleUI",
							[2] = "MailFu",
							[3] = "VolumeFu",
							[4] = "Auto_LootFu",
							[5] = "Name ToggleFu",
							[6] = "DurabilityFu",
							[7] = "SWStats2Fu",
						},
						["left"] = {
							[1] = "BugSack",
							[2] = "nQuestLog",
							[3] = "Answering Machine Plus",
							[4] = "oRA2",
							[5] = "Big Wigs",
							[6] = "Sanity Inventory",
							[7] = "Niagara",
							[8] = "KTMFu",
						},
						["center"] = {
							[1] = "FarmerFu",
							[2] = "ReagentFu",
							[3] = "AnkhTimerFu",
							[4] = "AmmoFu",
							[5] = "CrayonLib",
							[6] = "FactionsFu",
							[7] = "PetInfoFu",
							[8] = "CombatInfoFu",
							[9] = "SkillsPlusFu",
							[10] = "Top ScoreFu",
							[11] = "ExperienceFu",
							[12] = "HonorFu",
							[13] = "BattlegroundFu",
							[14] = "FriendsFu",
							[15] = "GuildFu",
							[16] = "GarbageFu",
							[17] = "MoneyFu",
							[18] = "ItemRackFu",
						},
					},
					["yPercent"] = 0.9866666482729135,
				},
			}
    MazzleUI:CreateSet("FuBar2DB.profiles.Default.panels", tempTable)
end

function Mazzifier:Mazzify_MovableBags()
    OpenAllBags()    
    MazzleUI:Execute("/movablebags reset")
end

function Mazzifier:Mazzify_nQuestLog()
    MazzleUI:CreateSet("nQuestLogDB.namespaces.Coloring.profiles.Default.trackerBorderColor", {["a"] = 1,["b"] = 0, ["g"] = 0, ["r"] = 0,})
    MazzleUI:CreateSet("nQuestLogDB.namespaces.Coloring.profiles.Default.trackerBackgroundColor", {["a"] = 0.47,["b"] = 0, ["g"] = 0, ["r"] = 0,})
    MazzleUI:CreateSet("nQuestLogDB.namespaces.Coloring.profiles.Default.objectiveHeader.threshold", true)   
    MazzleUI:CreateSet("nQuestLogDB.namespaces.Tooltips.profiles.Default.tooltipAnchor", "ANCHOR_BOTTOMLEFT")
    MazzleUI:CreateSet("nQuestLogDB.namespaces.DetailsFrame.profiles.Default.enabled", true)
    MazzleUI:CreateSet("nQuestLogDB.namespaces.DetailsFrame.profiles.Default.detail_data.transparency", 0.47)
    MazzleUI:CreateSet("nQuestLogDB.namespaces.DetailsFrame.profiles.Default.detail_data.offsety", -28)
    MazzleUI:CreateSet("nQuestLogDB.namespaces.DetailsFrame.profiles.Default.detail_data.offsetx", 324)
    MazzleUI:CreateSet("nQuestLogDB.namespaces.DetailsFrame.profiles.Default.detail_data.anchor", "TOPLEFT")
    MazzleUI:CreateSet("nQuestLogDB.namespaces.DetailsFrame.profiles.Default.detail_data.fontSizePercent", 1.15)

    MazzleUI:CreateSet("nQuestLogDB.namespaces.Comments.profiles.Default.data.transparency", 0.47)
    MazzleUI:CreateSet("nQuestLogDB.namespaces.Comments.profiles.Default.data.offsety", -28)
    MazzleUI:CreateSet("nQuestLogDB.namespaces.Comments.profiles.Default.data.offsetx", 663)
    MazzleUI:CreateSet("nQuestLogDB.namespaces.Comments.profiles.Default.data.anchor", "TOPLEFT")
    MazzleUI:CreateSet("nQuestLogDB.namespaces.Comments.profiles.Default.data.fontSizePercent", 1.15)

    MazzleUI:CreateSet("nQuestLogDB.namespaces.Notifications.profiles.Default.notifyFinishedObjective", true)
    MazzleUI:CreateSet("nQuestLogDB.namespaces.Notifications.profiles.Default.notifyLootedQuestItem", true)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.fontSize", 15)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.hideAllObjectives", false)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.hideCompletedObjectives", false)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.showZoneLevel", false)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.fontSizeZone", 15)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.zonePadding", 4)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.width", 326.9228458404541)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.showEmptyZones", false)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.positionTop", 1172)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.positionLeft", 0)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.questPadding", 3)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.positionBottom", 979.9998168945313)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.trackerGrowUp", false)
    MazzleUI:CreateSet("nQuestLogDB.profiles.Default.trackerLocked", true)
end

function Mazzifier:Mazzify_Sanity2()
    MazzleUI:CreateSet("SanityDB.profiles.Default.SearchTooltips", false)
    MazzleUI:CreateSet("SanityDB.profiles.Default.ShowBagIcon", false)
    MazzleUI:CreateSet("SanityDB.profiles.Default.showText", false)
end

function Mazzifier:Mazzify_sct()

    MazzleUI:CreateSet("SCT_CONFIG.currentProfile."..Mazzifier_PlayerName.."\32of\32"..Mazzifier_ServerName, "char")
    MazzleUI:CreateSet("SCT_CONFIG.chars.notFirstTime", true)
    MazzleUI:CreatePath("SCT_CONFIG.profiles.dummy")

    SCT_CONFIG.profiles["char/"..Mazzifier_PlayerName.." - "..Mazzifier_ServerName] = {
			["DMGFONT"] = 1,
			["SCTD_SPELLCOLOR"] = 1,
			["COLORS"] = {
				["SCTD_SHOWPET"] = {
					["r"] = 0.6,
					["g"] = 0.6,
					["b"] = 0,
				},
				["SCTD_SHOWSPELL"] = {
					["r"] = 1,
					["g"] = 1,
					["b"] = 0,
				},
				["SCTD_SHOWMELEE"] = {
					["r"] = 1,
					["g"] = 1,
					["b"] = 1,
				},
				["SCTD_SHOWPERIODIC"] = {
					["r"] = 1,
					["g"] = 1,
					["b"] = 0,
				},
				["SCTD_SHOWCOLORCRIT"] = {
					["b"] = 0,
					["g"] = 0,
					["r"] = 0.8274509803921568,
				},
			},
			["SHOWBUFF"] = false,
			["SCTD_SHOWCOLORCRIT"] = false,
			["SCTD_SHOWPET"] = 1,
			["SCTD_ENABLED"] = 1,
			["FRAMESDATA"] = {
				[1] = {
					["ANITYPE"] = 2,
					["FONT"] = 2,
					["ANISIDETYPE"] = 2,
					["YOFFSET"] = 90,
				},
				[2] = {
					["ANITYPE"] = 2,
					["DIRECTION"] = 1,
					["FONT"] = 2,
					["YOFFSET"] = 230,
				},
				[3] = {
					["ANITYPE"] = 1,
					["ALPHA"] = 100,
					["DIRECTION"] = false,
					["FADE"] = 1.5,
					["FONTSHADOW"] = 2,
					["TEXTSIZE"] = 24,
					["FONT"] = 2,
					["ANISIDETYPE"] = 1,
					["YOFFSET"] = 210,
					["XOFFSET"] = 0,
				},
				[10] = {
					["MSGFONT"] = 2,
					["MSGYOFFSET"] = 260,
				},
			},
			["PLAYSOUND"] = false,
			["SCTD_STICKYCRIT"] = false,
			["SCTD_USESCT"] = 1,
			["SHOWPOWER"] = false,
			["SPELLCOLOR"] = 1,
			["FRAMES"] = {
				["SHOWABSORB"] = 2,
				["SHOWREP"] = 2,
				["SHOWCOMBAT"] = 1,
				["SHOWDEBUFF"] = 10,
				["SHOWFADE"] = 2,
				["SHOWBUFF"] = 2,
				["SHOWEXECUTE"] = 10,
				["SHOWHONOR"] = 2,
			},
			["ANIMATIONSPEED"] = 20,
			["MANAFILTER"] = 75,
			["SPELLTYPE"] = 1,
			["SCTD_SHOWTARGETS"] = false,
			["SCTD_SHOWDMGTYPE"] = false,
			["SCTD_SHOWMELEE"] = 1,
			["SCTD_DMGFONT"] = 1,
			["SCTD_SHOWPERIODIC"] = 1,
			["SCTD_FLAGDMG"] = false,
			["SCTD_SHOWSPELL"] = 1,
			["SCTD_SHOWRESIST"] = 1,
			["FPSMODE"] = 1,
			["SCTD_SHOWSPELLNAME"] = 1,
			["SCTD_TARGET"] = 1,
		}
end

function Mazzifier:Mazzify_StatusWindow()
    if SWVar then
        SWVar[Mazzifier_PlayerName] = {
		["windows"] = {
			[1] = {
				["width"] = 75,
				["panes"] = {
					[1] = 1,
					[2] = 2,
					[3] = 0,
					[4] = 0,
					[5] = 0,
					[6] = 0,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
				},
			},
			[2] = {
				["horizontal"] = 1,
				["width"] = 105.8000030517578,
				["panes"] = {
					[1] = 10,
					[2] = 7,
					[3] = 0,
					[4] = 0,
					[5] = 0,
					[6] = 0,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
				},
			},
			[3] = {
				["width"] = 111.5999984741211,
				["panes"] = {
					[1] = 4,
					[2] = 0,
					[3] = 0,
					[4] = 0,
					[5] = 0,
					[6] = 0,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
				},
			},
			[4] = {
				["width"] = 86.59999847412109,
				["panes"] = {
					[1] = 3,
					[2] = 8,
					[3] = 0,
					[4] = 0,
					[5] = 0,
					[6] = 0,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
				},
			},
			[5] = {
				["width"] = 75,
				["panes"] = {
					[1] = 9,
					[2] = 0,
					[3] = 0,
					[4] = 0,
					[5] = 0,
					[6] = 0,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
				},
			},
			[6] = {
				["width"] = 75,
				["panes"] = {
					[1] = 0,
					[2] = 0,
					[3] = 0,
					[4] = 0,
					[5] = 0,
					[6] = 0,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
				},
			},
			[7] = {
				["background"] = 1,
				["width"] = 75,
				["panes"] = {
					[1] = 0,
					[2] = 0,
					[3] = 0,
					[4] = 0,
					[5] = 0,
					[6] = 0,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
				},
			},
			[8] = {
				["background"] = 1,
				["width"] = 75,
				["panes"] = {
					[1] = 0,
					[2] = 0,
					[3] = 0,
					[4] = 0,
					[5] = 0,
					[6] = 0,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
				},
			},
			[9] = {
				["background"] = 1,
				["width"] = 75,
				["panes"] = {
					[1] = 0,
					[2] = 0,
					[3] = 0,
					[4] = 0,
					[5] = 0,
					[6] = 0,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
				},
			},
			[10] = {
				["background"] = 1,
				["width"] = 75,
				["panes"] = {
					[1] = 0,
					[2] = 0,
					[3] = 0,
					[4] = 0,
					[5] = 0,
					[6] = 0,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
				},
			},
			[0] = {
				["panes"] = {
					[1] = 0,
					[2] = 0,
					[3] = 0,
					[4] = 0,
					[5] = 5,
					[6] = 6,
					[7] = 0,
					[8] = 0,
					[9] = 0,
					[10] = 0,
					[11] = 11,
					[12] = 12,
					[13] = 13,
					[14] = 14,
					[15] = 15,
					[16] = 16,
					[17] = 17,
					[18] = 18,
					[19] = 19,
					[20] = 20,
				},
			},
		},
		["panes"] = {
			[1] = "Time",
			[2] = "Latency",
			[3] = "FPS",
			[4] = "Durability",
			[5] = "Right Click",
			[6] = "Right Click",
			[7] = "Money",
			[8] = "Memory",
			[9] = "Position",
			[10] = "Bag Slots",
			[11] = "Right Click",
			[12] = "Right Click",
			[13] = "Right Click",
			[14] = "Right Click",
			[15] = "Right Click",
			[16] = "Right Click",
			[17] = "Right Click",
			[18] = "Right Click",
			[19] = "Right Click",
			[20] = "Right Click",
		},
	}
    end
end

function Mazzifier:Mazzify_TrinketMenu()

    if (not TrinketMenuPerOptions) then
        TrinketMenuPerOptions = {}
    end
    if (not TrinketMenuOptions) then
        TrinketMenuOptions = {}
    end
    TrinketMenuOptions["Columns"] = 3
    TrinketMenuOptions["CooldownCount"] = "OFF"
    TrinketMenuOptions["DisableToggle"] = "ON"
    TrinketMenuOptions["IconPos"] = -100
    TrinketMenuOptions["KeepDocked"] = "ON"
    TrinketMenuOptions["KeepOpen"] = "OFF"
    TrinketMenuOptions["LargeCooldown"] = "ON"
    TrinketMenuOptions["Locked"] = "ON"
    TrinketMenuOptions["MenuOnRight"] = "ON"
    TrinketMenuOptions["MenuOnShift"] = "OFF"
    TrinketMenuOptions["Notify"] = "ON"
    TrinketMenuOptions["NotifyChatAlso"] = "OFF"
    TrinketMenuOptions["NotifyThirty"] = "ON"
    TrinketMenuOptions["NotifyUsedOnly"] = "ON"
    TrinketMenuOptions["SetColumns"] = "ON"
    TrinketMenuOptions["ShowHotKeys"] = "ON"
    TrinketMenuOptions["ShowIcon"] = "ON"
    TrinketMenuOptions["ShowTooltips"] = "ON"
    TrinketMenuOptions["SquareMinimap"] = "OFF"
    TrinketMenuOptions["StopOnSwap"] = "OFF"
    TrinketMenuOptions["TinyTooltips"] = "OFF"
    TrinketMenuOptions["TooltipFollow"] = "OFF"
    TrinketMenuPerOptions["MainDock"] = "TOPRIGHT"
    TrinketMenuPerOptions["MainOrient"] = "HORIZONTAL"
    TrinketMenuPerOptions["MainScale"] = 1
    TrinketMenuPerOptions["MenuDock"] = "TOPLEFT"
    TrinketMenuPerOptions["MenuOrient"] = "HORIZONTAL"
    TrinketMenuPerOptions["MenuScale"] = 0.9091954231262207
    TrinketMenuPerOptions["Visible"] = "ON"
end

function Mazzifier:Mazzify_Decursive()
    MazzleUI:CreateSet("DcrDB.profiles.Default.hidden", true)
    MazzleUI:CreateSet("DcrDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("DcrDB.profiles.Default.DebuffsFramePerline", 15)
    MazzleUI:CreateSet("DcrDB.profiles.Default.LiveListAlpha", 0.4)
    MazzleUI:CreateSet("DcrDB.profiles.Default.Amount_Of_Afflicted", 5)
    MazzleUI:CreateSet("DcrDB.profiles.Default.LiveListScale", 1)
    MazzleUI:CreateSet("DcrDB.profiles.Default.Hidden", true)
    MazzleUI:CreateSet("DcrDB.profiles.Default.DebuffsFrameMaxCount", 40)
    MazzleUI:CreateSet("DcrDB.profiles.Default.ReverseLiveDisplay", true)
    MazzleUI:CreateSet("DcrDB.profiles.Default.DebuffsFrameElemAlpha", 0.38)
    MazzleUI:CreateSet("DcrDB.profiles.Default.DebuffsFrameElemBorderAlpha", 0.19)
end

function Mazzifier:Mazzify_Hourglass()
    MazzleUI:CreateSet("HourglassDB.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("HourglassDB.profiles.Default.emphasizeGrowup", true)
    MazzleUI:CreateSet("HourglassDB.profiles.Default.width", 190)

    MazzleUI:CreateSet("HourglassDB.profiles.Default.growth", true)
    MazzleUI:CreateSet("HourglassDB.profiles.Default.height", 16)
    MazzleUI:CreateSet("HourglassDB.profiles.Default.scale", 1.0)
    MazzleUI:CreateSet("HourglassDB.profiles.Default.emphasizeScale", 1.0)
    MazzleUI:CreateSet("HourglassDB.profiles.Default.max", 3600)
    MazzleUI:CreateSet("HourglassDB.profiles.Default.min", 2.5)
end

function Mazzifier:Mazzify_Quartz()
    MazzleUI:CreateSet("QuartzDB.namespaces.Target.profiles.Default.border", "None")
    MazzleUI:CreateSet("QuartzDB.namespaces.Target.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("QuartzDB.namespaces.Target.profiles.Default.alpha", 0.75)
    MazzleUI:CreateSet("QuartzDB.namespaces.Target.profiles.Default.h", 10)
    MazzleUI:CreateSet("QuartzDB.namespaces.Target.profiles.Default.w", 135)
    MazzleUI:CreateSet("QuartzDB.namespaces.Target.profiles.Default.hideicon", true)
    MazzleUI:CreateSet("QuartzDB.namespaces.Target.profiles.Default.fontsize", 11)
    MazzleUI:CreateSet("QuartzDB.namespaces.Target.profiles.Default.font", "Arial Narrow")
    MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.target", false)
    MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.focus", true)
    MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.bufffontsize", 11)
    MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.bufftexture", "BantoBarReverse")
    MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.focuswidth", 120)
    MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.focusheight", 16)
    MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.focusanchor", "Free")
    MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.focusx", 0)
    MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.focusy", 0)
    MazzleUI:CreateSet("QuartzDB.namespaces.Mirror.profiles.Default.mirrortexture", "BantoBarReverse")
    MazzleUI:CreateSet("QuartzDB.namespaces.Mirror.profiles.Default.mirrorposition", "Top")
    MazzleUI:CreateSet("QuartzDB.namespaces.Mirror.profiles.Default.mirroranchor", "Free")
    MazzleUI:CreateSet("QuartzDB.namespaces.Mirror.profiles.Default.mirrorwidth", 190)
    MazzleUI:CreateSet("QuartzDB.namespaces.Mirror.profiles.Default.mirrorheight", 16)
    MazzleUI:CreateSet("QuartzDB.namespaces.Mirror.profiles.Default.mirrorfontsize", 12)
    MazzleUI:CreateSet("QuartzDB.namespaces.Player.profiles.Default.border", "None")
    MazzleUI:CreateSet("QuartzDB.namespaces.Player.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("QuartzDB.namespaces.Player.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("QuartzDB.namespaces.Player.profiles.Default.h", 20)
    MazzleUI:CreateSet("QuartzDB.namespaces.Player.profiles.Default.w", 190)
    MazzleUI:CreateSet("QuartzDB.namespaces.Player.profiles.Default.iconalpha", 0.75)
    MazzleUI:CreateSet("QuartzDB.namespaces.Player.profiles.Default.icongap", 1)
    MazzleUI:CreateSet("QuartzDB.namespaces.Player.profiles.Default.fontsize", 11)
    MazzleUI:CreateSet("QuartzDB.namespaces.Focus.profiles.Default.alpha", 0.8)
    MazzleUI:CreateSet("QuartzDB.namespaces.Focus.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("QuartzDB.namespaces.Focus.profiles.Default.w", 120)
    MazzleUI:CreateSet("QuartzDB.namespaces.Focus.profiles.Default.x", 0)
    MazzleUI:CreateSet("QuartzDB.namespaces.Focus.profiles.Default.y", 0)
    MazzleUI:CreateSet("QuartzDB.namespaces.Focus.profiles.Default.fontsize", 12)
    MazzleUI:CreateSet("QuartzDB.namespaces.Focus.profiles.Default.font", "Arial Narrow")
    MazzleUI:CreateSet("QuartzDB.namespaces.GCD.profiles.Default.gcdposition", "Top")
    MazzleUI:CreateSet("QuartzDB.namespaces.GCD.profiles.Default.gcdalpha", 8)
    MazzleUI:CreateSet("QuartzDB.namespaces.GCD.profiles.Default.gcdheight", 4)
    MazzleUI:CreateSet("QuartzDB.namespaces.GCD.profiles.Default.sparkcolor", {[2] = 0.8627450980392157, [3] = 0.05882352941176471,})
    MazzleUI:CreateSet("QuartzDB.namespaces.Latency.profiles.Default.lagtextposition", "Below")
    MazzleUI:CreateSet("QuartzDB.namespaces.Latency.profiles.Default.lagfont", "Calibri v1.0")
    MazzleUI:CreateSet("QuartzDB.namespaces.Latency.profiles.Default.lagfontsize", 12)
    MazzleUI:CreateSet("QuartzDB.disabledModules.Default.Buff", false)
    MazzleUI:CreateSet("QuartzDB.disabledModules.Default.Target", false)
    MazzleUI:CreateSet("QuartzDB.disabledModules.Default.Timer", true)
    MazzleUI:CreateSet("QuartzDB.disabledModules.Default.Range", true)
    MazzleUI:CreateSet("QuartzDB.disabledModules.Default.Focus", false)
end

function Mazzifier:Mazzify_Prat()
    local tempTable
    MazzleUI:CreateSet("PratFuDB.profiles.Default.showText", false)
    MazzleUI:CreateSet("PratFuDB.profiles.Default.hidden", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.Alias", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.CustomFilters", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratAddonMsgs", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratAltNames", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratChannelReordering", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratChannelSeparator", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratChatFrames", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratChatLangButton", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratChatLog", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratClear", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratEventNames", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratFiltering", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratFontSize", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratPopupMessage", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratServerNames", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratSounds", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratSubstitutions", true)
    MazzleUI:CreateSet("PratDB.disabledModules.Default.PratUrlCopy", true)
    MazzleUI:CreateSet("PratDB.namespaces.PratChannelSeparator.profiles.Default.on", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratServerNames.profiles.Default.on", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratChatButtons.profiles.Default.reminder", true)
    MazzleUI:CreateSet("PratDB.namespaces.PratChatFrames.profiles.Default.initialized", true)
    MazzleUI:CreateSet("PratDB.namespaces.PratChatFrames.profiles.Default.on", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratChatLink.profiles.Default.on", true)
    MazzleUI:CreateSet("PratDB.namespaces.PratEventNames.profiles.Default.on", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratFontSize.profiles.Default.on", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratKeyBindings.profiles.Default.on", true)
    MazzleUI:CreateSet("PratDB.namespaces.PratPopupMessage.profiles.Default.on", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratUrlCopy.profiles.Default.on", false)
    MazzleUI:Execute("/prat channames say set Say")
    tempTable = {
					["shortnames"] = {
						["whisper"] = "To ",
						["say"] = "",
						["whisperincome"] = "",
						["yell"] = "",
					},
					["colon"] = false,
					["replace"] = {
						["channel5"] = false,
						["channel10"] = false,
						["say"] = false,
						["channel9"] = false,
						["channel3"] = false,
						["channel4"] = false,
						["yell"] = false,
						["channel8"] = false,
						["channel6"] = false,
						["channel7"] = false,
					},
					["space"] = false,
				}
    MazzleUI:CreateSet("PratDB.namespaces.PratChannelNames.profiles.Default", tempTable)
    MazzleUI:CreateSet("PratDB.namespaces.PratChannelSticky.profiles.Default.raid_warning", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratChannelSticky.profiles.Default.yell", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratChannelSticky.profiles.Default.whisper", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratChannelSticky.profiles.Default.emote", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratChannelSticky.profiles.Default.channel", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratChannelSticky.profiles.Default.battleground", false)
    MazzleUI:CreateSet("PratDB.namespaces.PratChatTabs.profiles.Default.on", true)
    MazzleUI:CreateSet("PratDB.namespaces.PratChatTabs.profiles.Default.cf", {[1] = "DEFAULT", [2] = "DEFAULT", [3] = "DEFAULT", [4] = "DEFAULT", [5] = "DEFAULT", [6] = "HIDDEN", [7] = "HIDDEN",})
    MazzleUI:CreateSet("PratDB.namespaces.PratChatTabs.profiles.Default.mode", "INDIVIDUAL")
    MazzleUI:CreateSet("PratDB.namespaces.PratJustify.profiles.Default.justification", {[6] = "CENTER",})
    MazzleUI:CreateSet("PratDB.namespaces.PratScroll.profiles.Default.LowDown", {
						[1] = false,
						[2] = false,
						[3] = false,
						[4] = false,
						[5] = false,
					})
    MazzleUI:CreateSet("PratDB.namespaces.PratScroll.profiles.Default.lowdowndelay", 40)
    MazzleUI:CreateSet("PratDB.namespaces.PratHistory.profiles.Default.chatlines", {
						[1] = 500,
						[2] = 400,
						[5] = 350,
						[7] = 300,
					})
    MazzleUI:Execute("/prat timestamps separate")
    tempTable = {
					["color"] = {
						["r"] = 0.8509803921568627,
						["g"] = 0.8509803921568627,
						["b"] = 0.8509803921568627,
					},
					["show"] = {
						[6] = false,
						[7] = false,
					},
					["format"] = {
						"%I:%M", -- [1]
						"%I:%M", -- [2]
						"%I:%M", -- [3]
						"%I:%M", -- [4]
						"%I:%M", -- [5]
						"", -- [6]
						"", -- [7]
					},
				}
    MazzleUI:CreateSet("PratDB.namespaces.PratTimestamps.profiles.Default", tempTable)
    MazzleUI:CreateSet("PratDB.namespaces.PlayerNames.profiles.Default.subgroup", false)
    MazzleUI:CreateSet("PratDB.namespaces.PlayerNames.profiles.Default.level", false)
    MazzleUI:CreateSet("PratDB.namespaces.PlayerNames.profiles.Default.linkinvite", true)

end

function Mazzifier:Mazzify_AHsearch()
    local tempTable = {
					["queries"] = {
						["Shadowcloth"] = {
							["minLevel"] = "",
							["name"] = "Shadowcloth",
							["order"] = 1,
							["qualityIndex"] = -1,
							["maxLevel"] = "",
							["classIndex"] = 5,
						},
						["Netherweb Spider Silk"] = {
							["name"] = "Netherweb Spider Silk",
							["order"] = 1,
							["qualityIndex"] = -1,
							["maxLevel"] = "",
							["minLevel"] = "",
						},
						["Netherweave Cloth"] = {
							["maxLevel"] = "",
							["minLevel"] = "",
							["order"] = 1,
							["qualityIndex"] = -1,
							["name"] = "Netherweave Cloth",
							["classIndex"] = 5,
						},
						["SpellCloth"] = {
							["name"] = "SpellCloth",
							["order"] = 1,
							["qualityIndex"] = -1,
							["maxLevel"] = "",
							["minLevel"] = "",
						},
						["Primal Mooncloth"] = {
							["minLevel"] = "",
							["name"] = "Primal Mooncloth",
							["order"] = 1,
							["qualityIndex"] = -1,
							["maxLevel"] = "",
							["classIndex"] = 5,
						},
					},
					["order"] = 1,
				}
    MazzleUI:CreateSet("AHsearchDB.profiles.Default.search.Tailoring", tempTable)

    local tempTable = {
					["order"] = 1,
					["queries"] = {
						["Sunfury Signet"] = {
							["maxLevel"] = "",
							["order"] = 1,
							["qualityIndex"] = -1,
							["name"] = "Sunfury Signet",
							["minLevel"] = "",
						},
						["Fel Armament"] = {
							["maxLevel"] = "",
							["order"] = 1,
							["qualityIndex"] = -1,
							["name"] = "fel armament",
							["minLevel"] = "",
						},
						["Arcane Tome"] = {
							["maxLevel"] = "",
							["order"] = 1,
							["qualityIndex"] = -1,
							["name"] = "arcane tome",
							["minLevel"] = "",
						},
					},
				}
    MazzleUI:CreateSet("AHsearchDB.profiles.Default.search.Reputation", tempTable)

    local tempTable = {
					["queries"] = {
						["Primal Life"] = {
							["minLevel"] = "",
							["order"] = 1,
							["qualityIndex"] = -1,
							["maxLevel"] = "",
							["name"] = "Primal Life",
						},
						["Primal Might"] = {
							["name"] = "Primal Might",
							["order"] = 1,
							["qualityIndex"] = -1,
							["maxLevel"] = "",
							["minLevel"] = "",
						},
						["Primal Fire"] = {
							["minLevel"] = "",
							["order"] = 1,
							["qualityIndex"] = -1,
							["maxLevel"] = "",
							["name"] = "Primal Fire",
						},
						["Primal Air"] = {
							["name"] = "Primal Air",
							["order"] = 1,
							["qualityIndex"] = -1,
							["maxLevel"] = "",
							["minLevel"] = "",
						},
						["Primal Mana"] = {
							["name"] = "Primal Mana",
							["order"] = 1,
							["qualityIndex"] = -1,
							["maxLevel"] = "",
							["minLevel"] = "",
						},
						["Primal Water"] = {
							["name"] = "Primal Water",
							["order"] = 1,
							["qualityIndex"] = -1,
							["maxLevel"] = "",
							["minLevel"] = "",
						},
					},
					["order"] = 1,
				}
    MazzleUI:CreateSet("AHsearchDB.profiles.Default.search.Primals", tempTable)

    local tempTable = {
					["order"] = 1,
					["queries"] = {
						["Star of Elune"] = {
							["maxLevel"] = "",
							["order"] = 1,
							["qualityIndex"] = -1,
							["name"] = "Star of Elune",
							["minLevel"] = "",
						},
						["Dawnstone"] = {
							["maxLevel"] = "",
							["order"] = 1,
							["qualityIndex"] = -1,
							["name"] = "Dawnstone",
							["minLevel"] = "",
						},
						["Noble Topaz"] = {
							["maxLevel"] = "",
							["order"] = 1,
							["qualityIndex"] = -1,
							["name"] = "Noble Topaz",
							["minLevel"] = "",
						},
					},
				}
    MazzleUI:CreateSet("AHsearchDB.profiles.Default.search.Gems", tempTable)

end

function Mazzifier:Mazzify_AdvancedTradeSkillWindow()
    atsw_considerbank = true
    atsw_consideralts = true
    atsw_considermerchants = true
    atsw_autobuy = false
    atsw_multicount = false
    atsw_recipetooltip = false
        
end
function Mazzifier:Mazzify_SimpleDruidBar()
    SimpleDruidBar_Config = {
    	["Height"] = 20,
    	["TextStyle"] = 1,
    	["Alpha"] = 0.8,
    	["Width"] = 169,
    }
end

function Mazzifier:Mazzify_ShardAce()
    MazzleUI:CreateSet("ShardAceDB.profiles.Default.SummonerPosition", "top")
    MazzleUI:CreateSet("ShardAceDB.profiles.Default.AutoSort", false)
end

function Mazzifier:Mazzify_MobHealth()

    MobHealth3DB = {
    	["Skeletal Sorcerer:52"] = 2813,
    	["Crimson Monk:60"] = 9186,
    	["Claw Tentacle:60"] = 1373,
    	["Cannon Master Willey:60"] = 36181,
    	["Black Broodling:52"] = 2444,
    	["Eye of C'Thun:-1"] = 1236935,
    	["Rotting Sludge:54"] = 3278,
    	["Blackwing Technician:60"] = 15141,
    	["Flameguard:61"] = 78326,
    	["Razzashi Venombrood:60"] = 12000,
    	["Twilight Stonecaller:60"] = 3396,
    	["Mummified Atal'ai:46"] = 6007,
    	["Sartura's Royal Guard:61"] = 94280,
    	["Sand Skitterer:56"] = 3618,
    	["High Priest Venoxis:-1"] = 219052,
    	["The Nameless Prophet:41"] = 4904,
    	["Qiraji Champion:63"] = 267360,
    	["Onyxian Warder:60"] = 76117,
    	["Voodoo Slave:60"] = 12376,
    	["Death Talon Dragonspawn:60"] = 36100,
    	["Dust Stormer:55"] = 3475,
    	["Soulflayer:61"] = 43900,
    	["Bloodlord Mandokir:-1"] = 456033,
    	["Scourge Soldier:54"] = 3170,
    	["Corrupted Green Whelp:60"] = 4494,
    	["Hukku:52"] = 8198,
    	["Risen Protector:59"] = 7131,
    	["Qiraji Scorpion:60"] = 6015,
    	["Gasher:51"] = 6894,
    	["Crimson Guardsman:58"] = 8625,
    	["Risen Guard:57"] = 8369,
    	["Razzashi Cobra:60"] = 15450,
    	["Vaelastrasz the Corrupt:-1"] = 3180047,
    	["Noxious Slime:46"] = 5000,
    	["Young Black Bear:6"] = 144,
    	["Venomtip Scorpid:53"] = 3181,
    	["Scholomance Necromancer:59"] = 7122,
    	["Twilight Keeper Exeter:60"] = 4133,
    	["Hive'Ashi Worker:58"] = 8375,
    	["Firesworn:60"] = 60825,
    	["Scarshield Grunt:54"] = 7642,
    	["Lava Surger:61"] = 93881,
    	["Hive'Ashi Sandstalker:58"] = 8476,
    	["Atal'ai Corpse Eater:49"] = 6249,
    	["Death Singer:57"] = 3740,
    	["Ravasaur Hunter:49"] = 3183,
    	["Thessala Hydra:46"] = 11252,
    	["Zulian Crocolisk:60"] = 9093,
    	["Crimson Sorcerer:59"] = 6127,
    	["Withered Mistress:60"] = 12622,
    	["Noth the Plaguebringer:-1"] = 1625444,
    	["Thessala Hydra:47"] = 11466,
    	["Crimson Defender:58"] = 6105,
    	["Stonelash Flayer:58"] = 3913,
    	["Stoneskin Gargoyle:61"] = 263359,
    	["Earth Elemental:55"] = 2781,
    	["Magma Elemental:46"] = 2377,
    	["Poison Sprite:43"] = 1257,
    	["Gehennas:-1"] = 305622,
    	["Gurubashi Headhunter:60"] = 21534,
    	["Zul'Lor:52"] = 18408,
    	["Gurubashi Warrior:55"] = 7830,
    	["Stonelash Scorpid:54"] = 3275,
    	["Infernal:60"] = 5005,
    	["Diemetradon:52"] = 3305,
    	["Deep Lurker:48"] = 6761,
    	["Blackwing Taskmaster:62"] = 51341,
    	["Stonelash Pincer:56"] = 3650,
    	["Gorishi Tunneler:53"] = 3210,
    	["Deathknight:61"] = 71604,
    	["Onyxian Warder:62"] = 80072,
    	["Hive'Regal Slavemaker:60"] = 9621,
    	["Hive'Regal Ambusher:59"] = 8743,
    	["Crypt Guard:61"] = 185556,
    	["Qiraji Lasher:61"] = 94892,
    	["Blackwing Guardsman:61"] = 29870,
    	["Greater Lava Spider:47"] = 2496,
    	["Dredge Striker:56"] = 3208,
    	["Frenzied Pterrordax:52"] = 3347,
    	["Lava Annihilator:62"] = 97051,
    	["Frenzied Bloodseeker Bat:60"] = 6408,
    	["Scourge Warder:56"] = 2907,
    	["Hakkari Shadow Hunter:61"] = 24854,
    	["Elder Diemetradon:55"] = 3529,
    	["Broodlord Lashlayer:-1"] = 911417,
    	["Sandfury Speaker:61"] = 21759,
    	["Onyxian Warder:63"] = 82778,
    	["Atal'ai Slave:46"] = 2484,
    	["Tar Beast:50"] = 2773,
    	["Fetid Zombie:54"] = 3557,
    	["Putridus Trickster:44"] = 5757,
    	["Spewed Larva:45"] = 5238,
    	["Crypt Slayer:59"] = 3967,
    	["Gurubashi Bat Rider:61"] = 31623,
    	["Noxxious Scion:46"] = 5712,
    	["Dread Weaver:59"] = 2776,
    	["Firemaw:-1"] = 980296,
    	["Cliff Walker:52"] = 7256,
    	["Un'Goro Gorilla:50"] = 3021,
    	["Qiraji Slayer:61"] = 99656,
    	["Elder Diemetradon:54"] = 3302,
    	["Sacrificed Troll:60"] = 763,
    	["Ragnaros:-1"] = 1072470,
    	["Rotting Ghoul:54"] = 3358,
    	["Flamewaker:62"] = 75629,
    	["Stonelash Scorpid:55"] = 3385,
    	["Shazzrah:-1"] = 291363,
    	["Diseased Flayer:59"] = 3973,
    	["Vekniss Drone:60"] = 5958,
    	["Hakkari Shadowcaster:61"] = 25142,
    	["Vekniss Soldier:61"] = 81568,
    	["Nightmare Phantasm:62"] = 57862,
    	["Atal'ai Slave:47"] = 2596,
    	["Hive'Regal Ambusher:60"] = 9409,
    	["Alexi Barov:60"] = 36360,
    	["Vile Larva:45"] = 1318,
    	["Golemagg the Incinerator:-1"] = 823138,
    	["Celebras the Cursed:49"] = 15696,
    	["Scholomance Adept:58"] = 6812,
    	["Atal'ai Skeleton:47"] = 2038,
    	["Desert Rumbler:56"] = 3573,
    	["Azure Templar:60"] = 8986,
    	["Loro:51"] = 7087,
    	["Spawn of Hakkar:51"] = 7554,
    	["Twilight Overlord:60"] = 3443,
    	["Rock Stalker:58"] = 3972,
    	["Spawn of Fankriss:63"] = 32245,
    	["Spectral Tutor:59"] = 7177,
    	["Onyxian Whelp:57"] = 2560,
    	["Firelord:61"] = 94576,
    	["Onyxia:-1"] = 1063257,
    	["Freezing Ghoul:56"] = 3665,
    	["Qiraji Brainwasher:61"] = 78549,
    	["Deathknight Cavalier:61"] = 111440,
    	["Giant Claw Tentacle:60"] = 91053,
    	["Noxious Plaguebat:54"] = 3356,
    	["Putrid Gargoyle:55"] = 3542,
    	["Heavy War Golem:47"] = 2463,
    	["Anubisath Swarmguard:62"] = 6144,
    	["Hive'Ashi Sandstalker:59"] = 8443,
    	["Vyral the Vile:61"] = 3381,
    	["Greater Lava Spider:49"] = 2887,
    	["Stitched Horror:57"] = 3730,
    	["Torn Screamer:54"] = 3264,
    	["Stitched Horror:58"] = 3857,
    	["Death Lord:61"] = 114261,
    	["Magmadar:-1"] = 826307,
    	["Baron Geddon:-1"] = 584766,
    	["Rotting Ghoul:55"] = 3439,
    	["Hive'Zora Hive Sister:59"] = 11463,
    	["Risen Protector:58"] = 6879,
    	["Corrupt Force of Nature:44"] = 1667,
    	["Creeping Sludge:46"] = 6575,
    	["Scholomance Necrolyte:58"] = 6780,
    	["Hive'Regal Burrower:59"] = 8839,
    	["Deep Borer:48"] = 2246,
    	["Bloodseeker Bat:60"] = 5412,
    	["Venom Stalker:61"] = 94599,
    	["Gorishi Worker:51"] = 3077,
    	["Primal Ooze:50"] = 3162,
    	["Plagued Hatchling:57"] = 3820,
    	["Slime Maggot:45"] = 1466,
    	["Skeletal Acolyte:56"] = 2907,
    	["Lava Annihilator:61"] = 93933,
    	["Putrid Gargoyle:54"] = 3410,
    	["Plagued Champion:61"] = 32937,
    	["Flamewaker Elite:62"] = 101205,
    	["Necrofiend:58"] = 8697,
    	["Necro Knight:61"] = 37936,
    	["Unliving Atal'ai:49"] = 6475,
    	["Spectral Tutor:60"] = 7291,
    	["Small Crag Boar:3"] = 71,
    	["Deeprot Tangler:45"] = 5327,
    	["Grethok the Controller:62"] = 63062,
    	["Mummified Atal'ai:47"] = 6405,
    	["Dust Stormer:57"] = 3764,
    	["Lava Reaver:62"] = 80887,
    	["Twilight Geolord:60"] = 4131,
    	["Jabbering Ghoul:54"] = 3706,
    	["Winter Wolf:7"] = 130,
    	["Hukku's Succubus:52"] = 1553,
    	["Onyxian Whelp:56"] = 2668,
    	["Corruptor:43"] = 1000,
    	["Zulian Panther:60"] = 21197,
    	["Un'Goro Stomper:52"] = 3249,
    	["Large Crag Boar:6"] = 120,
    	["Gorishi Stinger:52"] = 3262,
    	["Barbed Lasher:44"] = 8097,
    	["Noxxious Essence:45"] = 4210,
    	["Dread Weaver:58"] = 2679,
    	["Bony Construct:61"] = 36547,
    	["Obsidian Nullifier:61"] = 125860,
    	["Twilight Flamereaver:60"] = 4176,
    	["Gurubashi Champion:61"] = 31452,
    	["Skeletal Sorcerer:51"] = 2985,
    	["Risen Guard:59"] = 9173,
    	["Shade of Jin'do:-1"] = 1574,
    	["Gorishi Tunneler:52"] = 3414,
    	["Atal'ai Corpse Eater:50"] = 7161,
    	["Crimson Templar:60"] = 8308,
    	["Torn Screamer:53"] = 3470,
    	["Baron Kazum:-1"] = 410958,
    	["Desert Rumbler:58"] = 3867,
    	["Rockjaw Trogg:1"] = 42,
    	["Shade of Naxxramas:61"] = 38879,
    	["Plague Slime:61"] = 140933,
    	["Gurubashi Axe Thrower:60"] = 21852,
    	["Razzashi Broodwidow:61"] = 31808,
    	["Razzashi Skitterer:57"] = 4089,
    	["Glasshide Basilisk:43"] = 2046,
    	["Hive'Zora Waywatcher:59"] = 8804,
    	["Primordial Behemoth:48"] = 13424,
    	["Razzashi Serpent:60"] = 15198,
    	["Onyxian Warder:61"] = 78653,
    	["Dark Touched Warrior:61"] = 23945,
    	["Scholomance Necrolyte:57"] = 7517,
    	["Scarshield Sentry:53"] = 7421,
    	["Ragged Young Wolf:1"] = 42,
    	["Dredge Crusher:57"] = 3732,
    	["Instructor Razuvious:-1"] = 1998312,
    	["Crimson Monk:58"] = 8678,
    	["Naxxramas Follower:61"] = 95852,
    	["Inferno Elemental:47"] = 2463,
    	["Sulfuron Harbinger:-1"] = 439182,
    	["Twilight Avenger:58"] = 3878,
    	["Hooktooth Frenzy:60"] = 8862,
    	["Razzashi Raptor:60"] = 15185,
    	["Lava Reaver:63"] = 83217,
    	["Scholomance Necromancer:58"] = 6824,
    	["Death Touched Warrior:61"] = 23977,
    	["Atal'ai Mistress:60"] = 15360,
    	["Vekniss Stinger:62"] = 64469,
    	["Subterranean Diemetradon:46"] = 6676,
    	["Death Singer:59"] = 3980,
    	["Witherbark Speaker:61"] = 17384,
    	["Flamewaker Priest:62"] = 90472,
    	["Death Talon Captain:62"] = 241535,
    	["Lava Elemental:62"] = 80694,
    	["Scholomance Handler:60"] = 7000,
    	["Spectral Tutor:58"] = 6894,
    	["Gorishi Reaver:53"] = 3815,
    	["Zulian Tiger:60"] = 9111,
    	["Hive'Zora Tunneler:59"] = 8991,
    	["Vekniss Wasp:60"] = 33250,
    	["Gurubashi Berserker:62"] = 48615,
    	["Vekniss Hive Crawler:62"] = 98354,
    	["Razorlash:48"] = 14563,
    	["Giant Eye Tentacle:60"] = 36441,
    	["Zolo:51"] = 9736,
    	["Death Talon Wyrmkin:61"] = 87213,
    	["Cannibal Ghoul:54"] = 3471,
    	["Plagued Hatchling:59"] = 4049,
    	["Firewalker:61"] = 78491,
    	["Death Talon Seether:62"] = 113482,
    	["Blackwing Legionnaire:60"] = 9394,
    	["Ancient Core Hound:62"] = 113285,
    	["Winter Wolf:8"] = 154,
    	["Zulian Stalker:61"] = 22178,
    	["Cauldron Lord Bilemaw:53"] = 3238,
    	["Flamewaker Healer:60"] = 97523,
    	["Scholomance Adept:59"] = 7043,
    	["Flamewaker Protector:62"] = 86208,
    	["Skeletal Flayer:50"] = 3059,
    	["Carrion Spinner:61"] = 54840,
    	["Lava Elemental:61"] = 78282,
    	["Stitches:35"] = 12196,
    	["Noxxious Essence:46"] = 3730,
    	["Venomhide Ravasaur:51"] = 3048,
    	["Rock Stalker:57"] = 3724,
    	["Hakkari Shadowcaster:56"] = 25587,
    	["Searing Ghoul:55"] = 2400,
    	["Razzashi Venombrood:55"] = 13627,
    	["The Prophet Skeram:-1"] = 432503,
    	["Spawn of Mar'li:60"] = 6181,
    	["Un'Goro Gorilla:51"] = 3325,
    	["Anubisath Sentinel:61"] = 109545,
    	["Twilight Geolord:59"] = 4064,
    	["Murk Worm:47"] = 6083,
    	["Devilsaur:55"] = 9700,
    	["Infectious Skitterer:61"] = 16860,
    	["Hive'Regal Spitfire:60"] = 9578,
    	["Hive'Ashi Swarmer:58"] = 9144,
    	["Gahz'ranka:-1"] = 332471,
    	["Skeletal Guardian:55"] = 1733,
    	["Young Diemetradon:50"] = 2934,
    	["Twilight Master:60"] = 3280,
    	["Theradrim Guardian:48"] = 6017,
    	["Ghostly Marauder:41"] = 3476,
    	["Murk Spitter:46"] = 6267,
    	["Putridus Shadowstalker:43"] = 4981,
    	["Princess Huhuran:-1"] = 993790,
    	["Hive'Ashi Defender:59"] = 8617,
    	["Scorching Elemental:54"] = 2653,
    	["Hukku's Voidwalker:52"] = 2771,
    	["Murk Worm:48"] = 6413,
    	["Ambershard Crusher:41"] = 5181,
    	["Ziggurat Protector:58"] = 17162,
    	["Vilebranch Speaker:61"] = 22293,
    	["Risen Lackey:56"] = 275,
    	["Doom Touched Warrior:61"] = 24923,
    	["Mijan:52"] = 12170,
    	["Corrupted Blue Whelp:60"] = 4568,
    	["Risen Deathknight:61"] = 24218,
    	["Deathknight Understudy:60"] = 93140,
    	["Deep Borer:46"] = 2715,
    	["Death Singer:58"] = 3866,
    	["Hive'Zora Reaver:60"] = 9254,
    	["Cloned Ooze:51"] = 3079,
    	["Plagued Hatchling:58"] = 3861,
    	["Corrupted Bronze Whelp:60"] = 4452,
    	["Deep Lurker:47"] = 6416,
    	["High Priestess Mar'li:-1"] = 324089,
    	["Gorishi Worker:52"] = 2050,
    	["Deathknight Captain:61"] = 95048,
    	["Death Talon Hatcher:61"] = 86878,
    	["Scourge Warder:55"] = 2843,
    	["Dread Creeper:61"] = 48346,
    	["Hive'Zora Reaver:59"] = 9755,
    	["Hive'Regal Hive Lord:59"] = 12154,
    	["Large Crag Boar:7"] = 137,
    	["Vekniss Guardian:61"] = 62992,
    	["Hive'Regal Hive Lord:61"] = 13142,
    	["Hive'Zora Wasp:58"] = 3860,
    	["Constrictor Vine:46"] = 6069,
    	["Hive'Zora Hive Sister:60"] = 9113,
    	["Ohgan:-1"] = 89067,
    	["Creeping Sludge:45"] = 6281,
    	["Subterranean Diemetradon:47"] = 6195,
    	["Ambereye Basilisk:40"] = 4640,
    	["Theradrim Shardling:46"] = 1799,
    	["Celebrian Dryad:45"] = 4634,
    	["Stonelash Flayer:57"] = 3738,
    	["Necrofiend:60"] = 9126,
    	["Diseased Flayer:58"] = 4008,
    	["Crimson Defender:59"] = 7075,
    	["Razzashi Skitterer:52"] = 4150,
    	["Vile Larva:47"] = 1499,
    	["Hive'Ashi Stinger:57"] = 8610,
    	["Greater Lava Spider:48"] = 2561,
    	["Frenzied Pterrordax:53"] = 3552,
    	["Gorishi Wasp:52"] = 3092,
    	["Dredge Striker:55"] = 3139,
    	["Anubisath Warder:63"] = 300010,
    	["Crimson Gallant:59"] = 6956,
    	["Scholomance Dark Summoner:58"] = 7370,
    	["Atal'ai Warrior:48"] = 6401,
    	["Azuregos:-1"] = 883507,
    	["Vekniss Warrior:61"] = 49493,
    	["Cursed Mage:55"] = 2341,
    	["Putridus Satyr:43"] = 5079,
    	["Twilight Prophet:60"] = 7357,
    	["Molten Giant:62"] = 129138,
    	["Carrion Lurker:52"] = 3514,
    	["Noxious Slime:47"] = 5403,
    	["High Priestess Jeklik:-1"] = 345995,
    	["Qiraji Mindslayer:61"] = 124626,
    	["Constrictor Vine:45"] = 5684,
    	["Hakkar:-1"] = 693400,
    	["Putridus Trickster:45"] = 6100,
    	["The Duke of Shards:62"] = 60056,
    	["Corrupted Red Whelp:60"] = 4540,
    	["Crypt Walker:55"] = 3508,
    	["Occulus:50"] = 6636,
    	["Hive'Regal Spitfire:59"] = 9444,
    	["Vekniss Hatchling:60"] = 5533,
    	["Putridus Satyr:44"] = 5853,
    	["Hive'Ashi Defender:58"] = 9244,
    	["Putridus Shadowstalker:42"] = 5008,
    	["Firewalker:62"] = 80686,
    	["Hakkari Witch Doctor:60"] = 24066,
    	["Magma Elemental:48"] = 2576,
    	["Cyclone Warrior:58"] = 3974,
    	["Skeletal Flayer:51"] = 3128,
    	["Hive'Zora Wasp:59"] = 4025,
    	["Eye Tentacle:60"] = 1635,
    	["Son of Flame:60"] = 15160,
    	["Blackwing Mage:60"] = 7450,
    	["Dredge Crusher:58"] = 3866,
    	["Anubisath Warrior:62"] = 38398,
    	["Hakkari Priest:60"] = 19620,
    	["High Priestess Arlokk:-1"] = 277380,
    	["Core Hound:61"] = 47377,
    	["Risen Lackey:55"] = 253,
    	["Vekniss Borer:60"] = 6999,
    	["Plagued Guardian:61"] = 17505,
    	["Slime Maggot:46"] = 1504,
    	["Gurubashi Warrior:54"] = 7868,
    	["Scarshield Quartermaster:55"] = 10293,
    	["Crimson Battle Mage:59"] = 6219,
    	["Deep Lurker:49"] = 6399,
    	["Twilight Avenger:59"] = 4009,
    	["Flesh Tentacle:60"] = 23371,
    	["Twilight Keeper Mayna:60"] = 3194,
    	["Tinkerer Gizlock:50"] = 17488,
    	["Cursed Mage:54"] = 2295,
    	["Snow Tracker Wolf:6"] = 120,
    	["Razorgore the Untamed:-1"] = 438955,
    	["Obsidian Eradicator:60"] = 171599,
    	["Scarshield Sentry:54"] = 7870,
    	["C'Thun:-1"] = 987146,
    	["Muculent Ooze:49"] = 2786,
    	["Cannibal Ghoul:55"] = 3381,
    	["Lava Surger:62"] = 96052,
    	["Crypt Slayer:58"] = 3874,
    	["Gurubashi Blood Drinker:60"] = 18952,
    	["Young Diemetradon:49"] = 2962,
    	["Hoary Templar:60"] = 11389,
    	["Noxxion:48"] = 15247,
    	["Scourge Champion:60"] = 4105,
    	["Saturated Ooze:48"] = 6099,
    	["Deathclasp:59"] = 8571,
    	["Ambereye Basilisk:41"] = 4846,
    	["Gorishi Reaver:52"] = 3640,
    	["Son of Hakkar:60"] = 15065,
    	["Vile Larva:46"] = 1598,
    	["Glutinous Ooze:53"] = 4168,
    	["Mistress Natalia Mar'alith:62"] = 26145,
    	["Fledgling Pterrordax:49"] = 2744,
    	["Hate Shrieker:57"] = 3730,
    	["Molten Destroyer:63"] = 149228,
    	["Slavering Ghoul:51"] = 3194,
    	["Anub'Rekhan:-1"] = 1623527,
    	["Un'Goro Thunderer:52"] = 3120,
    	["Skeletal Steed:61"] = 44005,
    	["Hate Shrieker:55"] = 3477,
    	["Razzashi Broodwidow:56"] = 31668,
    	["Crimson Sorcerer:58"] = 6015,
    	["Theradrim Guardian:47"] = 7116,
    	["Atal'alarion:50"] = 16639,
    	["Death Talon Flamescale:62"] = 129591,
    	["Rotgrip:50"] = 15691,
    	["Razzashi Adder:60"] = 15498,
    	["Dark Adept:59"] = 3971,
    	["Plagued Warrior:61"] = 31049,
    	["Hive'Regal Burrower:60"] = 9709,
    	["Noxious Plaguebat:56"] = 3618,
    	["Scourge Soldier:53"] = 3185,
    	["Princess Theradras:51"] = 23196,
    	["Scholomance Dark Summoner:59"] = 7968,
    	["Zulian Prowler:60"] = 2924,
    	["Saturated Ooze:47"] = 6742,
    	["Hive'Regal Slavemaker:59"] = 9325,
    	["Twilight Overlord:61"] = 3335,
    	["Twilight Stonecaller:59"] = 3240,
    	["Unliving Atal'ai:48"] = 6079,
    	["Lord Vyletongue:47"] = 16056,
    	["Hakkari Blood Priest:61"] = 12438,
    	["Deeprot Tangler:44"] = 5812,
    	["Rotting Cadaver:54"] = 3539,
    	["Spewed Larva:47"] = 7983,
    	["Razzashi Skitterer:56"] = 4029,
    	["Primordial Behemoth:49"] = 13084,
    	["Fankriss the Unyielding:-1"] = 985702,
    	["Slavering Ghoul:50"] = 3045,
    	["Earth Elemental:54"] = 2638,
    	["Noxxion's Spawn:46"] = 757,
    	["Anubisath Defender:62"] = 479314,
    	["Razzashi Skitterer:53"] = 4334,
    	["Crimson Conjuror:57"] = 5854,
    	["Infectious Ghoul:61"] = 95607,
    	["Atal'ai Witch Doctor:50"] = 5415,
    	["Atal'ai Witch Doctor:49"] = 5615,
    	["Deeprot Stomper:44"] = 6970,
    	["Crimson Gallant:60"] = 7483,
    	["Cauldron Lord Malvinious:55"] = 2461,
    	["Subterranean Diemetradon:48"] = 6364,
    	["Bloodpetal Flayer:51"] = 3312,
    	["Scourge Champion:59"] = 4025,
    	["Razzashi Skitterer:58"] = 4294,
    	["Flameguard:62"] = 80558,
    	["Firelord:62"] = 97159,
    	["Twilight Keeper Havunth:60"] = 3546,
    	["Battleguard Sartura:-1"] = 745018,
    	["Gorishi Hive Guard:54"] = 3637,
    	["Skeletal Smith:61"] = 49892,
    	["Atal'ai Warrior:49"] = 6494,
    	["Putrid Gargoyle:56"] = 3630,
    	["Lava Spawn:60"] = 15378,
    	["Hakkari Shadowcaster:57"] = 25153,
    	["Qiraji Scarab:60"] = 8004,
    	["Barbed Lasher:45"] = 9343,
    	["Shadowmage:59"] = 2774,
    	["Oozeling:40"] = 867,
    	["Garr:-1"] = 654335,
    	["Sand Skitterer:55"] = 3492,
    	["Spewed Larva:46"] = 6267,
    	["Noxious Plaguebat:55"] = 3487,
    	["Jin'do the Hexxer:-1"] = 280600,
    	["Death Talon Overseer:62"] = 114667,
    	["Cavern Shambler:47"] = 4788,
    	["Lucifron:-1"] = 317324,
    	["Snow Tracker Wolf:7"] = 136,
    	["Corpse Scarab:60"] = 6047,
    }
    MobHealth3Config = {
    	["stableMax"] = false,
    	["saveData"] = true,
    	["precision"] = 10,
    }
    MobHealthDB = {
    	["thisIsADummyTable"] = true,
    }
end

function Mazzifier:Mazzify_Recap()
    MazzleUI:CreateSet("recap.UseOneSettings", false)
    MazzleUI:CreateSet("recap.Opt.DmgOutP.value", true)
    MazzleUI:CreateSet("recap.Opt.DmgOutP.width", 32)
    MazzleUI:CreateSet("recap.Opt.DPSvsAll.value", true)
    MazzleUI:CreateSet("recap.Opt.DPSvsAll.width", 45)
    MazzleUI:CreateSet("recap.Opt.ECrits.value", true)
    MazzleUI:CreateSet("recap.Opt.ECrits.width", 45)
    MazzleUI:CreateSet("recap.Opt.ECritsAvg.value", true)
    MazzleUI:CreateSet("recap.Opt.ECritsAvg.width", 35)
    MazzleUI:CreateSet("recap.Opt.ECritsMax.value", true)
    MazzleUI:CreateSet("recap.Opt.ECritsMax.width", 35)
    MazzleUI:CreateSet("recap.Opt.EHits.value", true)
    MazzleUI:CreateSet("recap.Opt.EHits.width", 45)
    MazzleUI:CreateSet("recap.Opt.EHitsAvg.value", true)
    MazzleUI:CreateSet("recap.Opt.EHitsAvg.width", 35)
    MazzleUI:CreateSet("recap.Opt.EHitsMax.value", true)
    MazzleUI:CreateSet("recap.Opt.EHitsMax.width", 35)
    MazzleUI:CreateSet("recap.Opt.EMiss.value", true)
    MazzleUI:CreateSet("recap.Opt.EMiss.width", 50)
    MazzleUI:CreateSet("recap.Opt.EnableSync.value", true)
    MazzleUI:CreateSet("recap.Opt.Heal.value", true)
    MazzleUI:CreateSet("recap.Opt.Heal.width", 62)
    MazzleUI:CreateSet("recap.Opt.HealP.value", true)
    MazzleUI:CreateSet("recap.Opt.HealP.width", 32)
    MazzleUI:CreateSet("recap.Opt.Kills.value", true)
    MazzleUI:CreateSet("recap.Opt.Kills.width", 28)
    MazzleUI:CreateSet("recap.Opt.MaxRank.value", 10)
    MazzleUI:CreateSet("recap.Opt.MinBack.value", false)
    MazzleUI:CreateSet("recap.Opt.Over.value", true)
    MazzleUI:CreateSet("recap.Opt.Over.width", 32)
    MazzleUI:CreateSet("recap.Opt.PartyData.value", true)
    MazzleUI:CreateSet("recap.Opt.Ranks.value", true)
    MazzleUI:CreateSet("recap.Opt.Ranks.width", 20)
    MazzleUI:CreateSet("recap.Opt.RemindGroupStatus.value", false)
    MazzleUI:CreateSet("recap.Opt.State.value", "Idle")
    MazzleUI:CreateSet("recap.Opt.SyncState.value", "Ready")
end

function Mazzifier:Mazzify_TinyTip()
    TinyTipDB = {
	["Scale"] = 1,
	["Fade"] = 2,
	["LevelGuess"] = true,
	["SmoothBorder"] = true,
	["PvPRank"] = 2,
	["PvPIconAnchor1"] = "TOPLEFT",
	["ToT"] = 1,
	["RTIconAnchor1"] = "BOTTOMRIGHT",
	["MAnchor"] = "LEFT",
	["ReactionText"] = true,
	["RTIconAnchor2"] = "TOPRIGHT",
	["_v"] = 33,
	["PvPIconAnchor2"] = "TOPRIGHT",
	["PvPIcon"] = true,
	["FAnchor"] = "LEFT",
	["RTIcon"] = true,
	["KeyElite"] = true,
}

end

function Mazzifier:Mazzify_WitchHunt()
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.targetonly", true)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.combatonly", true)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.learn", true)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.icons", false)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.targetonly", true)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.mfiltered.format_cast", true)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.mfiltered.format_dispel", false)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.mfiltered.format_fade", false)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.mfiltered.format_gain", false)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.mfiltered.format_spell", false)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.mfiltered.format_totem", false)
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.sinkOptions.sink20OutputSink", "UIErrorsFrame")
    MazzleUI:CreateSet("WitchHunt3DB.profiles.Default.sinkOptions.sink20ScrollArea", "Outgoing")
end

function Mazzifier:Mazzify_DiscordUnitFrames()
    LoadAddOn("DiscordUnitFramesOptions")
    if (DUF_Settings) then
        if (not DUF_Settings.MazzleUI) then
            DUF_Options_SaveSettings("MazzleUI")
        end
        if (Mazzifier_CurrentInstallOptions.Aspect == 1) then
            Mazzifier:Setup_DUF125("MazzleUI")
            MazzleUI_Settings.Mazz3D.clickCast = true
        elseif (Mazzifier_CurrentInstallOptions.Aspect == 2) then
            Mazzifier:Setup_DUF133("MazzleUI")
            MazzleUI_Settings.Mazz3D.clickCast = true
        elseif (Mazzifier_CurrentInstallOptions.Aspect == 3) then
            Mazzifier:Setup_DUF16("MazzleUI")
            MazzleUI_Settings.Mazz3D.clickCast = false
        end
        DUF_Options_LoadSettings("MazzleUI")
        DUF_Settings["MazzleUI"].player.TextBox[10].hide = nil
        DUF_Settings["MazzleUI"].player.TextBox[6].hide = nil
        DUF_Settings["MazzleUI"].target.TextBox[7].hide = nil
        DUF_Settings["MazzleUI"].target.TextBox[10].hide = nil
    else
        Mazzifier:Print("MAZZIFIER ERROR: Discord Unit Frames not initialized.")
    end
end

function Mazzifier:Mazzify_DBM_API()
    MazzleUI:CreateSet("DBM_SavedVars.DBM.MinimapButton.Enabled", false)
    local tempArray = {
				["AggroShake"] = false,
				["AggroFlash"] = false,
				["AggroAlertInAllInstances"] = false,
				["AggroSpecialWarning"] = false,
				["AggroAlert"] = false,
				["AggroSound"] = false,
				["AggroLocalWarning"] = false,
			}
	MazzleUI:CreateSet("DBM_SavedVars.DBM.MinimapButton.CharSettings."..Mazzifier_PlayerName, tempArray)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.ShowAutoRespondInfo", false)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.HideOutgoingInfoWhisper", false)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.FillUpStatusBars", true)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.StatusBarsFlippedOver", true)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.Gui.SelfWarning_Height", 27)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.Gui.RaidWarning_Height", 27)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.SpecialWarningTextSize", 27)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.Gui.SelfWarning_PosX", 300)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.Gui.SelfWarning_PosY", 500)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.Gui.RaidWarning_PosX", 300)
    MazzleUI:CreateSet("DBM_SavedVars.DBM.Gui.RaidWarning_PosY", -390)
	MazzleUI:CreateSet("DBM.Options.MinimapButton.CharSettings."..Mazzifier_PlayerName, tempArray)
    MazzleUI:CreateSet("DBM.Options.ShowAutoRespondInfo", false)
    MazzleUI:CreateSet("DBM.Options.HideOutgoingInfoWhisper", false)
    MazzleUI:CreateSet("DBM.Options.FillUpStatusBars", true)
    MazzleUI:CreateSet("DBM.Options.StatusBarsFlippedOver", true)
    MazzleUI:CreateSet("DBM.Options.Gui.SelfWarning_Height", 27)
    MazzleUI:CreateSet("DBM.Options.Gui.RaidWarning_Height", 27)
    MazzleUI:CreateSet("DBM.Options.SpecialWarningTextSize", 27)
    MazzleUI:CreateSet("DBM.Options.Gui.SelfWarning_PosX", 300)
    MazzleUI:CreateSet("DBM.Options.Gui.SelfWarning_PosY", 500)
    MazzleUI:CreateSet("DBM.Options.Gui.RaidWarning_PosX", 300)
    MazzleUI:CreateSet("DBM.Options.Gui.RaidWarning_PosY", -390)
	
end

function Mazzifier:Mazzify_SmartBuff()
    if (not SMARTBUFF_OnLoad) then Mazzifier:Print("Cannot mazzify SmartBuff!"); return; end;
    SMARTBUFF_ResetBuffTimers()
    MazzleUI:CreateSet("SMARTBUFF_Options.ToggleAutoCombat", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.AutoSwitchTemplateInst", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.BuffTarget", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.ScrollWheel", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.ToggleSubGrpChanged", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.ToggleMsgNormal", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.CTRASync", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.AutoTimer", 10)
    MazzleUI:CreateSet("SMARTBUFF_Options.ToggleGrp", {false, false, false, false, false, false, false, false})
    MazzleUI:CreateSet("SMARTBUFF_Options.AutoSwitchTemplate", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.AntiDaze", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.RebuffTimer", 20)
    MazzleUI:CreateSet("SMARTBUFF_Options.ToggleAutoSplash", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.BuffPvP", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.OldWheelDown", "CAMERAZOOMOUT")
    MazzleUI:CreateSet("SMARTBUFF_Options.AdvGrpBuffRange", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.ShowMiniGrp", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.BlacklistTimer", 5)
    MazzleUI:CreateSet("SMARTBUFF_Options.InCombat", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.MinCharges", 3)
    MazzleUI:CreateSet("SMARTBUFF_Options.Toggle", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.HideMmButton", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.ToggleAutoSound", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.BuffInCities", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.LastTemplate", "Solo")
    MazzleUI:CreateSet("SMARTBUFF_Options.Debug", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.CompMode", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.SplashDuration", 4)
    MazzleUI:CreateSet("SMARTBUFF_Options.ToggleMsgError", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.CurrentFont", 4)
    MazzleUI:CreateSet("SMARTBUFF_Options.ToggleAuto", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.HideSAButton", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.CheckCharges", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.AdvGrpBuffCheck", true)
    MazzleUI:CreateSet("SMARTBUFF_Options.ToggleAutoChat", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.ToggleMsgWarning", false)
    MazzleUI:CreateSet("SMARTBUFF_Options.OldWheelUp", "CAMERAZOOMIN")
    MazzleUI:CreateSet("SMARTBUFF_Options.FirstStart", "v2.0h")

    local function CheckBuffAndEnable(theBuff, doGroup, inCombat, outCombat)
        if (MazzleUI:GetValue("SMARTBUFF_Buffs.Solo."..string.gsub (theBuff, " ","\32"))) then
            SMARTBUFF_Buffs.Solo[theBuff].EnableS = true
            if (doGroup) then SMARTBUFF_Buffs.Solo[theBuff].EnableG = true; end
            if (inCombat) then SMARTBUFF_Buffs.Solo[theBuff].CIn = true; MazzleUI:CreateSet("SMARTBUFF_Options.InCombat", true); end;
            if (outCombat) then SMARTBUFF_Buffs.Solo[theBuff].COut = true; end
        end
        if (MazzleUI:GetValue("SMARTBUFF_Buffs.Raid."..string.gsub (theBuff, " ","\32"))) then
            SMARTBUFF_Buffs.Raid[theBuff].EnableS = true
            if (doGroup) then SMARTBUFF_Buffs.Raid[theBuff].EnableG = true; end
            if (inCombat) then SMARTBUFF_Buffs.Raid[theBuff].CIn = true; MazzleUI:CreateSet("SMARTBUFF_Options.InCombat", true); end;
            if (outCombat) then SMARTBUFF_Buffs.Raid[theBuff].COut = true; end
        end
        if (MazzleUI:GetValue("SMARTBUFF_Buffs.Party."..string.gsub (theBuff, " ","\32"))) then
            SMARTBUFF_Buffs.Party[theBuff].EnableS = true
            if (doGroup) then SMARTBUFF_Buffs.Party[theBuff].EnableG = true; end
            if (inCombat) then SMARTBUFF_Buffs.Party[theBuff].CIn = true; MazzleUI:CreateSet("SMARTBUFF_Options.InCombat", true); end;
            if (outCombat) then SMARTBUFF_Buffs.Party[theBuff].COut = true; end
        end
    end
    if (not SMARTBUFF_Buffs.Party) then SMARTBUFF_Buffs.Party = MazzleUI:CloneTable(SMARTBUFF_Buffs.Solo); end
    if (not SMARTBUFF_Buffs.Raid) then SMARTBUFF_Buffs.Raid = MazzleUI:CloneTable(SMARTBUFF_Buffs.Solo); end
    if (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Warlock") then
        CheckBuffAndEnable(SMARTBUFF_FELARMOR)
        CheckBuffAndEnable(SMARTBUFF_DEMONARMOR)
        CheckBuffAndEnable(SMARTBUFF_DEMONSKIN)
        CheckBuffAndEnable(SMARTBUFF_SOULLINK)
        MazzleUI:CreateSet("SMARTBUFF_Options.AutoSwitchTemplateInst", false)
        MazzleUI:CreateSet("SMARTBUFF_Options.AdvGrpBuffRange", false)
        MazzleUI:CreateSet("SMARTBUFF_Options.AdvGrpBuffCheck", false)
        CheckBuffAndEnable(SMARTBUFF_SENSEDEMONS)
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Mage") then
        CheckBuffAndEnable(SMARTBUFF_AI, true)
        CheckBuffAndEnable(SMARTBUFF_ICEARMOR)
        CheckBuffAndEnable(SMARTBUFF_FROSTARMOR)
        CheckBuffAndEnable(SMARTBUFF_MAGEARMOR)
        CheckBuffAndEnable(SMARTBUFF_MOLTENARMOR)
        CheckBuffAndEnable(SMARTBUFF_ICEBARRIER,false, true, false)
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Paladin") then
        CheckBuffAndEnable(SMARTBUFF_BOM, true)
        CheckBuffAndEnable(SMARTBUFF_BOK, true)
        CheckBuffAndEnable(SMARTBUFF_SENSEUNDEAD, true)
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Priest") then
        CheckBuffAndEnable(SMARTBUFF_PWF, true)
        CheckBuffAndEnable(SMARTBUFF_INNERFIRE)
        CheckBuffAndEnable(SMARTBUFF_DS, true)
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Warrior") then
        CheckBuffAndEnable(SMARTBUFF_BATTLESHOUT, false, true, false)
        MazzleUI:CreateSet("SMARTBUFF_Options.AutoSwitchTemplateInst", false)
        MazzleUI:CreateSet("SMARTBUFF_Options.AdvGrpBuffRange", false)
        MazzleUI:CreateSet("SMARTBUFF_Options.AdvGrpBuffCheck", false)
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Druid") then
        CheckBuffAndEnable(SMARTBUFF_MOTW, true)
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Rogue") then
        MazzleUI:CreateSet("SMARTBUFF_Options.AutoSwitchTemplateInst", false)
        MazzleUI:CreateSet("SMARTBUFF_Options.AdvGrpBuffRange", false)
        MazzleUI:CreateSet("SMARTBUFF_Options.AdvGrpBuffCheck", false)
    elseif (BClass:GetReverseTranslation(Mazzifier_PlayerClass) == "Hunter") then
        CheckBuffAndEnable(SMARTBUFF_TRUESHOTAURA)
    end
    CheckBuffAndEnable(SMARTBUFF_FINDMINERALS)
    CheckBuffAndEnable(SMARTBUFF_FINDHERBS)
    CheckBuffAndEnable(SMARTBUFF_FINDTREASURE)
end

function Mazzifier:Mazzify_sRaidFrames()

    if (sRaidFrames) then
        local LSRF = AceLibrary("AceLocale-2.2"):new("sRaidFrames")

        MazzleUI:CreateSet("sRaidFramesDB.profiles.Default.AggroCheck", true)
        MazzleUI:CreateSet("sRaidFramesDB.profiles.Default.BuffType", "buffsifnotdebuffed")
        MazzleUI:CreateSet("sRaidFramesDB.profiles.Default.BuffTooltipMethod", "notincombat")
        MazzleUI:CreateSet("sRaidFramesDB.profiles.Default.GroupSetup", LSRF["By group"])
        MazzleUI:CreateSet("sRaidFramesDB.profiles.Default.HealthFormat", "deficit")
        MazzleUI:CreateSet("sRaidFramesDB.profiles.Default.hidden", true)
        MazzleUI:CreateSet("sRaidFramesDB.profiles.Default.Locked", true)
        MazzleUI:CreateSet("sRaidFramesDB.profiles.Default.ShowOnlyDispellable", true)
        MazzleUI:CreateSet("sRaidFramesDB.profiles.Default.Texture", "BantoBarReverse")
        sRaidFramesDB.profiles.Default["BackgroundColor"] = {
				["a"] = 1,
				["b"] = 0,
				["g"] = 0,
				["r"] = 0,
			}
        sRaidFramesDB.profiles.Default["BorderColor"] = {
    				["b"] = 0.6784313725490196,
    				["g"] = 0.6784313725490196,
    				["r"] = 0.6784313725490196,
    			}
    
    end
end

function Mazzifier:Mazzify_XRS()
    MazzleUI:Execute("/xrs new bar")
        local tempTable = {
			["barTable"] = {
				[1] = {
					["textcolor"] = {
						["a"] = 1,
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
					},
					["c"] = {
						[1] = "Warrior",
						[2] = "Rogue",
					},
					["group"] = {
						[1] = true,
						[2] = true,
						[3] = true,
						[4] = true,
						[5] = true,
						[6] = true,
						[7] = true,
						[8] = true,
					},
					["barcolor"] = {
						["a"] = 1,
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
					},
					["w"] = "life",
					["name"] = "Melee Life",
				},
				[2] = {
					["textcolor"] = {
						["a"] = 1,
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
					},
					["c"] = {
						[1] = "Shaman",
						[2] = "Priest",
						[3] = "Druid",
					},
					["group"] = {
						[1] = true,
						[2] = true,
						[3] = true,
						[4] = true,
						[5] = true,
						[6] = true,
						[7] = true,
						[8] = true,
					},
					["barcolor"] = {
						["a"] = 1,
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
					},
					["w"] = "mana",
					["name"] = "Healing Mana",
				},
				[3] = {
					["textcolor"] = {
						["a"] = 1,
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
					},
					["name"] = "Mage Mana",
					["group"] = {
						[1] = true,
						[2] = true,
						[3] = true,
						[4] = true,
						[5] = true,
						[6] = true,
						[7] = true,
						[8] = true,
					},
					["barcolor"] = {
						["a"] = 1,
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
					},
					["w"] = "mana",
					["c"] = {
						[1] = "mage",
					},
				},
				[4] = {
					["textcolor"] = {
						["a"] = 1,
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
					},
					["c"] = {
						[1] = "Druid",
						[2] = "hunter",
						[3] = "mage",
						[4] = "paladin",
						[5] = "priest",
						[6] = "rogue",
						[7] = "warlock",
						[8] = "warrior",
					},
					["group"] = {
						[1] = true,
						[2] = true,
						[3] = true,
						[4] = true,
						[5] = true,
						[6] = true,
						[7] = true,
						[8] = true,
					},
					["barcolor"] = {
						["a"] = 1,
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
					},
					["w"] = "alive",
					["name"] = "Alive",
					["range"] = "30",
					["includeDeaths"] = false,
				},
			},
			["backgroundcolor"] = {
				["a"] = 0,
			},
			["HideBuffs"] = true,
			["Position"] = {
				["y"] = -19.84005763182233,
				["x"] = 1145.600064633204,
			},
			["titlecolor"] = {
				["r"] = 0.9098039215686274,
				["g"] = 1,
				["b"] = 0.07450980392156863,
			},
			["Texture"] = "Interface\\TargetingFrame\\UI-StatusBar",
		}
        MazzleUI:CreateSet("XRSDB.profiles.default", tempTable)
end

function Mazzifier:Mazzify_xcalc()
    MazzleUI:CreateSet("Xcalc_Settings.Binding", 1)
    MazzleUI:CreateSet("Xcalc_Settings.Minimapdisplay", 0)
end

function Mazzifier:Mazzify_XLoot()
    MazzleUI:CreateSet("XLootDB.namespaces.XLootMasterDB.profiles.Default.mlrolls", true)
    MazzleUI:CreateSet("XLootDB.namespaces.XLootMasterDB.profiles.Default.announce.group", 5)
    MazzleUI:CreateSet("XLootDB.namespaces.XLootMasterDB.profiles.Default.announce.rw", 6)
    MazzleUI:CreateSet("XLootDB.namespaces.XLootMasterDB.profiles.Default.announce.guild", 7)
    MazzleUI:CreateSet("XLootDB.namespaces.XLootGroupDB.profiles.Default.AnchorsAway.roll.anchor", false)
    MazzleUI:CreateSet("XLootDB.namespaces.XLootGroupDB.profiles.Default.AnchorsAway.roll.scale", 1.5)
    MazzleUI:CreateSet("XLootDB.namespaces.XLootGroupDB.profiles.Default.AnchorsAway.roll.threshold", 10000)
    MazzleUI:CreateSet("XLootDB.namespaces.XLootGroupDB.profiles.Default.AnchorsAway.roll.timeout", 10000)
    MazzleUI:CreateSet("XLootDB.namespaces.XLootGroupDB.profiles.Default.AnchorsAway.roll.pos", {["y"] = 621.8059543049365, ["x"] = 568.8889088821007})
    MazzleUI:CreateSet("XLootDB.namespaces.XLootGroupDB.profiles.Default.AnchorsAway.roll.lock", true)
    MazzleUI:CreateSet("XLootDB.namespaces.XLootGroupDB.profiles.Default.AnchorsAway.roll.attach", {["self"] = "TOP", ["x"] = 0, ["target"] = "BOTTOM", ["y"] = 0})
    MazzleUI:CreateSet("XLootDB.profiles.Default.qualityframe", true)
    MazzleUI:CreateSet("XLootDB.profiles.Default.qualityborder", true)
end

function Mazzifier:Mazzify_Aloft()
    Aloft:GetModule("Presets"):Set("Default")
    MazzleUI:CreateSet("AloftDB.namespaces.commentText.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("AloftDB.namespaces.healthText.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("AloftDB.namespaces.castBar.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("AloftDB.namespaces.npcTagText.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("AloftDB.namespaces.npcTagText.profiles.Default.enable", true)
    MazzleUI:CreateSet("AloftDB.namespaces.castBarTimeText.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("AloftDB.namespaces.classData.profiles.Default.save", false)
    MazzleUI:CreateSet("AloftDB.namespaces.visibility.profiles.Default.showFriendlyPets", false)
    MazzleUI:CreateSet("AloftDB.namespaces.visibility.profiles.Default.showCritters", false)
    MazzleUI:CreateSet("AloftDB.namespaces.guildData.profiles.Default.save", false)
    MazzleUI:CreateSet("AloftDB.namespaces.levelText.profiles.Default.fontSize", 9)
    MazzleUI:CreateSet("AloftDB.namespaces.levelText.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("AloftDB.namespaces.commentData.profiles.Default.save", false)
    MazzleUI:CreateSet("AloftDB.namespaces.commentData.profiles.Default.auto", false)
    MazzleUI:CreateSet("AloftDB.namespaces.highlight.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("AloftDB.namespaces.Banzai.profiles.Default.enable", true)
    MazzleUI:CreateSet("AloftDB.namespaces.manaText.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("AloftDB.namespaces.recentlyDamagedIcon.profiles.Default.enable", true)
    MazzleUI:CreateSet("AloftDB.namespaces.manaBar.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("AloftDB.namespaces.manaBar.profiles.Default.enable", true)
    MazzleUI:CreateSet("AloftDB.namespaces.nameText.profiles.Default.fontSize", 9)
    MazzleUI:CreateSet("AloftDB.namespaces.nameText.profiles.Default.shadow", true)
    MazzleUI:CreateSet("AloftDB.namespaces.nameText.profiles.Default.petOwnersName", "BRACKET")
    MazzleUI:CreateSet("AloftDB.namespaces.nameText.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("AloftDB.namespaces.nameText.profiles.Default.offsets.vertical", 10)
    MazzleUI:CreateSet("AloftDB.namespaces.nameText.profiles.Default.format", "[name][not(targetName):shortGuild:prefix(\" - \")][targetName:prefix(\" -> \")]")
    MazzleUI:CreateSet("AloftDB.namespaces.creatureTypeData.profiles.Default.save", false)
    MazzleUI:CreateSet("AloftDB.namespaces.banzai.profiles.Default.enable", true)
    MazzleUI:CreateSet("AloftDB.namespaces.polymorph.profiles.Default.enable", true)
    MazzleUI:CreateSet("AloftDB.namespaces.polymorph.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("AloftDB.namespaces.healthBar.profiles.Default.width", 100)
    MazzleUI:CreateSet("AloftDB.namespaces.healthBar.profiles.Default.alpha", 0.3)
    MazzleUI:CreateSet("AloftDB.namespaces.healthBar.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("AloftDB.namespaces.combatText.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("AloftDB.namespaces.classificationData.profiles.Default.save", false)
    MazzleUI:CreateSet("AloftDB.namespaces.spellNameText.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("AloftDB.namespaces.guildText.profiles.Default.enable", true)
    MazzleUI:CreateSet("AloftDB.namespaces.guildText.profiles.Default.format", "[shortGuild]")
    MazzleUI:CreateSet("AloftDB.namespaces.guildText.profiles.Default.font", "Calibri v1.0")
    MazzleUI:CreateSet("AloftDB.namespaces.frame.profiles.Default.backgroundAlpha", 0.41)
    MazzleUI:CreateSet("AloftDB.namespaces.frame.profiles.Default.width", 4)
    MazzleUI:CreateSet("AloftDB.namespaces.frame.profiles.Default.height", 4)
    MazzleUI:CreateSet("AloftDB.namespaces.frame.profiles.Default.backgroundAlpha", 0.26)
    MazzleUI:CreateSet("AloftFuDB.profiles.Default.showText", false)
    SetCVar("UnitNameOwn",0)
    SetCVar("UnitNameFriendlyPlayerName","1")
    SetCVar("UnitNameEnemyPlayerName","1")
    SetCVar("UnitNamePlayerGuild",1)
    SetCVar("UnitNamePlayerPVPTitle",0)
    SetCVar("UnitNameNPC",0)
    ShowNameplates(); NAMEPLATES_ON = 1; 
    ShowFriendNameplates(); FRIENDNAMEPLATES_ON = 1; 
end

function Mazzifier:Mazzify_Antagonist()
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.enabled.casts", false)
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.selfrelevant", true)
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.barscale", 1)
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.barcolor", "school")
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.showunder.cooldowns", 2)
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.texture", "BantoBarReverse")
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.growup", {[1] = true,[2] = true,[3] = true,})
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.titletext", {[1] = "",[2] = "",[3] = "",})
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.targetonly.casts", false)
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.barwidth", 185)
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.barheight", 16)
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.textsize", 12)
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.pattern.cooldowns", "$s : $n (CD)")
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.pattern.buffs", "$s : $n")
    MazzleUI:CreateSet("AntagonistDB.profiles.Default.pattern.casts", "$s : $t")

end

function Mazzifier:Mazzify_Chronometer()
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.barscale", 1)
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.bgcolor", "blue")
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.ghost", 1.5)
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.growup", true)
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.barcolor", "teal")
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.bartex", "BantoBarReverse")
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.text", "$s $t")
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.barwidth", 185)
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.barheight", 16)
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.selfbars", true)
    MazzleUI:CreateSet("ChronometerDB.profiles.Default.textsize", 11)
end

function Mazzifier:Mazzify_Omen()

end

function Mazzifier:Mazzify_Recount()

end

function Mazzifier:Mazzify_HitsMode()
	local tempTable = {
		["flt_src_includenames4"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["Shadow"] = {
			1, -- [1]
			12124331, -- [2]
		},
		["you_loot"] = {
			2, -- [1]
			16776960, -- [2]
		},
		["caps"] = {
			3, -- [1]
		},
		["oth_heal_oth"] = {
			0, -- [1]
			16776960, -- [2]
		},
		["flt_dst_spec_raidpets"] = {
			0, -- [1]
		},
		["flt_src_spec_target"] = {
			0, -- [1]
		},
		["oth_melee"] = {
			0, -- [1]
			16723759, -- [2]
		},
		["you_hot_others"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["cs_healsreceived"] = {
			0, -- [1]
			16777088, -- [2]
		},
		["flagcrits"] = {
			3, -- [1]
			16776960, -- [2]
		},
		["showoth_npc"] = {
			3, -- [1]
			16726802, -- [2]
		},
		["oth_gain"] = {
			0, -- [1]
		},
		["threshold2"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
		},
		["cs_damagegiven"] = {
			0, -- [1]
			65316, -- [2]
		},
		["vspet_drain"] = {
			2, -- [1]
			16723759, -- [2]
		},
		["oth_fall"] = {
			0, -- [1]
			16723759, -- [2]
		},
		["oth_hot_oth"] = {
			0, -- [1]
			16776960, -- [2]
		},
		["flt_dst_spec_raidtarget"] = {
			0, -- [1]
		},
		["flt_src_reac_friendly"] = {
			0, -- [1]
		},
		["enable3"] = {
			0, -- [1]
		},
		["flagenergizes"] = {
			0, -- [1]
		},
		["resize"] = {
			0, -- [1]
		},
		["you_miss"] = {
			1, -- [1]
			32768, -- [2]
		},
		["plusplus"] = {
			0, -- [1]
		},
		["flt_dst_reac_hostile"] = {
			0, -- [1]
		},
		["critoverlay"] = {
			3, -- [1]
			5523967, -- [2]
		},
		["flt_src_spec_partypets"] = {
			0, -- [1]
		},
		["pet_melee"] = {
			1, -- [1]
			65316, -- [2]
		},
		["showicons"] = {
			0, -- [1]
		},
		["flt_src_type_guardian"] = {
			0, -- [1]
		},
		["flt_src_spec_me"] = {
			0, -- [1]
		},
		["pet_nuke"] = {
			1, -- [1]
			16744576, -- [2]
		},
		["mob_dispel"] = {
			2, -- [1]
		},
		["you_heal_pet"] = {
			0, -- [1]
			16776960, -- [2]
		},
		["showyou"] = {
			2, -- [1]
			49407, -- [2]
		},
		["flt_dst_type_pet"] = {
			0, -- [1]
		},
		["flt_src_spec_mypet"] = {
			0, -- [1]
		},
		["cs_exp"] = {
			0, -- [1]
			7303167, -- [2]
		},
		["flt_src_includenames2"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["window3"] = {
			0, -- [1]
			0, -- [2]
			5, -- [3]
		},
		["mob_inter"] = {
			2, -- [1]
		},
		["you_gain_honor"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["others_hot_you"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["pet_dispel"] = {
			1, -- [1]
		},
		["oth_kill"] = {
			0, -- [1]
		},
		["flt_src_reac_hostile"] = {
			0, -- [1]
		},
		["flt_src_includenames1"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["threshold4"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
		},
		["Holy"] = {
			1, -- [1]
			16744576, -- [2]
		},
		["mob_debuff"] = {
			2, -- [1]
		},
		["flt_dst_type_npc"] = {
			0, -- [1]
		},
		["you_summon"] = {
			1, -- [1]
		},
		["window1"] = {
			0, -- [1]
			0, -- [2]
			6, -- [3]
		},
		["skill_up"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["oth_dispel"] = {
			0, -- [1]
		},
		["spam_instantkill"] = {
			2, -- [1]
		},
		["flt_dst_excludenames2"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["you_hot_yourself"] = {
			0, -- [1]
			16776960, -- [2]
		},
		["mob_gains"] = {
			2, -- [1]
		},
		["you_heal"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["flt_src_cont_player"] = {
			0, -- [1]
		},
		["skip_avoided"] = {
			0, -- [1]
		},
		["oth_energize"] = {
			0, -- [1]
			16776960, -- [2]
		},
		["mob_dot"] = {
			2, -- [1]
			16744576, -- [2]
		},
		["flt_dst_cont_npc"] = {
			0, -- [1]
		},
		["others_heal_pet"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["cs_duration"] = {
			0, -- [1]
			7303167, -- [2]
		},
		["pet_gainatk"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["mob_drain"] = {
			2, -- [1]
			16723759, -- [2]
		},
		["extval"] = {
			3, -- [1]
			11316396, -- [2]
		},
		["flt_dst_excludenames4"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["flt_src_excludenames1"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["mob_heal_itself"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["enable_flt_dst_type"] = {
			0, -- [1]
		},
		["flt_dst_type_object"] = {
			0, -- [1]
		},
		["cs_petdamagegiven"] = {
			0, -- [1]
			32768, -- [2]
		},
		["flt_dst_excludenames1"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["you_energize"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["Nature"] = {
			1, -- [1]
			65280, -- [2]
		},
		["spam_spellfailed"] = {
			0, -- [1]
		},
		["flt_src_affil_mine"] = {
			0, -- [1]
		},
		["flt_dst_spec_raid"] = {
			0, -- [1]
		},
		["petoverlay"] = {
			0, -- [1]
			16777215, -- [2]
		},
		["vspet_dispel"] = {
			2, -- [1]
		},
		["enable_flt_src_spec"] = {
			0, -- [1]
		},
		["mob_hot_itself"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["you_drain"] = {
			1, -- [1]
			65316, -- [2]
		},
		["flt_src_excludenames3"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["flt_dst_spec_partypets"] = {
			0, -- [1]
		},
		["oth_miss"] = {
			0, -- [1]
			8388608, -- [2]
		},
		["brackets"] = {
			3, -- [1]
			16777215, -- [2]
		},
		["enable"] = {
			15, -- [1]
		},
		["vspet_miss"] = {
			2, -- [1]
			8388608, -- [2]
		},
		["you_dot"] = {
			1, -- [1]
			16744576, -- [2]
		},
		["vspet_melee"] = {
			2, -- [1]
			16723759, -- [2]
		},
		["oth_summon"] = {
			0, -- [1]
		},
		["enable2"] = {
			15, -- [1]
		},
		["schoCol"] = {
			3, -- [1]
		},
		["you_craft"] = {
			2, -- [1]
		},
		["pet_energize"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["flt_src_type_object"] = {
			0, -- [1]
		},
		["flt_src_type_player"] = {
			0, -- [1]
		},
		["flt_dst_affil_raid"] = {
			0, -- [1]
		},
		["spam_unitdied"] = {
			2, -- [1]
		},
		["you_gain"] = {
			1, -- [1]
		},
		["flagpet"] = {
			0, -- [1]
		},
		["cs_sep_short"] = {
			0, -- [1]
			7303167, -- [2]
		},
		["cs_sep1"] = {
			0, -- [1]
			7303167, -- [2]
		},
		["Fire"] = {
			1, -- [1]
			16711680, -- [2]
		},
		["window2"] = {
			0, -- [1]
			0, -- [2]
			7, -- [3]
		},
		["showskill"] = {
			3, -- [1]
			13257945, -- [2]
		},
		["cs_skipentire"] = {
			0, -- [1]
		},
		["mob_nuke"] = {
			2, -- [1]
			16744576, -- [2]
		},
		["threshold3"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
		},
		["oth_debuff"] = {
			0, -- [1]
		},
		["showspelllinks"] = {
			3, -- [1]
		},
		["flt_dst_includenames3"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["pet_drain"] = {
			1, -- [1]
			65316, -- [2]
		},
		["skip_petdamage"] = {
			0, -- [1]
		},
		["flt_dst_spec_mypet"] = {
			0, -- [1]
		},
		["mob_melee"] = {
			2, -- [1]
			16723759, -- [2]
		},
		["pet_gains"] = {
			1, -- [1]
		},
		["enable1"] = {
			15, -- [1]
		},
		["flt_dst_includenames1"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["flt_src_reac_neutral"] = {
			0, -- [1]
		},
		["spam_durability"] = {
			0, -- [1]
		},
		["you_debuff"] = {
			1, -- [1]
		},
		["vspet_nuke"] = {
			2, -- [1]
			16744576, -- [2]
		},
		["you_gain_rep"] = {
			1, -- [1]
			16744576, -- [2]
		},
		["enable_flt_src_type"] = {
			0, -- [1]
		},
		["spam_spellsuccess"] = {
			0, -- [1]
		},
		["others_hot_pet"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["you_ench"] = {
			2, -- [1]
		},
		["flt_src_spec_raidtarget"] = {
			0, -- [1]
		},
		["flt_dst_affil_mine"] = {
			0, -- [1]
		},
		["flt_src_spec_tank"] = {
			0, -- [1]
		},
		["flt_src_spec_assist"] = {
			0, -- [1]
		},
		["spam_unitdestroyed"] = {
			0, -- [1]
		},
		["flt_dst_type_player"] = {
			0, -- [1]
		},
		["showrested"] = {
			1, -- [1]
		},
		["you_heal_yourself"] = {
			0, -- [1]
			16776960, -- [2]
		},
		["spam_spellstart"] = {
			0, -- [1]
		},
		["spam_dispelfailed"] = {
			0, -- [1]
		},
		["Arcane"] = {
			1, -- [1]
			11513775, -- [2]
		},
		["Frost"] = {
			1, -- [1]
			255, -- [2]
		},
		["skip_yourdamage"] = {
			0, -- [1]
		},
		["enable_flt_dst_spec"] = {
			0, -- [1]
		},
		["flt_src_spec_raid"] = {
			0, -- [1]
		},
		["mob_energize"] = {
			2, -- [1]
			16776960, -- [2]
		},
		["flt_dst_includenames4"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["mob_gainatk"] = {
			2, -- [1]
			16776960, -- [2]
		},
		["vspet_dot"] = {
			2, -- [1]
			16744576, -- [2]
		},
		["shortmode"] = {
			1, -- [1]
		},
		["showmob"] = {
			3, -- [1]
			16741485, -- [2]
		},
		["flt_dst_excludenames3"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["flt_src_spec_party"] = {
			0, -- [1]
		},
		["oth_drain"] = {
			0, -- [1]
			16723759, -- [2]
		},
		["threshold1"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
		},
		["oth_gainatk"] = {
			0, -- [1]
			16776960, -- [2]
		},
		["window4"] = {
			0, -- [1]
			0, -- [2]
			7, -- [3]
		},
		["cs_damagetaken"] = {
			0, -- [1]
			16723759, -- [2]
		},
		["you_melee"] = {
			1, -- [1]
			65316, -- [2]
		},
		["showoth_player"] = {
			3, -- [1]
			23039, -- [2]
		},
		["cs_skills"] = {
			0, -- [1]
			128, -- [2]
		},
		["mob_died"] = {
			0, -- [1]
		},
		["cs_sep2"] = {
			0, -- [1]
			7303167, -- [2]
		},
		["you_gainatk"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["flt_src_affil_raid"] = {
			0, -- [1]
		},
		["flt_src_type_pet"] = {
			0, -- [1]
		},
		["you_inter"] = {
			1, -- [1]
		},
		["cs_petdamagetaken"] = {
			0, -- [1]
			8388608, -- [2]
		},
		["pet_dot"] = {
			1, -- [1]
			16744576, -- [2]
		},
		["flagheals"] = {
			0, -- [1]
		},
		["oth_nuke"] = {
			0, -- [1]
			16744576, -- [2]
		},
		["flt_dst_affil_party"] = {
			0, -- [1]
		},
		["flt_src_spec_raidpets"] = {
			0, -- [1]
		},
		["flt_dst_spec_tank"] = {
			0, -- [1]
		},
		["enable_flt_dst_name"] = {
			0, -- [1]
		},
		["pet_miss"] = {
			1, -- [1]
			32768, -- [2]
		},
		["verbosea"] = {
			1, -- [1]
			16777215, -- [2]
		},
		["flt_src_includenames3"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["flt_src_type_npc"] = {
			0, -- [1]
		},
		["cs_sec"] = {
			0, -- [1]
			6316128, -- [2]
		},
		["others_heal_you"] = {
			1, -- [1]
			16776960, -- [2]
		},
		["enable_combatsummary"] = {
			0, -- [1]
		},
		["colorbyclass"] = {
			3, -- [1]
		},
		["flt_src_affil_outsider"] = {
			0, -- [1]
		},
		["flagexp"] = {
			15, -- [1]
		},
		["flt_dst_reac_neutral"] = {
			0, -- [1]
		},
		["flt_src_spec_focus"] = {
			0, -- [1]
		},
		["oth_dot"] = {
			0, -- [1]
			16744576, -- [2]
		},
		["flt_dst_spec_target"] = {
			0, -- [1]
		},
		["flt_src_affil_party"] = {
			0, -- [1]
		},
		["version"] = "3.7",
		["enable_flt_src_name"] = {
			0, -- [1]
		},
		["oth_inter"] = {
			0, -- [1]
		},
		["flt_dst_reac_friendly"] = {
			0, -- [1]
		},
		["you_fall"] = {
			1, -- [1]
			16723759, -- [2]
		},
		["you_nuke"] = {
			1, -- [1]
			16744576, -- [2]
		},
		["flt_src_cont_npc"] = {
			0, -- [1]
		},
		["flt_dst_spec_assist"] = {
			0, -- [1]
		},
		["mob_miss"] = {
			2, -- [1]
			8388608, -- [2]
		},
		["exp"] = {
			1, -- [1]
			7303167, -- [2]
		},
		["cs_attacksgained"] = {
			0, -- [1]
			16744576, -- [2]
		},
		["renameplayer"] = {
			2, -- [1]
		},
		["you_dispel"] = {
			1, -- [1]
		},
		["verboseb"] = {
			2, -- [1]
			16777215, -- [2]
		},
		["flt_dst_spec_me"] = {
			0, -- [1]
		},
		["cs_healsgiven"] = {
			0, -- [1]
			16776960, -- [2]
		},
		["flt_dst_affil_outsider"] = {
			0, -- [1]
		},
		["flt_src_excludenames4"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["showpet"] = {
			3, -- [1]
			6356834, -- [2]
		},
		["showoth_playerhostile"] = {
			3, -- [1]
			16726802, -- [2]
		},
		["cs_numeric"] = {
			0, -- [1]
			16777215, -- [2]
		},
		["you_hot_pet"] = {
			0, -- [1]
			16776960, -- [2]
		},
		["flt_dst_cont_player"] = {
			0, -- [1]
		},
		["verbosec"] = {
			0, -- [1]
			16777215, -- [2]
		},
		["skip_yourheals"] = {
			0, -- [1]
		},
		["flt_dst_includenames2"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["cs_damageavoided"] = {
			0, -- [1]
			8421504, -- [2]
		},
		["enable4"] = {
			15, -- [1]
		},
		["flt_dst_spec_focus"] = {
			0, -- [1]
		},
		["flt_src_excludenames2"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			"", -- [4]
		},
		["flt_dst_type_guardian"] = {
			0, -- [1]
		},
		["enable_filters"] = {
			0, -- [1]
		},
		["mob_summon"] = {
			2, -- [1]
		},
		["they_loot"] = {
			2, -- [1]
		},
		["pet_debuff"] = {
			1, -- [1]
		},
		["flt_dst_spec_party"] = {
			0, -- [1]
		},
		["cs_pethealsreceived"] = {
			0, -- [1]
			16777088, -- [2]
		},
		["cs_gained"] = {
			0, -- [1]
			16744576, -- [2]
		},
		}
    MazzleUI:CreateSet("HM_Options."..Mazzifier_PlayerName.."\32of\32"..Mazzifier_ServerName, tempTable)
end

function Mazzifier:Mazzify_Examiner()
    MazzleUI:CreateSet("Examiner_Config.AcceptAddonMsg", false)
    MazzleUI:CreateSet("Examiner_Config.ScanUnknownItems", false)
    MazzleUI:CreateSet("Examiner_Config.cacheFilter_", "")
    MazzleUI:CreateSet("Examiner_Config.ActAsUIFrame", false)
    MazzleUI:CreateSet("Examiner_Config.RatingsInPercent", false)
    MazzleUI:CreateSet("Examiner_Config.CombineAdditiveStats", true)
    MazzleUI:CreateSet("Examiner_Config.AutoInspect", true)
    MazzleUI:CreateSet("Examiner_Config.CachePvP", false)
    MazzleUI:CreateSet("Examiner_Config.cacheSort", "class")
    MazzleUI:CreateSet("Examiner_Config.scale", 1)
    MazzleUI:CreateSet("Examiner_Config.showBackground", true)
    MazzleUI:CreateSet("Examiner_Config.EnableCache", false)
    MazzleUI:CreateSet("Examiner_Config.activePage", 1)
end
