function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Skin_Lichking\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Skin_Lichking\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Skin_Lichking\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Skin_Lichking\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Skin_Lichking\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Skin_Lichking\\MazzleUICastingBarBorder",
            chatborder = "Interface\\AddOns\\MazzleUI_Skin_Lichking\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Skin_Lichking\\MazzleUIMinimapBorder",
        },
    }
end