--[[
	Bongos_Actionbar Localization
--]]

--Stance IDs
--Names of stances, should be what people call them
BONGOS_STANCES = {
	['DRUID'] = {'Bear', 'Aquatic', 'Cat', 'Travel', 'Moonkin/Tree of Life', 'Flight', 'Prowl'},
	['ROGUE'] = {'Stealth'},
	['WARRIOR'] = {'Battle', 'Defensive', 'Berserker'},
	['PRIEST'] = {'Shadowform/Redemption'},
}

--[[ UI Component names ]]--

BONGOS_ROWS = "Rows"
BONGOS_COLUMNS = "Columns"
BONGOS_SIZE = "Size"
BONGOS_ONE_BAG = "One Bag"
BONGOS_VERTICAL = "Vertical"

--[[ KeyBound ]]--

BONGOS_BINDINGS_CLEAR_HELP = "Press " .. GetBindingText('ESCAPE','KEY_') .. " to clear all hotkeys"
BONGOS_BINDINGS_NO_KEYS_BOUND = 'No Current Hotkeys'
BONGOS_BINDINGS_UNBOUND_FROM_ACTION = 'Unbound %s from %s'
BONGOS_BINDINGS_CLEARED = 'Cleared all hotkeys from %s'
BONGOS_KEY_BOUND_TO_ACTION = "Set %s to %s"
BONGOS_CANNOT_BIND_IN_COMBAT = "Sorry, you can't change key bindings while in combat."
BONGOS_BINDINGS_COMBAT_ENABLED = 'Out of combat, keys can be bound again'
BONGOS_BINDINGS_COMBAT_DISABLED = 'Entering combat, preventing keys from being bound'

--[[ Keybindings ]]--

BINDING_HEADER_BGPAGE = "Bongos Paging"
BINDING_HEADER_BQUICKPAGE = "Quick Paging"
BINDING_HEADER_BBARS = "Bongos Bar Visibility"

BINDING_NAME_BMENUBAR_TOGGLE = "Toggle the MenuBar"
BINDING_NAME_BBAGBAR_TOGGLE = "Toggle the BagBar"

--some german localization, thanks to Archiv
if GetLocale() == "deDE" then
	BINDING_HEADER_BQUICKPAGE = "Schnelles Paging"
	BINDING_HEADER_BBARS = "Bongos Bar Transparent"

	BINDING_NAME_BMENUBAR_TOGGLE = "Verstecke/Zeige die Men\195\188bar"
	BINDING_NAME_BBAGBAR_TOGGLE = "Verstecke/Zeige die Taschen Bar"
end