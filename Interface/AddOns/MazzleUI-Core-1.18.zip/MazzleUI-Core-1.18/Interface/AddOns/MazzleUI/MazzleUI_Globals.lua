-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

BINDING_HEADER_MAZZLEUI = "Mazzlefizz's MazzleUI";
BINDING_NAME_MAZZLEUICONTEXT = "Toggle Context Menu Buttons";
BINDING_NAME_MAZZLEUIQUEST = "Toggle nQuest Quest Minion";
BINDING_NAME_MAZZLEUINEXTVIEW = "Next Party/Raid View";
BINDING_NAME_MAZZLEUIVIEW1 = "View 1 - Raid Frames on Bottom";
BINDING_NAME_MAZZLEUIVIEW2 = "View 2 - Raid Frames on Top";
BINDING_NAME_MAZZLEUIVIEW3 = "View 3 - No Raid Frames";
BINDING_NAME_MAZZLEUIMT1 = "MT 1 - MT Windows on Side";
BINDING_NAME_MAZZLEUIMT2 = "MT 2 - MT Windows on Top";
BINDING_NAME_MAZZLEUIMT3 = "MT 3 - MT Windows on Top Wide";
BINDING_NAME_MAZZLEUIPARTYSHOW = "Party 1 - Show Party ";
BINDING_NAME_MAZZLEUIPARTYHIDE = "Party 2 - Hide Party";
BINDING_NAME_MAZZLEUITTELL = "Whisper Current Target";


MazzleUI_SettingsDefault = {
    debugPrint = false,
    debugLogOn = false,
    OptionsMode = "Options",
    OptionsLastTopic = 1,
    sRaidFrames = { scale = 0.8, targetAdjust = 315, groupSpacing = 0, xAnchor = 483, yAnchor = -1320, yMargin = 5},
    oRA = { width = 100, nameWidth = 52, nameIndent = 11, raidIconIndent = 0 },
    Mazz3D = { UseModels = true, randomAnims = true, eventAnims = true, adjustModels = true, debugEvents = false, debugCamera = false, debugCameraSounds = false, clickCast = true},
    HotSpots = { RaidCycle = true, KCI = true, Quest = true, Notebook = true, NeedyList = true, ItemRack = true, Compass = true, xCalc = true, ToT = true,},
    HUD = { Transparency_IC = 0.1, Transparency_OOC = 0.0, Transparency_FG_IC = 0.5, Transparency_FG_OOC = 0.0, UseHUD = true, Transparency_ToT = 1.0, 
            separation = 200, YAdjust = 0, Scale = 1, SelfFormat = 1, TargetFormat = 1, ShowRange = true},
    AutohideRezMonitor = true,
    AutoshowRezMonitor = true,
    AggroStrobe = true,
    AltClickToTrade = true,
    hideResurrectionXRSPvP = true,
    AutoRes = true,
    AutoSummon = false,
    AutoDismount = true,
    AutoOpenBags = true,
    HideQuestLog = true,
    HideKTM = true,
    HideContext = false,
    HideContextOnClick = true,
    MoveContext = true,
    manageRaidFrames = true,
    manageMTFrames = true,
    ShowRaidParty = true,
    ShowCharmIcons = true,
    FaveRaidPosition = 1,
    FaveMTPosition = 1,
    AutoSwapRaid20 = true,
    SnapToLayout = true,
    Skin = "MazzleUI_Skin_Noob123_BlackMetal",
	Performance_BlizzardSCTD = false,
    DiscordUpdate = 10,
    isManual = false,
	Performance_DiscordUpdate = 5,
	Performance_LightSCT = false,
	Performance_BigWigs = { noManual = true, manual = true, party = false, combat = true, raid = true, solo = false, pvp = false,},
	Performance_CECB = { manual = false, party = true, combat = true, raid = true, solo = true, pvp = true,},
	Performance_Discord = { canCombat = true, manual = false, party = true, combat = true, raid = false, solo = true, pvp = true,},
	Performance_Enabled = { manual = false, party = true, combat = false, raid = true, solo = true, pvp = true,},
	Performance_Gfx = { manual = false, party = true, combat = true, raid = true, solo = true, pvp = true,},
	Performance_Models = { canCombat = true, manual = false, party = true, combat = true, raid = true, solo = true, pvp = true,},
	Performance_Recap = { manual = false, party = true, combat = true, raid = true, solo = true, pvp = false,},
	Performance_SWS = { manual = false, party = true, solo = false, raid = true, combat = true, pvp = false,},
	Performance_SCT = { manual = false, party = true, combat = true, raid = true, solo = true, pvp = true,},
	Performance_SCTD = { manual = false, party = true, solo = true, raid = true, combat = true, pvp = true,},
	Performance_SpellAlert = { manual = false, party = true, solo = true, raid = true, combat = true, pvp = true,},
	Performance_HUDRange = { canCombat = true, manual = false, party = true, solo = true, raid = true, combat = true, pvp = true,},
	Performance_SpellEffects = { canCombat = true, manual = false, party = true, solo = true, raid = true, combat = true, pvp = true,},
}

MazzleUI_ArrangedButtons = { 
    [9] = "MiniMapMeetingStoneFrame",
    [8] = "SmartBuff_MiniMapButton",
    [7] = "ShardAceCount",
    [6] = "ShardAceHealth",
    [5] = "ShardAceSoul",
    [4] = "ShardAceSpell",
--    [4] = "ShardAceFire",
    [3] = "PoisonerMinimapButton",
    [2] = "MazzleUI_RecapButton", 
    [1] = "MazzleUI_EfficiencyButton",
}

unitDB = {
    ["player"] = {["petname"] = "pet",},
    ["target"] = {},
    ["party1"] = {["petname"] = "partypet1",},
    ["party2"] = {["petname"] = "partypet2",},
    ["party3"] = {["petname"] = "partypet3",},
    ["party4"] = {["petname"] = "partypet4",},
    ["partypet1"] = {},
    ["partypet2"] = {},
    ["partypet3"] = {},
    ["partypet4"] = {},
    ["pet"] = {},
}

animDB = {
    ["Death"] = { ["animNum"] = 1, ["duration"] = 2300, ["nextAnim"] = "Slain", },
    ["Slain"] = { ["animNum"] = 6, ["duration"] = nil, ["nextAnim"] = nil },
    ["Flinch"] = { ["animNum"] = 10, ["duration"] = 700, ["nextAnim"] = nil, },
    ["Flinch2"] = { ["animNum"] = 36, ["duration"] = 350, ["nextAnim"] = nil, },
    ["Wave"] = { ["animNum"] = 67, ["duration"] = 2500, ["nextAnim"] = nil, },
    ["Rude"] = { ["animNum"] = 73, ["duration"] = 2500, ["nextAnim"] = nil, },
    ["Roar"] = { ["animNum"] = 74, ["duration"] = 2500, ["nextAnim"] = nil, },
    ["Kiss"] = { ["animNum"] = 76, ["duration"] = 1400, ["nextAnim"] = nil, },
    ["Chicken"] = { ["animNum"] = 78, ["duration"] = 2800, ["nextAnim"] = nil, },
    ["Flex"] = { ["animNum"] = 82, ["duration"] = 2100, ["nextAnim"] = nil, },
}

Mazz3D_Model_Info = {
    [0] = {
    		["title"] = "Player",
    		["scale"] = {["width"] = 100,["height"] = 100,},
    		["anchor"] = {["anchorParent"] = "DUF_PlayerFrame_TextBox_8",
    			["x"] = -1, ["y"] = 5,},
    		["Character"] = {
    			["unitType"] = "player",
    			["dufparent"] = "DUF_PlayerFrame",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	},
    },	
    [1] = {
    		["title"] = "Target",
    		["scale"] = {["width"] = 120,["height"] = 120,},
    		["anchor"] = {["anchorParent"] = "DUF_TargetFrame_TextBox_6",
    			["x"] = 0,["y"] = 5,},
    		["Character"] = {
    			["unitType"] = "target",
    			["dufparent"] = "DUF_TargetFrame",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	},
    },	
    [2] = {
    		["title"] = "Party1",
    		["scale"] = {["width"] = 92,["height"] = 92,},
    		["anchor"] = {["anchorParent"] = "DUF_PartyFrame1_TextBox_10",
    			["x"] = 0,["y"] = 5,},
    		["Character"] = {
    			["unitType"] = "party1",
    			["dufparent"] = "DUF_PartyFrame1",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	},
    },	
    [3] = {
    		["title"] = "Party2",
    		["scale"] = {["width"] = 92,["height"] = 92,},
    		["anchor"] = {["anchorParent"] = "DUF_PartyFrame2_TextBox_10",
    			["x"] = 0,["y"] = 5,},
    		["Character"] = {
    			["unitType"] = "party2",
    			["dufparent"] = "DUF_PartyFrame2",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	},
    },	
    [4] = {
    		["title"] = "Party3",
    		["scale"] = {["width"] = 92,["height"] = 92,},
    		["anchor"] = {["anchorParent"] = "DUF_PartyFrame3_TextBox_10",
    			["x"] = 0,["y"] = 5,},
    		["Character"] = {
    			["unitType"] = "party3",
    			["dufparent"] = "DUF_PartyFrame3",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	},
    },	
    [5] = {
    		["title"] = "Party4",
    		["scale"] = {["width"] = 92,["height"] = 92,},
    		["anchor"] = {["anchorParent"] = "DUF_PartyFrame4_TextBox_10",
    			["x"] = 0,["y"] = 5,},
    		["Character"] = {
    			["unitType"] = "party4",
    			["dufparent"] = "DUF_PartyFrame4",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	},
    },	
    [6] = {
    		["title"] = "PartyPet1",
    		["scale"] = {["width"] = 85,["height"] = 85,},
    		["anchor"] = {["anchorParent"] = "DUF_PartyPetFrame1_ManaBar",
    			["x"] = 0,["y"] = 24,},
    		["Character"] = {
    			["unitType"] = "partypet1",
    			["dufparent"] = "DUF_PartyPetFrame1",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	},
    },	
    [7] = {
    		["title"] = "PartyPet2",
    		["scale"] = {["width"] = 85,["height"] = 85,},
    		["anchor"] = {["anchorParent"] = "DUF_PartyPetFrame2_ManaBar",
    			["x"] = 0,["y"] = 24,},
    		["Character"] = {
    			["unitType"] = "partypet2",
    			["dufparent"] = "DUF_PartyPetFrame2",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	},
    },	
    [8] = {
    		["title"] = "PartyPet3",
    		["scale"] = {["width"] = 85,["height"] = 85,},
    		["anchor"] = {["anchorParent"] = "DUF_PartyPetFrame3_ManaBar",
    			["x"] = 0,["y"] = 24,},
    		["Character"] = {
    			["unitType"] = "partypet3",
    			["dufparent"] = "DUF_PartyPetFrame3",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	},
    },	
    [9] = {
    		["title"] = "PartyPet4",
    		["scale"] = {["width"] = 85,["height"] = 85,},
    		["anchor"] = {["anchorParent"] = "DUF_PartyPetFrame4_ManaBar",
    			["x"] = 0,["y"] = 24,},
    		["Character"] = {
    			["unitType"] = "partypet4",
    			["dufparent"] = "DUF_PartyPetFrame4",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	},
    },	
    [10] = {
    		["title"] = "PlayerPet",
    		["scale"] = {["width"] = 75,["height"] = 75,},
    		["anchor"] = {["anchorParent"] = "DUF_PetFrame_TextBox_10",
    			["x"] = 0,["y"] = 6,},
    		["Character"] = {
    			["unitType"] = "pet",
    			["dufparent"] = "DUF_PetFrame",
    			["isRendered"] = false,
    			["camera"] = {
            		["scale"] = 1, ["zoom"]  = 0, ["rotation"] = 0,
            		["position"] = { ["panH"] = 0, ["panV"] = 0, },
            	},},
    		["GUI"] = {
        		["isEnabled"] = false, ["active"] = nil, 
        		["LeftButton"]   = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["RightButton"]  = {["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        		["ScrollWheel"]  = {{["NOKEY"] = nil,["ALT"]   = nil,["CTRL"]  = nil,["SHIFT"] = nil,},
        	},
    	}
    }
}

MazzleUI_DART_Constants = {  ["Health"] = 6,
                    ["Background"] = 7,
                    ["Mana"] = 8,
                    ["T_Health"] = 9,
                    ["T_Background"] = 10,
                    ["T_Mana"] = 11,}

MazzleUI_PerformanceItems = {
    "Performance_Gfx",
    "Performance_Models",
    "Performance_Recap",
    "Performance_CECB",
    "Performance_BigWigs",
    "Performance_SCT",
    "Performance_SCTD",
    "Performance_SpellAlert",
    "Performance_Discord",
    "Performance_SpellEffects",
    "Performance_HUDRange",
    "Performance_SWS",
    }

MazzleUI_Events = {
    AutoOpenBags =  {   setting = "MazzleUI_Settings.AutoOpenBags", 
                        events = {"AUCTION_HOUSE_SHOW", "BANKFRAME_OPENED", "MAIL_SHOW", "MERCHANT_SHOW", "TRADE_SHOW"}, 
                        handler = "Handle_ShowBags",
                        },
    AutoCloseBags=  {   setting = "MazzleUI_Settings.AutoOpenBags", 
                        events = {"AUCTION_HOUSE_CLOSED", "BANKFRAME_CLOSED", "MAIL_CLOSED", "MERCHANT_CLOSED", "TRADE_CLOSED"}, 
                        handler = "Handle_CloseBags",
                        },
    AutoRes =  {      setting = "MazzleUI_Settings.AutoRes", 
                        events = {"RESURRECT_REQUEST",}, 
                        handler = "Handle_AutoRes",
                        },
    AutoSummon = {    setting = "MazzleUI_Settings.AutoSummon",  
                        events = {"CONFIRM_SUMMON",}, 
                        handler = "Handle_AutoSummon",
                        },
    PVPMode = {       setting = "MazzleUI_Settings.Performance_Enabled.pvp",  
                        events = {"UNIT_FACTION",}, 
                        handler = "Handle_PVPMode",
                        },
    AutoDismount = {  setting = "MazzleUI_Settings.AutoDismount",  
                        events = {"TAXIMAP_OPENED",}, 
                        handler = "Handle_AutoDismount",
                        },
    AggroStrobe1 = {   setting = "MazzleUI_Settings.AggroStrobe",  
                        events = {"Banzai_PlayerGainedAggro",}, 
                        handler = "Handle_AggroSelfGain",
                        },
    AggroStrobe2 = {   setting = "MazzleUI_Settings.AggroStrobe",  
                        events = {"Banzai_PlayerLostAggro",}, 
                        handler = "Handle_AggroSelfLose",
                        },
    CharmButtons = {   setting = "MazzleUI_Settings.ShowCharmIcons",  
                        events = {"PARTY_LEADER_CHANGED",}, 
                        handler = "Handle_LeaderChange",
                        },
}

