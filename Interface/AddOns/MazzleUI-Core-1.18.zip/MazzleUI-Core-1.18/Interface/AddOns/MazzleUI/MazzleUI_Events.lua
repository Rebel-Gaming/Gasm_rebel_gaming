-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--
MazzleUI.EventsRegistered = {}

function MazzleUI:Register(theEvent, theFunc)
    if (not self.EventsRegistered[theEvent]) then
        self.EventsRegistered[theEvent] = true
        self:RegisterEvent(theEvent, theFunc)
    end
end

function MazzleUI:Unregister(theEvent)
    if (self.EventsRegistered[theEvent]) then
        self.EventsRegistered[theEvent] = false
        self:UnregisterEvent(theEvent)
    end
end

function Banzai_Callback(aggroGained, name)
	local playerName = UnitName("player")
	if ((aggroGained == 1) and (name == playerName)) then
		MazzleUI:TriggerEvent("Banzai_PlayerGainedAggro")
	else
		MazzleUI:TriggerEvent("Banzai_PlayerLostAggro")
	end
end

function MazzleUI:RegisterHUDEvents()
    self:Register("UNIT_HEALTH", "Handle_HealthChange") 
    self:Register("UNIT_MANA", "Handle_JuiceChange") 
    self:Register("UNIT_RAGE", "Handle_JuiceChange")
    self:Register("UNIT_ENERGY", "Handle_JuiceChange") 
    self:Register("UNIT_FOCUS", "Handle_JuiceChange") 
end

function MazzleUI:UnRegisterHUDEvents()
    if ((not MazzleUI_Settings.Mazz3D.UseModels) or (not MazzleUI_Settings.Mazz3D.eventAnims)) then
        self:Unregister("UNIT_HEALTH") 
    end
    self:Unregister("UNIT_MANA");
    self:Unregister("UNIT_RAGE");
    self:Unregister("UNIT_ENERGY");
    self:Unregister("UNIT_FOCUS")
end

function MazzleUI:RegisterBaseEvents()
    self:DebugPrint("Registering base events")
	self:Register("UNIT_MODEL_CHANGED","Handle_ModelChange");       
    self:Register("UNIT_PORTRAIT_UPDATE","Handle_ModelChange");     
    self:Register("UPDATE_SHAPESHIFT_FORMS","Handle_ModelChange");
    self:Register("UNIT_PET","Handle_PetEvent");                 
	local theFrame
	for i=0, 10, 1 do
    	theFrame = getglobal("Mazz3D_Camera"..i)
--        theFrame:SetScript("OnDragStart", MazzleUI.GUI_OnMouseDown)
--        theFrame:SetScript("OnDragStop", MazzleUI.GUI_OnMouseUp)
    end
end

function MazzleUI:UnregisterBaseEvents()
    self:DebugPrint("Unregistering base events")
	self:Unregister("UNIT_MODEL_CHANGED");       
    self:Unregister("UNIT_PORTRAIT_UPDATE");     
    self:Unregister("UNIT_PET");                 
    self:Unregister("UPDATE_SHAPESHIFT_FORMS");
	for i=0, 10, 1 do
    	theFrame = getglobal("Mazz3D_Camera"..i)
        theFrame:SetScript("OnDragStart", nil)
        theFrame:SetScript("OnDragStop", nil)
    end
end

function MazzleUI:RegisterAnimEvents()
    self:DebugPrint("Registering animation events")
	self:Register("UNIT_HEALTH","Handle_HealthChange");
end

function MazzleUI:UnregisterAnimEvents()
    self:DebugPrint("Unregistering animation events")
    if (not MazzleUI_Settings.HUD.UseHUD) then
    	self:Unregister("UNIT_HEALTH");
    end
end

function MazzleUI:RegisterAdjustEvents()
    self:DebugPrint("Registering camera control events.")
    local theFrame
	for i=0, 10, 1 do
    	theFrame = getglobal("Mazz3D_Camera"..i)
--        theFrame:SetScript("OnReceiveDrag", MazzleUI.GUI_OnMouseUp)
        theFrame:SetScript("OnMouseWheel", MazzleUI.GUI_OnMouseWheel)
        theFrame:SetScript("OnDragStart", MazzleUI.GUI_OnMouseDown)
        theFrame:SetScript("OnDragStop", MazzleUI.GUI_OnMouseUp)
    end
    Mazz3D_Camera1:EnableMouseWheel(1)
end

function MazzleUI:UnregisterAdjustEvents()
    self:DebugPrint("Unregistering camera control events")
    local theFrame
	for i=0, 10, 1 do
    	theFrame = getglobal("Mazz3D_Camera"..i)
--        theFrame:SetScript("OnReceiveDrag",nil)
        theFrame:SetScript("OnDragStart", nil)
        theFrame:SetScript("OnDragStop", nil)
        theFrame:SetScript("OnMouseWheel",nil)
    end	
    Mazz3D_Camera1:EnableMouseWheel(false)
end

function MazzleUI:RegisterEventForSetting(theEvent, theValue, theHandler)
    --self:Print("MazzleUI_RegisterEventForSetting called with ", theEvent, " ", theValue, " ", theHandler)
    if (theValue) then
        self:Register(theEvent, theHandler)
    else
        self:Unregister(theEvent)
    end
end

function MazzleUI:UpdateEventForSetting(eventType)
    if (MazzleUI_Events[eventType]) then
        local eventItem = MazzleUI_Events[eventType]
        for _,theEvent in pairs(eventItem.events) do
            self:RegisterEventForSetting(theEvent, MazzleUI:GetValue(eventItem.setting), eventItem.handler)
        end
    else
        self:Print("MAZZLEUI ERROR: Attempting to update event type for ", eventType, " which doesn't exist.")
    end
end

function MazzleUI:RegisterCharacterScripts(theCharacter)
    theCharacter:SetScript("OnShow", MazzleUI.Character_OnShow)
    theCharacter:SetScript("OnHide", MazzleUI.Character_OnHide)
end
