-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--
MazzleUI.FrameInfo_Placed = {}
MazzleUI.FrameInfo_Placed[1] = {
	["BigWigs"] = {
		["post"] = function() 
		            local aspect = MazzleUI:GetValue("Mazzifier_CurrentInstallOptions.Aspect") or MazzleUI_LastAspect or 2
		            if (aspect == 3) then
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.emphasizePosX", 752)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.emphasizePosY", 436)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Messages.profiles.Default.posx", 752)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Messages.profiles.Default.posy", 390)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.posx", 752)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.posy", 340)
                    elseif (aspect == 2) then
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.emphasizePosX", 646)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.emphasizePosY", 437)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Messages.profiles.Default.posx", 646)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Messages.profiles.Default.posy", 391)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.posx", 646)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.posy", 345)
                    else
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.emphasizePosX", 616)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.emphasizePosY", 458)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Messages.profiles.Default.posx", 616)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Messages.profiles.Default.posy", 427)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.posx", 616)
                        MazzleUI:CreateSet("BigWigsDB.namespaces.Bars.profiles.Default.posy", 395)
                    end; end,
	},
	["WitchHunt_DragButton"] = {
		["location"] = {
			["point"] = "TOP",
			["y"] = -67,
			["x"] = 0,
			["lock"] = 1,
			["frame"] = "UIParent",
			["to"] = "TOP",
			["use"] = 1,
		},
		["pre"] = function()
                            if (WitchHunt_DragButton) then 
                                if (not WitchHunt:IsActive()) then MazzleUI:Execute("/witchhunt standby"); end;
                            end;
            		end,
		["post"] = function() 
                            if (WitchHunt_DragButton) then 
                                WitchHunt_DragButton:GetScript("OnDragStop")(); 
                            end;
            		end,
	},
	["CappingFrame"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 700,
			["x"] = 3,
			["point"] = "BOTTOMLEFT",
			["frame"] = "UIParent",
			["to"] = "BOTTOMLEFT",
			["use"] = 1,
		},
	},
	["BattlefieldMinimapTab"] = {
		["pre"] = function() LoadAddOn("Blizzard_BattlefieldMinimap"); end,
		["location"] = {
			["y"] = 14,
			["x"] = -283,
			["point"] = "TOPRIGHT",
			["lock"] = 1,
			["frame"] = "UIParent",
			["to"] = "TOPRIGHT",
		},
	},
	["ChatFrame6"] = {
		["height"] = 102,
		["location"] = {
			["y"] = 21,
			["x"] = -256,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "UIParent",
			["point"] = "BOTTOMRIGHT",
		},
		["width"] = 111,
	},
	["ChatFrame1"] = {
		["height"] = 212,
		["location"] = {
			["y"] = 15,
			["x"] = 20,
			["to"] = "BOTTOMLEFT",
			["frame"] = "UIParent",
			["point"] = "BOTTOMLEFT",
		},
		["width"] = 347,
		["framelevel"] = 4,
	},
	["ChatFrame7"] = {
		["height"] = 102,
		["location"] = {
			["y"] = 21,
			["x"] = -22,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "UIParent",
			["point"] = "BOTTOMRIGHT",
		},
		["width"] = 217,
	},
	["OmnibusFrame"] = {
		["layoutCached"] = true,
		["height"] = 500,
		["location"] = {
			["y"] = 234,
			["x"] = 382,
			["to"] = "BOTTOMLEFT",
			["lock"] = 1,
			["frame"] = "UIParent",
			["point"] = "BOTTOMLEFT",
		},
		["width"] = 500,
	},
	["XRSFrame"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = -31,
			["x"] = 0,
			["point"] = "TOPRIGHT",
			["frame"] = "UIParent",
			["to"] = "TOPRIGHT",
		},
	},
	["ItemRefTooltip"] = {
		["location"] = {
			["y"] = -115.78,
			["x"] = 39,
			["to"] = "TOPLEFT",
			["lock"] = 1,
			["frame"] = "UIParent",
			["point"] = "TOPLEFT",
		},
	},
	["TicketStatusFrame"] = {
		["location"] = {
			["y"] = -27,
			["x"] = 0,
			["point"] = "TOPRIGHT",
			["frame"] = "UIParent",
			["to"] = "TOPRIGHT",
		},
	},
	["ChronometerAnchor"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 40,
			["x"] = -3,
			["point"] = "RIGHT",
			["frame"] = "HourglassFrame",
			["to"] = "LEFT",
		},
	},
	["SW_BarFrame1"] = {
		["layoutCached"] = true,
		["width"] = 260,
		["location"] = {
			["y"] = 742,
			["x"] = 1,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "UIParent",
			["point"] = "BOTTOMRIGHT",
		},
	},
	["tradeDispenserOSD"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 12,
			["x"] = 382,
			["point"] = "BOTTOMLEFT",
			["frame"] = "UIParent",
			["to"] = "BOTTOMLEFT",
		},
	},
	["AntagonistBar1"] = {
		["layoutCached"] = true,
		["pre"] = function() MazzleUI.FrameInfo_Placed[1]["AntagonistBar1"].location.y = MazzleUI.HUD.player.background:GetTop()+60; end,
		["location"] = {
			["y"] = 55,
			["x"] = 0,
			["point"] = "BOTTOM",
			["frame"] = "UIParent",
			["to"] = "BOTTOM",
		},
	},
	["AntagonistBar3"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 0,
			["x"] = 30,
			["point"] = "LEFT",
			["frame"] = "AntagonistBar2",
			["to"] = "RIGHT",
		},
	},
	["AntagonistBar2"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 40,
			["x"] = 64,
			["point"] = "LEFT",
			["frame"] = "HourglassFrame",
			["to"] = "RIGHT",
		},
	},
	["KLHTM_Frame"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = -20,
			["x"] = 0,
			["point"] = "TOPLEFT",
			["frame"] = "UIParent",
			["to"] = "TOPLEFT",
		},
	},
	["AutoBarFrame"] = {
		["post"] = function() 
                    	MazzleUI:CreateSet("AutoBar_Config."..Mazzifier_PlayerName.."\32-\32"..Mazzifier_ServerName..".display.docking", "ChatFrame7")
                    	MazzleUI:CreateSet("AutoBar_Config."..Mazzifier_PlayerName.."\32-\32"..Mazzifier_ServerName..".display.dockShiftY", -17)
                    	MazzleUI:CreateSet("AutoBar_Config."..Mazzifier_PlayerName.."\32-\32"..Mazzifier_ServerName..".display.dockShiftX", -1)
                        end,
	},
	["DBM_StatusBarTimerAnchor"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 33,
			["x"] = 129,
			["point"] = "BOTTOMLEFT",
			["frame"] = "MazzleHUD_Target_BG",
			["to"] = "BOTTOMRIGHT",
		},
	},
	["HourglassFrame"] = {
		["location"] = {
			["y"] = 356,
			["x"] = -1,
			["point"] = "BOTTOM",
			["frame"] = "UIParent",
			["to"] = "BOTTOM",
			},
		["post"] = function() if (HourglassFrame) then
                      MazzleUI:CreateSet("HourglassDB.profiles.Default.x", HourglassFrame:GetLeft())
                      MazzleUI:CreateSet("HourglassDB.profiles.Default.y", HourglassFrame:GetTop())
                   end; end,
	},
	["HourglassEmphasizeFrame"] = {
		["location"] = {
			["y"] = 100,
			["x"] = 0,
			["point"] = "BOTTOMLEFT",
			["frame"] = "HourglassFrame",
			["to"] = "TOPLEFT",
			},
		["post"] = function() if (HourglassEmphasizeFrame) then
                      MazzleUI:CreateSet("HourglassDB.profiles.Default.emphasizePosX", HourglassEmphasizeFrame:GetLeft())
                      MazzleUI:CreateSet("HourglassDB.profiles.Default.emphasizePosY", HourglassEmphasizeFrame:GetTop())
                   end; end,
	},
	["KOTJFeedButton"] = {
		["post"] = function() if (KingOfTheJungle and KOTJFeedButton) then KOTJFeedButton:SetScale(0.88); end; end,
		["location"] = {
			["y"] = 412,
			["x"] = 347,
			["point"] = "BOTTOMLEFT",
			["frame"] = "UIParent",
			["to"] = "BOTTOMLEFT",
		},
		["post"] = function() if (KingOfTheJungle and KOTJFeedButton) then
		                KingOfTheJungle.db.char.buttonScale = 0.88;
                		KingOfTheJungle.db.char.buttonPoint,_,_,KingOfTheJungle.db.char.buttonX,KingOfTheJungle.db.char.buttonY = KOTJFeedButton:GetPoint()
                   end; end,
	},
}

MazzleUI.FrameInfo_Placed[2] = {
	["DcrMUFsContainer"] = {
		["location"] = {
			["y"] = 257,
			["x"] = -335,
			["point"] = "BOTTOMRIGHT",
			["frame"] = "UIParent",
			["to"] = "BOTTOMRIGHT",
			},
		["post"] = function() if (Dcr and Dcr.MicroUnitF and Dcr.MicroUnitF.Frame) then
	                    MazzleUI:CreateSet("Dcr.profile.DebuffsFrame_x", Dcr.MicroUnitF.Frame:GetEffectiveScale() * Dcr.MicroUnitF.Frame:GetLeft());
	                    MazzleUI:CreateSet("Dcr.profile.DebuffsFrame_y", Dcr.MicroUnitF.Frame:GetEffectiveScale() * Dcr.MicroUnitF.Frame:GetTop() - UIParent:GetHeight() * UIParent:GetEffectiveScale());
                   end; end,
	},
	["DecursiveMainBar"] = {
		["location"] = {
			["y"] = 200,
			["x"] = -7,
			["point"] = "BOTTOMLEFT",
			["frame"] = "DcrMUFsContainer",
			["to"] = "TOPLEFT",
			},
		["post"] = function() if (Dcr and DecursiveMainBar) then
	                    MazzleUI:CreateSet("Dcr.profile.MainBarX", DecursiveMainBar:GetEffectiveScale() * DecursiveMainBar:GetLeft());
	                    MazzleUI:CreateSet("Dcr.profile.MainBarY", DecursiveMainBar:GetEffectiveScale() * DecursiveMainBar:GetTop() - UIParent:GetHeight() * UIParent:GetEffectiveScale());
                   end; end,
	},
	["QuartzCastBar"] = {
		["location"] = {
			["y"] = 308,
			["x"] = 9,
			["point"] = "BOTTOM",
			["frame"] = "UIParent",
			["to"] = "BOTTOM",
			},
		["post"] = function() if (QuartzCastBar) then
                      MazzleUI:CreateSet("QuartzDB.namespaces.Player.profiles.Default.x", QuartzCastBar:GetLeft())
                      MazzleUI:CreateSet("QuartzDB.namespaces.Player.profiles.Default.y", QuartzCastBar:GetBottom())
                      MazzleUI:CreateSet("QuartzDB.namespaces.Mirror.profiles.Default.mirrorx", QuartzCastBar:GetLeft())
                      MazzleUI:CreateSet("QuartzDB.namespaces.Mirror.profiles.Default.mirrory", QuartzCastBar:GetBottom()+160)
                   end; end,
	},
	["QuartzTargetBar"] = {
		["location"] = {
			["y"] = -4,
			["x"] = 0,
			["point"] = "BOTTOM",
			["frame"] = "MazzleUIToTFrame",
			["to"] = "TOP",
			},
		["post"] = function() if (QuartzCastBar) then
                      MazzleUI:CreateSet("QuartzDB.namespaces.Target.profiles.Default.x", QuartzTargetBar:GetLeft())
                      MazzleUI:CreateSet("QuartzDB.namespaces.Target.profiles.Default.y", QuartzTargetBar:GetBottom())
                   end; end,
	},
	["QuartzFocusBar"] = {
		["location"] = {
			["y"] = 17,
			["x"] = -5,
			["point"] = "BOTTOMLEFT",
			["frame"] = "DUF_FocusFrame_Buffs",
			["to"] = "BOTTOMLEFT",
			},
		["post"] = function() if (QuartzFocusBar) then
                      MazzleUI:CreateSet("QuartzDB.namespaces.Focus.profiles.Default.x", QuartzFocusBar:GetLeft())
                      MazzleUI:CreateSet("QuartzDB.namespaces.Focus.profiles.Default.y", QuartzFocusBar:GetBottom())
                      MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.focusx", QuartzDB.namespaces.Focus.profiles.Default.x + 3)
                      MazzleUI:CreateSet("QuartzDB.namespaces.Buff.profiles.Default.focusy", QuartzDB.namespaces.Focus.profiles.Default.y + 28)
                   end; end,
	},
	["CCP_CP_3"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 0,
			["x"] = -9,
			["point"] = "RIGHT",
			["frame"] = "MazzleHUD_Player_BG",
			["to"] = "LEFT",
		},
	},
	["CCP_CP_4"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 5,
			["x"] = 0,
			["point"] = "BOTTOM",
			["frame"] = "CCP_CP_3",
			["to"] = "TOP",
		},
	},
	["CCP_CP_5"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 5,
			["x"] = 0,
			["point"] = "BOTTOM",
			["frame"] = "CCP_CP_4",
			["to"] = "TOP",
		},
	},
	["CCP_CP_1"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = -5,
			["x"] = 0,
			["point"] = "TOP",
			["frame"] = "CCP_CP_2",
			["to"] = "BOTTOM",
		},
	},
	["CCP_CP_2"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = -5,
			["x"] = 0,
			["point"] = "TOP",
			["frame"] = "CCP_CP_3",
			["to"] = "BOTTOM",
		},
	},
	["Incubator"] = {
		["post"] = function() 
                        if (Incubator and Incubator.anchor) then 
                            Incubator.anchor:ClearAllPoints()
                            Incubator.anchor:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", 27, 700)
                            Incubator:SavePosition();
                        end
		            end,
	},
	["SmartBuff_KeyButton"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 0,
			["x"] = 0,
			["point"] = "BOTTOMLEFT",
			["frame"] = "DUF_PlayerFrame_TextBox_1",
			["to"] = "TOPLEFT",
		},
	},
	["SmartBuffSplashFrame"] = {
		["location"] = {
			["y"] = -2,
			["x"] = 0,
			["point"] = "TOPLEFT",
			["frame"] = "SmartBuff_KeyButton",
			["to"] = "TOPRIGHT",
		},
		["post"] = function() if (SmartBuffSplashFrame) then
                        MazzleUI:CreateSet("SMARTBUFF_Options.SplashY",  SmartBuffSplashFrame:GetTop()-1200)
                        MazzleUI:CreateSet("SMARTBUFF_Options.SplashX",  SmartBuffSplashFrame:GetLeft())
                   end; end,
	},
	["AnchorsAway_roll_Anchor"] = {
		["pre"] = function() if (AnchorsAway_roll_Anchor) then MazzleUI:Execute("/xloot group scale 1.5"); end; end,
		["location"] = {
			["y"] = -32,
			["x"] = 0,
			["point"] = "TOP",
			["frame"] = "UIParent",
			["to"] = "TOP",
		},
		["post"] = function() if (AnchorsAway_roll_Anchor) then
                        MazzleUI:CreateSet("XLootDB.namespaces.XLootGroupDB.profiles.Default.AnchorsAway.roll.pos", 
                                            {["y"] = AnchorsAway_roll_Anchor:GetTop(), 
                                             ["x"] = AnchorsAway_roll_Anchor:GetLeft()})
                   end; end,
	},
	["StatusWindowWindow5"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 0,
			["x"] = 0,
			["to"] = "BOTTOM",
			["frame"] = "UIParent",
			["point"] = "BOTTOM",
		},
	},
	["StatusWindowWindow1"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 0,
			["x"] = 21,
			["point"] = "RIGHT",
			["frame"] = "StatusWindowWindow4",
			["to"] = "LEFT",
		},
	},
	["StatusWindowWindow3"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 246,
			["x"] = 6,
			["to"] = "BOTTOMLEFT",
			["frame"] = "UIParent",
			["point"] = "BOTTOMLEFT",
		},
	},
	["StatusWindowWindow2"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = 169,
			["x"] = 0,
			["point"] = "BOTTOMRIGHT",
			["frame"] = "UIParent",
			["to"] = "BOTTOMRIGHT",
		},
	},
	["StatusWindowWindow4"] = {
		["pre"] = function() if (StatusWindow) then StatusWindow:InitWindows(); end; end,
		["layoutCached"] = true,
		["location"] = {
			["y"] = 186,
			["x"] = -239,
			["to"] = "BOTTOMRIGHT",
			["frame"] = "UIParent",
			["point"] = "BOTTOMRIGHT",
		},
	},
	["ItemRack_InvFrame"] = {
		["location"] = {
			["y"] = 275,
			["x"] = 7,
			["point"] = "BOTTOMRIGHT",
			["frame"] = "UIParent",
			["to"] = "BOTTOMRIGHT",
		},
		["post"] = function() if (ItemRack_Users and ItemRack_InvFrame) then
                		ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName].XPos = ItemRack_InvFrame:GetLeft();
                		ItemRack_Users[Mazzifier_PlayerName.." of "..Mazzifier_ServerName].YPos = ItemRack_InvFrame:GetTop();
                   end; end,
	},
	["TrinketMenu_MainFrame"] = {
		["location"] = {
			["y"] = 7,
			["x"] = -2,
			["to"] = "TOPLEFT",
			["lock"] = 1,
			["frame"] = "ChatFrame6",
			["point"] = "BOTTOMLEFT",
		},
		["pre"] = function() if (TrinketMenu and TrinketMenu_MainFrame) then
		                     TrinketMenu_MainFrame:Show()
		                     TrinketMenu.FrameToScale = TrinketMenu_MainFrame;
			                 TrinketMenu.ScaleFrame(0.88);
			      end; end,
		["post"] = function() if (TrinketMenu and TrinketMenu_MainFrame) then
		                      MazzleUI:CreateSet("TrinketMenuPerOptions.XPos", TrinketMenu_MainFrame:GetLeft());
		                      MazzleUI:CreateSet("TrinketMenuPerOptions.YPos", TrinketMenu_MainFrame:GetTop());
		                      MazzleUI:CreateSet("TrinketMenuPerOptions.MainScale", 0.88);
			      end; end,
	},
	["RecapFrame"] = {
		["pre"] = function() if (RecapFrame) then RecapFrame_Show(); end; end,
		["post"] = function() if (RecapFrame) then Recap_CheckWindowBounds(); end; end,
		["location"] = {
			["y"] = -20,
			["x"] = -135,
			["point"] = "TOPRIGHT",
			["frame"] = "UIParent",
			["to"] = "TOPRIGHT",
		},
	},
	["oRAResurrectionFrame"] = {
		["pre"] = function() if (oRAOResurrection) then if (not oRAOResurrection.resframe) then oRAOResurrection:SetupFrames(); end; oRAOResurrection:ToggleView(); end; end,
		["post"] = function() if (oRAOResurrection and oRAOResurrection.resframe) then oRAOResurrection:SavePosition(); oRAOResurrection:ToggleView(); end; end,
		["location"] = {
			["y"] = -24,
			["x"] = 24,
			["point"] = "TOPLEFT",
			["frame"] = "UIParent",
			["to"] = "TOPLEFT",
		},
	},
	["SimpleDruidBar_DisplayBar"] = {
		["layoutCached"] = true,
		["location"] = {
			["y"] = -28,
			["x"] = 1,
			["point"] = "BOTTOMRIGHT",
			["frame"] = "DUF_PlayerFrame",
			["to"] = "BOTTOMRIGHT",
		},
	},
}