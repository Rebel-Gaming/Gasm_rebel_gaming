-- Copyright ? 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

MazzleUI = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0", "AceDB-2.0", "AceEvent-2.0", "Metrognome-2.0", "AceHook-2.1")
local L = AceLibrary("AceLocale-2.2"):new("MazzleUI")
MazzleUI.ContextMenu =  AceLibrary("ContextMenu-1.0")

Mazzifier_Version = 1.1
local MazzleUI_SwitchBackToSide = false

function MazzleUI:OnInitialize()
    
	local mazzifycmd = {
		type = 'execute',
        desc = "Open the Mazzifier",
        func = function() self:LoadMazzifier(true); end
	}
	self:RegisterChatCommand({"/mazzify"}, mazzifycmd)

	MazzleUI_MouseClick:SetModelScale(0.5);
	MazzleUI_MouseClick:SetPosition(0, 0, 0.076875);
	MazzleUI_MouseClick:SetRotation(0.055);
    self:RegisterEvent("PLAYER_LOGIN", "Handle_PlayerLogin");

end

function MazzleUI:OnEnable()

    if (InCombatLockdown()) then
        self:ScheduleLeaveCombatAction(self.OnEnable, self)
        return
    end

    self:InitSettings()
    MazzleUI_DebugLog = {}
    MazzleUI_LastRaidView = MazzleUI_Settings.RaidLayout40
    
    -- Initialize efficiency modes
    MazzleUI_Status = {}
    MazzleUI_Status.inRaid40 = false
    MazzleUI_Status.inRaid20 = false
    MazzleUI_Status.inParty = false
    MazzleUI_Status.solo = false
    MazzleUI_Settings.isManual = false
    MazzleUI_Status.inPvP = UnitIsPVP("player")
    MazzleUI_Status.currentEfficiencyMode = "solo"
    MazzleUI_Status.currentEfficiencySettings = {}
    
    MazzleUI_Status.PlayerIsInCombat = false
    MazzleUI_Status.PlayerIsRegenOn = false
            
    for _,performanceItem in pairs(MazzleUI_PerformanceItems) do
        MazzleUI_Status.currentEfficiencySettings[performanceItem] = true;
    end

    if (Mazzifier_LastInstalledVersion and (Mazzifier_LastInstalledVersion > 0) and self:LoadSkin(MazzleUI_Settings.Skin)) then
        if (not MazzleUI_LastAspect) then
            MazzleUI_LastAspect = self:GetAspect()
        end
        
        self:CreateViewport(147)
        self:CreatePanel(MazzleUI_LastAspect)
        self:Frames_HideUnnecessary()
        self:Frames_ConfigureMinimap()
        self:CreateHotSpots()
        self:CreateHUD()
        self:CreateToTFrame()
        self:CreateCharmButtons()
        self:CreateContextMenu()
        self:CreateTargetButtons()
        self:ModelInit()    
        self:ScheduleEvent(self.Delayed_Initialize, 2, self)
        self:ScheduleEvent(self.Delayed_HideQuests, 3, self)
        self:ScheduleEvent(self.Delayed_HideKTM, 3, self)
        self:InitHUD()
        self:InitButtons()
        self:InitBags()
        self:UnregisterMetro("MazzleUITargetUpdate")
    	self:RegisterMetro("MazzleUITargetUpdate", MazzleUI.CheckTargetRange, 0.3, MazzleUI)
        
        self:Register("PARTY_MEMBERS_CHANGED", "Handle_PartyChange");
        self:Register("RAID_ROSTER_UPDATE", "Handle_GroupChanges");
        self:Register("PLAYER_ENTERING_WORLD", "Handle_Zoning");
        self:Register("PLAYER_TARGET_CHANGED", "Handle_TargetChange");
        self:Register("PLAYER_ENTER_COMBAT", "Handle_CombatStatus");
        self:Register("PLAYER_LEAVE_COMBAT", "Handle_CombatStatus");
        self:Register("PLAYER_REGEN_DISABLED", "Handle_CombatStatus");
        self:Register("PLAYER_REGEN_ENABLED", "Handle_CombatStatus");
        self:Register("UPDATE_WORLD_STATES", "Handle_MovingCaptureBar");

        MazzleUI:HookContainerClicking(MazzleUI_Settings.AltClickToTrade)
        
        for _,eventItem in pairs(MazzleUI_Events) do
            if (MazzleUI:GetValue(eventItem.setting)) then
                for _,theEvent in pairs(eventItem.events) do
                    self:RegisterEventForSetting(theEvent, true, eventItem.handler)
                end
            end
        end


        MazzleUI:Frames_ConfigureFrameList(MazzleUI.FrameInfo_Login[1])
        MazzleUI:CheckUserPlaced()
        
        local Banzai = AceLibrary("LibBanzai-2.0")
        Banzai:RegisterCallback(Banzai_Callback)
                        
        FCF_SelectDockFrame(ChatFrame1)
        DisableAddOn("!!Warmup")
        DisableAddOn("SimpleActionSets")
        
    end
end

function MazzleUI:HookContainerClicking(turnOn)
    if (turnOn) then
        if (not self:IsHooked("ContainerFrameItemButton_OnModifiedClick")) then
            self:Hook("ContainerFrameItemButton_OnModifiedClick", "HandleContainerModifiedClick", true)
        end
    else
        if (self:IsHooked("ContainerFrameItemButton_OnModifiedClick")) then
            self:Unhook("ContainerFrameItemButton_OnModifiedClick")
        end
    end
end

function MazzleUI:ZoomIn()
	if Minimap:GetZoom() == 5 then return end
	Minimap:SetZoom(Minimap:GetZoom() + 1)
end

function MazzleUI:ZoomOut()
	if Minimap:GetZoom() == 0 then return end
	Minimap:SetZoom(Minimap:GetZoom() - 1)
end

function MazzleUI:Wheel(s)
	if s > 0 then self:ZoomIn() return end
	self:ZoomOut()
end

function MazzleUI:LoadMazzifier(shouldToggle)
    if (not InCombatLockdown()) then
        if IsAddOnLoaded("Mazzifier") then
            if (shouldToggle) then shouldToggle = Mazzifier_Frame:IsVisible(); end
            if (shouldToggle) then
                --Mazzifier_Frame:Hide()
            else
                Mazzifier:Show();
            end
        else
            LoadAddOn("Mazzifier")
            Mazzifier:Show();
        end
    end
end

function MazzleUI:Delayed_Initialize(numCall)
    numCall = numCall or 1
    if (DUF_INITIALIZED) then 

        if (BActionSets and not BActionSets.g.showGrid) then BActionSets_SetShowGrid(1); BActionSets_SetShowGrid(nil); end;
        if (Warmup and (not Mazzifier_Frame)) then MazzleUI:Execute("/warmup"); end

        MazzleUI:Frames_HideUnnecessary_Delayed()
        MazzleUI:Handle_GroupChanges()
        MazzleUI:Frames_ConfigureFrameList(MazzleUI.FrameInfo_Login[2])
        MazzleUI:LinkTargetCave()
        MazzleUI:LinkPlaceCharmButtons()

        local lastFrameName = "MazzleUI_OptionsButton"
        local theButton
        local theButtonFrame
        for i=1, #(MazzleUI_ArrangedButtons), 1 do
            theButton = MazzleUI_ArrangedButtons[i]
            theButtonFrame = getglobal(theButton)
            if (theButtonFrame) then
                MazzleUI.FrameInfo_Minimap[theButton].location.frame = lastFrameName
                lastFrameName = theButton
            end
        end
        MazzleUI:Frames_ConfigureFrameList(MazzleUI.FrameInfo_Minimap)
    elseif (numCall < 20) then
        MazzleUI:ScheduleEvent(MazzleUI.Delayed_Initialize, 1, self, (numCall + 1))
    else
        MazzleUI:Print("Warning! Warning! Could not finish UI initialization.  Make sure DUF has not been disabled.  The world is ending!")
    end
end

function MazzleUI:Delayed_HideQuests(numCall)
    numCall = numCall or 1
    if (MazzleUI_Settings.HideQuestLog and IsAddOnLoaded("nQuestLog")) then
        if (nQuestLogFrame and nQuestLogFrame:IsVisible()) then 
            self:nQuestToggle("LeftButton");
        elseif (numCall < 5) then
            MazzleUI:ScheduleEvent(MazzleUI.Delayed_HideQuests, 1, self, (numCall + 1))
        end
    end
end

function MazzleUI:Delayed_HideKTM(numCall)
    numCall = numCall or 1
    if (MazzleUI_Settings.HideKTM and IsAddOnLoaded("KLHThreatMeter")) then 
        if (klhtm and klhtm.raidtable) then
        	local g=klhtm.raidtable.instances[1].gui
    		if g:IsShown() then g:Hide() end
        elseif (numCall < 5) then
            MazzleUI:ScheduleEvent(MazzleUI.Delayed_HideKTM, 1, self, (numCall + 1))
        end
    end
end

function MazzleUI:ModelInit()

    MazzleUI_Status.DebugLogOn = nil
    MazzleUI_Status.CursorX,     MazzleUI_Status.CursorY     = nil, nil;
    MazzleUI_Status.CursorMoveX, MazzleUI_Status.CursorMoveY = nil, nil;
    MazzleUI_Status.LastClickTime = time()
    MazzleUI_Status.LastGuess, MazzleUI_Status.LastCachedGuess, MazzleUI_Status.CachedGuesses = nil, nil, {};
    MazzleUI_Status.LastAdjusted = 0;
	
	local theObject, theCharacterObject
	ClickCastFrames = ClickCastFrames or {}

	for i=0, 10, 1 do
		theObject = CreateFrame("Button", "Mazz3D_Camera"..i, getglobal(Mazz3D_Model_Info[i].Character.dufparent), "Mazz3D_CharacterTemplate,SecureUnitButtonTemplate");
	    theObject.model = getglobal("Mazz3D_Camera"..i.."_Character")
        theObject.ID = i
        theObject:EnableMouse(1)

		theObject:RegisterForDrag("LeftButton", "RightButton")
		theObject:RegisterForClicks("AnyDown")
		-- setup secure clicks
		theObject.menu = function() DUF_UnitPopup_ShowMenu(Mazz3D_Model_Info[i].Character.unitType) end
		theObject:SetAttribute("unit",Mazz3D_Model_Info[i].Character.unitType)
		theObject:SetAttribute("type1","target")
		theObject:SetAttribute("type2","menu")
		theObject:SetAttribute("type3","assist")
		-- clique support
		if (MazzleUI_Settings.Mazz3D.clickCast) then
    		ClickCastFrames[theObject] = true
        end

        theObject.model:EnableMouse(false)
        theObject.model:EnableMouseWheel(false)
        self:Character_Initialize(theObject)
        unitDB[Mazz3D_Model_Info[i].Character.unitType].Character = theObject
        self:RegisterCharacterScripts(theObject)
    end	
    
    if (not Mazz3D_CameraDB) then
        return
    end

    unitDB.player.Character = Mazz3D_Camera0
    unitDB.target.Character = Mazz3D_Camera1
    unitDB.party1.Character = Mazz3D_Camera2
    unitDB.party2.Character = Mazz3D_Camera3
    unitDB.party3.Character = Mazz3D_Camera4
    unitDB.party4.Character = Mazz3D_Camera5
    unitDB.partypet1.Character = Mazz3D_Camera6
    unitDB.partypet2.Character = Mazz3D_Camera7
    unitDB.partypet3.Character = Mazz3D_Camera8
    unitDB.partypet4.Character = Mazz3D_Camera9
    unitDB.pet.Character = Mazz3D_Camera10
    
    if (MazzleUI_Settings.Mazz3D.randomAnims) then
        self:StartRandomAnims()
    end
    
    self:RegisterBaseEvents()
    if (MazzleUI_Settings.Mazz3D.eventAnims) then
        self:RegisterAnimEvents()
    end
    if (MazzleUI_Settings.Mazz3D.adjustModels) then
        self:RegisterAdjustEvents()
    end

end

function MazzleUI:SetModelClickCasting()
    local theObject
	ClickCastFrames = ClickCastFrames or {}
	for i=0, 10, 1 do
		theObject = getglobal("Mazz3D_Camera"..i);
		ClickCastFrames[theObject] = MazzleUI_Settings.Mazz3D.clickCast
		if (Clique) then
    		if (MazzleUI_Settings.Mazz3D.clickCast) then
    		    Clique:RegisterFrame(theObject)
    		else
    		    Clique:UnregisterFrame(theObject)
        		theObject:RegisterForDrag("LeftButton", "RightButton")
        		theObject:RegisterForClicks("AnyDown")
        		theObject.menu = function() DUF_UnitPopup_ShowMenu(Mazz3D_Model_Info[i].Character.unitType) end
        		theObject:SetAttribute("unit",Mazz3D_Model_Info[i].Character.unitType)
        		theObject:SetAttribute("type1","target")
        		theObject:SetAttribute("type2","menu")
        		theObject:SetAttribute("type3","assist")
    		end
        end
    end
end

function MazzleUI:StartRandomAnims()
    --self:DebugPrint("Scheduling random animations.")
	self:ScheduleRepeatingEvent("Mazz3D_RandomAnimTimer",self.Handle_RandomAnim, 150, self)
    self:PlayRandomAnim(Mazz3D_Camera0)
end

function MazzleUI:StopRandomAnims()
    --self:DebugPrint("Removing schedule for random animations.")
	self:CancelScheduledEvent("Mazz3D_RandomAnimTimer")
end


function MazzleUI:UpdateGroupSize()
    local numRaid = GetNumRaidMembers();
    if ((numRaid > 0) and (not MazzleUI_Status.inRaid40) and (not MazzleUI_Status.inRaid20)) then
        MazzleUI_LastRaidView = MazzleUI_Settings.RaidLayout40
    end
    if (numRaid > 20) then
	    if (not MazzleUI_Status.inRaid40) then
	        self:InRaid40Mode();
	    end
    elseif (numRaid > 0) then
	    if (not MazzleUI_Status.inRaid20) then
	        self:InRaid20Mode();
	    end
	else
        local numParty = GetNumPartyMembers();
    	if (numParty > 0) then
    		if (not MazzleUI_Status.inParty) then
	            self:InPartyMode();
	        end
        else
    	    if (not MazzleUI_Status.solo) then
	    	    self:InSoloMode();
		    end
		end
    end
end

function MazzleUI:UpdatePartyModels()
    local updateList = {}
    table.insert(updateList, Mazz3D_Camera2)
    table.insert(updateList, Mazz3D_Camera3)
    table.insert(updateList, Mazz3D_Camera4)
    table.insert(updateList, Mazz3D_Camera5)
    table.insert(updateList, Mazz3D_Camera6)
    table.insert(updateList, Mazz3D_Camera7)
    table.insert(updateList, Mazz3D_Camera8)
    table.insert(updateList, Mazz3D_Camera9)
    table.insert(updateList, Mazz3D_Camera10)
    for unit in pairs(unitDB) do
        self:Handle_DeathEvent(unitDB[unit].Character, unit)
        unitDB[unit].Character.lastHealth = UnitHealth(unit)
    end
    self:UpdateDirtyCharacters(updateList)
end

function MazzleUI:InRaid40Mode()
    MazzleUI_Status.inRaid40 = true
    MazzleUI_Status.inRaid = true
    MazzleUI_Status.inRaid20 = false
    MazzleUI_Status.inParty = false
    MazzleUI_Status.solo = false
    MazzleUI_Status.currentGroupType = "raid"
    self:InstantiateEfficiencyMode()
    
    if (MazzleUI_Settings.manageRaidFrames) then
        self:RaidViewSet()
    end
end

function MazzleUI:InRaid20Mode()
    MazzleUI_Status.inRaid20 = true
    MazzleUI_Status.inRaid40 = false
    MazzleUI_Status.inRaid = true
    MazzleUI_Status.inParty = false
    MazzleUI_Status.solo = false
    MazzleUI_Status.currentGroupType = "raid"
    self:InstantiateEfficiencyMode()

    if (MazzleUI_Settings.manageRaidFrames) then
        self:RaidViewSet()
    end
end

function MazzleUI:InPartyMode()
    MazzleUI_Status.inParty = true
    MazzleUI_Status.inRaid40 = false
    MazzleUI_Status.inRaid20 = false
    MazzleUI_Status.inRaid = false
    MazzleUI_Status.solo = false
    MazzleUI_Status.currentGroupType = "party"
    self:InstantiateEfficiencyMode()
end

function MazzleUI:InSoloMode()
    MazzleUI_Status.solo = true
    MazzleUI_Status.inRaid40 = false
    MazzleUI_Status.inRaid20 = false
    MazzleUI_Status.inRaid = false
    MazzleUI_Status.inParty = false
    MazzleUI_Status.currentGroupType = "solo"
    self:InstantiateEfficiencyMode()
end

function MazzleUI:ResetCameraGuesses()
    MazzleUI_Status.LastGuess = nil
    MazzleUI_Status.LastCachedGuess = nil
    MazzleUI_Status.CachedGuesses = {}
end

function MazzleUI:CheckCombatStatusManual()
    if (UnitAffectingCombat("player")) then
        if (not MazzleUI_Status.PlayerIsInCombat) then self:Handle_PlayerEnterCombat() end
    else
        if (MazzleUI_Status.PlayerIsInCombat) then self:Handle_PlayerLeaveCombat() end
    end
end


function MazzleUI:InitButtons()
    if (Mazzifier_LastInstalledVersion and (Mazzifier_LastInstalledVersion > 0)) then
        self:HighlightButton("RecapButton", false)
        self:HighlightButton("EfficiencyButton", false)
        self:HighlightButton("OptionsButton", false)
        
        if (MazzleUI_Settings.isManual) then
            self:HighlightButton("EfficiencyButton", true)
        end
        
        if ((not IsAddOnLoaded("Recap")) or 
            (IsAddOnLoaded("Recap") and 
            ((MazzleUI:GetValue("recap.Opt.State.value") ~= "Idle") and (MazzleUI:GetValue("recap.Opt.State.value") ~= "Active")))) then
            self:HighlightButton("RecapButton", true)
        end
    end
end

function MazzleUI:HighlightButton(theButton, shouldHilight)
    local theButton = getglobal("MazzleUI_"..theButton.."_IconSelect")
    if (theButton) then
        if (shouldHilight) then
            theButton:SetTexture("Interface\\AddOns\\MazzleUI\\Art\\MazzleUISelectedBorderButton")
        else
            theButton:SetTexture("")
        end
    end
end

function MazzleUI:InitBags()
	local STBAlpha = 0.5
	
	for i=1, NUM_CONTAINER_FRAMES, 1 do
		local bt = getglobal("ContainerFrame"..i.."BackgroundTop");
			 if bt then bt:SetAlpha(STBAlpha) end
    local bm = getglobal("ContainerFrame"..i.."BackgroundMiddle1");
   		if bm then bm:SetAlpha(STBAlpha) end
		local bb = getglobal("ContainerFrame"..i.."BackgroundBottom");
			if bb then bb:SetAlpha(STBAlpha) end
	end
	
end

function MazzleUI:OnClick(side, buttonID)
    if (buttonID == 1) then 
        self:ToggleRecap(side)
        GameTooltip:Hide()
        self:OnTooltip(1, MazzleUI_RecapButton)
    elseif (buttonID == 2) then 
        self:ToggleEfficiency()
        GameTooltip:Hide()
        self:OnTooltip(2, MazzleUI_EfficiencyButton)
    elseif (buttonID == 10) then 
        self:ToggleOptions()
        GameTooltip:Hide()
        self:OnTooltip(10, MazzleUI_OptionsButton)
    end
    self:MouseClickEffect()
end

function MazzleUI:OnTooltip(buttonID, owner)
    GameTooltip:SetOwner(owner,"ANCHOR_LEFT")
    if (buttonID == 1) then
        if (IsAddOnLoaded("Recap") and ((MazzleUI:GetValue("recap.Opt.State.value") == "Idle") or (MazzleUI:GetValue("recap.Opt.State.value") == "Active"))) then
        	GameTooltip:AddLine("Left-click to show/hide Recap.")
        	GameTooltip:AddLine("Right-click to toggle Recap combat monitoring.")
        	GameTooltip:AddLine("Recap is currently ON.")
        else
        	GameTooltip:AddLine("Left-click to show/hide Recap.")
        	GameTooltip:AddLine("Right-click to toggle Recap combat monitoring.")
        	GameTooltip:AddLine("Recap is currently OFF.")
        end
    elseif (buttonID == 2) then
        if (MazzleUI_Settings.isManual) then
        	GameTooltip:AddLine("Click to toggle MazzleUI Efficiency Mode.")
        	GameTooltip:AddLine("MazzleUI Efficiency Mode is currently ON.")
        else
        	GameTooltip:AddLine("Click to toggle MazzleUI Efficiency Mode.")
        	GameTooltip:AddLine("MazzleUI Efficiency Mode is currently OFF.")
        end
    elseif (buttonID == 9) then
    	GameTooltip:AddLine("Click to show the MazzleUI Help Desk.")
    elseif (buttonID == 10) then
    	GameTooltip:AddLine("Click to show MazzleUI Options and FAQ system.")
    end
    GameTooltip:Show()
end

function MazzleUI:InitSettings()

	Mazzifier_PlayerName = UnitName("player");
	Mazzifier_ServerName = GetCVar("realmName");
    Mazzifier_PlayerClass = UnitClass("player");

    if (not MazzleUI_Settings) then MazzleUI_Settings = {} end
    MazzleUI_Settings = self:VerifyDefaults(MazzleUI_Settings, MazzleUI_SettingsDefault)

end

function MazzleUI:VerifyDefaults(originalTable, defaultTable)
    
    for theSetting, theDefaultValue in pairs(defaultTable) do
        if (type(defaultTable[theSetting]) == "table") then
            if (type(originalTable[theSetting]) == "nil") then
                originalTable[theSetting] = {}
            end
            originalTable[theSetting] = self:VerifyDefaults(originalTable[theSetting], defaultTable[theSetting])
        else
            if (type(originalTable[theSetting]) == "nil") then
                originalTable[theSetting] = theDefaultValue
            end
       end
    end
    return originalTable
end

function MazzleUI:HotSpot_Tooltip_Handle(hotSpotNumber, owner)
    GameTooltip:SetOwner(owner,"ANCHOR_LEFT")

    if (hotSpotNumber == 0) then
    	if (MazzleUI_Settings.HotSpots.RaidCycle) then
        	GameTooltip:AddLine("Left-click to show/hide bag and menu bar.\nRight-click to cycle through different raid layouts.")
        else
        	GameTooltip:AddLine("Right-click to cycle through different raid layouts.")
        end
    elseif ((hotSpotNumber == 1) and MazzleUI_Settings.HotSpots.Quest) then
        GameTooltip:SetOwner(owner,"ANCHOR_RIGHT")
    	GameTooltip:AddLine("Left-Click to nQuestLog.\nRight-click to toggle Blizzard quest log.")
    elseif ((hotSpotNumber == 2) and MazzleUI_Settings.HotSpots.Notebook) then
        GameTooltip:SetOwner(owner,"ANCHOR_RIGHT")
    	GameTooltip:AddLine("Click to toggle Omnibus notepad.")
    elseif ((hotSpotNumber == 3) and MazzleUI_Settings.HotSpots.NeedyList) then
    	GameTooltip:AddLine("Left-click to toggle your context menu.")
    elseif ((hotSpotNumber == 4) and MazzleUI_Settings.HotSpots.ItemRack) then
        if (Dcr) then
        	GameTooltip:AddLine("Left-click to toggle ItemRack.\nRight-click to toggle Decursive.")
        else
        	GameTooltip:AddLine("Left-click to toggle ItemRack.")
        end
    elseif ((hotSpotNumber == 5) and MazzleUI_Settings.HotSpots.KCI) then
        GameTooltip:SetOwner(owner,"ANCHOR_TOPLEFT")
    	GameTooltip:AddLine("Click to copy text from this chat frame.")
    elseif ((hotSpotNumber == 6) and MazzleUI_Settings.HotSpots.Compass) then
        GameTooltip:SetOwner(owner,"ANCHOR_TOP")
    	GameTooltip:AddLine("Click to open your map.")
    elseif ((hotSpotNumber == 7) and MazzleUI_Settings.HotSpots.xCalc) then
        GameTooltip:SetOwner(owner,"ANCHOR_TOPRIGHT")
    	GameTooltip:AddLine("Left-click to toggle ItemSync loot database.\nRight-click to toggle XCalc.")
    end
    GameTooltip:Show()
end

function MazzleUI:HotSpot_Click_Handle(hotSpotNumber, theButton, side)
    if (InCombatLockdown()) then return; end;
    if (hotSpotNumber == 0) then
        if (MazzleUI_Settings.HotSpots.RaidCycle and arg1 and (arg1 == "RightButton")) then
            MazzleUI:NextView(1)
        else
            MazzleUI:BarsToggle()
        end
    elseif ((hotSpotNumber == 1) and MazzleUI_Settings.HotSpots.Quest) then
        MazzleUI:nQuestToggle(side)
    elseif ((hotSpotNumber == 2) and MazzleUI_Settings.HotSpots.Notebook) then
        MazzleUI:NotebookToggle()
    elseif ((hotSpotNumber == 3) and MazzleUI_Settings.HotSpots.NeedyList) then
    elseif ((hotSpotNumber == 4) and MazzleUI_Settings.HotSpots.ItemRack) then
        MazzleUI:ToggleTopRightHotSpot(side)
    elseif ((hotSpotNumber == 5) and MazzleUI_Settings.HotSpots.KCI) then
        if (Prat_CopyChat) then Prat_CopyChat:ScrapeChatFrame(SELECTED_CHAT_FRAME); end
    elseif ((hotSpotNumber == 6) and MazzleUI_Settings.HotSpots.Compass) then
        MazzleUI:ToggleMap()
    elseif ((hotSpotNumber == 7) and MazzleUI_Settings.HotSpots.xCalc) then
        MazzleUI:ToggleBottomRightHotSpot(side)
    end
    MazzleUI:MouseClickEffect()
end

function MazzleUI:ToggleTopRightHotSpot(side)
    if (side== "LeftButton") then
        MazzleUI:ItemRackToggle()
    elseif ((side== "RightButton") and Dcr) then
        if (DcrMUFsContainer and (not DcrMUFsContainer:IsVisible()) and oRAOMainTank and oRAOMainTank.secureframes and oRAMainTank:IsVisible() and (MazzleUI_Settings.FaveMTPosition == 1)) then
    	    MazzleUI_Settings.FaveMTPosition = 2; 
    	    MazzleUI:RaidViewSet();
    	    MazzleUI_SwitchBackToSide = true;
	    elseif (MazzleUI_SwitchBackToSide) then
    	    MazzleUI_Settings.FaveMTPosition = 1; 
    	    MazzleUI:RaidViewSet();
    	    MazzleUI_SwitchBackToSide = false;
	    end
        if (BBagBar and BBagBar:IsVisible()) then
            MazzleUI:BarsToggle()
        end
        MazzleUI:Execute("/dcr MicroFrameOpt show")
        MazzleUI:Execute("/dcr livelistoptions show")
    end
end

function MazzleUI:ToggleBottomRightHotSpot(side)
    if ((side== "LeftButton") and ItemSync) then
        if (not ISync_MainFrame:IsVisible()) then
            MazzleUI:Execute("/itemsync show")
         else
            ISync_MainFrame:Hide()
        end
    elseif ((side== "RightButton")) then
        if (not xcalc_windowdisplay) then LoadAddOn("xcalc"); end;
        if (xcalc_windowdisplay) then
            xcalc_windowdisplay()
        end
    end
end

function MazzleUI:nQuestToggle(side)
    if ((side== "LeftButton") and nQuestLogFrame) then
    	if (nQuestLogFrame:IsVisible()) then 
    	    nQuestLog:ToggleVisible(false); 
    	    if (nQuestLog:GetModule("DetailsFrame")) then nQuestLog:GetModule("DetailsFrame"):ShowLog(); end;
    	else 
    	    nQuestLog:ToggleVisible(true); 
    	end
    elseif ((side== "RightButton")) then
        if (QuestLogFrame:IsVisible()) then QuestLogFrame:Hide(); else QuestLogFrame:Show(); end
    end
end

function MazzleUI:NotebookToggle()
    if IsAddOnLoaded("Omnibus") then
        if (OmnibusFrame:IsVisible()) then 
            OmnibusFrame:Hide() 
        else 
            OmnibusFrame:Show()
        end
    end
end

function MazzleUI:BarsToggle()
    if (BBagBar) then
        if (BBagBar:IsVisible()) then 
            BBar.Hide(BBar.IDToBar("bags"), 1)
            BBar.Hide(BBar.IDToBar("menu"), 1)
            BBar.Hide(BBar.IDToBar("key"), 1)
        else
            BBar.Show(BBar.IDToBar("bags"), 1)
            BBar.Show(BBar.IDToBar("menu"), 1)
            BBar.Show(BBar.IDToBar("key"), 1)
        end
    end
end

function MazzleUI:ItemRackToggle()
    if IsAddOnLoaded("ItemRack") then
        ItemRack_Toggle()
    end
end

function MazzleUI:KCToggle()
    if (not InCombatLockdown()) then
        if IsAddOnLoaded("KC_Items") then
    		if (KC_LinkviewFrame:IsVisible()) then
    			KC_LinkviewFrame:Hide()
            else
                KC_LinkviewFrame:Show()			
    		end
        end
    end
end

function MazzleUI:ToggleMap()
    if (not InCombatLockdown()) then
        ToggleWorldMap();
    end;
end

function MazzleUI:ChangeDiscordUpdateRate(newSpeed)

    --self:Print("MazzleUI is setting all discord add-ons' update rate to "..newSpeed)
    if (DUF_Settings and DUF_INDEX and DUF_Settings[DUF_INDEX]) then
        DUF_Settings[DUF_INDEX].updatespeedbase = newSpeed
    	DUF_Settings[DUF_INDEX].updatespeed = 1 / DUF_Settings[DUF_INDEX].updatespeedbase;
    end

end

function MazzleUI:ToggleRecap(side)
    if (not InCombatLockdown()) then
        if IsAddOnLoaded("Recap") then
            if (side and (side == "RightButton")) then
                if (MazzleUI:GetValue("recap.Opt.State.value") == "Idle") or (MazzleUI:GetValue("recap.Opt.State.value") == "Active") then
            	    Recap_SetState("Stopped")
                    MazzleUI:HighlightButton("RecapButton", true)
                	UIErrorsFrame:AddMessage("Recap combat tracking now OFF.", 1.0, 0.0, 0.0, 1.0, 0.1);
            	else
            	    Recap_SetState("Idle")
                    MazzleUI:HighlightButton("RecapButton", false)
                	UIErrorsFrame:AddMessage("Recap combat tracking now ON.", 0.0, 1.0, 0.0, 1.0, 0.1);
            	end
            else
                RecapFrame_Toggle();
            end
        end
    end
end

function MazzleUI:ToggleOptions()
    if (not InCombatLockdown()) then
        if (not IsAddOnLoaded("MazzleOptions")) then
            LoadAddOn("MazzleOptions")
        elseif (MazzleOptions_Frame:IsVisible()) then
            MazzleOptions_Frame:Hide()
        else
            MazzleOptions_Frame:Show()
        end
    end
end



function MazzleUI:ToggleEfficiency()
    if (not InCombatLockdown()) then
        if (MazzleUI_Settings.isManual) then
            MazzleUI_Settings.isManual = false
            MazzleUI:InstantiateEfficiencyMode(true)
            MazzleUI:HighlightButton("EfficiencyButton", false)
        else
            MazzleUI_Settings.isManual = true
            MazzleUI:InstantiateEfficiencyMode()
            MazzleUI:HighlightButton("EfficiencyButton", true)
        end
    end
end

function MazzleUI:InstantiateEfficiencyMode(forceReInit)
    local shouldInstantiate
   if (MazzleUI_Settings.isManual) then
        if (MazzleUI_Status.currentEfficiencyMode == "manual" and (not forceReInit)) then return; else
            MazzleUI_Status.currentEfficiencyMode = "manual"
            MazzleUI_EfficiencyButton:SetText("M")
        end
   elseif (MazzleUI_Settings.Performance_Enabled["pvp"] and MazzleUI_Status.inPvP) then
        if (MazzleUI_Status.currentEfficiencyMode == "pvp" and (not forceReInit)) then return; else
            MazzleUI_Status.currentEfficiencyMode = "pvp"
            MazzleUI_EfficiencyButton:SetText("V")
        end
   elseif (MazzleUI_Settings.Performance_Enabled["raid"] and MazzleUI_Status.inRaid) then
        if (MazzleUI_Status.currentEfficiencyMode == "raid" and (not forceReInit)) then return; else
            MazzleUI_Status.currentEfficiencyMode = "raid"
            MazzleUI_EfficiencyButton:SetText("R")
        end
   elseif (MazzleUI_Settings.Performance_Enabled["party"] and MazzleUI_Status.inParty) then
        if (MazzleUI_Status.currentEfficiencyMode == "party" and (not forceReInit)) then return; else
            MazzleUI_Status.currentEfficiencyMode = "party"
            MazzleUI_EfficiencyButton:SetText("P")
        end
   elseif (MazzleUI_Settings.Performance_Enabled["combat"] and MazzleUI_Status.inCombat) then
        if (MazzleUI_Status.currentEfficiencyMode == "combat" and (not forceReInit)) then return; else
            MazzleUI_Status.currentEfficiencyMode = "combat"
            MazzleUI_EfficiencyButton:SetText("C")
        end
   else
        if (MazzleUI_Status.currentEfficiencyMode == "solo" and (not forceReInit)) then return; else
            MazzleUI_Status.currentEfficiencyMode = "solo"
            MazzleUI_EfficiencyButton:SetText("")
        end
    end
    for _,performanceOption in pairs(MazzleUI_PerformanceItems) do
        if (MazzleUI_Settings[performanceOption][MazzleUI_Status.currentEfficiencyMode] ~= MazzleUI_Status.currentEfficiencySettings[performanceOption]) then
            MazzleUI_Status.currentEfficiencySettings[performanceOption] = MazzleUI_Settings[performanceOption][MazzleUI_Status.currentEfficiencyMode]
            shouldInstantiate = true
            if ((MazzleUI_Status.currentEfficiencyMode == "combat") and (not MazzleUI_Settings[performanceOption].canCombat)) then
                 shouldInstantiate = false;
            elseif ((MazzleUI_Status.currentEfficiencyMode == "manual") and MazzleUI_Settings[performanceOption].noManual) then
                 shouldInstantiate = false;
            end
            if (shouldInstantiate) then MazzleUI:InstantiateEfficiencyItem(performanceOption, MazzleUI_Status.currentEfficiencySettings[performanceOption]); end;
        end
    end
end

function MazzleUI:WarnHighGraphics()
    StaticPopupDialogs["MazzleUI_Warn_Graphics"] = {
      text = "You have not yet told MazzleUI how high it should set the graphics when switching efficiency modes.  It's possible that it just set your graphics to a higher level than you are used to.  Please see the in-game FAQ entry that describes how to tell MazzleUI exactly how you like your video settings.",
      button1 = "Go to FAQ entry",
      button2 = "Ignore",
      OnAccept = function()
            LoadAddOn("MazzleOptions")
            MazzleOptions:Show()
            MazzleOptions:CategoryButtonOnClick(2)
            MazzleOptions:TopicButton_OnClick(35)
      end,
      timeout = 0,
      whileDead = 1,
      hideOnEscape = 1
    };
    StaticPopup_Show ("MazzleUI_Warn_Graphics");
end

function MazzleUI:InstantiateEfficiencyItem(performanceItem, setHigh)
    --self:Print("Instantiating performance setting: ", performanceItem, " ", setHigh)
    if (performanceItem == "Performance_Gfx") then
        if (gfxToggle) then
            if (setHigh) then
                if (not gfxToggle:IsInfoHigh()) then MazzleUI:WarnHighGraphics(); end;
                gfxToggle:LoadHi()
            else
                gfxToggle:LoadLo()
            end
        MazzleUI:Frames_ConfigureMinimap()
        end
    elseif (performanceItem == "Performance_Models") then
        if (setHigh) then
    	    self:StartRandomAnims()
    	    self:RegisterAnimEvents()
    	    self:RegisterAdjustEvents()
        else
            self:StopRandomAnims()
    	    self:UnregisterAnimEvents()
    	    self:UnregisterAdjustEvents()
        end
    elseif (performanceItem == "Performance_Recap") then
        if (Recap_SetState) then
            if (setHigh) then
                if (MazzleUI:GetValue("recap.Opt.State.value") ~= "Idle") or (MazzleUI:GetValue("recap.Opt.State.value") ~= "Active") then
                    self:ToggleRecap("RightButton")
                end
            else
                if (MazzleUI:GetValue("recap.Opt.State.value") == "Idle") or (MazzleUI:GetValue("recap.Opt.State.value") == "Active") then
                    self:ToggleRecap("RightButton")
                end
            end
        end
    elseif (performanceItem == "Performance_SWS") then
        if (SW_ToggleRunning) then
            if (setHigh) then
                if (not SW_Settings["IsRunning"]) then
                    SW_ToggleRunning(true);
                end
            else
                if (SW_Settings["IsRunning"]) then
                    SW_ToggleRunning(false);
                    SW_PauseEvents();
                end
            end
        end
    elseif (performanceItem == "Performance_CECB") then
        if (setHigh) then
            if (Chronometer) then Chronometer:ToggleActive(true); end;
            if (Antagonist) then Antagonist:ToggleActive(true); end;
            if (Hourglass) then Hourglass:ToggleActive(true); end;
        else
            if (Chronometer) then Chronometer:ToggleActive(false); end;
            if (Antagonist) then Antagonist:ToggleActive(false); end;
            if (Hourglass) then Hourglass:ToggleActive(false); end;
        end
    elseif (performanceItem == "Performance_HUDRange") then
        if (setHigh) then
            MazzleUI_Settings.HUD.ShowRange = true
            MazzleUI:Handle_TargetChange();
        else
            MazzleUI_Settings.HUD.ShowRange = false
        	if (not MazzleUI.TargetButtons) then MazzleUI:StopMetro("MazzleUITargetUpdate");  end;
        	MazzleUI.HUD.target.rangeText.textString:SetText("");
        end
    elseif (performanceItem == "Performance_SpellEffects") then
        if (setHigh) then
            --SetCVar("spellEffectLevel",(MazzleUI.lastSpellEffectLevel or "2"))
            SetCVar("spellEffectLevel","2")
        else
            MazzleUI.lastSpellEffectLevel = GetCVar("spellEffectLevel")
            SetCVar("spellEffectLevel","0")
        end
    elseif (performanceItem == "Performance_BigWigs") then
        if (BigWigs) then
            if (setHigh) then
                BigWigs:ToggleActive(true)
            else
                BigWigs:ToggleActive(false)
            end
        end
    elseif (performanceItem == "Performance_SCT") then
        if (SCT) then
            if (setHigh) then
                SCT:OnEnable()
            else
                SCT:OnDisable()
            end
        end
    elseif (performanceItem == "Performance_SCTD") then
        if (SCTD) then
            if (setHigh) then
                SCTD:OnEnable()
            else
                SCTD:OnDisable()
            end
        end
    elseif (performanceItem == "Performance_SpellAlert") then
        if (WitchHunt) then
            if (setHigh) then
                WitchHunt:ToggleActive(true)
            else
                WitchHunt:ToggleActive(false)
            end
        end
    elseif (performanceItem == "Performance_Discord") then
        if (setHigh) then
            MazzleUI:ChangeDiscordUpdateRate(MazzleUI_Settings.DiscordUpdate)
        else
            MazzleUI:ChangeDiscordUpdateRate(MazzleUI_Settings.Performance_DiscordUpdate)
        end
    end
end

function MazzleUI:BindContextMenu()
    local key1, key2 = GetBindingKey("MAZZLEUICONTEXT")
    self:Print("Binding context menu to ", key1, key2)
    MazzleUI.ContextMenu:ClearBindings()
    if (key1) then SetBinding(key1); MazzleUI.ContextMenu:SetShowBinding(key1); end;
    if (key2) then SetBinding(key2); MazzleUI.ContextMenu:SetShowBinding(key2); end;
	SaveBindings(2)
end

function MazzleUI:CheckTargetRange()
	if CheckInteractDistance("target",2) then
		if (self.TargetButtons) then
    		self.Buttons.Inspect:Show();
    		self.Buttons.Trade:Show();
    		self.Buttons.Follow:Show();
		end
		if (MazzleUI_Settings.HUD.ShowRange and self.HUD.visible) then self.HUD.target.rangeText.textString:SetText("0 - 11 yards"); end
	elseif CheckInteractDistance("target",4) then
		if (self.TargetButtons) then
    		self.Buttons.Trade:Hide();
    		self.Buttons.Inspect:Show();
     		self.Buttons.Follow:Show();
		end
		if (MazzleUI_Settings.HUD.ShowRange and self.HUD.visible) then self.HUD.target.rangeText.textString:SetText("11 - 30 yards"); end
	else
		if (self.TargetButtons) then
    		self.Buttons.Inspect:Hide();
    		self.Buttons.Trade:Hide();
    		self.Buttons.Follow:Hide();
		end
		if (MazzleUI_Settings.HUD.ShowRange and self.HUD.visible) then self.HUD.target.rangeText.textString:SetText("30+ yards"); end
	end
end
