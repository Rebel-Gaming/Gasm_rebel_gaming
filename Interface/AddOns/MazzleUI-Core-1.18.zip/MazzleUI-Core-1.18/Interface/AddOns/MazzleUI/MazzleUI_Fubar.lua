if not MazzleUI then return end

if not AceLibrary:HasInstance("FuBarPlugin-2.0") then return end

MazzleFu = AceLibrary("AceAddon-2.0"):new("FuBarPlugin-2.0", "AceDB-2.0")

MazzleFu.title = "MazzleUI"
MazzleFu.category = "Interface Enhancements";
MazzleFu.cannotDetachTooltip = true
--MazzleFu.tooltipHiddenWhenEmpty  = true;


function MazzleFu:OnInitialize()
    self.name = "FuBar - MazzleUI"
    self.hasIcon = true
    self.defaultPosition = "RIGHT"
    self.hasNoColor = true
    self.hideWithoutStandby = true
    self.cannotHideText = false
    self.cannotAttachToMinimap = true

	self:SetIcon("Interface\\AddOns\\MazzleUI\\Art\\MazzleUI_FubarIcon")
	self:RegisterDB("MazzleFuDB")
	self:RegisterDefaults('profile', {
		showText = true,
		showIcon = true
	})

end

MazzleFu.RaidPositionLookup = { [1] = "Bottom", [2] = "Top", [3] = "None"}
MazzleFu.RaidPositionLookup = MazzleUI:MirrorTable(MazzleFu.RaidPositionLookup)
MazzleFu.MTPositionLookup = { [1] = "Side", [2] = "Top"}
MazzleFu.MTPositionLookup = MazzleUI:MirrorTable(MazzleFu.MTPositionLookup)

MazzleFu.OnMenuRequest = {
    type = 'group',
    args = {
            {   type = 'execute',
                order = 1,
                name = "Open Mazzifier",
                desc = "Opens MazzleUI's configuration utility",
                func = function()
                    MazzleUI:LoadMazzifier(true); MazzleFu:OpenMenu();
                end
             },
            {
                type = 'execute',
                order = 2,
                name = "Open MazzleOptions",
                desc = "Opens the MazzleUI's options system",
                func = function()
                    LoadAddOn("MazzleOptions")
                    MazzleOptions:Show()
                    MazzleOptions:CategoryButtonOnClick(1)
                    MazzleFu:OpenMenu();
                end
             },
            {
                type = 'execute',
                order = 3,
                name = "Open Frequently Asked Questions",
                desc = "Opens the FAQ area of MazzleOptions",
                func = function()
                    LoadAddOn("MazzleOptions")
                    MazzleOptions:Show()
                    MazzleOptions:CategoryButtonOnClick(2)
                    MazzleOptions:TopicButton_OnClick(2)
                    MazzleFu:OpenMenu();
                end
             },
            {
                type = 'execute',
                order = 4,
                name = "Take Mazzlefizz out to eat",
                desc = "Makes you a wonderful human being!",
                func = function()
                    PlaySoundFile("Sound\\Character\\Gnome\\GnomeVocalFemale\\GnomeFemaleThankYou01.wav")
                    DoEmote("blush"); 
                    UIErrorsFrame:AddMessage("Thank you!\nYou can send a donation via paypal (www.paypal.com) to\nmazzleui.donations@gmail.com", 0.0, 0.0, 1.0, 1.0, 1);
                    DEFAULT_CHAT_FRAME:AddMessage("Thank you! You can send a donation via paypal (www.paypal.com) to mazzleui.donations@gmail.com.", 1, 0, 0)
                end
             },
            {
                type = 'execute',
                order = 5,
                name = "|CFF00FF00--------|CFFFF0000Hot-Swappable Unit Frames|CFF00FF00--------",
                desc = " ",
                func = function()
                end
             },
			{
				type = "text", name = "Raid Frames", desc = "Position of sRaid raid frames",
				get = function() return MazzleFu.RaidPositionLookup[MazzleUI_Settings.FaveRaidPosition] end,
				set = function(v) 
				    MazzleUI_Settings.FaveRaidPosition = MazzleFu.RaidPositionLookup[v]; 
				    MazzleUI:RaidViewSet() end,
				validate = {[1] = "Bottom", [2] = "Top",  [3] = "None"},
				order = 6,
			},
			{
				type = "text", name = "Main Tank Frames", desc = "Position of oRA2 Main Tank frames",
				get = function() return MazzleFu.MTPositionLookup[MazzleUI_Settings.FaveMTPosition] end,
				set = function(v) 
				    MazzleUI_Settings.FaveMTPosition = MazzleFu.MTPositionLookup[v]; 
				    MazzleUI:RaidViewSet() end,
				validate = {[1] = "Side", [2] = "Top"},
				order = 7,
			},
            {
                type = 'toggle',
                name = "Adjust raid layout to be better distributed in 20-mans",
                desc = "Determines whether MazzleUI will use an alternate 20 man raid layout where groups 5-8 are not shown and other groups are layed out more symmetrically",
                get = function()
                    return MazzleUI_Settings.AutoSwapRaid20;
                end,
                set = function(v)
                    MazzleUI_Settings.AutoSwapRaid20 = v; MazzleUI:Set_RefreshRaidView();
                end,
                map = { [false] = "Hide", [true] = "Show" },
				order = 8,
            },
            {
                type = 'toggle',
                name = "Show your party members when there's room available",
                desc = "Determines whether MazzleUI will show your party when you have raid frames shown on top",
                get = function()
                    return MazzleUI_Settings.ShowRaidParty
                end,
                set = function(v)
                    MazzleUI_Settings.ShowRaidParty = v; MazzleUI:Set_RefreshRaidView();
                end,
                map = { [false] = "Hide", [true] = "Show" },
				order = 9,
            },
            {
                type = 'toggle',
                name = "Hide your party members' pets",
                desc = "Determines whether MazzleUI will show unit frames and models for you parties' pets",
                get = function()
                    return MazzleUI:Get_DUFPartyPets();
                end,
                set = function(v)
                    MazzleUI:Set_DUFPartyPets(v); MazzleUI:Set_RefreshRaidView();
                end,
                map = { [false] = "Show", [true] = "Hide" },
				order = 10,
            },
            {
                type = 'execute',
                order = 11,
                name = "|CFF00FF00--------|CFFFF0000Bongos Action Bars|CFF00FF00--------",
                desc = " ",
                func = function()
                end
             },
            {
                type = 'execute',
                order = 12,
                name = "Open Bongos option window",
                desc = "Opens the Bongos configuration window for modifying your button setup",
                func = function() MazzleUI:Execute("/bongos");  MazzleFu:OpenMenu(); end,
             },
            {
                type = 'toggle',
                name = "Unlock and edit bars",
                desc = "Unocks Bongos, allowing you to edit the properties and positions of bars.  For global bar settings, open the options window.",
                get = function()
                    return (BongosSets and (not BongosSets.locked));
                end,
                set = function(v)
                    if (v) then MazzleUI:Execute("/bongos unlock"); else MazzleUI:Execute("/bongos lock"); end; MazzleFu:OpenMenu();
                end,
                map = { [false] = "Locked", [true] = "Editable" },
				order = 13,
            },
            {
                type = 'toggle',
                name = "Change key bindings of buttons",
                desc = "Enters Bongos key binding mode. Simply mouse over a button and hit the key you want to bind it to. You can also hit escape to clear all previous keys that button was bound to.",
                get = function()
                    return (BongosOptionsPanelBindingsPerCharacter and BongosOptionsPanelBindingsPerCharacter:IsVisible());
                end,
                set = function(v)
                    if (v) then 
                        if (not BongosOptions or (BongosOptions and not BongosOptions:IsVisible())) then MazzleUI:Execute("/bongos"); end;
                        BOptions_SwitchTab("Bindings"); 
                    else
                        if (not BongosOptions or (BongosOptions and not BongosOptions:IsVisible())) then MazzleUI:Execute("/bongos"); end;
                        BOptions_SwitchTab("General"); 
                        BongosOptions:Hide()
                    end;
                    MazzleFu:OpenMenu();
                end,
                map = { [false] = "Normal Operation", [true] = "Key Binding Mode" },
				order = 14,
            },
            {
                type = 'toggle',
                name = "Allow moving spells and skills",
                desc = "Unocks buttons, allowing you to drag skills around.  You can also do this by holding down the control key.",
                get = function()
                    return (not MazzleUI:GetValue("BActionSets.g.buttonsLocked"));
                end,
                set = function(v) MazzleUI:SetValue("BActionSets.g.buttonsLocked", (not v)); MazzleFu:OpenMenu(); end,
                map = { [false] = "Locked", [true] = "Unlocked" },
				order = 15,
            },
            {
                type = 'toggle',
                name = "Show empty buttons",
                desc = "Shows all empty buttons in all visible bars.",
                get = function()
                    return MazzleUI:GetValue("BActionSets.g.showGrid");
                end,
                set = function(v) BActionSets_SetShowGrid(v); end,
                map = { [false] = "Locked", [true] = "Unlocked" },
				order = 16,
            },
            {
                type = 'execute',
                order = 17,
                name = " ",
                desc = " ",
                func = function()
                end
             },
            {
                type = 'execute',
                order = 18,
                name = "Reload user interface",
                desc = "Reloads your UI which saves all of your settings and restarts all of your add-ons.",
                func = function() MazzleUI:Execute("/rl");  MazzleFu:OpenMenu(); end,
             },
    }
}