-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--
local LSRF = AceLibrary("AceLocale-2.2"):new("sRaidFrames")

function MazzleUI:NextView()

    if (MazzleUI_Settings.FaveMTPosition < 3) then
        MazzleUI_Settings.FaveMTPosition = MazzleUI_Settings.FaveMTPosition + 1
    elseif (MazzleUI_Settings.ShowRaidParty and (MazzleUI_Settings.FaveRaidPosition ~= 1)) then
        MazzleUI_Settings.FaveMTPosition = 1
        MazzleUI_Settings.ShowRaidParty = false
    else
        MazzleUI_Settings.ShowRaidParty = true
        MazzleUI_Settings.FaveMTPosition = 1
        if (MazzleUI_Settings.FaveRaidPosition == 3) then
            MazzleUI_Settings.FaveRaidPosition = 1
        else
            MazzleUI_Settings.FaveRaidPosition = MazzleUI_Settings.FaveRaidPosition + 1
        end
    end

    self:RaidViewSet()

end

function MazzleUI:RaidViewSet()
    local feedbackMsg = "MazzleUI hot-swapping raid layout: "
    --if (sRaidFrames.master and sRaidFrames.master:IsVisible() and DUF_Settings and DUF_INDEX) then
    --if (sRaidFrames and sRaidFrames.master and DUF_Settings and DUF_INDEX) then
    if (InCombatLockdown()) then
        self:ScheduleLeaveCombatAction(MazzleUI.RaidViewSet, self)
        return
    end
    if (sRaidFrames and sRaidFrames.master and sRaidFrames.groupframes and sRaidFrames.groupframes[1] and sRaidFrames.groupframes[1]:GetTop() and DUF_Settings and DUF_INDEX) then
        --self:Print("Setting sRaidFrames layout.")
        if (MazzleUI_LastAspect) then

            -- Set up raid frame positions
            if (MazzleUI_Settings.FaveRaidPosition == 1) then
                sRaidFrames.master:Show()
                self:LayoutRaid(1)
                feedbackMsg = feedbackMsg.."raid frames on bottom, " 
            elseif (MazzleUI_Settings.FaveRaidPosition == 2) then
                sRaidFrames.master:Show()
                if (MazzleUI_Settings.FaveMTPosition == 1) then
                    self:LayoutRaid(2)
                elseif (MazzleUI_Settings.FaveMTPosition == 2) then
                    self:LayoutRaid(3)
                elseif (MazzleUI_Settings.FaveMTPosition == 3) then
                    self:LayoutRaid(4)
                end
                feedbackMsg = feedbackMsg.."raid frames on top, " 
            elseif (MazzleUI_Settings.FaveRaidPosition == 3) then
                sRaidFrames.master:Hide()
                feedbackMsg = feedbackMsg.."no raid frames, " 
            end

            -- Show party frames if room and user wants
            if (MazzleUI_Settings.ShowRaidParty and (MazzleUI_Settings.FaveRaidPosition ~= 1)) then
                DUF_Settings[DUF_INDEX].hidepartyinraid = nil
                feedbackMsg = feedbackMsg.."show party, " 
            else
                DUF_Settings[DUF_INDEX].hidepartyinraid = 1
                feedbackMsg = feedbackMsg.."no party, " 
            end
            DUF_Main_UpdatePartyMembers()

            -- Position MT windows
            if (MazzleUI_Settings.manageMTFrames) then
                if (MazzleUI_Settings.FaveMTPosition == 1) then
--                    if ((not DUF_Settings[DUF_INDEX].hidepartyinraid) and (not DUF_Settings[DUF_INDEX].partypet.hide) and (MazzleUI_LastAspect ~= 3)) then
--
--                        self:oRA_MTPosition("petAdjust")
--                    else
--                        if (MazzleUI_LastAspect == 1) then
--                            self:oRA_MTPosition("standard-125")
--                        else
                            self:oRA_MTPosition("standard")
--                        end
--                  end
                    feedbackMsg = feedbackMsg.."MT windows on side." 
                elseif (MazzleUI_Settings.FaveMTPosition == 2) then
                    self:oRA_MTPosition("top")
                    feedbackMsg = feedbackMsg.."MT windows on top." 
                elseif (MazzleUI_Settings.FaveMTPosition == 3) then
                    self:oRA_MTPosition("top-3")
                    feedbackMsg = feedbackMsg.."MT windows on top with wider ToToT display." 
                end
            end
        	UIErrorsFrame:AddMessage(feedbackMsg, 0.0, 0.0, 1.0, 1.0, 0.05);
        end
    else
        -- This will probably not be needed when we are no longer using DUF
        self:ScheduleEvent(self.RaidViewSet, 2, self)
    end
end
        
function MazzleUI:LayoutRaid(theLayout)

    if (theLayout == 3) then theLayout = 4; end;
    if (theLayout == 1) then 
        if (MazzleUI_LastAspect == 3) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.6 40 bottom
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 282, groupSpacing = 25, xAnchor = 432, yAnchor = -1120, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle")
                self:sRaidGrow("up")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(true)
            else
                -- 1.6 20 on bottom
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 745, groupSpacing = 37, xAnchor = 433, yAnchor = -1065, yMargin = 5, adjust125x = 190, adjust125y = 100}
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 745, groupSpacing = 25, xAnchor = 325, yAnchor = -1093, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("right")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(false)
            end
        elseif (MazzleUI_LastAspect == 2) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.33 40 bottom
                MazzleUI_Settings.sRaidFrames = { scale = 0.815, targetAdjust = 295, groupSpacing = 0, xAnchor = 474, yAnchor = -1291, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle")
                self:sRaidGrow("up")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(true)
            else
                -- 1.33 20 bottom
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 296, groupSpacing = 45, xAnchor = 456, yAnchor = -1119, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("up")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20125")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(true)
            end
        elseif (MazzleUI_LastAspect == 1) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.25 40 bottom
                MazzleUI_Settings.sRaidFrames = { scale = 0.9, targetAdjust = 268, groupSpacing = 0, xAnchor = 430, yAnchor = -1169, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle125")
                self:sRaidGrow("up")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(true)
            else
                --1.25 20 on bottom
                MazzleUI_Settings.sRaidFrames = { scale = 0.9, targetAdjust = 297, groupSpacing = 30, xAnchor = 460, yAnchor = -1169, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("up")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20125")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(true)
            end
        end
    elseif (theLayout == 2) then 
        if (MazzleUI_LastAspect == 3) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.6 40 on top mt side
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 282, groupSpacing = 25, xAnchor = 661, yAnchor = -5, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:PositionLayout("horizontal")
                self:sRaidGrow("down")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(false)
            else
                -- 1.6 20 top mt side
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 482, groupSpacing = -67, xAnchor = 457, yAnchor = -30, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("right")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(false)
            end
        elseif (MazzleUI_LastAspect == 2) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.33 40 on top mt side
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 282, groupSpacing = 25, xAnchor = 490, yAnchor = -10, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:PositionLayout("horizontal")
                self:sRaidGrow("down")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(false)
            else
                -- 1.33 20 top mt side
                MazzleUI_Settings.sRaidFrames = { scale = 0.90, targetAdjust = 481, groupSpacing = -57, xAnchor = 325, yAnchor = -35, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("right")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(false)
            end
        elseif (MazzleUI_LastAspect == 1) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.25 40 on top mt side
                MazzleUI_Settings.sRaidFrames = { scale = 0.9, targetAdjust = 282, groupSpacing = 25, xAnchor = 473, yAnchor = -10, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:PositionLayout("horizontal")
                self:sRaidGrow("down")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(false)
            else
                -- 1.25 20 top mt side
                MazzleUI_Settings.sRaidFrames = { scale = 0.9, targetAdjust = 490, groupSpacing = -67, xAnchor = 264, yAnchor = -15, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("right")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(false)
            end
        end
    elseif (theLayout == 3) then 
        if (MazzleUI_LastAspect == 3) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.6 40 on top mt on top
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 255, groupSpacing = 10, xAnchor = 521, yAnchor = -20, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle")
                self:sRaidGrow("down")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(false)
            else
                -- 1.6 20 top mt top
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 694, groupSpacing = -67, xAnchor = 480, yAnchor = -15, yMargin = 5, adjust125x = 190, adjust125y = 100}
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 495, groupSpacing = -67, xAnchor = 450, yAnchor = -15, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("right")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(false)
            end
        elseif (MazzleUI_LastAspect == 2) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.33 40 on top mt on top
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 251, groupSpacing = 10, xAnchor = 328, yAnchor = -17, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle")
                self:sRaidGrow("down")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(false)
            else
                -- 1.33 20 top mt top done
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 695, groupSpacing = -67, xAnchor = 284, yAnchor = -15, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("right")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(false)
            end
        elseif (MazzleUI_LastAspect == 1) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.25 40 on top mt on top
                MazzleUI_Settings.sRaidFrames = { scale = 0.9, targetAdjust = 262, groupSpacing = 10, xAnchor = 306, yAnchor = -17, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle")
                self:sRaidGrow("down")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(false)
            else
                --1.25 20 top mt top done
                MazzleUI_Settings.sRaidFrames = { scale = 0.9, targetAdjust = 702, groupSpacing = -67, xAnchor = 264, yAnchor = -15, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("right")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(false)
            end
        end
    elseif (theLayout == 4) then 
        if (MazzleUI_LastAspect == 3) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.6 40 on top 3-frame mt on top
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 395, groupSpacing = 5, xAnchor = 446, yAnchor = -5, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle")
                self:sRaidGrow("down")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(false)
            else
                -- 1.6 20 top 3-frame mt on top
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 875, groupSpacing = -57, xAnchor = 260, yAnchor = -30, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("right")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(false)
            end
        elseif (MazzleUI_LastAspect == 2) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.33 40 top 3-frame mt on top
                MazzleUI_Settings.sRaidFrames = { scale = 0.94, targetAdjust = 395, groupSpacing = 3, xAnchor = 283, yAnchor = -10, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle")
                self:sRaidGrow("down")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(false)
            else
                -- 1.33 20 top 3-frame mt on top
                MazzleUI_Settings.sRaidFrames = { scale = 0.90, targetAdjust = 884, groupSpacing = -57, xAnchor = 124, yAnchor = -35, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("right")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(false)
            end
        elseif (MazzleUI_LastAspect == 1) then
            if (MazzleUI_Status.inRaid40 or (MazzleUI_Status.inRaid20 and (not MazzleUI_Settings.AutoSwapRaid20))) then
                -- 1.25 40 on top 3-frame mt on top
                MazzleUI_Settings.sRaidFrames = { scale = 0.9, targetAdjust = 399, groupSpacing = 5, xAnchor = 255, yAnchor = -17, yMargin = 5, adjust125x = 190, adjust125y = 100}
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle")
                self:sRaidGrow("down")
                self:sRaidShowGroups(true)
                MazzleUI:groupTitles(false)
            else
                --1.25 20 top 3-frame mt on top
                MazzleUI_Settings.sRaidFrames = { scale = 0.9, targetAdjust = 834, groupSpacing = -67, xAnchor = 198, yAnchor = -15, yMargin = 5, adjust125x = 190, adjust125y = 100}
                MazzleUI_Settings.sRaidFrames = { scale = 0.9, targetAdjust = 875, groupSpacing = -58, xAnchor = 72, yAnchor = -45, yMargin = 5, adjust125x = 190, adjust125y = 100}
                self:sRaidGrow("right")
                sRaidFrames:chatScale(MazzleUI_Settings.sRaidFrames.scale)
                sRaidFrames:chatSetPosition("mazzle20")
                self:sRaidShowGroups(false)
                MazzleUI:groupTitles(false)
            end
        end
    end
end

function MazzleUI:sRaidShowGroups(showAll)
    if (showAll) then
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][1].attributes.groupFilter = "1"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][2].attributes.groupFilter = "2"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][3].attributes.groupFilter = "3"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][4].attributes.groupFilter = "4"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][5].attributes.groupFilter = "5"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][6].attributes.groupFilter = "6"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][7].attributes.groupFilter = "7"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][8].attributes.groupFilter = "8"
    else
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][1].attributes.groupFilter = "1"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][2].attributes.groupFilter = "2"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][3].attributes.groupFilter = "3"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][4].attributes.groupFilter = "4"
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][5].attributes.groupFilter = ""
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][6].attributes.groupFilter = ""
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][7].attributes.groupFilter = ""
        sRaidFrames.opt.GroupSetups[LSRF["By group"]][8].attributes.groupFilter = ""
    end
	--sRaidFrames:UpdateVisibility()
	sRaidFrames:SetGroupFilters()
end

function MazzleUI:groupTitles(newValue)
    sRaidFrames:S("ShowGroupTitles", newValue)
    for _,f in pairs(sRaidFrames.groupframes) do
    	sRaidFrames:UpdateTitleVisibility(f.header)
    end
end

function MazzleUI:sRaidGrow(growDirection)
    
	sRaidFrames.opt.Growth = growDirection
	sRaidFrames:SetGrowth()

end

function MazzleUI:oRA_ToggleTargetTarget(value)
    if (oRAOMainTank.secureframes) then oRAOMainTank:ToggleTargetTarget(value); end;

end

function MazzleUI:oRA_MTGrowUp(value)
    if (oRAOMainTank.header) then oRAOMainTank:ToggleGrowup(value); end;
end

function MazzleUI:oRA_MTPosition(thePosition)
    local xcenter
    if (thePosition == "top") then
        thePosition = "top-3"
    end
    if (oRAOMainTank) then
        local oraMTPosition = {}
        if (thePosition == "standard") then
            MazzleUI:oRA_MTGrowUp(true)
            MazzleUI_Settings.oRA = { width = 100, nameWidth = 52, nameIndent = 11, raidIconIndent = 0 }
            oRAOMainTank:SetScale(1.0)
            oraMTPosition["oRA_MainTankFrameMtMain"] = {["location"] = { ["x"] = -237, ["y"] = 226, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT",},}
        elseif (thePosition == "standard-125") then
            MazzleUI_Settings.oRA = { width = 100, nameWidth = 52, nameIndent = 11, raidIconIndent = 0 }
            MazzleUI:oRA_MTGrowUp(true)
            oRAOMainTank:SetScale(1.0)
            oraMTPosition["oRA_MainTankFrameMtMain"] = {["location"] = { ["x"] = -237, ["y"] = 389, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT",},}
        elseif (thePosition == "top") then
            MazzleUI_Settings.oRA = { width = 120, nameWidth = 62, nameIndent = 18, raidIconIndent = 1  }
            if (MazzleUI_LastAspect == 3) then
                xcenter = -48
            elseif (MazzleUI_LastAspect == 2) then
                xcenter = -72
            elseif (MazzleUI_LastAspect == 1) then
                xcenter = -71
            end
            oRAOMainTank:SetScale(1.0)
            MazzleUI:oRA_MTGrowUp(false)
            oraMTPosition["oRA_MainTankFrameMtMain"] = {["location"] = { ["x"] = xcenter, ["y"] = -22, ["point"] = "TOP", ["frame"] = "UIParent", ["to"] = "TOP",},}
        elseif (thePosition == "top-3") then
            MazzleUI_Settings.oRA = { width = 120, nameWidth = 62, nameIndent = 18, raidIconIndent = 1  }
            if (MazzleUI_LastAspect == 3) then
                xcenter = -45
            elseif (MazzleUI_LastAspect == 2) then
                xcenter = -45
            elseif (MazzleUI_LastAspect == 1) then
                xcenter = -46
            end
            oRAOMainTank:SetScale(1.0)
            MazzleUI:oRA_MTGrowUp(false)
            oraMTPosition["oRA_MainTankFrameMtMain"] = {["location"] = { ["x"] = xcenter, ["y"] = -10, ["point"] = "TOPRIGHT", ["frame"] = "UIParent", ["to"] = "TOP",},}
        elseif (thePosition == "petAdjust") then
            --MazzleUI:Print("Adjusting for pets")
            MazzleUI_Settings.oRA = { width = 100, nameWidth = 52, nameIndent = 11, raidIconIndent = 0 }
            MazzleUI:oRA_MTGrowUp(true)
            oRAOMainTank:SetScale(1.0)
            oraMTPosition["oRA_MainTankFrameMtMain"] = {["location"] = { ["x"] = -237, ["y"] = 538, ["point"] = "BOTTOMRIGHT", ["frame"] = "UIParent", ["to"] = "BOTTOMRIGHT",},}
        end
        MazzleUI:Frames_ConfigureFrameList(oraMTPosition)
        oRAOMainTank:SavePosition()
        MazzleUI:oRA_ToggleTargetTarget(true)
    --    if (thePosition == "top-3") then
    --		oRAOMainTank.db.profile.showmttt = true
    --		--oRAOMainTank:UpdateFrameShow()
    --		oRAOMainTank:oRA_MainTankUpdate()
    --    else
    --		oRAOMainTank.db.profile.showmttt = false
    --		--oRAOMainTank:UpdateFrameShow()
    --    end
    end
end

function MazzleUI:Set_RefreshRaidView()
    if (MazzleUI_Settings.manageRaidFrames) then
        MazzleUI:RaidViewSet()
    end
end

function MazzleUI:Get_DUFPartyPets()
    return DUF_Settings[DUF_INDEX].partypet.hide
end

function MazzleUI:Set_DUFPartyPets(shouldHide)
    DUF_Settings[DUF_INDEX].partypet.hide = shouldHide
    DUF_Main_UpdatePartyMembers()
end
