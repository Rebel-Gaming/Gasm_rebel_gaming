-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

function MazzleUI:Handle_Zoning()
    self:CheckCombatStatusManual()
    if (MazzleUI_Settings.Mazz3D.UseModels and Mazzifier_LastInstalledVersion and (Mazzifier_LastInstalledVersion > 0)) then
        local updateList = {}
	    for _,petType in pairs({"pet", "partypet1", "partypet2", "partypet3", "partypet4"}) do
	        if (UnitExists(petType)) then
        	    table.insert(updateList, unitDB[petType].Character)
        	end
        end
        if (#(updateList) > 0) then self:UpdateDirtyCharacters(updateList) end
    end
end

function MazzleUI:Handle_PlayerLogin()
    if (Mazzifier_Progress and (Mazzifier_Progress == 1)) then
        LoadAddOn("Mazzifier")
        Mazzifier:Schedule_Phase2()
    elseif ((not Mazzifier_Progress) or (Mazzifier_Progress and (Mazzifier_Progress < 2)) or (Mazzifier_LastInstalledVersion and (Mazzifier_LastInstalledVersion < Mazzifier_Version))) then
        Mazzifier_Progress = 0
        MazzleUI:LoadMazzifier();
    end
end

function MazzleUI:Handle_HealthChange()
    if (MazzleUI_Settings.HUD.UseHUD) then
        if (arg1 == "player") then
            self:HUD_PlayerHealthEvent()
        elseif (arg1 == "target") then
            self:HUD_TargetHealthEvent()
        end
    end
    if (MazzleUI_Settings.Mazz3D.UseModels and MazzleUI_Settings.Mazz3D.eventAnims) then
        if (UnitExists(arg1) and unitDB[arg1]) then
            local newHealth = UnitHealth(arg1)
            if (not self:Handle_DeathEvent(unitDB[arg1].Character, arg1)) then
                if (UnitAffectingCombat(arg1) and (newHealth < unitDB[arg1].Character.lastHealth)) then
                    self:PlayRandomFlinch(unitDB[arg1].Character)
                end
            end
            unitDB[arg1].Character.lastHealth = newHealth
         end
     end
end

function MazzleUI:Handle_DeathEvent(Character)
    local isAlive = (not UnitIsDead(Character.unitType))
        
    if (Character.isAlive and (not isAlive)) then
        Character.isAlive = nil
        self:StartAnimation(Character, "Death")
        return 1
    end
    if ((not Character.isAlive) and isAlive and (UnitHealth(Character.unitType)>1)) then
        Character.isAlive = true
        self:StartAnimation(Character, "Roar")
        return 1
    end
    return nil
end

function MazzleUI:Handle_GroupChanges()
    self:UpdateGroupSize();
end

function MazzleUI:Handle_PartyChange()
    self:UpdateGroupSize();
    if (MazzleUI_Settings.Mazz3D.UseModels) then self:UpdatePartyModels(); end;
end

function MazzleUI:Handle_LeaderChange()
	if (MazzleUI_Settings.ShowCharmIcons and (IsPartyLeader() or IsRaidLeader() or IsRaidOfficer())) then self:ShowCharmIcons(); else self:HideCharmIcons(); end;
end

function MazzleUI:Handle_AutoRes()
	getglobal("StaticPopup1"):Hide()
	AcceptResurrect()
end

function MazzleUI:Handle_RandomAnim()
    if (math.random(100)<20) then
        self:PlayRandomAnim(Mazz3D_Camera0)
    end
    if (UnitExists("party1")) then
        if (math.random(100)<20) then
            self:PlayRandomAnim(Mazz3D_Camera2)
        end
    end
    if (UnitExists("party2")) then
        if (math.random(100)<20) then
            self:PlayRandomAnim(Mazz3D_Camera3)
        end
    end
    if (UnitExists("party3")) then
        if (math.random(100)<20) then
            self:PlayRandomAnim(Mazz3D_Camera4)
        end
    end
    if (UnitExists("party4")) then
        if (math.random(100)<20) then
            self:PlayRandomAnim(Mazz3D_Camera5)
        end
    end
end        

function MazzleUI:Handle_AutoSummon()
	getglobal("StaticPopup1"):Hide()
	ConfirmSummon()
end

function MazzleUI:Handle_PVPMode()
    MazzleUI_Status.inPvP = UnitIsPVP("player")
    self:InstantiateEfficiencyMode()
end

function MazzleUI:Handle_AutoDismount()
    for i=0,15 do
        local currentBuff = GetPlayerBuffTexture(i)
        if currentBuff then
            if ((   string.find(string.lower(currentBuff), "_mount_") or 
                    string.find(string.lower(currentBuff), "spell_nature_swiftness")) or (
                    string.find(string.lower(currentBuff), "_qirajicrystal_"))) then
                CancelPlayerBuff(i)
           end
        end
    end
end

function MazzleUI:Handle_PlayerEnterCombat()
    if (MazzleUI_Settings.HUD.UseHUD) then
        self:ShowHUD()
        self:ThinHUD(MazzleUI_Settings.HUD.Transparency_FG_IC, MazzleUI_Settings.HUD.Transparency_IC)
        self:ShowHUDNumbers()
        self:HUD_PlayerHealthEvent()
        self:HUD_TargetHealthEvent()
        self:HUD_PlayerManaEvent()
        self:HUD_TargetManaEvent()
    end
    if (MazzleUI_Settings.Performance_Enabled.combat) then
        self:InstantiateEfficiencyMode()
    end
end

function MazzleUI:Handle_PlayerLeaveCombat()
    if (MazzleUI_Settings.HUD.UseHUD) then
        --self.HUD.target.health:Hide()
        --self.HUD.target.mana:Hide()
        self:ThinHUD(MazzleUI_Settings.HUD.Transparency_FG_OOC, MazzleUI_Settings.HUD.Transparency_OOC)
        self.HUD.player.health.tex:SetHeight(256)
        self.HUD.player.health.tex:SetTexCoord(0,1,0,1)
        self.HUD.player.mana.tex:SetHeight(256)
        self.HUD.player.mana.tex:SetTexCoord(0,1,0,1)
        self.HUD.target.health.tex:SetHeight(256)
        self.HUD.target.health.tex:SetTexCoord(1,0,0,1)
        self.HUD.target.mana.tex:SetHeight(256)
        self.HUD.target.mana.tex:SetTexCoord(1,0,0,1)
        if (MazzleUI_Settings.HUD.Transparency_OOC == 0) then
            self:HideHUDNumbers()
            self.HUD.visible = false;
        end
    end
    if (MazzleUI_Settings.Performance_Enabled.combat) then
        self:InstantiateEfficiencyMode()
    end
end

function MazzleUI:Handle_ModelChange()
    local updateList = {}
    if (UnitExists(arg1) and unitDB[arg1]) then
        table.insert(updateList, unitDB[arg1].Character)
        self:UpdateDirtyCharacters(updateList)
    end
end

function MazzleUI:Handle_PetEvent()
    local updateList = {}
    if (UnitExists(arg1) and unitDB[arg1] and unitDB[arg1].petname and UnitExists(unitDB[arg1].petname)) then
        table.insert(updateList, unitDB[unitDB[arg1].petname].Character)
        unitDB[unitDB[arg1].petname].Character.lastHealth = UnitHealth(unitDB[arg1].petname)
        self:UpdateDirtyCharacters(updateList)
    end
end

function MazzleUI:Handle_CombatStatus()
	if(event == "PLAYER_ENTER_COMBAT" or event == "PLAYER_REGEN_DISABLED") then
		MazzleUI_Status.PlayerIsInCombat = true
		self:Handle_PlayerEnterCombat()
		if(event == "PLAYER_REGEN_DISABLED") then
			MazzleUI_Status.PlayerIsRegenOn = false
		end
	elseif(event == "PLAYER_LEAVE_COMBAT" or event == "PLAYER_REGEN_ENABLED") then
		if(event == "PLAYER_LEAVE_COMBAT" and MazzleUI_Status.PlayerIsRegenOn) then
			MazzleUI_Status.PlayerIsInCombat = false
			self:Handle_PlayerLeaveCombat()
		elseif(event == "PLAYER_REGEN_ENABLED") then
			MazzleUI_Status.PlayerIsInCombat = false
			MazzleUI_Status.PlayerIsRegenOn = true
			self:Handle_PlayerLeaveCombat()
		end
	end
end

function MazzleUI:Handle_JuiceChange()
    if (arg1 == "player") then
        self:HUD_PlayerManaEvent()
    elseif (arg1 == "target") then
        self:HUD_TargetManaEvent()
    end
end

function MazzleUI:Handle_TargetChange()
    if (MazzleUI_Settings.HUD.UseHUD) then
        self:HUD_TargetHealthEvent()
        self:HUD_TargetManaEvent()
    end
    self:CheckCombatStatusManual()
	if (UnitExists("target")) then
        if (MazzleUI_Settings.Mazz3D.UseModels) then
            local updateList = {}
            table.insert(updateList, Mazz3D_Camera1)
            self:ResetCameraGuesses()
            self:GetCamera()
            self:ResetAnimation(Mazz3D_Camera1)
            Mazz3D_Camera1.lastHealth = UnitHealth("target")
            self:UpdateDirtyCharacters(updateList)
        end
        if (MazzleUI_Settings.HUD.ShowRange and self.HUD.visible) then
            local _,_,tur, _, _ = self:MetroStatus("MazzleUITargetUpdate")
        	if (not tur) then self:StartMetro("MazzleUITargetUpdate"); end;
        end
        if(UnitIsFriend("player","target") and UnitIsPlayer("target") and not UnitIsUnit("player","target")) then
            self.TargetButtons = true
            if (not (MazzleUI_Settings.HUD.ShowRange and self.HUD.visible)) then
            	self:StartMetro("MazzleUITargetUpdate")
            end
            self.Buttons.Whisper:Show()
        else
            if (not (MazzleUI_Settings.HUD.ShowRange and self.HUD.visible)) then
            	self:StopMetro("MazzleUITargetUpdate")
            end
            self.TargetButtons = false
            self.Buttons.Follow:Hide()
            self.Buttons.Inspect:Hide()
            self.Buttons.Whisper:Hide()
            self.Buttons.Trade:Hide()
        end
    else
        self:StopMetro("MazzleUITargetUpdate")
        self.HUD.target.rangeText.textString:SetText("")
    end
end

function MazzleUI:HandleTargetButton(buttonType)
    if (buttonType == "Follow") then
        FollowUnit("target");
    elseif (buttonType == "Inspect") then
    	InspectUnit("target");
    elseif (buttonType == "Whisper") then
    	local name, realm = UnitName("target");
    	local playerName, playerRealm = UnitName("player");
    	if(realm) then
    		if (realm == playerRealm) then
    			ChatFrame_SendTell(name)
    		else
    			ChatFrame_SendTell(name.."-"..realm);
    		end
    	else
    		ChatFrame_SendTell(name)
    	end
    elseif (buttonType == "Trade") then
        InitiateTrade("target");
    end
end

function MazzleUI:Handle_ShowBags()
    if (Baggins) then
        Baggins:OpenAllBags()
    else
    	OpenAllBags(true)
    end
end

function MazzleUI:Handle_CloseBags()
    if (Baggins) then
        Baggins:CloseAllBags()
    else
    	ContainerFrame1.backpackWasOpen = nil
    	CloseAllBags()
    end
end

-- Following function is based on Grennon's AltClickToTrade which is based 
-- on GMail 1.x which was ported from CT_MailMod pre-1.5
-- Same exact thing except removed auto-trade initiation
-- and modulated via an option in MazzleOptions

function MazzleUI:HandleContainerModifiedClick(...)
  if  (...) == "LeftButton" and IsAltKeyDown() and not CursorHasItem() then
    self.bag, self.slot = this:GetParent():GetID(), this:GetID()
    if SendMailFrame:IsVisible() and not IsAddOnLoaded("Postal") then
      PickupContainerItem(self.bag, self.slot)
      ClickSendMailItemButton()
      return
    elseif TradeFrame:IsVisible() then
      for i = 1, 6 do
        if not GetTradePlayerItemLink(i) then
	  PickupContainerItem(self.bag, self.slot)
          ClickTradeButton(i)
	  return
        end
      end
    elseif AuctionFrameAuctions and AuctionFrameAuctions:IsVisible() and not IsAddOnLoaded("Fence") then
      PickupContainerItem(self.bag, self.slot)
      ClickAuctionSellItemButton()
      return
    end
  end
  self.hooks["ContainerFrameItemButton_OnModifiedClick"](...)
end

local currentRedValue, cra

function MazzleUI:Handle_AggroSelfGain()
    currentRedValue = 0.4
    cra = - 0.1
    self:ScheduleRepeatingEvent("Mazz3D_AggroTimer",self.UpdateAggro, .1, self)
end

function MazzleUI:UpdateAggro()
    currentRedValue = currentRedValue + cra
    if (currentRedValue<0) then currentRedValue = 0.1; cra = 0.1;
    elseif (currentRedValue>0.3) then currentRedValue = 0.2; cra =  - 0.1; end
    self.panelTextures.l.tex:SetVertexColor(1, currentRedValue, currentRedValue)
    self.panelTextures.ml.tex:SetVertexColor(1, currentRedValue, currentRedValue)
    self.panelTextures.mr.tex:SetVertexColor(1, currentRedValue, currentRedValue)
    self.panelTextures.r.tex:SetVertexColor(1, currentRedValue, currentRedValue)
    self.panelTextures.cave.tex:SetVertexColor(1, currentRedValue, currentRedValue)
    MinimapBorder:SetVertexColor(1, currentRedValue, currentRedValue)
end

function MazzleUI:Handle_AggroSelfLose()
	self:CancelScheduledEvent("Mazz3D_AggroTimer")
    self.panelTextures.l.tex:SetVertexColor(1, 1, 1)
    self.panelTextures.ml.tex:SetVertexColor(1, 1, 1)
    self.panelTextures.mr.tex:SetVertexColor(1, 1, 1)
    self.panelTextures.r.tex:SetVertexColor(1, 1, 1)
    self.panelTextures.cave.tex:SetVertexColor(1, 1, 1)
    MinimapBorder:SetVertexColor(1, 1, 1)
end

function MazzleUI:Handle_MovingCaptureBar()
    if (InCombatLockdown()) then
        self:ScheduleLeaveCombatAction(self.Handle_MovingCaptureBar, self)
    elseif (WorldStateCaptureBar1) then 
        WorldStateCaptureBar1:ClearAllPoints();
        WorldStateCaptureBar1:SetPoint("LEFT",UIParent,"LEFT",5,95);
    end
end