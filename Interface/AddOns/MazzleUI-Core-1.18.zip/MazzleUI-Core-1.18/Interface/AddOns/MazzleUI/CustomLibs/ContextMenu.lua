-- Context Menu
--
-- By TigerHeart of Argent Dawn
-- Patch 2.2 Fixes by meio September 25, 2007
-- 
-- Only call after "PLAYER_LOGIN" so bindings are set properly.
--
-- KNOWN ISSUES: 
-- - Not saving position after relogging.
--   to fix, you need to save the positioning yourself, and call lib:SetPosition() to restore it upon login.

-- Arguments:
-- name = name of frame to create.
-- cols = number of columns. Default: 4
-- rows = number of rows. Default: 4
-- startid = ActionID to start with. Default: last actionslots available
-- showstartup = "1" to show on startup or "0" to not show. Default: not show
-- movetomouse = true/false to either have it snap to mouse, or not.
-- debug = true to show state changes in the header

local MAJOR_VER = "ContextMenu-1.0"
local MINOR_VER = 1
--local MINOR_VER = 2

local lib = {}
function lib:Create(name, rows, cols, startid, showstartup, movetomouse, debug)
	assert(not self.frameName, "Only one frame per library instance!")
	assert(name, "must declare a name for the menu!")
	assert(not getglobal(name),name.." already exists!")
	-- store frame name for later functions.
	self.frameName = name
	----------
	-- set defaults
	----------
	local useArray
	local rows = rows or 4
	local cols = cols or 4
	if type(startid=="nil") then
		startid = (120-((rows*cols)*2))+1 -- *2 is for two pages.
	elseif(type(startid) == "table") then
		useArray = true
	end
	assert(not useArray or (useArray and #startid < rows*cols),name.." does not have enough allocated ID's!")
	--if useArray and #startid < rows*cols then self:error("Not enough allocated ID's for context menu!") end
	local showstartup = showstartup and "1" or "0"
	----------
	-- create main anchor
	----------
	local anchor = CreateFrame("Button", name, UIParent, "SecureAnchorButtonTemplate")
	--anchor:SetPoint("BOTTOMRIGHT", UIParent,"BOTTOMRIGHT", -366, 215)
	anchor:SetPoint("TOPLEFT", UIParent,"TOPLEFT")
	anchor:EnableMouse(0)
	anchor:SetWidth(25)
	anchor:SetHeight(25)
	anchor:RegisterForClicks("AnyDown")
	-- raise events to children
	anchor:SetAttribute("*childraise*", true)
	-- send state on click (AnchorButton only has one state)
	anchor:SetAttribute("*childstate*", "^keybinds")
	
	anchor.rows = rows
	anchor.cols = cols

	----------
	-- create main header. This is the 'workhorse'
	-- state descriptions:
	-- 0 - hide
	-- 1-3 - show that bar.
	-- 4-5 - show bar with paging. Paging only works on mouseover.
	-- 3 states for no mouseover so that we change from page 2 to 1
	--   we don't change the menu's position.
	-- thus page2 = state 3, and page1 starts at 1, and from then on is 2.
	----------
	local hdr = CreateFrame("Frame", "$parentHeader", anchor, "SecureStateHeaderTemplate")
	-- set it so we can move it around
	if not hdr:IsUserPlaced() then
		hdr:SetMovable(true)
		hdr:SetPoint("CENTER",UIParent,"CENTER")
		hdr:SetUserPlaced(true)
	end
	-- also we want the layout positioning to be saved as well
	-- hdr:SetUserPlaced(true)
	hdr.isdebugging = debug
	-- set state based on 'key' anchor keybind being pressed.
	hdr:SetAttribute("statemap-anchor-keybinds", "0-1")
	-- set state based on 'click' anchor being clicked.
	hdr:SetAttribute("statemap-anchor-click", "0:2;*:0;")
	-- set state based on button being moused over.
	hdr:SetAttribute("statemap-anchor-enter", "1,2:4;3:5")
	-- set state based on mouse leaving button.
	hdr:SetAttribute("statemap-anchor-leave", "4:2;5:3")
	-- accept paging from page buttons
	hdr:SetAttribute("statemap-page", "$input")
	-- set location on show to cursor
	if movetomouse then
		hdr:SetAttribute("headofsrelpoint", "cursor")
		hdr:SetAttribute("headofsx", "1:0")
		hdr:SetAttribute("headofsy", "1:0")
	end
	-- clear bindings in state 0-3, state 4-5 add paging buttons.
	hdr:SetAttribute("statebindings","0-3:;4-5:paging")
	-- set initial state
	hdr:SetAttribute("state", showstartup or "0")
	-- debug code
	hdr.StateChanged = function(self,state)
		if self.isdebugging then ChatFrame1:AddMessage(state) end
	end
	-- add header to anchors
	anchor:SetAttribute("anchorchild", hdr)

	----------
	-- page up button
	----------
	local pageu = CreateFrame("Button", "$parentPageUp", anchor, "SecureActionButtonTemplate")
	-- reuse anchoring points
	pageu:SetAllPoints(anchor)
	pageu:SetAttribute("hidestates","0")
	-- export the state to the header as 'page'. Required for header to process the change!
	pageu:SetAttribute("exportstate","page")
	-- change from page 5 to 4
	pageu:SetAttribute("newstate","5:4")
	-- set binding. This only operates if the button is visible.
	pageu:SetAttribute("bindings-paging", "MOUSEWHEELUP")
	-- add the button to the header
	hdr:SetAttribute("addchild", pageu)

	----------
	-- page down button
	----------
	local paged = CreateFrame("Button", "$parentPageDown", anchor, "SecureActionButtonTemplate")
	paged:SetAllPoints(anchor)
	paged:SetAttribute("hidestates", "0")
	paged:SetAttribute("exportstate", "page")
	paged:SetAttribute("newstate", "4:5")
	paged:SetAttribute("bindings-paging", "MOUSEWHEELDOWN")
	hdr:SetAttribute("addchild", paged)

	-- declare locals
	local relpt,relptr,numbtn,first = hdr, hdr,0,nil

	hooksecurefunc("SecureStateAnchor_RunChild", function(self,button, remapButton)
		--ChatFrame1:AddMessage(this:GetName())
		-- pass up if we are not with the context menu.
		if not this.NeedsTooltip then return end;
		-- otherwise handle enter/leave
		if button == "OnEnter" then
			ActionButton_SetTooltip(self);
		elseif button == "OnLeave" then
			this.updateTooltip = nil;
			GameTooltip:Hide();
		end
	end)

	----------
	-- setup buttons
	----------
	for i = 0,rows-1 do
		first=true
		for i2 = 0,cols-1 do
			local thisID = useArray and table.remove(startid) or startid+numbtn
			-- inherits from SecureAnchorEnterTemplate so we can get enter/leave information and propogate it to the parent
			-- inherits from SecureActionButtonTemplate and ActionBarButtonTemplate so it will act and look like like a regular button
			local btn = CreateFrame("CheckButton", "$parentButton"..(numbtn+1),anchor,"SecureActionButtonTemplate, ActionBarButtonTemplate, SecureAnchorEnterTemplate")
			----------
			-- handle mouseover
			----------
			-- 'raise' the OnEnter event to the 'child'
			btn:SetAttribute("*childraise-OnEnter",true)
			-- value to export to 'child' for entering
			btn:SetAttribute("*childstate-OnEnter","enter")
			-- value to export to 'child' for leaving
			btn:SetAttribute("*childstate-OnLeave","leave")
			-- we need to set the 'anchorchild' to the hdr, even though technically we are a child
			-- so that the header will get and deal with the enter/leave events
			btn:SetAttribute("anchorchild", hdr)
			-- signal that this button is handled via the context menu.
			btn.NeedsTooltip = true	
			----------
			-- setup button display/positioning and processing info
			----------
			-- required for handling of button info
			btn:SetScript("OnAttributeChanged", ActionButton_UpdateAction)
			-- handle column/row positioning.
			btn:SetPoint((first and "TOP" or "LEFT"), (first and relptr or relpt), (first and "BOTTOM" or "RIGHT"),(first and 0 or 3),(first and -3 or 0))
			-- display 'grid' when buttons are empty!
			btn.showgrid = 1
			-- save point of this row for next row.
			relptr = first and btn or relptr
			first=nil
			-- save point of this button for next col.
			relpt = btn

			----------
			-- setup button 'events'
			----------
			-- set up initial states (0=hide, 1=page1 with set position, 2=page1 so remap to 1, 3=page2)
			btn:SetAttribute("statebutton", "0:S0;1,2,4:S1;3,5:S2")
			-- both pages are of type 'action'
			btn:SetAttribute("type-S1", "action")
			btn:SetAttribute("type-S2", "action")
			btn:SetAttribute("type-enter", "state")
			-- setup button->actionID relationships
			btn:SetAttribute("*action-S1", thisID)
			--btn:SetAttribute("*action-S2", thisID+rows*cols+1)
			btn:SetAttribute("*action-S2", thisID+rows*cols)
			-- set it to hide on state S0
			btn:SetAttribute("hidestates", "0")
			-- add the child to the header.
			hdr:SetAttribute("addchild", btn)
			numbtn=numbtn+1
		end
	end
end

-- set menu to close when you click a button.
function lib:SetCloseOnClick(val)
	assert(self.frameName, "No frame to modify!")
	local frame = getglobal(self.frameName)
	local pageup = getglobal(self.frameName.."PageUp")
	local pagedown = getglobal(self.frameName.."PageDown")
	for x=1, frame.rows*frame.cols do
		local btn = getglobal(self.frameName.."Button"..x)
		-- if we are set to close when button is pressed, then set this attribute, otherwise remove it.
		if val then
			-- remap to 0
			btn:SetAttribute("newstate","*:0")
		else
			btn:SetAttribute("newstate",nil)
		end
	end
end

-- clear all bindings on an arbitrary button
function lib:ClearBindings()
    local theBinding = 'CLICK ' .. self.frameName .. ':LeftButton'
	while GetBindingKey(theBinding) do
		SetBinding(GetBindingKey(theBinding), nil)
	end
end

-- set a keybind to an arbitrary button
function lib:SetShowBinding(bind)
	if bind then
		SetBindingClick(bind, self.frameName)
	end
end

-- set page up binding for a context menu
function lib:SetPageUpBinding(bindUp)
	getglobal(self.frameName.."PageUp"):SetAttribute("bindings-paging",bindUp)
end

-- set page down binding for a context menu
function lib:SetPageDownBinding(bindDown)
	getglobal(self.frameName.."PageDown"):SetAttribute("bindings-paging",bindDown)
end

function lib:CreateClickButton(point,parent,relpoint,x,y,width,height)
	local anchor = CreateFrame("Button", self.frameName.."ClickFrame", UIParent, "SecureAnchorButtonTemplate")
	anchor:SetPoint(point,parent,relpoint,x,y)
--	anchor:EnableMouse(1)
	anchor:SetWidth(width)
	anchor:SetHeight(height)
	anchor:RegisterForClicks("AnyDown")
	-- raise events to children
	anchor:SetAttribute("*childraise*", true)
	-- send state on click (AnchorButton only has one state)
	anchor:SetAttribute("*childstate*", "^click")
	anchor:SetAttribute("anchorchild",getglobal(self.frameName.."Header"))
end

function lib:SetMoveToMouse(movetomouse)
	local hdr = getglobal(self.frameName.."Header")
	if movetomouse then
		hdr:SetAttribute("headofsrelpoint", "cursor")
		hdr:SetAttribute("headofsx", "1:0")
		hdr:SetAttribute("headofsy", "1:0")
	else
		hdr:SetAttribute("headofsrelpoint", nil)
		hdr:SetAttribute("headofsx", nil)
		hdr:SetAttribute("headofsy", nil)	
	end
end

function lib:OnSetPosition(callback,callbackself)
	self.setposcallback = callback
	local f=getglobal(self.frameName.."Header")
	if not self.hdrSetPoint then
		self.hdrSetPoint = f.SetPoint
	end
	if callback then
		if callbackself then
			f.SetPoint = function(...)
				self.hdrSetPoint(...)
				self.setposcallback(callbackself,f:GetPoint())
			end					
		else
			f.SetPoint = function(...)
				self.hdrSetPoint(...)
				self.setposcallback(f:GetPoint())
			end
		end
	else
		f.SetPoint = self.hdrSetPoint
		self.hdrSetPoint = nil
	end
end

function lib:SetPosition(rel,parent,relpt,x,y)
	if InCombatLockdown() then
        self:ScheduleLeaveCombatAction(self.SetPosition, self, rel,parent,relpt,x,y)
		return
	end
	local hdr = getglobal(self.frameName.."Header")
	hdr:SetMovable(true)
	hdr:SetUserPlaced(true)
	hdr:ClearAllPoints()
	hdr:SetPoint(rel,parent,relpt,x,y)
end
-- register the library with Ace.
AceLibrary:Register(lib, MAJOR_VER, MINOR_VER)