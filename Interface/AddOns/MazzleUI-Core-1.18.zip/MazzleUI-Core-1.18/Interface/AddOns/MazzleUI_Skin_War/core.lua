function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Skin_War\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Skin_War\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Skin_War\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Skin_War\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Skin_War\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Skin_War\\MazzleUICastingBarBorder",
            chatborder = "Interface\\MazzleUI_Skin_War\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Skin_War\\MazzleUIMinimapBorder",
        },
    }
end