MazzleOptions_VERSION_MESSAGE			= MazzleOptions_Version or "Beta";
MazzleOptions_LOADED_MESSAGE			= "|CFFFF0000MazzleOptions v|CFFFFFFFF"..MazzleOptions_VERSION_MESSAGE.."|CFFFF0000 loaded.";
