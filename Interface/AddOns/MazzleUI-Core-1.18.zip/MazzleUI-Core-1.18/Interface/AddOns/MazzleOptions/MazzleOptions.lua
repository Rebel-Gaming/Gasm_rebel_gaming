-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

MazzleOptions = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0", "AceDB-2.0", "AceEvent-2.0")
local L = AceLibrary("AceLocale-2.2"):new("MazzleOptions")

MazzleOptions_Version = "0.92b"

local WidgetPool = {}
WidgetPool.YesNoPool = {}
WidgetPool.CheckButtonPool = {}
WidgetPool.MenuPool = {}
WidgetPool.SliderPool = {}
WidgetPool.ButtonPool = {}
WidgetPool.TextboxPool = {}
WidgetPool.PerformancePool = {}
WidgetPool.TitleButtonPool = {}

function MazzleOptions:OnLoad()
	this:RegisterEvent("ADDON_LOADED");
	tinsert(UISpecialFrames, "MazzleOptions_Frame");

end

function MazzleOptions:OnEvent(event)
	if (event=="ADDON_LOADED" and arg1=="MazzleOptions" ) then
	    DEFAULT_CHAT_FRAME:AddMessage(MazzleOptions_LOADED_MESSAGE,0.0,1.0,0.0);

        MazzleOptions.Actives = {}
        MazzleOptions.ScrollPosition = {}
        MazzleOptions:Build_Options()
        MazzleOptions:Build_AddOn_Directory()
        MazzleOptions:SetupHelp()
        
        if (not MazzleUI_Settings.OptionsLastTopic) then
            MazzleUI_Settings.OptionsMode = "Options"
            MazzleUI_Settings.OptionsLastTopic = 1
        end
        MazzleOptions:SetContentData()

        local OptionsButton
        if (MazzleOptions_SettingsInfo.NumTopics > MazzleOptions_HelpInfo.NumTopics) then
            self.MaxTopics = MazzleOptions_SettingsInfo.NumTopics; else self.MaxTopics = MazzleOptions_HelpInfo.NumTopics;
        end
        for i=1, self.MaxTopics, 1 do
            OptionsButton = CreateFrame("Button", "MazzleOptionsTopic"..i, MazzleOptions_Topics_ScrollChildFrame, "MazzleOptionsTitleButtonTemplate");
            OptionsButton:SetID(i);
            OptionsButton.isActive = 1;
            if ( i > 1 ) then
                OptionsButton:SetPoint("TOPLEFT", "MazzleOptionsTopic"..(i-1),"BOTTOMLEFT", 0, 0)
            else
                OptionsButton:SetPoint("TOPLEFT", "MazzleOptions_Topics_ScrollChildFrame", "TOPLEFT", -10, -5);
            end
        end
        MazzleOptions.Initialized = true
        MazzleOptions_Frame:Show()
	end
end

function MazzleOptions:Show()
    if (MazzleOptions.Initialized) then
    	MazzleOptions_Frame:Show();
        self:PopulateTopics()
        self:LayoutWidgets(MazzleUI_Settings.OptionsLastTopic)
        self:RestoreScrollPosition()
    	self:ScheduleRepeatingEvent("MazzleOptions_AnimTimer",self.Animate, 0.2, self)
        self:ScheduleEvent(function() MazzleOptions_Topics_ScrollFrame:UpdateScrollChildRect(); end, 1, self)
    	self.needsReload = false
    end
end

function MazzleOptions:Hide()
	self:CancelScheduledEvent("MazzleOptions_AnimTimer")
	MazzleOptions_Frame:Hide();
	if (self.needsReload) then MazzleOptions_ReloadUIFrame:Show() end
end

function MazzleOptions:SetContentData()
    if (MazzleUI_Settings.OptionsMode == "Options") then
        self.ContentData = MazzleOptions_SettingsInfo
        MazzleOptions_HelpButton:UnlockHighlight()
        MazzleOptions_OptionsButton:LockHighlight()
    else
        self.ContentData = MazzleOptions_HelpInfo
        MazzleOptions_OptionsButton:UnlockHighlight()
        MazzleOptions_HelpButton:LockHighlight()
    end
    MazzleUI_Settings.OptionsLastTopic = 1
end

function MazzleOptions:CategoryButtonOnClick(buttonID)
    if (buttonID == 1) then
        MazzleUI_Settings.OptionsMode = "Options"
    else
        MazzleUI_Settings.OptionsMode = "Help"
    end
    MazzleOptions:SetContentData()
    MazzleOptions:PopulateTopics()
    MazzleOptions:LayoutWidgets(MazzleUI_Settings.OptionsLastTopic)
    MazzleOptions:RestoreScrollPosition()
end

function MazzleOptions:Animate()
    if (MazzleOptionsWaveTexture1:IsVisible()) then
        MazzleOptionsWaveTexture1:Hide()
        MazzleOptionsWaveTexture2:Show()
    else
        MazzleOptionsWaveTexture1:Show()
        MazzleOptionsWaveTexture2:Hide()
    end
end

function MazzleOptions:PopulateTopics()
    local totalWidth = 280
    local OptionsButton, lastPoint
    local repeatString, repeatWidth, repeatLength, entryString
    if ( self.ContentData.NumTopics > 0 ) then
        for i=1, self.MaxTopics, 1 do
            OptionsButton = getglobal("MazzleOptionsTopic"..i);
            if (i <= self.ContentData.NumTopics) then
                OptionsButton:SetText(self.ContentData.Contents[i].name);
                OptionsButton:SetHeight(OptionsButton:GetTextHeight() + 6);
                if (string.sub(self.ContentData.Contents[i].name, 1,1) == " ") then
                    repeatString = "-"
                    repeatWidth = 4
                    entryString = "|CFF00FF00 "..self.ContentData.Contents[i].name.." |CFFFF0000"
                    repeatLength = (((totalWidth - OptionsButton:GetTextWidth())/2)/repeatWidth)
                    OptionsButton:SetText(TEXT("|CFFFF0000"..string.rep(repeatString, repeatLength)..entryString..string.rep(repeatString, repeatLength)))
                end
    
                if (self.ContentData.Contents[i].tooltipText) then
                    OptionsButton.tooltipText = self.ContentData.Contents[i].tooltipText
                end
                OptionsButton:Show();
           else
                OptionsButton:Hide();
           end
           _, lastPoint, _, _, _ = OptionsButton:GetPoint()
            if (MazzleUI_Settings.OptionsMode == "Options") then
                if (i>1) then OptionsButton:ClearAllPoints(); OptionsButton:SetPoint("TOPLEFT", "MazzleOptionsTopic"..(i-1),"BOTTOMLEFT", 0, 0); end
                getglobal("MazzleOptionsTopic"..i.."Text"):ClearAllPoints()
                getglobal("MazzleOptionsTopic"..i.."Text"):SetPoint("TOP", 0, -4)
            else
                if (i>1) then OptionsButton:ClearAllPoints(); OptionsButton:SetPoint("TOPLEFT", "MazzleOptionsTopic"..(i-1),"BOTTOMLEFT", 0, -5); end
                getglobal("MazzleOptionsTopic"..i.."Text"):ClearAllPoints()
                getglobal("MazzleOptionsTopic"..i.."Text"):SetPoint("LEFT", 10, 0)
            end                

        end
    end
    MazzleOptions_Topics_ScrollFrame:UpdateScrollChildRect();
end


function MazzleOptions:TopicButton_OnClick(buttonID)
	PlaySound("igQuestListSelect");
	MazzleOptions:SaveScrollPosition()
	MazzleUI_Settings.OptionsLastTopic = buttonID
    MazzleOptions:LayoutWidgets(buttonID)
    MazzleOptions:RestoreScrollPosition()
end

function MazzleOptions:SaveScrollPosition()
    if (MazzleUI_Settings.OptionsMode == "Options") then
        self.ScrollPosition[MazzleUI_Settings.OptionsLastTopic] = MazzleOptions_Contents_ScrollFrame:GetVerticalScroll()
    end
end

function MazzleOptions:RestoreScrollPosition()
    if  ((MazzleUI_Settings.OptionsMode == "Options") and self.ScrollPosition[MazzleUI_Settings.OptionsLastTopic]) then
        --MazzleOptions_Contents_ScrollFrame:SetVerticalScroll(self.ScrollPosition[MazzleUI_Settings.OptionsLastTopic])
        -- for some reason, scroll bar does not move though contents do.  Setting it on a timer as a quick workaround
        self:ScheduleEvent(function() MazzleOptions_Contents_ScrollFrame:SetVerticalScroll(MazzleOptions.ScrollPosition[MazzleUI_Settings.OptionsLastTopic]); end, 0.05, self)
        
    else
        MazzleOptions_Contents_ScrollFrame:SetVerticalScroll(0)
    end
end

function MazzleOptions:CreateWidget(requestedType, requestedAnchor, requestedParent, anchorType, xadjust, yadjust, widgetID)
    if (not xadjust) then
        xadjust = 0
    end
    if (not yadjust) then
        yadjust = 0
    end

    local newWidgetName

    local newWidgetType, newWidgetName, newWidgetTemplate, newWidgetList, newWidget
    if (requestedType == "YesNo") then
         newWidgetType = "Frame"
         newWidgetTemplate = "MazzleOptions_YesNoTemplate"
         newWidgetList = "YesNoPool"
    elseif (requestedType == "CheckButton") then
         newWidgetType = "CheckButton"
         newWidgetTemplate = "MazzleOptions_CheckButtonTemplate"
         newWidgetList = "CheckButtonPool"
         yadjust = yadjust + 12
    elseif (requestedType == "Slider") then
         newWidgetType = "Slider"
         newWidgetTemplate = "MazzleOptions_SliderTemplate"
         newWidgetList = "SliderPool"
    elseif (requestedType == "Menu") then
         newWidgetType = "Frame"
         newWidgetTemplate = "MazzleOptions_ButtonDropDownTemplate"
         newWidgetList = "MenuPool"
    elseif (requestedType == "Textbox") then
         newWidgetType = "Frame"
         newWidgetTemplate = "MazzleOptions_TextBoxTemplate"
         newWidgetList = "TextboxPool"
    elseif (requestedType == "Button") then
         newWidgetType = "Button"
         newWidgetTemplate = "MazzleOptions_ButtonTemplate"
         newWidgetList = "ButtonPool"
    elseif (requestedType == "PerformanceEntry") then
         newWidgetType = "Frame"
         newWidgetTemplate = "MazzleOptions_PerformanceTemplate"
         newWidgetList = "PerformancePool"
    elseif (requestedType == "TitleButton") then
         newWidgetType = "Button"
         newWidgetTemplate = "MazzleOptionsTitleButtonTemplate"
         newWidgetList = "TitleButtonPool"
    end

    for i=1, #(WidgetPool[newWidgetList]), 1 do
        if (WidgetPool[newWidgetList][i].isFree) then
            --self:Print ("--> Found an existing widget to reuse.")
            newWidget = WidgetPool[newWidgetList][i]
            newWidgetName = WidgetPool[newWidgetList][i].widgetName
        end
    end
    if (not newWidget) then
        newWidget = {}
        newWidget.widgetName = "MazzleOptions_"..requestedType..(#(WidgetPool[newWidgetList])+1)
        newWidget.frame = CreateFrame(newWidgetType, newWidget.widgetName, requestedParent, newWidgetTemplate);
        table.insert(WidgetPool[newWidgetList], newWidget)
    end
    newWidget.isFree = false
    newWidget.frame:SetParent(requestedParent)
	newWidget.frame:ClearAllPoints()
	if (anchorType == "top") then
        newWidget.frame:SetPoint("TOPLEFT", requestedAnchor, "TOPLEFT", (5 + xadjust), (-10 + yadjust));
	elseif (anchorType == "topright") then
        newWidget.frame:SetPoint("TOPRIGHT", requestedAnchor, "TOPRIGHT", (-30 + xadjust), (-20 + yadjust));
	elseif (anchorType == "middle") then
        newWidget.frame:SetPoint("TOPLEFT", requestedAnchor, "BOTTOMLEFT", xadjust, (-10 + yadjust));
	elseif (anchorType == "right") then
        newWidget.frame:SetPoint("TOPRIGHT", requestedAnchor, "BOTTOMRIGHT", xadjust, (0 + yadjust));
	elseif (anchorType == "aboveright") then
        newWidget.frame:SetPoint("BOTTOMRIGHT", requestedAnchor, "TOPRIGHT", xadjust, (0 + yadjust));
	elseif (anchorType == "center") then
        newWidget.frame:SetPoint("TOP", requestedAnchor, "BOTTOM", xadjust, (-20 + yadjust));
    end
    if (requestedType == "YesNo") then
        newWidget.labelName = newWidget.widgetName.."Title"
        newWidget.checkButtonYes = newWidget.widgetName.."_CheckButtonYes"
        newWidget.checkButtonNo = newWidget.widgetName.."_CheckButtonNo"
    elseif (requestedType == "CheckButton") then
        newWidget.labelName = newWidget.widgetName.."Text"
    elseif (requestedType == "Textbox") then
        newWidget.labelName = newWidget.widgetName.."_Text"
    elseif (requestedType == "Slider") then
        newWidget.labelName = newWidget.widgetName.."Text"
        newWidget.lowName = newWidget.widgetName.."Low"
        newWidget.highName = newWidget.widgetName.."High"
    elseif (requestedType == "Menu") then
        newWidget.labelName = newWidget.widgetName.."Label"
    elseif (requestedType == "Button") then
        newWidget.labelName = newWidget.widgetName.."Label"
    elseif (requestedType == "PerformanceEntry") then
        newWidget.labelName = newWidget.widgetName.."Label"
        newWidget.headerName = newWidget.widgetName.."Header"
        newWidget.checkButton1 = newWidget.widgetName.."_CheckButton1"
        newWidget.checkButton2 = newWidget.widgetName.."_CheckButton2"
        newWidget.checkButton3 = newWidget.widgetName.."_CheckButton3"
        newWidget.checkButton4 = newWidget.widgetName.."_CheckButton4"
        newWidget.checkButton5 = newWidget.widgetName.."_CheckButton5"
        newWidget.checkButton6 = newWidget.widgetName.."_CheckButton6"
    end
    newWidget.frame:Show()
    newWidget.frame:SetID(widgetID)
    return newWidget
end

function MazzleOptions:ClearWidgets()
    local currentWidget
    -- Loop through different widget lists and put them as unused
    for _,poolList in pairs({"YesNoPool", "CheckButtonPool", "SliderPool", "MenuPool", "PerformancePool", "ButtonPool", "TextboxPool", "TitleButtonPool"}) do
        for i=1, #(WidgetPool[poolList]), 1 do
            currentWidget = WidgetPool[poolList][i]
            currentWidget.isFree = true
            currentWidget.frame:SetParent(UIParent)
            currentWidget.frame:ClearAllPoints()
            currentWidget.frame:SetPoint("CENTER", UIParent)
            currentWidget.frame:SetID(0)
            currentWidget.frame:Hide()
        end
    end
end

function MazzleOptions:CountWidgets()
    for _,poolList in pairs({"YesNoPool", "CheckButtonPool", "SliderPool", "MenuPool", "PerformancePool", "ButtonPool", "TextboxPool", "TitleButtonPool"}) do
        self:Print("Number of ", poolList, " widgets: ", #(WidgetPool[poolList]))
    end
end

	
function MazzleOptions:YesNo_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:CreateWidget("YesNo", lastFrame, MazzleOptions_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)
    getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.question))
    if ((currentWidgetInfo.parameter and MazzleUI:GetValue(currentWidgetInfo.parameter)) or
        (currentWidgetInfo.readOnlyParameter and MazzleUI:GetValue(currentWidgetInfo.readOnlyParameter)) or
        (currentWidgetInfo.readProc and currentWidgetInfo.readProc())) then
        getglobal(lastWidget.widgetName.."_CheckButtonYes"):SetChecked(1)
        getglobal(lastWidget.widgetName.."_CheckButtonNo"):SetChecked(nil)
    else
        getglobal(lastWidget.widgetName.."_CheckButtonYes"):SetChecked(nil)
        getglobal(lastWidget.widgetName.."_CheckButtonNo"):SetChecked(1)
    end
    if (currentWidgetInfo.yesText) then
        getglobal(lastWidget.widgetName.."_CheckButtonYesText"):SetText(TEXT(currentWidgetInfo.yesText))
    end
    if (currentWidgetInfo.noText) then
        getglobal(lastWidget.widgetName.."_CheckButtonNoText"):SetText(TEXT(currentWidgetInfo.noText))
    end
    return lastWidget
end

function MazzleOptions:Menu_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:CreateWidget("Menu", lastFrame, MazzleOptions_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)
    getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.name))
    if (currentWidgetInfo.menuItemsReadProc) then
        self:Menu_Initialize(lastWidget.frame, currentWidgetInfo.menuItemsReadProc())
    else
        self:Menu_Initialize(lastWidget.frame, currentWidgetInfo.menuItems)
    end
    if (currentWidgetInfo.width) then
        UIDropDownMenu_SetWidth( currentWidgetInfo.width, lastWidget.frame)
    end
    if (MazzleOptions_EnabledStatus) then
        UIDropDownMenu_EnableDropDown(lastWidget.frame)
        local menuValue = nil
        if (currentWidgetInfo.parameter) then
            menuValue = MazzleUI:GetValue(currentWidgetInfo.parameter)
        elseif (currentWidgetInfo.readOnlyParameter) then
            menuValue = MazzleUI:GetValue(currentWidgetInfo.readOnlyParameter)
        end    
        if (currentWidgetInfo.readProc) then
             menuValue = currentWidgetInfo.readProc(menuValue)
        end
        UIDropDownMenu_SetSelectedValue(lastWidget.frame, menuValue)
    else
        OptionsFrame_DisableDropDown(lastWidget.frame)
    end
    return lastWidget
end

function MazzleOptions:Menu_Initialize(theMenu, itemList)
	UIDropDownMenu_Initialize(theMenu, function() MazzleOptions:Menu_MakeButtons(theMenu, itemList) end);
	theMenu.tooltip = "";
	UIDropDownMenu_SetWidth(323, theMenu);
	UIDropDownMenu_JustifyText("CENTER", theMenu)
end

function MazzleOptions:Menu_MakeButtons(theMenu, itemList)
	local selectedValue = UIDropDownMenu_GetSelectedValue(theMenu);
	local info;
    local valcnt = 0
    for index,value in pairs(itemList) do
        valcnt = valcnt + 1
    	info = {};
    	info.text = itemList[index];
    	info.func = function() MazzleOptions:Menu_SetValue(theMenu) end;
    	info.value = valcnt
    	if ( info.value == selectedValue ) then
    		info.checked = 1;
    	end
    	UIDropDownMenu_AddButton(info);
    end
end

function MazzleOptions:Menu_SetValue(theMenu)
	UIDropDownMenu_SetSelectedValue(theMenu, this.value);
    if (MazzleOptions.Actives[theMenu:GetID()].info.parameter) then
        MazzleUI:CreateSet( MazzleOptions.Actives[theMenu:GetID()].info.parameter, this.value)
    end
    MazzleOptions:SetProc(theMenu:GetID(), this.value)
end

function MazzleOptions:TitleButton_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:CreateWidget("TitleButton", lastFrame, MazzleOptions_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)
    if (currentWidgetInfo.label) then
        lastWidget.frame:SetText(TEXT(currentWidgetInfo.label))
    end
    lastWidget.frame:SetWidth(MazzleOptions_Content_ScrollChildFrame:GetWidth())
    lastWidget.frame:SetScript("OnClick", currentWidgetInfo.setProc)
    getglobal(lastWidget.widgetName.."Text"):ClearAllPoints()
    getglobal(lastWidget.widgetName.."Text"):SetPoint("LEFT", lastWidget.frame, "LEFT", 5, 0)
    return lastWidget
end

function MazzleOptions:Button_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:CreateWidget("Button", lastFrame, MazzleOptions_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)
    if (currentWidgetInfo.name) then
        lastWidget.frame:SetText(TEXT(currentWidgetInfo.name))
    end
    if (currentWidgetInfo.label) then
        getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.label))
    end
    if (MazzleOptions_EnabledStatus) then
        lastWidget.frame:Enable()
    else
        lastWidget.frame:Disable()
    end
    return lastWidget
end

function MazzleOptions:Button_SetValue(widgetID)
    MazzleOptions:SetProc(widgetID)
end

function MazzleOptions:CheckButton_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:CreateWidget("CheckButton", lastFrame, MazzleOptions_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)
    getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.name))
    if (MazzleOptions_EnabledStatus) then
        OptionsFrame_EnableCheckBox(lastWidget.frame)
        local checkValue = nil
        if (currentWidgetInfo.parameter) then
            checkValue = MazzleUI:GetValue(currentWidgetInfo.parameter)
        elseif (currentWidgetInfo.readOnlyParameter) then
            checkValue = MazzleUI:GetValue(currentWidgetInfo.readOnlyParameter)
        end    
        if (currentWidgetInfo.readProc) then
             checkValue = currentWidgetInfo.readProc(checkValue)
        end
        lastWidget.frame:SetChecked(checkValue)
    else
        OptionsFrame_DisableCheckBox(lastWidget.frame)
    end
    return lastWidget
end

function MazzleOptions:CheckButton_SetValue(widgetID, widgetValue)
    if (MazzleOptions.Actives[widgetID].info.parameter) then
        MazzleUI:CreateSet( MazzleOptions.Actives[widgetID].info.parameter, widgetValue)
    end
    MazzleOptions:SetProc(widgetID, widgetValue)
end

function MazzleOptions:Slider_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:CreateWidget("Slider", lastFrame, MazzleOptions_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)

	getglobal(lastWidget.lowName):SetText(TEXT(self:Slider_Round(currentWidgetInfo.stepValue,currentWidgetInfo.minValue)))
	getglobal(lastWidget.highName):SetText(TEXT(self:Slider_Round(currentWidgetInfo.stepValue,currentWidgetInfo.maxValue)))
	lastWidget.frame:SetMinMaxValues(currentWidgetInfo.minValue, currentWidgetInfo.maxValue);
	lastWidget.frame:SetValueStep(currentWidgetInfo.stepValue);

    if (MazzleOptions_EnabledStatus) then
        local paramValue
    	if (currentWidgetInfo.readOnlyParameter) then
            paramValue = MazzleUI:GetValue(currentWidgetInfo.readOnlyParameter) or 0;
        elseif (currentWidgetInfo.readFunc) then
            paramValue = currentWidgetInfo.readFunc();
        elseif (currentWidgetInfo.parameter) then
            paramValue = MazzleUI:GetValue(currentWidgetInfo.parameter) or 0
        end
        getglobal(lastWidget.labelName):SetText(
            currentWidgetInfo.name.." "..self:Slider_Round(currentWidgetInfo.stepValue,paramValue)..currentWidgetInfo.units)
        lastWidget.frame:SetValue(paramValue);
        OptionsFrame_EnableSlider(lastWidget.frame);
    else
        getglobal(lastWidget.labelName):SetText(currentWidgetInfo.name)
        OptionsFrame_DisableSlider(lastWidget.frame);
    end
	lastWidget.frame.tooltipText = currentWidgetInfo.tooltip or "";
    return lastWidget
end

function MazzleOptions:SliderSet(widgetID, widgetValue)
    widgetValue = MazzleOptions:Slider_Format(widgetID, widgetValue)
    MazzleUI:CreateSet( MazzleOptions.Actives[widgetID].info.parameter, tonumber(widgetValue))
    getglobal(MazzleOptions.Actives[widgetID].widget.labelName):SetText(
        MazzleOptions.Actives[widgetID].info.name.." "..widgetValue..MazzleOptions.Actives[widgetID].info.units)
    MazzleOptions:SetProc(widgetID, tonumber(widgetValue))
end

function MazzleOptions:Slider_Format(widgetID, sliderValue)
    return MazzleOptions:Slider_Round(MazzleOptions.Actives[widgetID].info.stepValue, sliderValue)
end

function MazzleOptions:Slider_Round(stepValue, sliderValue)
    local formatString = "%i"
    if (stepValue < 1) then
        formatString = "%.2f"
    end
    if (sliderValue == nil) then return 0 else return string.format(formatString, sliderValue) end
end

function MazzleOptions:AddOnHeader_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)

    local realNumLines = currentWidgetInfo.numLines
    
    local headerName, buttonName, addonToggleFunc, enableStatus = self:GetAddonStatus(currentWidgetInfo)

    MazzleOptions_EnabledStatus = enableStatus
    currentWidgetInfo.numLines = 1
    currentWidgetInfo.text = headerName
    currentWidgetInfo.width = nil
    currentWidgetInfo.headerWidget = self:Textbox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    
    currentWidgetInfo.numLines = realNumLines
    if (currentJustification == "top") then currentJustification = "middle"; end;
    currentWidgetInfo.text = currentWidgetInfo.addonDescription
    currentWidgetInfo.width = "full"
    local infoWidget = self:Infobox_Create(currentWidgetInfo, currentWidgetInfo.headerWidget.frame, currentJustification, xadjust, yadjust, widgetID)
     
    MazzleOptions_EnabledStatus = true;
    currentWidgetInfo.name = buttonName;
    currentWidgetInfo.setProc = addonToggleFunc

    currentWidgetInfo.theButton = self:Button_Create(currentWidgetInfo, infoWidget.frame, "aboveright", xadjust, yadjust, widgetID)
    
    MazzleOptions_EnabledStatus = enableStatus

    return infoWidget
end

function MazzleOptions:ToggleAddOn( turnOn, currentWidgetInfo)

    if (turnOn) then
        self:Print(currentWidgetInfo.addonName, " will be enabled upon next UI reload.")
        EnableAddOn(currentWidgetInfo.requiredAddOn)
    else
        self:Print(currentWidgetInfo.addonName, " will be disabled upon next UI reload.")
        DisableAddOn(currentWidgetInfo.requiredAddOn)
    end

    local headerName, buttonName, addonToggleFunc = MazzleOptions:GetAddonStatus(currentWidgetInfo)
    currentWidgetInfo.setProc = addonToggleFunc;
    local textWidget = getglobal(currentWidgetInfo.headerWidget.labelName)
    textWidget:SetText(TEXT(headerName))
    currentWidgetInfo.headerWidget.frame:SetWidth(textWidget:GetStringWidth() + 32)
    currentWidgetInfo.theButton.frame:SetText(TEXT(buttonName))
    self.needsReload = true
end

function MazzleOptions:GetAddonStatus( currentWidgetInfo )
    local isEnabled, loadable, rv1, rv2, rv3, rv4
    _, _, _, isEnabled, loadable, _, _= GetAddOnInfo(currentWidgetInfo.requiredAddOn)
    if (isEnabled) then
        if (loadable) then
            rv1 = currentWidgetInfo.addonName
            rv2 = "Disable AddOn"
            rv3 = function() MazzleOptions:ToggleAddOn(false, currentWidgetInfo); end;
            rv4 = true
        else
            rv1 = currentWidgetInfo.addonName.." (on after reload)"
            rv2 = "Don't Enable"
            rv3 = function() MazzleOptions:ToggleAddOn(false, currentWidgetInfo); end;
            rv4 = false
        end
    else
        if (loadable) then
            rv1 = currentWidgetInfo.addonName.." (off after reload)"
            rv2 = "Don't Disable"
            rv3 = function() MazzleOptions:ToggleAddOn(true, currentWidgetInfo); end;
            rv4 = true
        else
            rv1 = currentWidgetInfo.addonName
            rv2 = "Enable AddOn"
            rv3 = function() MazzleOptions:ToggleAddOn(true, currentWidgetInfo); end;
            rv4 = false
        end
    end
    return rv1, rv2, rv3, rv4
end

function MazzleOptions:Textbox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID, textOverride)
    local lastWidget = self:CreateWidget("Textbox", lastFrame, MazzleOptions_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID, textOverride)
    
    local theTextString = currentWidgetInfo.text
    if (textOverride) then theTextString = textOverride; end
    
    local textWidget = getglobal(lastWidget.labelName)
    if (MazzleOptions_EnabledStatus) then
        textWidget:SetTextColor(0, 1, 0);
        textWidget:SetText(TEXT(theTextString))
    else
        textWidget:SetText(TEXT(theTextString))
        textWidget:SetTextColor(0.5, 0.5, 0.5);
    end
    
    if (currentWidgetInfo.width == "full") then currentWidgetInfo.width = 500
    else currentWidgetInfo.width = currentWidgetInfo.width or (textWidget:GetStringWidth() + 32); end
    
    textWidget:ClearAllPoints()
    textWidget:SetPoint("TOPLEFT", lastWidget.frame, "TOPLEFT" , 0, 0);
    textWidget:SetWidth(currentWidgetInfo.width-20)
    lastWidget.frame:SetWidth(currentWidgetInfo.width)
    lastWidget.frame:SetHeight(textWidget:GetHeight()+20)
    textWidget:ClearAllPoints()
    textWidget:SetPoint("TOPLEFT", lastWidget.frame, "TOPLEFT" , 10, -10);
    textWidget:SetPoint("BOTTOMRIGHT", lastWidget.frame, "BOTTOMRIGHT" , -10, 10);
    
    if (not MazzleOptions_TextboxBackdrop) then
        MazzleOptions_TextboxBackdrop = lastWidget.frame:GetBackdrop()
    else
        lastWidget.frame:SetBackdrop(MazzleOptions_TextboxBackdrop) 
        lastWidget.frame:SetBackdropBorderColor(0.4, 0.4, 0.4);
        lastWidget.frame:SetBackdropColor(0.05, 0.05, 0.05);
    end
    return lastWidget
end

    
function MazzleOptions:Infobox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:Textbox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, (yadjust+16), widgetID)

    if (MazzleOptions_EnabledStatus) then
		getglobal(lastWidget.labelName):SetTextColor(1, 1, 1);
        getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.text))
    else
        getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.text))
		getglobal(lastWidget.labelName):SetTextColor(0.5, 0.5, 0.5);
    end
    --lastWidget.frame:SetWidth(currentWidgetInfo.width or 500)
    return lastWidget
end

function MazzleOptions:Notebox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)

    local noteText
    if (currentWidgetInfo.notetype  == "warning") then
        noteText = "|CFFFF0000Warning: |r"..currentWidgetInfo.text
    elseif (currentWidgetInfo.notetype  == "example") then
        noteText = "|CFFFF8000Example: |r"..currentWidgetInfo.text
    elseif (currentWidgetInfo.notetype  == "none") then
        noteText = currentWidgetInfo.text
    else
        noteText = "|CFFFF8000Note:  |r"..currentWidgetInfo.text
    end
    currentWidgetInfo.width = currentWidgetInfo.width or "full"
    
    local lastWidget = self:Textbox_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust , widgetID, noteText)
    if (MazzleOptions_EnabledStatus) then
		getglobal(lastWidget.labelName):SetTextColor(1, 1, 1);
        getglobal(lastWidget.labelName):SetText(TEXT(noteText))
    else
        getglobal(lastWidget.labelName):SetText(TEXT(noteText))
		getglobal(lastWidget.labelName):SetTextColor(0.5, 0.5, 0.5);
    end

    --lastWidget.frame:SetWidth(currentWidgetInfo.width or 500)
    lastWidget.frame:SetBackdrop(nil)
    return lastWidget
end

function MazzleOptions:SetScrollingText(frameName, newText)
    getglobal(frameName.."_ScrollFrame__ScrollChildFrame_Text"):SetText(newText)
    getglobal(frameName.."_ScrollFrame__ScrollChildFrame_Text"):SetHeight(getglobal(frameName.."_ScrollFrame__ScrollChildFrame_Text"):GetHeight())
end

function MazzleOptions:SetText(frameName, newText, newTextHeight, newTextWidth)
    getglobal(frameName.."_Text"):SetText(newText)
    getglobal(frameName.."_Text"):SetNonSpaceWrap(true)
    getglobal(frameName):SetHeight(newTextHeight)
    getglobal(frameName):SetWidth(newTextWidth)
    
end

function MazzleOptions:TestHeight(widgetNum, newHeight, newWidth, newText)
    local theText = newText or getglobal(MazzleOptions.Actives[widgetNum].widget.widgetName.."_Text"):GetText()
    local theWidth = newWidth or getglobal(MazzleOptions.Actives[widgetNum].widget.widgetName):GetWidth()
    local theHeight = newHeight or getglobal(MazzleOptions.Actives[widgetNum].widget.widgetName):GetHeight()
    self:SetText(MazzleOptions.Actives[widgetNum].widget.widgetName, theText, theHeight, theWidth)
end

function MazzleOptions:PerformanceEntry_Create(currentWidgetInfo, lastFrame, currentJustification, xadjust, yadjust, widgetID)
    local lastWidget = self:CreateWidget("PerformanceEntry", lastFrame, MazzleOptions_Content_ScrollChildFrame, currentJustification, xadjust, yadjust, widgetID)
    getglobal(lastWidget.labelName):SetText(TEXT(currentWidgetInfo.name))
    if (currentWidgetInfo.header) then
        getglobal(lastWidget.headerName):SetText(TEXT(currentWidgetInfo.header))
    else
        getglobal(lastWidget.headerName):SetText("")
    end
    getglobal(lastWidget.checkButton1):SetChecked(MazzleUI:GetValue(currentWidgetInfo.parameter..".solo"))
    getglobal(lastWidget.checkButton3):SetChecked(MazzleUI:GetValue(currentWidgetInfo.parameter..".party"))
    getglobal(lastWidget.checkButton4):SetChecked(MazzleUI:GetValue(currentWidgetInfo.parameter..".raid"))
    getglobal(lastWidget.checkButton5):SetChecked(MazzleUI:GetValue(currentWidgetInfo.parameter..".pvp"))
    if (MazzleUI:GetValue(currentWidgetInfo.parameter..".canCombat")) then
        getglobal(lastWidget.checkButton2):SetChecked(MazzleUI:GetValue(currentWidgetInfo.parameter..".combat"))
        OptionsFrame_EnableCheckBox(getglobal(lastWidget.checkButton2))
        getglobal(lastWidget.checkButton2):Show()
    else
        getglobal(lastWidget.checkButton2):SetChecked(nil)
        OptionsFrame_DisableCheckBox(getglobal(lastWidget.checkButton2))
        getglobal(lastWidget.checkButton2):Hide()
    end
    if (MazzleUI:GetValue(currentWidgetInfo.parameter..".noManual")) then
        getglobal(lastWidget.checkButton6):SetChecked(nil)
        OptionsFrame_DisableCheckBox(getglobal(lastWidget.checkButton6))
        getglobal(lastWidget.checkButton6):Hide()
    else
        getglobal(lastWidget.checkButton6):SetChecked(MazzleUI:GetValue(currentWidgetInfo.parameter..".manual"))
        OptionsFrame_EnableCheckBox(getglobal(lastWidget.checkButton6))
        getglobal(lastWidget.checkButton6):Show()
    end
    return lastWidget
end

function MazzleOptions:PerformanceEntry_SetValue(widgetID, modeID, modeValue)
    if (MazzleOptions.Actives[widgetID].info.parameter) then
        local modeString
        if (modeID == 1) then modeString = "solo"
            elseif (modeID == 2) then modeString = "combat"
            elseif (modeID == 3) then modeString = "party"
            elseif (modeID == 4) then modeString = "raid"
            elseif (modeID == 5) then modeString = "pvp"
            elseif (modeID == 6) then modeString = "manual"
        end
        MazzleUI:CreateSet( MazzleOptions.Actives[widgetID].info.parameter.."."..modeString, modeValue)
        MazzleUI:InstantiateEfficiencyMode(true)
    end
    MazzleOptions:SetProc(widgetID, widgetValue)
end

function MazzleOptions:SetProc(widgetID, widgetValue)
    if (MazzleOptions.Actives[widgetID].info.setProc) then
        MazzleOptions.Actives[widgetID].info.setProc(widgetID, widgetValue)
    end
end

function MazzleOptions:LayoutWidgets(topicNum)
    for i=1, self.ContentData.NumTopics, 1 do
        getglobal("MazzleOptionsTopic"..i):UnlockHighlight();
    end
    getglobal("MazzleOptionsTopic"..topicNum):LockHighlight();
    
    self:ClearWidgets()
    MazzleOptions.Actives = {}
    MazzleOptions_EnabledStatus = true
    local lastWidget, currentJustification, xadjust, yadjust
    
    for i=1, #(self.ContentData.Contents[topicNum]), 1 do
        MazzleOptions.Actives[i] = {}
        MazzleOptions.Actives[i].info = self.ContentData.Contents[topicNum][i]
        xadjust = MazzleOptions.Actives[i].info.xadjust or 0
        yadjust = MazzleOptions.Actives[i].info.yadjust or 0
        if (i == 1) then
            currentJustification = "top"
        else
            currentJustification = MazzleOptions.Actives[i].info.justification or "middle"
        end
        if (lastWidget) then lastFrame = lastWidget.frame else lastFrame = "MazzleOptions_Content_ScrollChildFrame" end
        if (MazzleOptions.Actives[i].info.type == "YesNo") then
            lastWidget = self:YesNo_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (MazzleOptions.Actives[i].info.type == "Menu") then
            lastWidget = self:Menu_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (MazzleOptions.Actives[i].info.type == "AddOnHeader") then
            lastWidget = self:AddOnHeader_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (MazzleOptions.Actives[i].info.type == "Button") then
            lastWidget = self:Button_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (MazzleOptions.Actives[i].info.type == "CheckButton") then
            lastWidget = self:CheckButton_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (MazzleOptions.Actives[i].info.type == "Slider") then
            lastWidget = MazzleOptions:Slider_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (MazzleOptions.Actives[i].info.type == "Textbox") then
            lastWidget = self:Textbox_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (MazzleOptions.Actives[i].info.type == "Infobox") then
            lastWidget = self:Infobox_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (MazzleOptions.Actives[i].info.type == "Notebox") then
            lastWidget = self:Notebox_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (MazzleOptions.Actives[i].info.type == "TitleButton") then
            lastWidget = self:TitleButton_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        elseif (MazzleOptions.Actives[i].info.type == "PerformanceEntry") then
            lastWidget = self:PerformanceEntry_Create(MazzleOptions.Actives[i].info, 
                                                    lastFrame, currentJustification, xadjust, yadjust, i)
        end
        MazzleOptions.Actives[i].widget = lastWidget
    end
    MazzleOptions_Contents_ScrollFrame:UpdateScrollChildRect()
end

