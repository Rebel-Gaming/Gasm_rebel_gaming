function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Skin_Minyaen_Dungeon\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Skin_Minyaen_Dungeon\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Skin_Minyaen_Dungeon\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Skin_Minyaen_Dungeon\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Skin_Minyaen_Dungeon\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Skin_Minyaen_Dungeon\\MazzleUICastingBarBorder",
            chatborder = "Interface\\AddOns\\MazzleUI_Skin_Minyaen_Dungeon\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Skin_Minyaen_Dungeon\\MazzleUIMinimapBorder",
        },
    }
end