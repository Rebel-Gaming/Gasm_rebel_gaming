--[[
	Bongos Bindings
--]]

local DEFAULT_BINDINGS = 0
local ACCOUNT_BINDINGS = 1
local CHARACTER_BINDINGS = 2
local enabled
local current
local wasUnlocked

function ShowEmptyButtons()
	bg_showGrid = 1
	BActionButton.ForAll(BActionButton.ShowGrid)
	BPetBar_ForAllButtons(BPetButton.ShowGrid)
end

function HideEmptyButtons()
	bg_showGrid = nil
	BActionButton.ForAll(BActionButton.HideGrid)
	BPetBar_ForAllButtons(BPetButton.HideGrid)
end

--[[ Options Frame Functions ]]--

function BOptionsBinder_OnShow()
	enabled = true
	
	wasUnlocked = not BongosSets.locked
	if wasUnlocked then
		Bongos_SetLock(true)
	end
	
	ShowEmptyButtons()
	if InCombatLockdown() then
		CQ.Do(KeyBound_Enable)
	else
		KeyBound_Enable()
	end
end

function BOptionsBinder_OnHide()
	enabled = nil
	
	if wasUnlocked then
		Bongos_SetLock(false)
	end

	HideEmptyButtons()
	KeyBound_Disable()

	if InCombatLockdown() then
		SaveBindings(current)
	else
		CQ.Do(function() SaveBindings(current) end)
	end
end

--[[ Per Character Bindings ]]--

function BOptionsBinderPerCharacter_OnShow()
	if not current then
		current = GetCurrentBindingSet()
	end
	this:SetChecked(GetCurrentBindingSet() == CHARACTER_BINDINGS)
end

function BOptionsBinderPerCharacter_OnClick(checkButton)
	if checkButton:GetChecked() then
		current = CHARACTER_BINDINGS
	else
		current = ACCOUNT_BINDINGS
	end
	LoadBindings(current)
end

--[[ Combat Events ]]--

local wasEnabled
BEvent:AddAction('PLAYER_REGEN_ENABLED', function()
	if wasEnabled or enabled then
		ShowEmptyButtons()
	end
	wasEnabled = nil
end)

BEvent:AddAction('PLAYER_REGEN_DISABLED', function()
	wasEnabled = enabled
	if wasEnabled then
		HideEmptyButtons()
	end
end)