SunnArt.options.args.theme.values["SunnArtPack4\\horde"]="Horde"
SunnArt.options.args.theme.values["SunnArtPack4\\emblem"]="Emblem"
SunnArt.options.args.theme.values["SunnArtPack4\\spiked"]="Spiked"
SunnArt.options.args.theme.values["SunnArtPack4\\scraped"]="Scraped"