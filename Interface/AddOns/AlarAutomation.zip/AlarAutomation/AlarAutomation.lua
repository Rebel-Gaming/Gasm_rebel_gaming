local __FILE__=tostring(debugstack(1,2,0):match("(.*):1:")) -- MUST BE LINE 1
local _,_,_,toc=GetBuildInfo()
local pp=print
--[[
Name: AlarAutomation.lua
Revision: $Rev: 72 $
Author: Alar of Daggerspine
Email: alar@aspide.it
Website: http://www.curse.com
SVN: $HeadUrl:$
License: GPL v2.1
--]]
local me, ns = ...
--[===[@debug@
print("Loading",__FILE__," inside ",me)
--@end-debug@]===]
if (LibDebug) then LibDebug() end
local function debug(...) 
--[===[@debug@
print(...)
--@end-debug@]===]
end
local print=_G.print
local notify=_G.print
local error=_G.error
local function dump() end
local function debugEnable() end
if (LibStub("AlarLoader-3.0",true)) then
	local rc=LibStub("AlarLoader-3.0"):GetPrintFunctions(me)
	print=rc.print
	--[===[@debug@
	debug=rc.debug
	dump=rc.dump
	--@end-debug@]===]
	notify=rc.notify
	error=rc.error
	debugEnable=rc.debugEnable
else
	debug("Missing AlarLoader-3.0")
end
debugEnable(false)
local L=LibStub("AceLocale-3.0"):GetLocale(me,true)
--[[ Standard prologue end --]]
local MAINHAND=GetInventorySlotInfo("MainHandSlot") 
local mainhand
local OFFHAND=GetInventorySlotInfo("SecondaryHandSlot")
local offhand 
local PET_PASSIVE_TEXTURE = [[Interface\Icons\ABILITY_SEAL]]
local _G =_G
print("Got toc:",toc)
-- Cata compatibility
--[===[@debug@
if (LibDebug) then LibDebug() end
--@end-debug@]===]
local Id="AAU"
local Fullname="AlarAutomation"
local Nofishing="phishing"
local FishingPole="Fishing Poles"
local Fishing=Nofishing
local fu
local titan
local help
local AMOMAXBUFFS=10
local restoreRKEY = false
local hunter = false
local warlock = false
local fu={}
------------------------------------------------------
local _G = _G
--_G['AAU']=AlarCreateAddon(Fullname,true)
local addon=LibStub("AlarLoader-3.0"):CreateAddon(me,true)
_G.AAU=addon
local frames=LibStub("AlarFrames-3.0")
local L=LibStub("AceLocale-3.0"):GetLocale(me,true)
local C=LibStub("AlarCrayon-3.0"):GetColorTable()
local AMO_RED=C.RED
local AMO_YELLOW=C.YELLOW
local AMO_ORANGE=C.ORANGE
local AlarTrack
--addon.ID="AAU"
--addon.DATABASE="dbAAU"
local function today() return date("%m/%d/%y") end
local function toweek() return date("%U") end

function addon:OnEnabled(first)
    if (first and self.localdb.char.trackopen) then
        self:CmdTrack()
    end
    self:EvtStart()
    self:CheckPet()
    self:LoadFishing()
end
function addon:OnDisabled()
    self:EvtStop()
end
addon.CmdWatchDesc=L["Watchs a selection of buffs and warns when they expire"]
addon.CmdWatchType="group"
addon.CmdWatchArgs={
	type="group",inline=true,
	name=L["Watcher Preferences"],
	args={
	    Configure={
	        type="execute",
	        name='Configure',
	        desc=L["Configure watched buffs"],
	        func="CmdWatch",
	    },
	    Test={
	        type="execute",
	        name="Test",
	        desc=L["Test sound"],
	        func="PlayWW",
	    },
	    Sound={
	        type="select",
	        name="Sound",
	        desc=L["Choose a sound"],
	        values={Horn='Horn',Chimes='Chimes',Beam='Beam',RaidWarning='RaidWarning',ReadyCheck='ReadyCheck',none='none'},
	        set="OptToggleSet",
	        get="OptToggleGet",
	        arg="WATCHSOUND"
	    }
	}
}
local Sounds={
    Horn="Sound\\Doodad\\ZeppelinHorn.wav",
    Chimes="Sound\\Doodad\\SimonGame_LargeBlueTree.wav",
    Beam="Sound\\Doodad\\UtherShrineLightBeam_Open.wav",
    RaidWarning="RaidWarning",
    ReadyCheck="ReadyCheck",
}
local LastPlayedSound=0

function addon:OnInitialized()
    self.localdb=self.db:RegisterNamespace("private")
    self.localdb:RegisterDefaults({char={
        frames=frames:GetDefault(),
        WATCHED={},
        TRACKED={},
        WATCHSOUND="ReadyCheck",
        trackopen=false,
    }})
    hunter=self:Is("HUNTER")
    warlock=self:Is("WARLOCK")
    local g
    self:AddLabel(L["Interface"],L["Interface enhancements"])
    self:AddToggle('QUICKFISH',true,L["Quick fishing"],L["Auto show a cast button for fishing at your mouse position right after you loot"])
    self:AddLocalCmd('Fish',"CmdFish",L["Fish!"],L["Equip your fishing pole and start fishing"])
    self:AddLocalCmd('NoFish',"CmdNoFish",L["Stop Fish!"],L["Equip back your previous weapons"])
    self:AddToggle('QUICKGOSSIP',false,L["Skip gossip"],L["Some NPCs have a gossip screen before actually giving you something to do"])
    self:AddToggle('AUTOPILOT',false,L["Autopilot"],L["When active you will autofollow any member of your party who sends you follow me"])
    self:AddToggle('AUTOGROUP',false,L["Auto accept group"],L["When active, you will autoaccept group invite from people in your friend list"])
    self:AddToggle('AUTORESURRECT',false,L["Auto accept resurrect"],L["When active you will autoaccept resurrection. Nice to go to bathrooom when you die on minute 1 on that 60 minutes long encounter"])
    self:AddToggle('AUTOSUMMON',false,L["Auto accept summon"],L["When enabled you accept any summon request"])
    self:AddToggle('REASPECT',hunter,L["Aspect reminder"],L["Reminds you to recast your current aspect after death"])
    self:AddToggle('AUTODISMOUNT',true,L["Auto dismount"],L["When active, every time you try to do something you cant do mounted, you are dismounted"])
    self:AddToggle('DISMOUNTPROTECTION',true,L["Dismount protection"],L["When active, if you try do dismount when flying you get warned and not dismounted"])
    self:AddLabel(L["Combat"],L["Combat related"])
    self:AddToggle('SAFEPET',hunter or warlock,L["Aggressive pet warning"],L["This try to avoid leaving a BG with pet still in aggro mode, take a gryphon and land in a neutral city...Getting owned by bruisers"])
    self:AddToggle('BESMART',true,L["Disable chat functions when fighting"],L["Disables R (default reply key) and closes the chatbox when you are in combat"])
    self:AddLabel(L["Chat"],L["Chat and whispers"])
    self:AddToggle('ENHANCE',false,L["Enhance whispers"],L["When active, whispers will be shown on your HUD"])
    g=self:AddToggle('REFLECT',false,L["Whispers reflection"],L["When active, your whispers will be forwarded"])
    g.width="full"
    self:AddEdit('REFLECTTO','',L["Whisper reflection receiver:"],L["All your whispers will be forwarded to this guy"])
    self:AddCmd("ip","ChatP",L["Speaks in party chat"],L["Doesnt change your default chat"])
    self:AddCmd("is","ChatS",L["Speaks in say"],L["Doesnt change your default chat"])
    self:AddCmd("ig","ChatG",L["Speaks in guild chat"],L["Doesnt change your default chat"])
    self:AddCmd("io","ChatO",L["Speaks in officer chat"],L["Doesnt change your default chat"])
    self:AddCmd("ib","ChatB",L["Speaks in the 'best' chat"],L["Chooses the chat depending on your grouping status"])
    self:AddLabel(L["Utility"],L["Utility commands"])
    self:AddLocalCmd('Track',"CmdTrack",L["Opens item tracker"],L["Quest like minion to track items you are farming"])
    self:AddLocalCmd(L["Watcher"],"CmdWatch",L["Auto buff recast alert"])
    self:AddTable('WatcherData',self.CmdWatchArgs)
    self.ApplyAspect=function() return end
    if (not hunter) then
        self:SetVar("REASPECT",false)
        if (not warlock) then
            self:SetVar("SAFEPET",false)
        end
    end
	help(self)
	-- Creazione bottone per retrack
	local f
	if (self:Is("HUNTER")) then
		f=LibStub("AceGUI-3.0"):Create("AlarCastSingleButton")
		f:Hide()
		f:SetCallback("OnClick",function(self) self:Hide() end)
		self.AspectFrame=f 
	end
	if (self:Is("HUNTER") or self:Is("WARLOCK")) then
	
		f=LibStub("AceGUI-3.0"):Create("AlarCastSingleButton")
		f:SetMacrotext('/petpassive')
		f:SetIcon(PET_PASSIVE_TEXTURE)
		f:SetCallback("OnClick",function(self) self:Hide() end)
		self.PetFrame=f 
	end

end
function addon:IsFriend(player)
    local i
    for i =1,GetNumFriends() do
        local name,_,_,_,_ =GetFriendInfo(i)
        if (name == player) then
            return true
        end
    end
    return false
end
function addon:Parse(msg)
    if (not msg) then
        return nil
    end
    local cmd,subcmd,param = strsplit(" ",msg,3)
    local _,fullarg=strsplit(" ",msg,2)
    return cmd,subcmd,param,fullarg
end

function addon:EvtSPELL_CHANGED()
	self:LoadFishing()
end
local function localizeFishing(Fishing,FishTexture)
	if (toc < 40000) then
        local i=1
        while (i<GetNumSkillLines() ) do
	        local nome,header,expanded=GetSkillLineInfo(i)
	        if (header and not expanded) then
		        ExpandSkillHeader(i)
		        i=0
			else
				if (not header and GetSpellTexture(nome)==FishTexture) then
					Fishing=nome
					i=9999
				end
			end
			i=i+1
		end
	else 
		debug ("Cata Code")
		local p1,p2,arch,fishing,cooking,firstaid=GetProfessions()
		print (p1,p2,arch,fishing,cooking,firstaid)
		if (fishing) then
			print(GetProfessions(fishing))
			Fishing=GetProfessionInfo(fishing)
			print(Fishing)
		end
	end
	return Fishing
end
function addon:LoadFishing()
	if (InCombatLockdown()) then return end

    if (not Fishing) then
        Fishing=Nofishing
    end
    if (Fishing == Nofishing) then
    	Fishing=localizeFishing(Fishing,"Interface\\Icons\\Trade_Fishing")
    end
    if (Fishing == Nofishing) then
        self:Notify("Couldnt localize Fishing. Maybe you didnt learn it?")
    else
        self:Notify("Fishing localized as " .. tostring(Fishing))
		local f=LibStub("AceGUI-3.0"):Create("AlarCastSingleButton")
		f:Hide()
		f:SetSpell(Fishing)
		f:SetCallback("OnClick",function(self) self:FadeStop() self:FadeOut(5) end)
		f:SetCallback("OnClose",function()	self:CmdNoFish() end )
		self.FishFrame=f
    end
	--self.FishFrame:SetIcon(PET_PASSIVE_TEXTURE)    
	--local f=frames:CreateCastPanel("AAU_Fish",false)
	--f:SetSpell(Fishing)
	--f:Hide()
end
function addon:EvtPARTY_INVITE_REQUEST(event,arg1)
    self:Debug("Invited from %s",arg1)
    if (not self:GetBoolean("AUTOGROUP")) then return end
    if (self:IsFriend(arg1)) then
        self:Debug("From friend")
        local Dialog=StaticPopup_FindVisible("PARTY_INVITE",nil)
        if (Dialog) then
            self:Debug("Dialog found")
            StaticPopup_OnClick(Dialog,1)
        else
            self:Debug("Dialog not found")
        end
    else
        self:Debug("From not friend")
        self:Debug(AMO_RED .. arg1 .. L[" just invited you to a group"])
    end
    self:Debug("End event")
end
function addon:EvtGOSSIP_SHOW()
    if (self:GetBoolean("QUICKGOSSIP")) then
         local vox,tipo,more=GetGossipOptions()
         if (not more) then
            if (not GetGossipActiveQuests() and not GetGossipAvailableQuests()) then
                self:Printf(AMO_YELLOW .. "Skipped %s gossip: %s%s",tipo or '',AMO_ORANGE,GetGossipText())
                self:Printf(AMO_YELLOW .. "Taken option: %s",vox)
                SelectGossipOption(1)
            end
        end
    end
end
local textures={
['Interface\\Icons\\Ability_Hunter_AspectOfTheMonkey']='A',
['Interface\\Icons\\Ability_Hunter_AspectoftheViper']='A',
['Interface\\Icons\\Spell_Nature_RavenForm']='A',
['Interface\\Icons\\Spell_Nature_ProtectionFormNature']='A',
['Interface\\Icons\\Ability_Mount_PinkTiger']='A',
}
local cachedtextures={}
function addon:EvtZONE_CHANGED_NEW_AREA(...)
    if (not IsActiveBattlefieldArena()) then
        self:CheckPet()
    elseif (GetNumBattlefieldPositions()) then
        self:CheckPet()
    end
end
function addon:EvtPLAYER_ENTERING_WORLD(...)
	if (not IsActiveBattlefieldArena()) then
		self:CheckPet()
	elseif (GetNumBattlefieldPositions()) then
		self:CheckPet()
	end
end

function addon:EvtCONFIRM_SUMMON()
    self:Trace("CONFIRM_SUMMON")
    if (not self:GetBoolean("AUTOSUMMON")) then
        return
    end
    local Dialog=StaticPopup_FindVisible("CONFIRM_SUMMON",nil)
    if (Dialog) then
        debug("Dialog found")
        StaticPopup_OnClick(Dialog,1)
    else
        debug("Dialog not found")
    end
end
function addon:EvtRESURRECT_REQUEST(event,player)
    self:Trace("RESURRECT_REQUEST")
    if (not self:GetBoolean("AUTORESURRECT")) then
        return
    end
    local Dialog=StaticPopup_FindVisible("RESURRECT_NO_SICKNESS",nil)
    if (Dialog) then
        debug("Dialog found")
        StaticPopup_OnClick(Dialog,1)
    else
        dDebug("Dialog not found")
    end
end

function addon:EvtLOOT_CLOSED(event,id)
    if (AlarTrack and AlarTrack:IsShown()) then
        self:TrackerUpdate()
    end
end
function addon:EvtCHAT_MSG_SKILL(event,arg)
    if (not Fishing or Fishing == Nofishing) then
        self:LoadFishing()
    end
end
addon.EvtBAG_UPDATE=addon.EvtLOOT_CLOSED
function addon:EvtCOMBAT_LOG_EVENT(_,timestamp,event,sguid,sname,sflags,dguid,dname,dflags,spellid,spellname,stack,kind,...)
    if (bit.band(COMBATLOG_OBJECT_AFFILIATION_MINE,dflags)==1) then
        --sdebug(event,sname,dname,spellid,'(',spellname,')',stack,kind,...)
        if (event == "SPELL_AURA_REMOVED" and kind=="BUFF") then
        	local arg=spellname
        	-- Fishing check
        	if self.FishFrame then
			    if (not InCombatLockdown()) then
			    	if (arg:find(Fishing)) then
			        	if (self:GetBoolean("QUICKFISH")) then
			                self.FishFrame:ShowAtMouse()
			                return
			            end
			        end
			    end
		    end
		    --self:Print("Checking",arg)
		    for i,v in pairs(self.localdb.char.WATCHED) do
		        if (arg:find(i)) then
		           self:WatcherWarn(arg)
		           break
		        end
		    end
		    if self.AspectFrame then
			    local texture=cachedtextures[arg]
			    if (not texture) then
			    	cachedtextures[arg]=GetSpellTexture(arg)
			    	texture=cachedtextures
			    end
			    --adebug(arg,"=>",texture)
			    if (texture) then
		            self:ScheduleLeaveCombatAction(
		            	function()
		            	self.AspectFrame:SetSpell(arg)
		            	self.AspectFrame.display=true
		            end
		            )
	            end
            end
		end
	end
		    
end

function addon:EvtPLAYER_UNGHOST()
    --[===[@debug@
    debug("Unghost, trying Track and Aspect")
    --@end-debug@]===]
    if (self.AspectFrame.display) then
        if (self:GetBoolean("REASPECT")) then
			self.AspectFrame:Pop()
			self.AspectFrame:FadeOut(15,15)			
			self.AspectFrame.display=nil
        end
    end
end
function addon:EvtPLAYER_REGEN_DISABLED()
-- I am about to enter combat... let's close chatbox and disable R as reply
    if (not self:GetBoolean("BESMART")) then
        return
    end
    local ChatFrameEditBox=ChatEdit_GetActiveWindow()
    if (ChatFrameEditBox) then
    	ChatFrameEditBox:ClearFocus()
    	ChatFrameEditBox:Hide()
    end
    if (GetBindingAction("R") == "REPLY") then
        SetBinding("R",nil)
        restoreRKEY=true
        self:Debug("Disabling R (reply) while fighting")
    else
        restoreRKEY=false
    end
    for i,v in pairs(self.localdb.char.WATCHED) do
        local buff,rank = UnitBuff('player',i)
        if (not buff) then
            self:WatcherWarn(i)
        end
    end

end
function addon:EvtPLAYER_REGEN_ENABLED()
-- I am about to enter combat... let's close chatbox and disable R as whsilòeper reply
    if (restoreRKEY) then
        SetBinding("R","REPLY")
        self:Debug("Reenabling R (reply) after fighting")
    end
end

function addon:EvtCHAT_MSG_WHISPER(event,msg,from)
    --[===[@debug@
        self:Print("DBG",arg1,arg2,"Whisper")
    --@end-debug@]===]
    if (self:GetBoolean("ENHANCE")) then
        self:Onscreen_Purple("[" .. tostring(from) .. "] whispers " .. tostring(msg));
    end
    local gf=self:GetSet("REFLECTTO")
    if (self:GetBoolean("REFLECT") and gf) then
        if (gf ~= "") then
            SendChatMessage("[" .. from .. "] whispers " .. msg,"WHISPER",nil,gf)
        end
    end
    if (self:GetBoolean("AUTOPILOT")) then
        self:AutoPilot(msg,from)
    end
end
function addon:SeekUnitID(target)
    local n=GetNumPartyMembers()
    for i=1,n do
        if (UnitName("Party" .. i) == target) then
            return "Party" .. i
        end
    end
    n=GetNumRaidMembers()
    for i=1,n do
        if (UnitName("Raid" .. i) == target) then
            return "Raid" .. i
        end
    end
    return
end
function addon:AutoPilot(msg,sender)
    local cmd,target=self:Parse(msg)
    if (target == "me") then
        target=sender
    end
    if(cmd == "follow") then
        self:Print("%s asks you to follow %s",sender,target)
        local unit=self:SeekUnitID(target)
        if (unit) then
            FollowUnit(unit)
            SendChatMessage("AutoFollowing you, but may still be afk","WHISPER","COMMON",target)
        end
    end
end
function addon:Evt(...)
end
function addon:CheckPet()
    if(self:GetBoolean("SAFEPET")) then
        if (self:Is("HUNTER") or self:Is("WARLOCK")) then
            local nome,_,texture,_,active=GetPetActionInfo(8)
            if (active) then
                self:Onscreen_Red("Maybe you want to set your pet to passive?")
                self.PetFrame:Pop()
                self.PetFrame:FadeOut(15,15)
                PlaySoundFile("Sound\\Creature\\SpectralTiger\\SpectralTigerWoundCrit")
            else
            	self.PetFrame:Hide()
            end
            return
        end
    end
end

function addon:EvtTAXIMAP_OPENED()
    self:CheckPet()
end
function addon:EvtUI_ERROR_MESSAGE(event,message)
    --self:Debug("UI_ERROR_MESSAGE: %s ",message)
    if (message == SPELL_FAILED_NOT_MOUNTED or
        message == ERR_TAXIPLAYERALREADYMOUNTED  or
        message == ERR_MOUNT_ALREADYMOUNTED) then
        self:AutoDismount()
    elseif (message == ERR_LOOT_NOTSTANDING or message == "xx") then
        DoEmote("STAND")
    elseif (message == ERR_MOUNT_SHAPESHIFTED or
        message == ERR_CANT_INTERACT_SHAPESHIFTED or
        message == SPELL_FAILED_NOT_SHAPESHIFT or
        message == ERR_NO_ITEMS_WHILE_SHAPESHIFTED or
        message == ERR_TAXIPLAYERSHAPESHIFTED or
        message == ERR_NOT_WHILE_SHAPESHIFTED) then
        if (self:GetBoolean('AUTODESHAPESHIFT')) then
            for index = 1,GetNumShapeshiftForms() do
                local icon, name, active, castable = GetShapeshiftFormInfo(index);
                if (active) then
                    CastShapeshiftForm(index)
                    break
                end
            end
        end
    end
end

function addon:AutoDismount()
    if (IsFlying() and self:GetBoolean("DISMOUNTPROTECTION")) then
        self:Print("Dismounting while flying would not be safe..")
        return
    end
    if (self:GetBoolean("AUTODISMOUNT") and IsMounted()) then
        Dismount()
     end
end
-- Chat function
function addon:chat(msg,tipo)
    SendChatMessage(msg,tipo);
end
function addon:ChatS(msg)
    self:chat(msg,"SAY")
end
function addon:ChatG(msg)
    self:chat(msg,"GUILD")
end
function addon:ChatP(msg)
    self:chat(msg,"PARTY")
end
function addon:ChatO(msg)
    self:chat(msg,"OFFICER")
end
function addon:ChatB(msg,general)
    local channel="PARTY"
    if (GetNumRaidMembers() > 0) then
        channel="RAID"
    elseif (GetNumPartyMembers() > 0) then
        channel="PARTY"
    elseif (general) then
        self:Channel(msg,"General")
        return
    end
    self:chat(msg,channel)
end
-- Local Worker FUnction
local WinAdd
local WinUpdate
local WinRemove
function WinRemove(self,fname,this,button)
    local form=frames:IsFrame(fname)
    if (button == "RightButton"and not CursorHasItem()) then
        local id=this.itemID
        if (id) then
            self:Print(L['Removed'],form.items[id])
            form.items[id]=nil
            this.itemID=nil
        end
        local k=tonumber(form.lastitem)
        if (k) then
            for i = 1,k do
                local l=getglobal(fname .. i)
                if (l) then
                    l:Hide()
                    l.ignore=true
                end
            end
        end
        WinUpdate(self,fname)
    elseif CursorHasItem() then
        WinAdd(self,form)
    end
end
function WinUpdate(self,fname)
    local form=frames:IsFrame(fname)
    if (not form) then return end
    local i=0
    for itemID,itemLink in pairs(form.items) do
        i=i+1
        local l=getglobal(fname .. i)
        if (fname =="AlarTrack") then
            if (not l) then
                l=frames:AddRLabel(form,i,form:GetWidth(),5,-i*20)
                frames:BOTH(l,true,5)
                frames:SetClick(l,function(this,button) self:TrackerRemove(this,button) end)
            end
            l:SetText(itemLink .. '  ' .. GetItemCount(itemID))
            form:SetHeight(i * 20)
        elseif (fname == "AlarWatch") then
            if (not l) then
                l=frames:AddSpellButton(form,i,5,-i *48,nil,true)
            end
            l:SetSpell{spellname=itemID,spelltype='spell'}
            l:SetText(itemID)
            form:SetHeight(AMOMAXBUFFS * 32)
        end
        l:Show()
        l.ignore=false
        l.itemID=itemID
        form.lastitem=i
    end
    form:SetHeight(form:GetHeight()+60)
end
function WinAdd(self,fname)
    form=frames:IsFrame(fname,true)
    local tipo,itemID,itemLink=GetCursorInfo()
    if (tipo and tipo=="item") then
        form.items[itemID]=itemLink
        WinUpdate(self,form:GetName())
    end
    ClearCursor()
end

function addon:TrackerCreate()
    local fname="AlarTrack"
    local form=frames:CreateTrackerPanel(fname,"Item Tracker")
    frames:AttachStorage(form,self.localdb.char,frames[fname])
    frames:AddHelpButton(form,[[
Drop items to track on panel
Right click to delete item]])
    form:EnableMouse(true)
    form:SetScript("OnReceiveDrag",function() self:TrackerAdd() end)
    form.items=self.localdb.char.TRACKED
    l=frames:AddCLabel(form,"Hint",L["Drop here items to be tracked"])
    frames:AddResizer(form)
    l:ClearAllPoints()
    l:SetPoint("BOTTOM",0,10)
    return form
end
function addon:TrackerRemove(this,button)
    WinRemove(self,"AlarTrack",this,button)
end
function addon:WatcherRemove(this,button)
    --WinRemove(self,"AlarTrack",this,button)
end
function addon:TrackerAdd()
    WinAdd(self,"AlarTrack")
end
function addon:WatcherAdd()
    WinAdd(self,"AlarWatch")
end
function addon:TrackerUpdate()
    WinUpdate(self,"AlarTrack")
end
function addon:WatcherUpdate()
    WinUpdate(self,"AlarWatch")
end
function addon:WatcherSave()
    self.localdb.char.WATCHED={}
    for i=1,AMOMAXBUFFS do
        local c=getglobal('AlarWatchSpell' .. i)
        if (not c) then break end
        if (c.spelltype == "spell") then
            self.localdb.char.WATCHED[c.spellname]=c.spellrank
        end
    end
end

function addon:WatcherCreate()
    local form=frames:CreateMiniPanel('AlarWatch',"Buff Watcher Config")
    frames:AttachStorage(form,self.localdb.char.frames[fname])
    frames:AddHelpButton(form,L["Drag and drop the spells you want to watch\nRight click to remove"])
    form.items=self.localdb.char.WATCHED
    form:EnableMouse(true)
    for i = 1,AMOMAXBUFFS do
        frames:AddSpellButton(form,i,15,-i *48,nil,true)
    end
    AlarWatchBtSave:SetScript("OnClick",function(...) self:WatcherSave(...) end)
    return AlarWatch
end
function addon:PlayWW()
    local sound=self:GetSet("WATCHSOUND")
    sound=Sounds[sound]
    if (sound and sound ~="none") then
        if (sound:find("%pwav$")) then
            PlaySoundFile(sound)
        else
            PlaySound(sound)
        end
    end

end

function addon:WatcherWarn(buffname)
    if (buffname) then
        self:Onscreen_Orange("Recast " .. buffname)
    end
    if (GetTime()-LastPlayedSound < 1) then
        return
    end
    LastPlayedSound=GetTime()
    self:PlayWW()
end
function addon:CmdWatch()
    if (not AlarWatch) then
        AlarWatch=self:WatcherCreate()
    end
    self:WatcherUpdate()
    AlarWatch:Show()
end
addon.CmdTrackDesc="Tracks items in a movable window"
function addon:CmdTrack()
-- Create a frame to watch farm ed objects
    if (not AlarTrack) then
        AlarTrack=self:TrackerCreate()
        AlarTrack:Show()
        self.localdb.char.trackopen=true
        self:TrackerUpdate()
    else
        if (AlarTrack:IsShown()) then
            AlarTrack:Hide()
            self.localdb.char.trackopen=false
        else
            AlarTrack:Show()
            self.localdb.char.trackopen=true
        end
    end
end
function addon:CmdHelp()
	self:Help() 
end
function addon:CmdNoFish()
	local warn=true
	if (mainhand) then 
		EquipItemByName(mainhand,MAINHAND) 
		warn=false 
	end
	if (offhand) then 
		self:ScheduleTimer(EquipItemByName,2,offhand)
	end
	if (warn) then self:Onscreen_Red(L["Check your weapons!!!!"]) end
end
function addon:CmdFish()
	if (Fishing ==Nofishing) then
		notify(L["You better learn to fish!"])
		return
	end 
	local canfish
	if (not IsEquippedItemType(FishingPole)) then
		-- let's scan for the first fishing pole we can usebetter fishing pole we can use!
		--ItemSubType is 7th index in
		local itemid,bag,slot,itemname=self:ScanBags(7,FishingPole)
		if (itemid) then
			mainhand=GetInventoryItemID("player",MAINHAND)
			offhand=GetInventoryItemID("player",OFFHAND)
			notify(L["Equipping"],itemname)
			EquipItemByName(itemid)
			canfish=true
		else
			notify(L["No fishing pole found, sorry"])
		end
	else
		canfish=true
	end	
	if (canfish) then
		notify(L["Starting to fish"])
		self.FishFrame:ShowAtCenter()
	end
	
end


-- Compatibility: self:Register() scans the method table and register events
addon:Register()
function help(self)
--===DOCBEGIN===
    self:RelNotes(4,3,0,[[
Cataclysm compatibility
]])
    self:RelNotes(4,2,5,[[
Feature: You can disable "dismount while flying" protecttion, if you feel lucky
]])
    self:RelNotes(3,3,5,[[
Fixed: an issue with localization, preventing AlarAutomation from loading
]])
    self:RelNotes(3,3,4,[[
Fixed: /is /ig /ib /io /ip should now work. Thanks to LarryCurse who found the time to file a ticket.
Feature: somewhat improved pet aggro warning. Now a check is done as soon as you enter game
]])
    self:RelNotes(3,3,2,[[
Feature: WoW 3.0.3 compatible
Fixed: Error related to GetPlayerBuffName() removed
Fixed: Error related to Parse() removed
Fixed: Error related to IsFriend() removed
Fixed: AutoPilot is working again
]])
    self:RelNotes(3,2,5,[[
Feature: WoW 2.4 compatible
Fix: QUICKFISH and WATCHER working again
]])
    self:RelNotes(3,2,4,[[
Feature: Items tracker now stays netween sessions
]])
    self:RelNotes(3,2,3,[[
Fixed: attempt to index global 'ATT' (a nil value) - No need to upgrade is this error was not present for you
Fixed: dependence from Babble-Spell removed. Now quickfish works for all
]])
    self:RelNotes(3,2,2,[[
Upgrade: Embedded libraries upgrade
Fixed: ...AlarLib-2.0.lua:4689: bad argument #1 to 'pairs' (table expected, got nil)
]])
    self:RelNotes(3,2,1,[[
Upgrade: Embedded library upgrade
]])
    self:RelNotes(3,2,0,[[
Fixed: Moved Skip gossip to proper Interface enhancements section
Feature: Most of AlarAutomation commands are now bindable
Feature: QUICKFISH when you are fishing, displays a cast button for fishing
after you catch your fish, at the point your cursor is, ready to be
clicked (even with right button, so you dont even need to move or change your finger.)
Feature: /aau safepet warns if your pet is aggressive when zoning
Feature: /aau track opens a panel to track farmed item
Feature: /aau watch watcher for buff, with /aau watch config
you chooose which buff you want to be reminded about
 when they expire in combat
]])
    self:RelNotes(3,1,0,[[
Not released for public.
]])
    self:RelNotes(3,0,3,[[
Fixed: /aau attune was not working
Feature: /aau attune panel now rescales and resizes gracefully
]])

    self:RelNotes(3,0,2,[[
Feature: Embedded Library upgrade
]])
    self:RelNotes(3,0,0,[[
Feature: Updated to WoW 2.3
Feature: Autoaccept Summon
Feature: Autoaccept Resurrect
]])
    self:HF_Title("Automation for common tasks","Description")
    self:HF_Paragraph("Description")
    self:HF_Pre([[
This addon tries to make your life in WoW easier.
It automates common tasks, store some wildely used macro and so on.
Some new commands:
]])
    self:HF_Paragraph(L["Lifestyle"])
    --self:HF_Cmd(L["Attune"],L["Ogri'la relic's emanation helper"],L["In game pad to annotare colors'sequence"])
    --self:HF_Cmd(L["Freebag"],L["Frees the smallest bag"],L["Scan your bags and try to free one of them"])
    --self:HF_Cmd(L["Swapammo"],L["Fill the smallest bag with ammonitions"],L["Useful to swap quiver or ammo puch with a standard bag when grinding"])
    self:HF_Cmd(L["Toggle Quickfish"],L["Fast cast utility"])
    self:HF_Cmd(L["Toggle Safepet"],L["Warns if your pet is aggressive when zoning"])
    self:HF_Cmd(L["Track"],L["Opens a panel to track farmed item"])
    self:HF_Cmd(L["Watch Config"],L["watcher for buff, configure it with /aau watch config"])
    self:HF_Paragraph(L["Chat related commands"])
	self:HF_CmdA("ig","ChatG",L["Speaks in guild chat without modifying current default channel"])
    self:HF_CmdA("is","ChatS",L["Speaks in say chat without modifying current default channel"])
    self:HF_CmdA("ip","ChatP",L["Speaks in party chat without modifying current default channel"])
    self:HF_CmdA("ib","ChatB",L["Speaks in the most appropriate chat without modifying current default channel (raid if in raid, party if in party)"])
    self:HF_Paragraph(L["Whisper related commands"])
    self:HF_Cmd(L["Toggle Enhance"],nil,L["Displays received whispers on screen"])
    self:HF_Cmd(L["Toggle Reflectto"],nil,L["Forwards received whispers to [nomepg]"])
    self:HF_Cmd(L["Toggle Reflect"],nil,L["Disables whispers' forwarding"])
    self:HF_Paragraph(L["Group related commands"])
    self:HF_Cmd(L["Toggle Autogroup"],nil,L["Enables autoaccept for group invite from people in your friends' list."])
    self:HF_Cmd(L["Toggle Autopilot"],nil,L["Enables autofollowing"],[[
        If a party member sends you ''follow me'', you start following him
        If a party member sends you ''follow pippo'', you start following pippo.
    BE CAREFUL WITH THIS ONE!!]])
--===DOCEND===
end
_G.BINDING_HEADER_ALARAUTOMATION="AlarAutomation"
_G.BINDING_NAME_TRACK="Track"
_G.BINDING_NAME_WATCH="Watch"
_G.BINDING_NAME_FISHON="Start Fising"
_G.BINDING_NAME_FISHOFF="Stop Fising"
_G.AAU=addon
