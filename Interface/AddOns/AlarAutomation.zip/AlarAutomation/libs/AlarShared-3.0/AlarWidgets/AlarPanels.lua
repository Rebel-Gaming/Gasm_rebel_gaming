local __FILE__=tostring(debugstack(1,2,0):match("(.*):1:")) -- MUST BE LINE 1
local MAJOR_VERSION = ("AlarPanels.lua"):gsub(".lua","")
local MINOR_VERSION = tonumber(string.sub("$Revision: 450 $", 12, -3))
local pp=print
--[[
Name: AlarPanels.lua
Revision: $Rev: 450 $
Author: Alar of Daggerspine
Email: alar@aspide.it
Website: http://www.curse.com
SVN: $HeadUrl:$
Description: Generic library
Dependencies: Ace3
License: LGPL v2.1
--]]
local me, ns = ...
--[===[@debug@
print("Loading",__FILE__," inside ",me)
--@end-debug@]===]
if (LibDebug) then LibDebug() end
local function debug(...) 
--[===[@debug@
	print(...)
--@end-debug@]===]
end
local print=_G.print
local notify=_G.print
local error=_G.error
local function dump() end
local function debugEnable() end
if (LibStub("AlarLoader-3.0",true)) then
	local rc=LibStub("AlarLoader-3.0"):GetPrintFunctions(me)
	print=rc.print
	--[===[@debug@
	debug=rc.debug
	dump=rc.dump
	--@end-debug@]===]
	notify=rc.notify
	error=rc.error
	debugEnable=rc.debugEnable
else
	debug("Missing AlarLoader-3.0")
end
local _,_,_,toc=GetBuildInfo()
if (not LibStub) then
    error("Couldn't find LibStub. Please reinstall " .. MAJOR_VERSION )
end
local lib,old=LibStub:NewLibrary(MAJOR_VERSION,MINOR_VERSION)
if (not lib) then
    debug("Already loaded a newer or equal version of " .. MAJOR_VERSION)
    return -- Already loaded
end
if (old) then
    debug(format("Upgrading %s from %s to %s",MAJOR_VERSION,old,MINOR_VERSION))
end
debugEnable(false)
local L=LibStub("AceLocale-3.0"):GetLocale('AlarShared',true)
--[[ Standard prologue end --]]
local AWG=LibStub("AlarWidgets-3.0")
local AceGUI=AWG.AceGUI
local L=AWG.L
local InjectStandardMethods=AWG.InjectStandardMethods
-- Defining 3 kind of panels at the price of one :)
local Version = 1
local mx={}

mx.FrameBackdrop = {
	bgFile = "Interface\\Tooltips\\ChatBubble-Background",
	edgeFile = "Interface\\Tooltips\\ChatBubble-BackDrop",
	tile = true, tileSize = 32, edgeSize = 32,
	insets = { left = 32, right = 32, top = 32, bottom = 32 }
}
mx.PanelBackdrop  = {
	bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
	edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
	tile = true, tileSize = 16, edgeSize = 16,
	insets = { left = 3, right = 3, top = 5, bottom = 3 }
}
function mx.frameOnSizeChanged(this)
	local self = this.obj
	local status = self.status or self.localstatus
	status.width = this:GetWidth()
	status.height = this:GetHeight()
	status.top = this:GetTop()
	status.left = this:GetLeft()
end

function mx.closeOnClick(this)
   this.obj:Fire("OnSave")
   this.obj:Hide()
end

-- Widget Methods

function mx.SetBackdrop(self,backdrop)
    if (type("backdrop" == "string")) then
       self.frame:SetBackdrop(Backdrops[backdrop])
    else
       self.frame:SetBackdrop(backdrop)
    end
end

function mx.SetStatusText(self,text)
	if (self.statustext) then
		self.statustext:SetText(text)
	end
end

function mx.SetAlpha(self,value)
	self.frame:SetAlpha(value)
end

function mx.Show(self)
	self.frame:Show()
	if (self.xbutton) then
		self.xbutton:SetFrameStrata(self.frame:GetFrameStrata())
		self.xbutton:SetFrameLevel(99)
	end
end

function mx.Lock(self)
	local status = self.status or self.localstatus
	if (self.title) then
		self.title:EnableMouse(not status.locked)
	end
	if (self.sizer_se) then
		self.sizer_se:EnableMouse(not status.locked)
	end
end


local mktitle
local mksizer
do 
	local mx=mx
	function mktitle(title,frame)
		-- Title bar
		--[[
        local ntexture=title:CreateTexture(nil,"ARTWORK")
        ntexture:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        ntexture:SetVertexColor(1,0,0)
        ntexture:SetAllPoints(title)
        ]]
        local htexture=title:CreateTexture(nil,"HIGHLIGHT")
        htexture:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        htexture:SetVertexColor(1,0,0)
        htexture:SetBlendMode("ADD")
        htexture:SetAllPoints(title)
      end	
      
	
end
do
	local mx=mx

	local function Construct_panel()
		--local frame = CreateFrame("Frame",nil,UIParent)
		--local self = {}
		self=AceGUI:Create("Window")
		local frame=self.frame
		self.type = "AlarPanel"
		InjectStandardMethods(self)
		self.Show = mx.Show
		self.Lock= mx.Lock
		self.SetTitle =  mx.SetTitle
		
		self.SetStatusText = SetStatusText
		self.ApplyStatus = mx.ApplyStatus
		self.OnWidthSet = mx.OnWidthSet
		self.OnHeightSet = mx.OnHeightSet
		self.SetAlpha =mx.SetAlpha
		
		self.localstatus = {}
		
		frame.obj = self
		--[[
		frame:SetWidth(700)
		frame:SetHeight(500)
		frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
		frame:EnableMouse()
		frame:SetMovable(true)
		frame:SetResizable(true)
		frame:SetFrameStrata("MEDIUM")
		frame:SetScript("OnHide",mx.frameOnClose)		
		frame:SetScript("OnMouseDown", mx.frameOnMouseDown)	
		--]]	
		-- Backdrop and border
		frame:SetBackdrop(mx.FrameBackdrop)
		frame:SetBackdropColor(0,0,0,1)
		--frame:SetScript("OnHide",mx.frameOnClose)
		--frame:SetMinResize(100,50)
		--frame:SetScript("OnSizeChanged", mx.frameOnSizeChanged)
		frame:SetToplevel(true)
		-- title bar
		mktitle(self.title,frame)
		return self	
	end
	AceGUI:RegisterWidgetType("AlarPanel",Construct_panel,Version)
	AWG.widgets.AlarPanel=Version
end
do
	local backdrop = {
		--bgFile = "Interface\\ChatFrame\\ChatFrameBackground", tile = true, tileSize = 16,
		bgFile="Interface\\QuestFrame\\UI-QuestTitleHighlight", tile = false, tileSize = 16,
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16,
		insets = {left = 4, right = 4, top = 4, bottom = 4},
	}
	local mx=mx
	local function Construct_transparent()
		--local self = LibStub("AceGUI-3.0"):Create("Frame")
		--local frame=self.frame
		--local frame = AceGuiCreateFrame("Frame",nil,UIParent)
		--self={}
		local self=AceGUI:Create("Window")
		local frame=self.frame
		self.type = "AlarTransparent"
		InjectStandardMethods(self)
		self.Show = mx.Show
		self.Lock= mx.Lock
		self.SetAlpha =mx.SetAlpha
		self.localstatus = {}
		
		frame.obj = self
		for _,f in pairs({frame:GetRegions()}) do
			if (f:GetObjectType()=="Texture") then f:Hide() end
		end		
		frame:SetBackdrop(backdrop)
		frame:SetBackdropColor(1,0.1,0.1)
		frame:SetBackdropBorderColor(0.4,0.4,0.4)		
		self.closebutton:Hide()
		self:EnableResize(false)
		frame:SetWidth(100)
		frame:SetHeight(30)
		frame:EnableMouse()
		frame:SetMovable(true)
		-- title bar
		mktitle(self.title,frame)
		--AceGUI:RegisterAsContainer(self)
		self:Show()
		self:EnableResize(false)
		return self	
	end
	AceGUI:RegisterWidgetType("AlarTransparent",Construct_transparent,Version)
	AWG.widgets.AlarTransparent=Version
end
--[[
	Pannello di configurazione
	Ha una casella di stato e un pulsante save
	Eventi:
		OnSave
		OnCancel
--]]
do
	local mx=mx
	local function closeOnClick(this)
		print("Chiuso sul bottone")
		local r=this.obj:Fire("OnCancel")
		if ( not r) then
		    print("Canceled")
		    return
		end
		this.obj:Hide()
	end
		
	local function Construct_config()
		local self=AceGUI:Create('AlarPanel')
		self.type="AlarConfig"
		local frame=self.frame
		local xbutton=self.xbutton
		xbutton:SetScript("OnClick",mx.closeOnClick)
		-- Save button 
		local closebutton = CreateFrame("Button",nil,frame,"UIPanelButtonTemplate")
		closebutton:SetScript("OnClick", mx.closeOnClick)
		closebutton:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-27,17)
		closebutton:SetHeight(20)
		closebutton:SetWidth(100)
		closebutton:SetText("Save")
		self.closebutton = closebutton
		closebutton.obj = self
		--Status 
		local statusbg = CreateFrame("Frame",nil,frame)
		statusbg:SetPoint("BOTTOMLEFT",frame,"BOTTOMLEFT",15,15)
		statusbg:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-132,15)
		statusbg:SetHeight(24)
		statusbg:SetBackdrop(mx.PanelBackdrop)
		statusbg:SetBackdropColor(0.1,0.1,0.1)
		statusbg:SetBackdropBorderColor(0.4,0.4,0.4)
		self.statusbg = statusbg
		local statustext = statusbg:CreateFontString(nil,"OVERLAY","GameFontNormal")
		self.statustext = statustext
		statustext:SetPoint("TOPLEFT",statusbg,"TOPLEFT",7,-2)
		statustext:SetPoint("BOTTOMRIGHT",statusbg,"BOTTOMRIGHT",-7,2)
		statustext:SetHeight(20)
		statustext:SetJustifyH("LEFT")
		statustext:SetText("")
		self.SetStatusText=mx.SetStatusText
		return self
	
	end
	AceGUI:RegisterWidgetType("AlarConfig",Construct_config,Version)
	AWG.widgets.AlarConfig=Version
end
		

