TourGuide:RegisterGuide("Stranglethorn Vale (47)", "Searing Gorge (47-48)", "Horde", function()
return [[
F Booty Bay |N|via zeppelin to Grom'gol| |NORAF|
A Whiskey Slim's Lost Grog |T| |QID|580| |NORAF|
h Booty Bay |T| |NORAF|
T Back to Booty Bay |T| |QID|1118| |NORAF|
T Deliver to MacKinley |T| |QID|2874| |NORAF|
A The Captain's Chest |T| |QID|614| |NORAF|

C The Captain's Chest |N|On the beach east of Booty Bay, head north when you reach the sea (36.3,69.7)| |QID|614| |NORAF|
N Loot the bottles on the beach |L|4098| |NORAF|
A Message in a Bottle (Part 1) |U|4098| |QID|594| |NORAF|
T Message in a Bottle (Part 1) |N|On the large island east of Booty Bay (38.5, 80.6)| |QID|594| |NORAF|
A Message in a Bottle (Part 2) |QID|630| |NORAF|
C Message in a Bottle (Part 2) |N|South-east side of the island (40.4, 82.7)| |QID|630| |NORAF|
T Message in a Bottle (Part 2) |QID|630| |NORAF|
C The Bloodsail Buccaneers (Part 5) |N|In the three ships off the coast - make sure to check downstairs in each one for the riddle.| |QID|608| |NORAF|
A Cortello's Riddle (Part 1) |N|Check downstairs in the ships, scroll is usually in the middle ship.| |U|4056| |QID|624| |NORAF|

H Booty Bay |NORAF|
T The Bloodsail Buccaneers (Part 5) |T| |QID|608| |NORAF|
T The Captain's Chest |T| |QID|614| |NORAF|
]]
end)
