
TourGuide:RegisterGuide("Azshara (50)", "The Hinterlands (50-51)", "Horde", function()
return [[
F Orgrimmar |NORAF|
h Orgrimmar |NORAF|

F Azshara |NORAF|
A Stealing Knowledge |QID|3517| |NORAF|
C Stealing Knowledge |N|At Ruins of Eldarath (36,54)| |QID|3517| |NORAF|
C Seeping Corruption (Part 1) |N|Tide Pools at: 1-(47,61) 2-(47,51) 3-(48,48) 4-(47,46)| |QID|3568| |NORAF|
T Stealing Knowledge |QID|3517| |NORAF|
A Delivery to Archmage Xylem |QID|3561| |NORAF|
A Delivery to Magatha |QID|3518| |NORAF|
A Delivery to Jes'rimon |QID|3541| |NORAF|
A Delivery to Andron Gant |QID|3542| |NORAF|
T Delivery to Archmage Xylem |N|Take teleporter at (28,50)| |QID|3561| |NORAF|
A Xylem's Payment to Jediga |QID|3565| |NORAF|

F Thunder Bluff |NORAF|
T Delivery to Magatha |N|Elder Rise| |QID|3518| |NORAF|
A Magatha's Payment to Jediga |QID|3562| |NORAF|

H Orgrimmar |NORAF|
T Rise of the Silithid |Z|Orgrimmar| |QID|32| |NORAF|
A March of the Silithid |QID|4494| |NORAF|
T Delivery to Jes'rimon |N|at (55,34)| |Z|Orgrimmar| |QID|3541| |NORAF|
A Jes'rimon's Payment to Jediga |QID|3563| |NORAF|
A Bone-Bladed Weapons |QID|4300| |NORAF|

F Undercity |NORAF|
T Delivery to Andron Gant |N|Apothecarium Quarter| |QID|3542| |NORAF|
A Andron's Payment to Jediga |QID|3564| |NORAF|
T Seeping Corruption (Part 1) |QID|3568| |NORAF|
A Vivian Lagrave |QID|4133| |NORAF|
A Seeping Corruption (Part 2) |QID|3569| |NORAF|
T Seeping Corruption (Part 2) |QID|3569| |NORAF|
]]
end)
