TourGuide:RegisterGuide("Thousand Needles (37)", "Dustwallow Marsh (37-38)", "Horde", function()
return [[
F Orgrimmar |N|Take the zeppelin, dur!| |NORAF|
T Alliance Relations (Part 4) |N|Keldran in the Valley of Spirits (21,53)| |QID|1436| |Z|Orgrimmar| |NORAF|
F The Crossroads |NORAF|
h The Crossroads |NORAF|

F Freewind Post |NORAF|
T The Swarm Grows (Part 2) |QID|1146| |NORAF| |N|Follow the road east to the edge of the flats.  There's a little camp to the south (67.6, 64.0).|
A The Swarm Grows (Part 3) |QID|1147| |NORAF|

T Parts for Kravel |QID|1112| |NORAF| |N|At the Mirage Raceway (77.8, 77.2)|
A Delivery to the Gnomes |QID|1114| |NORAF|
T Delivery to the Gnomes |QID|1114| |NORAF|
T Goblin Sponsorship (Part 5) |QID|1183| |NORAF|

A The Eighteenth Pilot |QID|1186| |NORAF|
T The Eighteenth Pilot |QID|1186| |NORAF|

A Razzeric's Tweaking |QID|1187| |NORAF|
T Encrusted Tail Fins |QID|1107| |NORAF|
A The Rumormonger |QID|1115| |NORAF|

A Parts of the Swarm (Part 1) |QID|1148| |NORAF| |U|5877| |N|Kill silithid to the south until the item drops to start this.|
C Parts of the Swarm (Part 1) |QID|1148| |NORAF|

H The Crossroads |NORAF|
T Parts of the Swarm (Part 1) |QID|1148| |NORAF| |T|
A Parts of the Swarm (Part 2) |QID|1184| |NORAF| |T|
]]end)
