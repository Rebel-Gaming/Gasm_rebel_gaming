
TourGuide_RecorderDB = "
N  |N|Tirisfal Glades,  (58.89, 59.27)|
A The New Plague |QID|11167| |N|Howling Fjord, Vengeance Landing (78.57, 29.08)|
A War is Hell |QID|11270| |N|Howling Fjord, Vengeance Landing (78.65, 31.17)|
A Let Them Eat Crow |QID|11227| |N|Howling Fjord, Vengeance Landing (79.11, 31.26)|
U |cffffffff|Hitem:33278:0:0:0:0:0:0:1535501920:70|h[Burning Torch]|h|r |N|Howling Fjord, Bleeding Vale (75.57, 32.70)|
U |cffffffff|Hitem:33238:0:0:0:0:0:0:2074408102:70|h[Crow Meat]|h|r |N|Howling Fjord, Bleeding Vale (74.64, 34.81)|
- |QID|11270.1| |QO|Fallen Combatant burned: 10/10| |N|Howling Fjord, Bleeding Vale (75.47, 33.69)|
U |cffffffff|Hitem:33221:0:0:0:0:0:0:1279255204:70|h[Plaguehound Cage]|h|r |N|Howling Fjord, Bleeding Vale (75.33, 33.54)|
- |QID|11227.1| |QO|Plaguehound Fed: 5/5| |N|Howling Fjord, Bleeding Vale (75.41, 33.58)|
T War is Hell |QID|11270| |N|Howling Fjord, Vengeance Landing (78.55, 31.13)|
A Reports from the Field |QID|11221| |N|Howling Fjord, Vengeance Landing (78.55, 31.13)|
T Let Them Eat Crow |QID|11227| |N|Howling Fjord, Vengeance Landing (79.11, 31.29)|
A Sniff Out the Enemy |QID|11253| |N|Howling Fjord, Vengeance Landing (79.11, 31.29)|
- |QID|11221.1| |QO|Listen to Razael's Report: 1/1| |N|Howling Fjord, Bleeding Vale (77.53, 34.65)|
- |QID|11221.2| |QO|Listen to Lyana's Report: 1/1| |N|Howling Fjord, Bleeding Vale (78.77, 36.90)|
T Reports from the Field |QID|11221| |N|Howling Fjord, Vengeance Landing (78.54, 31.16)|
A The Windrunner Fleet |QID|11229| |N|Howling Fjord, Vengeance Landing (78.54, 31.16)|
T The Windrunner Fleet |QID|11229| |N|The Windrunner,  (84.66, 36.39)|
A Ambushed! |QID|11230| |N|The Windrunner,  (84.66, 36.39)|
- |QID|11230.1| |QO|North Fleet Marine slain: 15/15| |N|Howling Fjord,  (84.30, 36.77)|
T Ambushed! |QID|11230| |N|The Windrunner,  (84.64, 36.40)|
U |cff1eff00|Hitem:35817:0:0:0:0:0:0:810245039:70|h[Nerubian Inner Husk]|h|r |N|The Windrunner,  (84.64, 36.40)|
A Guide Our Sights |QID|11232| |N|The Windrunner,  (84.64, 36.40)|
- |QID|11167.1| |QO|Intact Plague Container: 10/10| |N|Howling Fjord,  (81.14, 36.04)|
U |cffffffff|Hitem:33335:0:0:0:0:0:0:167844614:70|h[Cannoneer's Smoke Flare]|h|r |N|Howling Fjord, Derelict Strand (80.02, 38.08)|
- |QID|11232.1| |QO|Eastern Cannon Marked: 1/1| |N|Howling Fjord, Derelict Strand (80.36, 38.22)|
- |QID|11232.2| |QO|Western Cannon Marked: 1/1| |N|Howling Fjord, Derelict Strand (79.36, 40.20)|
T Guide Our Sights |QID|11232| |N|Howling Fjord, Bleeding Vale (79.14, 36.42)|
A Landing the Killing Blow |QID|11233| |N|Howling Fjord, Bleeding Vale (79.14, 36.42)|
- |QID|11233.1| |QO|Captain Olster slain: 1/1| |N|Howling Fjord, Derelict Strand (81.45, 43.33)|
- |QID|11233.2| |QO|Lieutenant Celeyne slain: 1/1| |N|Howling Fjord, Derelict Strand (83.14, 43.12)|
A Trail of Fire |QID|11241| |N|Howling Fjord, Derelict Strand (83.17, 43.13)|
- |QID|11233.3| |QO|Sergeant Lorric slain: 1/1| |N|Howling Fjord, Derelict Strand (81.99, 40.76)|
- |QID|11241.1| |QO|Rescue Apothecary Hanes| |N|Howling Fjord, Bleeding Vale (78.64, 37.16)|
T Landing the Killing Blow |QID|11233| |N|Howling Fjord, Bleeding Vale (78.65, 37.12)|
U |cff1eff00|Hitem:35808:0:0:0:0:0:0:1284132743:70|h[Coldstone Cutlass]|h|r |N|Howling Fjord, Bleeding Vale (78.65, 37.12)|
A Report to Anselm |QID|11234| |N|Howling Fjord, Bleeding Vale (78.69, 37.13)|
T Report to Anselm |QID|11234| |N|Howling Fjord, Vengeance Landing (78.60, 31.18)|
A A Score to Settle |QID|11272| |N|Howling Fjord, Vengeance Landing (78.60, 31.18)|
T The New Plague |QID|11167| |N|Howling Fjord, Vengeance Landing (78.56, 29.07)|
A Spiking the Mix |QID|11168| |N|Howling Fjord, Vengeance Landing (78.56, 29.07)|
T Trail of Fire |QID|11241| |N|Howling Fjord, Vengeance Landing (78.56, 29.07)|
- |QID|11168.1| |QO|Giant Toxin Gland: 3/3| |N|Howling Fjord,  (77.86, 22.35)|
T Sniff Out the Enemy |QID|11253| |N|Howling Fjord,  (75.99, 19.78)|
A The Dragonskin Map |QID|11254| |N|Howling Fjord,  (75.99, 19.78)|
T Spiking the Mix |QID|11168| |N|Howling Fjord, Vengeance Landing (78.55, 29.06)|
A Test at Sea |QID|11170| |N|Howling Fjord, Vengeance Landing (78.55, 29.06)|
T The Dragonskin Map |QID|11254| |N|Howling Fjord, Vengeance Landing (78.60, 31.13)|
A The Offensive Begins |QID|11295| |N|Howling Fjord, Vengeance Landing (78.60, 31.13)|
- |QID|11170.1| |QO|North Fleet Reservist Infected: 16/16| |N|The Frozen Sea,  (90.40, 85.01)|
T Test at Sea |QID|11170| |N|Howling Fjord, Vengeance Landing (78.59, 29.08)|
A New Agamand |QID|11304| |N|Howling Fjord, Vengeance Landing (78.59, 29.08)|
T The Offensive Begins |QID|11295| |N|Howling Fjord, Vengeance Lift (71.15, 38.99)|
A A Lesson in Fear |QID|11282| |N|Howling Fjord, Vengeance Lift (71.15, 38.99)|
A Help for Camp Winterhoof |QID|12566| |N|Howling Fjord, Vengeance Lift (71.37, 39.18)|
U |cffffffff|Hitem:33563:0:0:0:0:0:0:243178473:70|h[Forsaken Banner]|h|r |N|Howling Fjord, Balejar Watch (69.31, 39.28)|
- |QID|11282.2| |QO|Ulf the Bloodletter's Corpse Impaled: 1/1| |N|Howling Fjord, Balejar Watch (69.31, 39.28)|
- |QID|11282.1| |QO|Oric the Baleful's Corpse Impaled: 1/1| |N|Howling Fjord, Balejar Watch (69.18, 38.43)|
- |QID|11282.3| |QO|Gunnar Thorvardsson's Corpse Impaled: 1/1| |N|Howling Fjord, Balejar Watch (69.57, 40.02)|
T A Lesson in Fear |QID|11282| |N|Howling Fjord, Vengeance Lift (71.07, 39.11)|
A Baleheim Bodycount |QID|11283| |N|Howling Fjord, Vengeance Lift (71.13, 39.12)|
A Baleheim Must Burn! |QID|11285| |N|Howling Fjord, Vengeance Lift (71.13, 39.12)|
- |QID|11285.2| |QO|Winterskorn Watchtower Burned: 1/1| |N|Howling Fjord, Baleheim (67.05, 39.79)|
- |QID|11285.3| |QO|Winterskorn Bridge Burned: 1/1| |N|Howling Fjord, Baleheim (66.10, 39.84)|
- |QID|11285.1| |QO|Winterskorn Dwelling Burned: 1/1| |N|Howling Fjord, Baleheim (64.85, 41.45)|
- |QID|11285.4| |QO|Winterskorn Barracks Burned: 1/1| |N|Howling Fjord, Baleheim (64.01, 41.16)|
- |QID|11283.1| |QO|Baleheim Bodycount: 16/16| |N|Howling Fjord,  (66.44, 42.28)|
T Baleheim Bodycount |QID|11283| |N|Howling Fjord, Vengeance Lift (71.14, 39.14)|
T Baleheim Must Burn! |QID|11285| |N|Howling Fjord, Vengeance Lift (71.14, 39.14)|
A The Ambush |QID|11303| |N|Howling Fjord, Vengeance Lift (71.14, 39.14)|
T The Ambush |QID|11303| |N|Howling Fjord, Lydell's Ambush (65.87, 36.66)|
A Adding Injury to Insult |QID|12481| |N|Howling Fjord, Lydell's Ambush (65.87, 36.66)|
U |cffffffff|Hitem:33581:0:0:0:0:0:0:1554468566:70|h[Vrykul Insult]|h|r |N|Howling Fjord, Baleheim (64.41, 38.34)|
- |QID|12481.1| |QO|Bjorn Halgurdsson insulted: 1/1| |N|Howling Fjord, Baleheim (63.92, 38.68)|
- |QID|12481.2| |QO|Bjorn Halgurdsson defeated: 1/1| |N|Howling Fjord, Lydell's Ambush (66.07, 36.49)|
T Adding Injury to Insult |QID|12481| |N|Howling Fjord, Lydell's Ambush (65.87, 36.67)|
A Against Nifflevar |QID|12482| |N|Howling Fjord, Ghostblade Post (67.51, 60.63)|
A The Enemy's Legacy |QID|11423| |N|Howling Fjord, Ghostblade Post (67.40, 60.36)|
- |QID|12482.3| |QO|Dragonflayer Hunting Hound slain: 4/4| |N|Howling Fjord, Nifflevar (67.44, 56.12)|
- |QID|11423.2| |QO|Saga of the Valkyr: 1/1| |N|Howling Fjord, Nifflevar (67.42, 57.21)|
- |QID|11423.3| |QO|Saga of the Winter Curse: 1/1| |N|Howling Fjord, Nifflevar (68.88, 52.63)|
- |QID|12482.1| |QO|Dragonflayer Warrior slain: 5/5| |N|Howling Fjord, Nifflevar (67.26, 51.08)|
- |QID|12482.2| |QO|Dragonflayer Rune-Seer slain: 4/4| |N|Howling Fjord, Nifflevar (64.76, 53.50)|
- |QID|11423.1| |QO|Saga of the Twins: 1/1| |N|Howling Fjord, Nifflevar (64.76, 53.57)|
T Against Nifflevar |QID|12482| |N|Howling Fjord, Ghostblade Post (67.52, 60.55)|
T The Enemy's Legacy |QID|11423| |N|Howling Fjord, Ghostblade Post (67.39, 60.41)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:1164880706:70|h[Frostweave Cloth]|h|r |N|Howling Fjord, New Agamand (52.23, 66.42)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1323334258:70|h[Netherweave Cloth]|h|r |N|Howling Fjord, New Agamand (52.23, 66.42)|
U |cffffffff|Hitem:17056:0:0:0:0:0:0:1041147148:70|h[Light Feather]|h|r |N|Howling Fjord, New Agamand (52.23, 66.42)|
T New Agamand |QID|11304| |N|Howling Fjord, New Agamand (53.53, 66.34)|
A A Tailor-Made Formula |QID|11305| |N|Howling Fjord, New Agamand (53.53, 66.34)|
A Green Eggs and Whelps |QID|11279| |N|Howling Fjord, New Agamand (53.14, 66.87)|
A Shield Hill |QID|11424| |N|Howling Fjord, New Agamand (53.70, 65.26)|
- |QID|11305.1| |QO|Dragonflayer Patriarch's Blood: 1/1| |N|Howling Fjord, Thorvald's Camp (46.86, 68.06)|
T A Tailor-Made Formula |QID|11305| |N|Howling Fjord, New Agamand (53.51, 66.35)|
U |cff1eff00|Hitem:35856:0:0:0:0:0:0:109055988:70|h[Hair-Trigger Blunderbuss]|h|r |N|Howling Fjord, New Agamand (53.51, 66.35)|
A Apply Heat and Stir |QID|11306| |N|Howling Fjord, New Agamand (53.51, 66.35)|
U |cffffffff|Hitem:34023:0:0:0:0:0:0:1715739482:70|h[Empty Apothecary's Flask]|h|r |N|Howling Fjord, New Agamand (53.57, 66.51)|
U |cffffffff|Hitem:34024:0:0:0:0:0:0:54778338:70|h[Flask of Vrykul Blood]|h|r |N|Howling Fjord, New Agamand (53.50, 66.30)|
U |cffffffff|Hitem:33614:0:0:0:0:0:0:507923530:70|h[Empty Apothecary's Flask]|h|r |N|Howling Fjord, New Agamand (53.59, 66.46)|
U |cffffffff|Hitem:33615:0:0:0:0:0:0:906616642:70|h[Flask of Vrykul Blood]|h|r |N|Howling Fjord, New Agamand (53.51, 66.31)|
U |cffffffff|Hitem:33614:0:0:0:0:0:0:1163389264:70|h[Empty Apothecary's Flask]|h|r |N|Howling Fjord, New Agamand (53.60, 66.57)|
U |cffffffff|Hitem:33615:0:0:0:0:0:0:1153628783:70|h[Flask of Vrykul Blood]|h|r |N|Howling Fjord, New Agamand (53.51, 66.31)|
U |cffffffff|Hitem:33614:0:0:0:0:0:0:831530120:70|h[Empty Apothecary's Flask]|h|r |N|Howling Fjord, New Agamand (53.61, 66.48)|
U |cffffffff|Hitem:33615:0:0:0:0:0:0:1628093552:70|h[Flask of Vrykul Blood]|h|r |N|Howling Fjord, New Agamand (53.53, 66.32)|
- |QID|11306.1| |QO|Balanced Concoction: 1/1| |N|Howling Fjord, New Agamand (53.53, 66.32)|
T Apply Heat and Stir |QID|11306| |N|Howling Fjord, New Agamand (53.53, 66.32)|
A Field Test |QID|11307| |N|Howling Fjord, New Agamand (53.53, 66.32)|
- |QID|11307.1| |QO|Plagued Vrykul Sprayed: 10/10| |N|Howling Fjord, Halgrind (50.41, 56.37)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:70|h[Hearthstone]|h|r |N|Howling Fjord, Halgrind (48.18, 57.64)|
T Field Test |QID|11307| |N|Howling Fjord, New Agamand (53.50, 66.32)|
A Time for Cleanup |QID|11308| |N|Howling Fjord, New Agamand (53.50, 66.32)|
T Time for Cleanup |QID|11308| |N|Howling Fjord, New Agamand (53.67, 65.30)|
A Parts for the Job |QID|11309| |N|Howling Fjord, New Agamand (53.67, 65.30)|
- |QID|11309.1| |QO|Shoveltusk Ligament: 6/6| |N|Howling Fjord,  (53.89, 73.77)|
- |QID|11309.2| |QO|Fresh Pound of Flesh: 1/1| |N|Howling Fjord,  (53.05, 74.20)|
A The Dead Rise! |QID|11504| |N|Howling Fjord, The Ancient Lift (40.35, 60.28)|
T Parts for the Job |QID|11309| |N|Howling Fjord, New Agamand (53.66, 65.29)|
A Warning: Some Assembly Required |QID|11310| |N|Howling Fjord, New Agamand (53.66, 65.29)|
- |QID|11504.1| |QO|Fengir's Clue: 1/1| |N|Howling Fjord, Shield Hill (57.60, 77.53)|
- |QID|11504.2| |QO|Rodin's Clue: 1/1| |N|Howling Fjord, Shield Hill (59.14, 76.97)|
- |QID|11504.3| |QO|Isuldof's Clue: 1/1| |N|Howling Fjord, Shield Hill (59.71, 79.33)|
- |QID|11504.4| |QO|Windan's Clue: 1/1| |N|Howling Fjord, Shield Hill (61.90, 80.12)|
U |cffffffff|Hitem:27854:0:0:0:0:0:0:-2061220762:70|h[Smoked Talbuk Venison]|h|r |N|Howling Fjord, Shield Hill (62.35, 80.29)|
- |QID|11424.1| |QO|Ancient Vrykul Bone: 5/5| |N|Howling Fjord, Shield Hill (59.46, 76.21)|
T Shield Hill |QID|11424| |N|Howling Fjord, New Agamand (53.66, 65.32)|
U |cffffffff|Hitem:37091:0:0:0:0:0:0:-2101819121:70|h[Scroll of Intellect VII]|h|r |N|Howling Fjord, New Agamand (51.90, 66.69)|
U |cffffffff|Hitem:33459:0:0:0:0:0:0:2009732790:70|h[Scroll of Protection VI]|h|r |N|Howling Fjord, New Agamand (51.90, 66.69)|
U |cffffffff|Hitem:33462:0:0:0:0:0:0:1320447570:70|h[Scroll of Strength VI]|h|r |N|Howling Fjord, New Agamand (51.90, 66.69)|
- |QID|11310.1| |QO|Plagued Vrykul exterminated: 20/20| |N|Howling Fjord, Halgrind (48.02, 59.15)|
A Root Causes |QID|11182| |N|Howling Fjord, Ember Clutch (41.35, 49.69)|
- |QID|11279.1| |QO|Plagued Proto-Whelp Specimen: 10/10| |N|Howling Fjord, Ember Clutch (39.26, 48.43)|
- |QID|11182.1| |QO|Dragonflayer Handler slain: 5/5| |N|Howling Fjord, Ember Clutch (40.41, 53.40)|
U |cffffffff|Hitem:33449:0:0:0:0:0:0:927959340:70|h[Crusty Flatbread]|h|r |N|Howling Fjord, Ember Clutch (40.44, 53.23)|
- |QID|11182.2| |QO|Skeld Drakeson slain: 1/1| |N|Howling Fjord, Ember Clutch (41.37, 52.50)|
T Root Causes |QID|11182| |N|Howling Fjord, Ember Clutch (41.17, 49.54)|
T The Dead Rise! |QID|11504| |N|Howling Fjord, The Ancient Lift (40.35, 60.30)|
A Elder Atuik and Kamagua |QID|11507| |N|Howling Fjord, The Ancient Lift (40.35, 60.30)|
T Elder Atuik and Kamagua |QID|11507| |N|Howling Fjord, Kamagua (24.99, 57.05)|
A Grezzix Spindlesnap |QID|11508| |N|Howling Fjord, Kamagua (24.99, 57.05)|
A Feeding the Survivors |QID|11456| |N|Howling Fjord, Kamagua (24.99, 57.05)|
T Grezzix Spindlesnap |QID|11508| |N|Howling Fjord,  (23.13, 62.67)|
A Street \"Cred\" |QID|11509| |N|Howling Fjord,  (23.13, 62.67)|
T Street \"Cred\" |QID|11509| |N|Howling Fjord, Scalawag Point (35.12, 80.99)|
A \"Scoodles\" |QID|11510| |N|Howling Fjord, Scalawag Point (35.12, 80.99)|
A Forgotten Treasure |QID|11434| |N|Howling Fjord, Scalawag Point (35.62, 80.29)|
A Swabbin' Soap |QID|11469| |N|Howling Fjord, Scalawag Point (37.75, 79.48)|
- |QID|11510.1| |QO|Sin'dorei Scrying Crystal: 1/1| |N|Howling Fjord, Garvan's Reef (38.33, 83.58)|
- |QID|11434.1| |QO|Amani Vase: 1/1| |N|Howling Fjord,  (37.14, 85.32)|
- |QID|11434.2| |QO|Eagle Figurine: 1/1| |N|Howling Fjord, Garvan's Reef (37.79, 84.64)|
T Forgotten Treasure |QID|11434| |N|Howling Fjord, Scalawag Point (35.61, 80.31)|
A The Fragrance of Money |QID|11455| |N|Howling Fjord, Scalawag Point (35.61, 80.31)|
T \"Scoodles\" |QID|11510| |N|Howling Fjord, Scalawag Point (35.15, 80.98)|
A The Staff of Storm's Fury |QID|11511| |N|Howling Fjord, Scalawag Point (35.15, 80.98)|
A The Frozen Heart of Isuldof |QID|11512| |N|Howling Fjord, Scalawag Point (35.15, 80.98)|
A The Lost Shield of the Aesirites |QID|11519| |N|Howling Fjord, Scalawag Point (35.15, 80.98)|
A The Ancient Armor of the Kvaldir |QID|11567| |N|Howling Fjord, Scalawag Point (35.15, 80.98)|
A Gambling Debt |QID|11464| |N|Howling Fjord, Scalawag Point (36.39, 80.51)|
- |QID|11464.1| |QO|\"Silvermoon\" Harry's Debt: 1/1| |N|Howling Fjord, Scalawag Point (35.13, 80.96)|
T Gambling Debt |QID|11464| |N|Howling Fjord, Scalawag Point (36.24, 80.54)|
A Jack Likes His Drink |QID|11466| |N|Howling Fjord, Scalawag Point (36.24, 80.54)|
- |QID|11466.1| |QO|Jack Adams' Debt: 1/1| |N|Howling Fjord, Scalawag Point (35.54, 79.44)|
T Jack Likes His Drink |QID|11466| |N|Howling Fjord, Scalawag Point (36.24, 80.50)|
A Dead Man's Debt |QID|11467| |N|Howling Fjord, Scalawag Point (36.24, 80.50)|
T The Lost Shield of the Aesirites |QID|11519| |N|Howling Fjord, Garvan's Reef (37.24, 74.77)|
A Mutiny on the Mercy |QID|11527| |N|Howling Fjord, Garvan's Reef (37.24, 74.76)|
- |QID|11527.1| |QO|Barrel of Blasting Powder: 5/5| |N|Howling Fjord, Garvan's Reef (40.34, 75.21)|
T Mutiny on the Mercy |QID|11527| |N|Howling Fjord, Garvan's Reef (39.65, 74.46)|
A Sorlof's Booty |QID|11529| |N|Howling Fjord, Garvan's Reef (38.88, 72.11)|
- |QID|11529.1| |QO|Sorlof's Booty: 1/1| |N|Howling Fjord, Sorlof's Strand (40.31, 72.89)|
T Sorlof's Booty |QID|11529| |N|Howling Fjord, Garvan's Reef (37.22, 74.79)|
A The Shield of the Aesirites |QID|11530| |N|Howling Fjord, Garvan's Reef (37.22, 74.79)|
- |QID|11455.1| |QO|Bear Musk: 4/4| |N|Howling Fjord, Garvan's Reef (33.86, 80.66)|
- |QID|11469.1| |QO|Big Roy's Blubber: 1/1| |N|Howling Fjord, Garvan's Reef (31.53, 79.10)|
T Swabbin' Soap |QID|11469| |N|Howling Fjord, Scalawag Point (37.72, 79.45)|
T The Fragrance of Money |QID|11455| |N|Howling Fjord, Scalawag Point (35.63, 80.27)|
A A Traitor Among Us |QID|11473| |N|Howling Fjord, Scalawag Point (35.63, 80.27)|
T A Traitor Among Us |QID|11473| |N|Howling Fjord, Scalawag Point (35.62, 80.58)|
A Zeh'gehn Sez |QID|11459| |N|Howling Fjord, Scalawag Point (35.62, 80.58)|
T Zeh'gehn Sez |QID|11459| |N|Howling Fjord, Scalawag Point (35.66, 80.26)|
A A Carver and a Croaker |QID|11476| |N|Howling Fjord, Scalawag Point (35.66, 80.26)|
- |QID|11476.2| |QO|Shiny Knife: 1/1| |N|Howling Fjord, Scalawag Point (35.11, 80.91)|
- |QID|11476.1| |QO|Scalawag Frog: 1/1| |N|Howling Fjord, Scalawag Point (35.93, 80.82)|
T A Carver and a Croaker |QID|11476| |N|Howling Fjord, Scalawag Point (35.60, 80.59)|
A \"Crowleg\" Dan |QID|11479| |N|Howling Fjord, Scalawag Point (35.60, 80.59)|
- |QID|11479.1| |QO|\"Crowleg\" Dan slain: 1/1| |N|Howling Fjord, Scalawag Point (35.97, 83.49)|
T \"Crowleg\" Dan |QID|11479| |N|Howling Fjord, Scalawag Point (35.64, 80.33)|
A Meet Number Two |QID|11480| |N|Howling Fjord, Scalawag Point (35.64, 80.33)|
T Meet Number Two |QID|11480| |N|Howling Fjord, Scalawag Point (35.37, 79.55)|
A The Jig is Up |QID|11471| |N|Howling Fjord, Scalawag Point (35.37, 79.55)|
U |cffffffff|Hitem:27854:0:0:0:0:0:0:-2061220762:70|h[Smoked Talbuk Venison]|h|r |N|Howling Fjord, Garvan's Reef (33.73, 79.26)|
- |QID|11471.1| |QO|Jonah Sterling's Spyglass: 1/1| |N|Howling Fjord, Garvan's Reef (33.55, 78.66)|
- |QID|11512.1| |QO|The Frozen Heart of Isuldof: 1/1| |N|Howling Fjord, Garvan's Reef (32.39, 78.74)|
T The Jig is Up |QID|11471| |N|Howling Fjord, Scalawag Point (35.37, 79.54)|
- |QID|11567.1| |QO|The Ancient Armor of the Kvaldir: 1/1| |N|Howling Fjord,  (81.82, 73.95)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:70|h[Hearthstone]|h|r |N|Howling Fjord,  (81.99, 74.24)|
A The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.62, 58.76)|
U |cff1eff00|Hitem:35824:0:0:0:0:0:0:506186894:70|h[Stoneblade Slicer]|h|r |N|Howling Fjord, Kamagua (25.61, 57.51)|
U |cffffffff|Hitem:33444:0:0:0:0:0:0:931124354:70|h[Pungent Seal Whey]|h|r |N|Howling Fjord, Kamagua (25.20, 58.91)|
U |cffffffff|Hitem:8383:0:0:0:0:0:0:0:70|h[Plain Letter]|h|r |N|Howling Fjord, Kamagua (25.20, 58.91)|
- |QID|11467.1| |QO|Black Conrad's Treasure: 1/1| |N|Howling Fjord, The Isle of Spears (32.66, 60.32)|
- |QID|11456.1| |QO|Island Shoveltusk Meat: 6/6| |N|Howling Fjord, The Isle of Spears (30.65, 59.64)|
T Feeding the Survivors |QID|11456| |N|Howling Fjord, Kamagua (25.04, 57.06)|
A Arming Kamagua |QID|11457| |N|Howling Fjord, Kamagua (25.04, 57.06)|
- |QID|11457.1| |QO|Chimaera Horn: 3/3| |N|Howling Fjord, The Isle of Spears (29.06, 68.99)|
T Dead Man's Debt |QID|11467| |N|Howling Fjord, Scalawag Point (36.28, 80.37)|
U |cffffffff|Hitem:34119:0:0:0:0:0:0:978779896:70|h[Black Conrad's Treasure]|h|r |N|Howling Fjord, Scalawag Point (36.28, 80.37)|
U |cffffffff|Hitem:34127:0:0:0:0:0:0:80229530:70|h[Tasty Reef Fish]|h|r |N|Howling Fjord, Twin Shores (31.65, 74.52)|
- |QID|11472.1| |QO|Reef Bull led to a Reef Cow| |N|Howling Fjord, Twin Shores (31.35, 71.35)|
T The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.66, 58.81)|
U |cff1eff00|Hitem:7909:0:0:0:0:0:0:-2120228465:70|h[Aquamarine]|h|r |N|Howling Fjord, Kamagua (25.24, 58.90)|
U |cff1eff00|Hitem:23107:0:0:0:0:0:0:-1851793009:70|h[Shadow Draenite]|h|r |N|Howling Fjord, Kamagua (25.24, 58.90)|
U |cff0070dd|Hitem:23437:0:0:0:0:0:0:1906303375:70|h[Talasite]|h|r |N|Howling Fjord, Kamagua (25.24, 58.90)|
T Arming Kamagua |QID|11457| |N|Howling Fjord, Kamagua (25.06, 57.05)|
A Avenge Iskaal |QID|11458| |N|Howling Fjord, Kamagua (25.06, 57.05)|
- |QID|11511.1| |QO|The Staff of Storm's Fury: 1/1| |N|Howling Fjord, Iskaal (35.28, 64.81)|
- |QID|11458.1| |QO|Crazed Northsea Slaver slain: 8/8| |N|Howling Fjord, Iskaal (34.10, 63.37)|
T Avenge Iskaal |QID|11458| |N|Howling Fjord, Kamagua (25.03, 57.06)|
A Travel to Moa'ki Harbor |QID|12118| |N|Howling Fjord, Kamagua (24.65, 58.74)|
T The Staff of Storm's Fury |QID|11511| |N|Howling Fjord, The Ancient Lift (40.26, 60.15)|
T The Frozen Heart of Isuldof |QID|11512| |N|Howling Fjord, The Ancient Lift (40.26, 60.15)|
T The Shield of the Aesirites |QID|11530| |N|Howling Fjord, The Ancient Lift (40.26, 60.15)|
T The Ancient Armor of the Kvaldir |QID|11567| |N|Howling Fjord, The Ancient Lift (40.26, 60.15)|
A A Return to Resting |QID|11568| |N|Howling Fjord, The Ancient Lift (40.26, 60.15)|
U |cffffffff|Hitem:33613:0:0:0:0:0:0:230727931:70|h[Abomination Assembly Kit]|h|r |N|Howling Fjord, Halgrind (47.58, 58.60)|
- |QID|11310.1| |QO|Plagued Vrykul exterminated: 20/20| |N|Howling Fjord, Halgrind (47.58, 58.60)|
T Green Eggs and Whelps |QID|11279| |N|Howling Fjord, New Agamand (53.12, 66.87)|
A Draconis Gastritis |QID|11280| |N|Howling Fjord, New Agamand (53.12, 66.87)|
T Warning: Some Assembly Required |QID|11310| |N|Howling Fjord, New Agamand (53.64, 65.32)|
- |QID|11568.1| |QO|Shield of the Aesirites Returned: 1/1| |N|Howling Fjord, Shield Hill (57.62, 77.46)|
- |QID|11568.2| |QO|Staff of Storm's Fury Returned: 1/1| |N|Howling Fjord, Shield Hill (59.23, 76.98)|
- |QID|11568.3| |QO|Frozen Heart of Isuldof Returned: 1/1| |N|Howling Fjord, Shield Hill (59.79, 79.41)|
- |QID|11568.4| |QO|Ancient Armor of the Kvaldir Returned: 1/1| |N|Howling Fjord, Shield Hill (61.92, 80.11)|
U |cffffffff|Hitem:33441:0:0:0:0:0:0:797667862:70|h[Tillinghast's Plagued Meat]|h|r |N|Howling Fjord, Ember Clutch (41.79, 48.91)|
- |QID|11280.1| |QO|Proto-Drake Plague Results Observed: 1/1| |N|Howling Fjord, Ember Clutch (41.79, 49.10)|
T A Return to Resting |QID|11568| |N|Howling Fjord, The Ancient Lift (40.32, 60.31)|
A Return to Atuik |QID|11572| |N|Howling Fjord, The Ancient Lift (40.32, 60.31)|
T Return to Atuik |QID|11572| |N|Howling Fjord, Kamagua (25.07, 57.03)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:70|h[Hearthstone]|h|r |N|Howling Fjord, Kamagua (25.07, 57.03)|
T Draconis Gastritis |QID|11280| |N|Howling Fjord, New Agamand (53.01, 66.84)|
T Help for Camp Winterhoof |QID|12566| |N|Howling Fjord, Camp Winterhoof (48.11, 10.85)|
A Hasty Preparations |QID|11271| |N|Howling Fjord, Camp Winterhoof (48.30, 11.04)|
A Suppressing the Elements |QID|11311| |N|Howling Fjord, Camp Winterhoof (48.94, 11.82)|
A Making the Horn |QID|11275| |N|Howling Fjord, Camp Winterhoof (49.33, 11.86)|
U |cffffffff|Hitem:27854:0:0:0:0:0:0:-2061220762:70|h[Smoked Talbuk Venison]|h|r |N|Howling Fjord,  (51.48, 7.27)|
- |QID|11275.1| |QO|Undamaged Ram Horn: 6/6| |N|Howling Fjord,  (51.09, 10.33)|
- |QID|11311.1| |QO|Mountain Elementals slain: 8/8| |N|Howling Fjord, Frostblade Peak (57.42, 9.74)|
- |QID|11271.1| |QO|Spotted Hippogryph Down: 10/10| |N|Howling Fjord,  (50.28, 21.73)|
T Suppressing the Elements |QID|11311| |N|Howling Fjord, Camp Winterhoof (49.01, 12.03)|
T Making the Horn |QID|11275| |N|Howling Fjord, Camp Winterhoof (49.33, 11.84)|
A Mimicking Nature's Call |QID|11281| |N|Howling Fjord, Camp Winterhoof (49.33, 11.84)|
A The Frozen Glade |QID|11312| |N|Howling Fjord, Camp Winterhoof (49.33, 11.84)|
A The Book of Runes |QID|11350| |N|Howling Fjord, Camp Winterhoof (49.17, 12.24)|
A Keeping Watch on the Interlopers |QID|11297| |N|Howling Fjord, Camp Winterhoof (48.48, 10.53)|
A March of the Giants |QID|11365| |N|Howling Fjord, Camp Winterhoof (48.17, 10.47)|
T Hasty Preparations |QID|11271| |N|Howling Fjord, Camp Winterhoof (48.34, 10.90)|
T The Frozen Glade |QID|11312| |N|Howling Fjord, The Frozen Glade (61.52, 22.80)|
A Spirits of the Ice |QID|11313| |N|Howling Fjord, The Frozen Glade (61.52, 22.80)|
- |QID|11313.1| |QO|Icy Core: 15/15| |N|Howling Fjord, The Frozen Glade (60.13, 23.70)|
T Spirits of the Ice |QID|11313| |N|Howling Fjord, The Frozen Glade (61.45, 22.79)|
A The Fallen Sisters |QID|11314| |N|Howling Fjord, The Frozen Glade (61.45, 22.79)|
A Wild Vines |QID|11315| |N|Howling Fjord, The Frozen Glade (61.45, 22.79)|
U |cffffffff|Hitem:27854:0:0:0:0:0:0:-2061220762:71|h[Smoked Talbuk Venison]|h|r |N|Howling Fjord, The Vibrant Glade (52.17, 28.16)|
- |QID|11314.1| |QO|Chill Nymphs Freed: 7/7| |N|Howling Fjord, The Vibrant Glade (52.49, 26.92)|
- |QID|11315.1| |QO|Scarlet Ivy slain: 8/8| |N|Howling Fjord, The Vibrant Glade (52.30, 28.15)|
T Wild Vines |QID|11315| |N|Howling Fjord, The Frozen Glade (61.48, 22.80)|
T The Fallen Sisters |QID|11314| |N|Howling Fjord, The Frozen Glade (61.48, 22.80)|
A Spawn of the Twisted Glade |QID|11316| |N|Howling Fjord, The Frozen Glade (61.48, 22.80)|
A Seeds of the Blacksouled Keepers |QID|11319| |N|Howling Fjord, The Frozen Glade (61.48, 22.80)|
- |QID|11316.1| |QO|Thornvine Creeper slain: 10/10| |N|Howling Fjord, The Twisted Glade (54.47, 16.39)|
- |QID|11319.1| |QO|Spores frozen: 8/8| |N|Howling Fjord, The Twisted Glade (55.64, 17.65)|
T Seeds of the Blacksouled Keepers |QID|11319| |N|Howling Fjord, The Frozen Glade (61.49, 22.78)|
T Spawn of the Twisted Glade |QID|11316| |N|Howling Fjord, The Frozen Glade (61.49, 22.78)|
A Keeper Witherleaf |QID|11428| |N|Howling Fjord, The Frozen Glade (61.49, 22.78)|
- |QID|11428.1| |QO|Keeper Witherleaf slain: 1/1| |N|Howling Fjord, The Twisted Glade (52.51, 17.90)|
T Keeper Witherleaf |QID|11428| |N|Howling Fjord, The Frozen Glade (61.44, 22.81)|
U |cffffffff|Hitem:33450:0:0:0:0:0:0:1797081374:71|h[Carved Horn]|h|r |N|Howling Fjord,  (52.47, 4.25)|
- |QID|11281.1| |QO|Test Nokoma's Horn: 1/1| |N|Howling Fjord,  (52.40, 4.27)|
U |cff1eff00|Hitem:36599:0:0:0:0:0:-40:1997275197:71|h[Ocean Trident of the Bandit]|h|r |N|Howling Fjord, Camp Winterhoof (49.32, 11.03)|
U |cff1eff00|Hitem:35960:0:0:0:0:0:-8:951517245:71|h[Farshire Pants of the Whale]|h|r |N|Howling Fjord, Camp Winterhoof (49.32, 11.03)|
U |cff1eff00|Hitem:35968:0:0:0:0:0:-39:882573375:71|h[Bloodspore Leggings of the Invoker]|h|r |N|Howling Fjord, Camp Winterhoof (49.32, 11.03)|
U |cff1eff00|Hitem:36305:0:0:0:0:0:-45:1798504495:71|h[Coldrock Pauldrons of the Champion]|h|r |N|Howling Fjord, Camp Winterhoof (49.32, 11.03)|
U |cffffffff|Hitem:33778:0:0:0:0:0:0:369330399:71|h[Book of Runes - Chapter 1]|h|r |N|Howling Fjord, Giants' Run (72.47, 28.22)|
- |QID|11350.1| |QO|The Book of Runes: 1/1| |N|Howling Fjord, Giants' Run (72.47, 28.22)|
U |cffffffff|Hitem:27854:0:0:0:0:0:0:-2061220762:71|h[Smoked Talbuk Venison]|h|r |N|Howling Fjord,  (70.42, 18.09)|
U |cffffffff|Hitem:27854:0:0:0:0:0:0:-2061220762:71|h[Smoked Talbuk Venison]|h|r |N|Howling Fjord,  (70.68, 15.80)|
- |QID|11365.1| |QO|Runed Stone Giant Corpses Analyzed: 4/4| |N|Howling Fjord,  (70.91, 16.69)|
T Mimicking Nature's Call |QID|11281| |N|Howling Fjord, Camp Winterhoof (49.35, 11.92)|
T The Book of Runes |QID|11350| |N|Howling Fjord, Camp Winterhoof (49.18, 12.18)|
A Mastering the Runes |QID|11351| |N|Howling Fjord, Camp Winterhoof (49.18, 12.18)|
T March of the Giants |QID|11365| |N|Howling Fjord, Camp Winterhoof (48.14, 10.50)|
A The Lodestone |QID|11366| |N|Howling Fjord, Camp Winterhoof (48.14, 10.50)|
A Skorn Must Fall! |QID|11256| |N|Howling Fjord, Camp Winterhoof (48.11, 10.65)|
- |QID|11366.1| |QO|Compare Runes with the Broken Tablet: 1/1| |N|Howling Fjord, Giants' Run (71.60, 17.36)|
- |QID|11351.1| |QO|Iron Rune Carving Tools: 1/1| |N|Howling Fjord, Giants' Run (73.35, 24.95)|
T The Lodestone |QID|11366| |N|Howling Fjord, Camp Winterhoof (48.18, 10.51)|
A Demolishing Megalith |QID|11367| |N|Howling Fjord, Camp Winterhoof (48.18, 10.51)|
T Mastering the Runes |QID|11351| |N|Howling Fjord, Camp Winterhoof (49.15, 12.15)|
A The Rune of Command |QID|11352| |N|Howling Fjord, Camp Winterhoof (49.15, 12.15)|
- |QID|11352.1| |QO|Test Rune of Command: 1/1| |N|Howling Fjord, Giants' Run (70.58, 24.18)|
- |QID|11352.2| |QO|Binder Murdis slain: 1/1| |N|Howling Fjord, Giants' Run (71.81, 24.63)|
- |QID|11367.1| |QO|Megalith slain: 1/1| |N|Howling Fjord, Frostblade Peak (68.91, 10.77)|
T Demolishing Megalith |QID|11367| |N|Howling Fjord, Camp Winterhoof (48.15, 10.46)|
T The Rune of Command |QID|11352| |N|Howling Fjord, Camp Winterhoof (49.16, 12.18)|
U |cffffffff|Hitem:33340:0:0:0:0:0:0:1012143030:71|h[Winterhoof Emblem]|h|r |N|Howling Fjord, Skorn (44.35, 26.28)|
T Skorn Must Fall! |QID|11256| |N|Howling Fjord, Skorn (44.35, 26.28)|
A Gruesome, But Necessary |QID|11257| |N|Howling Fjord, Skorn (44.35, 26.28)|
A Burn Skorn, Burn! |QID|11258| |N|Howling Fjord, Skorn (44.35, 26.28)|
A Towers of Certain Doom |QID|11259| |N|Howling Fjord, Skorn (44.35, 26.28)|
- |QID|11258.2| |QO|Northeast Longhouse Set Ablaze: 1/1| |N|Howling Fjord, Skorn (46.33, 28.26)|
- |QID|11258.3| |QO|Barracks Set Ablaze: 1/1| |N|Howling Fjord, Skorn (46.11, 30.76)|
- |QID|11258.1| |QO|Northwest Longhouse Set Ablaze: 1/1| |N|Howling Fjord, Skorn (43.67, 28.55)|
- |QID|11259.1| |QO|Northwest Tower Targeted: 1/1| |N|Howling Fjord, Skorn (44.20, 29.79)|
- |QID|11257.1| |QO|Winterskorn Vrykul Dismembered: 20/20| |N|Howling Fjord, Skorn (45.22, 30.71)|
- |QID|11259.2| |QO|East Tower Targeted: 1/1| |N|Howling Fjord, Skorn (46.21, 31.92)|
- |QID|11259.3| |QO|Southwest Tower Targeted: 1/1| |N|Howling Fjord, Skorn (43.62, 34.61)|
U |cffffffff|Hitem:33345:0:0:0:0:0:0:-2110232322:71|h[Vrykul Scroll of Ascension]|h|r |N|Howling Fjord, Skorn (43.31, 35.84)|
A Stop the Ascension! |QID|11260| |N|Howling Fjord, Skorn (43.31, 35.84)|
- |QID|11259.4| |QO|Southeast Tower Targeted: 1/1| |N|Howling Fjord, Skorn (45.82, 35.91)|
T Gruesome, But Necessary |QID|11257| |N|Howling Fjord, Skorn (45.83, 35.84)|
T Burn Skorn, Burn! |QID|11258| |N|Howling Fjord, Skorn (45.83, 35.84)|
T Towers of Certain Doom |QID|11259| |N|Howling Fjord, Skorn (45.83, 35.84)|
- |QID|11261.1| |QO|Winterhoof Emblem: 1/1| |N|Howling Fjord, Skorn (45.83, 35.84)|
A The Conqueror of Skorn! |QID|11261| |N|Howling Fjord, Skorn (45.83, 35.84)|
U |cffffffff|Hitem:33346:0:0:0:0:0:0:2118945566:71|h[Vrykul Scroll of Ascension]|h|r |N|Howling Fjord, Skorn (45.07, 35.12)|
- |QID|11260.1| |QO|Halfdan the Ice-Hearted slain: 1/1| |N|Howling Fjord, Skorn (45.04, 35.70)|
T The Conqueror of Skorn! |QID|11261| |N|Howling Fjord, Camp Winterhoof (48.13, 10.79)|
A Dealing With Gjalerbron |QID|11263| |N|Howling Fjord, Camp Winterhoof (48.13, 10.79)|
T Stop the Ascension! |QID|11260| |N|Howling Fjord, Camp Winterhoof (48.13, 10.79)|
A Find Sage Mistwalker |QID|11287| |N|Howling Fjord, Camp Winterhoof (48.13, 10.79)|
A Of Keys and Cages |QID|11265| |N|Howling Fjord, Camp Winterhoof (48.13, 10.79)|
U |cffffffff|Hitem:33347:0:0:0:0:0:0:1932879392:71|h[Gjalerbron Attack Plans]|h|r |N|Howling Fjord, Gjalerbron (38.49, 8.51)|
A Gjalerbron Attack Plans |QID|11266| |N|Howling Fjord, Gjalerbron (38.49, 8.51)|
- |QID|11265.1| |QO|Gjalerbron Prisoner Freed: 10/10| |N|Howling Fjord, Gjalerbron (34.93, 10.32)|
- |QID|11263.3| |QO|Gjalerbron Sleep-Watcher slain: 8/8| |N|Howling Fjord, Gjalerbron (34.87, 10.94)|
- |QID|11263.2| |QO|Gjalerbron Rune-Caster slain: 8/8| |N|Howling Fjord, Gjalerbron (34.85, 10.91)|
- |QID|11263.1| |QO|Gjalerbron Warrior slain: 15/15| |N|Howling Fjord, Gjalerbron (35.48, 10.01)|
T Gjalerbron Attack Plans |QID|11266| |N|Howling Fjord, Camp Winterhoof (49.50, 11.49)|
A The Frost Wyrm and its Master |QID|11267| |N|Howling Fjord, Camp Winterhoof (49.50, 11.49)|
T Of Keys and Cages |QID|11265| |N|Howling Fjord, Camp Winterhoof (48.14, 10.58)|
A The Walking Dead |QID|11268| |N|Howling Fjord, Camp Winterhoof (48.14, 10.58)|
T Dealing With Gjalerbron |QID|11263| |N|Howling Fjord, Camp Winterhoof (48.11, 10.63)|
A Necro Overlord Mezhen |QID|11264| |N|Howling Fjord, Camp Winterhoof (48.11, 10.63)|
A Sleeping Giants |QID|11433| |N|Howling Fjord, Camp Winterhoof (48.36, 10.93)|
U |cffffffff|Hitem:34083:0:0:0:0:0:0:715938803:71|h[Awakening Rod]|h|r |N|Howling Fjord, The Waking Halls (35.01, 12.44)|
- |QID|11268.2| |QO|Fearsome Horror slain: 4/4| |N|Howling Fjord, The Waking Halls (36.65, 13.36)|
- |QID|11433.1| |QO|Dormant Vrykul slain: 5/5| |N|Howling Fjord, The Waking Halls (35.24, 11.47)|
- |QID|11268.1| |QO|Deathless Watcher slain: 10/10| |N|Howling Fjord, Gjalerbron (35.87, 17.03)|
- |QID|11268.3| |QO|Putrid Wight slain: 2/2| |N|Howling Fjord, Gjalerbron (35.99, 16.80)|
U |cffffffff|Hitem:27854:0:0:0:0:0:0:-2061220762:71|h[Smoked Talbuk Venison]|h|r |N|Howling Fjord, Gjalerbron (38.14, 12.22)|
- |QID|11264.1| |QO|Necro Overlord Mezhen slain: 1/1| |N|Howling Fjord, Gjalerbron (38.64, 13.04)|
U |cffffffff|Hitem:34091:0:0:0:0:0:0:1486969286:71|h[Mezhen's Writings]|h|r |N|Howling Fjord, Gjalerbron (38.64, 13.04)|
A The Slumbering King |QID|11453| |N|Howling Fjord, Gjalerbron (38.64, 13.04)|
- |QID|11453.1| |QO|Queen Angerboda slain: 1/1| |N|Howling Fjord, Winter's Terrace (41.51, 6.06)|
- |QID|11267.1| |QO|Wyrmcaller Vile slain: 1/1| |N|Howling Fjord, Gjalerbron (36.37, 7.34)|
- |QID|11267.3| |QO|Wyrmcaller's Horn: 1/1| |N|Howling Fjord, Gjalerbron (36.37, 7.34)|
U |cffffffff|Hitem:33282:0:0:0:0:0:0:-2044327974:71|h[Wyrmcaller's Horn]|h|r |N|Howling Fjord, Gjalerbron (36.27, 7.64)|
- |QID|11267.2| |QO|Glacion slain: 1/1| |N|Howling Fjord, Gjalerbron (36.44, 7.59)|
T Find Sage Mistwalker |QID|11287| |N|Howling Fjord, Steel Gate (31.14, 24.44)|
A The Artifacts of Steel Gate |QID|11286| |N|Howling Fjord, Steel Gate (31.14, 24.44)|
A Rivenwood Captives |QID|11296| |N|Howling Fjord, Steel Gate (31.23, 24.39)|
- |QID|11286.1| |QO|Steel Gate Artifact: 10/10| |N|Howling Fjord, Steel Gate (32.00, 26.38)|
T The Artifacts of Steel Gate |QID|11286| |N|Howling Fjord, Steel Gate (31.24, 24.45)|
A The Cleansing |QID|11317| |N|Howling Fjord, Steel Gate (31.24, 24.45)|
- |QID|11296.1| |QO|Winterhoof Longrunner Freed: 7/7| |N|Howling Fjord, Rivenwood (30.68, 21.41)|
T Rivenwood Captives |QID|11296| |N|Howling Fjord, Steel Gate (31.35, 24.29)|
T Keeping Watch on the Interlopers |QID|11297| |N|Howling Fjord, Apothecary Camp (26.35, 24.53)|
A What's in That Brew? |QID|11298| |N|Howling Fjord, Apothecary Camp (26.35, 24.53)|
A And You Thought Murlocs Smelled Bad! |QID|11397| |N|Howling Fjord, Apothecary Camp (26.13, 24.44)|
A Brains! Brains! Brains! |QID|11301| |N|Howling Fjord, Apothecary Camp (26.02, 24.50)|
T The Frost Wyrm and its Master |QID|11267| |N|Howling Fjord, Camp Winterhoof (49.51, 11.54)|
T The Walking Dead |QID|11268| |N|Howling Fjord, Camp Winterhoof (48.21, 10.55)|
T Necro Overlord Mezhen |QID|11264| |N|Howling Fjord, Camp Winterhoof (48.12, 10.67)|
T The Slumbering King |QID|11453| |N|Howling Fjord, Camp Winterhoof (48.12, 10.67)|
T Sleeping Giants |QID|11433| |N|Howling Fjord, Camp Winterhoof (48.31, 10.98)|
- |QID|11317.1| |QO|Cleansed of Your Inner Turmoil: 1/1| |N|Howling Fjord, Frostblade Peak (61.07, 2.33)|
T The Cleansing |QID|11317| |N|Howling Fjord, Steel Gate (31.12, 24.53)|
A In Worg's Clothing |QID|11323| |N|Howling Fjord, Steel Gate (31.12, 24.53)|
U |cffffffff|Hitem:33618:0:0:0:0:0:0:381012900:71|h[Worg Disguise]|h|r |N|Howling Fjord, Rivenwood (30.03, 6.81)|
T In Worg's Clothing |QID|11323| |N|Howling Fjord, Rivenwood (29.64, 5.72)|
A Brother Betrayers |QID|11415| |N|Howling Fjord, Rivenwood (29.64, 5.72)|
- |QID|11415.1| |QO|Bjomolf slain: 1/1| |N|Howling Fjord,  (28.01, 22.86)|
- |QID|11415.2| |QO|Varg slain: 1/1| |N|Howling Fjord,  (34.25, 28.01)|
T Brother Betrayers |QID|11415| |N|Howling Fjord, Rivenwood (29.65, 5.71)|
A Eyes of the Eagle |QID|11417| |N|Howling Fjord, Rivenwood (29.65, 5.71)|
- |QID|11417.1| |QO|Eyes of the Eagle: 1/1| |N|Howling Fjord,  (41.04, 37.74)|
- |QID|11298.1| |QO|Dwarven Keg: 5/5| |N|Howling Fjord, Whisper Gulch (32.60, 36.56)|
- |QID|11301.1| |QO|Deranged Explorer Brain: 12/12| |N|Howling Fjord, Whisper Gulch (32.31, 37.27)|
U |cffffffff|Hitem:36781:0:0:0:0:0:0:1693462555:71|h[Darkwater Clam]|h|r |N|Howling Fjord, Chillmere Coast (25.05, 34.61)|
U |cffffffff|Hitem:27854:0:0:0:0:0:0:-2061220762:71|h[Smoked Talbuk Venison]|h|r |N|Howling Fjord, Chillmere Coast (25.05, 34.61)|
U |cffffffff|Hitem:33962:0:0:0:0:0:0:-1898508896:71|h[Scourge Device]|h|r |N|Howling Fjord, Chillmere Coast (20.63, 21.02)|
A It's a Scourge Device |QID|11398| |N|Howling Fjord, Chillmere Coast (20.31, 21.08)|
A Trident of the Son |QID|11422| |N|Howling Fjord, Chillmere Coast (19.72, 22.15)|
- |QID|11397.1| |QO|Chillmere Coast Scourge Killed: 15/15| |N|Howling Fjord, Chillmere Coast (20.88, 24.74)|
- |QID|11422.1| |QO|Rotgill's Trident: 1/1| |N|Howling Fjord, Chillmere Coast (23.98, 35.40)|
T Trident of the Son |QID|11422| |N|Howling Fjord, Chillmere Coast (19.69, 22.21)|
T Brains! Brains! Brains! |QID|11301| |N|Howling Fjord, Apothecary Camp (26.01, 24.36)|
T And You Thought Murlocs Smelled Bad! |QID|11397| |N|Howling Fjord, Apothecary Camp (26.25, 24.56)|
T It's a Scourge Device |QID|11398| |N|Howling Fjord, Apothecary Camp (26.25, 24.56)|
A Bring Down Those Shields |QID|11399| |N|Howling Fjord, Apothecary Camp (26.25, 24.56)|
T What's in That Brew? |QID|11298| |N|Howling Fjord, Apothecary Camp (26.36, 24.54)|
U |cffffffff|Hitem:36781:0:0:0:0:0:0:-2104209012:71|h[Darkwater Clam]|h|r |N|Howling Fjord,  (24.30, 21.08)|
- |QID|11399.1| |QO|Scourging Crystals Destroyed: 3/3| |N|Howling Fjord, Chillmere Coast (21.53, 24.58)|
T Bring Down Those Shields |QID|11399| |N|Howling Fjord, Apothecary Camp (26.05, 24.75)|
U |cffffffff|Hitem:33618:0:0:0:0:0:0:381012900:71|h[Worg Disguise]|h|r |N|Howling Fjord, Rivenwood (26.90, 9.87)|
T Eyes of the Eagle |QID|11417| |N|Howling Fjord, Rivenwood (29.65, 5.73)|
- |QID|11324.2| |QO|Worg Disguise: 1/1| |N|Howling Fjord, Rivenwood (29.65, 5.73)|
A Alpha Worg |QID|11324| |N|Howling Fjord, Rivenwood (29.65, 5.73)|
- |QID|11324.1| |QO|Garwal slain: 1/1| |N|Howling Fjord, Rivenwood (26.77, 13.66)|
T Alpha Worg |QID|11324| |N|Howling Fjord, Steel Gate (31.11, 24.51)|
U |cff1eff00|Hitem:36307:0:0:0:0:0:-11:1723727921:71|h[Baleheim Belt of the Falcon]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
U |cff1eff00|Hitem:36321:0:0:0:0:0:-16:1696596018:71|h[Wyrmskull Epaulets of Stamina]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
U |cff1eff00|Hitem:35975:0:0:0:0:0:-34:-1828650943:71|h[Mur'gul Cap of Nature Protection]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
U |cff1eff00|Hitem:35972:0:0:0:0:0:-38:1071906865:71|h[Mur'gul Boots of the Prophet]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
U |cff1eff00|Hitem:36432:0:0:0:0:0:-43:2008088611:71|h[Silver Rope Chain of the Soldier]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
U |cff1eff00|Hitem:36630:0:0:0:0:0:-9:1306591253:71|h[Sinewed Crossbow of the Owl]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
U |cff1eff00|Hitem:36501:0:0:0:0:0:-41:1286930493:71|h[Granite Maul of the Beast]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
U |cffffffff|Hitem:36782:0:0:0:0:0:0:417485309:71|h[Succulent Clam Meat]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
U |cffffffff|Hitem:36782:0:0:0:0:0:0:293194420:71|h[Succulent Clam Meat]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
U |cffffffff|Hitem:36782:0:0:0:0:0:0:1742107852:71|h[Succulent Clam Meat]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
U |cffffffff|Hitem:36782:0:0:0:0:0:0:729356744:71|h[Succulent Clam Meat]|h|r |N|Dragonblight, Moa'ki Harbor (48.36, 74.44)|
T Travel to Moa'ki Harbor |QID|12118| |N|Dragonblight, Moa'ki Harbor (48.04, 74.80)|
A Your Presence is Required at Agmar's Hammer |QID|11996| |N|Dragonblight, Moa'ki Harbor (48.04, 74.80)|
A Into the Fold |QID|11978| |N|Dragonblight, Westwind Refugee Camp (13.65, 49.01)|
A Pride of the Horde |QID|11980| |N|Dragonblight, Westwind Refugee Camp (14.13, 49.82)|
- |QID|11980.1| |QO|Anub'ar Ambusher slain: 15/15| |N|Dragonblight,  (15.06, 47.84)|
- |QID|11978.1| |QO|Horde Armaments: 10/10| |N|Dragonblight,  (16.62, 50.10)|
T Pride of the Horde |QID|11980| |N|Dragonblight, Westwind Refugee Camp (14.21, 49.90)|
T Into the Fold |QID|11978| |N|Dragonblight, Westwind Refugee Camp (13.46, 49.35)|
A Blood Oath of the Horde |QID|11983| |N|Dragonblight, Westwind Refugee Camp (13.46, 49.35)|
U |cffffffff|Hitem:35784:0:0:0:0:0:0:855038738:71|h[Blood Oath of the Horde]|h|r |N|Dragonblight, Westwind Refugee Camp (13.65, 49.72)|
- |QID|11983.1| |QO|Taunka Admitted Into the Horde: 5/5| |N|Dragonblight, Westwind Refugee Camp (13.19, 49.59)|
T Blood Oath of the Horde |QID|11983| |N|Dragonblight, Westwind Refugee Camp (13.28, 49.54)|
A Agmar's Hammer |QID|12008| |N|Dragonblight, Westwind Refugee Camp (13.17, 49.44)|
T Agmar's Hammer |QID|12008| |N|Dragonblight, Agmar's Hammer (38.11, 46.36)|
A Victory Nears... |QID|12034| |N|Dragonblight, Agmar's Hammer (38.11, 46.36)|
T Your Presence is Required at Agmar's Hammer |QID|11996| |N|Dragonblight, Agmar's Hammer (38.06, 46.31)|
A Rifle the Bodies |QID|11999| |N|Dragonblight, Agmar's Hammer (38.06, 46.31)|
A Wanted: Magister Keldonus |QID|12089| |N|Dragonblight, Agmar's Hammer (37.64, 46.54)|
A Wanted: Gigantaur |QID|12090| |N|Dragonblight, Agmar's Hammer (37.64, 46.54)|
A Wanted: Dreadtalon |QID|12091| |N|Dragonblight, Agmar's Hammer (37.64, 46.54)|
T Victory Nears... |QID|12034| |N|Dragonblight, Agmar's Hammer (36.66, 46.56)|
A From the Depths of Azjol-Nerub |QID|12036| |N|Dragonblight, Agmar's Hammer (36.66, 46.56)|
A Black Blood of Yogg-Saron |QID|12039| |N|Dragonblight, Agmar's Hammer (36.65, 47.30)|
A Imbeciles Abound! |QID|12189| |N|Dragonblight, Agmar's Hammer (36.12, 48.76)|
A Containing the Rot |QID|12100| |N|Dragonblight, Agmar's Hammer (37.13, 48.55)|
A Marked for Death: High Cultist Zangus |QID|12056| |N|Dragonblight, Agmar's Hammer (35.84, 48.31)|
- |QID|12089.1| |QO|Magister Keldonus slain: 1/1| |N|Dragonblight, Moonrest Gardens (21.11, 63.62)|
- |QID|12090.1| |QO|Gigantaur slain: 1/1| |N|Dragonblight, Snowfall Glade (47.77, 62.59)|
- |QID|12091.1| |QO|Dreadtalon slain: 1/1| |N|Dragonblight, The Dragon Wastes (45.95, 43.25)|
T Wanted: Magister Keldonus |QID|12089| |N|Dragonblight, Agmar's Hammer (35.86, 48.31)|
T Wanted: Gigantaur |QID|12090| |N|Dragonblight, Agmar's Hammer (35.86, 48.31)|
T Wanted: Dreadtalon |QID|12091| |N|Dragonblight, Agmar's Hammer (35.86, 48.31)|
U |cff1eff00|Hitem:38117:0:0:0:0:0:0:592471670:72|h[Dreadtalon's Clutch]|h|r |N|Dragonblight, Agmar's Hammer (35.86, 48.31)|
A To Dragon's Fall |QID|12095| |N|Dragonblight, Agmar's Hammer (35.86, 48.31)|
T To Dragon's Fall |QID|12095| |N|Dragonblight, Dragon's Fall (47.24, 32.97)|
A Sarathstra, Scourge of the North |QID|12097| |N|Dragonblight, Dragon's Fall (47.24, 32.97)|
A Pest Control |QID|12144| |N|Dragonblight, Dragon's Fall (46.77, 33.44)|
- |QID|12097.1| |QO|Sarathstra's Frozen Heart: 1/1| |N|Dragonblight, The Dragon Wastes (48.43, 30.91)|
U |cffffffff|Hitem:36856:0:0:0:0:0:0:1912432548:72|h[Emblazoned Battle Horn]|h|r |N|Dragonblight,  (42.46, 39.29)|
A Disturbing Implications |QID|12147| |N|Dragonblight,  (42.46, 39.29)|
T Disturbing Implications |QID|12147| |N|Dragonblight, Wyrmrest Temple (59.97, 55.18)|
A One of a Kind |QID|12148| |N|Dragonblight, Wyrmrest Temple (59.97, 55.18)|
- |QID|12148.1| |QO|Emblazoned Battle Horn: 1/1| |N|Dragonblight, The Dragon Wastes (53.06, 59.91)|
T One of a Kind |QID|12148| |N|Dragonblight, Wyrmrest Temple (59.93, 55.16)|
A Mighty Magnataur |QID|12149| |N|Dragonblight, Wyrmrest Temple (59.93, 55.16)|
- |QID|12149.1| |QO|Iceshatter slain: 1/1| |N|Dragonblight, The Dragon Wastes (65.78, 51.17)|
- |QID|12144.2| |QO|Dragonblight Magnataur: 3/3| |N|Dragonblight, The Dragon Wastes (65.78, 51.17)|
- |QID|12149.2| |QO|Bloodfeast slain: 1/1| |N|Dragonblight, The Dragon Wastes (67.35, 70.35)|
- |QID|12149.3| |QO|Drakegore slain: 1/1| |N|Dragonblight, The Dragon Wastes (67.62, 40.46)|
T Mighty Magnataur |QID|12149| |N|Dragonblight, Wyrmrest Temple (59.96, 55.13)|
A Reclusive Runemaster |QID|12150| |N|Dragonblight, Wyrmrest Temple (59.96, 55.13)|
- |QID|12150.1| |QO|Name of the Magnataur Warlord| |N|Dragonblight,  (71.66, 49.93)|
T Reclusive Runemaster |QID|12150| |N|Dragonblight, Wyrmrest Temple (59.96, 55.14)|
A Wanton Warlord |QID|12151| |N|Dragonblight, Wyrmrest Temple (59.96, 55.14)|
- |QID|12151.1| |QO|Grom'thar's Head: 1/1| |N|Dragonblight, The Dragon Wastes (57.80, 75.45)|
A Cycle of Life |QID|12454| |N|Dragonblight, Emerald Dragonshrine (64.52, 72.14)|
- |QID|12454.1| |QO|Emerald Skytalon slain: 5/5| |N|Dragonblight, Emerald Dragonshrine (63.08, 72.25)|
T Cycle of Life |QID|12454| |N|Dragonblight, Emerald Dragonshrine (64.95, 74.01)|
A The Plume of Alystros |QID|12456| |N|Dragonblight, Emerald Dragonshrine (64.95, 74.01)|
- |QID|12456.1| |QO|The Plume of Alystros: 1/1| |N|Dragonblight, Emerald Dragonshrine (64.83, 77.79)|
T The Plume of Alystros |QID|12456| |N|Dragonblight, Emerald Dragonshrine (64.73, 72.30)|
T Wanton Warlord |QID|12151| |N|Dragonblight, Wyrmrest Temple (59.98, 55.26)|
T Sarathstra, Scourge of the North |QID|12097| |N|Dragonblight, Agmar's Hammer (35.84, 48.39)|
U |cff0070dd|Hitem:38533:0:0:0:0:0:0:1007879946:72|h[Girdle of Forceful Annihilation]|h|r |N|Dragonblight, Agmar's Hammer (35.98, 47.89)|
- |QID|12100.2| |QO|Rot Resistant Organ: 1/1| |N|Dragonblight,  (31.59, 46.82)|
U |cffffffff|Hitem:27854:0:0:0:0:0:0:-2061220762:72|h[Smoked Talbuk Venison]|h|r |N|Dragonblight,  (30.77, 48.91)|
- |QID|12100.1| |QO|Infected Wildlife slain: 15/15| |N|Dragonblight,  (28.84, 47.83)|
- |QID|12056.1| |QO|Head of High Cultist Zangus: 1/1| |N|Dragonblight, The Pit of Narjun (28.79, 49.77)|
- |QID|12039.1| |QO|Black Blood of Yogg-Saron Sample: 10/10| |N|Dragonblight, The Pit of Narjun (28.82, 49.13)|
- |QID|12036.1| |QO|Pit of Narjun Explored| |N|Dragonblight, The Pit of Narjun (26.30, 49.98)|
A An Enemy in Arthas |QID|12040| |N|Dragonblight, The Pit of Narjun (26.12, 50.71)|
A Death to the Traitor King |QID|13167| |N|Dragonblight, The Pit of Narjun (26.12, 50.71)|
A Don't Forget the Eggs! |QID|13182| |N|Dragonblight, The Pit of Narjun (26.12, 50.71)|
- |QID|12040.1| |QO|Anub'ar Underlord slain: 6/6| |N|Dragonblight, The Pit of Narjun (28.56, 47.59)|
T An Enemy in Arthas |QID|12040| |N|Dragonblight, The Pit of Narjun (26.11, 50.69)|
A The Lost Empire |QID|12041| |N|Dragonblight, The Pit of Narjun (26.11, 50.69)|
A Avenge this Atrocity! |QID|12006| |N|Dragonblight, Moonrest Gardens (24.18, 59.96)|
U |cffffffff|Hitem:35792:0:0:0:0:0:0:64389310:72|h[Mage Hunter Personal Effects]|h|r |N|Dragonblight, Moonrest Gardens (24.55, 59.04)|
U |cffffffff|Hitem:35792:0:0:0:0:0:0:919228906:72|h[Mage Hunter Personal Effects]|h|r |N|Dragonblight, Moonrest Gardens (24.55, 59.04)|
U |cffffffff|Hitem:35792:0:0:0:0:0:0:88276276:72|h[Mage Hunter Personal Effects]|h|r |N|Dragonblight, Moonrest Gardens (24.55, 59.04)|
U |cffffffff|Hitem:35792:0:0:0:0:0:0:700745214:72|h[Mage Hunter Personal Effects]|h|r |N|Dragonblight, Moonrest Gardens (24.55, 59.04)|
U |cffffffff|Hitem:35792:0:0:0:0:0:0:1683294164:72|h[Mage Hunter Personal Effects]|h|r |N|Dragonblight, Moonrest Gardens (24.31, 61.27)|
U |cffffffff|Hitem:35792:0:0:0:0:0:0:1822870036:72|h[Mage Hunter Personal Effects]|h|r |N|Dragonblight, Moonrest Gardens (24.72, 61.57)|
U |cffffffff|Hitem:35792:0:0:0:0:0:0:259049091:72|h[Mage Hunter Personal Effects]|h|r |N|Dragonblight, Moonrest Gardens (23.42, 61.19)|
U |cffffffff|Hitem:35792:0:0:0:0:0:0:811711942:72|h[Mage Hunter Personal Effects]|h|r |N|Dragonblight, Moonrest Gardens (23.28, 58.43)|
- |QID|11999.1| |QO|Moonrest Gardens Plans: 1/1| |N|Dragonblight, Moonrest Gardens (23.28, 58.43)|
- |QID|12006.1| |QO|Blue Dragonflight forces at Moonrest Gardens slain: 15/15| |N|Dragonblight, Glittering Strand (24.73, 64.11)|
T Avenge this Atrocity! |QID|12006| |N|Dragonblight, Moonrest Gardens (24.17, 60.08)|
A End Arcanimus |QID|12013| |N|Dragonblight, Moonrest Gardens (24.17, 60.08)|
- |QID|12013.1| |QO|Arcanimus slain: 1/1| |N|Dragonblight, Moonrest Gardens (20.03, 59.69)|
T End Arcanimus |QID|12013| |N|Dragonblight, Moonrest Gardens (24.22, 60.19)|
T From the Depths of Azjol-Nerub |QID|12036| |N|Dragonblight, Agmar's Hammer (36.66, 46.52)|
A The Might of the Horde |QID|12053| |N|Dragonblight, Agmar's Hammer (36.66, 46.52)|
T Rifle the Bodies |QID|11999| |N|Dragonblight, Agmar's Hammer (38.00, 46.24)|
A Prevent the Accord |QID|12005| |N|Dragonblight, Agmar's Hammer (38.00, 46.24)|
T The Lost Empire |QID|12041| |N|Dragonblight, Agmar's Hammer (38.10, 46.35)|
T Black Blood of Yogg-Saron |QID|12039| |N|Dragonblight, Agmar's Hammer (36.61, 47.07)|
A Scourge Armaments |QID|12048| |N|Dragonblight, Agmar's Hammer (36.61, 47.07)|
T Containing the Rot |QID|12100| |N|Dragonblight, Agmar's Hammer (37.17, 48.58)|
A The Good Doctor... |QID|12101| |N|Dragonblight, Agmar's Hammer (37.17, 48.58)|
T The Good Doctor... |QID|12101| |N|Dragonblight, Agmar's Hammer (36.09, 48.79)|
A In Search of the Ruby Lilac |QID|12102| |N|Dragonblight, Agmar's Hammer (36.09, 48.79)|
T Marked for Death: High Cultist Zangus |QID|12056| |N|Dragonblight, Agmar's Hammer (35.84, 48.26)|
A Strength of Icemist |QID|12063| |N|Dragonblight, Agmar's Hammer (35.70, 45.94)|
U |cffffffff|Hitem:33444:0:0:0:0:0:0:2111670216:72|h[Pungent Seal Whey]|h|r |N|Dragonblight, Agmar's Hammer (37.30, 46.63)|
U |cffffffff|Hitem:17056:0:0:0:0:0:0:1097548492:72|h[Light Feather]|h|r |N|Dragonblight, Agmar's Hammer (37.30, 46.63)|
U |cffffffff|Hitem:17058:0:0:0:0:0:0:1173071576:72|h[Fish Oil]|h|r |N|Dragonblight, Agmar's Hammer (37.30, 46.63)|
U |cff0070dd|Hitem:37796:0:0:0:0:0:0:-2023919292:72|h[Earthbound Cape]|h|r |N|Dragonblight, Agmar's Hammer (37.93, 46.10)|
U |cff1eff00|Hitem:35980:0:0:0:0:0:-36:1338179634:72|h[Foothold Boots of the Sorcerer]|h|r |N|Dragonblight, Agmar's Hammer (37.25, 46.66)|
- |QID|12053.1| |QO|Warsong Battle Standard Defended| |N|Dragonblight, Icemist Village (27.22, 42.85)|
T Strength of Icemist |QID|12063| |N|Dragonblight, Icemist Village (22.64, 41.79)|
A Chains of the Anub'ar |QID|12064| |N|Dragonblight, Icemist Village (22.64, 41.79)|
U |cffffffff|Hitem:28501:0:0:0:0:0:0:190607232:72|h[Ravager Egg Omelet]|h|r |N|Dragonblight, Icemist Village (22.64, 39.95)|
U |cffffffff|Hitem:43463:0:0:0:0:0:0:-1623614371:72|h[Scroll of Agility VII]|h|r |N|Dragonblight, Icemist Village (22.64, 39.95)|
U |cffffffff|Hitem:36744:0:0:0:0:0:0:1151389358:72|h[Flesh-bound Tome]|h|r |N|Dragonblight, Icemist Village (25.29, 44.13)|
A The Flesh-Bound Tome |QID|12057| |N|Dragonblight, Icemist Village (25.29, 44.13)|
- |QID|12048.1| |QO|Scourge Armament: 8/8| |N|Dragonblight, Icemist Village (25.75, 43.98)|
U |cffffffff|Hitem:21254:0:0:0:0:0:0:78041107:72|h[Winter Veil Cookie]|h|r |N|Dragonblight, Icemist Village (26.13, 43.49)|
- |QID|12064.3| |QO|Sinok's Key Fragment: 1/1| |N|Dragonblight, Icemist Village (26.42, 45.03)|
- |QID|12064.1| |QO|Anok'ra's Key Fragment: 1/1| |N|Dragonblight, Icemist Village (24.93, 43.99)|
U |cffffffff|Hitem:21254:0:0:0:0:0:0:78041107:72|h[Winter Veil Cookie]|h|r |N|Dragonblight, Icemist Village (24.44, 39.75)|
- |QID|12064.2| |QO|Tivax's Key Fragment: 1/1| |N|Dragonblight, Icemist Village (23.85, 39.05)|
T Chains of the Anub'ar |QID|12064| |N|Dragonblight, Icemist Village (22.61, 41.83)|
A Return of the High Chief |QID|12069| |N|Dragonblight, Icemist Village (22.61, 41.83)|
- |QID|12069.1| |QO|Fragment of Anub'et'kan's Husk: 1/1| |N|Dragonblight, Icemist Village (25.03, 39.81)|
- |QID|12005.1| |QO|Wind Trader Mu'fah's Remains: 1/1| |N|Dragonblight, Moonrest Gardens (18.59, 58.14)|
- |QID|12005.2| |QO|The Scales of Goramosh: 1/1| |N|Dragonblight, Moonrest Gardens (19.46, 58.04)|
U |cffffffff|Hitem:36746:0:0:0:0:0:0:1273452700:72|h[Goramosh's Strange Device]|h|r |N|Dragonblight, Moonrest Gardens (19.51, 57.96)|
A A Strange Device |QID|12059| |N|Dragonblight, Moonrest Gardens (19.51, 57.96)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:72|h[Hearthstone]|h|r |N|Dragonblight, Moonrest Gardens (19.51, 57.96)|
T Prevent the Accord |QID|12005| |N|Dragonblight, Agmar's Hammer (38.05, 46.14)|
T A Strange Device |QID|12059| |N|Dragonblight, Agmar's Hammer (38.05, 46.14)|
A Projections and Plans |QID|12061| |N|Dragonblight, Agmar's Hammer (38.05, 46.14)|
T The Might of the Horde |QID|12053| |N|Dragonblight, Agmar's Hammer (36.71, 46.56)|
A Attack by Air!  |QID|12071| |N|Dragonblight, Agmar's Hammer (36.71, 46.56)|
T Scourge Armaments |QID|12048| |N|Dragonblight, Agmar's Hammer (36.58, 47.10)|
T Attack by Air!  |QID|12071| |N|Dragonblight, Agmar's Hammer (37.19, 45.84)|
A Blightbeasts be Damned! |QID|12072| |N|Dragonblight, Agmar's Hammer (37.19, 45.84)|
T Return of the High Chief |QID|12069| |N|Dragonblight, Agmar's Hammer (36.40, 45.56)|
A All Hail Roanauk! |QID|12140| |N|Dragonblight, Agmar's Hammer (36.77, 45.80)|
T The Flesh-Bound Tome |QID|12057| |N|Dragonblight, Agmar's Hammer (35.85, 48.33)|
A Koltira and the Language of Death |QID|12115| |N|Dragonblight, Agmar's Hammer (35.85, 48.33)|
T Koltira and the Language of Death |QID|12115| |N|Dragonblight, Agmar's Hammer (36.17, 47.58)|
A In Service of Blood |QID|12125| |N|Dragonblight, Agmar's Hammer (36.17, 47.58)|
A In Service of the Unholy |QID|12126| |N|Dragonblight, Agmar's Hammer (36.17, 47.58)|
A In Service of Frost |QID|12127| |N|Dragonblight, Agmar's Hammer (36.17, 47.58)|
- |QID|12140.1| |QO|Roanauk Icemist initiated: 1/1| |N|Dragonblight, Agmar's Hammer (36.33, 45.59)|
T All Hail Roanauk! |QID|12140| |N|Dragonblight, Agmar's Hammer (36.93, 45.96)|
U |cffffffff|Hitem:36774:0:0:0:0:0:0:654028654:72|h[Valnok's Flare Gun]|h|r |N|Dragonblight,  (28.33, 46.72)|
- |QID|12072.1| |QO|Anub'ar Blightbeast slain: 25/25| |N|Dragonblight, Icemist Village (25.69, 46.97)|
U |cffffffff|Hitem:36747:0:0:0:0:0:0:1748647554:72|h[Surge Needle Teleporter]|h|r |N|Dragonblight, Moonrest Gardens (20.36, 55.09)|
- |QID|12061.1| |QO|Object on the Surge Needle observed: 1/1| |N|Dragonblight, Surge Needle (19.68, 60.32)|
T Blightbeasts be Damned! |QID|12072| |N|Dragonblight, Agmar's Hammer (37.21, 45.81)|
T Projections and Plans |QID|12061| |N|Dragonblight, Agmar's Hammer (37.98, 46.25)|
A The Focus on the Beach |QID|12066| |N|Dragonblight, Agmar's Hammer (37.98, 46.25)|
U |cffffffff|Hitem:36751:0:0:0:0:0:0:436771317:72|h[Ley Line Focus Control Ring]|h|r |N|Dragonblight, Glittering Strand (26.54, 65.07)|
- |QID|12066.1| |QO|Ley line focus information retrieved: 1/1| |N|Dragonblight, Glittering Strand (26.42, 65.02)|
T The Focus on the Beach |QID|12066| |N|Dragonblight, Agmar's Hammer (37.96, 46.22)|
A Atop the Woodlands |QID|12084| |N|Dragonblight, Agmar's Hammer (37.96, 46.22)|
A Strengthen the Ancients |QID|12096| |N|Dragonblight, Agmar's Hammer (36.56, 47.72)|
- |QID|12125.1| |QO|Filled Blood Gem: 1/1| |N|Dragonblight, Indu'le Village (35.67, 65.73)|
U |cffffffff|Hitem:36786:0:0:0:0:0:0:1472768634:72|h[Bark of the Walkers]|h|r |N|Dragonblight, Lothalor Woodlands (34.53, 67.39)|
- |QID|12096.1| |QO|Lothalor Ancient strengthened: 3/3| |N|Dragonblight, Lothalor Woodlands (34.58, 71.34)|
U |cffffffff|Hitem:36779:0:0:0:0:0:0:1048139626:72|h[Ley Line Focus Control Amulet]|h|r |N|Dragonblight, Lothalor Woodlands (32.38, 72.31)|
- |QID|12084.1| |QO|Ley line focus information retrieved: 1/1| |N|Dragonblight, Lothalor Woodlands (32.38, 72.31)|
U |cffffffff|Hitem:36780:0:0:0:0:0:0:1585010538:72|h[Lieutenant Ta'zinni's Letter]|h|r |N|Dragonblight, Lothalor Woodlands (32.38, 72.31)|
A A Letter for Home |QID|12085| |N|Dragonblight, Lothalor Woodlands (32.38, 72.31)|
T In Service of Blood |QID|12125| |N|Dragonblight, Agmar's Hammer (36.78, 46.62)|
T Strengthen the Ancients |QID|12096| |N|Dragonblight, Agmar's Hammer (36.53, 47.76)|
U |cff1eff00|Hitem:38112:0:0:0:0:0:0:1230500:72|h[Bark Covered Pauldrons]|h|r |N|Dragonblight, Agmar's Hammer (36.53, 47.76)|
T Atop the Woodlands |QID|12084| |N|Dragonblight, Agmar's Hammer (37.97, 46.24)|
A Search Indu'le Village |QID|12106| |N|Dragonblight, Agmar's Hammer (37.97, 46.24)|
T A Letter for Home |QID|12085| |N|Dragonblight, Agmar's Hammer (38.10, 46.31)|
A Let Nothing Go To Waste |QID|11958| |N|Dragonblight, Moa'ki Harbor (48.03, 74.77)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.31, 74.37)|
A Signs of Big Watery Trouble |QID|12011| |N|Dragonblight, Moa'ki Harbor (47.81, 79.95)|
T Signs of Big Watery Trouble |QID|12011| |N|Dragonblight, Moa'ki Harbor (47.72, 76.72)|
A The Bait |QID|12016| |N|Dragonblight, Moa'ki Harbor (47.72, 76.72)|
- |QID|12016.1| |QO|The Flesh of \"Two Huge Pincers\": 1/1| |N|Dragonblight, Kili'ua's Atoll (42.89, 81.25)|
T The Bait |QID|12016| |N|Dragonblight, Moa'ki Harbor (47.64, 76.67)|
A Meat on the Hook |QID|12017| |N|Dragonblight, Moa'ki Harbor (47.64, 76.67)|
- |QID|12017.1| |QO|Tu'u'gwar slain: 1/1| |N|Dragonblight, Moa'ki Harbor (46.70, 78.21)|
T Meat on the Hook |QID|12017| |N|Dragonblight, Moa'ki Harbor (47.64, 76.70)|
- |QID|11958.1| |QO|Stolen Moa'ki Goods: 6/6| |N|Dragonblight, Snowfall Glade (47.44, 64.19)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.45, 64.13)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.30, 74.29)|
T Let Nothing Go To Waste |QID|11958| |N|Dragonblight, Moa'ki Harbor (48.00, 74.81)|
A Slay Loguhn |QID|11959| |N|Dragonblight, Moa'ki Harbor (48.00, 74.81)|
U |cffffffff|Hitem:35688:0:0:0:0:0:0:1036253852:72|h[Blood of Loguhn]|h|r |N|Dragonblight, Snowfall Glade (46.67, 59.23)|
- |QID|11959.1| |QO|Loguhn's Blood Smeared: 1/1| |N|Dragonblight, Snowfall Glade (46.67, 59.23)|
T Slay Loguhn |QID|11959| |N|Dragonblight, Moa'ki Harbor (48.05, 74.91)|
U |cff1eff00|Hitem:43622:0:0:0:0:0:0:1549229908:72|h[Froststeel Lockbox]|h|r |N|Dragonblight, Moa'ki Harbor (48.33, 74.40)|
A Tua'kea's Crab Traps |QID|12009| |N|Dragonblight, Moa'ki Harbor (48.06, 76.12)|
A Spiritual Insight |QID|12028| |N|Dragonblight, Moa'ki Harbor (49.07, 75.75)|
U |cffffffff|Hitem:35907:0:0:0:0:0:0:355343978:72|h[Toalu'u's Spiritual Incense]|h|r |N|Dragonblight, Moa'ki Harbor (48.94, 75.80)|
- |QID|12028.1| |QO|Spiritual insight concerning Indu'le Village attained.| |N|Dragonblight, Moa'ki Harbor (48.94, 75.85)|
T Spiritual Insight |QID|12028| |N|Dragonblight, Moa'ki Harbor (49.10, 75.66)|
A Elder Mana'loa |QID|12030| |N|Dragonblight, Moa'ki Harbor (49.10, 75.66)|
- |QID|12009.1| |QO|Tua'kea Crab Trap: 8/8| |N|Dragonblight, Moa'ki Harbor (50.30, 79.28)|
T Tua'kea's Crab Traps |QID|12009| |N|Dragonblight, Moa'ki Harbor (47.76, 76.67)|
T Elder Mana'loa |QID|12030| |N|Dragonblight, Indu'le Village (36.67, 65.39)|
A Freedom for the Lingering |QID|12031| |N|Dragonblight, Indu'le Village (36.67, 65.39)|
U |cffffffff|Hitem:21254:0:0:0:0:0:0:78041107:72|h[Winter Veil Cookie]|h|r |N|Dragonblight, Lake Indu'le (38.19, 66.91)|
T Search Indu'le Village |QID|12106| |N|Dragonblight, Lake Indu'le (40.23, 66.79)|
A The End of the Line |QID|12110| |N|Dragonblight, Lake Indu'le (40.23, 66.79)|
U |cffffffff|Hitem:36815:0:0:0:0:0:0:1768515928:72|h[Ley Line Focus Control Talisman]|h|r |N|Dragonblight, Lake Indu'le (39.79, 67.21)|
- |QID|12110.1| |QO|Ley Line Focus information retrieved: 1/1| |N|Dragonblight, Lake Indu'le (39.79, 67.21)|
- |QID|12031.1| |QO|Indu'le spirits put to rest: 15/15| |N|Dragonblight, Indu'le Village (36.41, 65.68)|
T Freedom for the Lingering |QID|12031| |N|Dragonblight, Indu'le Village (36.49, 65.20)|
A Conversing With the Depths |QID|12032| |N|Dragonblight, Indu'le Village (36.49, 65.20)|
- |QID|12032.1| |QO|Oacha'noa's compulsion obeyed.| |N|Dragonblight, The Briny Pinnacle (34.17, 83.79)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:72|h[Hearthstone]|h|r |N|Dragonblight, The Briny Pinnacle (34.68, 84.35)|
T Conversing With the Depths |QID|12032| |N|Dragonblight, Moa'ki Harbor (49.07, 75.73)|
- |QID|12110.2| |QO|Azure Dragonshrine observed: 1/1| |N|Dragonblight, Azure Dragonshrine (52.98, 65.48)|
- |QID|12127.1| |QO|Filled Frost Gem: 1/1| |N|Dragonblight, The Mirror of Dawn (66.88, 54.99)|
- |QID|12102.1| |QO|Ruby Lilac: 1/1| |N|Dragonblight, Ruby Dragonshrine (47.68, 49.15)|
U |cffffffff|Hitem:37833:0:0:0:0:0:0:589531398:72|h[Ruby Brooch]|h|r |N|Dragonblight, Ruby Dragonshrine (47.68, 49.05)|
A The Fate of the Ruby Dragonshrine |QID|12419| |N|Dragonblight, Ruby Dragonshrine (47.68, 49.05)|
- |QID|12126.1| |QO|Filled Unholy Gem: 1/1| |N|Dragonblight, Ruby Dragonshrine (46.66, 49.87)|
T In Service of the Unholy |QID|12126| |N|Dragonblight, Agmar's Hammer (37.07, 46.57)|
T In Service of Frost |QID|12127| |N|Dragonblight, Agmar's Hammer (37.07, 46.57)|
A The Power to Destroy |QID|12132| |N|Dragonblight, Agmar's Hammer (37.07, 46.57)|
- |QID|12132.1| |QO|Shadowy Tormentor slain: 6/6| |N|Dragonblight, Agmar's Hammer (35.99, 47.93)|
T The Power to Destroy |QID|12132| |N|Dragonblight, Agmar's Hammer (37.09, 46.80)|
A The Translated Tome |QID|12136| |N|Dragonblight, Agmar's Hammer (37.09, 46.80)|
T The Translated Tome |QID|12136| |N|Dragonblight, Agmar's Hammer (35.84, 48.27)|
T In Search of the Ruby Lilac |QID|12102| |N|Dragonblight, Agmar's Hammer (36.10, 48.73)|
A Return to Soar |QID|12104| |N|Dragonblight, Agmar's Hammer (36.10, 48.73)|
T The End of the Line |QID|12110| |N|Dragonblight, Agmar's Hammer (37.97, 46.23)|
A Gaining an Audience |QID|12122| |N|Dragonblight, Agmar's Hammer (37.97, 46.23)|
T Return to Soar |QID|12104| |N|Dragonblight, Agmar's Hammer (37.19, 48.55)|
A Where the Wild Things Roam |QID|12111| |N|Dragonblight, Agmar's Hammer (37.19, 48.55)|
- |QID|12111.2| |QO|Arctic Grizzly Inoculated: 5/5| |N|Dragonblight,  (33.68, 49.48)|
- |QID|12111.1| |QO|Snowfall Elk Inoculated: 5/5| |N|Dragonblight,  (36.26, 50.68)|
T Where the Wild Things Roam |QID|12111| |N|Dragonblight, Agmar's Hammer (37.19, 48.65)|
T Gaining an Audience |QID|12122| |N|Dragonblight, Wyrmrest Temple (57.98, 54.25)|
A Speak with your Ambassador |QID|12767| |N|Dragonblight, Wyrmrest Temple (57.98, 54.25)|
T Speak with your Ambassador |QID|12767| |N|Dragonblight, Wyrmrest Temple (58.22, 55.56)|
A Report to the Ruby Dragonshrine |QID|12461| |N|Dragonblight, Wyrmrest Temple (58.22, 55.56)|
T The Fate of the Ruby Dragonshrine |QID|12419| |N|Dragonblight, Wyrmrest Temple (59.73, 54.55)|
A Mystery of the Infinite |QID|12470| |N|Dragonblight, Wyrmrest Temple (59.94, 54.50)|
A The Obsidian Dragonshrine |QID|12447| |N|Dragonblight, Wyrmrest Temple (60.02, 54.32)|
A Seeds of the Lashers |QID|12458| |N|Dragonblight, Wyrmrest Temple (59.61, 54.31)|
U |cff1eff00|Hitem:38152:0:0:0:0:0:0:850005746:72|h[Mace of the Violet Guardian]|h|r |N|Dragonblight, The Dragon Wastes (56.60, 51.42)|
- |QID|12144.1| |QO|Snowplain Snobolds: 10/10| |N|Dragonblight, The Dragon Wastes (55.77, 54.26)|
T Pest Control |QID|12144| |N|Dragonblight, Dragon's Fall (46.75, 33.42)|
A Canyon Chase |QID|12145| |N|Dragonblight, Dragon's Fall (46.75, 33.42)|
A The High Executor Needs You |QID|12488| |N|Dragonblight, Agmar's Hammer (36.62, 46.52)|
A Cho'war the Pillager |QID|9946| |N|,  (55.75, 62.37)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.32, 74.37)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.03, 61.82)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.30, 74.30)|
A The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.60, 58.77)|
U |cffffffff|Hitem:40946:0:0:0:0:0:0:1175713217:73|h[Anuniaq's Net]|h|r |N|Howling Fjord,  (33.09, 71.73)|
- |QID|11472.1| |QO|Reef Bull led to a Reef Cow| |N|Howling Fjord, Twin Shores (31.03, 71.80)|
T The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.69, 58.87)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:-1752556448:73|h[Frostweave Cloth]|h|r |N|Orgrimmar, Valley of Strength (50.83, 70.69)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:-1296208348:73|h[Frostweave Cloth]|h|r |N|Orgrimmar, Valley of Strength (50.83, 70.69)|
A Reading the Meters |QID|11900| |N|Borean Tundra, Transitus Shield (32.99, 34.30)|
A Secrets of the Ancients |QID|11910| |N|Borean Tundra, Transitus Shield (32.99, 34.30)|
A Have They No Shame? |QID|13095| |N|Borean Tundra, Transitus Shield (33.42, 34.37)|
- |QID|11900.2| |QO|Southern Coldarra Reading: 1/1| |N|Borean Tundra, Coldarra (28.33, 34.97)|
- |QID|11900.1| |QO|Nexus Geological Reading: 1/1| |N|Borean Tundra, The Nexus (28.26, 28.55)|
- |QID|11900.3| |QO|Northern Coldarra Reading: 1/1| |N|Borean Tundra, Coldarra (31.62, 20.66)|
- |QID|11900.4| |QO|Western Coldarra Reading: 1/1| |N|Borean Tundra, Coldarra (22.58, 23.51)|
T Reading the Meters |QID|11900| |N|Borean Tundra, Transitus Shield (32.98, 34.37)|
A Postponing the Inevitable |QID|11905| |N|Borean Tundra, Transitus Shield (32.98, 34.37)|
T Have They No Shame? |QID|13095| |N|Borean Tundra, Transitus Shield (33.40, 34.33)|
U |cff0070dd|Hitem:43184:0:0:0:0:0:0:167397910:73|h[Tundra Pauldrons]|h|r |N|Borean Tundra, Transitus Shield (33.40, 34.33)|
T Postponing the Inevitable |QID|11905| |N|Borean Tundra, Transitus Shield (33.01, 34.31)|
U |cff0070dd|Hitem:42765:0:0:0:0:0:0:45167138:73|h[Gauntlets of the Disturbed Giant]|h|r |N|Borean Tundra, Transitus Shield (33.01, 34.31)|
A Nuts for Berries |QID|11912| |N|Borean Tundra, Transitus Shield (33.53, 34.26)|
A Basic Training |QID|11918| |N|Borean Tundra, Transitus Shield (33.33, 34.44)|
- |QID|11910.2| |QO|Magic-Bound Splinter: 3/3| |N|Borean Tundra, Coldarra (33.25, 24.51)|
- |QID|11912.1| |QO|Frostberry: 10/10| |N|Borean Tundra, Coldarra (27.72, 33.82)|
- |QID|11910.1| |QO|Glacial Splinter: 3/3| |N|Borean Tundra, Coldarra (25.06, 35.52)|
- |QID|11918.1| |QO|Coldarra Spellweaver slain: 10/10| |N|Borean Tundra, Coldarra (29.88, 32.75)|
T Secrets of the Ancients |QID|11910| |N|Borean Tundra, Transitus Shield (33.01, 34.31)|
A Quickening |QID|11911| |N|Borean Tundra, Transitus Shield (33.01, 34.31)|
T Basic Training |QID|11918| |N|Borean Tundra, Transitus Shield (33.32, 34.41)|
A Hatching a Plan |QID|11936| |N|Borean Tundra, Transitus Shield (33.32, 34.41)|
T Nuts for Berries |QID|11912| |N|Borean Tundra, Transitus Shield (33.43, 34.38)|
A Keep the Secret Safe |QID|11914| |N|Borean Tundra, Transitus Shield (33.43, 34.38)|
U |cffffffff|Hitem:35648:0:0:0:0:0:0:1503485086:73|h[Scintillating Fragment]|h|r |N|Borean Tundra, Transitus Shield (33.43, 34.38)|
A Puzzling... |QID|11941| |N|Borean Tundra, Transitus Shield (33.43, 34.38)|
T Puzzling... |QID|11941| |N|Borean Tundra, Transitus Shield (33.30, 34.43)|
A The Cell |QID|11943| |N|Borean Tundra, Transitus Shield (33.30, 34.43)|
- |QID|11943.1| |QO|Energy Core: 1/1| |N|Borean Tundra, Coldarra (24.64, 29.88)|
- |QID|11943.2| |QO|Prison Casing: 1/1| |N|Borean Tundra, Coldarra (27.25, 20.42)|
T The Cell |QID|11943| |N|Borean Tundra, Transitus Shield (33.33, 34.46)|
U |cffffffff|Hitem:35671:0:0:0:0:0:0:1556393462:73|h[Augmented Arcane Prison]|h|r |N|Borean Tundra, Transitus Shield (33.24, 33.94)|
A Keristrasza |QID|11946| |N|Borean Tundra, Transitus Shield (33.24, 33.94)|
T Keristrasza |QID|11946| |N|Borean Tundra, Transitus Shield (33.24, 33.94)|
A Bait and Switch |QID|11951| |N|Borean Tundra, Transitus Shield (33.24, 33.94)|
- |QID|11951.1| |QO|Crystallized Mana Shard: 10/10| |N|Borean Tundra, Coldarra (27.11, 21.79)|
T Bait and Switch |QID|11951| |N|Borean Tundra, Coldarra (29.11, 22.48)|
A Saragosa's End |QID|11957| |N|Borean Tundra, Coldarra (29.11, 22.48)|
U |cffffffff|Hitem:35690:0:0:0:0:0:0:828074702:73|h[Arcane Power Focus]|h|r |N|Saragosa's Landing,  (21.14, 22.46)|
- |QID|11957.1| |QO|Saragosa's Corpse: 1/1| |N|Saragosa's Landing,  (22.00, 22.64)|
T Saragosa's End |QID|11957| |N|Saragosa's Landing,  (22.00, 22.64)|
- |QID|11967.1| |QO|Augmented Arcane Prison: 1/1| |N|Saragosa's Landing,  (22.00, 22.64)|
A Mustering the Reds |QID|11967| |N|Saragosa's Landing,  (22.00, 22.64)|
T Mustering the Reds |QID|11967| |N|Borean Tundra, Transitus Shield (33.28, 34.44)|
A Springing the Trap |QID|11969| |N|Borean Tundra, Transitus Shield (33.28, 34.44)|
U |cffffffff|Hitem:44950:0:0:0:0:0:0:1206158123:73|h[Raelorasz' Spark]|h|r |N|Borean Tundra, The Nexus (25.16, 24.26)|
- |QID|11969.1| |QO|Assault on Malygos Complete: 1/1| |N|Borean Tundra, Coldarra (34.41, 25.65)|
T Springing the Trap |QID|11969| |N|Borean Tundra, Transitus Shield (33.24, 34.46)|
A Prisoner of War |QID|11973| |N|Borean Tundra, Transitus Shield (33.24, 34.46)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:73|h[Hearthstone]|h|r |N|Borean Tundra, Transitus Shield (33.34, 34.21)|
U |cffffffff|Hitem:8845:0:0:0:0:0:0:1317392125:73|h[Ghost Mushroom]|h|r |N|Dragonblight, Venomspite (76.98, 62.77)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.32, 74.31)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.11, 61.76)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.30, 74.34)|
A Triage |QID|6622| |N|Arathi Highlands, Hammerfall (73.36, 36.76)|
- |QID|6622.1| |QO|15 Patients Saved!| |N|Arathi Highlands, Hammerfall (73.02, 36.83)|
T Triage |QID|6622| |N|Arathi Highlands, Hammerfall (73.34, 36.91)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:300238957:73|h[Runecloth]|h|r |N|Arathi Highlands, Hammerfall (73.79, 33.18)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:-1925518290:73|h[Runecloth]|h|r |N|Arathi Highlands, Hammerfall (73.79, 33.18)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1472673356:73|h[Mageweave Cloth]|h|r |N|Arathi Highlands, Hammerfall (73.79, 33.18)|
U |cff1eff00|Hitem:36616:0:0:0:0:0:-40:1569652757:73|h[Dutiful Longbow of the Bandit]|h|r |N|Arathi Highlands, Hammerfall (73.92, 33.21)|
U |cffffffff|Hitem:22012:0:0:0:0:0:0:0:73|h[Master First Aid - Doctor in the House]|h|r |N|Hellfire Peninsula, Falcon Watch (26.28, 62.02)|
U |cffffffff|Hitem:21992:0:0:0:0:0:0:0:73|h[Manual: Netherweave Bandage]|h|r |N|Hellfire Peninsula, Falcon Watch (26.87, 60.41)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:73|h[Hearthstone]|h|r |N|Hellfire Peninsula, Falcon Watch (26.87, 60.41)|
U |cffffffff|Hitem:21993:0:0:0:0:0:0:0:73|h[Manual: Heavy Netherweave Bandage]|h|r |N|Dragonblight, Venomspite (76.90, 62.95)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:648602458:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1609227187:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:-1773494352:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:668528832:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:593012077:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:1137589758:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:-2077293506:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:401008528:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:1835789294:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:-2057274318:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:1177018903:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:-1715360796:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:600402096:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:691725746:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:1595372425:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:622648488:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:616137468:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:1273234164:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:-1591955384:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:1967220568:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:1935149336:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:706218486:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:1773059052:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:973912952:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:932066598:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1333468434:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1409394276:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:-1937523401:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1790685892:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:2129953744:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1997739570:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1381146488:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1649704522:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:998257288:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:-1638032172:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1950269270:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:-1802605430:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:-1925156870:73|h[Netherweave Cloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
U |cffffffff|Hitem:14047:0:0:0:0:0:0:-1829498192:73|h[Runecloth]|h|r |N|Dragonblight, Venomspite (76.95, 62.81)|
A Hellscream's Vigil |QID|11585| |N|Borean Tundra, Warsong Hold (41.58, 53.95)|
T Hellscream's Vigil |QID|11585| |N|Borean Tundra, Warsong Hold (41.28, 53.54)|
A The Defense of Warsong Hold |QID|11596| |N|Borean Tundra, Warsong Hold (41.33, 53.63)|
T The Defense of Warsong Hold |QID|11596| |N|Borean Tundra, Warsong Hold (43.26, 55.07)|
A Taking Back Mightstone Quarry |QID|11598| |N|Borean Tundra, Warsong Hold (43.26, 55.07)|
A Patience is a Virtue that We Don't Need |QID|11606| |N|Borean Tundra, Warsong Hold (43.33, 55.47)|
A Taken by the Scourge |QID|11611| |N|Borean Tundra, Warsong Hold (42.27, 56.27)|
A Ride to Taunka'le Village |QID|11888| |N|Borean Tundra, Warsong Hold (41.75, 54.53)|
A Too Close For Comfort |QID|11574| |N|Borean Tundra, Warsong Hold (41.76, 54.66)|
A To Bor'gorok Outpost, Quickly! |QID|12486| |N|Borean Tundra, Warsong Hold (41.31, 53.37)|
- |QID|11598.1| |QO|Nerub'ar slain: 15/15| |N|Borean Tundra, Mightstone Quarry (41.19, 58.58)|
- |QID|11606.1| |QO|Warsong Munitions: 15/15| |N|Borean Tundra, Mightstone Quarry (41.90, 58.15)|
- |QID|11611.1| |QO|Warsong Peon Freed: 5/5| |N|Borean Tundra, Mightstone Quarry (42.33, 57.66)|
T Taken by the Scourge |QID|11611| |N|Borean Tundra, Warsong Hold (42.21, 56.22)|
T Patience is a Virtue that We Don't Need |QID|11606| |N|Borean Tundra, Warsong Hold (43.32, 55.49)|
A Bury Those Cockroaches! |QID|11608| |N|Borean Tundra, Warsong Hold (43.32, 55.49)|
T Taking Back Mightstone Quarry |QID|11598| |N|Borean Tundra, Warsong Hold (43.26, 55.04)|
A Cutting Off the Source |QID|11602| |N|Borean Tundra, Warsong Hold (43.26, 55.04)|
A Untold Truths |QID|11614| |N|Borean Tundra, Warsong Hold (43.26, 55.05)|
U |cffffffff|Hitem:34710:0:0:0:0:0:0:507410169:73|h[Seaforium Depth Charge Bundle]|h|r |N|Borean Tundra, Mightstone Quarry (44.50, 57.46)|
- |QID|11608.2| |QO|East Nerub'ar Sinkhole Destroyed: 1/1| |N|Borean Tundra, Mightstone Quarry (44.19, 57.26)|
- |QID|11608.1| |QO|South Nerub'ar Sinkhole Destroyed: 1/1| |N|Borean Tundra, Mightstone Quarry (42.02, 58.60)|
- |QID|11608.4| |QO|North Nerub'ar Sinkhole Destroyed: 1/1| |N|Borean Tundra, Mightstone Quarry (41.62, 50.57)|
T Untold Truths |QID|11614| |N|Borean Tundra, Mightstone Quarry (40.08, 51.97)|
A Nerub'ar Secrets |QID|11615| |N|Borean Tundra, Mightstone Quarry (40.09, 51.95)|
- |QID|11608.3| |QO|West Nerub'ar Sinkhole Destroyed: 1/1| |N|Borean Tundra, Mightstone Quarry (39.87, 51.94)|
- |QID|11602.1| |QO|Nerub'ar Egg Sac Destroyed: 10/10| |N|Borean Tundra, Mightstone Quarry (39.57, 51.08)|
T Bury Those Cockroaches! |QID|11608| |N|Borean Tundra, Warsong Hold (43.34, 55.50)|
T Cutting Off the Source |QID|11602| |N|Borean Tundra, Warsong Hold (43.28, 55.06)|
A Wind Master To'bor |QID|11634| |N|Borean Tundra, Warsong Hold (43.28, 55.06)|
T Nerub'ar Secrets |QID|11615| |N|Borean Tundra, Warsong Hold (43.21, 55.10)|
A Message to Hellscream |QID|11616| |N|Borean Tundra, Warsong Hold (43.21, 55.10)|
T Quickening |QID|11911| |N|Borean Tundra, Transitus Shield (32.99, 34.32)|
U |cff0070dd|Hitem:42768:0:0:0:0:0:0:2027870926:73|h[Boots of the Unbowed Protector]|h|r |N|Borean Tundra, Transitus Shield (32.99, 34.32)|
T Too Close For Comfort |QID|11574| |N|Borean Tundra, Amber Ledge (45.29, 33.48)|
T Message to Hellscream |QID|11616| |N|Borean Tundra, Warsong Hold (41.41, 53.57)|
A Reinforcements Incoming... |QID|11618| |N|Borean Tundra, Warsong Hold (41.41, 53.57)|
T Wind Master To'bor |QID|11634| |N|Borean Tundra, Warsong Hold (42.22, 54.90)|
A Magic Carpet Ride |QID|11636| |N|Borean Tundra, Warsong Hold (42.22, 54.90)|
T Magic Carpet Ride |QID|11636| |N|Borean Tundra, Coast of Echoes (32.22, 54.16)|
A Tank Ain't Gonna Fix Itself |QID|11642| |N|Borean Tundra, Coast of Echoes (32.22, 54.16)|
A Horn of the Ancient Mariner |QID|11660| |N|Borean Tundra, Coast of Echoes (32.31, 54.32)|
A Into the Mist |QID|11655| |N|Borean Tundra, Coast of Echoes (32.31, 54.32)|
T Tank Ain't Gonna Fix Itself |QID|11642| |N|Borean Tundra, Coast of Echoes (32.16, 54.25)|
A Mobu's Pneumatic Tank Transjigamarig |QID|11643| |N|Borean Tundra, Coast of Echoes (32.12, 54.29)|
A Super Strong Metal Plates! |QID|11644| |N|Borean Tundra, Coast of Echoes (32.12, 54.29)|
- |QID|11643.1| |QO|Pneumatic Tank Transjigamarig: 1/1| |N|Borean Tundra, Garrosh's Landing (32.35, 49.09)|
- |QID|11644.1| |QO|Super Strong Metal Plate: 10/10| |N|Borean Tundra, Garrosh's Landing (31.66, 49.90)|
A Escaping the Mist |QID|11664| |N|Borean Tundra, Garrosh's Landing (31.82, 52.40)|
- |QID|11664.1| |QO|Mootoo Saved| |N|Borean Tundra, Coast of Echoes (31.34, 54.52)|
T Escaping the Mist |QID|11664| |N|Borean Tundra, Coast of Echoes (31.73, 54.43)|
T Mobu's Pneumatic Tank Transjigamarig |QID|11643| |N|Borean Tundra, Coast of Echoes (32.12, 54.33)|
T Super Strong Metal Plates! |QID|11644| |N|Borean Tundra, Coast of Echoes (32.12, 54.33)|
A Tanks a lot... |QID|11651| |N|Borean Tundra, Coast of Echoes (32.12, 54.33)|
T Tanks a lot... |QID|11651| |N|Borean Tundra, Coast of Echoes (32.20, 54.16)|
A The Plains of Nasam |QID|11652| |N|Borean Tundra, Coast of Echoes (32.20, 54.16)|
- |QID|11660.1| |QO|Horn of the Ancient Mariner: 1/1| |N|Borean Tundra, Garrosh's Landing (31.20, 51.22)|
- |QID|11655.1| |QO|Tuskarr Relic: 8/8| |N|Borean Tundra, Garrosh's Landing (29.98, 52.37)|
T Horn of the Ancient Mariner |QID|11660| |N|Borean Tundra, Coast of Echoes (32.30, 54.34)|
A Orabus the Helmsman |QID|11661| |N|Borean Tundra, Coast of Echoes (32.30, 54.34)|
T Into the Mist |QID|11655| |N|Borean Tundra, Coast of Echoes (32.30, 54.34)|
A Burn in Effigy |QID|11656| |N|Borean Tundra, Coast of Echoes (32.30, 54.34)|
- |QID|11652.1| |QO|Scourge Leader identified| |N|Borean Tundra, Plains of Nasam (36.74, 62.88)|
- |QID|11652.3| |QO|Injured Warsong Soldier rescued: 3/3| |N|Borean Tundra, Plains of Nasam (34.46, 62.96)|
- |QID|11652.2| |QO|Scourge Unit obliterated: 100/100| |N|Borean Tundra, Plains of Nasam (34.78, 60.77)|
U |cffffffff|Hitem:34830:0:0:0:0:0:0:426907648:73|h[Tuskarr Torch]|h|r |N|Borean Tundra, Pal'ea (29.81, 61.64)|
- |QID|11656.4| |QO|Bor's Anvil destroyed: 1/1| |N|Borean Tundra, Pal'ea (29.81, 61.64)|
U |cffffffff|Hitem:34844:0:0:0:0:0:0:173142694:73|h[Horn of the Ancient Mariner]|h|r |N|Borean Tundra, Warsong Jetty (26.92, 54.81)|
- |QID|11661.1| |QO|Orabus the Helmsman slain: 1/1| |N|Borean Tundra, Warsong Jetty (26.68, 54.74)|
- |QID|11656.2| |QO|The Kur Drakkar destroyed: 1/1| |N|Borean Tundra, Garrosh's Landing (30.97, 49.03)|
- |QID|11656.1| |QO|The Serpent's Maw destroyed: 1/1| |N|Borean Tundra, Garrosh's Landing (31.53, 48.30)|
- |QID|11656.3| |QO|Bor's Hammer destroyed: 1/1| |N|Borean Tundra, Garrosh's Landing (29.98, 52.44)|
T Orabus the Helmsman |QID|11661| |N|Borean Tundra, Coast of Echoes (32.32, 54.35)|
T Burn in Effigy |QID|11656| |N|Borean Tundra, Coast of Echoes (32.32, 54.35)|
A Seek Out Karuk! |QID|11662| |N|Borean Tundra, Coast of Echoes (32.32, 54.35)|
T Reinforcements Incoming... |QID|11618| |N|Borean Tundra, Warsong Farms Outpost (38.05, 52.56)|
A The Warsong Farms |QID|11686| |N|Borean Tundra, Warsong Farms Outpost (38.05, 52.56)|
A Merciful Freedom |QID|11676| |N|Borean Tundra, Warsong Farms Outpost (37.95, 52.52)|
A Damned Filthy Swine |QID|11688| |N|Borean Tundra, Warsong Farms Outpost (37.87, 52.34)|
- |QID|11686.2| |QO|Scout Torp's Farm: 1/1| |N|Borean Tundra, Torp's Farm (36.86, 52.36)|
- |QID|11686.1| |QO|Scout Warsong Granary: 1/1| |N|Borean Tundra, Warsong Granary (34.92, 54.65)|
- |QID|11686.3| |QO|Scout Warsong Slaughterhouse: 1/1| |N|Borean Tundra, Warsong Slaughterhouse (39.36, 47.92)|
T The Warsong Farms |QID|11686| |N|Borean Tundra, Warsong Farms Outpost (38.11, 52.62)|
A Get to Getry |QID|11703| |N|Borean Tundra, Warsong Farms Outpost (38.11, 52.62)|
- |QID|11688.1| |QO|Unliving Swine slain: 10/10| |N|Borean Tundra,  (35.08, 48.27)|
- |QID|11676.1| |QO|Scourge Prisoner Freed: 5/5| |N|Borean Tundra,  (37.30, 47.55)|
T Damned Filthy Swine |QID|11688| |N|Borean Tundra, Warsong Farms Outpost (37.87, 52.26)|
A Bring 'Em Back Alive |QID|11690| |N|Borean Tundra, Warsong Farms Outpost (37.87, 52.26)|
T Merciful Freedom |QID|11676| |N|Borean Tundra, Warsong Farms Outpost (37.89, 52.54)|
U |cffffffff|Hitem:34954:0:0:0:0:0:0:586125988:73|h[Torp's Kodo Snaffle]|h|r |N|Borean Tundra,  (37.64, 50.45)|
- |QID|11690.1| |QO|Kodo Rescued: 8/8| |N|Borean Tundra,  (37.37, 50.44)|
T Bring 'Em Back Alive |QID|11690| |N|Borean Tundra, Warsong Farms Outpost (37.84, 52.38)|
T Get to Getry |QID|11703| |N|Borean Tundra,  (34.54, 46.46)|
A Foolish Endeavors |QID|11705| |N|Borean Tundra,  (34.54, 46.46)|
- |QID|11705.1| |QO|Varidus the Flenser Defeated| |N|Borean Tundra,  (35.39, 46.49)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:73|h[Hearthstone]|h|r |N|Borean Tundra,  (35.09, 46.06)|
T The Plains of Nasam |QID|11652| |N|Borean Tundra, Warsong Hold (41.41, 53.57)|
T Foolish Endeavors |QID|11705| |N|Borean Tundra, Warsong Hold (41.41, 53.57)|
A Nork Bloodfrenzy's Charge |QID|11709| |N|Borean Tundra, Warsong Hold (41.41, 53.57)|
T Seek Out Karuk! |QID|11662| |N|Borean Tundra,  (47.10, 75.41)|
A Karuk's Oath |QID|11613| |N|Borean Tundra,  (47.10, 75.41)|
- |QID|11613.2| |QO|Skadir Longboatsman slain: 5/5| |N|Borean Tundra, Riplash Strand (47.75, 78.99)|
- |QID|11613.1| |QO|Skadir Raider slain: 6/6| |N|Borean Tundra, Riplash Strand (47.29, 80.45)|
A Cruelty of the Kvaldir |QID|12471| |N|Borean Tundra, Riplash Strand (44.19, 77.78)|
T Karuk's Oath |QID|11613| |N|Borean Tundra,  (47.16, 75.42)|
A Gamel the Cruel |QID|11619| |N|Borean Tundra,  (47.16, 75.42)|
T Cruelty of the Kvaldir |QID|12471| |N|Borean Tundra,  (47.16, 75.42)|
- |QID|11619.1| |QO|Gamel the Cruel slain: 1/1| |N|Borean Tundra, Riplash Strand (46.43, 78.19)|
T Gamel the Cruel |QID|11619| |N|Borean Tundra,  (47.12, 75.40)|
A A Father's Words |QID|11620| |N|Borean Tundra,  (47.12, 75.40)|
T A Father's Words |QID|11620| |N|Borean Tundra, Shrine of Scales (43.65, 80.46)|
A The Trident of Naz'jan |QID|11625| |N|Borean Tundra, Shrine of Scales (43.65, 80.46)|
- |QID|11625.1| |QO|Trident of Naz'jan: 1/1| |N|Borean Tundra, Riplash Ruins (55.03, 88.51)|
T The Trident of Naz'jan |QID|11625| |N|Borean Tundra, Shrine of Scales (43.63, 80.63)|
A The Emissary |QID|11626| |N|Borean Tundra, Shrine of Scales (43.63, 80.63)|
U |cffffffff|Hitem:35850:0:0:0:0:0:0:1385979111:73|h[Trident of Naz'jan]|h|r |N|Borean Tundra, Riplash Ruins (52.29, 88.24)|
- |QID|11626.1| |QO|Leviroth slain: 1/1| |N|Borean Tundra, Riplash Ruins (52.04, 88.33)|
T The Emissary |QID|11626| |N|Borean Tundra,  (47.18, 75.45)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:73|h[Hearthstone]|h|r |N|Borean Tundra,  (47.18, 75.45)|
T Nork Bloodfrenzy's Charge |QID|11709| |N|Borean Tundra, Mightstone Quarry (43.75, 54.53)|
A Coward Delivery... Under 30 Minutes or it's Free |QID|11711| |N|Borean Tundra, Mightstone Quarry (43.75, 54.53)|
U |cffffffff|Hitem:34971:0:0:0:0:0:0:2084800264:73|h[Warsong Flare Gun]|h|r |N|Borean Tundra,  (55.28, 50.87)|
- |QID|11711.1| |QO|Alliance Deserter Delivered| |N|Borean Tundra,  (55.28, 50.87)|
T Coward Delivery... Under 30 Minutes or it's Free |QID|11711| |N|Borean Tundra, Bloodspore Plains (52.42, 51.48)|
A Vermin Extermination |QID|11714| |N|Borean Tundra, Bloodspore Plains (52.42, 51.48)|
A The Wondrous Bloodspore |QID|11716| |N|Borean Tundra, Bloodspore Plains (52.14, 52.46)|
- |QID|11714.3| |QO|Bloodspore Roaster slain: 2/2| |N|Borean Tundra, Gammoth (51.72, 56.24)|
- |QID|11714.2| |QO|Bloodspore Firestarter slain: 5/5| |N|Borean Tundra, Bloodspore Plains (51.17, 61.93)|
- |QID|11716.1| |QO|Bloodspore Carpel: 10/10| |N|Borean Tundra, Bloodspore Plains (51.60, 60.97)|
- |QID|11714.1| |QO|Bloodspore Harvester slain: 8/8| |N|Borean Tundra, Bloodspore Plains (52.30, 59.40)|
T Vermin Extermination |QID|11714| |N|Borean Tundra, Bloodspore Plains (52.62, 51.71)|
T The Wondrous Bloodspore |QID|11716| |N|Borean Tundra, Bloodspore Plains (52.11, 52.40)|
A Pollen from the Source |QID|11717| |N|Borean Tundra, Bloodspore Plains (52.11, 52.40)|
- |QID|11717.1| |QO|Bloodspore Moth Pollen: 5/5| |N|Borean Tundra, Bloodspore Plains (51.75, 53.75)|
T Pollen from the Source |QID|11717| |N|Borean Tundra, Bloodspore Plains (52.14, 52.48)|
A A Suitable Test Subject |QID|11719| |N|Borean Tundra, Bloodspore Plains (52.14, 52.48)|
U |cffffffff|Hitem:34978:0:0:0:0:0:0:1206780985:74|h[Pollinated Bloodspore Flower]|h|r |N|Borean Tundra, Bloodspore Plains (52.14, 52.48)|
- |QID|11719.1| |QO|Bloodspore Flower Used| |N|Borean Tundra, Bloodspore Plains (52.14, 52.48)|
T A Suitable Test Subject |QID|11719| |N|Borean Tundra, Bloodspore Plains (52.11, 52.49)|
A The Invasion of Gammoth |QID|11720| |N|Borean Tundra, Bloodspore Plains (52.11, 52.49)|
T The Invasion of Gammoth |QID|11720| |N|Borean Tundra, Bloodspore Plains (52.18, 52.91)|
A Gammothra the Tormentor |QID|11721| |N|Borean Tundra, Bloodspore Plains (52.18, 52.91)|
- |QID|11721.1| |QO|Head of Gammothra: 1/1| |N|Borean Tundra, Gammoth (45.73, 61.43)|
A Massive Moth Omelet? |QID|11724| |N|Borean Tundra, Gammoth (48.55, 58.91)|
T Massive Moth Omelet? |QID|11724| |N|Borean Tundra, Bloodspore Plains (52.15, 52.47)|
T Gammothra the Tormentor |QID|11721| |N|Borean Tundra, Bloodspore Plains (52.24, 52.73)|
A Trophies of Gammoth |QID|11722| |N|Borean Tundra, Bloodspore Plains (52.24, 52.73)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:74|h[Hearthstone]|h|r |N|Borean Tundra, Bloodspore Plains (52.29, 52.60)|
T Trophies of Gammoth |QID|11722| |N|Borean Tundra, Warsong Hold (41.41, 53.61)|
A Hellscream's Champion |QID|11916| |N|Borean Tundra, Warsong Hold (41.41, 53.61)|
A The Magical Kingdom of Dalaran |QID|12791| |N|Borean Tundra, Warsong Hold (41.51, 53.64)|
A Ears of Our Enemies |QID|11866| |N|Borean Tundra, D.E.H.T.A. Encampment (57.12, 44.33)|
A Help Those That Cannot Help Themselves |QID|11876| |N|Borean Tundra, D.E.H.T.A. Encampment (57.12, 44.33)|
A Ned, Lord of Rhinos... |QID|11884| |N|Borean Tundra, D.E.H.T.A. Encampment (57.12, 44.33)|
A Unfit for Death |QID|11865| |N|Borean Tundra, D.E.H.T.A. Encampment (56.84, 44.07)|
A Happy as a Clam |QID|11869| |N|Borean Tundra, D.E.H.T.A. Encampment (57.27, 44.07)|
U |cffffffff|Hitem:35127:0:0:0:0:0:0:1186694436:74|h[Pile of Fake Furs]|h|r |N|Borean Tundra,  (57.58, 46.27)|
- |QID|11865.1| |QO|Nesingwary Trapper Trapped: 8/8| |N|Borean Tundra,  (56.92, 50.01)|
- |QID|11866.1| |QO|Nesingwary Lackey Ear: 15/15| |N|Borean Tundra,  (56.48, 53.45)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:74|h[Hearthstone]|h|r |N|Dragonblight, Maw of Neltharion (37.26, 31.82)|
U |cffffffff|Hitem:35228:0:0:0:0:0:0:1170051334:74|h[D.E.H.T.A. Trap Smasher]|h|r |N|Borean Tundra,  (54.44, 45.24)|
- |QID|11876.1| |QO|Mammoth Calf Freed: 8/8| |N|Borean Tundra,  (57.92, 36.15)|
A Reclaiming the Quarry |QID|11612| |N|Borean Tundra,  (54.34, 36.11)|
- |QID|11869.1| |QO|Loot Crazed Diver slain: 10/10| |N|Borean Tundra, Lake Kum'uya (53.36, 46.11)|
- |QID|11884.2| |QO|\"Lunchbox\" slain: 1/1| |N|Borean Tundra,  (47.97, 40.32)|
- |QID|11884.1| |QO|Nedar, Lord of Rhinos slain: 1/1| |N|Borean Tundra,  (47.95, 40.36)|
T Unfit for Death |QID|11865| |N|Borean Tundra, D.E.H.T.A. Encampment (56.83, 43.96)|
A The Culler Cometh |QID|11868| |N|Borean Tundra, D.E.H.T.A. Encampment (56.83, 43.96)|
T Ned, Lord of Rhinos... |QID|11884| |N|Borean Tundra, D.E.H.T.A. Encampment (56.83, 43.96)|
U |cff1eff00|Hitem:37520:0:0:0:0:0:0:434381305:74|h[Plainkeeper Blockade]|h|r |N|Borean Tundra, D.E.H.T.A. Encampment (56.83, 43.96)|
T Help Those That Cannot Help Themselves |QID|11876| |N|Borean Tundra, D.E.H.T.A. Encampment (57.01, 44.29)|
A Khu'nok Will Know |QID|11878| |N|Borean Tundra, D.E.H.T.A. Encampment (57.01, 44.29)|
T Ears of Our Enemies |QID|11866| |N|Borean Tundra, D.E.H.T.A. Encampment (57.01, 44.29)|
T Happy as a Clam |QID|11869| |N|Borean Tundra, D.E.H.T.A. Encampment (57.27, 44.18)|
A The Abandoned Reach |QID|11870| |N|Borean Tundra, D.E.H.T.A. Encampment (57.27, 44.18)|
- |QID|11878.1| |QO|Orphaned Mammoth Calf Delivered to Khu'nok| |N|Borean Tundra,  (59.55, 30.71)|
T Khu'nok Will Know |QID|11878| |N|Borean Tundra,  (59.55, 30.68)|
A Kaw the Mammoth Destroyer |QID|11879| |N|Borean Tundra,  (59.55, 30.68)|
- |QID|11879.1| |QO|Kaw's War Halberd: 1/1| |N|Borean Tundra,  (53.72, 22.87)|
T Kaw the Mammoth Destroyer |QID|11879| |N|Borean Tundra, D.E.H.T.A. Encampment (57.00, 44.26)|
- |QID|11868.1| |QO|Karen \"I Don't Caribou\" the Culler slain: 1/1| |N|Borean Tundra,  (57.22, 56.27)|
T The Abandoned Reach |QID|11870| |N|Borean Tundra, The Abandoned Reach (57.75, 55.15)|
A Not On Our Watch |QID|11871| |N|Borean Tundra, The Abandoned Reach (57.75, 55.15)|
- |QID|11871.1| |QO|Shipment of Animal Parts: 12/12| |N|Borean Tundra, The Abandoned Reach (60.09, 61.86)|
T Not On Our Watch |QID|11871| |N|Borean Tundra, The Abandoned Reach (57.78, 55.14)|
A The Nefarious Clam Master... |QID|11872| |N|Borean Tundra, The Abandoned Reach (57.78, 55.14)|
- |QID|11872.1| |QO|Clam Master K slain: 1/1| |N|Borean Tundra,  (61.19, 66.37)|
T The Nefarious Clam Master... |QID|11872| |N|Borean Tundra, D.E.H.T.A. Encampment (57.27, 44.10)|
T The Culler Cometh |QID|11868| |N|Borean Tundra, D.E.H.T.A. Encampment (56.86, 44.04)|
A The Assassination of Harold Lane |QID|11892| |N|Borean Tundra, D.E.H.T.A. Encampment (56.98, 44.27)|
- |QID|11892.1| |QO|Harold Lane slain: 1/1| |N|Borean Tundra,  (49.88, 41.40)|
T The Assassination of Harold Lane |QID|11892| |N|Borean Tundra, D.E.H.T.A. Encampment (57.01, 44.29)|
A Prison Break |QID|11587| |N|Borean Tundra, Amber Ledge (45.32, 33.43)|
A Monitoring the Rift: Cleftcliff Anomaly |QID|11576| |N|Borean Tundra, Amber Ledge (45.02, 33.46)|
- |QID|11587.1| |QO|Arcane Prisoners Rescued: 1/1| |N|Borean Tundra, Beryl Point (41.82, 42.50)|
- |QID|11576.1| |QO|Cleftcliff Anomaly Reading Taken: 1/1| |N|Borean Tundra, The Westrift (34.23, 42.08)|
T Prison Break |QID|11587| |N|Borean Tundra, Amber Ledge (45.27, 33.46)|
A Abduction |QID|11590| |N|Borean Tundra, Amber Ledge (45.27, 33.46)|
T Monitoring the Rift: Cleftcliff Anomaly |QID|11576| |N|Borean Tundra, Amber Ledge (45.05, 33.42)|
A Monitoring the Rift: Sundered Chasm |QID|11582| |N|Borean Tundra, Amber Ledge (45.05, 33.42)|
- |QID|11582.1| |QO|Sundered Chasm Reading Taken: 1/1| |N|Borean Tundra, The Westrift (43.72, 28.53)|
U |cffffffff|Hitem:34691:0:0:0:0:0:0:619557507:74|h[Arcane Binder]|h|r |N|Borean Tundra,  (43.01, 36.33)|
- |QID|11590.1| |QO|Captured Beryl Sorcerer: 1/1| |N|Borean Tundra,  (43.01, 36.33)|
T Monitoring the Rift: Sundered Chasm |QID|11582| |N|Borean Tundra, Amber Ledge (45.06, 33.41)|
A Monitoring the Rift: Winterfin Cavern |QID|12728| |N|Borean Tundra, Amber Ledge (45.06, 33.41)|
T Abduction |QID|11590| |N|Borean Tundra, Amber Ledge (45.21, 33.43)|
A The Borean Inquisition |QID|11646| |N|Borean Tundra, Amber Ledge (45.21, 33.44)|
T The Borean Inquisition |QID|11646| |N|Borean Tundra, Amber Ledge (46.38, 32.83)|
A The Art of Persuasion |QID|11648| |N|Borean Tundra, Amber Ledge (46.38, 32.83)|
- |QID|11648.1| |QO|Prisoner Interrogated: 1/1| |N|Borean Tundra, Amber Ledge (46.38, 32.83)|
T The Art of Persuasion |QID|11648| |N|Borean Tundra, Amber Ledge (46.38, 32.83)|
A Sharing Intelligence |QID|11663| |N|Borean Tundra, Amber Ledge (46.38, 32.83)|
T Sharing Intelligence |QID|11663| |N|Borean Tundra, Amber Ledge (45.31, 33.42)|
A A Race Against Time |QID|11671| |N|Borean Tundra, Amber Ledge (45.33, 33.44)|
- |QID|11671.1| |QO|Salrand's Broken Key: 1/1| |N|Borean Tundra, Beryl Point (41.87, 39.19)|
T A Race Against Time |QID|11671| |N|Borean Tundra, Amber Ledge (45.22, 33.45)|
A Reforging the Key |QID|11679| |N|Borean Tundra, Amber Ledge (45.22, 33.45)|
T Reforging the Key |QID|11679| |N|Borean Tundra, Amber Ledge (45.31, 34.26)|
A Taking Wing |QID|11680| |N|Borean Tundra, Amber Ledge (45.31, 34.26)|
T Taking Wing |QID|11680| |N|Borean Tundra, Amber Ledge (46.37, 37.21)|
A Rescuing Evanor |QID|11681| |N|Borean Tundra, Amber Ledge (46.36, 37.21)|
T Rescuing Evanor |QID|11681| |N|Borean Tundra, Amber Ledge (46.40, 32.47)|
A Dragonspeak |QID|11682| |N|Borean Tundra, Amber Ledge (46.40, 32.47)|
T Dragonspeak |QID|11682| |N|Borean Tundra, Amber Ledge (45.30, 34.23)|
A Traversing the Rift |QID|11733| |N|Borean Tundra, Amber Ledge (45.30, 34.23)|
T Traversing the Rift |QID|11733| |N|Borean Tundra, Transitus Shield (32.99, 34.32)|
- |QID|11914.1| |QO|Nexus Mana Essence: 5/5| |N|Borean Tundra, The Nexus (29.32, 27.01)|
- |QID|11936.1| |QO|Dragon Eggs destroyed: 5/5| |N|Borean Tundra, The Nexus (29.33, 27.99)|
T Hatching a Plan |QID|11936| |N|Borean Tundra, Transitus Shield (33.28, 34.46)|
A Drake Hunt |QID|11919| |N|Borean Tundra, Transitus Shield (33.28, 34.46)|
T Keep the Secret Safe |QID|11914| |N|Borean Tundra, Transitus Shield (33.43, 34.42)|
- |QID|11919.1| |QO|Captured Nexus Drake: 1/1| |N|Borean Tundra, Transitus Shield (33.28, 34.32)|
T Drake Hunt |QID|11919| |N|Borean Tundra, Transitus Shield (33.30, 34.41)|
A Cracking the Code |QID|11931| |N|Borean Tundra, Transitus Shield (33.30, 34.41)|
- |QID|11931.2| |QO|Azure Codex: 1/1| |N|Borean Tundra, Coldarra (32.64, 27.80)|
- |QID|11931.1| |QO|Shimmering Rune: 3/3| |N|Borean Tundra, Coldarra (34.56, 28.42)|
T Cracking the Code |QID|11931| |N|Borean Tundra, Transitus Shield (33.31, 34.44)|
A The Honored Ancestors |QID|11605| |N|Borean Tundra,  (54.83, 35.78)|
- |QID|11605.1| |QO|Elder Kesuk identified: 1/1| |N|Borean Tundra, Coldrock Quarry (50.95, 32.39)|
- |QID|11605.3| |QO|Elder Takret identified: 1/1| |N|Borean Tundra, Coldrock Quarry (52.28, 31.22)|
- |QID|11605.2| |QO|Elder Sagani identified: 1/1| |N|Borean Tundra, Coldrock Quarry (52.87, 34.09)|
- |QID|11612.1| |QO|Beryl Treasure Hunter slain: 12/12| |N|Borean Tundra, Coldrock Quarry (53.73, 33.98)|
T The Honored Ancestors |QID|11605| |N|Borean Tundra,  (54.65, 35.65)|
A The Lost Spirits |QID|11607| |N|Borean Tundra,  (54.65, 35.65)|
T Reclaiming the Quarry |QID|11612| |N|Borean Tundra,  (54.37, 36.16)|
A Hampering Their Escape |QID|11617| |N|Borean Tundra,  (54.37, 36.16)|
U |cffffffff|Hitem:34711:0:0:0:0:0:0:1183579284:74|h[Core of Malice]|h|r |N|Borean Tundra, Coldrock Quarry (53.49, 33.34)|
- |QID|11617.2| |QO|North Platform Destroyed: 1/1| |N|Borean Tundra, Coldrock Quarry (51.16, 32.39)|
U |cffffffff|Hitem:34711:0:0:0:0:0:0:1324563183:74|h[Core of Malice]|h|r |N|Borean Tundra, Coldrock Quarry (51.08, 32.24)|
U |cffffffff|Hitem:34711:0:0:0:0:0:0:2079412738:74|h[Core of Malice]|h|r |N|Borean Tundra, Coldrock Quarry (51.35, 31.64)|
- |QID|11607.2| |QO|Kaskala Shaman spirits freed: 3/3| |N|Borean Tundra, Coldrock Quarry (51.35, 31.64)|
U |cffffffff|Hitem:34711:0:0:0:0:0:0:-1889412201:74|h[Core of Malice]|h|r |N|Borean Tundra, Coldrock Quarry (51.29, 31.14)|
- |QID|11607.1| |QO|Kaskala Craftsman spirits freed: 3/3| |N|Borean Tundra, Coldrock Quarry (51.29, 31.14)|
- |QID|11617.3| |QO|West Platform Destroyed: 1/1| |N|Borean Tundra,  (50.15, 34.38)|
- |QID|11617.1| |QO|East Platform Destroyed: 1/1| |N|Borean Tundra,  (52.21, 35.81)|
T Hampering Their Escape |QID|11617| |N|Borean Tundra,  (54.29, 36.19)|
A A Visit to the Curator |QID|11623| |N|Borean Tundra,  (54.29, 36.19)|
T The Lost Spirits |QID|11607| |N|Borean Tundra,  (54.53, 35.75)|
A Picking Up the Pieces |QID|11609| |N|Borean Tundra,  (54.53, 35.75)|
- |QID|11623.1| |QO|Curator Insivius slain: 1/1| |N|Borean Tundra,  (50.06, 32.75)|
- |QID|11609.1| |QO|Tuskarr Ritual Object: 6/6| |N|Borean Tundra, Coldrock Quarry (51.47, 30.20)|
T A Visit to the Curator |QID|11623| |N|Borean Tundra,  (54.34, 36.20)|
T Picking Up the Pieces |QID|11609| |N|Borean Tundra,  (54.84, 35.76)|
A Leading the Ancestors Home |QID|11610| |N|Borean Tundra,  (54.85, 35.74)|
- |QID|11610.2| |QO|Elder Sagani's ceremony completed: 1/1| |N|Borean Tundra, Coldrock Quarry (52.99, 34.24)|
- |QID|11610.1| |QO|Elder Kesuk's ceremony completed: 1/1| |N|Borean Tundra, Coldrock Quarry (51.34, 32.26)|
- |QID|11610.3| |QO|Elder Takret's ceremony completed: 1/1| |N|Borean Tundra, Coldrock Quarry (52.17, 31.50)|
T Leading the Ancestors Home |QID|11610| |N|Borean Tundra,  (54.63, 35.65)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:74|h[Hearthstone]|h|r |N|Borean Tundra,  (54.93, 35.57)|
T The Magical Kingdom of Dalaran |QID|12791| |N|Dalaran, The Violet Gate (56.51, 46.16)|
A Learning to Leave and Return: the Magical Way |QID|12790| |N|Dalaran, The Violet Gate (56.51, 46.16)|
- |QID|12790.1| |QO|Teleport to Violet Stand Crystal used: 1/1| |N|Dalaran, The Violet Gate (4.74, 61.82)|
- |QID|12790.2| |QO|Teleport to Dalaran Crystal used: 1/1| |N|Dalaran, The Violet Gate (55.92, 46.79)|
T Learning to Leave and Return: the Magical Way |QID|12790| |N|Dalaran, The Violet Gate (56.79, 46.59)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:1519102592:74|h[Frostweave Cloth]|h|r |N|Undercity, Trade Quarter (67.88, 38.69)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:-1620258347:74|h[Frostweave Cloth]|h|r |N|Undercity, Trade Quarter (67.88, 38.69)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.38, 74.45)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (49.12, 63.19)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.29, 74.32)|
T The High Executor Needs You |QID|12488| |N|Dragonblight, Venomspite (76.78, 63.22)|
A To Conquest Hold, But Be Careful! |QID|12487| |N|Dragonblight, Venomspite (76.78, 63.22)|
T Imbeciles Abound! |QID|12189| |N|Dragonblight, Venomspite (77.69, 62.75)|
A The Forsaken Blight and You: How Not to Die |QID|12188| |N|Dragonblight, Venomspite (77.69, 62.75)|
A Blighted Last Rites |QID|12206| |N|Dragonblight, Venomspite (77.03, 62.85)|
U |cffffffff|Hitem:37129:0:0:0:0:0:0:1808302193:74|h[Flask of Blight]|h|r |N|Dragonblight, Venomspite (77.05, 62.95)|
- |QID|12206.1| |QO|Flask of Blight tested: 1/1| |N|Dragonblight, Venomspite (77.05, 62.95)|
T Blighted Last Rites |QID|12206| |N|Dragonblight, Venomspite (77.05, 62.87)|
A Let Them Not Rise! |QID|12211| |N|Dragonblight, Venomspite (77.05, 62.87)|
A Wanted: The Scarlet Onslaught |QID|12205| |N|Dragonblight, Venomspite (77.05, 62.87)|
A Funding the War Effort |QID|12303| |N|Dragonblight, Venomspite (75.98, 63.18)|
A Materiel Plunder |QID|12209| |N|Dragonblight, Venomspite (75.98, 63.18)|
A Beachfront Property |QID|12304| |N|Dragonblight,  (79.34, 65.12)|
- |QID|12303.1| |QO|Forgotten Treasure: 6/6| |N|Dragonblight, The Forgotten Shore (83.45, 69.95)|
- |QID|12304.1| |QO|Forgotten ghosts slain: 20/20| |N|Dragonblight, The Forgotten Shore (86.65, 68.92)|
- |QID|12188.1| |QO|Ectoplasmic Residue: 10/10| |N|Dragonblight, The Forgotten Shore (80.94, 68.07)|
T Beachfront Property |QID|12304| |N|Dragonblight,  (79.41, 65.08)|
T Funding the War Effort |QID|12303| |N|Dragonblight, Venomspite (75.91, 63.15)|
T The Forsaken Blight and You: How Not to Die |QID|12188| |N|Dragonblight, Venomspite (77.65, 62.75)|
A Emerald Dragon Tears |QID|12200| |N|Dragonblight, Venomspite (77.65, 62.75)|
U |cff1eff00|Hitem:37521:0:0:0:0:0:0:1343601733:74|h[Icechill Buckler]|h|r |N|Dragonblight, Venomspite (76.81, 63.07)|
U |cff1eff00|Hitem:37520:0:0:0:0:0:0:434381305:74|h[Plainkeeper Blockade]|h|r |N|Dragonblight, Venomspite (76.81, 63.07)|
- |QID|12200.1| |QO|Emerald Dragon Tear: 8/8| |N|Dragonblight, Emerald Dragonshrine (62.39, 73.46)|
T Emerald Dragon Tears |QID|12200| |N|Dragonblight, Venomspite (77.68, 62.74)|
A Spread the Good Word |QID|12218| |N|Dragonblight, Venomspite (77.68, 62.74)|
- |QID|12209.2| |QO|Scarlet Onslaught Weapon: 8/8| |N|Dragonblight, New Hearthglen (70.46, 74.08)|
- |QID|12211.1| |QO|Scarlet Onslaught corpses picked clean: 15/15| |N|Dragonblight, New Hearthglen (69.57, 72.07)|
- |QID|12205.1| |QO|Members of the Scarlet Onslaught slain: 20/20| |N|Dragonblight, New Hearthglen (69.56, 71.31)|
- |QID|12209.1| |QO|Scarlet Onslaught Armor: 8/8| |N|Dragonblight, New Hearthglen (71.10, 72.94)|
T Let Them Not Rise! |QID|12211| |N|Dragonblight, Venomspite (76.99, 62.78)|
T Wanted: The Scarlet Onslaught |QID|12205| |N|Dragonblight, Venomspite (76.79, 63.19)|
A No Mercy for the Captured |QID|12245| |N|Dragonblight, Venomspite (76.79, 63.06)|
T Materiel Plunder |QID|12209| |N|Dragonblight, Venomspite (75.97, 63.17)|
A Stealing from the Siegesmiths |QID|12230| |N|Dragonblight, Venomspite (76.44, 62.62)|
A Fresh Remounts |QID|12214| |N|Dragonblight, Venomspite (75.98, 61.92)|
- |QID|12218.1| |QO|Hungering Dead slain: 30/30| |N|Dragonblight, The Carrion Fields (85.11, 53.35)|
- |QID|12230.1| |QO|Siegesmith Bomb: 6/6| |N|Dragonblight, The Carrion Fields (84.31, 47.53)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:74|h[Hearthstone]|h|r |N|Dragonblight, The Carrion Fields (84.40, 47.60)|
A The Honored Dead |QID|11593| |N|Borean Tundra, Steeljaw's Caravan (48.41, 19.44)|
A Put Them to Rest |QID|11594| |N|Borean Tundra, Steeljaw's Caravan (48.41, 19.44)|
A We Strike! |QID|11592| |N|Borean Tundra, Steeljaw's Caravan (48.30, 19.71)|
- |QID|11592.1| |QO|Successfully assisted Longrunner Proudhoof's assault.| |N|Borean Tundra, Steeljaw's Caravan (49.56, 26.83)|
- |QID|11593.1| |QO|Fallen Caravan Guards & Workers Torched: 10/10| |N|Borean Tundra, Steeljaw's Caravan (47.20, 21.69)|
- |QID|11594.1| |QO|Taunka spirits laid to rest: 20/20| |N|Borean Tundra, Steeljaw's Caravan (49.38, 23.89)|
T The Honored Dead |QID|11593| |N|Borean Tundra, Steeljaw's Caravan (48.38, 19.68)|
T Put Them to Rest |QID|11594| |N|Borean Tundra, Steeljaw's Caravan (48.38, 19.68)|
T We Strike! |QID|11592| |N|Borean Tundra, Bor'gorok Outpost (49.60, 10.71)|
T To Bor'gorok Outpost, Quickly! |QID|12486| |N|Borean Tundra, Bor'gorok Outpost (50.26, 9.82)|
A The Sky Will Know |QID|11624| |N|Borean Tundra, Bor'gorok Outpost (50.26, 9.82)|
A King Mrgl-Mrgl |QID|11702| |N|Borean Tundra, Bor'gorok Outpost (49.01, 10.30)|
T The Sky Will Know |QID|11624| |N|Borean Tundra, Ruins of Eldra'nath (46.66, 9.40)|
A Boiling Point |QID|11627| |N|Borean Tundra, Ruins of Eldra'nath (46.66, 9.40)|
- |QID|11627.2| |QO|Churn has submitted: 1/1| |N|Borean Tundra, Blistering Pool (45.93, 12.81)|
- |QID|11627.1| |QO|Simmer has submitted: 1/1| |N|Borean Tundra, Charred Rise (50.83, 15.27)|
T Boiling Point |QID|11627| |N|Borean Tundra, Ruins of Eldra'nath (46.63, 9.35)|
A Motes of the Enraged |QID|11649| |N|Borean Tundra, Ruins of Eldra'nath (46.63, 9.35)|
- |QID|11649.1| |QO|Tempest Mote: 5/5| |N|Borean Tundra, Ruins of Eldra'nath (43.65, 8.06)|
T Motes of the Enraged |QID|11649| |N|Borean Tundra, Ruins of Eldra'nath (46.50, 9.25)|
A Return to the Spirit Talker |QID|11629| |N|Borean Tundra, Ruins of Eldra'nath (46.50, 9.25)|
T Return to the Spirit Talker |QID|11629| |N|Borean Tundra, Bor'gorok Outpost (50.25, 9.82)|
A Vision of Air |QID|11631| |N|Borean Tundra, Bor'gorok Outpost (50.25, 9.82)|
T King Mrgl-Mrgl |QID|11702| |N|Borean Tundra, Winterfin Retreat (43.51, 13.88)|
U |cffffffff|Hitem:37097:0:0:0:0:0:0:1172041292:74|h[Scroll of Spirit VII]|h|r |N|Borean Tundra, Winterfin Retreat (43.51, 13.88)|
A Learning to Communicate |QID|11571| |N|Borean Tundra, Winterfin Retreat (43.51, 13.88)|
- |QID|11571.1| |QO|The King's Filled Conch: 1/1| |N|Borean Tundra, The Westrift (42.58, 15.42)|
T Learning to Communicate |QID|11571| |N|Borean Tundra, Winterfin Retreat (43.54, 13.95)|
A Winterfin Commerce |QID|11559| |N|Borean Tundra, Winterfin Retreat (43.54, 13.95)|
- |QID|11559.1| |QO|Winterfin Clam: 5/5| |N|Borean Tundra, The Westrift (42.29, 14.66)|
T Winterfin Commerce |QID|11559| |N|Borean Tundra, Winterfin Retreat (42.99, 13.80)|
A Oh Noes, the Tadpoles! |QID|11560| |N|Borean Tundra, Winterfin Retreat (43.45, 13.95)|
A Them! |QID|11561| |N|Borean Tundra, Winterfin Retreat (42.89, 13.61)|
A Escape from the Winterfin Caverns |QID|11570| |N|Borean Tundra, Winterfin Caverns (37.81, 23.02)|
- |QID|11570.1| |QO|Escort Lurgglbr to safety| |N|Borean Tundra, Winterfin Village (41.33, 16.29)|
- |QID|11561.1| |QO|Winterfin murlocs slain: 15/15| |N|Borean Tundra, Winterfin Village (39.94, 16.61)|
- |QID|11560.1| |QO|Winterfin Tadpole rescued: 20/20| |N|Borean Tundra, Winterfin Village (40.36, 18.65)|
T Them! |QID|11561| |N|Borean Tundra, Winterfin Retreat (42.82, 13.80)|
T Oh Noes, the Tadpoles! |QID|11560| |N|Borean Tundra, Winterfin Retreat (43.45, 13.91)|
A I'm Being Blackmailed By My Cleaner |QID|11562| |N|Borean Tundra, Winterfin Retreat (43.45, 13.91)|
U |cffffffff|Hitem:3825:0:0:0:0:0:0:1000820942:74|h[Elixir of Fortitude]|h|r |N|Borean Tundra, Winterfin Retreat (43.45, 13.91)|
T Escape from the Winterfin Caverns |QID|11570| |N|Borean Tundra, Winterfin Retreat (43.45, 13.91)|
T I'm Being Blackmailed By My Cleaner |QID|11562| |N|Borean Tundra, Winterfin Retreat (42.04, 12.83)|
A Grmmurggll Mrllggrl Glrggl!!! |QID|11563| |N|Borean Tundra, Winterfin Retreat (42.04, 12.83)|
A Succulent Orca Stew |QID|11564| |N|Borean Tundra, Winterfin Retreat (42.05, 13.07)|
U |cff9d9d9d|Hitem:43851:0:0:0:0:0:0:1588082241:74|h[Fur Clothing Scraps]|h|r |N|Borean Tundra, Winterfin Retreat (42.00, 12.95)|
U |cff9d9d9d|Hitem:33561:0:0:0:0:0:0:782540126:74|h[Hardened Flipper]|h|r |N|Borean Tundra, Glimmer Bay (40.21, 10.90)|
- |QID|11563.1| |QO|Glrggl's Head: 1/1| |N|Borean Tundra, Glimmer Bay (39.75, 8.13)|
- |QID|11564.1| |QO|Succulent Orca Blubber: 7/7| |N|Borean Tundra, The Westrift (41.43, 13.87)|
T Succulent Orca Stew |QID|11564| |N|Borean Tundra, Winterfin Retreat (41.97, 13.12)|
T Grmmurggll Mrllggrl Glrggl!!! |QID|11563| |N|Borean Tundra, Winterfin Retreat (42.02, 12.86)|
A The Spare Suit |QID|11565| |N|Borean Tundra, Winterfin Retreat (42.02, 12.86)|
T The Spare Suit |QID|11565| |N|Borean Tundra, Winterfin Retreat (43.46, 13.89)|
A Surrender... Not! |QID|11566| |N|Borean Tundra, Winterfin Retreat (43.46, 13.89)|
U |cffffffff|Hitem:34620:0:0:0:0:0:0:332136288:75|h[King Mrgl-Mrgl's Spare Suit]|h|r |N|Borean Tundra, Winterfin Village (41.54, 15.82)|
U |cffffffff|Hitem:34669:0:0:0:0:0:0:215652706:75|h[Arcanometer]|h|r |N|Borean Tundra, Winterfin Caverns (39.76, 19.65)|
- |QID|12728.1| |QO|Winterfin Cavern Reading Taken: 1/1| |N|Borean Tundra, Winterfin Caverns (39.76, 19.65)|
A Keymaster Urmgrgl |QID|11569| |N|Borean Tundra, Winterfin Caverns (37.83, 23.17)|
- |QID|11569.1| |QO|Urmgrgl's Key: 1/1| |N|Borean Tundra, Winterfin Caverns (39.13, 22.58)|
- |QID|11566.1| |QO|Claw of Claximus: 1/1| |N|Borean Tundra, Winterfin Caverns (37.58, 27.44)|
T Keymaster Urmgrgl |QID|11569| |N|Borean Tundra, Winterfin Caverns (37.80, 23.25)|
T Surrender... Not! |QID|11566| |N|Borean Tundra, Winterfin Retreat (43.47, 13.90)|
U |cffffffff|Hitem:36781:0:0:0:0:0:0:-2070909122:75|h[Darkwater Clam]|h|r |N|Borean Tundra, Winterfin Retreat (43.07, 13.73)|
U |cffffffff|Hitem:37700:0:0:0:0:0:0:2024808075:75|h[Crystallized Air]|h|r |N|Borean Tundra, Winterfin Retreat (43.07, 13.73)|
U |cffffffff|Hitem:34779:0:0:0:0:0:0:1522763044:75|h[Imperean's Primal]|h|r |N|Borean Tundra, Bor'gorok Outpost (50.22, 9.91)|
- |QID|11631.1| |QO|Farseer Grimwalker's fate divined: 1/1| |N|Borean Tundra, Bor'gorok Outpost (50.21, 9.81)|
T Vision of Air |QID|11631| |N|Borean Tundra, Bor'gorok Outpost (50.21, 9.81)|
A Farseer Grimwalker's Spirit |QID|11635| |N|Borean Tundra, Bor'gorok Outpost (50.21, 9.81)|
A Revenge Upon Magmoth |QID|11639| |N|Borean Tundra, Bor'gorok Outpost (50.11, 10.12)|
T Farseer Grimwalker's Spirit |QID|11635| |N|Borean Tundra, Magmoth (56.20, 9.17)|
A Kaganishu |QID|11637| |N|Borean Tundra, Magmoth (56.20, 9.17)|
- |QID|11639.1| |QO|Magmoth Shaman slain: 10/10| |N|Borean Tundra, Magmoth (55.53, 11.03)|
- |QID|11637.2| |QO|Kaganishu's Fetish: 1/1| |N|Borean Tundra, Magmoth (56.20, 12.67)|
- |QID|11639.4| |QO|Mate of Magmothregar slain: 3/3| |N|Borean Tundra, Magmoth (56.29, 11.20)|
U |cffffffff|Hitem:34781:0:0:0:0:0:0:2084610624:75|h[Kaganishu's Fetish]|h|r |N|Borean Tundra, Magmoth (56.21, 9.19)|
- |QID|11637.1| |QO|Farseer Grimwalker set free: 1/1| |N|Borean Tundra, Magmoth (56.21, 9.19)|
T Kaganishu |QID|11637| |N|Borean Tundra, Magmoth (56.21, 9.19)|
A Return My Remains |QID|11638| |N|Borean Tundra, Magmoth (56.21, 9.19)|
- |QID|11638.1| |QO|Farseer Grimwalker's Remains: 1/1| |N|Borean Tundra, Magmoth (56.22, 9.08)|
- |QID|11639.3| |QO|Magmoth Crusher slain: 3/3| |N|Borean Tundra, Magmoth (54.90, 10.40)|
- |QID|11639.2| |QO|Magmoth Forager slain: 5/5| |N|Borean Tundra, Magmoth (54.85, 13.18)|
T Return My Remains |QID|11638| |N|Borean Tundra, Bor'gorok Outpost (50.25, 9.85)|
T Revenge Upon Magmoth |QID|11639| |N|Borean Tundra, Bor'gorok Outpost (49.56, 10.09)|
T Monitoring the Rift: Winterfin Cavern |QID|12728| |N|Borean Tundra, Amber Ledge (45.00, 33.44)|
A Not Without a Fight! |QID|11949| |N|Borean Tundra, Kaskala (63.79, 46.03)|
A Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (63.88, 45.79)|
- |QID|11945.1| |QO|Kaskala Supplies: 8/8| |N|Borean Tundra, Kaskala (65.83, 46.55)|
- |QID|11949.1| |QO|Kvaldir Raider slain: 12/12| |N|Borean Tundra, Kaskala (65.01, 45.69)|
T Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (64.02, 45.75)|
T Not Without a Fight! |QID|11949| |N|Borean Tundra, Kaskala (63.78, 46.04)|
A Muahit's Wisdom |QID|11950| |N|Borean Tundra, Kaskala (63.78, 46.04)|
T Muahit's Wisdom |QID|11950| |N|Borean Tundra, Njord's Breath Bay (67.21, 54.80)|
A Spirits Watch Over Us |QID|11961| |N|Borean Tundra, Njord's Breath Bay (67.21, 54.80)|
- |QID|11961.1| |QO|Issliruk's Totem: 1/1| |N|Borean Tundra, Njord's Breath Bay (67.65, 50.49)|
T Spirits Watch Over Us |QID|11961| |N|Borean Tundra, Njord's Breath Bay (67.19, 54.78)|
A The Tides Turn |QID|11968| |N|Borean Tundra, Njord's Breath Bay (67.19, 54.78)|
- |QID|11968.1| |QO|Heigarr the Horrible slain: 1/1| |N|Borean Tundra, Njord's Breath Bay (67.61, 56.75)|
T The Tides Turn |QID|11968| |N|Borean Tundra, Njord's Breath Bay (67.25, 54.78)|
T Ride to Taunka'le Village |QID|11888| |N|Borean Tundra, Taunka'le Village (77.28, 38.37)|
A What Are They Up To? |QID|11890| |N|Borean Tundra, Taunka'le Village (77.28, 38.37)|
A Scouting the Sinkholes |QID|11684| |N|Borean Tundra, Taunka'le Village (77.13, 37.90)|
A Load 'er Up! |QID|11881| |N|Borean Tundra, Taunka'le Village (77.50, 37.09)|
T Hellscream's Champion |QID|11916| |N|Borean Tundra, Taunka'le Village (75.93, 37.29)|
U |cff0070dd|Hitem:38241:0:0:0:0:0:0:1761898644:75|h[Fury of the Raging Dragon]|h|r |N|Borean Tundra, Taunka'le Village (75.92, 37.35)|
A Sage Highmesa is Missing |QID|11674| |N|Borean Tundra, Taunka'le Village (77.33, 37.04)|
A Emergency Supplies |QID|11887| |N|Borean Tundra, Scalding Pools (64.05, 35.84)|
U |cffffffff|Hitem:35272:0:0:0:0:0:0:2113179258:75|h[Jenny's Whistle]|h|r |N|Borean Tundra, Scalding Pools (63.40, 35.94)|
- |QID|11881.1| |QO|Return Jenny to safety without losing cargo: 1/1| |N|Borean Tundra, Taunka'le Village (77.71, 36.95)|
T Load 'er Up! |QID|11881| |N|Borean Tundra, Taunka'le Village (77.56, 37.00)|
A The Power of the Elements |QID|11893| |N|Borean Tundra, Taunka'le Village (77.56, 37.00)|
- |QID|11893.1| |QO|Energy Collected: 10/10| |N|Borean Tundra, Steam Springs (71.96, 35.80)|
- |QID|11684.1| |QO|Mark Location of South Sinkhole: 1/1| |N|Borean Tundra, The Geyser Fields (70.66, 36.20)|
- |QID|11684.2| |QO|Mark Location of Northeast Sinkhole: 1/1| |N|Borean Tundra, The Geyser Fields (69.95, 33.07)|
- |QID|11684.3| |QO|Mark Location of Northwest Sinkhole: 1/1| |N|Borean Tundra, The Geyser Fields (66.83, 32.77)|
- |QID|11890.1| |QO|Fizzcrank Pumping Station environs inspected.| |N|Borean Tundra, The Geyser Fields (65.77, 24.87)|
- |QID|11887.1| |QO|Gnomish Emergency Toolkit: 7/7| |N|Borean Tundra, Scalding Pools (62.85, 28.71)|
T Emergency Supplies |QID|11887| |N|Borean Tundra, Taunka'le Village (77.50, 37.09)|
T The Power of the Elements |QID|11893| |N|Borean Tundra, Taunka'le Village (77.58, 36.99)|
A Patching Up |QID|11894| |N|Borean Tundra, Taunka'le Village (77.52, 37.05)|
T Scouting the Sinkholes |QID|11684| |N|Borean Tundra, Taunka'le Village (77.14, 37.84)|
A The Heart of the Elements |QID|11685| |N|Borean Tundra, Taunka'le Village (77.14, 37.84)|
T What Are They Up To? |QID|11890| |N|Borean Tundra, Taunka'le Village (77.27, 38.32)|
A Master the Storm |QID|11895| |N|Borean Tundra, Taunka'le Village (77.27, 38.32)|
- |QID|11895.1| |QO|Storm mastered: 1/1| |N|Borean Tundra, Taunka'le Village (77.03, 38.84)|
T Master the Storm |QID|11895| |N|Borean Tundra, Taunka'le Village (77.24, 38.37)|
A Weakness to Lightning |QID|11896| |N|Borean Tundra, Taunka'le Village (77.24, 38.37)|
A Cleaning Up the Pools |QID|11906| |N|Borean Tundra, Taunka'le Village (76.98, 37.64)|
A Souls of the Decursed |QID|11899| |N|Borean Tundra, Taunka'le Village (77.35, 37.05)|
- |QID|11906.1| |QO|Fizzcrank Spare Parts: 15/15| |N|Borean Tundra, The Geyser Fields (62.25, 24.71)|
- |QID|11896.1| |QO|Robots weakened and destroyed: 15/15| |N|Borean Tundra, The Geyser Fields (64.76, 17.77)|
- |QID|11899.1| |QO|Gnome soul captured: 10/10| |N|Borean Tundra, The Geyser Fields (61.77, 22.25)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:75|h[Hearthstone]|h|r |N|Borean Tundra, The Geyser Fields (61.77, 22.25)|
T Cleaning Up the Pools |QID|11906| |N|Borean Tundra, Taunka'le Village (76.99, 37.58)|
T Weakness to Lightning |QID|11896| |N|Borean Tundra, Taunka'le Village (77.24, 38.34)|
A The Sub-Chieftains |QID|11907| |N|Borean Tundra, Taunka'le Village (77.24, 38.34)|
T Souls of the Decursed |QID|11899| |N|Borean Tundra, Taunka'le Village (77.36, 37.05)|
A Defeat the Gearmaster |QID|11909| |N|Borean Tundra, Taunka'le Village (77.26, 36.88)|
- |QID|11907.4| |QO|The Grinder slain: 1/1| |N|Borean Tundra, South Point Station (65.08, 28.86)|
- |QID|11907.3| |QO|Max Blasto slain: 1/1| |N|Borean Tundra, Mid Point Station (63.66, 22.42)|
- |QID|11907.1| |QO|Twonky slain: 1/1| |N|Borean Tundra, West Point Station (60.37, 20.31)|
- |QID|11907.2| |QO|ED-210 slain: 1/1| |N|Borean Tundra, The Geyser Fields (65.47, 17.17)|
- |QID|11909.1| |QO|The Gearmaster's Manual researched: 1/1| |N|Borean Tundra, Fizzcrank Pumping Station (64.48, 23.33)|
- |QID|11909.2| |QO|Mechazod's Head: 1/1| |N|Borean Tundra, Fizzcrank Pumping Station (64.49, 23.35)|
T The Sub-Chieftains |QID|11907| |N|Borean Tundra, Taunka'le Village (77.24, 38.37)|
T Defeat the Gearmaster |QID|11909| |N|Borean Tundra, Taunka'le Village (77.34, 37.04)|
U |cffffffff|Hitem:35288:0:0:0:0:0:0:1913239560:75|h[Uncured Caribou Hide]|h|r |N|Borean Tundra, The Geyser Fields (67.98, 36.16)|
- |QID|11894.1| |QO|Steam Cured Hide: 5/5| |N|Borean Tundra, The Geyser Fields (68.03, 34.10)|
T Seeds of the Lashers |QID|12458| |N|Borean Tundra, The Geyser Fields (68.03, 34.10)|
- |QID|12218.1| |QO|Hungering Dead slain: 30/30| |N|Borean Tundra, The Geyser Fields (68.03, 34.10)|
- |QID|12230.1| |QO|Siegesmith Bomb: 6/6| |N|Borean Tundra, The Geyser Fields (68.03, 34.10)|
A Seeds of the Lashers |QID|12458| |N|Borean Tundra, The Geyser Fields (68.03, 34.10)|
- |QID|11685.1| |QO|Elemental Heart: 5/5| |N|Borean Tundra,  (87.72, 45.67)|
T Patching Up |QID|11894| |N|Borean Tundra, Taunka'le Village (77.49, 37.10)|
A Shrouds of the Scourge |QID|11628| |N|Borean Tundra, Taunka'le Village (75.95, 37.29)|
T The Heart of the Elements |QID|11685| |N|Borean Tundra, Taunka'le Village (75.65, 35.80)|
A The Horn of Elemental Fury |QID|11695| |N|Borean Tundra, Taunka'le Village (75.65, 35.80)|
- |QID|11695.2| |QO|Lower Horn Half: 1/1| |N|Borean Tundra, The Flood Plains (78.79, 28.48)|
- |QID|11695.1| |QO|Upper Horn Half: 1/1| |N|Borean Tundra, The Flood Plains (68.53, 40.32)|
T The Horn of Elemental Fury |QID|11695| |N|Borean Tundra, Taunka'le Village (75.65, 35.77)|
A The Collapse |QID|11706| |N|Borean Tundra, Taunka'le Village (75.65, 35.77)|
U |cffffffff|Hitem:34968:0:0:0:0:0:0:477411700:75|h[The Horn of Elemental Fury]|h|r |N|Borean Tundra, The Geyser Fields (70.69, 36.18)|
- |QID|11706.2| |QO|Nerubian tunnels collapsed: 1/1| |N|Borean Tundra, The Geyser Fields (70.72, 36.13)|
- |QID|11706.1| |QO|Lord Kryxix slain: 1/1| |N|Borean Tundra, The Geyser Fields (71.19, 35.87)|
T The Collapse |QID|11706| |N|Borean Tundra, Taunka'le Village (75.65, 35.78)|
U |cffffffff|Hitem:36781:0:0:0:0:0:0:1426244100:75|h[Darkwater Clam]|h|r |N|Borean Tundra, Taunka'le Village (76.46, 35.70)|
T Sage Highmesa is Missing |QID|11674| |N|Borean Tundra,  (74.57, 23.67)|
A A Proper Death |QID|11675| |N|Borean Tundra,  (74.57, 23.67)|
- |QID|11628.1| |QO|Scourged Mammoth Pelt: 5/5| |N|Borean Tundra, The Dens of Dying (78.98, 22.14)|
- |QID|11675.1| |QO|Plagued Magnataur slain: 10/10| |N|Borean Tundra, The Dens of Dying (75.98, 19.63)|
T A Proper Death |QID|11675| |N|Borean Tundra,  (74.62, 23.50)|
A Stop the Plague |QID|11677| |N|Borean Tundra,  (74.62, 23.50)|
- |QID|11677.1| |QO|Plague Cauldron Neutralized: 1/1| |N|Den of Dying,  (78.29, 18.07)|
T Stop the Plague |QID|11677| |N|Borean Tundra,  (74.69, 23.50)|
A Find Bristlehorn |QID|11678| |N|Borean Tundra,  (74.69, 23.50)|
A Fallen Necropolis |QID|11683| |N|Borean Tundra,  (74.69, 23.50)|
T Find Bristlehorn |QID|11678| |N|Borean Tundra, Talramas (69.76, 12.62)|
A The Doctor and the Lich-Lord |QID|11687| |N|Borean Tundra, Talramas (69.76, 12.62)|
- |QID|11687.1| |QO|Doctor Razorgrin slain: 1/1| |N|Borean Tundra, Talramas (69.71, 13.02)|
- |QID|11687.2| |QO|Lich-Lord Chillwinter slain: 1/1| |N|Borean Tundra, Talramas (69.16, 13.63)|
- |QID|11683.1| |QO|Talramas Scourge Destroyed: 20/20| |N|Borean Tundra,  (66.27, 14.08)|
T Fallen Necropolis |QID|11683| |N|Borean Tundra,  (74.59, 23.62)|
T The Doctor and the Lich-Lord |QID|11687| |N|Borean Tundra,  (74.59, 23.62)|
A Return with the Bad News |QID|11689| |N|Borean Tundra,  (74.59, 23.62)|
T Return with the Bad News |QID|11689| |N|Borean Tundra, Taunka'le Village (77.35, 37.05)|
T Shrouds of the Scourge |QID|11628| |N|Borean Tundra, Taunka'le Village (75.97, 37.28)|
A The Bad Earth |QID|11630| |N|Borean Tundra, Taunka'le Village (75.97, 37.28)|
- |QID|11630.1| |QO|Scourged Earth: 8/8| |N|Borean Tundra, The Flood Plains (80.15, 29.46)|
T The Bad Earth |QID|11630| |N|Borean Tundra, Taunka'le Village (75.95, 37.30)|
A Blending In |QID|11633| |N|Borean Tundra, Taunka'le Village (75.95, 37.30)|
U |cff0070dd|Hitem:37796:0:0:0:0:0:0:-2023919292:75|h[Earthbound Cape]|h|r |N|Borean Tundra, Spire of Blood (86.92, 22.12)|
U |cffffffff|Hitem:34782:0:0:0:0:0:0:508964566:75|h[Imbued Scourge Shroud]|h|r |N|Borean Tundra, Spire of Blood (86.86, 22.05)|
- |QID|11633.2| |QO|Spire of Blood Scouted: 1/1| |N|Borean Tundra, Spire of Blood (88.23, 20.88)|
- |QID|11633.1| |QO|Spire of Decay Scouted: 1/1| |N|Borean Tundra, Spire of Decay (83.98, 20.80)|
- |QID|11633.3| |QO|Spire of Pain Scouted: 1/1| |N|Borean Tundra, Spire of Pain (89.18, 28.71)|
T Blending In |QID|11633| |N|Borean Tundra, Taunka'le Village (75.96, 37.27)|
A Words of Power |QID|11640| |N|Borean Tundra, Taunka'le Village (75.96, 37.27)|
A Neutralizing the Cauldrons |QID|11647| |N|Borean Tundra, Taunka'le Village (75.96, 37.27)|
A A Courageous Strike |QID|11641| |N|Borean Tundra, Taunka'le Village (75.96, 37.27)|
- |QID|11641.2| |QO|En'kilah Necromancer slain: 5/5| |N|Borean Tundra, Temple City of En'kilah (84.04, 24.87)|
- |QID|11640.1| |QO|High Priest Naferset's Scroll: 1/1| |N|Borean Tundra, Spire of Decay (83.74, 20.51)|
U |cffffffff|Hitem:34815:0:0:0:0:0:0:-2087476607:75|h[Vial of Fresh Blood]|h|r |N|Borean Tundra, Spire of Blood (88.06, 22.17)|
A The Spire of Blood |QID|11654| |N|Borean Tundra, Spire of Blood (88.06, 22.17)|
- |QID|11640.3| |QO|High Priest Andorath's Scroll: 1/1| |N|Borean Tundra, Spire of Blood (88.11, 20.97)|
T The Spire of Blood |QID|11654| |N|Borean Tundra, Spire of Blood (87.57, 20.06)|
A Shatter the Orbs! |QID|11659| |N|Borean Tundra, Spire of Blood (87.57, 20.06)|
- |QID|11659.1| |QO|Blood Globes Shattered: 5/5| |N|Borean Tundra, Spire of Blood (88.37, 20.11)|
- |QID|11647.2| |QO|Central Cauldron Cleansed: 1/1| |N|Borean Tundra, Temple City of En'kilah (86.07, 22.86)|
- |QID|11647.3| |QO|West Cauldron Cleansed: 1/1| |N|Borean Tundra, Temple City of En'kilah (85.52, 20.29)|
- |QID|11640.2| |QO|High Priest Talet-Kha's Scroll: 1/1| |N|Borean Tundra, Spire of Pain (89.36, 28.77)|
- |QID|11647.1| |QO|East Cauldron Cleansed: 1/1| |N|Borean Tundra, Temple City of En'kilah (87.68, 29.72)|
- |QID|11641.1| |QO|En'kilah Ghoul slain: 15/15| |N|Borean Tundra, Spire of Blood (86.56, 22.13)|
T Neutralizing the Cauldrons |QID|11647| |N|Borean Tundra, Taunka'le Village (75.97, 37.25)|
T A Courageous Strike |QID|11641| |N|Borean Tundra, Taunka'le Village (75.97, 37.25)|
T Words of Power |QID|11640| |N|Borean Tundra, Taunka'le Village (75.97, 37.25)|
A Breaking Through |QID|11898| |N|Borean Tundra, Taunka'le Village (75.97, 37.25)|
- |QID|11898.2| |QO|Luthion the Vile slain: 1/1| |N|Borean Tundra, Naxxanar (87.94, 29.08)|
- |QID|11898.3| |QO|Vanthryn the Merciless slain: 1/1| |N|Borean Tundra, Naxxanar (85.64, 27.54)|
U |cffffffff|Hitem:43465:0:0:0:0:0:0:-1782801230:75|h[Scroll of Strength VII]|h|r |N|Borean Tundra, Naxxanar (86.59, 28.28)|
U |cffffffff|Hitem:28102:0:0:0:0:0:0:716646330:75|h[Onslaught Elixir]|h|r |N|Borean Tundra, Naxxanar (86.59, 28.28)|
- |QID|11898.1| |QO|Prince Valanar slain: 1/1| |N|Borean Tundra, Naxxanar (86.24, 28.70)|
T Shatter the Orbs! |QID|11659| |N|Borean Tundra, Taunka'le Village (76.84, 37.95)|
T Breaking Through |QID|11898| |N|Borean Tundra, Taunka'le Village (75.96, 37.29)|
A The Fall of Taunka'le Village |QID|11929| |N|Borean Tundra, Taunka'le Village (75.96, 37.29)|
T The Fall of Taunka'le Village |QID|11929| |N|Borean Tundra, Taunka'le Village (78.26, 37.86)|
A Across Transborea |QID|11930| |N|Borean Tundra, Taunka'le Village (78.26, 37.86)|
- |QID|11930.1| |QO|Secure Passage to Dragonblight| |N|Dragonblight, Coldwind Pass (10.64, 53.69)|
T Across Transborea |QID|11930| |N|Dragonblight, Coldwind Pass (12.81, 51.62)|
T Stealing from the Siegesmiths |QID|12230| |N|Dragonblight, Venomspite (76.83, 62.41)|
A Bombard the Ballistae |QID|12232| |N|Dragonblight, Venomspite (76.83, 62.41)|
T Spread the Good Word |QID|12218| |N|Dragonblight, Venomspite (77.68, 62.75)|
A The Forsaken Blight |QID|12221| |N|Dragonblight, Venomspite (77.68, 62.75)|
A A Means to an End |QID|12240| |N|Dragonblight, Venomspite (77.05, 62.83)|
A Need to Know |QID|12234| |N|Dragonblight, Venomspite (76.79, 63.05)|
U |cffffffff|Hitem:37233:0:0:0:0:0:0:619995656:75|h[The Forsaken Blight]|h|r |N|Dragonblight, New Hearthglen (68.18, 74.29)|
U |cffffffff|Hitem:37300:0:0:0:0:0:0:1924591153:75|h[Levine Family Termites]|h|r |N|Dragonblight, New Hearthglen (68.35, 74.58)|
- |QID|12240.1| |QO|Foreman Kaleiki slain: 1/1| |N|Dragonblight, New Hearthglen (68.33, 74.40)|
U |cffffffff|Hitem:37202:0:0:0:0:0:0:-2137692647:75|h[Onslaught Riding Crop]|h|r |N|Dragonblight, New Hearthglen (69.33, 73.37)|
U |cffffffff|Hitem:37202:0:0:0:0:0:0:1198388631:75|h[Onslaught Riding Crop]|h|r |N|Dragonblight, New Hearthglen (74.39, 65.17)|
- |QID|12234.2| |QO|Scarlet Onslaught Daily Orders: Barracks: 1/1| |N|Dragonblight, New Hearthglen (69.83, 71.87)|
- |QID|12234.1| |QO|Scarlet Onslaught Daily Orders: Abbey: 1/1| |N|Dragonblight, Library Wing (73.43, 72.69)|
- |QID|12234.3| |QO|Scarlet Onslaught Daily Orders: Beach: 1/1| |N|Dragonblight, Crusader's Landing (71.52, 80.39)|
- |QID|12245.2| |QO|Senior Scrivener Barriga slain: 1/1| |N|Dragonblight, New Hearthglen (69.41, 73.98)|
- |QID|12245.1| |QO|Deathguard Schneider slain: 1/1| |N|Dragonblight, New Hearthglen (71.34, 72.19)|
- |QID|12245.4| |QO|Chancellor Amai slain: 1/1| |N|Dragonblight, New Hearthglen (72.56, 72.55)|
- |QID|12245.3| |QO|Engineer Burke slain: 1/1| |N|Dragonblight, New Hearthglen (72.75, 74.42)|
U |cffffffff|Hitem:37202:0:0:0:0:0:0:1765777413:75|h[Onslaught Riding Crop]|h|r |N|Dragonblight, New Hearthglen (74.20, 67.36)|
- |QID|12214.1| |QO|Scarlet Onslaught Warhorse reins handed over: 3/3| |N|Dragonblight, Venomspite (75.98, 61.92)|
T Fresh Remounts |QID|12214| |N|Dragonblight, Venomspite (75.97, 61.92)|
T A Means to an End |QID|12240| |N|Dragonblight, Venomspite (77.03, 62.89)|
A Fire Upon the Waters |QID|12243| |N|Dragonblight, Venomspite (77.03, 62.89)|
T No Mercy for the Captured |QID|12245| |N|Dragonblight, Venomspite (76.77, 63.22)|
A Torture the Torturer |QID|12252| |N|Dragonblight, Venomspite (76.77, 63.22)|
T Need to Know |QID|12234| |N|Dragonblight, Venomspite (76.77, 63.05)|
A The Spy in New Hearthglen |QID|12239| |N|Dragonblight, Venomspite (76.77, 63.05)|
- |QID|12252.1| |QO|Torturer LeCraft fully questioned: 1/1| |N|Dragonblight, New Hearthglen (69.75, 71.94)|
- |QID|12252.2| |QO|Torturer LeCraft slain: 1/1| |N|Dragonblight, New Hearthglen (69.75, 71.94)|
U |cffffffff|Hitem:37432:0:0:0:0:0:0:726908577:75|h[Torturer's Rod]|h|r |N|Dragonblight, New Hearthglen (69.59, 71.71)|
A The Rod of Compulsion |QID|12271| |N|Dragonblight, New Hearthglen (69.59, 71.71)|
T The Spy in New Hearthglen |QID|12239| |N|Dragonblight, New Hearthglen (73.62, 73.47)|
A Without a Prayer |QID|12254| |N|Dragonblight, New Hearthglen (73.62, 73.47)|
- |QID|12243.1| |QO|Sails of the Sinner's Folly set afire: 1/1| |N|Dragonblight, Sinner's Folly (71.45, 82.61)|
- |QID|12243.2| |QO|Captain Shely's Rutters: 1/1| |N|Dragonblight, Sinner's Folly (71.86, 83.86)|
- |QID|12254.1| |QO|Bishop Street's Prayer Book: 1/1| |N|Dragonblight, New Hearthglen (69.21, 76.68)|
T Without a Prayer |QID|12254| |N|Dragonblight, New Hearthglen (73.60, 73.44)|
A The Perfect Dissemblance |QID|12260| |N|Dragonblight, New Hearthglen (73.60, 73.44)|
- |QID|12260.1| |QO|Onslaught Raven Priest's image stolen: 1/1| |N|Dragonblight, New Hearthglen (72.91, 74.32)|
T The Perfect Dissemblance |QID|12260| |N|Dragonblight, New Hearthglen (73.62, 73.61)|
A A Fall From Grace |QID|12274| |N|Dragonblight, New Hearthglen (73.62, 73.61)|
U |cffffffff|Hitem:37432:0:0:0:0:0:0:726908577:76|h[Torturer's Rod]|h|r |N|Dragonblight, New Hearthglen (73.79, 74.12)|
- |QID|12274.1| |QO|Abbey bell rung: 1/1| |N|Dragonblight, New Hearthglen (72.86, 73.49)|
- |QID|12274.2| |QO|High Abbot spoken with: 1/1| |N|Dragonblight, New Hearthglen (74.02, 75.69)|
T A Fall From Grace |QID|12274| |N|Dragonblight, New Hearthglen (73.62, 73.61)|
A The Truth Will Out |QID|12283| |N|Dragonblight, New Hearthglen (73.62, 73.61)|
- |QID|12283.1| |QO|The Diary of High General Abbendis: 1/1| |N|Dragonblight, New Hearthglen (68.24, 76.92)|
T Fire Upon the Waters |QID|12243| |N|Dragonblight, Venomspite (77.01, 62.83)|
T Torture the Torturer |QID|12252| |N|Dragonblight, Venomspite (76.79, 63.18)|
T The Truth Will Out |QID|12283| |N|Dragonblight, Venomspite (76.79, 63.18)|
A Do Unto Others |QID|12285| |N|Dragonblight, Venomspite (76.79, 63.18)|
T The Rod of Compulsion |QID|12271| |N|Dragonblight, Venomspite (76.79, 63.18)|
A The Denouncement |QID|12273| |N|Dragonblight, Venomspite (76.79, 63.18)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.29, 74.28)|
U |cff0070dd|Hitem:44057:0:0:0:0:0:0:0:76|h[Ivory-Reinforced Chestguard]|h|r |N|Dragonblight, Moa'ki Harbor (48.54, 75.65)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (45.03, 61.53)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.29, 74.35)|
U |cffffffff|Hitem:43013:0:0:0:0:0:0:550270360:76|h[Chilled Meat]|h|r |N|Orgrimmar, Valley of Strength (49.97, 68.93)|
U |cffffffff|Hitem:37700:0:0:0:0:0:0:2024808075:76|h[Crystallized Air]|h|r |N|Orgrimmar, Valley of Strength (49.97, 68.93)|
U |cffffffff|Hitem:37705:0:0:0:0:0:0:1509982825:76|h[Crystallized Water]|h|r |N|Orgrimmar, Valley of Strength (49.97, 68.93)|
U |cffffffff|Hitem:37704:0:0:0:0:0:0:1716816200:76|h[Crystallized Life]|h|r |N|Orgrimmar, Valley of Strength (49.97, 68.93)|
U |cffffffff|Hitem:37702:0:0:0:0:0:0:-1989263082:76|h[Crystallized Fire]|h|r |N|Orgrimmar, Valley of Strength (49.97, 68.93)|
U |cff1eff00|Hitem:36783:0:0:0:0:0:0:1291225040:76|h[Northsea Pearl]|h|r |N|Orgrimmar, Valley of Strength (49.97, 68.93)|
U |cffffffff|Hitem:43011:0:0:0:0:0:0:1825707036:76|h[Worg Haunch]|h|r |N|Orgrimmar, Valley of Strength (49.92, 68.57)|
U |cffffffff|Hitem:22832:0:0:0:0:0:0:927628156:76|h[Super Mana Potion]|h|r |N|Orgrimmar, Valley of Strength (49.92, 68.57)|
U |cffffffff|Hitem:37091:0:0:0:0:0:0:1304689308:76|h[Scroll of Intellect VII]|h|r |N|Orgrimmar, Valley of Strength (49.92, 68.57)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:1693424115:76|h[Frostweave Cloth]|h|r |N|Orgrimmar, Valley of Strength (50.65, 70.66)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:-1962263155:76|h[Frostweave Cloth]|h|r |N|Orgrimmar, Valley of Strength (50.65, 70.66)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:76|h[Hearthstone]|h|r |N|Orgrimmar, Valley of Honor (75.87, 33.41)|
- |QID|12273.1| |QO|Commander Jordan's denouncement & death: 1/1| |N|Dragonblight, New Hearthglen (69.73, 71.80)|
- |QID|12273.3| |QO|Blacksmith Goodman's denouncement & death: 1/1| |N|Dragonblight, New Hearthglen (70.69, 70.50)|
- |QID|12273.2| |QO|Lead Cannoneer Zierhut's denouncement & death: 1/1| |N|Dragonblight, New Hearthglen (73.46, 77.61)|
- |QID|12273.4| |QO|Stable Master Mercer's denouncement & death: 1/1| |N|Dragonblight, New Hearthglen (67.83, 75.04)|
U |cffffffff|Hitem:22832:0:0:0:0:0:0:2032585988:76|h[Super Mana Potion]|h|r |N|Dragonblight, New Hearthglen (68.54, 75.63)|
U |cffffffff|Hitem:33462:0:0:0:0:0:0:1320447570:76|h[Scroll of Strength VI]|h|r |N|Dragonblight, New Hearthglen (70.97, 77.07)|
U |cffffffff|Hitem:33444:0:0:0:0:0:0:608125401:76|h[Pungent Seal Whey]|h|r |N|Dragonblight, New Hearthglen (71.04, 77.16)|
- |QID|12285.1| |QO|The Head of the High General: 1/1| |N|Dragonblight, New Hearthglen (71.13, 77.75)|
T The Denouncement |QID|12273| |N|Dragonblight, Venomspite (76.79, 63.22)|
T Do Unto Others |QID|12285| |N|Dragonblight, Venomspite (76.79, 63.22)|
- |QID|12458.1| |QO|Lasher Seed: 3/3| |N|Dragonblight, Emerald Dragonshrine (63.06, 75.09)|
T Seeds of the Lashers |QID|12458| |N|Dragonblight, Wyrmrest Temple (59.61, 54.34)|
A That Which Creates Can Also Destroy |QID|12459| |N|Dragonblight, Wyrmrest Temple (59.61, 54.34)|
A Message from the West |QID|12033| |N|Dragonblight, Agmar's Hammer (37.29, 46.75)|
U |cffffffff|Hitem:35941:0:0:0:0:0:0:161986158:76|h[Letter from Saurfang]|h|r |N|Dragonblight, Agmar's Hammer (37.29, 46.75)|
- |QID|12033.1| |QO|Letter from Saurfang read and destroyed| |N|Dragonblight, Agmar's Hammer (37.29, 46.75)|
T Message from the West |QID|12033| |N|Dragonblight, Agmar's Hammer (37.29, 46.75)|
T Report to the Ruby Dragonshrine |QID|12461| |N|Dragonblight,  (43.02, 50.84)|
A Heated Battle |QID|12448| |N|Dragonblight,  (43.02, 50.84)|
- |QID|12448.2| |QO|Frigid Geist Attacker slain: 8/8| |N|Dragonblight,  (42.79, 51.88)|
- |QID|12448.1| |QO|Frigid Ghoul Attacker slain: 12/12| |N|Dragonblight,  (42.79, 51.88)|
- |QID|12448.3| |QO|Frigid Abomination Attacker slain: 1/1| |N|Dragonblight,  (42.79, 51.88)|
T Heated Battle |QID|12448| |N|Dragonblight,  (42.93, 50.85)|
A Return to the Earth |QID|12449| |N|Dragonblight,  (42.93, 50.85)|
U |cffffffff|Hitem:37727:0:0:0:0:0:0:1601223231:76|h[Ruby Acorn]|h|r |N|Dragonblight, Ruby Dragonshrine (47.36, 46.88)|
- |QID|12449.1| |QO|Ruby Keeper Returned to the Earth: 6/6| |N|Dragonblight, Ruby Dragonshrine (45.88, 46.78)|
T Return to the Earth |QID|12449| |N|Dragonblight,  (42.96, 50.82)|
A Through Fields of Flame |QID|12450| |N|Dragonblight,  (42.96, 50.82)|
- |QID|12450.2| |QO|Ruby Corruption Cleansed: 1/1| |N|Dragonblight, Ruby Dragonshrine (47.67, 49.05)|
- |QID|12450.1| |QO|Frigid Necromancer slain: 6/6| |N|Dragonblight, Ruby Dragonshrine (47.77, 47.48)|
T Through Fields of Flame |QID|12450| |N|Dragonblight,  (42.89, 50.87)|
A The Steward of Wyrmrest Temple |QID|12769| |N|Dragonblight,  (42.89, 50.87)|
- |QID|12145.1| |QO|Icefist slain: 1/1| |N|Dragonblight,  (42.62, 40.90)|
T Canyon Chase |QID|12145| |N|Dragonblight, Dragon's Fall (46.76, 33.44)|
A Return to Sender |QID|12469| |N|Dragonblight, The Dragon Wastes (48.40, 24.18)|
T Return to Sender |QID|12469| |N|Dragonblight, Nozzlerust Post (54.94, 23.36)|
A Stocking Up |QID|12044| |N|Dragonblight, Nozzlerust Post (54.94, 23.36)|
A Shaved Ice |QID|12045| |N|Dragonblight, Nozzlerust Post (54.45, 23.46)|
A Nozzlerust Defense |QID|12043| |N|Dragonblight, Nozzlerust Post (54.49, 23.49)|
- |QID|12459.1| |QO|Weakened Reanimated Frost Wyrm slain: 1/1| |N|Dragonblight, The Dragon Wastes (49.50, 24.16)|
- |QID|12045.1| |QO|Ice Shard Cluster: 4/4| |N|Dragonblight, Coldwind Heights (51.18, 19.64)|
T Shaved Ice |QID|12045| |N|Dragonblight, Nozzlerust Post (54.69, 23.32)|
A Soft Packaging |QID|12046| |N|Dragonblight, Nozzlerust Post (54.69, 23.32)|
- |QID|12046.1| |QO|Thin Animal Hide: 12/12| |N|Dragonblight, The Dragon Wastes (49.01, 24.82)|
- |QID|12043.1| |QO|Wastes Taskmaster slain: 1/1| |N|Dragonblight, The Dragon Wastes (58.27, 30.42)|
- |QID|12044.1| |QO|Composite Ore: 8/8| |N|Dragonblight, The Dragon Wastes (59.20, 31.01)|
- |QID|12043.2| |QO|Wastes Digger slain: 12/12| |N|Dragonblight, The Dragon Wastes (58.93, 31.20)|
T Stocking Up |QID|12044| |N|Dragonblight, Nozzlerust Post (54.97, 23.43)|
T Nozzlerust Defense |QID|12043| |N|Dragonblight, Nozzlerust Post (54.42, 23.64)|
T Soft Packaging |QID|12046| |N|Dragonblight, Nozzlerust Post (54.70, 23.33)|
A Something That Doesn't Melt |QID|12047| |N|Dragonblight, Nozzlerust Post (54.70, 23.33)|
A Hard to Swallow |QID|12049| |N|Dragonblight, Nozzlerust Post (54.96, 23.34)|
- |QID|12049.1| |QO|Seared Jormungar Meat: 6/6| |N|Dragonblight, The Dragon Wastes (58.65, 23.59)|
- |QID|12047.1| |QO|Splintered Bone Chunk: 12/12| |N|Dragonblight, The Dragon Wastes (53.36, 25.23)|
T Something That Doesn't Melt |QID|12047| |N|Dragonblight, Nozzlerust Post (54.74, 23.34)|
T Hard to Swallow |QID|12049| |N|Dragonblight, Nozzlerust Post (54.99, 23.37)|
A Lumber Hack |QID|12050| |N|Dragonblight, Nozzlerust Post (54.99, 23.37)|
A Harp on This! |QID|12052| |N|Dragonblight, Nozzlerust Post (54.52, 23.58)|
- |QID|12050.1| |QO|Coldwind Lumber: 50/50| |N|Dragonblight, Coldwind Heights (52.78, 20.07)|
- |QID|12052.1| |QO|Mistress of the Coldwind slain: 1/1| |N|Dragonblight, Coldwind Heights (45.20, 9.83)|
- |QID|12052.2| |QO|Coldwind Harpies: 15/15| |N|Dragonblight, Coldwind Heights (49.85, 16.17)|
T Lumber Hack |QID|12050| |N|Dragonblight, Nozzlerust Post (54.97, 23.45)|
T Harp on This! |QID|12052| |N|Dragonblight, Nozzlerust Post (54.50, 23.51)|
A Stiff Negotiations |QID|12112| |N|Dragonblight, Nozzlerust Post (54.50, 23.51)|
T Stiff Negotiations |QID|12112| |N|Dragonblight, The Crystal Vice (59.45, 18.09)|
A Slim Pickings |QID|12075| |N|Dragonblight, The Crystal Vice (59.45, 18.09)|
- |QID|12075.1| |QO|Sample of Rockflesh: 1/1| |N|Dragonblight, Ice Heart Cavern (56.20, 12.06)|
T Slim Pickings |QID|12075| |N|Dragonblight, The Crystal Vice (59.44, 18.08)|
A Messy Business |QID|12076| |N|Dragonblight, The Crystal Vice (59.44, 18.08)|
A Stomping Grounds |QID|12079| |N|Dragonblight, The Crystal Vice (59.05, 17.84)|
- |QID|12076.1| |QO|Vial of Corrosive Spit: 2/2| |N|Dragonblight, Ice Heart Cavern (54.80, 11.37)|
- |QID|12079.1| |QO|Ice Heart Jormungar Feeder slain: 8/8| |N|Dragonblight, Ice Heart Cavern (52.58, 16.85)|
T Messy Business |QID|12076| |N|Dragonblight, The Crystal Vice (59.36, 18.11)|
A Apply This Twice A Day |QID|12077| |N|Dragonblight, The Crystal Vice (59.36, 18.11)|
T Stomping Grounds |QID|12079| |N|Dragonblight, The Crystal Vice (59.10, 17.81)|
T Apply This Twice A Day |QID|12077| |N|Dragonblight, The Crystal Vice (59.10, 17.81)|
A Really Big Worm |QID|12080| |N|Dragonblight, The Crystal Vice (59.10, 17.81)|
A Worm Wrangler |QID|12078| |N|Dragonblight, The Crystal Vice (59.41, 18.08)|
U |cff9d9d9d|Hitem:37674:0:0:0:0:0:0:1346425457:76|h[An Unopened Tome of Advice]|h|r |N|Dragonblight, Ice Heart Cavern (55.31, 10.56)|
- |QID|12078.1| |QO|Captured Jormungar Spawn: 3/3| |N|Dragonblight, Ice Heart Cavern (53.87, 11.13)|
T Worm Wrangler |QID|12078| |N|Dragonblight, The Crystal Vice (59.44, 18.07)|
T The Forsaken Blight |QID|12221| |N|Dragonblight, Agmar's Hammer (36.05, 48.78)|
U |cff1eff00|Hitem:38177:0:0:0:0:0:0:343783824:76|h[Siege Captain's Gun]|h|r |N|Dragonblight, Agmar's Hammer (36.05, 48.78)|
T The Obsidian Dragonshrine |QID|12447| |N|Dragonblight, Maw of Neltharion (35.18, 30.09)|
A No One to Save You |QID|12262| |N|Dragonblight, Maw of Neltharion (35.18, 30.09)|
A No Place to Run |QID|12261| |N|Dragonblight, Maw of Neltharion (35.18, 30.09)|
U |cffffffff|Hitem:28501:0:0:0:0:0:0:190607232:76|h[Ravager Egg Omelet]|h|r |N|Dragonblight,  (41.77, 31.16)|
U |cffffffff|Hitem:33462:0:0:0:0:0:0:1320447570:76|h[Scroll of Strength VI]|h|r |N|Dragonblight,  (41.77, 31.16)|
- |QID|12261.1| |QO|Destructive Ward Fully Charged: 1/1| |N|Dragonblight,  (41.86, 31.34)|
- |QID|12262.2| |QO|Smoldering Skeleton slain: 10/10| |N|Dragonblight, Obsidian Dragonshrine (40.82, 31.16)|
- |QID|12262.1| |QO|Burning Depths Necrolyte slain: 6/6| |N|Dragonblight, Obsidian Dragonshrine (40.19, 31.47)|
T No One to Save You |QID|12262| |N|Dragonblight, Maw of Neltharion (35.21, 30.14)|
T No Place to Run |QID|12261| |N|Dragonblight, Maw of Neltharion (35.21, 30.14)|
A The Best of Intentions |QID|12263| |N|Dragonblight, Maw of Neltharion (35.21, 30.14)|
- |QID|12263.1| |QO|Uncover the Magmawyrm Resurrection Chamber| |N|Dragonblight, Maw of Neltharion (31.74, 30.48)|
T The Best of Intentions |QID|12263| |N|Dragonblight, Maw of Neltharion (35.20, 30.07)|
A Culling the Damned |QID|12264| |N|Dragonblight, Maw of Neltharion (35.20, 30.07)|
A Defiling the Defilers |QID|12265| |N|Dragonblight, Maw of Neltharion (35.20, 30.07)|
- |QID|12264.1| |QO|Burning Depths Necromancer slain: 3/3| |N|Dragonblight, Maw of Neltharion (33.19, 28.72)|
- |QID|12265.1| |QO|Necromantic Rune destroyed: 8/8| |N|Dragonblight, Maw of Neltharion (32.89, 28.47)|
- |QID|12264.3| |QO|Smoldering Geist slain: 6/6| |N|Dragonblight, Maw of Neltharion (34.70, 27.10)|
- |QID|12264.2| |QO|Smoldering Construct slain: 6/6| |N|Dragonblight, Maw of Neltharion (33.95, 26.84)|
T Culling the Damned |QID|12264| |N|Dragonblight, Maw of Neltharion (35.19, 30.11)|
T Defiling the Defilers |QID|12265| |N|Dragonblight, Maw of Neltharion (35.19, 30.11)|
A Neltharion's Flame |QID|12267| |N|Dragonblight, Maw of Neltharion (35.19, 30.11)|
- |QID|12267.1| |QO|Summoning Area Cleansed: 1/1| |N|Dragonblight, Maw of Neltharion (31.81, 30.57)|
- |QID|12267.2| |QO|Rothin the Decaying slain: 1/1| |N|Dragonblight, Maw of Neltharion (31.43, 30.99)|
T Neltharion's Flame |QID|12267| |N|Dragonblight, Maw of Neltharion (35.19, 30.10)|
A Tales of Destruction |QID|12266| |N|Dragonblight, Maw of Neltharion (35.19, 30.10)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:76|h[Hearthstone]|h|r |N|Dragonblight, Maw of Neltharion (35.19, 30.10)|
T The Steward of Wyrmrest Temple |QID|12769| |N|Dragonblight, Wyrmrest Temple (57.94, 54.29)|
A Informing the Queen |QID|12124| |N|Dragonblight, Wyrmrest Temple (57.94, 54.29)|
T Tales of Destruction |QID|12266| |N|Dragonblight, Wyrmrest Temple (60.04, 54.20)|
T Informing the Queen |QID|12124| |N|Dragonblight, Wyrmrest Temple (59.88, 54.60)|
A Report to Lord Afrasastrasz |QID|12435| |N|Dragonblight, Wyrmrest Temple (59.88, 54.60)|
U |cffffffff|Hitem:34960:0:0:0:0:0:0:646854912:76|h[The Legend of the Horn]|h|r |N|Dragonblight, Bronze Dragonshrine (71.49, 41.34)|
U |cffffffff|Hitem:37923:0:0:0:0:0:0:2131445725:76|h[Hourglass of Eternity]|h|r |N|Dragonblight, Bronze Dragonshrine (71.49, 41.34)|
- |QID|12470.1| |QO|Hourglass of Eternity protected| |N|Dragonblight, Bronze Dragonshrine (71.40, 41.31)|
A The Cleansing Of Jintha'kalar |QID|12545| |N|Dragonblight, Light's Trust (84.02, 26.18)|
- |QID|12545.1| |QO|Jintha'kalar Scourge Slain: 15/15| |N|Dragonblight, Jintha'kalar (87.36, 20.11)|
T The Cleansing Of Jintha'kalar |QID|12545| |N|Dragonblight, Light's Trust (84.04, 25.99)|
A Into the Breach! |QID|12789| |N|Dragonblight, Light's Trust (84.04, 25.99)|
U |cffffffff|Hitem:37887:0:0:0:0:0:0:697744849:76|h[Seeds of Nature's Wrath]|h|r |N|Dragonblight, Jintha'kalar (89.25, 19.53)|
- |QID|12459.3| |QO|Weakened Overseer Deathgaze slain: 1/1| |N|Dragonblight, Jintha'kalar (89.51, 19.03)|
- |QID|12459.2| |QO|Weakened Turgid the Vile slain: 1/1| |N|Dragonblight, The Carrion Fields (86.12, 47.08)|
U |cffffffff|Hitem:22832:0:0:0:0:0:0:785469876:76|h[Super Mana Potion]|h|r |N|Dragonblight, The Carrion Fields (85.53, 47.60)|
U |cffffffff|Hitem:37259:0:0:0:0:0:0:833449763:76|h[Siegesmith Bombs]|h|r |N|Dragonblight, The Carrion Fields (84.79, 52.36)|
- |QID|12232.1| |QO|New Hearthglen Ballista bombarded: 5/5| |N|Dragonblight, New Hearthglen (68.54, 75.85)|
T Bombard the Ballistae |QID|12232| |N|Dragonblight, Venomspite (77.53, 62.00)|
U |cff1eff00|Hitem:38198:0:0:0:0:0:0:1812689862:76|h[Joint-Severing Quickblade]|h|r |N|Dragonblight, Venomspite (75.97, 63.16)|
T Mystery of the Infinite |QID|12470| |N|Dragonblight, Wyrmrest Temple (59.94, 54.52)|
T That Which Creates Can Also Destroy |QID|12459| |N|Dragonblight, Wyrmrest Temple (59.62, 54.48)|
A The Kor'kron Vanguard! |QID|12224| |N|Dragonblight, Agmar's Hammer (38.11, 46.34)|
T The Kor'kron Vanguard! |QID|12224| |N|Dragonblight, Kor'kron Vanguard (40.73, 17.98)|
A Audience With The Dragon Queen |QID|12496| |N|Dragonblight, Kor'kron Vanguard (40.73, 17.98)|
T Audience With The Dragon Queen |QID|12496| |N|Dragonblight, Wyrmrest Temple (59.86, 54.59)|
A Galakrond and the Scourge |QID|12497| |N|Dragonblight, Wyrmrest Temple (59.86, 54.59)|
T Galakrond and the Scourge |QID|12497| |N|Dragonblight, Wyrmrest Temple (59.63, 53.55)|
A On Ruby Wings |QID|12498| |N|Dragonblight, Wyrmrest Temple (59.63, 53.55)|
- |QID|12498.2| |QO|Scythe of Antiok: 1/1| |N|Dragonblight, The Wicked Coil (54.80, 31.27)|
- |QID|12498.1| |QO|Wastes Scavenger slain: 30/30| |N|Dragonblight, Galakrond's Rest (54.84, 34.59)|
T On Ruby Wings |QID|12498| |N|Dragonblight, Wyrmrest Temple (59.85, 54.53)|
A Return To Angrathar |QID|12500| |N|Dragonblight, Wyrmrest Temple (59.85, 54.53)|
T Report to Lord Afrasastrasz |QID|12435| |N|Dragonblight, Wyrmrest Temple (59.20, 54.33)|
A Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.20, 54.33)|
- |QID|12372.2| |QO|Azure Drake slain: 5/5| |N|Dragonblight, Wyrmrest Temple (58.42, 57.06)|
- |QID|12372.1| |QO|Azure Dragon slain: 3/3| |N|Dragonblight, Wyrmrest Temple (57.81, 56.56)|
- |QID|12372.3| |QO|Destabilize the Azure Dragonshrine: 1/1| |N|Dragonblight, Azure Dragonshrine (55.43, 66.10)|
T Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.22, 54.34)|
T Return To Angrathar |QID|12500| |N|Dragonblight, Kor'kron Vanguard (40.77, 18.04)|
A Darkness Stirs |QID|13242| |N|Dragonblight, Angrathar the Wrath Gate (38.39, 19.27)|
- |QID|13242.1| |QO|Saurfang's Battle Armor: 1/1| |N|Dragonblight, Angrathar the Wrath Gate (38.09, 18.70)|
T Darkness Stirs |QID|13242| |N|Borean Tundra, Warsong Hold (41.40, 53.73)|
A Herald of War |QID|13257| |N|Borean Tundra, Warsong Hold (41.40, 53.73)|
T Herald of War |QID|13257| |N|Orgrimmar, Grommash Hold (31.98, 37.61)|
A A Life Without Regret |QID|13266| |N|Orgrimmar, Grommash Hold (32.05, 37.83)|
T A Life Without Regret |QID|13266| |N|Tirisfal Glades, Ruins of Lordaeron (61.74, 62.71)|
A The Battle For The Undercity |QID|13267| |N|Tirisfal Glades, Ruins of Lordaeron (61.74, 62.71)|
T The Battle For The Undercity |QID|13267| |N|Undercity, Royal Quarter (53.94, 89.42)|
T To Conquest Hold, But Be Careful! |QID|12487| |N|Grizzly Hills, Conquest Hold (20.74, 64.28)|
A The Conqueror's Task |QID|12468| |N|Grizzly Hills, Conquest Hold (20.74, 64.28)|
T The Conqueror's Task |QID|12468| |N|Grizzly Hills, Conquest Hold (20.95, 64.12)|
A A Show of Strength |QID|12257| |N|Grizzly Hills, Conquest Hold (20.95, 64.12)|
A The Flamebinders' Secrets |QID|12256| |N|Grizzly Hills, Conquest Hold (20.95, 64.12)|
A Gray Worg Hides |QID|12175| |N|Grizzly Hills, Conquest Hold (21.97, 65.11)|
A Supplemental Income |QID|12436| |N|Grizzly Hills, Conquest Hold (22.62, 66.10)|
A Supplemental Income |QID|12436| |N|,  (64.34, 61.86)|
T Prisoner of War |QID|11973| |N|Borean Tundra, Transitus Shield (33.30, 34.44)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:951870108:76|h[Frostweave Cloth]|h|r |N|Dragonblight, Agmar's Hammer (37.24, 46.65)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:-2098218260:76|h[Frostweave Cloth]|h|r |N|Dragonblight, Agmar's Hammer (37.24, 46.65)|
A The Faceless Ones |QID|13187| |N|Dragonblight, The Pit of Narjun (26.13, 50.66)|
T Death to the Traitor King |QID|13167| |N|Dragonblight, The Pit of Narjun (26.16, 50.66)|
T Don't Forget the Eggs! |QID|13182| |N|Dragonblight, The Pit of Narjun (26.16, 50.66)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:77|h[Hearthstone]|h|r |N|Dragonblight, The Pit of Narjun (26.27, 50.19)|
U |cff0070dd|Hitem:44362:0:0:0:0:0:0:26970177:77|h[Expelling Gauntlets]|h|r |N|Grizzly Hills, Conquest Hold (20.84, 64.55)|
- |QID|12256.1| |QO|Flame-Imbued Talisman: 3/3| |N|Grizzly Hills, Voldrune (28.63, 74.46)|
- |QID|12257.1| |QO|Dragonflayer Huscarl slain: 12/12| |N|Grizzly Hills, Voldrune (30.60, 74.77)|
- |QID|12436.1| |QO|Succulent Venison: 5/5| |N|Grizzly Hills,  (32.52, 64.58)|
A Blackriver Brawl |QID|12170| |N|Grizzly Hills,  (26.51, 65.76)|
- |QID|12175.1| |QO|Gray Worg Hide: 3/3| |N|Grizzly Hills,  (25.39, 70.80)|
T Supplemental Income |QID|12436| |N|Grizzly Hills, Conquest Hold (22.61, 66.11)|
T Gray Worg Hides |QID|12175| |N|Grizzly Hills, Conquest Hold (21.99, 65.10)|
A A Minor Substitution |QID|12176| |N|Grizzly Hills, Conquest Hold (21.99, 65.10)|
T A Show of Strength |QID|12257| |N|Grizzly Hills, Conquest Hold (20.95, 64.11)|
T The Flamebinders' Secrets |QID|12256| |N|Grizzly Hills, Conquest Hold (20.95, 64.11)|
A The Thane of Voldrune |QID|12259| |N|Grizzly Hills, Conquest Hold (20.95, 64.11)|
- |QID|12259.1| |QO|Thane Torvald Eriksson slain: 1/1| |N|Grizzly Hills, Voldrune (27.25, 73.10)|
- |QID|12176.1| |QO|Grizzly Hide: 6/6| |N|Grizzly Hills,  (29.06, 51.08)|
T A Minor Substitution |QID|12176| |N|Grizzly Hills, Conquest Hold (21.97, 65.18)|
A Jun'ik's Coverup |QID|12177| |N|Grizzly Hills, Conquest Hold (21.97, 65.18)|
T The Thane of Voldrune |QID|12259| |N|Grizzly Hills, Conquest Hold (20.97, 64.11)|
A Onward to Camp Oneqwah |QID|12451| |N|Grizzly Hills, Conquest Hold (20.97, 64.11)|
A My Enemy's Friend |QID|12412| |N|Grizzly Hills, Conquest Hold (20.76, 64.15)|
- |QID|12177.1| |QO|Coal: 1/1| |N|Grizzly Hills, Conquest Hold (23.40, 63.13)|
- |QID|12177.2| |QO|Simple Flour: 5/5| |N|Grizzly Hills, Conquest Hold (22.64, 66.06)|
T Jun'ik's Coverup |QID|12177| |N|Grizzly Hills, Conquest Hold (21.99, 65.05)|
A Delivery to Krenna |QID|12178| |N|Grizzly Hills, Conquest Hold (21.99, 65.05)|
T Delivery to Krenna |QID|12178| |N|Grizzly Hills, Conquest Hold (20.78, 64.24)|
- |QID|12170.1| |QO|Alliance in Blackriver slain: 10/10| |N|Grizzly Hills, Blackriver Logging Camp (28.38, 62.77)|
T Blackriver Brawl |QID|12170| |N|Grizzly Hills,  (26.45, 65.67)|
U |cffffffff|Hitem:37830:0:0:0:0:0:0:969520666:77|h[Mikhail's Journal]|h|r |N|Grizzly Hills, Forest's Edge Post (35.49, 67.50)|
A Mikhail's Journal |QID|12423| |N|Grizzly Hills, Forest's Edge Post (35.49, 67.50)|
- |QID|12412.2| |QO|Vladek slain: 1/1| |N|Grizzly Hills, Forest's Edge Post (36.19, 67.78)|
- |QID|12412.1| |QO|Silverbrook Hunter slain: 8/8| |N|Grizzly Hills,  (35.52, 69.66)|
T Mikhail's Journal |QID|12423| |N|Grizzly Hills, Conquest Hold (20.76, 64.20)|
A Gorgonna |QID|12424| |N|Grizzly Hills, Conquest Hold (20.76, 64.20)|
T My Enemy's Friend |QID|12412| |N|Grizzly Hills, Conquest Hold (20.76, 64.20)|
A Attack on Silverbrook |QID|12413| |N|Grizzly Hills, Conquest Hold (20.76, 64.20)|
T Gorgonna |QID|12424| |N|Grizzly Hills, Conquest Hold (20.89, 64.09)|
A Tactical Clemency |QID|12422| |N|Grizzly Hills, Conquest Hold (20.89, 64.09)|
U |cff1eff00|Hitem:39087:0:0:0:0:0:0:569106046:77|h[Cobalt Belt]|h|r |N|Grizzly Hills, Conquest Hold (21.98, 65.08)|
A Good Troll Hunting |QID|12208| |N|Grizzly Hills, Conquest Hold (22.23, 64.76)|
A Eyes Above |QID|12453| |N|Grizzly Hills, Conquest Hold (22.50, 62.98)|
T Good Troll Hunting |QID|12208| |N|Grizzly Hills, Granite Springs (16.22, 47.74)|
A Filling the Cages |QID|11984| |N|Grizzly Hills, Granite Springs (16.22, 47.74)|
- |QID|11984.1| |QO|Captured Live Ice Troll: 1/1| |N|Grizzly Hills, Ruins of Drak'Zin (14.35, 60.52)|
T Filling the Cages |QID|11984| |N|Grizzly Hills, Granite Springs (16.13, 47.67)|
A Truce? |QID|11989| |N|Grizzly Hills, Granite Springs (16.35, 47.83)|
U |cffffffff|Hitem:38083:0:0:0:0:0:0:-2112073698:77|h[Dull Carving Knife]|h|r |N|Grizzly Hills, Granite Springs (16.51, 47.86)|
- |QID|11989.1| |QO|Blood Pact With Drakuru: 1/1| |N|Grizzly Hills, Granite Springs (16.43, 47.86)|
T Truce? |QID|11989| |N|Grizzly Hills, Granite Springs (16.43, 47.86)|
A Vial of Visions |QID|11990| |N|Grizzly Hills, Granite Springs (16.43, 47.86)|
- |QID|11990.1| |QO|Imbued Vial: 1/1| |N|Grizzly Hills, Granite Springs (15.98, 47.83)|
- |QID|11990.2| |QO|Haze Leaf: 3/3| |N|Grizzly Hills, Zeb'Halak (13.26, 41.22)|
- |QID|11990.3| |QO|Waterweed Frond: 1/1| |N|Grizzly Hills, Zeb'Halak (14.85, 39.67)|
T Vial of Visions |QID|11990| |N|Grizzly Hills, Granite Springs (16.41, 47.83)|
A Subject to Interpretation |QID|11991| |N|Grizzly Hills, Granite Springs (16.41, 47.83)|
A Scourgekabob |QID|12484| |N|Grizzly Hills, Granite Springs (15.79, 46.76)|
U |cffffffff|Hitem:38149:0:0:0:0:0:0:1476222066:77|h[Scourged Troll Mummy]|h|r |N|Grizzly Hills, Granite Springs (16.79, 48.26)|
- |QID|12484.1| |QO|Mummified Carcass Burned: 1/1| |N|Grizzly Hills, Granite Springs (16.79, 48.26)|
T Scourgekabob |QID|12484| |N|Grizzly Hills, Granite Springs (16.74, 48.27)|
A Seared Scourge |QID|12029| |N|Grizzly Hills, Granite Springs (16.74, 48.27)|
A Shimmercap Stew |QID|12483| |N|Grizzly Hills, Granite Springs (15.74, 46.81)|
U |cffffffff|Hitem:35797:0:0:0:0:0:0:658664649:77|h[Drakuru's Elixir]|h|r |N|Grizzly Hills, Ruins of Drak'Zin (13.32, 60.88)|
T Subject to Interpretation |QID|11991| |N|Grizzly Hills, Ruins of Drak'Zin (13.32, 60.88)|
A Sacrifices Must be Made |QID|12007| |N|Grizzly Hills, Ruins of Drak'Zin (13.32, 60.88)|
- |QID|12483.1| |QO|Ice Serpent Eye: 5/5| |N|Grizzly Hills,  (11.06, 61.10)|
- |QID|12483.2| |QO|Shimmering Snowcap: 5/5| |N|Grizzly Hills,  (11.10, 59.56)|
- |QID|12007.1| |QO|Eye of the Prophets: 1/1| |N|Grizzly Hills, Zeb'Halak (17.91, 36.47)|
U |cffffffff|Hitem:35797:0:0:0:0:0:0:658664649:77|h[Drakuru's Elixir]|h|r |N|Grizzly Hills, Zeb'Halak (17.34, 36.33)|
T Sacrifices Must be Made |QID|12007| |N|Grizzly Hills, Zeb'Halak (17.35, 36.33)|
A Heart of the Ancients |QID|12042| |N|Grizzly Hills, Zeb'Halak (17.35, 36.33)|
U |cffffffff|Hitem:35908:0:0:0:0:0:0:1502031782:77|h[Mack's Dark Grog]|h|r |N|Grizzly Hills,  (16.12, 29.87)|
- |QID|12029.1| |QO|Scourge Trolls Burned: 20/20| |N|Grizzly Hills,  (16.50, 29.38)|
T Seared Scourge |QID|12029| |N|Grizzly Hills, Granite Springs (16.62, 48.19)|
A Search and Rescue |QID|12037| |N|Grizzly Hills, Granite Springs (16.62, 48.19)|
- |QID|12483.3| |QO|Sweetroot: 5/5| |N|Grizzly Hills, Zeb'Halak (18.63, 39.30)|
T Shimmercap Stew |QID|12483| |N|Grizzly Hills, Granite Springs (15.81, 46.61)|
A Say Hello to My Little Friend |QID|12190| |N|Grizzly Hills, Granite Springs (15.81, 46.61)|
T Search and Rescue |QID|12037| |N|Grizzly Hills, Granite Springs (15.81, 46.61)|
A Search and Rescue |QID|12037| |N|Grizzly Hills, Granite Springs (15.81, 46.61)|
T Tactical Clemency |QID|12422| |N|Grizzly Hills, Bonesnap's Camp (21.92, 29.99)|
- |QID|12413.1| |QO|Silverbrook Defender slain: 8/8| |N|Grizzly Hills, Silverbrook Hills (24.96, 37.02)|
A Overwhelmed! |QID|12288| |N|Grizzly Hills, Blue Sky Logging Grounds (33.89, 32.84)|
A Keep 'Em on Their Heels |QID|12284| |N|Grizzly Hills, Blue Sky Logging Grounds (34.38, 32.97)|
A Making Repairs |QID|12280| |N|Grizzly Hills, Blue Sky Logging Grounds (34.38, 32.70)|
A Shred the Alliance |QID|12270| |N|Grizzly Hills, Blue Sky Logging Grounds (34.50, 32.60)|
T Heart of the Ancients |QID|12042| |N|Grizzly Hills, Blue Sky Logging Grounds (36.99, 32.40)|
A My Heart is in Your Hands |QID|12802| |N|Grizzly Hills, Blue Sky Logging Grounds (36.99, 32.40)|
- |QID|12284.1| |QO|Alliance units eliminated: 15/15| |N|Grizzly Hills, Blue Sky Logging Grounds (40.87, 36.40)|
- |QID|12280.3| |QO|High Tension Spring: 2/2| |N|Grizzly Hills, Blue Sky Logging Grounds (34.83, 39.05)|
- |QID|12280.1| |QO|Grooved Cog: 4/4| |N|Grizzly Hills, Blue Sky Logging Grounds (33.22, 39.77)|
- |QID|12280.2| |QO|Notched Sprocket: 3/3| |N|Grizzly Hills, Blue Sky Logging Grounds (33.46, 41.60)|
T Making Repairs |QID|12280| |N|Grizzly Hills, Blue Sky Logging Grounds (34.35, 32.67)|
T Keep 'Em on Their Heels |QID|12284| |N|Grizzly Hills, Blue Sky Logging Grounds (34.45, 32.89)|
- |QID|12288.1| |QO|Wounded Skirmishers Healed: 10/10| |N|Grizzly Hills, Blue Sky Logging Grounds (33.04, 40.74)|
- |QID|12270.1| |QO|Shredder delivered: 3/3| |N|Grizzly Hills, Blue Sky Logging Grounds (34.47, 32.61)|
T Shred the Alliance |QID|12270| |N|Grizzly Hills, Blue Sky Logging Grounds (34.47, 32.61)|
T Overwhelmed! |QID|12288| |N|Grizzly Hills, Blue Sky Logging Grounds (33.93, 32.70)|
U |cffffffff|Hitem:37877:0:0:0:0:0:0:856989848:77|h[Silver Feather]|h|r |N|Grizzly Hills, Blue Sky Logging Grounds (42.62, 34.97)|
- |QID|12453.1| |QO|Imperial Eagle's sight bound: 6/6| |N|Grizzly Hills,  (44.08, 36.01)|
U |cffffffff|Hitem:35797:0:0:0:0:0:0:658664649:77|h[Drakuru's Elixir]|h|r |N|Grizzly Hills, Drak'atal Passage (44.86, 28.46)|
T My Heart is in Your Hands |QID|12802| |N|Grizzly Hills, Drak'atal Passage (44.93, 28.43)|
A Voices From the Dust |QID|12068| |N|Grizzly Hills, Drak'atal Passage (44.93, 28.43)|
T Onward to Camp Oneqwah |QID|12451| |N|Grizzly Hills, Camp Oneqwah (65.10, 47.71)|
A An Expedient Ally |QID|12074| |N|Grizzly Hills, Camp Oneqwah (65.23, 47.72)|
A The Unexpected 'Guest' |QID|12195| |N|Grizzly Hills, Camp Oneqwah (65.19, 47.51)|
A The Horse Hollerer |QID|12415| |N|Grizzly Hills, Camp Oneqwah (64.98, 47.78)|
- |QID|12195.1| |QO|Mature Stag Horn: 5/5| |N|Grizzly Hills,  (69.35, 50.43)|
T The Unexpected 'Guest' |QID|12195| |N|Grizzly Hills, Camp Oneqwah (65.24, 47.42)|
A An Intriguing Plan |QID|12165| |N|Grizzly Hills, Camp Oneqwah (65.16, 47.28)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:806973254:77|h[Frostweave Cloth]|h|r |N|Grizzly Hills, Camp Oneqwah (65.46, 47.36)|
U |cffffffff|Hitem:43013:0:0:0:0:0:0:1857369066:77|h[Chilled Meat]|h|r |N|Grizzly Hills, Camp Oneqwah (65.46, 47.36)|
A A Bear of an Appetite |QID|12279| |N|Grizzly Hills, Redwood Trading Post (69.05, 40.09)|
T Say Hello to My Little Friend |QID|12190| |N|Grizzly Hills, Harkor's Camp (73.71, 34.07)|
A Nice to Meat You |QID|12113| |N|Grizzly Hills, Harkor's Camp (73.71, 34.07)|
A Therapy |QID|12114| |N|Grizzly Hills, Harkor's Camp (73.71, 34.07)|
A It Takes Guts.... |QID|12116| |N|Grizzly Hills, Harkor's Camp (73.91, 34.04)|
- |QID|12116.1| |QO|Drakkari Canopic Jar: 5/5| |N|Grizzly Hills, Drakil'jin Ruins (69.94, 20.46)|
- |QID|12068.1| |QO|Drakkari Tablets: 1/1| |N|Grizzly Hills, Drakil'jin Ruins (69.36, 18.14)|
A Dun-da-Dun-tah! |QID|12082| |N|Grizzly Hills, Drakil'jin Ruins (69.41, 17.52)|
- |QID|12082.1| |QO|Harrison has escorted you to safety.| |N|Grizzly Hills,  (73.46, 23.92)|
- |QID|12114.2| |QO|Drakkari Oracle slain: 10/10| |N|Grizzly Hills, Drakil'jin Ruins (73.42, 25.17)|
- |QID|12114.1| |QO|Drakkari Protector slain: 10/10| |N|Grizzly Hills, Drakil'jin Ruins (72.12, 28.14)|
T It Takes Guts.... |QID|12116| |N|Grizzly Hills, Harkor's Camp (73.88, 34.21)|
A Drak'aguul's Mallet |QID|12120| |N|Grizzly Hills, Harkor's Camp (73.88, 34.21)|
T Therapy |QID|12114| |N|Grizzly Hills, Harkor's Camp (73.75, 34.07)|
T Dun-da-Dun-tah! |QID|12082| |N|Grizzly Hills, Harkor's Camp (73.75, 34.07)|
- |QID|12120.1| |QO|Drakil'jin Mallet: 1/1| |N|Grizzly Hills, Drakil'jin Ruins (72.70, 29.78)|
U |cffffffff|Hitem:35797:0:0:0:0:0:0:658664649:77|h[Drakuru's Elixir]|h|r |N|Grizzly Hills, Drakil'jin Ruins (71.43, 24.71)|
U |cffffffff|Hitem:28501:0:0:0:0:0:0:190607232:77|h[Ravager Egg Omelet]|h|r |N|Grizzly Hills, Drakil'jin Ruins (71.67, 26.14)|
T Voices From the Dust |QID|12068| |N|Grizzly Hills, Drakil'jin Ruins (71.67, 26.14)|
A Cleansing Drak'Tharon |QID|12238| |N|Grizzly Hills, Drakil'jin Ruins (71.67, 26.14)|
T Drak'aguul's Mallet |QID|12120| |N|Grizzly Hills, Harkor's Camp (73.89, 34.19)|
A See You on the Other Side |QID|12121| |N|Grizzly Hills, Harkor's Camp (73.89, 34.19)|
U |cffffffff|Hitem:36834:0:0:0:0:0:0:1998834032:77|h[Charged Drakil'jin Mallet]|h|r |N|Grizzly Hills, Drakil'jin Ruins (71.51, 24.82)|
- |QID|12121.1| |QO|Death by Warlord Jin'arrak: 1/1| |N|Grizzly Hills, Drakil'jin Ruins (71.45, 24.68)|
T See You on the Other Side |QID|12121| |N|Grizzly Hills, Drakil'jin Ruins (69.47, 19.44)|
A Chill Out, Mon |QID|12137| |N|Grizzly Hills, Drakil'jin Ruins (69.47, 19.44)|
- |QID|12137.1| |QO|Snow of Eternal Slumber: 1/1| |N|Grizzly Hills, Drakil'jin Ruins (69.41, 19.53)|
U |cffffffff|Hitem:36859:0:0:0:0:0:0:431986219:77|h[Snow of Eternal Slumber]|h|r |N|Grizzly Hills, Drakil'jin Ruins (70.32, 20.24)|
- |QID|12137.2| |QO|Drakkari Spirit Particles: 5/5| |N|Grizzly Hills, Drakil'jin Ruins (70.95, 19.57)|
T Chill Out, Mon |QID|12137| |N|Grizzly Hills, Harkor's Camp (73.92, 34.21)|
A Jin'arrak's End |QID|12152| |N|Grizzly Hills, Harkor's Camp (73.92, 34.21)|
U |cffffffff|Hitem:36873:0:0:0:0:0:0:1625111164:77|h[Drakkari Spirit Dust]|h|r |N|Grizzly Hills, Drakil'jin Ruins (71.22, 19.77)|
U |cffffffff|Hitem:37063:0:0:0:0:0:0:1909677376:77|h[Infused Drakkari Offering]|h|r |N|Grizzly Hills, Drakil'jin Ruins (71.33, 24.55)|
- |QID|12152.1| |QO|Warlord Jin'arrak Destroyed: 1/1| |N|Grizzly Hills, Drakil'jin Ruins (71.33, 24.55)|
T Jin'arrak's End |QID|12152| |N|Grizzly Hills, Harkor's Camp (73.89, 34.24)|
- |QID|12113.1| |QO|Fibrous Worg Meat: 10/10| |N|Grizzly Hills, Solstice Village (65.64, 42.61)|
U |cffffffff|Hitem:37716:0:0:0:0:0:0:1311790260:77|h[Flashbang Grenade]|h|r |N|Grizzly Hills, Westfall Brigade Encampment (60.91, 31.32)|
- |QID|12415.1| |QO|Highland Mustangs Frightened: 15/15| |N|Grizzly Hills,  (59.48, 20.14)|
T An Expedient Ally |QID|12074| |N|Grizzly Hills, Boulder Hills (65.65, 17.83)|
A Raining Down Destruction |QID|11982| |N|Grizzly Hills, Boulder Hills (65.65, 17.83)|
U |cffffffff|Hitem:35734:0:0:0:0:0:0:2076652569:77|h[Boulder]|h|r |N|Grizzly Hills, Thor Modan (68.99, 14.28)|
U |cffffffff|Hitem:35734:0:0:0:0:0:0:2125975184:77|h[Boulder]|h|r |N|Grizzly Hills, Thor Modan (69.01, 14.30)|
- |QID|11982.1| |QO|Iron Dwarf Operations Disrupted: 5/5| |N|Grizzly Hills, Thor Modan (69.01, 14.30)|
T Raining Down Destruction |QID|11982| |N|Grizzly Hills, Boulder Hills (65.62, 17.76)|
A Rallying the Troops |QID|12070| |N|Grizzly Hills, Boulder Hills (65.62, 17.76)|
U |cffffffff|Hitem:36764:0:0:0:0:0:0:521829636:77|h[Shard of the Earth]|h|r |N|Grizzly Hills, Boulder Hills (67.95, 12.36)|
- |QID|12070.1| |QO|Grizzly Hills Giants Rallied: 5/5| |N|Grizzly Hills, Boulder Hills (67.37, 10.46)|
- |QID|12070.2| |QO|Iron Rune Avengers Slain: 5/5| |N|Grizzly Hills, Boulder Hills (67.28, 9.81)|
T Rallying the Troops |QID|12070| |N|Grizzly Hills, Boulder Hills (65.65, 17.78)|
A Into the Breach |QID|11985| |N|Grizzly Hills, Boulder Hills (65.65, 17.78)|
A The Damaged Journal |QID|12026| |N|Grizzly Hills, Thor Modan (64.24, 19.82)|
U |cffffffff|Hitem:35739:0:0:0:0:0:0:1889990164:77|h[Incomplete Journal]|h|r |N|Grizzly Hills, Thor Modan (64.61, 23.71)|
- |QID|12026.1| |QO|Brann Bronzebeard's Journal: 1/1| |N|Grizzly Hills, Thor Modan (64.61, 23.71)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:77|h[Hearthstone]|h|r |N|Grizzly Hills, Thor Modan (64.55, 23.57)|
T The Damaged Journal |QID|12026| |N|Grizzly Hills, Camp Oneqwah (65.25, 47.71)|
A Deciphering the Journal |QID|12054| |N|Grizzly Hills, Camp Oneqwah (65.25, 47.71)|
T The Horse Hollerer |QID|12415| |N|Grizzly Hills, Camp Oneqwah (65.02, 47.80)|
- |QID|12054.1| |QO|Spiritsbreath: 1/1| |N|Grizzly Hills, Heart's Blood Shrine (66.44, 58.72)|
T Deciphering the Journal |QID|12054| |N|Grizzly Hills, Camp Oneqwah (65.16, 47.81)|
A The Runic Prophecies |QID|12058| |N|Grizzly Hills, Camp Oneqwah (65.16, 47.81)|
A Pounding the Iron |QID|12073| |N|Grizzly Hills, Camp Oneqwah (65.12, 47.68)|
- |QID|12073.1| |QO|Iron Dwarf Defenders Killed: 10/10| |N|Grizzly Hills, Thor Modan (68.62, 15.31)|
- |QID|12058.3| |QO|Third Prophecy Deciphered: 1/1| |N|Grizzly Hills, Thor Modan (68.49, 16.11)|
- |QID|12058.1| |QO|First Prophecy Deciphered: 1/1| |N|Grizzly Hills, Thor Modan (69.00, 14.50)|
- |QID|11985.1| |QO|Iron Thane Argrum slain: 1/1| |N|Grizzly Hills, Thor Modan (70.18, 13.02)|
- |QID|12058.2| |QO|Second Prophecy Deciphered: 1/1| |N|Grizzly Hills, Thor Modan (70.11, 14.66)|
T Into the Breach |QID|11985| |N|Grizzly Hills, Boulder Hills (65.62, 17.73)|
A Gavrock |QID|12081| |N|Grizzly Hills, Boulder Hills (65.62, 17.73)|
T Gavrock |QID|12081| |N|Grizzly Hills, Ruins of Tethys (79.74, 33.71)|
A Runes of Compulsion |QID|12093| |N|Grizzly Hills, Ruins of Tethys (79.74, 33.71)|
U |cffffffff|Hitem:37542:0:0:0:0:0:0:692610146:77|h[Fishing Net]|h|r |N|Grizzly Hills, Ruins of Tethys (79.47, 34.02)|
- |QID|12279.1| |QO|Northern Salmon: 6/6| |N|Grizzly Hills, Eastwind Shore (76.49, 34.47)|
- |QID|12093.3| |QO|Overseer Lochli slain: 1/1| |N|Grizzly Hills, Eastwind Shore (75.06, 37.35)|
U |cffffffff|Hitem:33454:0:0:0:0:0:0:1620553220:77|h[Salted Venison]|h|r |N|Grizzly Hills, Eastwind Shore (79.00, 43.43)|
- |QID|12093.4| |QO|Overseer Brunon slain: 1/1| |N|Grizzly Hills, Eastwind Shore (78.94, 43.66)|
- |QID|12093.2| |QO|Overseer Korgan slain: 1/1| |N|Grizzly Hills, Eastwind Shore (71.92, 34.26)|
- |QID|12093.1| |QO|Overseer Durval slain: 1/1| |N|Grizzly Hills, Eastwind Shore (67.58, 29.60)|
- |QID|12113.2| |QO|Shovelhorn Steak: 10/10| |N|Grizzly Hills, Eastwind Shore (73.08, 36.03)|
T Nice to Meat You |QID|12113| |N|Grizzly Hills, Harkor's Camp (73.73, 34.13)|
T Runes of Compulsion |QID|12093| |N|Grizzly Hills, Ruins of Tethys (79.75, 33.76)|
A Latent Power |QID|12094| |N|Grizzly Hills, Ruins of Tethys (79.75, 33.76)|
U |cffffffff|Hitem:36787:0:0:0:0:0:0:1017958550:77|h[Shard of Gavrock]|h|r |N|Grizzly Hills, Eastwind Shore (78.82, 39.77)|
- |QID|12094.2| |QO|Power Drawn from Second Ancient Stone: 1/1| |N|Grizzly Hills, Eastwind Shore (78.82, 39.77)|
- |QID|12094.3| |QO|Power Drawn from Third Ancient Stone: 1/1| |N|Grizzly Hills,  (74.04, 44.05)|
- |QID|12094.1| |QO|Power Drawn from First Ancient Stone: 1/1| |N|Grizzly Hills,  (71.37, 39.64)|
T Latent Power |QID|12094| |N|Grizzly Hills, Ruins of Tethys (79.70, 33.70)|
A Free at Last |QID|12099| |N|Grizzly Hills, Ruins of Tethys (79.70, 33.70)|
- |QID|12099.1| |QO|Runed Giants Freed: 4/4| |N|Grizzly Hills,  (73.72, 45.03)|
T The Runic Prophecies |QID|12058| |N|Grizzly Hills, Camp Oneqwah (65.19, 47.85)|
T Pounding the Iron |QID|12073| |N|Grizzly Hills, Camp Oneqwah (65.16, 47.80)|
A In the Name of Loken |QID|12204| |N|Grizzly Hills, Camp Oneqwah (65.16, 47.80)|
U |cff1eff00|Hitem:36674:0:0:0:0:0:-44:1401880606:77|h[Old Tooth of the Elder]|h|r |N|Grizzly Hills, Camp Oneqwah (65.45, 47.40)|
T A Bear of an Appetite |QID|12279| |N|Grizzly Hills, Redwood Trading Post (69.02, 40.15)|
- |QID|12204.1| |QO|Hugh Glass Questioned: 1/1| |N|Grizzly Hills, Redwood Trading Post (69.02, 40.15)|
T Free at Last |QID|12099| |N|Grizzly Hills, Ruins of Tethys (79.68, 33.70)|
- |QID|12204.2| |QO|Gavrock Questioned: 1/1| |N|Grizzly Hills, Ruins of Tethys (79.68, 33.70)|
T In the Name of Loken |QID|12204| |N|Grizzly Hills, Camp Oneqwah (65.11, 47.61)|
A The Overseer's Shadow |QID|12201| |N|Grizzly Hills, Camp Oneqwah (65.11, 47.61)|
T Attack on Silverbrook |QID|12413| |N|Grizzly Hills, Conquest Hold (20.77, 64.20)|
A Ruuna the Blind |QID|12425| |N|Grizzly Hills, Conquest Hold (20.94, 64.12)|
A The Conquest Pit: Bear Wrestling! |QID|12427| |N|Grizzly Hills, Conquest Hold (22.36, 63.88)|
T Eyes Above |QID|12453| |N|Grizzly Hills, Conquest Hold (22.51, 62.94)|
A Vordrassil's Fall |QID|12207| |N|Grizzly Hills, Conquest Hold (22.51, 62.94)|
A The Darkness Beneath |QID|12213| |N|Grizzly Hills, Conquest Hold (22.51, 62.94)|
U |cffffffff|Hitem:36849:0:0:0:0:0:0:2135060414:77|h[Golem Blueprint Section 1]|h|r |N|Grizzly Hills, Dun Argol (77.08, 62.33)|
- |QID|12165.1| |QO|War Golem Blueprint: 1/1| |N|Grizzly Hills, Dun Argol (77.08, 62.33)|
- |QID|12201.1| |QO|Overseer's Uniform: 1/1| |N|Grizzly Hills, Dun Argol (76.16, 57.87)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:77|h[Hearthstone]|h|r |N|Grizzly Hills, Dun Argol (76.16, 57.87)|
T An Intriguing Plan |QID|12165| |N|Grizzly Hills, Camp Oneqwah (65.15, 47.34)|
A From the Ground Up |QID|12196| |N|Grizzly Hills, Camp Oneqwah (65.15, 47.34)|
T The Overseer's Shadow |QID|12201| |N|Grizzly Hills, Camp Oneqwah (65.10, 47.65)|
A Cultivating an Image |QID|12202| |N|Grizzly Hills, Camp Oneqwah (65.10, 47.65)|
U |cff1eff00|Hitem:41599:0:0:0:0:0:0:504258900:78|h[Frostweave Bag]|h|r |N|Grizzly Hills, Camp Oneqwah (65.47, 47.34)|
U |cff1eff00|Hitem:41599:0:0:0:0:0:0:1947379451:78|h[Frostweave Bag]|h|r |N|Grizzly Hills, Camp Oneqwah (65.47, 47.34)|
U |cff0070dd|Hitem:41357:0:0:0:0:0:0:272762217:78|h[Daunting Handguards]|h|r |N|Grizzly Hills, Camp Oneqwah (65.47, 47.34)|
U |cff0070dd|Hitem:41345:0:0:0:0:0:0:1515970593:78|h[Daunting Legplates]|h|r |N|Grizzly Hills, Camp Oneqwah (65.47, 47.34)|
U |cff0070dd|Hitem:38452:0:0:0:0:0:0:0:78|h[Bulwark of the Warchief]|h|r |N|Vengeance Landing Inn, Howling Fjord,  (79.58, 30.74)|
U |cff0070dd|Hitem:38454:0:0:0:0:0:0:0:78|h[Warsong Punisher]|h|r |N|Vengeance Landing Inn, Howling Fjord,  (79.58, 30.74)|
U |cff0070dd|Hitem:44349:0:0:0:0:0:0:604820536:78|h[Warchief's Legplates of Carnage]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:44953:0:0:0:0:0:0:1768602996:78|h[Worg Tartare]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:36733:0:0:0:0:0:0:582209567:78|h[Coldwind Lumber]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:36770:0:0:0:0:0:0:1777122878:78|h[Zort's Protective Elixir]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:43010:0:0:0:0:0:0:1800776480:78|h[Worm Meat]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:37097:0:0:0:0:0:0:1103865170:78|h[Scroll of Spirit VII]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:22829:0:0:0:0:0:0:-2034490498:78|h[Super Healing Potion]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:35685:0:0:0:0:0:0:-2115393472:78|h[Crystallized Mana Shard]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:21519:0:0:0:0:0:0:218215135:78|h[Mistletoe]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:37173:0:0:0:0:0:0:778211828:78|h[Geomancer's Orb]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:22832:0:0:0:0:0:0:-1634014106:78|h[Super Mana Potion]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:22829:0:0:0:0:0:0:1663561680:78|h[Super Healing Potion]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cff1eff00|Hitem:38198:0:0:0:0:0:0:1812689862:78|h[Joint-Severing Quickblade]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:35797:0:0:0:0:0:0:658664649:78|h[Drakuru's Elixir]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:28102:0:0:0:0:0:0:716646330:78|h[Onslaught Elixir]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:3928:0:0:0:0:0:0:1263245930:78|h[Superior Healing Potion]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cff1eff00|Hitem:31952:0:0:0:0:0:0:1592998639:78|h[Khorium Lockbox]|h|r |N|Undercity, Trade Quarter (66.20, 45.46)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:78|h[Hearthstone]|h|r |N|Undercity, War Quarter (48.06, 15.35)|
U |cffffffff|Hitem:37125:0:0:0:0:0:0:504450536:78|h[Rokar's Camera]|h|r |N|Grizzly Hills, Dun Argol (76.40, 57.03)|
U |cffffffff|Hitem:33120:0:0:0:0:0:0:1292441011:78|h[Shoveltusk Meat]|h|r |N|Grizzly Hills, Dun Argol (76.83, 58.97)|
- |QID|12202.1| |QO|Iron Dwarf Images Captured: 8/8| |N|Grizzly Hills, Dun Argol (75.42, 56.46)|
- |QID|12196.1| |QO|War Golem Part: 8/8| |N|Grizzly Hills, Dun Argol (76.84, 62.60)|
T Cultivating an Image |QID|12202| |N|Grizzly Hills, Camp Oneqwah (65.09, 47.69)|
A Loken's Orders |QID|12203| |N|Grizzly Hills, Camp Oneqwah (65.09, 47.69)|
T From the Ground Up |QID|12196| |N|Grizzly Hills, Camp Oneqwah (65.14, 47.33)|
A We Have the Power |QID|12197| |N|Grizzly Hills, Camp Oneqwah (65.14, 47.33)|
- |QID|12197.1| |QO|Durar's Power Cell: 1/1| |N|Grizzly Hills, Dun Argol (74.94, 56.98)|
- |QID|12197.2| |QO|Kathorn's Power Cell: 1/1| |N|Grizzly Hills, Dun Argol (76.83, 58.96)|
U |cffffffff|Hitem:37071:0:0:0:0:0:0:2119710201:78|h[Overseer Disguise Kit]|h|r |N|Grizzly Hills, Dun Argol (77.80, 58.13)|
- |QID|12203.1| |QO|Message from Loken received: 1/1| |N|Grizzly Hills, Dun Argol (81.47, 60.27)|
T Loken's Orders |QID|12203| |N|Grizzly Hills, Camp Oneqwah (65.11, 47.65)|
T We Have the Power |QID|12197| |N|Grizzly Hills, Camp Oneqwah (65.12, 47.39)|
A ... Or Maybe We Don't |QID|12198| |N|Grizzly Hills, Camp Oneqwah (65.12, 47.39)|
- |QID|12198.1| |QO|Charge Level: 10/10| |N|Grizzly Hills,  (72.67, 56.02)|
T ... Or Maybe We Don't |QID|12198| |N|Grizzly Hills, Camp Oneqwah (65.12, 47.33)|
A Bringing Down the Iron Thane |QID|12199| |N|Grizzly Hills, Camp Oneqwah (65.12, 47.33)|
U |cffffffff|Hitem:36865:0:0:0:0:0:0:1255008589:78|h[Golem Control Unit]|h|r |N|Grizzly Hills, Dun Argol (76.12, 62.85)|
- |QID|12199.1| |QO|Iron Thane Furyhammer slain: 1/1| |N|Grizzly Hills, Dun Argol (76.47, 63.81)|
T Bringing Down the Iron Thane |QID|12199| |N|Grizzly Hills, Camp Oneqwah (65.16, 47.47)|
- |QID|12213.3| |QO|Orb used beneath Vordrassil's Tears.: 1/1| |N|Grizzly Hills, Vordrassil's Tears (30.37, 43.66)|
- |QID|12213.2| |QO|Orb used beneath Vordrassil's Limb.: 1/1| |N|Grizzly Hills, Vordrassil's Limb (32.14, 45.96)|
- |QID|12213.1| |QO|Orb used beneath Vordrassil's Heart.: 1/1| |N|Grizzly Hills, Vordrassil's Heart (41.24, 54.64)|
- |QID|12207.1| |QO|Slime Sample: 6/6| |N|Grizzly Hills, Vordrassil's Heart (39.85, 48.92)|
T Ruuna the Blind |QID|12425| |N|Grizzly Hills, Ruuna's Camp (44.02, 48.01)|
A Ruuna's Request |QID|12328| |N|Grizzly Hills, Ruuna's Camp (44.02, 48.01)|
- |QID|12328.1| |QO|Gossamer Dust: 4/4| |N|Grizzly Hills,  (46.92, 40.99)|
T Ruuna's Request |QID|12328| |N|Grizzly Hills, Ruuna's Camp (44.05, 47.82)|
A Out of Body Experience |QID|12327| |N|Grizzly Hills, Ruuna's Camp (44.05, 47.82)|
U |cffffffff|Hitem:37661:0:0:0:0:0:0:311666262:78|h[Gossamer Potion]|h|r |N|Grizzly Hills, Ruuna's Camp (44.05, 47.82)|
- |QID|12327.1| |QO|Vision from the Past| |N|Silverpine Forest, Pyrewood Village (46.52, 76.16)|
T Out of Body Experience |QID|12327| |N|Grizzly Hills, Ruuna's Camp (44.12, 47.86)|
A Fate and Coincidence |QID|12329| |N|Grizzly Hills, Ruuna's Camp (44.12, 47.86)|
T Fate and Coincidence |QID|12329| |N|Grizzly Hills, White Pine Trading Post (57.57, 41.30)|
A Sasha's Hunt |QID|12134| |N|Grizzly Hills, White Pine Trading Post (57.57, 41.30)|
A Anatoly Will Talk |QID|12330| |N|Grizzly Hills, White Pine Trading Post (57.57, 41.30)|
- |QID|12134.1| |QO|Solstice Hunter slain: 12/12| |N|Grizzly Hills, Solstice Village (62.59, 41.62)|
U |cffffffff|Hitem:37665:0:0:0:0:0:0:1461055995:78|h[Tranquilizer Dart]|h|r |N|Grizzly Hills, Solstice Village (62.43, 41.84)|
- |QID|12330.1| |QO|Tatjana Delivered| |N|Grizzly Hills, White Pine Trading Post (57.78, 41.71)|
T Sasha's Hunt |QID|12134| |N|Grizzly Hills, White Pine Trading Post (57.56, 41.36)|
T Anatoly Will Talk |QID|12330| |N|Grizzly Hills, White Pine Trading Post (57.56, 41.36)|
A A Sister's Pledge |QID|12411| |N|Grizzly Hills, White Pine Trading Post (57.56, 41.36)|
T A Sister's Pledge |QID|12411| |N|Grizzly Hills, Duskhowl Den (64.86, 43.42)|
A Hour of the Worg |QID|12164| |N|Grizzly Hills, Duskhowl Den (64.92, 43.50)|
T Vordrassil's Fall |QID|12207| |N|Grizzly Hills, Conquest Hold (22.49, 63.03)|
T The Darkness Beneath |QID|12213| |N|Grizzly Hills, Conquest Hold (22.49, 63.03)|
A A Possible Link |QID|12229| |N|Grizzly Hills, Conquest Hold (22.49, 63.03)|
A The Bear God's Offspring |QID|12231| |N|Grizzly Hills, Conquest Hold (22.49, 63.03)|
- |QID|12231.1| |QO|Orsonn's Story: 1/1| |N|Grizzly Hills, Rage Fang Shrine (48.12, 58.73)|
- |QID|12231.2| |QO|Kodian's Story: 1/1| |N|Grizzly Hills, Heart's Blood Shrine (66.86, 62.21)|
- |QID|12229.1| |QO|Crazed Furbolg Blood: 8/8| |N|Grizzly Hills, Rage Fang Shrine (48.58, 57.75)|
T A Possible Link |QID|12229| |N|Grizzly Hills, Conquest Hold (22.50, 62.94)|
T The Bear God's Offspring |QID|12231| |N|Grizzly Hills, Conquest Hold (22.50, 62.94)|
A Destroy the Sapling |QID|12241| |N|Grizzly Hills, Conquest Hold (22.50, 62.94)|
A Vordrassil's Seeds |QID|12242| |N|Grizzly Hills, Conquest Hold (22.50, 62.94)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:1595508862:78|h[Frostweave Cloth]|h|r |N|Grizzly Hills, Conquest Hold (21.49, 64.97)|
U |cffffffff|Hitem:11325:0:0:0:0:0:0:0:78|h[Dark Iron Ale Mug]|h|r |N|Terokkar Forest,  (33.79, 35.74)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:78|h[Hearthstone]|h|r |N|Terokkar Forest,  (33.92, 35.63)|
U |cffffffff|Hitem:22789:0:0:0:0:0:0:0:78|h[Terocone]|h|r |N|Grizzly Hills, Conquest Hold (21.44, 64.95)|
U |cffffffff|Hitem:13465:0:0:0:0:0:0:0:78|h[Mountain Silversage]|h|r |N|Grizzly Hills, Conquest Hold (21.44, 64.95)|
U |cffffffff|Hitem:22791:0:0:0:0:0:0:0:78|h[Netherbloom]|h|r |N|Grizzly Hills, Conquest Hold (21.44, 64.95)|
U |cffffffff|Hitem:36904:0:0:0:0:0:0:0:78|h[Tiger Lily]|h|r |N|Grizzly Hills, Conquest Hold (21.44, 64.95)|
U |cffffffff|Hitem:36905:0:0:0:0:0:0:0:78|h[Lichbloom]|h|r |N|Grizzly Hills, Conquest Hold (21.44, 64.95)|
U |cffffffff|Hitem:37921:0:0:0:0:0:0:0:78|h[Deadnettle]|h|r |N|Grizzly Hills, Conquest Hold (21.44, 64.95)|
U |cff1eff00|Hitem:13468:0:0:0:0:0:0:0:78|h[Black Lotus]|h|r |N|Grizzly Hills, Conquest Hold (21.44, 64.95)|
U |cffffffff|Hitem:25708:0:0:0:0:0:0:0:78|h[Thick Clefthoof Leather]|h|r |N|Grizzly Hills, Conquest Hold (21.44, 64.95)|
U |cffffffff|Hitem:37306:0:0:0:0:0:0:1899525811:78|h[Verdant Torch]|h|r |N|Grizzly Hills, Grizzlemaw (50.96, 42.65)|
- |QID|12241.1| |QO|Vordrassil's Ashes: 1/1| |N|Grizzly Hills, Grizzlemaw (50.87, 42.66)|
- |QID|12242.1| |QO|Vordrassil's Seed: 8/8| |N|Grizzly Hills, Grizzlemaw (50.77, 36.74)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:78|h[Hearthstone]|h|r |N|Grizzly Hills, Grizzlemaw (50.53, 37.38)|
T Destroy the Sapling |QID|12241| |N|Grizzly Hills, Conquest Hold (22.48, 62.99)|
T Vordrassil's Seeds |QID|12242| |N|Grizzly Hills, Conquest Hold (22.48, 62.99)|
A Ursoc, the Bear God |QID|12236| |N|Grizzly Hills, Conquest Hold (22.48, 62.99)|
T The Faceless Ones |QID|13187| |N|Dragonblight, The Pit of Narjun (26.17, 50.69)|
A The Conquest Pit: Bear Wrestling! |QID|12427| |N|Grizzly Hills, Conquest Hold (22.39, 63.88)|
- |QID|12427.1| |QO|Ironhide defeated| |N|Grizzly Hills, The Conquest Pit (23.20, 64.56)|
T The Conquest Pit: Bear Wrestling! |QID|12427| |N|Grizzly Hills, Conquest Hold (22.31, 64.09)|
A The Conquest Pit: Mad Furbolg Fighting |QID|12428| |N|Grizzly Hills, Conquest Hold (22.41, 63.89)|
- |QID|12428.1| |QO|Torgg Thundertotem defeated| |N|Grizzly Hills, The Conquest Pit (23.25, 64.65)|
T The Conquest Pit: Mad Furbolg Fighting |QID|12428| |N|Grizzly Hills, Conquest Hold (22.30, 64.05)|
A The Conquest Pit: Blood and Metal |QID|12429| |N|Grizzly Hills, Conquest Hold (22.41, 63.95)|
- |QID|12429.1| |QO|Rustblood defeated| |N|Grizzly Hills, The Conquest Pit (23.25, 64.65)|
T The Conquest Pit: Blood and Metal |QID|12429| |N|Grizzly Hills, Conquest Hold (22.30, 64.06)|
A The Conquest Pit: Death Is Likely |QID|12430| |N|Grizzly Hills, Conquest Hold (22.38, 63.92)|
- |QID|12430.1| |QO|Horgrenn Hellcleave defeated| |N|Grizzly Hills, The Conquest Pit (23.08, 64.52)|
T The Conquest Pit: Death Is Likely |QID|12430| |N|Grizzly Hills, Conquest Hold (22.31, 64.10)|
A The Conquest Pit: Final Showdown |QID|12431| |N|Grizzly Hills, Conquest Hold (22.37, 63.86)|
T The Conquest Pit: Final Showdown |QID|12431| |N|Grizzly Hills, The Conquest Pit (23.38, 64.91)|
U |cffffffff|Hitem:37307:0:0:0:0:0:0:1694939182:78|h[Purified Ashes of Vordrassil]|h|r |N|Grizzly Hills, Ursoc's Den (52.03, 18.43)|
- |QID|12236.1| |QO|Ursoc Cleansed: 1/1| |N|Grizzly Hills, Ursoc's Den (52.03, 18.43)|
T Ursoc, the Bear God |QID|12236| |N|Grizzly Hills, Conquest Hold (22.51, 62.96)|
U |cff0070dd|Hitem:39173:0:0:0:0:0:0:723806076:78|h[Bulwark of the Tormented God]|h|r |N|Grizzly Hills, Conquest Hold (22.00, 65.11)|
U |cff0070dd|Hitem:38452:0:0:0:0:0:0:0:78|h[Bulwark of the Warchief]|h|r |N|Grizzly Hills, Conquest Hold (22.00, 65.11)|
U |cff1eff00|Hitem:25054:0:0:0:0:0:-45:-777191395:78|h[Sodalite Band of the Champion]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cff1eff00|Hitem:13468:0:0:0:0:0:0:0:78|h[Black Lotus]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cff1eff00|Hitem:10129:0:0:0:0:0:1208:1853270824:78|h[Revenant Gauntlets of the Bear]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cff1eff00|Hitem:15280:0:0:0:0:0:850:1398647746:78|h[Wizard's Hand of the Eagle]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cffffffff|Hitem:3914:0:0:0:0:0:0:-974866188:78|h[Journeyman's Backpack]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cffffffff|Hitem:8500:0:0:0:0:0:0:0:78|h[Great Horned Owl]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cffffffff|Hitem:8501:0:0:0:0:0:0:0:78|h[Hawk Owl]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cffffffff|Hitem:8497:0:0:0:0:0:0:0:78|h[Rabbit Crate (Snowshoe)]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cffffffff|Hitem:8486:0:0:0:0:0:0:0:78|h[Cat Carrier (Cornish Rex)]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cffffffff|Hitem:8485:0:0:0:0:0:0:0:78|h[Cat Carrier (Bombay)]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cffffffff|Hitem:8488:0:0:0:0:0:0:0:78|h[Cat Carrier (Silver Tabby)]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
U |cffffffff|Hitem:8487:0:0:0:0:0:0:0:78|h[Cat Carrier (Orange Tabby)]|h|r |N|Zul'Drak, The Argent Stand (40.92, 65.82)|
T Into the Breach! |QID|12789| |N|Zul'Drak, Light's Breach (32.07, 74.49)|
A This Just In: Fire Still Hot! |QID|12859| |N|Zul'Drak, Light's Breach (31.99, 75.49)|
A Trolls Is Gone Crazy! |QID|12861| |N|Zul'Drak, Light's Breach (32.12, 75.60)|
A In Search Of Answers |QID|12902| |N|Zul'Drak, Light's Breach (32.15, 75.65)|
A Wanted: Ragemane's Flipper |QID|12857| |N|Zul'Drak, Light's Breach (32.20, 75.66)|
U |cffffffff|Hitem:41161:0:0:0:0:0:0:-1904780376:78|h[Drakuru \"Lock Opener\"]|h|r |N|Zul'Drak, Rageclaw Den (34.09, 82.30)|
U |cffffffff|Hitem:41161:0:0:0:0:0:0:385723646:78|h[Drakuru \"Lock Opener\"]|h|r |N|Zul'Drak, Rageclaw Den (34.58, 83.94)|
U |cffffffff|Hitem:41161:0:0:0:0:0:0:1451142016:78|h[Drakuru \"Lock Opener\"]|h|r |N|Zul'Drak, Rageclaw Den (35.17, 84.42)|
T In Search Of Answers |QID|12902| |N|Zul'Drak, Rageclaw Den (34.98, 83.88)|
A Orders From Drakuru |QID|12883| |N|Zul'Drak, Rageclaw Den (34.98, 83.88)|
U |cffffffff|Hitem:41161:0:0:0:0:0:0:-1895741269:78|h[Drakuru \"Lock Opener\"]|h|r |N|Zul'Drak, Rageclaw Den (35.42, 84.01)|
U |cffffffff|Hitem:41161:0:0:0:0:0:0:1792051987:78|h[Drakuru \"Lock Opener\"]|h|r |N|Zul'Drak, Rageclaw Den (35.44, 82.53)|
- |QID|12861.1| |QO|Captured Rageclaw Freed: 8/8| |N|Zul'Drak, Rageclaw Den (35.44, 82.53)|
- |QID|12859.1| |QO|Hut Fire Doused: 15/15| |N|Zul'Drak, Rageclaw Den (35.11, 81.43)|
T Orders From Drakuru |QID|12883| |N|Zul'Drak, Light's Breach (32.09, 75.82)|
A The Ebon Watch |QID|12884| |N|Zul'Drak, Light's Breach (32.09, 75.82)|
T Trolls Is Gone Crazy! |QID|12861| |N|Zul'Drak, Light's Breach (32.13, 75.71)|
T This Just In: Fire Still Hot! |QID|12859| |N|Zul'Drak, Light's Breach (32.01, 75.66)|
A Crusader Forward Camp |QID|12894| |N|Zul'Drak, Light's Breach (32.09, 75.66)|
- |QID|12857.1| |QO|Ragemane's Flipper: 1/1| |N|Zul'Drak, Rageclaw Lake (38.23, 84.51)|
T Wanted: Ragemane's Flipper |QID|12857| |N|Zul'Drak, Light's Breach (32.13, 75.73)|
U |cff0070dd|Hitem:44734:0:0:0:0:0:0:165096544:78|h[Hammer of Quiet Mourning]|h|r |N|Zul'Drak, Light's Breach (31.43, 75.29)|
T The Ebon Watch |QID|12884| |N|Zul'Drak, Ebon Watch (14.10, 73.70)|
A Kickin' Nass and Takin' Manes |QID|12630| |N|Zul'Drak, Ebon Watch (14.10, 73.70)|
A The Amphitheater of Anguish: Yggdras! |QID|12932| |N|Zul'Drak, Amphitheater of Anguish (48.50, 56.34)|
- |QID|12932.1| |QO|Yggdras Defeated| |N|Zul'Drak, Amphitheater of Anguish (48.00, 56.78)|
T The Amphitheater of Anguish: Yggdras! |QID|12932| |N|Zul'Drak, Amphitheater of Anguish (48.50, 56.31)|
A The Amphitheater of Anguish: Magnataur! |QID|12933| |N|Zul'Drak, Amphitheater of Anguish (48.04, 56.46)|
- |QID|12933.1| |QO|Stinkbeard Defeated| |N|Zul'Drak, Amphitheater of Anguish (47.98, 56.51)|
T The Amphitheater of Anguish: Magnataur! |QID|12933| |N|Zul'Drak, Amphitheater of Anguish (48.46, 56.31)|
A The Amphitheater of Anguish: From Beyond! |QID|12934| |N|Zul'Drak, Amphitheater of Anguish (48.19, 56.75)|
- |QID|12934.1| |QO|Elemental Lord Defeated| |N|Zul'Drak, Amphitheater of Anguish (48.26, 57.19)|
T The Amphitheater of Anguish: From Beyond! |QID|12934| |N|Zul'Drak, Amphitheater of Anguish (48.52, 56.45)|
A The Amphitheater of Anguish: Tuskarrmageddon! |QID|12935| |N|Zul'Drak, Amphitheater of Anguish (48.23, 56.78)|
- |QID|12935.1| |QO|Orinoko Tuskbreaker Defeated| |N|Zul'Drak, Amphitheater of Anguish (48.01, 56.92)|
T The Amphitheater of Anguish: Tuskarrmageddon! |QID|12935| |N|Zul'Drak, Amphitheater of Anguish (48.53, 56.47)|
A The Amphitheater of Anguish: Korrak the Bloodrager! |QID|12936| |N|Zul'Drak, Amphitheater of Anguish (48.08, 56.57)|
- |QID|12936.1| |QO|Korrak the Bloodrager Defeated| |N|Zul'Drak, Amphitheater of Anguish (47.80, 56.57)|
T The Amphitheater of Anguish: Korrak the Bloodrager! |QID|12936| |N|Zul'Drak, Amphitheater of Anguish (48.47, 56.30)|
A The Champion of Anguish |QID|12948| |N|Zul'Drak, Amphitheater of Anguish (48.09, 56.55)|
- |QID|12948.1| |QO|Vladof the Butcher Defeated| |N|Zul'Drak, Amphitheater of Anguish (48.46, 57.06)|
T The Champion of Anguish |QID|12948| |N|Zul'Drak, Amphitheater of Anguish (48.54, 56.44)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:78|h[Hearthstone]|h|r |N|Zul'Drak, Amphitheater of Anguish (48.54, 56.44)|
T Crusader Forward Camp |QID|12894| |N|Zul'Drak, Crusader Forward Camp (25.35, 64.00)|
A That's What Friends Are For... |QID|12903| |N|Zul'Drak, Crusader Forward Camp (25.35, 64.00)|
A Making Something Out Of Nothing |QID|12901| |N|Zul'Drak, Crusader Forward Camp (25.27, 63.88)|
A A Great Storm Approaches |QID|12912| |N|Zul'Drak, Thrym's End (19.71, 55.94)|
- |QID|12903.2| |QO|Gerk found: 1/1| |N|Zul'Drak, Thrym's End (17.54, 57.38)|
A Light Won't Grant Me Vengeance |QID|12904| |N|Zul'Drak, Thrym's End (17.62, 57.46)|
- |QID|12903.3| |QO|Burr found: 1/1| |N|Zul'Drak, Thrym's End (15.98, 59.18)|
- |QID|12903.1| |QO|Crusader Dargath found: 1/1| |N|Zul'Drak, Dargath's Demise (25.01, 51.99)|
- |QID|12901.1| |QO|Scourge Scrap Metal: 10/10| |N|Zul'Drak, Thrym's End (18.87, 59.53)|
- |QID|12904.1| |QO|Vargul slain: 15/15| |N|Zul'Drak, Thrym's End (18.85, 57.60)|
T Light Won't Grant Me Vengeance |QID|12904| |N|Zul'Drak, Thrym's End (17.69, 57.61)|
T Making Something Out Of Nothing |QID|12901| |N|Zul'Drak, Crusader Forward Camp (25.28, 63.84)|
T A Great Storm Approaches |QID|12912| |N|Zul'Drak, Crusader Forward Camp (25.28, 63.84)|
A Gymer's Salvation |QID|12914| |N|Zul'Drak, Crusader Forward Camp (25.28, 63.84)|
T That's What Friends Are For... |QID|12903| |N|Zul'Drak, Crusader Forward Camp (25.28, 63.84)|
- |QID|12914.1| |QO|Banshee Essence: 6/6| |N|Zul'Drak, The Dead Fields (24.99, 58.70)|
U |cffffffff|Hitem:33454:0:0:0:0:0:0:-1493356098:78|h[Salted Venison]|h|r |N|Zul'Drak,  (11.65, 74.87)|
- |QID|12914.2| |QO|Diatomaceous Earth: 6/6| |N|Zul'Drak,  (15.64, 75.54)|
U |cffffffff|Hitem:38659:0:0:0:0:0:0:2031284758:78|h[Stefan's Steel Toed Boot]|h|r |N|Zul'Drak,  (17.81, 75.43)|
U |cffffffff|Hitem:38659:0:0:0:0:0:0:2031284758:79|h[Stefan's Steel Toed Boot]|h|r |N|Zul'Drak,  (18.77, 75.74)|
- |QID|12630.1| |QO|Hair Samples Collected: 10/10| |N|Zul'Drak,  (14.43, 67.29)|
U |cffffffff|Hitem:38660:0:0:0:0:0:0:-1476548134:79|h[Unliving Choker]|h|r |N|Zul'Drak,  (14.43, 67.29)|
A An Invitation, of Sorts... |QID|12631| |N|Zul'Drak,  (14.43, 67.29)|
T Kickin' Nass and Takin' Manes |QID|12630| |N|Zul'Drak, Ebon Watch (14.13, 73.72)|
T An Invitation, of Sorts... |QID|12631| |N|Zul'Drak, Ebon Watch (14.13, 73.72)|
A Near Miss |QID|12637| |N|Zul'Drak, Ebon Watch (14.13, 73.72)|
- |QID|12637.1| |QO|Choker's Purpose Exposed: 1/1| |N|Zul'Drak, Ebon Watch (14.25, 73.98)|
A Taking a Stand |QID|12795| |N|Zul'Drak, Ebon Watch (14.22, 73.94)|
T Near Miss |QID|12637| |N|Zul'Drak, Ebon Watch (14.11, 73.76)|
A You Can Run, But You Can't Hide |QID|12629| |N|Zul'Drak, Ebon Watch (14.11, 73.76)|
- |QID|12629.2| |QO|Gooey Ghoul Drool: 5/5| |N|Zul'Drak, Reliquary of Agony (20.79, 78.48)|
- |QID|12629.1| |QO|Putrid Abomination Guts: 5/5| |N|Zul'Drak,  (23.54, 75.07)|
T You Can Run, But You Can't Hide |QID|12629| |N|Zul'Drak, Ebon Watch (14.12, 73.76)|
A Dressing Down |QID|12648| |N|Zul'Drak, Ebon Watch (14.12, 73.76)|
- |QID|12648.1| |QO|Bitter Plasma: 1/1| |N|Zul'Drak, Reliquary of Agony (19.78, 75.44)|
A Feedin' Da Goolz |QID|12652| |N|Zul'Drak, Reliquary of Agony (19.78, 75.44)|
U |cffffffff|Hitem:38701:0:0:0:0:0:0:208575484:79|h[Bowels and Brains Bowl]|h|r |N|Zul'Drak,  (18.91, 75.69)|
- |QID|12652.1| |QO|Decaying Ghouls Fed: 10/10| |N|Zul'Drak, Reliquary of Agony (22.59, 74.21)|
T Feedin' Da Goolz |QID|12652| |N|Zul'Drak, Reliquary of Agony (19.89, 75.33)|
T Dressing Down |QID|12648| |N|Zul'Drak, Ebon Watch (14.12, 73.75)|
A Infiltrating Voltarus |QID|12661| |N|Zul'Drak, Ebon Watch (14.12, 73.75)|
A Dark Horizon |QID|12664| |N|Zul'Drak, Voltarus (27.16, 46.09)|
- |QID|12664.1| |QO|Tour of Zul'Drak complete: 1/1| |N|Voltarus,  (27.79, 44.60)|
T Dark Horizon |QID|12664| |N|Voltarus,  (27.15, 46.08)|
- |QID|12661.1| |QO|Overlord Drakuru's task complete: 1/1| |N|Voltarus,  (27.15, 46.08)|
U |cffffffff|Hitem:41390:0:0:0:0:0:0:2053709784:79|h[Stefan's Horn]|h|r |N|Zul'Drak, Reliquary of Pain (28.05, 44.85)|
T Infiltrating Voltarus |QID|12661| |N|Zul'Drak, Reliquary of Pain (28.05, 44.85)|
A So Far, So Bad |QID|12669| |N|Zul'Drak, Reliquary of Pain (28.05, 44.85)|
A It Rolls Downhill |QID|12673| |N|Zul'Drak, Voltarus (27.17, 46.12)|
U |cffffffff|Hitem:39157:0:0:0:0:0:0:59314533:79|h[Scepter of Suggestion]|h|r |N|Zul'Drak, Reliquary of Pain (27.36, 43.61)|
- |QID|12673.1| |QO|Blight Crystals collected: 7/7| |N|Zul'Drak, Reliquary of Pain (28.64, 43.05)|
U |cffffffff|Hitem:39154:0:0:0:0:0:0:307341589:79|h[Diluting Additive]|h|r |N|Zul'Drak, Reliquary of Pain (30.99, 44.28)|
- |QID|12669.2| |QO|Blight Cauldrons diluted: 5/5| |N|Zul'Drak, Reliquary of Pain (30.61, 44.70)|
- |QID|12669.1| |QO|Drakuru's task complete: 1/1| |N|Zul'Drak, Voltarus (27.19, 46.09)|
T It Rolls Downhill |QID|12673| |N|Zul'Drak, Voltarus (27.19, 46.09)|
U |cffffffff|Hitem:41390:0:0:0:0:0:0:2053709784:79|h[Stefan's Horn]|h|r |N|Zul'Drak, Reliquary of Pain (28.07, 44.47)|
T So Far, So Bad |QID|12669| |N|Zul'Drak, Reliquary of Pain (28.07, 44.47)|
A Hazardous Materials |QID|12677| |N|Zul'Drak, Reliquary of Pain (28.07, 44.47)|
A Zero Tolerance |QID|12686| |N|Zul'Drak, Voltarus (27.17, 46.08)|
- |QID|12677.2| |QO|Harvested Blight Crystal: 5/5| |N|Zul'Drak, Voltarus (29.46, 43.29)|
U |cffffffff|Hitem:39206:0:0:0:0:0:0:1177952280:79|h[Scepter of Empowerment]|h|r |N|Zul'Drak, Reliquary of Pain (30.92, 48.67)|
- |QID|12686.1| |QO|Darmuk Slain: 1/1| |N|Zul'Drak, Reliquary of Pain (30.42, 51.01)|
T Zero Tolerance |QID|12686| |N|Zul'Drak, Voltarus (27.16, 46.09)|
- |QID|12677.1| |QO|Drakuru's task complete: 1/1| |N|Zul'Drak, Voltarus (27.16, 46.09)|
T Hazardous Materials |QID|12677| |N|Zul'Drak, Reliquary of Pain (27.98, 44.80)|
A Sabotage |QID|12676| |N|Zul'Drak, Reliquary of Pain (27.98, 44.80)|
A Fuel for the Fire |QID|12690| |N|Zul'Drak, Voltarus (27.17, 46.08)|
U |cffffffff|Hitem:39165:0:0:0:0:0:0:609242259:79|h[Explosive Charges]|h|r |N|Zul'Drak, Reliquary of Pain (27.37, 48.32)|
- |QID|12676.1| |QO|Scourgewagons destroyed: 5/5| |N|Zul'Drak, Reliquary of Pain (28.44, 51.23)|
U |cffffffff|Hitem:39238:0:0:0:0:0:0:1873758048:79|h[Scepter of Command]|h|r |N|Zul'Drak, Frigid Breach (32.21, 40.59)|
- |QID|12690.1| |QO|Drakkari Skullcrushers Slain: 60/60| |N|Zul'Drak, Frigid Breach (33.46, 36.39)|
- |QID|12690.2| |QO|Drakkari Chieftain Lured: 3/3| |N|Zul'Drak, Frigid Breach (33.23, 37.08)|
T Fuel for the Fire |QID|12690| |N|Zul'Drak, Voltarus (27.17, 46.10)|
- |QID|12676.2| |QO|Drakuru's task complete: 1/1| |N|Zul'Drak, Voltarus (27.17, 46.10)|
A Disclosure |QID|12710| |N|Zul'Drak, Voltarus (27.17, 46.10)|
- |QID|12710.1| |QO|Drakuru's upper chamber explored: 1/1| |N|Zul'Drak, Voltarus (27.31, 42.45)|
T Disclosure |QID|12710| |N|Zul'Drak, Voltarus (27.16, 46.10)|
- |QID|12676.3| |QO|Learn Drakuru's secret: 1/1| |N|Zul'Drak, Voltarus (27.16, 46.10)|
U |cffffffff|Hitem:41390:0:0:0:0:0:0:2053709784:79|h[Stefan's Horn]|h|r |N|Zul'Drak, Reliquary of Pain (28.01, 44.48)|
T Sabotage |QID|12676| |N|Zul'Drak, Reliquary of Pain (28.05, 44.39)|
A Betrayal |QID|12713| |N|Zul'Drak, Reliquary of Pain (28.05, 44.39)|
U |cffffffff|Hitem:37093:0:0:0:0:0:0:1043669534:79|h[Scroll of Stamina VII]|h|r |N|Zul'Drak, Reliquary of Pain (28.44, 49.00)|
- |QID|12713.1| |QO|Drakuru's Skull: 1/1| |N|Zul'Drak, Voltarus (28.64, 44.77)|
U |cffffffff|Hitem:43059:0:0:0:0:0:0:1799541079:79|h[Drakuru's Last Wish]|h|r |N|Zul'Drak, Voltarus (28.40, 44.84)|
T Betrayal |QID|12713| |N|Zul'Drak, Reliquary of Pain (27.66, 53.91)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:79|h[Hearthstone]|h|r |N|Zul'Drak, Reliquary of Pain (27.66, 53.91)|
U |cff0070dd|Hitem:39655:0:0:0:0:0:0:508099858:79|h[Betrayer's Choker]|h|r |N|Zul'Drak, The Argent Stand (40.84, 66.39)|
- |QID|12914.2| |QO|Diatomaceous Earth: 6/6| |N|,  (66.81, 43.40)|
- |QID|12914.1| |QO|Banshee Essence: 6/6| |N|,  (66.81, 43.40)|
A Hour of the Worg |QID|12164| |N|,  (66.81, 43.40)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:2125292892:79|h[Frostweave Cloth]|h|r |N|Zul'Drak, The Argent Stand (40.89, 65.64)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:2039200092:79|h[Frostweave Cloth]|h|r |N|Zul'Drak, The Argent Stand (40.89, 65.64)|
T Gymer's Salvation |QID|12914| |N|Zul'Drak, Crusader Forward Camp (25.33, 63.93)|
A Our Only Hope |QID|12916| |N|Zul'Drak, Crusader Forward Camp (25.33, 63.93)|
- |QID|12916.1| |QO|Scourge Enclosure Blown Up: 1/1| |N|Zul'Drak, Thrym's End (20.18, 56.66)|
T Our Only Hope |QID|12916| |N|Zul'Drak, Thrym's End (19.97, 56.60)|
A The Storm King's Vengeance |QID|12919| |N|Zul'Drak, Thrym's End (19.97, 56.60)|
- |QID|12919.2| |QO|Algar the Chosen slain: 1/1| |N|Zul'Drak, Reliquary of Pain (27.42, 50.77)|
- |QID|12919.4| |QO|Prince Navarius slain: 1/1| |N|Zul'Drak, The Dead Fields (32.22, 63.94)|
- |QID|12919.1| |QO|Scourge slain: 100/100| |N|Zul'Drak, The Dead Fields (32.11, 62.50)|
- |QID|12919.3| |QO|Thrym slain: 1/1| |N|Zul'Drak, The Dead Fields (31.07, 61.54)|
T The Storm King's Vengeance |QID|12919| |N|Zul'Drak, Crusader Forward Camp (25.33, 64.03)|
T Taking a Stand |QID|12795| |N|Zul'Drak, The Argent Stand (39.43, 66.87)|
A Defend the Stand |QID|12503| |N|Zul'Drak, The Argent Stand (39.43, 66.87)|
A Parachutes for the Argent Crusade |QID|12740| |N|Zul'Drak, The Argent Stand (39.43, 66.87)|
- |QID|12565.1| |QO|Drakkari Offerings: 10/10| |N|Zul'Drak, The Argent Stand (40.60, 65.71)|
A The Blessing of Zim'Abwa |QID|12565| |N|Zul'Drak, The Argent Stand (40.60, 65.71)|
U |cffffffff|Hitem:4401:0:0:0:0:0:0:1517741930:79|h[Mechanical Squirrel Box]|h|r |N|Zul'Drak, The Argent Stand (40.86, 65.78)|
U |cffffffff|Hitem:19462:0:0:0:0:0:0:684638462:79|h[Unhatched Jubling Egg]|h|r |N|Zul'Drak, The Argent Stand (40.86, 65.78)|
U |cffffffff|Hitem:19450:0:0:0:0:0:0:166036560:79|h[A Jubling's Tiny Home]|h|r |N|Zul'Drak, The Argent Stand (40.86, 65.78)|
- |QID|12740.1| |QO|Argent forces equipped with a parachute: 10/10| |N|Zul'Drak, The Argent Stand (37.49, 65.84)|
- |QID|12503.1| |QO|Scourge at The Argent Stand destroyed: 10/10| |N|Zul'Drak, The Argent Stand (37.23, 66.60)|
T Defend the Stand |QID|12503| |N|Zul'Drak, The Argent Stand (39.48, 66.93)|
T Parachutes for the Argent Crusade |QID|12740| |N|Zul'Drak, The Argent Stand (39.48, 66.93)|
A New Orders for Sergeant Stackhammer |QID|12505| |N|Zul'Drak, The Argent Stand (40.37, 66.59)|
A Pa'Troll |QID|12596| |N|Zul'Drak, The Argent Stand (40.37, 66.59)|
A Trouble at the Altar of Sseratus |QID|12506| |N|Zul'Drak, The Argent Stand (40.60, 65.74)|
T New Orders for Sergeant Stackhammer |QID|12505| |N|Zul'Drak, Altar of Sseratus (40.46, 48.26)|
A Argent Crusade, We Are Leaving! |QID|12504| |N|Zul'Drak, Altar of Sseratus (40.46, 48.26)|
A Mopping Up |QID|12508| |N|Zul'Drak, Altar of Sseratus (40.46, 48.26)|
U |cffffffff|Hitem:38321:0:0:0:0:0:0:1346261120:79|h[Strange Mojo]|h|r |N|Zul'Drak, Altar of Sseratus (40.39, 46.67)|
A Strange Mojo |QID|12507| |N|Zul'Drak, Altar of Sseratus (40.39, 46.67)|
- |QID|12508.1| |QO|Followers of Sseratus slain: 10/10| |N|Zul'Drak, Altar of Sseratus (41.08, 45.78)|
- |QID|12504.1| |QO|Argent Soldiers told to report back to the sergeant: 10/10| |N|Zul'Drak, Altar of Sseratus (40.42, 44.89)|
- |QID|12506.1| |QO|Main building at the Altar of Sseratus investigated.| |N|Zul'Drak, Altar of Sseratus (40.39, 39.45)|
T Argent Crusade, We Are Leaving! |QID|12504| |N|Zul'Drak, Altar of Sseratus (40.44, 48.06)|
T Mopping Up |QID|12508| |N|Zul'Drak, Altar of Sseratus (40.42, 48.21)|
T Trouble at the Altar of Sseratus |QID|12506| |N|Zul'Drak, The Argent Stand (40.54, 65.52)|
T Strange Mojo |QID|12507| |N|Zul'Drak, The Argent Stand (40.54, 65.52)|
A Precious Elemental Fluids |QID|12510| |N|Zul'Drak, The Argent Stand (40.54, 65.52)|
A The Drakkari Do Not Need Water Elementals! |QID|12562| |N|Zul'Drak, The Argent Stand (40.16, 68.81)|
U |cff1eff00|Hitem:36423:0:0:0:0:0:-43:-1926234071:79|h[Posy Ring of the Soldier]|h|r |N|Zul'Drak, The Argent Stand (40.88, 65.72)|
T The Blessing of Zim'Abwa |QID|12565| |N|Zul'Drak, Zim'Abwa (36.70, 72.40)|
A Something for the Pain |QID|12597| |N|Zul'Drak, Drak'Sotra (48.69, 78.87)|
- |QID|12597.1| |QO|Mature Water-Poppy: 5/5| |N|Zul'Drak, Drak'Sotra Fields (42.07, 79.30)|
U |cffffffff|Hitem:38323:0:0:0:0:0:0:603923424:79|h[Water Elemental Link]|h|r |N|Zul'Drak, Drak'Sotra Fields (42.09, 79.51)|
U |cffffffff|Hitem:38324:0:0:0:0:0:0:731614656:79|h[Tether to the Plane of Water]|h|r |N|Zul'Drak, Drak'Sotra Fields (42.09, 79.51)|
U |cffffffff|Hitem:38323:0:0:0:0:0:0:269686560:79|h[Water Elemental Link]|h|r |N|Zul'Drak, Drak'Sotra Fields (38.38, 76.82)|
U |cffffffff|Hitem:38324:0:0:0:0:0:0:1970460160:79|h[Tether to the Plane of Water]|h|r |N|Zul'Drak, Drak'Sotra Fields (38.38, 76.82)|
U |cffffffff|Hitem:38323:0:0:0:0:0:0:1353460736:79|h[Water Elemental Link]|h|r |N|Zul'Drak, Drak'Sotra Fields (40.53, 76.43)|
U |cffffffff|Hitem:38324:0:0:0:0:0:0:768233152:79|h[Tether to the Plane of Water]|h|r |N|Zul'Drak, Drak'Sotra Fields (40.53, 76.43)|
- |QID|12510.1| |QO|Precious Elemental Fluids: 3/3| |N|Zul'Drak, Drak'Sotra Fields (40.50, 76.34)|
- |QID|12562.1| |QO|Drakkari Water Binder slain: 10/10| |N|Zul'Drak, Drak'Sotra Fields (41.45, 76.50)|
T Something for the Pain |QID|12597| |N|Zul'Drak, Drak'Sotra (48.69, 78.87)|
- |QID|12596.1| |QO|Captain Brandon's Task: 1/1| |N|Zul'Drak, Drak'Sotra (48.69, 78.87)|
A Throwing Down |QID|12598| |N|Zul'Drak, Drak'Sotra (58.00, 72.53)|
A Leave No One Behind |QID|12512| |N|Zul'Drak, Drak'Sotra (58.60, 72.42)|
- |QID|12598.1| |QO|Nerubian Tunnels Sealed: 5/5| |N|Zul'Drak, Drak'Sotra (53.57, 68.24)|
- |QID|12512.1| |QO|Saved Crusader Jonathan: 1/1| |N|Zul'Drak, Drak'Sotra (58.51, 72.56)|
- |QID|12512.2| |QO|Saved Crusader Lamoof: 1/1| |N|Zul'Drak, Drak'Sotra (58.27, 72.46)|
- |QID|12512.3| |QO|Saved Crusader Josephine: 1/1| |N|Zul'Drak, Drak'Sotra (58.12, 72.44)|
- |QID|12596.2| |QO|Captain Rupert's Task: 1/1| |N|Zul'Drak, Drak'Sotra (58.12, 72.44)|
T Throwing Down |QID|12598| |N|Zul'Drak, Drak'Sotra (58.12, 72.44)|
T Leave No One Behind |QID|12512| |N|Zul'Drak, Drak'Sotra (58.62, 72.52)|
A Skimmer Spinnerets |QID|12553| |N|Zul'Drak, Drak'Sotra (58.19, 72.13)|
A Death to the Necromagi |QID|12552| |N|Zul'Drak, Drak'Sotra (58.12, 72.09)|
A Cocooned! |QID|12606| |N|Zul'Drak, Drak'Sotra (58.07, 72.34)|
- |QID|12606.1| |QO|Freed Captive Footmen: 3/3| |N|Zul'Drak, Drak'Sotra (54.29, 67.54)|
T Cocooned! |QID|12606| |N|Zul'Drak, Drak'Sotra (58.05, 72.50)|
- |QID|12553.1| |QO|Intact Skimmer Spinneret: 5/5| |N|Zul'Drak, Kolramas (56.40, 78.04)|
- |QID|12552.1| |QO|Hath'ar Necromagus slain: 8/8| |N|Zul'Drak, Kolramas (55.23, 81.77)|
T Skimmer Spinnerets |QID|12553| |N|Zul'Drak, Drak'Sotra (58.24, 72.11)|
A Crashed Sprayer |QID|12583| |N|Zul'Drak, Drak'Sotra (58.24, 72.11)|
T Death to the Necromagi |QID|12552| |N|Zul'Drak, Drak'Sotra (58.09, 72.18)|
A Malas the Corrupter |QID|12554| |N|Zul'Drak, Drak'Sotra (58.09, 72.18)|
A Pure Evil |QID|12584| |N|Zul'Drak, Drak'Sotra (58.06, 72.33)|
- |QID|12583.1| |QO|Plague Sprayer Parts: 1/1| |N|Zul'Drak, Drak'Sotra (48.68, 75.29)|
T Crashed Sprayer |QID|12583| |N|Zul'Drak, Drak'Sotra (58.25, 72.16)|
A A Tangled Skein |QID|12555| |N|Zul'Drak, Drak'Sotra (58.25, 72.16)|
- |QID|12555.1| |QO|Plague Sprayers webbed and destroyed: 5/5| |N|Zul'Drak, Kolramas (56.92, 84.08)|
- |QID|12584.1| |QO|Chunk of Saronite: 10/10| |N|Zul'Drak, Kolramas (62.18, 78.17)|
T A Tangled Skein |QID|12555| |N|Zul'Drak, Drak'Sotra (58.19, 72.18)|
A Creature Comforts |QID|12599| |N|Zul'Drak, Drak'Agal (48.07, 63.82)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:79|h[Hearthstone]|h|r |N|Zul'Drak, Drak'Agal (48.07, 63.82)|
T Pure Evil |QID|12584| |N|Zul'Drak, The Argent Stand (40.82, 66.53)|
T Precious Elemental Fluids |QID|12510| |N|Zul'Drak, The Argent Stand (40.61, 65.71)|
A Mushroom Mixer |QID|12514| |N|Zul'Drak, The Argent Stand (40.61, 65.71)|
T The Drakkari Do Not Need Water Elementals! |QID|12562| |N|Zul'Drak, The Argent Stand (40.16, 68.80)|
A Gluttonous Lurkers |QID|12527| |N|Zul'Drak, The Argent Stand (41.31, 65.04)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:1926015616:79|h[Frostweave Cloth]|h|r |N|Zul'Drak, The Argent Stand (40.85, 65.58)|
U |cffffffff|Hitem:37705:0:0:0:0:0:0:-1749892407:79|h[Crystallized Water]|h|r |N|Zul'Drak, The Argent Stand (40.85, 65.58)|
U |cffffffff|Hitem:18256:0:0:0:0:0:0:0:79|h[Imbued Vial]|h|r |N|Zul'Drak, The Argent Stand (40.78, 66.25)|
U |cffffffff|Hitem:38380:0:0:0:0:0:0:1864621056:79|h[Zul'Drak Rat]|h|r |N|Zul'Drak, Drak'Agal (44.17, 68.22)|
- |QID|12527.1| |QO|Basilisk Crystals: 5/5| |N|Zul'Drak, Drak'Agal (41.86, 59.85)|
- |QID|12514.1| |QO|Muddlecap Fungus: 10/10| |N|Zul'Drak, Drak'Agal (41.59, 60.30)|
- |QID|12599.1| |QO|Dead Thornwood: 20/20| |N|Zul'Drak, Drak'Agal (41.55, 56.71)|
T Creature Comforts |QID|12599| |N|Zul'Drak, Drak'Agal (48.13, 63.80)|
- |QID|12596.3| |QO|Captain Grondel's Task: 1/1| |N|Zul'Drak, Drak'Agal (48.13, 63.80)|
T Mushroom Mixer |QID|12514| |N|Zul'Drak, The Argent Stand (40.56, 65.56)|
A Too Much of a Good Thing |QID|12516| |N|Zul'Drak, The Argent Stand (40.56, 65.56)|
- |QID|12596.3| |QO|Captain Grondel's Task: 1/1| |N|,  (66.81, 43.41)|
- |QID|12596.1| |QO|Captain Brandon's Task: 1/1| |N|,  (66.81, 43.41)|
- |QID|12596.2| |QO|Captain Rupert's Task: 1/1| |N|,  (66.81, 43.41)|
- |QID|12527.1| |QO|Basilisk Crystals: 5/5| |N|,  (66.81, 43.41)|
A Hour of the Worg |QID|12164| |N|,  (66.81, 43.41)|
- |QID|12516.1| |QO|Muddled Prophet of Sseratus slain: 1/1| |N|Zul'Drak, Altar of Sseratus (40.44, 42.94)|
A Siphoning the Spirits |QID|12799| |N|Zul'Drak, Heb'Valok (35.66, 52.27)|
T Gluttonous Lurkers |QID|12527| |N|Zul'Drak, Heb'Valok (35.09, 52.18)|
A Lab Work |QID|12557| |N|Zul'Drak, Heb'Valok (35.09, 52.18)|
- |QID|12557.2| |QO|Withered Batwing found: 1/1| |N|Zul'Drak, Heb'Valok (35.05, 53.32)|
- |QID|12557.4| |QO|Chilled Serpent Mucus found: 1/1| |N|Zul'Drak, Heb'Valok (35.05, 53.32)|
- |QID|12557.1| |QO|Muddy Mire Maggot found: 1/1| |N|Zul'Drak, Heb'Valok (34.93, 53.23)|
- |QID|12557.3| |QO|Amberseed found: 1/1| |N|Zul'Drak, Heb'Valok (34.77, 51.24)|
- |QID|12596.4| |QO|Alchemist Finklestein's Task: 1/1| |N|Zul'Drak, Heb'Valok (35.08, 52.13)|
T Lab Work |QID|12557| |N|Zul'Drak, Heb'Valok (35.08, 52.13)|
- |QID|12799.1| |QO|Ancient Ectoplasm: 5/5| |N|Zul'Drak, Pools of Zha'Jin (35.82, 60.60)|
T Siphoning the Spirits |QID|12799| |N|Zul'Drak, Heb'Valok (35.57, 52.26)|
A Stocking the Shelves |QID|12609| |N|Zul'Drak, Heb'Valok (35.57, 52.26)|
A Clipping Their Wings |QID|12610| |N|Zul'Drak, Heb'Valok (35.57, 52.26)|
- |QID|12609.1| |QO|Fresh Spider Ichor: 7/7| |N|Zul'Drak, Heb'Valok (36.31, 57.47)|
- |QID|12610.1| |QO|Unblemished Bat Wing: 7/7| |N|Zul'Drak, Heb'Valok (37.14, 52.66)|
T Stocking the Shelves |QID|12609| |N|Zul'Drak, Heb'Valok (35.66, 52.27)|
T Clipping Their Wings |QID|12610| |N|Zul'Drak, Heb'Valok (35.66, 52.27)|
T Too Much of a Good Thing |QID|12516| |N|Zul'Drak, The Argent Stand (40.59, 65.63)|
A To the Witch Doctor |QID|12623| |N|Zul'Drak, The Argent Stand (40.59, 65.63)|
T Pa'Troll |QID|12596| |N|Zul'Drak, The Argent Stand (40.35, 66.57)|
A Troll Patrol |QID|12587| |N|Zul'Drak, The Argent Stand (40.35, 66.57)|
- |QID|12554.1| |QO|Head of the Corrupter: 1/1| |N|Zul'Drak, Kolramas (61.09, 77.86)|
T Malas the Corrupter |QID|12554| |N|Zul'Drak, Drak'Sotra (58.04, 72.10)|
T Head Games |QID|13129| |N|Grizzly Hills, Granite Springs (16.65, 48.17)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:79|h[Hearthstone]|h|r |N|Grizzly Hills, Granite Springs (16.65, 48.17)|
A Troll Patrol: Can You Dig It? |QID|12588| |N|Zul'Drak, Drak'Sotra (48.72, 78.94)|
- |QID|12588.1| |QO|Ancient Dirt Mounds Investigtated: 5/5| |N|Zul'Drak,  (45.56, 81.56)|
- |QID|12587.1| |QO|Captain Brandon's Task: 1/1| |N|Zul'Drak, Drak'Sotra (48.69, 78.89)|
T Troll Patrol: Can You Dig It? |QID|12588| |N|Zul'Drak, Drak'Sotra (48.69, 78.89)|
A Troll Patrol: Throwing Down |QID|12591| |N|Zul'Drak, Drak'Sotra (58.04, 72.50)|
- |QID|12591.1| |QO|Nerubian Tunnels Collapsed: 5/5| |N|Zul'Drak, Drak'Sotra (54.82, 70.75)|
T Troll Patrol: Throwing Down |QID|12591| |N|Zul'Drak, Drak'Sotra (58.04, 72.52)|
- |QID|12587.2| |QO|Captain Rupert's Task: 1/1| |N|Zul'Drak, Drak'Sotra (58.04, 72.52)|
A Troll Patrol: Couldn't Care Less |QID|12594| |N|Zul'Drak, Drak'Agal (48.07, 63.84)|
- |QID|12594.1| |QO|Mossy Rampagers Slain: 7/7| |N|Zul'Drak, Drak'Agal (43.29, 61.01)|
T Troll Patrol: Couldn't Care Less |QID|12594| |N|Zul'Drak, Drak'Agal (48.13, 63.79)|
- |QID|12587.3| |QO|Captain Grondel's Task: 1/1| |N|Zul'Drak, Drak'Agal (48.13, 63.79)|
A Troll Patrol: The Alchemist's Apprentice |QID|12541| |N|Zul'Drak, Heb'Valok (35.09, 52.14)|
- |QID|12541.1| |QO|Truth Serum Created: 1/1| |N|Zul'Drak, Heb'Valok (35.11, 52.08)|
T Troll Patrol: The Alchemist's Apprentice |QID|12541| |N|Zul'Drak, Heb'Valok (35.07, 52.19)|
- |QID|12587.4| |QO|Alchemist Finklestein's Task: 1/1| |N|Zul'Drak, Heb'Valok (35.07, 52.19)|
T Troll Patrol |QID|12587| |N|Zul'Drak, The Argent Stand (40.35, 66.67)|
T To the Witch Doctor |QID|12623| |N|Zul'Drak, Zim'Torga (59.45, 57.93)|
A Breaking Through Jin'Alai |QID|12627| |N|Zul'Drak, Zim'Torga (59.45, 57.93)|
- |QID|12615.1| |QO|Drakkari Offerings: 10/10| |N|Zul'Drak, Zim'Torga (59.45, 57.93)|
A The Blessing of Zim'Torga |QID|12615| |N|Zul'Drak, Zim'Torga (59.45, 57.93)|
A Just Checkin' |QID|13099| |N|Zul'Drak, Zim'Torga (59.89, 57.86)|
A The Leaders at Jin'Alai |QID|12622| |N|Zul'Drak, Zim'Torga (59.17, 56.32)|
T The Blessing of Zim'Torga |QID|12615| |N|Zul'Drak, Zim'Torga (59.41, 57.20)|
U |cffa335ee|Hitem:41168:0:0:0:0:0:0:414807004:80|h[Armor Plated Combat Shotgun]|h|r |N|Zul'Drak, Zim'Torga (59.41, 57.20)|
A Where in the World is Hemet Nesingwary? |QID|12521| |N|Dalaran, Krasus' Landing (68.65, 43.01)|
U |cffa335ee|Hitem:41392:0:0:0:0:0:0:1259951414:80|h[Tempered Titansteel Treads]|h|r |N|Dalaran, Dalaran Merchant's Bank (41.87, 75.59)|
U |cffffffff|Hitem:43463:0:0:0:0:0:0:1187344064:80|h[Scroll of Agility VII]|h|r |N|Dalaran, Dalaran Merchant's Bank (41.86, 75.47)|
U |cff9d9d9d|Hitem:18365:0:0:0:0:0:0:1957875390:80|h[A Thoroughly Read Copy of \"Nat Pagle's Extreme' Anglin.\"]|h|r |N|Dalaran, Dalaran Merchant's Bank (42.09, 79.01)|
U |cffffffff|Hitem:42253:0:0:0:0:0:0:-1548120320:80|h[Iceweb Spider Silk]|h|r |N|Dalaran, The Eventide (45.21, 68.47)|
U |cff1eff00|Hitem:35622:0:0:0:0:0:0:1797198208:80|h[Eternal Water]|h|r |N|Dalaran, The Eventide (45.21, 68.47)|
U |cffffffff|Hitem:37700:0:0:0:0:0:0:-1901873128:80|h[Crystallized Air]|h|r |N|Dalaran, The Eventide (45.21, 68.47)|
U |cffffffff|Hitem:37705:0:0:0:0:0:0:-1749892407:80|h[Crystallized Water]|h|r |N|Dalaran, The Eventide (45.21, 68.47)|
U |cffffffff|Hitem:37701:0:0:0:0:0:0:1859613110:80|h[Crystallized Earth]|h|r |N|Dalaran, The Eventide (45.21, 68.47)|
U |cffffffff|Hitem:37704:0:0:0:0:0:0:1158898944:80|h[Crystallized Life]|h|r |N|Dalaran, The Eventide (45.21, 68.47)|
U |cffffffff|Hitem:23445:0:0:0:0:0:0:390431680:80|h[Fel Iron Bar]|h|r |N|Dalaran, The Eventide (45.21, 68.47)|
U |cffffffff|Hitem:18300:0:0:0:0:0:0:-2062500736:80|h[Hyjal Nectar]|h|r |N|Dalaran, The Eventide (45.21, 68.47)|
U |cffffffff|Hitem:41426:0:0:0:0:0:0:1619921664:80|h[Magically Wrapped Gift]|h|r |N|Dalaran, The Eventide (45.21, 68.47)|
U |cff0070dd|Hitem:37646:0:0:0:0:0:0:1717639828:80|h[Burning Skull Pendant]|h|r |N|Dalaran, The Eventide (46.81, 68.01)|
U |cff0070dd|Hitem:37197:0:0:0:0:0:0:1094109982:80|h[Tattered Castle Drape]|h|r |N|Dalaran, The Eventide (46.81, 68.01)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Thunder Bluff, Hunter Rise (60.89, 79.91)|
U |cffa335ee|Hitem:41387:0:0:0:0:0:0:1687764480:80|h[Tempered Titansteel Helm]|h|r |N|Silvermoon City,  (89.89, 43.22)|
U |cffa335ee|Hitem:42508:3849:0:0:0:0:0:235302592:80|h[Titansteel Shield Wall]|h|r |N|Silvermoon City,  (89.89, 43.22)|
U |cffffffff|Hitem:29957:0:0:0:0:0:0:0:80|h[Silver Dragonhawk Hatchling]|h|r |N|Eversong Woods, Fairbreeze Village (44.85, 71.78)|
U |cffffffff|Hitem:29956:0:0:0:0:0:0:0:80|h[Red Dragonhawk Hatchling]|h|r |N|Eversong Woods, Fairbreeze Village (44.85, 71.78)|
U |cffffffff|Hitem:29953:0:0:0:0:0:0:0:80|h[Golden Dragonhawk Hatchling]|h|r |N|Eversong Woods, Fairbreeze Village (44.85, 71.78)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:494315392:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:797941760:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:1692330368:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:134226176:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:1300133888:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:346394656:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:2084189184:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:1998343936:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:1750923264:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:211196912:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25439:0:0:0:0:0:0:1396605824:80|h[Tigerseye Band]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25438:0:0:0:0:0:0:2010765440:80|h[Malachite Pendant]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25438:0:0:0:0:0:0:1180014464:80|h[Malachite Pendant]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25438:0:0:0:0:0:0:1164544768:80|h[Malachite Pendant]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25438:0:0:0:0:0:0:599024832:80|h[Malachite Pendant]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25438:0:0:0:0:0:0:1680757504:80|h[Malachite Pendant]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25438:0:0:0:0:0:0:1154542208:80|h[Malachite Pendant]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cff1eff00|Hitem:25438:0:0:0:0:0:0:1288883968:80|h[Malachite Pendant]|h|r |N|Silvermoon City, The Royal Exchange (83.07, 66.01)|
U |cffffffff|Hitem:2840:0:0:0:0:0:0:1175674368:80|h[Copper Bar]|h|r |N|Silvermoon City, The Royal Exchange (87.82, 51.42)|
U |cffffffff|Hitem:2840:0:0:0:0:0:0:1591755392:80|h[Copper Bar]|h|r |N|Silvermoon City, The Royal Exchange (87.82, 51.42)|
U |cffffffff|Hitem:2840:0:0:0:0:0:0:279599904:80|h[Copper Bar]|h|r |N|Silvermoon City, The Royal Exchange (87.82, 51.42)|
U |cffffffff|Hitem:2840:0:0:0:0:0:0:1449629568:80|h[Copper Bar]|h|r |N|Silvermoon City, The Royal Exchange (87.82, 51.42)|
U |cffffffff|Hitem:2840:0:0:0:0:0:0:1646114816:80|h[Copper Bar]|h|r |N|Silvermoon City, The Royal Exchange (87.82, 51.42)|
U |cffffffff|Hitem:2835:0:0:0:0:0:0:-1883405184:80|h[Rough Stone]|h|r |N|Silvermoon City, The Royal Exchange (88.14, 50.93)|
U |cffffffff|Hitem:2589:0:0:0:0:0:0:1477297024:80|h[Linen Cloth]|h|r |N|Silvermoon City, The Royal Exchange (88.14, 50.93)|
U |cff1eff00|Hitem:774:0:0:0:0:0:0:-1982785146:80|h[Malachite]|h|r |N|Silvermoon City, The Royal Exchange (88.14, 50.93)|
U |cff1eff00|Hitem:20823:0:0:0:0:0:0:1325078272:80|h[Gloom Band]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20823:0:0:0:0:0:0:2134248448:80|h[Gloom Band]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20823:0:0:0:0:0:0:1159009280:80|h[Gloom Band]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20823:0:0:0:0:0:0:450758080:80|h[Gloom Band]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20823:0:0:0:0:0:0:483962592:80|h[Gloom Band]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20823:0:0:0:0:0:0:880066304:80|h[Gloom Band]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:1795553152:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:1270827392:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:274290048:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:864758592:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:852143040:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:1720609280:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:1315770496:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:282685856:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:923084928:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:1185584640:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:853044992:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:1988552192:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:1506058496:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:116628768:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:932919168:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:562367744:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.15, 50.68)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:1002056064:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:1166309760:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:764443584:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20827:0:0:0:0:0:0:486353984:80|h[Ring of Silver Might]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:1795498240:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:2105028864:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:2050523008:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:391112480:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:2003219456:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:330362304:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:1228087552:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:19000104:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:669609152:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:1488524160:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cff1eff00|Hitem:20828:0:0:0:0:0:0:1485022720:80|h[Ring of Twilight Shadows]|h|r |N|Silvermoon City, The Royal Exchange (88.03, 51.33)|
U |cffffffff|Hitem:20970:0:0:0:0:0:0:0:80|h[Design: Pendant of the Agate Shield]|h|r |N|Silvermoon City, The Royal Exchange (88.19, 50.48)|
U |cffffffff|Hitem:11023:0:0:0:0:0:0:0:80|h[Ancona Chicken]|h|r |N|Silvermoon City, The Royal Exchange (88.19, 50.48)|
U |cff1eff00|Hitem:30420:0:0:0:0:0:0:2085908736:80|h[Heavy Jade Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.18, 50.55)|
U |cff1eff00|Hitem:30420:0:0:0:0:0:0:2057927424:80|h[Heavy Jade Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.18, 50.55)|
U |cff1eff00|Hitem:30420:0:0:0:0:0:0:168440272:80|h[Heavy Jade Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.18, 50.55)|
U |cff1eff00|Hitem:30420:0:0:0:0:0:0:1630435712:80|h[Heavy Jade Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.18, 50.55)|
U |cff1eff00|Hitem:30420:0:0:0:0:0:0:236815040:80|h[Heavy Jade Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.18, 50.55)|
U |cff1eff00|Hitem:20950:0:0:0:0:0:0:220134592:80|h[Pendant of the Agate Shield]|h|r |N|Silvermoon City, The Royal Exchange (88.18, 50.55)|
U |cff1eff00|Hitem:20950:0:0:0:0:0:0:697651264:80|h[Pendant of the Agate Shield]|h|r |N|Silvermoon City, The Royal Exchange (88.18, 50.55)|
U |cff1eff00|Hitem:20950:0:0:0:0:0:0:924128832:80|h[Pendant of the Agate Shield]|h|r |N|Silvermoon City, The Royal Exchange (88.18, 50.55)|
U |cff1eff00|Hitem:20950:0:0:0:0:0:0:2110295168:80|h[Pendant of the Agate Shield]|h|r |N|Silvermoon City, The Royal Exchange (88.18, 50.55)|
U |cff1eff00|Hitem:30420:0:0:0:0:0:0:883678016:80|h[Heavy Jade Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.18, 50.55)|
U |cff1eff00|Hitem:20950:0:0:0:0:0:0:1175882496:80|h[Pendant of the Agate Shield]|h|r |N|Silvermoon City, The Royal Exchange (88.20, 51.21)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:1393859328:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.92, 51.17)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:1144581632:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.92, 51.17)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:1975096832:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.92, 51.17)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:126524224:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.92, 51.17)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:2072468480:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.92, 51.17)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:1837168000:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.92, 51.17)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:541323840:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.92, 51.17)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:2117069568:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.92, 51.17)|
U |cffffffff|Hitem:2836:0:0:0:0:0:0:-2081893047:80|h[Coarse Stone]|h|r |N|Silvermoon City,  (89.22, 42.97)|
U |cffffffff|Hitem:2835:0:0:0:0:0:0:1199848902:80|h[Rough Stone]|h|r |N|Silvermoon City,  (89.22, 42.97)|
U |cffffffff|Hitem:2835:0:0:0:0:0:0:2067916630:80|h[Rough Stone]|h|r |N|Silvermoon City,  (89.22, 42.97)|
U |cffffffff|Hitem:2835:0:0:0:0:0:0:711929196:80|h[Rough Stone]|h|r |N|Silvermoon City,  (89.22, 42.97)|
U |cffffffff|Hitem:2835:0:0:0:0:0:0:1693163888:80|h[Rough Stone]|h|r |N|Silvermoon City,  (89.22, 42.97)|
U |cffffffff|Hitem:2589:0:0:0:0:0:0:1281288096:80|h[Linen Cloth]|h|r |N|Silvermoon City,  (89.22, 42.97)|
U |cffffffff|Hitem:2589:0:0:0:0:0:0:1678008042:80|h[Linen Cloth]|h|r |N|Silvermoon City,  (89.22, 42.97)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:501734784:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.70, 51.38)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:1765797248:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.70, 51.38)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:1535985280:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.70, 51.38)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:881613824:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.70, 51.38)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:1662866816:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.70, 51.38)|
U |cff1eff00|Hitem:20955:0:0:0:0:0:0:889117824:80|h[Golden Dragon Ring]|h|r |N|Silvermoon City, The Royal Exchange (87.70, 51.38)|
U |cffffffff|Hitem:20973:0:0:0:0:0:0:0:80|h[Design: Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.34, 51.04)|
U |cff1eff00|Hitem:20958:0:0:0:0:0:0:1826861952:80|h[Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.54)|
U |cff1eff00|Hitem:20958:0:0:0:0:0:0:1197647616:80|h[Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.54)|
U |cff1eff00|Hitem:20958:0:0:0:0:0:0:1467062400:80|h[Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.54)|
U |cff1eff00|Hitem:20958:0:0:0:0:0:0:988153152:80|h[Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.54)|
U |cff1eff00|Hitem:20958:0:0:0:0:0:0:1607373952:80|h[Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.54)|
U |cff1eff00|Hitem:20958:0:0:0:0:0:0:767167424:80|h[Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.54)|
U |cff1eff00|Hitem:20958:0:0:0:0:0:0:367576832:80|h[Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.54)|
U |cff1eff00|Hitem:20958:0:0:0:0:0:0:849284672:80|h[Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.54)|
U |cffffffff|Hitem:20975:0:0:0:0:0:0:0:80|h[Design: The Jade Eye]|h|r |N|Silvermoon City,  (90.71, 73.66)|
U |cff1eff00|Hitem:20958:0:0:0:0:0:0:725740096:80|h[Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 50.52)|
U |cff1eff00|Hitem:20958:0:0:0:0:0:0:33248000:80|h[Blazing Citrine Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 50.52)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:629123264:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 50.52)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:1565781504:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 50.52)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:482208256:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 50.52)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:2111564416:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 50.52)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:295438400:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 50.52)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:370414432:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 50.52)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:2032378624:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.26, 51.08)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:1904152192:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.26, 51.08)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:904357376:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.26, 51.08)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:1658474880:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.26, 51.08)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:2111755776:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.26, 51.08)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:777201664:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 50.99)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:1755537536:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 50.99)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:1583726592:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 50.99)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:119422288:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 50.99)|
U |cff1eff00|Hitem:20960:0:0:0:0:0:0:1183669376:80|h[Engraved Truesilver Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 50.99)|
U |cffffffff|Hitem:29903:0:0:0:0:0:0:0:80|h[Yellow Moth Egg]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 50.99)|
U |cffffffff|Hitem:29904:0:0:0:0:0:0:0:80|h[White Moth Egg]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 50.99)|
U |cffffffff|Hitem:29901:0:0:0:0:0:0:0:80|h[Blue Moth Egg]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 50.99)|
U |cffffffff|Hitem:15407:0:0:0:0:0:0:1131220736:80|h[Cured Rugged Hide]|h|r |N|Silvermoon City, The Royal Exchange (88.25, 51.10)|
U |cffffffff|Hitem:7079:0:0:0:0:0:0:992251974:80|h[Globe of Water]|h|r |N|Silvermoon City, The Royal Exchange (88.25, 51.10)|
U |cffffffff|Hitem:10558:0:0:0:0:0:0:1635459597:80|h[Gold Power Core]|h|r |N|Silvermoon City, The Royal Exchange (88.25, 51.10)|
U |cffffffff|Hitem:15994:0:0:0:0:0:0:1483968000:80|h[Thorium Widget]|h|r |N|Silvermoon City, The Royal Exchange (88.25, 51.10)|
U |cffffffff|Hitem:18631:0:0:0:0:0:0:524872733:80|h[Truesilver Transformer]|h|r |N|Silvermoon City, The Royal Exchange (88.25, 51.10)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:1808259968:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 51.21)|
U |cff1eff00|Hitem:20961:0:0:0:0:0:0:1965719936:80|h[Citrine Ring of Rapid Healing]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 51.21)|
U |cffffffff|Hitem:21277:0:0:0:0:0:0:1918108672:80|h[Tranquil Mechanical Yeti]|h|r |N|Silvermoon City, The Royal Exchange (88.13, 51.09)|
U |cffffffff|Hitem:2841:0:0:0:0:0:0:252990624:80|h[Bronze Bar]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cffffffff|Hitem:3576:0:0:0:0:0:0:1275409152:80|h[Tin Bar]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cffffffff|Hitem:3576:0:0:0:0:0:0:24715260:80|h[Tin Bar]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cffffffff|Hitem:2770:0:0:0:0:0:0:295795161:80|h[Copper Ore]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:576467008:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:69364296:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:702898368:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:315616704:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:1113036288:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:1608541184:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:149641648:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:893490752:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:584223040:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:267026944:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:1281931904:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:43563000:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:578759232:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff1eff00|Hitem:20959:0:0:0:0:0:0:1814500736:80|h[The Jade Eye]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.99)|
U |cff0070dd|Hitem:20964:0:0:0:0:0:517:394897888:80|h[Aquamarine Signet of the Wolf]|h|r |N|Silvermoon City, The Royal Exchange (88.27, 51.23)|
U |cff0070dd|Hitem:20964:0:0:0:0:0:2115:1325522816:80|h[Aquamarine Signet of Regeneration]|h|r |N|Silvermoon City, The Royal Exchange (88.27, 51.23)|
U |cff0070dd|Hitem:20964:0:0:0:0:0:1197:1079750912:80|h[Aquamarine Signet of the Bear]|h|r |N|Silvermoon City, The Royal Exchange (88.27, 51.23)|
U |cff0070dd|Hitem:20964:0:0:0:0:0:518:768464832:80|h[Aquamarine Signet of the Wolf]|h|r |N|Silvermoon City, The Royal Exchange (88.27, 51.23)|
U |cff0070dd|Hitem:20964:0:0:0:0:0:857:1933500800:80|h[Aquamarine Signet of the Eagle]|h|r |N|Silvermoon City, The Royal Exchange (88.27, 51.23)|
U |cff0070dd|Hitem:20964:0:0:0:0:0:602:1768693120:80|h[Aquamarine Signet of the Monkey]|h|r |N|Silvermoon City, The Royal Exchange (88.27, 51.23)|
U |cff0070dd|Hitem:20964:0:0:0:0:0:603:29688054:80|h[Aquamarine Signet of the Monkey]|h|r |N|Silvermoon City, The Royal Exchange (88.27, 51.23)|
U |cff1eff00|Hitem:21755:0:0:0:0:0:0:930833856:80|h[Aquamarine Pendant of the Warrior]|h|r |N|Silvermoon City, The Royal Exchange (88.09, 51.31)|
U |cff1eff00|Hitem:21755:0:0:0:0:0:0:1400921984:80|h[Aquamarine Pendant of the Warrior]|h|r |N|Silvermoon City, The Royal Exchange (88.09, 51.31)|
U |cff1eff00|Hitem:21755:0:0:0:0:0:0:640811840:80|h[Aquamarine Pendant of the Warrior]|h|r |N|Silvermoon City, The Royal Exchange (88.09, 51.31)|
U |cff1eff00|Hitem:21755:0:0:0:0:0:0:953532288:80|h[Aquamarine Pendant of the Warrior]|h|r |N|Silvermoon City, The Royal Exchange (88.09, 51.31)|
U |cff1eff00|Hitem:21755:0:0:0:0:0:0:510144864:80|h[Aquamarine Pendant of the Warrior]|h|r |N|Silvermoon City, The Royal Exchange (88.09, 51.31)|
U |cffffffff|Hitem:20817:0:0:0:0:0:0:1897584000:80|h[Bronze Setting]|h|r |N|Silvermoon City, The Royal Exchange (88.00, 51.35)|
U |cffffffff|Hitem:20817:0:0:0:0:0:0:200272608:80|h[Bronze Setting]|h|r |N|Silvermoon City, The Royal Exchange (88.00, 51.35)|
U |cffffffff|Hitem:20817:0:0:0:0:0:0:1535376128:80|h[Bronze Setting]|h|r |N|Silvermoon City, The Royal Exchange (88.00, 51.35)|
U |cff1eff00|Hitem:3864:0:0:0:0:0:0:1799960085:80|h[Citrine]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 51.19)|
U |cff1eff00|Hitem:1529:0:0:0:0:0:0:1132706732:80|h[Jade]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 51.19)|
U |cff1eff00|Hitem:3864:0:0:0:0:0:0:-2061916815:80|h[Citrine]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 51.19)|
U |cffffffff|Hitem:7067:0:0:0:0:0:0:-1582486112:80|h[Elemental Earth]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 51.19)|
U |cffffffff|Hitem:8151:0:0:0:0:0:0:-1683686490:80|h[Flask of Mojo]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 51.19)|
U |cff1eff00|Hitem:21764:0:0:0:0:0:0:1205802240:80|h[Ruby Pendant of Fire]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:21764:0:0:0:0:0:0:177607104:80|h[Ruby Pendant of Fire]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:21764:0:0:0:0:0:0:678105600:80|h[Ruby Pendant of Fire]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:21764:0:0:0:0:0:0:2023324800:80|h[Ruby Pendant of Fire]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:21764:0:0:0:0:0:0:6108063:80|h[Ruby Pendant of Fire]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:21764:0:0:0:0:0:0:1876363136:80|h[Ruby Pendant of Fire]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:21764:0:0:0:0:0:0:275134048:80|h[Ruby Pendant of Fire]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:21764:0:0:0:0:0:0:1931230848:80|h[Ruby Pendant of Fire]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:21764:0:0:0:0:0:0:644188032:80|h[Ruby Pendant of Fire]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:21764:0:0:0:0:0:0:600276096:80|h[Ruby Pendant of Fire]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:1652584576:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:1205275648:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:1622257152:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:1513918208:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:1370854016:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:1254533376:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:609328384:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:1957568896:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:1955369344:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:2089851136:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 50.36)|
U |cff1eff00|Hitem:21765:0:0:0:0:0:0:2123017472:80|h[Truesilver Healing Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 51.13)|
U |cff1eff00|Hitem:21765:0:0:0:0:0:0:273108128:80|h[Truesilver Healing Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 51.13)|
U |cff1eff00|Hitem:21765:0:0:0:0:0:0:2102323328:80|h[Truesilver Healing Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 51.13)|
U |cff1eff00|Hitem:21765:0:0:0:0:0:0:447360768:80|h[Truesilver Healing Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.24, 51.13)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:928044800:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.15)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:567916928:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.15)|
U |cff1eff00|Hitem:30421:0:0:0:0:0:0:554521472:80|h[Red Ring of Destruction]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.15)|
U |cff1eff00|Hitem:30422:0:0:0:0:0:0:1059418112:80|h[Diamond Focus Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.19, 51.29)|
U |cff1eff00|Hitem:30422:0:0:0:0:0:0:1739983104:80|h[Diamond Focus Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.19, 51.29)|
U |cff1eff00|Hitem:21767:0:0:0:0:0:0:1349946240:80|h[Simple Opal Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.09)|
U |cff1eff00|Hitem:21767:0:0:0:0:0:0:578575872:80|h[Simple Opal Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.09)|
U |cff1eff00|Hitem:21767:0:0:0:0:0:0:1108930048:80|h[Simple Opal Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.09)|
U |cff1eff00|Hitem:21767:0:0:0:0:0:0:887857280:80|h[Simple Opal Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.09)|
U |cff1eff00|Hitem:21767:0:0:0:0:0:0:1904880000:80|h[Simple Opal Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.09)|
U |cff1eff00|Hitem:21767:0:0:0:0:0:0:1891150080:80|h[Simple Opal Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.09)|
U |cff1eff00|Hitem:21767:0:0:0:0:0:0:237325008:80|h[Simple Opal Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.09)|
U |cff1eff00|Hitem:21767:0:0:0:0:0:0:1727259392:80|h[Simple Opal Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.09)|
U |cff1eff00|Hitem:30422:0:0:0:0:0:0:543117632:80|h[Diamond Focus Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.09)|
U |cff1eff00|Hitem:30422:0:0:0:0:0:0:410759872:80|h[Diamond Focus Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.09)|
U |cff1eff00|Hitem:21790:0:0:0:0:0:0:45904672:80|h[Sapphire Pendant of Winter Night]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 51.24)|
U |cff1eff00|Hitem:21790:0:0:0:0:0:0:154232528:80|h[Sapphire Pendant of Winter Night]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 51.24)|
U |cff1eff00|Hitem:21790:0:0:0:0:0:0:1324944000:80|h[Sapphire Pendant of Winter Night]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 51.24)|
U |cff1eff00|Hitem:21790:0:0:0:0:0:0:1993435904:80|h[Sapphire Pendant of Winter Night]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 51.24)|
U |cff1eff00|Hitem:21790:0:0:0:0:0:0:1819770624:80|h[Sapphire Pendant of Winter Night]|h|r |N|Silvermoon City, The Royal Exchange (88.23, 51.24)|
U |cff1eff00|Hitem:21790:0:0:0:0:0:0:1933309312:80|h[Sapphire Pendant of Winter Night]|h|r |N|Silvermoon City, The Royal Exchange (88.04, 51.36)|
U |cff1eff00|Hitem:21790:0:0:0:0:0:0:1275356800:80|h[Sapphire Pendant of Winter Night]|h|r |N|Silvermoon City, The Royal Exchange (88.04, 51.36)|
U |cff1eff00|Hitem:21790:0:0:0:0:0:0:1702617472:80|h[Sapphire Pendant of Winter Night]|h|r |N|Silvermoon City, The Royal Exchange (88.04, 51.36)|
U |cff1eff00|Hitem:21790:0:0:0:0:0:0:669943104:80|h[Sapphire Pendant of Winter Night]|h|r |N|Silvermoon City, The Royal Exchange (88.04, 51.36)|
U |cffffffff|Hitem:2770:0:0:0:0:0:0:1281965680:80|h[Copper Ore]|h|r |N|Silvermoon City, The Royal Exchange (88.04, 51.36)|
U |cffffffff|Hitem:2770:0:0:0:0:0:0:747732726:80|h[Copper Ore]|h|r |N|Silvermoon City, The Royal Exchange (88.04, 51.36)|
U |cff1eff00|Hitem:21775:0:0:0:0:0:0:989537472:80|h[Onslaught Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.96)|
U |cff1eff00|Hitem:21775:0:0:0:0:0:0:734847616:80|h[Onslaught Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.96)|
U |cff1eff00|Hitem:21775:0:0:0:0:0:0:1075744512:80|h[Onslaught Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.96)|
U |cff1eff00|Hitem:21775:0:0:0:0:0:0:254914816:80|h[Onslaught Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.96)|
U |cff1eff00|Hitem:21775:0:0:0:0:0:0:555926976:80|h[Onslaught Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.96)|
U |cff1eff00|Hitem:21775:0:0:0:0:0:0:761340032:80|h[Onslaught Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.96)|
U |cff1eff00|Hitem:21790:0:0:0:0:0:0:1517605120:80|h[Sapphire Pendant of Winter Night]|h|r |N|Silvermoon City, The Royal Exchange (88.21, 50.96)|
U |cff1eff00|Hitem:21775:0:0:0:0:0:0:847411264:80|h[Onslaught Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.19, 51.09)|
U |cff1eff00|Hitem:21775:0:0:0:0:0:0:775644544:80|h[Onslaught Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.19, 51.09)|
U |cff1eff00|Hitem:29160:0:0:0:0:0:0:901775488:80|h[Emerald Lion Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.20)|
U |cff1eff00|Hitem:29160:0:0:0:0:0:0:1262845312:80|h[Emerald Lion Ring]|h|r |N|Silvermoon City, The Royal Exchange (88.22, 51.20)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Silvermoon City, The Royal Exchange (84.90, 51.27)|
U |cff0070dd|Hitem:39973:0:0:0:0:0:0:0:80|h[Ghostly Skull]|h|r |N|Dalaran, The Black Market (63.31, 16.18)|
U |cff1eff00|Hitem:23094:0:0:0:0:0:0:1672735872:80|h[Teardrop Blood Garnet]|h|r |N|Hellfire Peninsula, Thrallmar (56.43, 37.89)|
U |cff1eff00|Hitem:23108:0:0:0:0:0:0:876320960:80|h[Glowing Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.43, 37.89)|
U |cff1eff00|Hitem:23103:0:0:0:0:0:0:1530972544:80|h[Radiant Deep Peridot]|h|r |N|Hellfire Peninsula, Thrallmar (56.43, 37.89)|
U |cff1eff00|Hitem:23113:0:0:0:0:0:0:768347072:80|h[Brilliant Golden Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.43, 37.89)|
U |cff1eff00|Hitem:23098:0:0:0:0:0:0:523963040:80|h[Inscribed Flame Spessarite]|h|r |N|Hellfire Peninsula, Thrallmar (56.43, 37.89)|
U |cff1eff00|Hitem:23094:0:0:0:0:0:0:1612537344:80|h[Teardrop Blood Garnet]|h|r |N|Hellfire Peninsula, Thrallmar (56.43, 37.89)|
U |cff1eff00|Hitem:23094:0:0:0:0:0:0:1946899072:80|h[Teardrop Blood Garnet]|h|r |N|Hellfire Peninsula, Thrallmar (56.43, 37.89)|
U |cff1eff00|Hitem:23113:0:0:0:0:0:0:1507373696:80|h[Brilliant Golden Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.43, 37.89)|
U |cff1eff00|Hitem:23108:0:0:0:0:0:0:2056414976:80|h[Glowing Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.43, 37.89)|
U |cff1eff00|Hitem:23098:0:0:0:0:0:0:2081186560:80|h[Inscribed Flame Spessarite]|h|r |N|Hellfire Peninsula, Thrallmar (56.43, 37.89)|
U |cffffffff|Hitem:23425:0:0:0:0:0:0:2091470720:80|h[Adamantite Ore]|h|r |N|Hellfire Peninsula, Thrallmar (56.46, 37.84)|
U |cff1eff00|Hitem:28595:0:0:0:0:0:0:10977048:80|h[Bright Blood Garnet]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23094:0:0:0:0:0:0:696003200:80|h[Teardrop Blood Garnet]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23094:0:0:0:0:0:0:1132849920:80|h[Teardrop Blood Garnet]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:28595:0:0:0:0:0:0:1094418048:80|h[Bright Blood Garnet]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:28595:0:0:0:0:0:0:728099200:80|h[Bright Blood Garnet]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cffffffff|Hitem:23424:0:0:0:0:0:0:-1864122407:80|h[Fel Iron Ore]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cffffffff|Hitem:23424:0:0:0:0:0:0:834284412:80|h[Fel Iron Ore]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23113:0:0:0:0:0:0:628916032:80|h[Brilliant Golden Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23108:0:0:0:0:0:0:1480131328:80|h[Glowing Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23119:0:0:0:0:0:0:1377399424:80|h[Sparkling Azure Moonstone]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23119:0:0:0:0:0:0:2116391552:80|h[Sparkling Azure Moonstone]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23108:0:0:0:0:0:0:594373120:80|h[Glowing Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23113:0:0:0:0:0:0:81107160:80|h[Brilliant Golden Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23113:0:0:0:0:0:0:1729702656:80|h[Brilliant Golden Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23113:0:0:0:0:0:0:516855104:80|h[Brilliant Golden Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.81)|
U |cff1eff00|Hitem:23095:0:0:0:0:0:0:118133816:80|h[Bold Blood Garnet]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23118:0:0:0:0:0:0:1937081856:80|h[Solid Azure Moonstone]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23118:0:0:0:0:0:0:521751552:80|h[Solid Azure Moonstone]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23095:0:0:0:0:0:0:735080384:80|h[Bold Blood Garnet]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff9d9d9d|Hitem:7997:0:0:0:0:0:0:1414666496:80|h[Red Defias Mask]|h|r |N|Undercity, Trade Quarter (68.14, 38.93)|
U |cffffffff|Hitem:2592:0:0:0:0:0:0:-1921314560:80|h[Wool Cloth]|h|r |N|Undercity, Trade Quarter (68.14, 38.93)|
U |cffffffff|Hitem:2592:0:0:0:0:0:0:-2142593664:80|h[Wool Cloth]|h|r |N|Undercity, Trade Quarter (68.14, 38.93)|
U |cffffffff|Hitem:2592:0:0:0:0:0:0:619402224:80|h[Wool Cloth]|h|r |N|Undercity, Trade Quarter (68.14, 38.93)|
U |cffffffff|Hitem:5787:0:0:0:0:0:0:1100872768:80|h[Pattern: Murloc Scale Breastplate]|h|r |N|Undercity, Trade Quarter (68.14, 38.93)|
U |cff1eff00|Hitem:1206:0:0:0:0:0:0:724726240:80|h[Moss Agate]|h|r |N|Undercity, Trade Quarter (68.14, 38.93)|
U |cffffffff|Hitem:2770:0:0:0:0:0:0:1089342400:80|h[Copper Ore]|h|r |N|Undercity, Trade Quarter (68.14, 38.93)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Wetlands, Dun Algaz (48.60, 69.65)|
U |cff1eff00|Hitem:8705:0:0:0:0:0:0:2057003392:80|h[OOX-22/FE Distress Beacon]|h|r |N|Feralas, Woodpaw Hills (70.43, 51.24)|
A Find OOX-22/FE! |QID|2766| |N|Feralas, Woodpaw Hills (70.43, 51.24)|
T Find OOX-22/FE! |QID|2766| |N|Feralas, Feral Scar Vale (53.40, 55.64)|
A Rescue OOX-22/FE! |QID|2767| |N|Feralas, Feral Scar Vale (53.40, 55.60)|
- |QID|2767.1| |QO|Escort OOX-22/FE to the dock along the Forgotten Coast| |N|Feralas, The Forgotten Coast (45.60, 43.24)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Feralas, Oneiros (51.88, 15.40)|
U |cffffffff|Hitem:33454:0:0:0:0:0:0:-1819643008:80|h[Salted Venison]|h|r |N|The Hinterlands,  (36.59, 58.86)|
U |cffffffff|Hitem:9241:0:0:0:0:0:0:-1905719808:80|h[Sacred Mallet]|h|r |N|The Hinterlands, The Altar of Zul (48.99, 68.55)|
U |cff1eff00|Hitem:14436:0:0:0:0:0:0:1825540544:80|h[Windchaser Coronet]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cff1eff00|Hitem:15287:0:0:0:0:0:1709:1941067904:80|h[Crusader Bow of Marksmanship]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cff1eff00|Hitem:7529:0:0:0:0:0:620:-1709152128:80|h[Cabalist Helm of the Monkey]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cff1eff00|Hitem:15169:0:0:0:0:0:1203:2044162176:80|h[Imposing Shoulders of the Bear]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cff1eff00|Hitem:7552:0:0:0:0:0:0:1521930560:80|h[Falcon's Hook]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cffffffff|Hitem:4306:0:0:0:0:0:0:1314353088:80|h[Silk Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1414539136:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1735435008:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1775954944:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1268711296:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cffffffff|Hitem:2835:0:0:0:0:0:0:1464541632:80|h[Rough Stone]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cffffffff|Hitem:2836:0:0:0:0:0:0:2100086016:80|h[Coarse Stone]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cffffffff|Hitem:2770:0:0:0:0:0:0:1196106176:80|h[Copper Ore]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cff1eff00|Hitem:1210:0:0:0:0:0:0:1343309376:80|h[Shadowgem]|h|r |N|The Hinterlands, Revantusk Village (78.86, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:-2041681408:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:807242304:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1330767040:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:962237632:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:918885056:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1200083264:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:-2139561472:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:-1693373824:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:12207:0:0:0:0:0:0:1141028096:80|h[Giant Egg]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:4589:0:0:0:0:0:0:2053686528:80|h[Long Elegant Feather]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cff1eff00|Hitem:7532:0:0:0:0:0:1614:1468167008:80|h[Cabalist Spaulders of Defense]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cff1eff00|Hitem:12022:0:0:0:0:0:769:1056379200:80|h[Iridium Chain of the Owl]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cff1eff00|Hitem:7533:0:0:0:0:0:176:-1526258432:80|h[Cabalist Cloak of Intellect]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:8151:0:0:0:0:0:0:2121927104:80|h[Flask of Mojo]|h|r |N|The Hinterlands, Revantusk Village (78.88, 80.37)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|The Hinterlands, Zun'watha (21.72, 57.31)|
U |cffffffff|Hitem:12208:0:0:0:0:0:0:1273827136:80|h[Tender Wolf Meat]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cffffffff|Hitem:12203:0:0:0:0:0:0:1589394048:80|h[Red Wolf Meat]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cffffffff|Hitem:12207:0:0:0:0:0:0:1654306368:80|h[Giant Egg]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cffffffff|Hitem:4589:0:0:0:0:0:0:1908051328:80|h[Long Elegant Feather]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cffffffff|Hitem:8151:0:0:0:0:0:0:1602788928:80|h[Flask of Mojo]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23100:0:0:0:0:0:0:1672269696:80|h[Glinting Flame Spessarite]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23098:0:0:0:0:0:0:1185678208:80|h[Inscribed Flame Spessarite]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23098:0:0:0:0:0:0:212839376:80|h[Inscribed Flame Spessarite]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23100:0:0:0:0:0:0:1231465472:80|h[Glinting Flame Spessarite]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23100:0:0:0:0:0:0:1520025216:80|h[Glinting Flame Spessarite]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23100:0:0:0:0:0:0:1574694272:80|h[Glinting Flame Spessarite]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23100:0:0:0:0:0:0:631558336:80|h[Glinting Flame Spessarite]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23104:0:0:0:0:0:0:233336320:80|h[Jagged Deep Peridot]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23104:0:0:0:0:0:0:586444544:80|h[Jagged Deep Peridot]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23104:0:0:0:0:0:0:675303360:80|h[Jagged Deep Peridot]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23104:0:0:0:0:0:0:2120173312:80|h[Jagged Deep Peridot]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cff1eff00|Hitem:23104:0:0:0:0:0:0:1852937856:80|h[Jagged Deep Peridot]|h|r |N|Thunder Bluff,  (44.98, 59.03)|
U |cffffffff|Hitem:2770:0:0:0:0:0:0:790634560:80|h[Copper Ore]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
U |cffffffff|Hitem:2770:0:0:0:0:0:0:1575736576:80|h[Copper Ore]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
U |cffffffff|Hitem:2835:0:0:0:0:0:0:1114943168:80|h[Rough Stone]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
U |cffffffff|Hitem:2835:0:0:0:0:0:0:765449968:80|h[Rough Stone]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
U |cffffffff|Hitem:2835:0:0:0:0:0:0:1059070016:80|h[Rough Stone]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
U |cffffffff|Hitem:2836:0:0:0:0:0:0:-2081024256:80|h[Coarse Stone]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
U |cffffffff|Hitem:2836:0:0:0:0:0:0:-1620188928:80|h[Coarse Stone]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
U |cffffffff|Hitem:2771:0:0:0:0:0:0:595304672:80|h[Tin Ore]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
U |cffffffff|Hitem:2771:0:0:0:0:0:0:2065884928:80|h[Tin Ore]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
U |cff1eff00|Hitem:1206:0:0:0:0:0:0:2017539968:80|h[Moss Agate]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Thousand Needles, Freewind Post (45.85, 50.95)|
A Learning to Fly |QID|11498| |N|Shattrath City, Terrace of Light (63.82, 41.04)|
U |cff1eff00|Hitem:23100:0:0:0:0:0:0:1720373376:80|h[Glinting Flame Spessarite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23100:0:0:0:0:0:0:159481872:80|h[Glinting Flame Spessarite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23100:0:0:0:0:0:0:1072317440:80|h[Glinting Flame Spessarite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23100:0:0:0:0:0:0:2071231104:80|h[Glinting Flame Spessarite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:1179230848:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:1914593024:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:1259249536:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:1525376768:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:428474688:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:452371008:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:2056968320:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:1321028608:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:1884841984:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:705086912:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:1213811840:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cff1eff00|Hitem:23111:0:0:0:0:0:0:938882688:80|h[Sovereign Shadow Draenite]|h|r |N|Hellfire Peninsula, Thrallmar (56.47, 37.82)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Hellfire Peninsula, Thrallmar (56.75, 37.71)|
U |cffffffff|Hitem:43156:0:0:0:0:0:0:0:80|h[Tabard of the Wyrmrest Accord]|h|r |N|Dragonblight, Wyrmrest Temple (59.94, 53.08)|
U |cffffffff|Hitem:43425:0:0:0:0:0:0:812028032:80|h[Glyph of Blocking]|h|r |N|Dalaran, The Scribes' Sacellum (41.55, 37.33)|
U |cffffffff|Hitem:39002:0:0:0:0:0:0:631781336:80|h[Scroll of Enchant Chest - Greater Defense]|h|r |N|Dalaran, The Bank of Dalaran (55.04, 18.97)|
T A Score to Settle |QID|11272| |N|Howling Fjord, Vengeance Landing (78.61, 31.11)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1259920832:80|h[Mageweave Cloth]|h|r |N|Undercity, Trade Quarter (67.96, 38.00)|
U |cffffffff|Hitem:8153:0:0:0:0:0:0:1086894400:80|h[Wildvine]|h|r |N|Undercity, Trade Quarter (67.96, 38.00)|
U |cffffffff|Hitem:2772:0:0:0:0:0:0:1170154752:80|h[Iron Ore]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.15)|
U |cffffffff|Hitem:2772:0:0:0:0:0:0:1780805760:80|h[Iron Ore]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.15)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:1438590208:80|h[Heavy Stone]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.15)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:810428320:80|h[Heavy Stone]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.15)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:2004607232:80|h[Heavy Stone]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.15)|
U |cffffffff|Hitem:2836:0:0:0:0:0:0:862030752:80|h[Coarse Stone]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.15)|
U |cffffffff|Hitem:2771:0:0:0:0:0:0:593595296:80|h[Tin Ore]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.15)|
U |cffffffff|Hitem:4278:0:0:0:0:0:0:2053032448:80|h[Lesser Bloodstone Ore]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.15)|
U |cffffffff|Hitem:3182:0:0:0:0:0:0:-1357631616:80|h[Spider's Silk]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.15)|
U |cff1eff00|Hitem:1206:0:0:0:0:0:0:1759985792:80|h[Moss Agate]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.15)|
U |cffffffff|Hitem:2772:0:0:0:0:0:0:-2115796608:80|h[Iron Ore]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.11)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:1322958016:80|h[Heavy Stone]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.11)|
U |cffffffff|Hitem:4461:0:0:0:0:0:0:1735950592:80|h[Raptor Hide]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.11)|
U |cffffffff|Hitem:4278:0:0:0:0:0:0:1311510016:80|h[Lesser Bloodstone Ore]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.11)|
U |cffffffff|Hitem:4306:0:0:0:0:0:0:1338617984:80|h[Silk Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:931830856:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cffffffff|Hitem:5117:0:0:0:0:0:0:1842095680:80|h[Vibrant Plume]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cffffffff|Hitem:8151:0:0:0:0:0:0:1744677632:80|h[Flask of Mojo]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cffffffff|Hitem:2772:0:0:0:0:0:0:1141372608:80|h[Iron Ore]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cffffffff|Hitem:2771:0:0:0:0:0:0:-1889041920:80|h[Tin Ore]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:952679968:80|h[Heavy Stone]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cffffffff|Hitem:2836:0:0:0:0:0:0:867873952:80|h[Coarse Stone]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cffffffff|Hitem:12207:0:0:0:0:0:0:1371475776:80|h[Giant Egg]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:-1715979136:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cff1eff00|Hitem:1210:0:0:0:0:0:0:1403465856:80|h[Shadowgem]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cff1eff00|Hitem:9294:0:0:0:0:0:0:-1179108224:80|h[Recipe: Wildvine Potion]|h|r |N|The Hinterlands, Revantusk Village (78.90, 80.46)|
U |cffffffff|Hitem:44739:0:0:0:0:0:0:886464474:80|h[Diamond-cut Refractor Scope]|h|r |N|The Hinterlands, Revantusk Village (78.85, 80.46)|
U |cffffffff|Hitem:20767:0:0:0:0:0:0:1365239168:80|h[Scum Covered Bag]|h|r |N|The Hinterlands, Agol'watha (45.42, 42.45)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:1039043136:80|h[Heavy Stone]|h|r |N|The Hinterlands, Revantusk Village (78.84, 80.31)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:-2131764608:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.84, 80.31)|
U |cffffffff|Hitem:12207:0:0:0:0:0:0:1374982848:80|h[Giant Egg]|h|r |N|The Hinterlands, Revantusk Village (78.84, 80.31)|
U |cffffffff|Hitem:12207:0:0:0:0:0:0:1194269120:80|h[Giant Egg]|h|r |N|The Hinterlands, Revantusk Village (78.84, 80.31)|
U |cff1eff00|Hitem:7519:0:0:0:0:0:1045:691019824:80|h[Gossamer Pants of the Whale]|h|r |N|The Hinterlands, Revantusk Village (78.84, 80.31)|
U |cff1eff00|Hitem:3208:0:0:0:0:0:337:-1428390144:80|h[Conk Hammer of Stamina]|h|r |N|The Hinterlands, Revantusk Village (78.84, 80.31)|
U |cffffffff|Hitem:8151:0:0:0:0:0:0:1266203840:80|h[Flask of Mojo]|h|r |N|The Hinterlands, Revantusk Village (78.84, 80.31)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1322427456:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.84, 80.31)|
U |cffffffff|Hitem:2772:0:0:0:0:0:0:770607680:80|h[Iron Ore]|h|r |N|The Hinterlands, Revantusk Village (78.84, 80.31)|
U |cffffffff|Hitem:8146:0:0:0:0:0:0:-1930177920:80|h[Wicked Claw]|h|r |N|The Hinterlands, Revantusk Village (78.84, 80.31)|
U |cff1eff00|Hitem:8704:0:0:0:0:0:0:-1739512832:80|h[OOX-09/HL Distress Beacon]|h|r |N|The Hinterlands,  (64.99, 44.81)|
A Find OOX-09/HL! |QID|485| |N|The Hinterlands,  (64.99, 44.81)|
T Find OOX-09/HL! |QID|485| |N|The Hinterlands,  (49.33, 37.77)|
A Rescue OOX-09/HL! |QID|836| |N|The Hinterlands,  (49.33, 37.77)|
- |QID|836.1| |QO|Escort OOX-09/HL to the shoreline beyond Overlook Cliff| |N|The Hinterlands, The Overlook Cliffs (79.06, 61.51)|
U |cffffffff|Hitem:8151:0:0:0:0:0:0:-1940890624:80|h[Flask of Mojo]|h|r |N|The Hinterlands, Revantusk Village (78.89, 80.41)|
U |cffffffff|Hitem:8152:0:0:0:0:0:0:1059999264:80|h[Flask of Big Mojo]|h|r |N|The Hinterlands, Revantusk Village (78.89, 80.41)|
U |cffffffff|Hitem:38303:0:0:0:0:0:0:1651596544:80|h[Enduring Mojo]|h|r |N|The Hinterlands, Revantusk Village (78.89, 80.41)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1236580096:80|h[Mageweave Cloth]|h|r |N|The Hinterlands, Revantusk Village (78.89, 80.41)|
U |cffffffff|Hitem:4599:0:0:0:0:0:0:735041840:80|h[Cured Ham Steak]|h|r |N|The Hinterlands, Revantusk Village (78.89, 80.41)|
T Rescue OOX-22/FE! |QID|2767| |N|Stranglethorn Vale, Booty Bay (28.33, 76.32)|
T Rescue OOX-09/HL! |QID|836| |N|Stranglethorn Vale, Booty Bay (28.33, 76.32)|
U |cffffffff|Hitem:10398:0:0:0:0:0:0:679566080:80|h[Mechanical Chicken]|h|r |N|Swamp of Sorrows, Stonard (46.05, 54.68)|
A Kibler's Exotic Pets |QID|4729| |N|Burning Steppes, Flame Crest (65.90, 22.07)|
A En-Ay-Es-Tee-Why |QID|4862| |N|Burning Steppes, Flame Crest (65.90, 22.07)|
T Kibler's Exotic Pets |QID|4729| |N|Burning Steppes, Flame Crest (65.91, 22.03)|
T En-Ay-Es-Tee-Why |QID|4862| |N|Burning Steppes, Flame Crest (65.91, 22.03)|
U |cffffffff|Hitem:12264:0:0:0:0:0:0:2010036480:80|h[Worg Carrier]|h|r |N|Burning Steppes, Flame Crest (65.91, 22.03)|
U |cffffffff|Hitem:12529:0:0:0:0:0:0:1272475264:80|h[Smolderweb Carrier]|h|r |N|Burning Steppes, Flame Crest (65.91, 22.03)|
U |cff0070dd|Hitem:16735:0:0:0:0:0:0:1029001248:80|h[Bracers of Valor]|h|r |N|Badlands, Kargath (3.95, 47.42)|
U |cff1eff00|Hitem:8269:0:0:0:0:0:0:760565792:80|h[Ebonhold Boots]|h|r |N|Badlands, Kargath (3.95, 47.42)|
U |cff1eff00|Hitem:15282:0:0:0:0:0:766:979115232:80|h[Dragon Finger of the Owl]|h|r |N|Badlands, Kargath (3.95, 47.42)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:882479456:80|h[Heavy Stone]|h|r |N|Badlands, Kargath (3.95, 47.42)|
U |cffffffff|Hitem:2772:0:0:0:0:0:0:614044000:80|h[Iron Ore]|h|r |N|Badlands, Kargath (3.95, 47.42)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:-1944631168:80|h[Heavy Stone]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.09)|
U |cff1eff00|Hitem:2775:0:0:0:0:0:0:348626952:80|h[Silver Ore]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.09)|
U |cffffffff|Hitem:14227:0:0:0:0:0:0:1087943552:80|h[Ironweb Spider Silk]|h|r |N|Arathi Highlands, Hammerfall (73.77, 33.09)|
U |cffffffff|Hitem:2771:0:0:0:0:0:0:1831650560:80|h[Tin Ore]|h|r |N|Arathi Highlands, Hammerfall (73.93, 33.21)|
U |cffffffff|Hitem:2771:0:0:0:0:0:0:1220858048:80|h[Tin Ore]|h|r |N|Arathi Highlands, Hammerfall (73.93, 33.21)|
U |cffffffff|Hitem:2772:0:0:0:0:0:0:1104597440:80|h[Iron Ore]|h|r |N|Arathi Highlands, Hammerfall (73.93, 33.21)|
U |cffffffff|Hitem:2772:0:0:0:0:0:0:1894802688:80|h[Iron Ore]|h|r |N|Arathi Highlands, Hammerfall (73.93, 33.21)|
U |cffffffff|Hitem:2835:0:0:0:0:0:0:1927394688:80|h[Rough Stone]|h|r |N|Arathi Highlands, Hammerfall (73.93, 33.21)|
U |cffffffff|Hitem:7912:0:0:0:0:0:0:-1950846080:80|h[Solid Stone]|h|r |N|Arathi Highlands, Hammerfall (73.93, 33.21)|
U |cffffffff|Hitem:2836:0:0:0:0:0:0:1489293504:80|h[Coarse Stone]|h|r |N|Arathi Highlands, Hammerfall (73.93, 33.21)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:1872910848:80|h[Heavy Stone]|h|r |N|Arathi Highlands, Hammerfall (73.93, 33.21)|
U |cffffffff|Hitem:4235:0:0:0:0:0:0:-2075482112:80|h[Heavy Hide]|h|r |N|Arathi Highlands, Hammerfall (73.93, 33.21)|
U |cffffffff|Hitem:2770:0:0:0:0:0:0:1658959232:80|h[Copper Ore]|h|r |N|Arathi Highlands, Hammerfall (73.93, 33.21)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Arathi Highlands, Hammerfall (73.08, 32.73)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Silverpine Forest, Ambermill (62.33, 63.25)|
U |cff0070dd|Hitem:44188:0:0:0:0:0:0:0:80|h[Cloak of Peaceful Resolutions]|h|r |N|Dragonblight, Wyrmrest Temple (59.90, 53.06)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.32, 74.25)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (45.46, 61.32)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.31, 74.32)|
U |cffffffff|Hitem:23425:0:0:0:0:0:0:2091470720:80|h[Adamantite Ore]|h|r |N|Dalaran, Krasus' Landing (70.98, 45.85)|
U |cffffffff|Hitem:21746:0:0:0:0:0:0:37898262:80|h[Lucky Red Envelope]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:27682:0:0:0:0:0:0:1731307844:80|h[Talbuk Venison]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:27682:0:0:0:0:0:0:1305753369:80|h[Talbuk Venison]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:27678:0:0:0:0:0:0:-1776027213:80|h[Clefthoof Meat]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:27678:0:0:0:0:0:0:-1500965004:80|h[Clefthoof Meat]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:596706576:80|h[Netherweave Cloth]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:21746:0:0:0:0:0:0:60978207:80|h[Lucky Red Envelope]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:21746:0:0:0:0:0:0:1343663934:80|h[Lucky Red Envelope]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:21746:0:0:0:0:0:0:1749033205:80|h[Lucky Red Envelope]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:21746:0:0:0:0:0:0:1483485572:80|h[Lucky Red Envelope]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:21746:0:0:0:0:0:0:1515810693:80|h[Lucky Red Envelope]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:21746:0:0:0:0:0:0:464027718:80|h[Lucky Red Envelope]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:21746:0:0:0:0:0:0:1858383650:80|h[Lucky Red Envelope]|h|r |N|Dalaran, The Eventide (44.88, 68.46)|
U |cffffffff|Hitem:21744:0:0:0:0:0:0:-151513814:80|h[Lucky Rocket Cluster]|h|r |N|Dalaran, Dalaran Merchant's Bank (42.58, 78.94)|
U |cffffffff|Hitem:21745:0:0:0:0:0:0:-159193026:80|h[Elder's Moonstone]|h|r |N|Dalaran, Dalaran Merchant's Bank (42.58, 78.94)|
U |cff0070dd|Hitem:41116:0:0:0:0:0:0:1873999488:80|h[Tempered Saronite Bracers]|h|r |N|Dalaran, The Eventide (45.12, 68.21)|
U |cff0070dd|Hitem:40675:0:0:0:0:0:0:870007616:80|h[Tempered Saronite Shoulders]|h|r |N|Dalaran, The Eventide (45.12, 68.21)|
U |cff0070dd|Hitem:43184:0:0:0:0:0:0:167397910:80|h[Tundra Pauldrons]|h|r |N|Dalaran, The Eventide (45.12, 68.21)|
U |cff0070dd|Hitem:40669:0:0:0:0:0:0:881390848:80|h[Tempered Saronite Belt]|h|r |N|Dalaran, The Eventide (45.12, 68.21)|
U |cff1eff00|Hitem:24078:0:0:0:0:0:0:1459053568:80|h[Heavy Adamantite Ring]|h|r |N|Dalaran, Dalaran (45.72, 38.35)|
U |cff1eff00|Hitem:24078:0:0:0:0:0:0:2064460544:80|h[Heavy Adamantite Ring]|h|r |N|Dalaran, Dalaran (45.72, 38.35)|
U |cff1eff00|Hitem:24078:0:0:0:0:0:0:2029801984:80|h[Heavy Adamantite Ring]|h|r |N|Dalaran, Dalaran (45.72, 38.35)|
U |cffffffff|Hitem:23425:0:0:0:0:0:0:303882601:80|h[Adamantite Ore]|h|r |N|Dalaran, Dalaran (45.72, 38.35)|
U |cffffffff|Hitem:23425:0:0:0:0:0:0:1520108188:80|h[Adamantite Ore]|h|r |N|Dalaran, Dalaran (45.72, 38.35)|
U |cff1eff00|Hitem:23107:0:0:0:0:0:0:2018869504:80|h[Shadow Draenite]|h|r |N|Dalaran, Dalaran (45.72, 38.35)|
U |cff1eff00|Hitem:23117:0:0:0:0:0:0:751283696:80|h[Azure Moonstone]|h|r |N|Dalaran, Dalaran (45.72, 38.35)|
U |cff1eff00|Hitem:23112:0:0:0:0:0:0:550140708:80|h[Golden Draenite]|h|r |N|Dalaran, Dalaran (45.72, 38.35)|
U |cff1eff00|Hitem:24078:0:0:0:0:0:0:1164713472:80|h[Heavy Adamantite Ring]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cff1eff00|Hitem:24078:0:0:0:0:0:0:1930468224:80|h[Heavy Adamantite Ring]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cffffffff|Hitem:23425:0:0:0:0:0:0:1002675263:80|h[Adamantite Ore]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cffffffff|Hitem:2592:0:0:0:0:0:0:1221231744:80|h[Wool Cloth]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cffffffff|Hitem:4306:0:0:0:0:0:0:1983718016:80|h[Silk Cloth]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cffffffff|Hitem:23425:0:0:0:0:0:0:768092492:80|h[Adamantite Ore]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cffffffff|Hitem:43427:0:0:0:0:0:0:1499755338:80|h[Glyph of Sunder Armor]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cffffffff|Hitem:43413:0:0:0:0:0:0:2032006177:80|h[Glyph of Rapid Charge]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cffffffff|Hitem:23425:0:0:0:0:0:0:2064979930:80|h[Adamantite Ore]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cff1eff00|Hitem:23107:0:0:0:0:0:0:821541216:80|h[Shadow Draenite]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cff1eff00|Hitem:23117:0:0:0:0:0:0:-1952855040:80|h[Azure Moonstone]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cff1eff00|Hitem:23077:0:0:0:0:0:0:1162979392:80|h[Blood Garnet]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cff1eff00|Hitem:23079:0:0:0:0:0:0:1252475584:80|h[Deep Peridot]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cff1eff00|Hitem:23112:0:0:0:0:0:0:1431953984:80|h[Golden Draenite]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cff1eff00|Hitem:21929:0:0:0:0:0:0:1201315136:80|h[Flame Spessarite]|h|r |N|Dalaran, Dalaran (45.87, 37.57)|
U |cff1eff00|Hitem:24078:0:0:0:0:0:0:606996928:80|h[Heavy Adamantite Ring]|h|r |N|Dalaran, Dalaran (45.85, 37.65)|
U |cff1eff00|Hitem:24078:0:0:0:0:0:0:1316243584:80|h[Heavy Adamantite Ring]|h|r |N|Dalaran, Dalaran (45.85, 37.65)|
U |cffffffff|Hitem:26042:0:0:0:0:0:0:-1985076846:80|h[Oshu'gun Crystal Powder Sample]|h|r |N|Dalaran, The Bank of Dalaran (54.32, 15.90)|
U |cff0070dd|Hitem:37197:0:0:0:0:0:0:1094109982:80|h[Tattered Castle Drape]|h|r |N|Dalaran, The Bank of Dalaran (54.32, 15.79)|
U |cff0070dd|Hitem:43184:0:0:0:0:0:0:167397910:80|h[Tundra Pauldrons]|h|r |N|Dalaran, The Bank of Dalaran (54.32, 15.79)|
U |cffffffff|Hitem:35188:0:0:0:0:0:0:2009198070:80|h[Nesingwary Lackey Ear]|h|r |N|Dalaran, The Bank of Dalaran (54.29, 16.05)|
U |cffffffff|Hitem:21100:0:0:0:0:0:0:978872010:80|h[Coin of Ancestry]|h|r |N|Dalaran, The Bank of Dalaran (54.29, 16.05)|
U |cff1eff00|Hitem:21213:0:0:0:0:0:0:253874195:80|h[Preserved Holly]|h|r |N|Dalaran, The Bank of Dalaran (54.29, 16.05)|
U |cffffffff|Hitem:20414:0:0:0:0:0:0:-1595563335:80|h[Hallowed Wand - Wisp]|h|r |N|Dalaran, The Bank of Dalaran (54.29, 16.05)|
U |cffffffff|Hitem:24581:0:0:0:0:0:0:1809317958:80|h[Mark of Thrallmar]|h|r |N|Dalaran, The Bank of Dalaran (54.29, 16.05)|
U |cffffffff|Hitem:21519:0:0:0:0:0:0:218215135:80|h[Mistletoe]|h|r |N|Dalaran, The Bank of Dalaran (54.29, 16.05)|
U |cffffffff|Hitem:34597:0:0:0:0:0:0:944910598:80|h[Winterfin Clam]|h|r |N|Dalaran, The Bank of Dalaran (54.29, 16.05)|
U |cffffffff|Hitem:35799:0:0:0:0:0:0:468728817:80|h[Frozen Mojo]|h|r |N|Dalaran, The Bank of Dalaran (54.29, 16.05)|
U |cffffffff|Hitem:33120:0:0:0:0:0:0:1292441011:80|h[Shoveltusk Meat]|h|r |N|Dalaran, The Bank of Dalaran (54.29, 16.05)|
U |cffffffff|Hitem:41427:0:0:0:0:0:0:888347655:80|h[Dalaran Firework]|h|r |N|Dalaran, The Bank of Dalaran (54.29, 16.05)|
U |cffffffff|Hitem:4278:0:0:0:0:0:0:795110528:80|h[Lesser Bloodstone Ore]|h|r |N|Dalaran, Dalaran (52.15, 26.61)|
U |cff1eff00|Hitem:29584:0:0:0:0:0:0:0:80|h[Throat Piercers]|h|r |N|Dalaran, Dalaran (52.20, 26.58)|
A The Ring of Blood: Brokentoe |QID|9962| |N|Nagrand, The Ring of Blood (42.79, 20.83)|
- |QID|9962.1| |QO|Brokentoe Defeated| |N|Nagrand, The Ring of Blood (43.49, 20.60)|
T The Ring of Blood: Brokentoe |QID|9962| |N|Nagrand, The Ring of Blood (42.80, 20.79)|
A The Ring of Blood: The Blue Brothers |QID|9967| |N|Nagrand, The Ring of Blood (42.80, 20.79)|
- |QID|9967.1| |QO|The Blue Brothers Defeated| |N|Nagrand, The Ring of Blood (43.35, 20.64)|
T The Ring of Blood: The Blue Brothers |QID|9967| |N|Nagrand, The Ring of Blood (42.84, 20.70)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1706722048:80|h[Netherweave Cloth]|h|r |N|Nagrand, The Ring of Blood (42.84, 20.70)|
U |cffffffff|Hitem:33462:0:0:0:0:0:0:1320447570:80|h[Scroll of Strength VI]|h|r |N|Nagrand, The Ring of Blood (42.84, 20.70)|
U |cffffffff|Hitem:21991:0:0:0:0:0:0:437660213:80|h[Heavy Netherweave Bandage]|h|r |N|Nagrand, The Ring of Blood (42.84, 20.70)|
A The Ring of Blood: Rokdar the Sundered Lord |QID|9970| |N|Nagrand, The Ring of Blood (42.84, 20.73)|
- |QID|9970.1| |QO|Rokdar the Sundered Lord Defeated| |N|Nagrand, The Ring of Blood (44.15, 19.82)|
T The Ring of Blood: Rokdar the Sundered Lord |QID|9970| |N|Nagrand, The Ring of Blood (42.85, 20.66)|
U |cffffffff|Hitem:33454:0:0:0:0:0:0:-1902245376:80|h[Salted Venison]|h|r |N|Nagrand, The Ring of Blood (42.81, 20.76)|
A The Ring of Blood: Skra'gath |QID|9972| |N|Nagrand, The Ring of Blood (42.80, 20.77)|
- |QID|9972.1| |QO|Skra'gath Defeated| |N|Nagrand, The Ring of Blood (43.55, 20.52)|
T The Ring of Blood: Skra'gath |QID|9972| |N|Nagrand, The Ring of Blood (42.84, 20.70)|
U |cffffffff|Hitem:27854:0:0:0:0:0:0:1507083136:80|h[Smoked Talbuk Venison]|h|r |N|Nagrand, The Ring of Blood (42.84, 20.70)|
A The Ring of Blood: The Warmaul Champion |QID|9973| |N|Nagrand, The Ring of Blood (42.79, 20.76)|
- |QID|9973.1| |QO|The Warmaul Champion Defeated| |N|Nagrand, The Ring of Blood (43.83, 20.40)|
T The Ring of Blood: The Warmaul Champion |QID|9973| |N|Nagrand, The Ring of Blood (42.82, 20.72)|
U |cffffffff|Hitem:27651:0:0:0:0:0:0:958956466:80|h[Buzzard Bites]|h|r |N|Nagrand, The Ring of Blood (42.82, 20.72)|
A The Ring of Blood: The Final Challenge |QID|9977| |N|Nagrand, The Ring of Blood (42.80, 20.76)|
- |QID|9977.1| |QO|Mogor, Hero of the Warmaul Defeated| |N|Nagrand, The Ring of Blood (43.90, 20.65)|
T The Ring of Blood: The Final Challenge |QID|9977| |N|Nagrand, The Ring of Blood (42.76, 20.61)|
U |cff1eff00|Hitem:26044:0:0:0:0:0:0:1241417184:80|h[Halaa Research Token]|h|r |N|Shattrath City, Bank (58.97, 61.22)|
U |cff0070dd|Hitem:33783:0:0:0:0:0:0:0:80|h[Design: Steady Talasite]|h|r |N|Nagrand, Halaa (41.26, 44.35)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Nagrand,  (19.92, 30.22)|
U |cff0070dd|Hitem:33782:0:0:0:0:0:0:1282558976:80|h[Steady Talasite]|h|r |N|Dalaran, Dalaran (51.21, 28.47)|
U |cff1eff00|Hitem:7533:0:0:0:0:0:176:-1526258432:80|h[Cabalist Cloak of Intellect]|h|r |N|Dalaran, Dalaran (52.09, 26.52)|
U |cff1eff00|Hitem:12022:0:0:0:0:0:769:1056379200:80|h[Iridium Chain of the Owl]|h|r |N|Dalaran, Dalaran (52.09, 26.52)|
U |cff1eff00|Hitem:7532:0:0:0:0:0:1614:1468167008:80|h[Cabalist Spaulders of Defense]|h|r |N|Dalaran, Dalaran (52.09, 26.52)|
A Finish the Shipment |QID|13041| |N|Dalaran, Cartier & Co. Fine Jewelry (40.35, 34.89)|
- |QID|13041.1| |QO|Chalcedony: 1/1| |N|Dalaran, Magus Commerce Exchange (40.13, 32.31)|
T Finish the Shipment |QID|13041| |N|Dalaran, Cartier & Co. Fine Jewelry (40.39, 34.84)|
A Shipment: Glowing Ivory Figurine |QID|12959| |N|Dalaran, Cartier & Co. Fine Jewelry (40.39, 34.84)|
U |cff0070dd|Hitem:40012:0:0:0:0:0:0:1713943040:80|h[Brilliant Autumn's Glow]|h|r |N|Dalaran, Magus Commerce Exchange (40.23, 32.54)|
U |cff0070dd|Hitem:40012:0:0:0:0:0:0:1331768960:80|h[Brilliant Autumn's Glow]|h|r |N|Dalaran, Magus Commerce Exchange (40.23, 32.54)|
U |cff0070dd|Hitem:40012:0:0:0:0:0:0:1986793728:80|h[Brilliant Autumn's Glow]|h|r |N|Dalaran, Magus Commerce Exchange (40.23, 32.54)|
U |cff0070dd|Hitem:40012:0:0:0:0:0:0:221701504:80|h[Brilliant Autumn's Glow]|h|r |N|Dalaran, Magus Commerce Exchange (40.23, 32.54)|
U |cff0070dd|Hitem:40012:0:0:0:0:0:0:232511952:80|h[Brilliant Autumn's Glow]|h|r |N|Dalaran, Magus Commerce Exchange (40.23, 32.54)|
U |cff0070dd|Hitem:40012:0:0:0:0:0:0:1864278528:80|h[Brilliant Autumn's Glow]|h|r |N|Dalaran, Magus Commerce Exchange (40.23, 32.54)|
U |cff0070dd|Hitem:40053:0:0:0:0:0:0:1684330752:80|h[Pristine Monarch Topaz]|h|r |N|Dalaran, Magus Commerce Exchange (40.11, 32.37)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:-2110958464:80|h[Netherweave Cloth]|h|r |N|Dalaran, Dalaran (45.66, 38.42)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1252804608:80|h[Netherweave Cloth]|h|r |N|Dalaran, Dalaran (45.66, 38.42)|
U |cffffffff|Hitem:21877:0:0:0:0:0:0:1706722048:80|h[Netherweave Cloth]|h|r |N|Dalaran, Dalaran (45.66, 38.42)|
U |cffffffff|Hitem:25433:0:0:0:0:0:0:628884984:80|h[Obsidian Warbeads]|h|r |N|Dalaran, The Bank of Dalaran (53.35, 15.37)|
U |cffffffff|Hitem:26042:0:0:0:0:0:0:-1985076846:80|h[Oshu'gun Crystal Powder Sample]|h|r |N|Dalaran, The Bank of Dalaran (53.35, 15.37)|
U |cff1eff00|Hitem:24757:0:0:0:0:0:-34:853409828:80|h[Umbrafen Waistband of Nature Protection]|h|r |N|Dalaran, Dalaran (52.06, 26.56)|
U |cff1eff00|Hitem:24962:0:0:0:0:0:-45:-1885142996:80|h[Khan'aish Helmet of the Champion]|h|r |N|Dalaran, Dalaran (52.06, 26.56)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.33, 74.31)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.14, 61.48)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.31, 74.32)|
A The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.61, 58.75)|
U |cffffffff|Hitem:40946:0:0:0:0:0:0:2106968960:80|h[Anuniaq's Net]|h|r |N|Howling Fjord,  (33.15, 71.76)|
U |cffffffff|Hitem:34127:0:0:0:0:0:0:2092257408:80|h[Tasty Reef Fish]|h|r |N|Howling Fjord, Twin Shores (31.59, 73.90)|
- |QID|11472.1| |QO|Reef Bull led to a Reef Cow| |N|Howling Fjord, Twin Shores (31.04, 71.70)|
T The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.65, 58.82)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Howling Fjord,  (65.59, 69.93)|
U |cffffffff|Hitem:42104:0:0:0:0:0:0:919934816:80|h[Shoveltusk Ivory]|h|r |N|Dalaran, Cartier & Co. Fine Jewelry (40.45, 35.14)|
- |QID|12959.1| |QO|Glowing Ivory Figurine: 1/1| |N|Dalaran, Cartier & Co. Fine Jewelry (40.45, 35.14)|
T Shipment: Glowing Ivory Figurine |QID|12959| |N|Dalaran, Cartier & Co. Fine Jewelry (40.45, 35.14)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.34, 74.33)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.21, 61.49)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.30, 74.31)|
A The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.64, 58.78)|
U |cffffffff|Hitem:40946:0:0:0:0:0:0:1016140224:80|h[Anuniaq's Net]|h|r |N|Howling Fjord,  (34.16, 70.18)|
U |cffffffff|Hitem:34127:0:0:0:0:0:0:1695352704:80|h[Tasty Reef Fish]|h|r |N|Howling Fjord, Twin Shores (31.53, 74.02)|
- |QID|11472.1| |QO|Reef Bull led to a Reef Cow| |N|Howling Fjord, Twin Shores (31.03, 71.73)|
T The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.61, 58.82)|
A Mystery of the Infinite, Redux |QID|13343| |N|Dragonblight, Wyrmrest Temple (59.99, 54.41)|
U |cffffffff|Hitem:44450:0:0:0:0:0:0:906225792:80|h[Hourglass of Eternity]|h|r |N|Dragonblight, Bronze Dragonshrine (71.02, 41.18)|
- |QID|13343.1| |QO|Hourglass of Eternity protected from the Infinite Dragonflight.| |N|Dragonblight, Bronze Dragonshrine (70.96, 41.20)|
T Mystery of the Infinite, Redux |QID|13343| |N|Dragonblight, Wyrmrest Temple (60.00, 54.42)|
A Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.20, 54.33)|
- |QID|12372.1| |QO|Azure Dragon slain: 3/3| |N|Dragonblight, The Dragon Wastes (58.59, 57.50)|
- |QID|12372.2| |QO|Azure Drake slain: 5/5| |N|Dragonblight, The Dragon Wastes (57.57, 56.90)|
- |QID|12372.3| |QO|Destabilize the Azure Dragonshrine: 1/1| |N|Dragonblight, Azure Dragonshrine (55.47, 65.92)|
T Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.18, 54.33)|
A Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (64.02, 45.71)|
- |QID|11945.1| |QO|Kaskala Supplies: 8/8| |N|Borean Tundra, Kaskala (65.28, 47.90)|
T Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (63.93, 45.77)|
A Gem Perfection |QID|13002| |N|Borean Tundra, Warsong Hold (41.54, 53.33)|
- |QID|13002.1| |QO|Huge Citrine: 2/2| |N|Borean Tundra, Warsong Hold (41.98, 54.75)|
- |QID|13002.2| |QO|Dark Jade: 2/2| |N|Borean Tundra, Warsong Hold (41.98, 54.75)|
- |QID|13002.3| |QO|Shadow Crystal: 2/2| |N|Borean Tundra, Warsong Hold (41.98, 54.75)|
T Gem Perfection |QID|13002| |N|Borean Tundra, Warsong Hold (41.55, 53.37)|
U |cff1eff00|Hitem:41888:0:0:0:0:0:0:599079488:80|h[Small Velvet Bag]|h|r |N|Borean Tundra, Warsong Hold (42.28, 55.60)|
A Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.26, 34.47)|
A The Struggle Persists |QID|13124| |N|Borean Tundra, Transitus Shield (33.26, 34.47)|
A Corastrasza |QID|13412| |N|Borean Tundra, Transitus Shield (33.41, 34.38)|
U |cffffffff|Hitem:35506:0:0:0:0:0:0:1196800384:80|h[Raelorasz's Spear]|h|r |N|Borean Tundra, Coldarra (25.69, 31.32)|
- |QID|11940.1| |QO|Captured Nexus Drake: 1/1| |N|Borean Tundra, Transitus Shield (33.20, 34.22)|
T Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.33, 34.45)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Borean Tundra, Transitus Shield (33.17, 34.36)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Tanaris, Land's End Beach (62.51, 75.01)|
U |cffffffff|Hitem:7912:0:0:0:0:0:0:1019924576:80|h[Solid Stone]|h|r |N|Dalaran, Dalaran (52.37, 27.78)|
U |cffffffff|Hitem:7912:0:0:0:0:0:0:597661068:80|h[Solid Stone]|h|r |N|Dalaran, Dalaran (52.37, 27.78)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:895861792:80|h[Heavy Stone]|h|r |N|Dalaran, Dalaran (52.37, 27.78)|
U |cffffffff|Hitem:2772:0:0:0:0:0:0:627426336:80|h[Iron Ore]|h|r |N|Dalaran, Dalaran (52.37, 27.78)|
U |cffffffff|Hitem:3858:0:0:0:0:0:0:2075685760:80|h[Mithril Ore]|h|r |N|Dalaran, Dalaran (52.37, 27.78)|
U |cff1eff00|Hitem:2776:0:0:0:0:0:0:1053817280:80|h[Gold Ore]|h|r |N|Dalaran, Dalaran (52.37, 27.78)|
U |cffffffff|Hitem:4338:0:0:0:0:0:0:1378310592:80|h[Mageweave Cloth]|h|r |N|Dalaran, Dalaran (52.37, 27.78)|
U |cffffffff|Hitem:4306:0:0:0:0:0:0:2046037184:80|h[Silk Cloth]|h|r |N|Dalaran, Dalaran (52.37, 27.78)|
U |cff1eff00|Hitem:36193:0:0:0:0:0:-6:1794768943:80|h[Njord Shoulderguards of the Eagle]|h|r |N|Dalaran, Dalaran (52.37, 27.78)|
U |cffffffff|Hitem:9276:0:0:0:0:0:0:-1980494656:80|h[Pirate's Footlocker]|h|r |N|Dalaran, Dalaran (50.94, 28.60)|
U |cff1eff00|Hitem:41888:0:0:0:0:0:0:599079488:80|h[Small Velvet Bag]|h|r |N|Dalaran, Dalaran (50.94, 28.60)|
U |cffffffff|Hitem:9251:0:0:0:0:0:0:-891749016:80|h[Upper Map Fragment]|h|r |N|Dalaran, Dalaran (52.02, 27.68)|
U |cffffffff|Hitem:6256:0:0:0:0:0:0:0:80|h[Fishing Pole]|h|r |N|Thunder Bluff,  (46.93, 58.40)|
U |cff1eff00|Hitem:25978:0:0:0:0:0:0:227138934:80|h[Seth's Graphite Fishing Pole]|h|r |N|Thunder Bluff,  (46.93, 58.40)|
U |cffffffff|Hitem:6529:0:0:0:0:0:0:0:80|h[Shiny Bauble]|h|r |N|Thunder Bluff,  (46.93, 58.40)|
U |cffffffff|Hitem:6256:0:0:0:0:0:0:0:80|h[Fishing Pole]|h|r |N|Mulgore, Stonebull Lake (44.33, 61.06)|
U |cffa335ee|Hitem:42508:3849:0:0:0:0:0:235302592:80|h[Titansteel Shield Wall]|h|r |N|Mulgore, Stonebull Lake (44.33, 61.06)|
U |cff0070dd|Hitem:44734:0:0:0:0:0:0:165096544:80|h[Hammer of Quiet Mourning]|h|r |N|Mulgore, Stonebull Lake (44.33, 61.06)|
U |cffffffff|Hitem:43156:0:0:0:0:0:0:0:80|h[Tabard of the Wyrmrest Accord]|h|r |N|Mulgore, Stonebull Lake (44.33, 61.06)|
U |cffffffff|Hitem:6325:0:0:0:0:0:0:0:80|h[Recipe: Brilliant Smallfish]|h|r |N|Thunder Bluff,  (50.98, 51.89)|
U |cffffffff|Hitem:6328:0:0:0:0:0:0:0:80|h[Recipe: Longjaw Mud Snapper]|h|r |N|Thunder Bluff,  (51.21, 53.05)|
U |cffffffff|Hitem:6330:0:0:0:0:0:0:0:80|h[Recipe: Bristle Whisker Catfish]|h|r |N|Thunder Bluff,  (51.21, 53.05)|
U |cffffffff|Hitem:16083:0:0:0:0:0:0:0:80|h[Expert Fishing - The Bass and You]|h|r |N|Stranglethorn Vale, Booty Bay (25.79, 73.00)|
U |cffffffff|Hitem:6289:0:0:0:0:0:0:940745600:80|h[Raw Longjaw Mud Snapper]|h|r |N|The Barrens, Ratchet (62.17, 39.11)|
U |cffffffff|Hitem:6289:0:0:0:0:0:0:1764760960:80|h[Raw Longjaw Mud Snapper]|h|r |N|The Barrens, Ratchet (62.17, 39.11)|
U |cffffffff|Hitem:4592:0:0:0:0:0:0:1678250880:80|h[Longjaw Mud Snapper]|h|r |N|The Barrens, Ratchet (62.17, 39.11)|
U |cffffffff|Hitem:4592:0:0:0:0:0:0:808323520:80|h[Longjaw Mud Snapper]|h|r |N|The Barrens, Ratchet (62.17, 39.11)|
U |cffffffff|Hitem:6289:0:0:0:0:0:0:1624401920:80|h[Raw Longjaw Mud Snapper]|h|r |N|The Barrens, Ratchet (62.14, 39.18)|
U |cffffffff|Hitem:6309:0:0:0:0:0:0:-2073700352:80|h[17 Pound Catfish]|h|r |N|The Barrens, Ratchet (62.14, 39.18)|
U |cffffffff|Hitem:40772:0:0:0:0:0:0:1430051724:80|h[Gnomish Army Knife]|h|r |N|Stonetalon Mountains, Sun Rock Retreat (45.24, 59.52)|
U |cff1eff00|Hitem:9801:0:0:0:0:0:1104:488091376:80|h[Superior Belt of the Boar]|h|r |N|The Barrens, The Crossroads (52.04, 30.50)|
U |cff1eff00|Hitem:9801:0:0:0:0:0:764:1103276032:80|h[Superior Belt of the Owl]|h|r |N|The Barrens, The Crossroads (52.04, 30.50)|
U |cff1eff00|Hitem:25978:0:0:0:0:0:0:227138934:80|h[Seth's Graphite Fishing Pole]|h|r |N|The Barrens, The Stagnant Oasis (55.92, 42.27)|
U |cffffffff|Hitem:20708:0:0:0:0:0:0:1535902592:80|h[Tightly Sealed Trunk]|h|r |N|The Barrens, The Stagnant Oasis (55.92, 42.27)|
U |cffffffff|Hitem:16072:0:0:0:0:0:0:0:80|h[Expert Cookbook]|h|r |N|Desolace, Shadowprey Village (26.16, 69.83)|
U |cffffffff|Hitem:6522:0:0:0:0:0:0:1596788096:80|h[Deviate Fish]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:6522:0:0:0:0:0:0:1093681408:80|h[Deviate Fish]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:6522:0:0:0:0:0:0:1667880832:80|h[Deviate Fish]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:6522:0:0:0:0:0:0:649811008:80|h[Deviate Fish]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:6289:0:0:0:0:0:0:2074541312:80|h[Raw Longjaw Mud Snapper]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:6289:0:0:0:0:0:0:1735441152:80|h[Raw Longjaw Mud Snapper]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:6289:0:0:0:0:0:0:281777916:80|h[Raw Longjaw Mud Snapper]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:6289:0:0:0:0:0:0:-2049029120:80|h[Raw Longjaw Mud Snapper]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:6291:0:0:0:0:0:0:1905516032:80|h[Raw Brilliant Smallfish]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:6308:0:0:0:0:0:0:412490976:80|h[Raw Bristle Whisker Catfish]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:6308:0:0:0:0:0:0:533799024:80|h[Raw Bristle Whisker Catfish]|h|r |N|Desolace, Shadowprey Village (24.90, 68.76)|
U |cffffffff|Hitem:17062:0:0:0:0:0:0:0:80|h[Recipe: Mithril Head Trout]|h|r |N|Desolace, Shadowprey Village (21.61, 73.97)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Desolace, Shadowprey Village (21.61, 73.97)|
A Shipment: Blood Jade Amulet  |QID|12958| |N|Dalaran, Cartier & Co. Fine Jewelry (40.32, 35.06)|
A Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.20, 54.33)|
- |QID|12372.1| |QO|Azure Dragon slain: 3/3| |N|Dragonblight, Wyrmrest Temple (58.15, 56.12)|
- |QID|12372.2| |QO|Azure Drake slain: 5/5| |N|Dragonblight, The Dragon Wastes (57.64, 59.21)|
- |QID|12372.3| |QO|Destabilize the Azure Dragonshrine: 1/1| |N|Dragonblight, Azure Dragonshrine (55.56, 65.83)|
T Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.19, 54.38)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.31, 74.32)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.29, 64.63)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.32, 74.33)|
A The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.62, 58.74)|
U |cffffffff|Hitem:40946:0:0:0:0:0:0:628331584:80|h[Anuniaq's Net]|h|r |N|Howling Fjord,  (34.19, 70.19)|
U |cffffffff|Hitem:34127:0:0:0:0:0:0:1673756800:80|h[Tasty Reef Fish]|h|r |N|Howling Fjord, Twin Shores (31.59, 74.00)|
- |QID|11472.1| |QO|Reef Bull led to a Reef Cow| |N|Howling Fjord, Twin Shores (31.01, 71.63)|
T The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.66, 58.82)|
A Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (63.93, 45.78)|
- |QID|11945.1| |QO|Kaskala Supplies: 8/8| |N|Borean Tundra, Kaskala (66.13, 46.08)|
T Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (63.94, 45.78)|
A Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.31, 34.43)|
U |cffffffff|Hitem:35506:0:0:0:0:0:0:1765640576:80|h[Raelorasz's Spear]|h|r |N|Borean Tundra, Coldarra (26.82, 32.06)|
- |QID|11940.1| |QO|Captured Nexus Drake: 1/1| |N|Borean Tundra, Transitus Shield (33.28, 34.43)|
T Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.28, 34.43)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Borean Tundra, Transitus Shield (33.23, 34.23)|
U |cffffffff|Hitem:41989:0:0:0:0:0:0:1535598080:80|h[Vrykul Amulet]|h|r |N|Dalaran, Cartier & Co. Fine Jewelry (40.30, 34.89)|
- |QID|12958.1| |QO|Blood Jade Amulet: 1/1| |N|Dalaran, Cartier & Co. Fine Jewelry (40.30, 34.89)|
T Shipment: Blood Jade Amulet  |QID|12958| |N|Dalaran, Cartier & Co. Fine Jewelry (40.30, 34.89)|
U |cff0070dd|Hitem:41783:0:0:0:0:0:0:1275654400:80|h[Design: Purified Twilight Opal]|h|r |N|Dalaran, Cartier & Co. Fine Jewelry (40.30, 34.89)|
A Shipment: Blood Jade Amulet  |QID|12958| |N|Dalaran, Cartier & Co. Fine Jewelry (40.30, 34.89)|
A Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.20, 54.33)|
- |QID|12372.1| |QO|Azure Dragon slain: 3/3| |N|Dragonblight, Wyrmrest Temple (57.90, 56.28)|
- |QID|12372.3| |QO|Destabilize the Azure Dragonshrine: 1/1| |N|Dragonblight, Azure Dragonshrine (55.68, 66.04)|
- |QID|12372.2| |QO|Azure Drake slain: 5/5| |N|Dragonblight, Wyrmrest Temple (59.22, 57.63)|
T Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.22, 54.35)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.34, 74.33)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.00, 61.79)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.30, 74.36)|
A The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.62, 58.77)|
U |cffffffff|Hitem:40946:0:0:0:0:0:0:2068584704:80|h[Anuniaq's Net]|h|r |N|Howling Fjord,  (34.16, 70.18)|
U |cffffffff|Hitem:34127:0:0:0:0:0:0:1483461376:80|h[Tasty Reef Fish]|h|r |N|Howling Fjord, Twin Shores (31.56, 73.97)|
- |QID|11472.1| |QO|Reef Bull led to a Reef Cow| |N|Howling Fjord, Twin Shores (31.01, 71.76)|
T The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.66, 58.78)|
A Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (63.98, 45.66)|
- |QID|11945.1| |QO|Kaskala Supplies: 8/8| |N|Borean Tundra, Kaskala (66.64, 48.62)|
T Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (64.01, 45.68)|
A Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.30, 34.47)|
U |cffffffff|Hitem:35506:0:0:0:0:0:0:157158768:80|h[Raelorasz's Spear]|h|r |N|Borean Tundra, Coldarra (26.91, 31.95)|
- |QID|11940.1| |QO|Captured Nexus Drake: 1/1| |N|Borean Tundra, Transitus Shield (33.22, 34.43)|
T Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.25, 34.49)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Borean Tundra, Transitus Shield (33.25, 34.49)|
U |cffffffff|Hitem:43009:0:0:0:0:0:0:-1797848960:80|h[Shoveltusk Flank]|h|r |N|Dalaran, The Bank of Dalaran (54.66, 19.23)|
U |cffffffff|Hitem:43013:0:0:0:0:0:0:-1665838976:80|h[Chilled Meat]|h|r |N|Dalaran, The Bank of Dalaran (54.66, 19.23)|
U |cffffffff|Hitem:43011:0:0:0:0:0:0:1511619008:80|h[Worg Haunch]|h|r |N|Dalaran, The Bank of Dalaran (54.66, 19.23)|
U |cffffffff|Hitem:6256:0:0:0:0:0:0:0:80|h[Fishing Pole]|h|r |N|Dalaran, The Bank of Dalaran (54.53, 15.99)|
U |cff1eff00|Hitem:4566:0:0:0:0:0:841:-2055671680:80|h[Sturdy Quarterstaff of the Eagle]|h|r |N|Dalaran, Dalaran (52.26, 27.14)|
U |cffffffff|Hitem:6310:0:0:0:0:0:0:1306876672:80|h[19 Pound Catfish]|h|r |N|Dalaran, Dalaran (52.06, 26.50)|
U |cffffffff|Hitem:41989:0:0:0:0:0:0:1643460352:80|h[Vrykul Amulet]|h|r |N|Dalaran, Cartier & Co. Fine Jewelry (40.20, 35.04)|
- |QID|12958.1| |QO|Blood Jade Amulet: 1/1| |N|Dalaran, Cartier & Co. Fine Jewelry (40.20, 35.04)|
T Shipment: Blood Jade Amulet  |QID|12958| |N|Dalaran, Cartier & Co. Fine Jewelry (40.20, 35.04)|
A You Too Good. |QID|6608| |N|Orgrimmar, Valley of Honor (69.59, 28.91)|
T You Too Good. |QID|6608| |N|Dustwallow Marsh, Nat's Landing (58.70, 60.21)|
A Nat Pagle, Angler Extreme |QID|6607| |N|Dustwallow Marsh, Nat's Landing (58.70, 60.21)|
- |QID|6607.4| |QO|Savage Coast Blue Sailfin: 1/1| |N|Stranglethorn Vale, The Savage Coast (33.02, 32.11)|
- |QID|6607.2| |QO|Misty Reed Mahi Mahi: 1/1| |N|Swamp of Sorrows, Misty Reed Strand (79.19, 95.26)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Swamp of Sorrows,  (38.34, 56.16)|
U |cffffffff|Hitem:20708:0:0:0:0:0:0:1535902592:80|h[Tightly Sealed Trunk]|h|r |N|Thunder Bluff,  (41.00, 53.41)|
U |cffffffff|Hitem:7973:0:0:0:0:0:0:1795729536:80|h[Big-mouth Clam]|h|r |N|Thunder Bluff,  (41.00, 53.41)|
U |cffffffff|Hitem:7974:0:0:0:0:0:0:111063248:80|h[Zesty Clam Meat]|h|r |N|Thunder Bluff,  (44.76, 59.20)|
U |cffffffff|Hitem:2319:0:0:0:0:0:0:-1346372187:80|h[Medium Leather]|h|r |N|Thunder Bluff,  (44.76, 59.20)|
U |cffffffff|Hitem:2996:0:0:0:0:0:0:-1077936731:80|h[Bolt of Linen Cloth]|h|r |N|Thunder Bluff,  (44.76, 59.20)|
U |cffffffff|Hitem:6532:0:0:0:0:0:0:0:80|h[Bright Baubles]|h|r |N|Feralas, Verdantis River (62.95, 52.49)|
- |QID|6607.1| |QO|Feralas Ahi: 1/1| |N|Feralas, Verdantis River (62.95, 52.49)|
- |QID|6607.3| |QO|Sar'theris Striker: 1/1| |N|Desolace, Sar'theris Strand (25.92, 77.39)|
T Nat Pagle, Angler Extreme |QID|6607| |N|Dustwallow Marsh, Nat's Landing (58.71, 60.19)|
U |cffffffff|Hitem:13941:0:0:0:0:0:0:0:80|h[Recipe: Filet of Redgill]|h|r |N|Dustwallow Marsh, The Quagmire (37.07, 59.53)|
U |cffffffff|Hitem:6358:0:0:0:0:0:0:-2084797952:80|h[Oily Blackmouth]|h|r |N|Dustwallow Marsh, Mudsprocket (42.00, 73.20)|
U |cffffffff|Hitem:6359:0:0:0:0:0:0:554169244:80|h[Firefin Snapper]|h|r |N|Dustwallow Marsh, Mudsprocket (42.00, 73.20)|
U |cffffffff|Hitem:3820:0:0:0:0:0:0:1403931264:80|h[Stranglekelp]|h|r |N|Dustwallow Marsh, Mudsprocket (42.00, 73.20)|
U |cffffffff|Hitem:37097:0:0:0:0:0:0:1103865170:80|h[Scroll of Spirit VII]|h|r |N|Dustwallow Marsh, Mudsprocket (42.00, 73.21)|
U |cffffffff|Hitem:33470:0:0:0:0:0:0:955669760:80|h[Frostweave Cloth]|h|r |N|Dustwallow Marsh, Mudsprocket (42.00, 73.21)|
- |QID|6610.3| |QO|Alterac Swiss: 20/20| |N|Tanaris, Gadgetzan (52.57, 28.11)|
A Clamlette Surprise |QID|6610| |N|Tanaris, Gadgetzan (52.57, 28.11)|
- |QID|6610.2| |QO|Zesty Clam Meat: 10/10| |N|Tanaris, Gadgetzan (52.30, 27.82)|
U |cffffffff|Hitem:6308:0:0:0:0:0:0:1765677312:80|h[Raw Bristle Whisker Catfish]|h|r |N|Tanaris, Gadgetzan (52.32, 27.84)|
U |cffffffff|Hitem:6308:0:0:0:0:0:0:848951488:80|h[Raw Bristle Whisker Catfish]|h|r |N|Tanaris, Gadgetzan (52.32, 27.84)|
U |cffffffff|Hitem:6308:0:0:0:0:0:0:792664736:80|h[Raw Bristle Whisker Catfish]|h|r |N|Tanaris, Gadgetzan (52.32, 27.84)|
U |cffffffff|Hitem:6308:0:0:0:0:0:0:1302432960:80|h[Raw Bristle Whisker Catfish]|h|r |N|Tanaris, Gadgetzan (52.32, 27.84)|
U |cffffffff|Hitem:6308:0:0:0:0:0:0:1976280064:80|h[Raw Bristle Whisker Catfish]|h|r |N|Tanaris, Gadgetzan (52.32, 27.84)|
- |QID|6610.1| |QO|Giant Egg: 12/12| |N|Tanaris, Gadgetzan (52.32, 27.84)|
T Clamlette Surprise |QID|6610| |N|Tanaris, Gadgetzan (52.58, 28.11)|
U |cffffffff|Hitem:8365:0:0:0:0:0:0:1229262976:80|h[Raw Mithril Head Trout]|h|r |N|Tanaris, Gadgetzan (52.34, 27.86)|
U |cffffffff|Hitem:8365:0:0:0:0:0:0:1470449664:80|h[Raw Mithril Head Trout]|h|r |N|Tanaris, Gadgetzan (52.34, 27.86)|
U |cffffffff|Hitem:8365:0:0:0:0:0:0:690952832:80|h[Raw Mithril Head Trout]|h|r |N|Tanaris, Gadgetzan (52.34, 27.86)|
U |cffffffff|Hitem:8365:0:0:0:0:0:0:813026496:80|h[Raw Mithril Head Trout]|h|r |N|Tanaris, Gadgetzan (52.34, 27.86)|
U |cffffffff|Hitem:13946:0:0:0:0:0:0:0:80|h[Recipe: Poached Sunscale Salmon]|h|r |N|Tanaris, Steamwheedle Port (66.65, 22.17)|
U |cffffffff|Hitem:13945:0:0:0:0:0:0:0:80|h[Recipe: Nightfin Soup]|h|r |N|Tanaris, Steamwheedle Port (66.65, 22.17)|
U |cffffffff|Hitem:13939:0:0:0:0:0:0:0:80|h[Recipe: Spotted Yellowtail]|h|r |N|Tanaris, Steamwheedle Port (66.65, 22.17)|
U |cffffffff|Hitem:7912:0:0:0:0:0:0:-1890423808:80|h[Solid Stone]|h|r |N|Tanaris, Gadgetzan (52.27, 27.82)|
U |cffffffff|Hitem:2838:0:0:0:0:0:0:1103000256:80|h[Heavy Stone]|h|r |N|Tanaris, Gadgetzan (52.27, 27.82)|
U |cffffffff|Hitem:3858:0:0:0:0:0:0:2136108032:80|h[Mithril Ore]|h|r |N|Tanaris, Gadgetzan (52.27, 27.82)|
U |cffffffff|Hitem:2772:0:0:0:0:0:0:834564800:80|h[Iron Ore]|h|r |N|Tanaris, Gadgetzan (52.27, 27.82)|
U |cff1eff00|Hitem:2776:0:0:0:0:0:0:953835392:80|h[Gold Ore]|h|r |N|Tanaris, Gadgetzan (52.27, 27.82)|
U |cff1eff00|Hitem:2775:0:0:0:0:0:0:1711203200:80|h[Silver Ore]|h|r |N|Tanaris, Gadgetzan (52.27, 27.82)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Tanaris, Gadgetzan (52.07, 26.97)|
A Shipment: Wicked Sun Brooch  |QID|12960| |N|Dalaran, Cartier & Co. Fine Jewelry (40.24, 35.18)|
A Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.20, 54.33)|
- |QID|12372.1| |QO|Azure Dragon slain: 3/3| |N|Dragonblight, The Dragon Wastes (57.40, 60.52)|
- |QID|12372.3| |QO|Destabilize the Azure Dragonshrine: 1/1| |N|Dragonblight, Azure Dragonshrine (55.61, 65.91)|
- |QID|12372.2| |QO|Azure Drake slain: 5/5| |N|Dragonblight, Azure Dragonshrine (55.42, 64.86)|
T Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.22, 54.20)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.34, 74.35)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.17, 61.48)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.29, 74.27)|
A The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.62, 58.73)|
U |cffffffff|Hitem:40946:0:0:0:0:0:0:1340206080:80|h[Anuniaq's Net]|h|r |N|Howling Fjord,  (34.17, 70.20)|
U |cffffffff|Hitem:34127:0:0:0:0:0:0:1320080256:80|h[Tasty Reef Fish]|h|r |N|Howling Fjord, Twin Shores (31.68, 73.81)|
- |QID|11472.1| |QO|Reef Bull led to a Reef Cow| |N|Howling Fjord, Twin Shores (31.03, 71.72)|
T The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.65, 58.79)|
A Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (64.02, 45.72)|
- |QID|11945.1| |QO|Kaskala Supplies: 8/8| |N|Borean Tundra, Kaskala (65.94, 47.75)|
T Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (64.01, 45.67)|
A Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.28, 34.47)|
U |cffffffff|Hitem:35506:0:0:0:0:0:0:404064352:80|h[Raelorasz's Spear]|h|r |N|Borean Tundra, Coldarra (24.48, 25.02)|
- |QID|11940.1| |QO|Captured Nexus Drake: 1/1| |N|Borean Tundra, Transitus Shield (33.28, 34.44)|
T Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.28, 34.44)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Borean Tundra, Transitus Shield (33.24, 34.27)|
U |cffffffff|Hitem:42105:0:0:0:0:0:0:1265804720:80|h[Iron Dwarf Brooch]|h|r |N|Dalaran, Magus Commerce Exchange (40.43, 31.92)|
- |QID|12960.1| |QO|Wicked Sun Brooch: 1/1| |N|Dalaran, Magus Commerce Exchange (40.43, 31.92)|
T Shipment: Wicked Sun Brooch  |QID|12960| |N|Dalaran, Cartier & Co. Fine Jewelry (40.35, 35.12)|
U |cff0070dd|Hitem:40094:0:0:0:0:0:0:1601269632:80|h[Dazzling Forest Emerald]|h|r |N|Dalaran, Magus Commerce Exchange (40.42, 32.38)|
U |cff0070dd|Hitem:40094:0:0:0:0:0:0:2050808832:80|h[Dazzling Forest Emerald]|h|r |N|Dalaran, Magus Commerce Exchange (40.42, 32.38)|
U |cff0070dd|Hitem:40094:0:0:0:0:0:0:1370544000:80|h[Dazzling Forest Emerald]|h|r |N|Dalaran, Magus Commerce Exchange (40.42, 32.38)|
U |cff0070dd|Hitem:40094:0:0:0:0:0:0:1254960000:80|h[Dazzling Forest Emerald]|h|r |N|Dalaran, Magus Commerce Exchange (40.42, 32.38)|
U |cff0070dd|Hitem:40094:0:0:0:0:0:0:1307729664:80|h[Dazzling Forest Emerald]|h|r |N|Dalaran, Magus Commerce Exchange (40.42, 32.38)|
U |cff0070dd|Hitem:40094:0:0:0:0:0:0:532643776:80|h[Dazzling Forest Emerald]|h|r |N|Dalaran, Magus Commerce Exchange (40.42, 32.38)|
U |cff0070dd|Hitem:40094:0:0:0:0:0:0:1184522752:80|h[Dazzling Forest Emerald]|h|r |N|Dalaran, Magus Commerce Exchange (40.42, 32.38)|
U |cff0070dd|Hitem:40094:0:0:0:0:0:0:1324165504:80|h[Dazzling Forest Emerald]|h|r |N|Dalaran, Magus Commerce Exchange (40.42, 32.38)|
U |cff0070dd|Hitem:40094:0:0:0:0:0:0:1673033088:80|h[Dazzling Forest Emerald]|h|r |N|Dalaran, Magus Commerce Exchange (40.42, 32.38)|
U |cff0070dd|Hitem:40094:0:0:0:0:0:0:1091526016:80|h[Dazzling Forest Emerald]|h|r |N|Dalaran, Magus Commerce Exchange (40.42, 32.38)|
U |cff0070dd|Hitem:42315:0:0:0:0:0:0:0:80|h[Design: Thick Dragon's Eye]|h|r |N|Dalaran, Cartier & Co. Fine Jewelry (40.43, 35.11)|
U |cffffffff|Hitem:13947:0:0:0:0:0:0:0:80|h[Recipe: Lobster Stew]|h|r |N|Feralas, Wildwind Lake (74.90, 49.24)|
U |cffffffff|Hitem:13948:0:0:0:0:0:0:0:80|h[Recipe: Mightfish Steak]|h|r |N|Feralas, Wildwind Lake (74.90, 49.24)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Feralas, Wildwind Lake (74.92, 49.39)|
U |cffffffff|Hitem:13760:0:0:0:0:0:0:-1945025280:80|h[Raw Sunscale Salmon]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
U |cffffffff|Hitem:13760:0:0:0:0:0:0:1628906240:80|h[Raw Sunscale Salmon]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
U |cffffffff|Hitem:8365:0:0:0:0:0:0:1981154688:80|h[Raw Mithril Head Trout]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
U |cffffffff|Hitem:13758:0:0:0:0:0:0:1402996608:80|h[Raw Redgill]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
U |cffffffff|Hitem:13758:0:0:0:0:0:0:-1972056704:80|h[Raw Redgill]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
U |cffffffff|Hitem:13758:0:0:0:0:0:0:897041840:80|h[Raw Redgill]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
U |cffffffff|Hitem:6362:0:0:0:0:0:0:2102135296:80|h[Raw Rockscale Cod]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
U |cffffffff|Hitem:6310:0:0:0:0:0:0:1279113984:80|h[19 Pound Catfish]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
U |cffffffff|Hitem:13757:0:0:0:0:0:0:1337765728:80|h[Lightning Eel]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
U |cffffffff|Hitem:13757:0:0:0:0:0:0:2053107200:80|h[Lightning Eel]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
U |cffffffff|Hitem:6358:0:0:0:0:0:0:1353612224:80|h[Oily Blackmouth]|h|r |N|Dalaran, Dalaran (59.02, 48.22)|
A Shipment: Glowing Ivory Figurine |QID|12959| |N|Dalaran, Cartier & Co. Fine Jewelry (40.37, 35.23)|
A Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.20, 54.33)|
- |QID|12372.1| |QO|Azure Dragon slain: 3/3| |N|Dragonblight, Wyrmrest Temple (57.89, 55.36)|
- |QID|12372.3| |QO|Destabilize the Azure Dragonshrine: 1/1| |N|Dragonblight, Azure Dragonshrine (55.46, 65.87)|
- |QID|12372.2| |QO|Azure Drake slain: 5/5| |N|Dragonblight, Wyrmrest Temple (61.24, 54.30)|
T Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.24, 54.34)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.27, 74.26)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.44, 64.20)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.31, 74.34)|
A The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.61, 58.74)|
U |cffffffff|Hitem:40946:0:0:0:0:0:0:802684160:80|h[Anuniaq's Net]|h|r |N|Howling Fjord,  (34.15, 70.16)|
U |cffffffff|Hitem:34127:0:0:0:0:0:0:1997916288:80|h[Tasty Reef Fish]|h|r |N|Howling Fjord, Twin Shores (31.61, 74.04)|
- |QID|11472.1| |QO|Reef Bull led to a Reef Cow| |N|Howling Fjord, Twin Shores (31.02, 71.83)|
T The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.64, 58.84)|
A Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (64.00, 45.72)|
- |QID|11945.1| |QO|Kaskala Supplies: 8/8| |N|Borean Tundra, Kaskala (65.77, 48.32)|
T Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (64.03, 45.70)|
U |cffffffff|Hitem:42104:0:0:0:0:0:0:1683506048:80|h[Shoveltusk Ivory]|h|r |N|Borean Tundra, Kaskala (64.03, 45.70)|
- |QID|12959.1| |QO|Glowing Ivory Figurine: 1/1| |N|Borean Tundra, Kaskala (64.03, 45.70)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Borean Tundra, Kaskala (64.03, 45.70)|
T Shipment: Glowing Ivory Figurine |QID|12959| |N|Dalaran, Cartier & Co. Fine Jewelry (40.30, 35.27)|
U |cffffffff|Hitem:39898:0:0:0:0:0:0:-596643096:80|h[Cobra Hatchling]|h|r |N|Dalaran, Magus Commerce Exchange (40.47, 32.02)|
U |cffffffff|Hitem:39899:0:0:0:0:0:0:926087113:80|h[White Tickbird Hatchling]|h|r |N|Dalaran, Magus Commerce Exchange (40.47, 32.02)|
U |cffffffff|Hitem:39896:0:0:0:0:0:0:170980754:80|h[Tickbird Hatchling]|h|r |N|Dalaran, Magus Commerce Exchange (40.47, 32.02)|
A Shipment: Shifting Sun Curio  |QID|12963| |N|Dalaran, Cartier & Co. Fine Jewelry (40.32, 35.33)|
A Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.20, 54.33)|
- |QID|12372.1| |QO|Azure Dragon slain: 3/3| |N|Dragonblight, Wyrmrest Temple (58.32, 56.31)|
- |QID|12372.3| |QO|Destabilize the Azure Dragonshrine: 1/1| |N|Dragonblight, Azure Dragonshrine (55.64, 65.71)|
- |QID|12372.2| |QO|Azure Drake slain: 5/5| |N|Dragonblight, Azure Dragonshrine (55.07, 63.26)|
T Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.22, 54.35)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.32, 74.35)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.17, 61.43)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.28, 74.35)|
A The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.63, 58.78)|
U |cffffffff|Hitem:40946:0:0:0:0:0:0:580273792:80|h[Anuniaq's Net]|h|r |N|Howling Fjord,  (34.13, 70.20)|
U |cffffffff|Hitem:34127:0:0:0:0:0:0:1601728256:80|h[Tasty Reef Fish]|h|r |N|Howling Fjord, Twin Shores (31.48, 74.12)|
- |QID|11472.1| |QO|Reef Bull led to a Reef Cow| |N|Howling Fjord, Twin Shores (31.00, 71.78)|
T The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.63, 58.82)|
A Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (64.01, 45.69)|
- |QID|11945.1| |QO|Kaskala Supplies: 8/8| |N|Borean Tundra, Kaskala (65.55, 47.03)|
T Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (63.99, 45.81)|
A Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.28, 34.45)|
U |cffffffff|Hitem:35506:0:0:0:0:0:0:343431232:80|h[Raelorasz's Spear]|h|r |N|Borean Tundra, Coldarra (25.18, 30.73)|
- |QID|11940.1| |QO|Captured Nexus Drake: 1/1| |N|Borean Tundra, Transitus Shield (33.31, 34.44)|
T Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.31, 34.44)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Borean Tundra, Transitus Shield (33.31, 34.44)|
U |cffffffff|Hitem:42108:0:0:0:0:0:0:1167151552:80|h[Scourge Curio]|h|r |N|Dalaran, Magus Commerce Exchange (40.39, 32.16)|
- |QID|12963.1| |QO|Shifting Sun Curio: 1/1| |N|Dalaran, Magus Commerce Exchange (40.39, 32.16)|
T Shipment: Shifting Sun Curio  |QID|12963| |N|Dalaran, Cartier & Co. Fine Jewelry (40.26, 35.26)|
A Shipment: Bright Armor Relic |QID|12962| |N|Dalaran, Cartier & Co. Fine Jewelry (40.35, 35.40)|
A Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.20, 54.33)|
- |QID|12372.1| |QO|Azure Dragon slain: 3/3| |N|Dragonblight, Wyrmrest Temple (57.76, 54.19)|
- |QID|12372.2| |QO|Azure Drake slain: 5/5| |N|Dragonblight, The Dragon Wastes (57.39, 55.45)|
- |QID|12372.3| |QO|Destabilize the Azure Dragonshrine: 1/1| |N|Dragonblight, Azure Dragonshrine (55.50, 66.13)|
T Defending Wyrmrest Temple |QID|12372| |N|Dragonblight, Wyrmrest Temple (59.26, 54.34)|
A Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.30, 74.33)|
- |QID|11960.1| |QO|Snowfall Glade Pup: 12/12| |N|Dragonblight, Snowfall Glade (47.18, 61.34)|
T Planning for the Future |QID|11960| |N|Dragonblight, Moa'ki Harbor (48.30, 74.32)|
A The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.63, 58.78)|
U |cffffffff|Hitem:40946:0:0:0:0:0:0:1268631808:80|h[Anuniaq's Net]|h|r |N|Howling Fjord,  (34.16, 70.20)|
U |cffffffff|Hitem:34127:0:0:0:0:0:0:559561600:80|h[Tasty Reef Fish]|h|r |N|Howling Fjord, Twin Shores (31.52, 73.94)|
- |QID|11472.1| |QO|Reef Bull led to a Reef Cow| |N|Howling Fjord, Twin Shores (31.03, 71.75)|
T The Way to His Heart... |QID|11472| |N|Howling Fjord, Kamagua (24.65, 58.83)|
A Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (64.01, 45.77)|
- |QID|11945.1| |QO|Kaskala Supplies: 8/8| |N|Borean Tundra, Kaskala (64.86, 46.24)|
T Preparing for the Worst |QID|11945| |N|Borean Tundra, Kaskala (63.97, 45.78)|
A Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.27, 34.50)|
U |cffffffff|Hitem:35506:0:0:0:0:0:0:1445941504:80|h[Raelorasz's Spear]|h|r |N|Borean Tundra, Coldarra (25.21, 30.20)|
- |QID|11940.1| |QO|Captured Nexus Drake: 1/1| |N|Borean Tundra, Transitus Shield (33.28, 34.44)|
T Drake Hunt |QID|11940| |N|Borean Tundra, Transitus Shield (33.28, 34.44)|
U |cffffffff|Hitem:6948:0:0:0:0:0:0:0:80|h[Hearthstone]|h|r |N|Borean Tundra, Transitus Shield (33.40, 34.18)|
U |cffffffff|Hitem:42107:0:0:0:0:0:0:981604672:80|h[Elemental Armor Scrap]|h|r |N|Dalaran, Magus Commerce Exchange (40.56, 31.81)|
- |QID|12962.1| |QO|Bright Armor Relic: 1/1| |N|Dalaran, Magus Commerce Exchange (40.56, 31.81)|
T Shipment: Bright Armor Relic |QID|12962| |N|Dalaran, Cartier & Co. Fine Jewelry (40.43, 35.12)|"
