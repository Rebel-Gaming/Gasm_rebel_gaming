TourGuide:RegisterGuide("The Barrens (25)", "Thousand Needles (25-26)", "Horde", function()
return [[
F Camp Taurajo
A Melor Sends Word |QID|1130| |T|
T Ishamuhale |QID|882| |O| |NORAF|
A Enraged Thunder Lizards |QID|907| |O| |PRE|Ishamuhale| |NORAF|
h Camp Taurajo |NORAF|
A A New Ore Sample |QID|1153| |NORAF|
C Enraged Thunder Lizards |QID|907| |O| |PRE|Ishamuhale| |NORAF|
C Revenge of Gann (Part 1) |QID|846| |N|Keel two dorfs at Bael'dun Keep (49.31, 84.54), it'll make you feel alright.|
T Revenge of Gann (Part 1) |QID|846| |N|Back up patroling on Southern Gold Road (46.18, 81.23)|
A Revenge of Gann (Part 2) |QID|849|
C Revenge of Gann (Part 2) |QID|849| |N|Blow up the Flying Machine (46.97, 85.68)|
T Revenge of Gann (Part 2) |QID|849|

R The Great Lift
T Calling in the Reserves |QID|5881|
A Message to Freewind Post |QID|4542|
]] end)
