TourGuide:RegisterGuide("Azshara (46-47)", "Stranglethorn Vale (47)", "Horde", function()
return [[
F Splintertree Post |N|Ashenvale| |NORAF|
R Azshara |N|Go east dur!| |NORAF|

A Spiritual Unrest |N|To the south of the road as you enter the zone (11.4,78.2)| |QID|5535| |NORAF|
A A Land Filled with Hatred |QID|5536| |NORAF|
C Spiritual Unrest |N|Ghosts in the ruins north of the road (17,66)| |QID|5535| |NORAF|
C A Land Filled with Hatred |N|Further north, more ruins containing satyrs (20,62)| |QID|5536| |NORAF|
T Spiritual Unrest |QID|5535| |NORAF|
T A Land Filled with Hatred |QID|5536| |NORAF|

R Valormok |N|North of the road, on the mountain's edge (21,52)| |NORAF|
T Betrayed (Part 1) |QID|3504| |N|Skip the follow-up.| |NORAF|

H Orgrimmar |NORAF|
F Undercity |NORAF|
A Seeping Corruption (Part 1) |N|Apothecarium Quarter| |QID|3568| |NORAF|
A Errand for Apothecary Zinge (Part 1) |QID|232| |NORAF|
T Errand for Apothecary Zinge (Part 1) |N|Out in other room| |QID|232| |NORAF|
A Errand for Apothecary Zinge (Part 2) |QID|238| |NORAF|
T Errand for Apothecary Zinge (Part 2) |QID|238| |NORAF|
A Into the Field |QID|243| |NORAF|
]]
end)
