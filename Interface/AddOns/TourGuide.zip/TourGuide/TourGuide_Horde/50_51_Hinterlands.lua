
TourGuide:RegisterGuide("The Hinterlands (50-51)", "Un'Goro Crater (51-53)", "Horde", function()
return [[
F Tarren Mill |NORAF|
R The Hinterlands |N|Entrance at (86,30)| |Z|Hillsbrad Foothills| |NORAF|
T Ripple Recovery |N|Go to (26,48) Skip follow up quest| |QID|650| |NORAF|
T The Atal'ai Exile |N| Go south to (33,75), skip follow up| |QID|1429| |NORAF|
C Sprinkle's Secret Ingredient |N| At the lake (41,60)| |QID|2641| |NORAF|

R Revantusk Village |N|(77,79)| |NORAF|
A Snapjaws, Mon! |QID|7815| |NORAF|
A Gammerita, Mon! |QID|7816| |NORAF|
A Lard Lost His Lunch |QID|7840| |NORAF|

C Snapjaws, Mon! |QID|7815| |NORAF|
C Gammerita, Mon! |QID|7816| |NORAF|
C Whiskey Slim's Lost Grog |QID|580| |NORAF|
T Cortello's Riddle |N| At (80,46) a little chest in the water| |QID|626| |NORAF|
C Lard Lost His Lunch |N| (84,42)| |QID|7840| |NORAF|
T Snapjaws, Mon! |QID|7815| |NORAF|
T Gammerita, Mon! |QID|7816| |NORAF|
T Lard Lost His Lunch |QID|7840| |NORAF|
]]
end)
