TourGuide:RegisterGuide("Hillsbrad Foothills (29-30)", "Arathi Highlands (30)", "Horde", function()
return [[
F Orgrimmar |NORAF|
h Orgrimmar |NORAF|

R Hillsbrad Foothills |N|Take the zeppelin outside Orgrimmar to Undercity.  Run down thru Silverpine.| |NORAF|
A Time To Strike |QID|494| |N|At Southpoint Tower (20.82, 47.31) just as you enter the zone.| |NORAF|

T Time To Strike |QID|494| |N|Follow the road east then north to Tarren Mill (62.33, 20.28).| |NORAF|
A Regthar Deathgate |QID|1361| |NORAF|
A The Hammer May Fall |QID|676| |NORAF|
]] end)
