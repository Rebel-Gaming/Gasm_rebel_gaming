TourGuide:RegisterGuide("Arathi Highlands (30)", "Stranglethorn Vale (30-31)", "Horde", function()
return [[
C The Hammer May Fall |QID|676| |N|Follow the road east into Arathi Highlands.  The ogre mound is just north of the road about a third of the way in (34,44).| |NORAF|

T The Hammer May Fall |QID|676| |N|Follow the road to the northeast corner of the zone (74.2, 33.8).| |NORAF|
A Hammerfall |QID|655| |NORAF|
T Hammerfall |QID|655| |NORAF|
A Raising Spirits (Part 1) |QID|672| |NORAF|

C Raising Spirits (Part 1) |QID|672| |N|Kill raptors west of Hammerfall.| |NORAF|

T Raising Spirits (Part 1) |QID|672| |N|Back at Hammerfall (74.67, 36.46)| |NORAF|
A Raising Spirits (Part 2) |QID|674| |NORAF|
T Raising Spirits (Part 2) |QID|674| |NORAF|
A Raising Spirits (Part 3) |QID|675| |NORAF|
T Raising Spirits (Part 3) |QID|675| |N|Skip the follow-up| |NORAF|
]] end)
