
TourGuide:RegisterGuide("Western Plaguelands (57-59)", "Hellfire Peninsula (60-61)", "Horde", function()
return [[
T A Plague Upon Thee (Part 1) |QID|5901| |NORAF|
A A Plague Upon Thee (Part 2) |QID|5902| |NORAF|

T A Plague Upon Thee (Part 2) |QID|5902| |NORAF|
A A Plague Upon Thee (Part 3) |QID|6390| |NORAF|

A Unfinished Business (Part 1) |QID|6004| |N|(51,28)|

C Unfinished Business (Part 1) |QID|6004|
T Unfinished Business (Part 1) |QID|6004|
A Unfinished Business (Part 2) |QID|6023|

C Unfinished Business (Part 2) |QID|6023|
C The So-Called Mark of the Lightbringer |QID|9443|
T Unfinished Business (Part 2) |QID|6023|
A Unfinished Business (Part 3) |QID|6025|
C Unfinished Business (Part 3) |QID|6025|
T Unfinished Business (Part 3) |QID|6025|

T A Plague Upon Thee (Part 3) |QID|6390| |NORAF|
T The So-Called Mark of the Lightbringer |QID|9443|
A Defiling Uther's Tomb |QID|9444|

T Auntie Marlene |QID|5152|
A A Strange Historian |QID|5153|

C A Strange Historian |QID|5153|
C Defiling Uther's Tomb |QID|9444| |N|You'll need to equip the quest item at the tomb.|

T A Strange Historian |QID|5153|
A The Annals of Darrowshire |QID|5154|
A A Matter of Time |QID|4971|

C A Matter of Time |QID|4971| |N|Find the blue glowy silos around the edges of Andorhal and use the horn.| |U|12627|
C The Annals of Darrowshire |QID|5154|
C All Along the Watchtowers |QID|5098| |U|12815| |N|Mark each tower in Andorhal, you can get close enough to mark without aggroing mobs inside if you are careful. (47,71) (40,71) (42,66) (44,63)|

T A Matter of Time |QID|4971|
A Counting Out Time |QID|4973|
T The Annals of Darrowshire |QID|5154|
A Brother Carlin |QID|5210|

C Counting Out Time |QID|4973| |N|Find lunchboxes in the houses all around Andorhal.|
C Skeletal Fragments |QID|964| |NORAF| |N|Kill undead all over Andorhal.|

T Counting Out Time |QID|4973|

H Light's Hope Chapel
T Zaeldarr the Outcast |QID|6021|
T Brother Carlin |QID|5210|

T Skeletal Fragments |QID|964| |NORAF|
T Defiling Uther's Tomb |QID|9444|
T All Along the Watchtowers |QID|5098|
]]
end)
