
TourGuide:RegisterGuide("Western Plaguelands (58)", "Eastern Plaguelands (58)", "Alliance", function()
return [[
F Western Plaguelands
T The Eastern Plagues |QID|6185|
A The Blightcaller Cometh |QID|6186|

T Auntie Marlene |N|House in Sorrow Hill (49,78)| |QID|5152|
A A Strange Historian |QID|5153|
C A Strange Historian |N|Gravestone just north of the house (49.65, 76.75)| |QID|5153|
T A Strange Historian |N|In the inn in Andorhal (39.43, 66.81)| |QID|5153|
A The Annals of Darrowshire |QID|5154|
A A Matter of Time |QID|4971|

C A Matter of Time |N|Find the blue glowy silos around the edges of Andorhal (45.05, 62.73).  Use horn.|  |U|12627| |QID|4971|
C The Annals of Darrowshire |N|In the town hall (43.91, 69.22).  Loot books till you find it.| |QID|5154|

T A Matter of Time |N|Back at the inn| |QID|4971|
A Counting Out Time |QID|4973|
T The Annals of Darrowshire |QID|5154|
A Brother Carlin |QID|5210|

C Counting Out Time |N|Find lunchboxes in the houses all around Andorhal.| |QID|4973|
C Skeletal Fragments |N|Kill undead all over Andorhal.| |QID|5537|

T Counting Out Time |N|Back at the inn| |QID|4973|
]]
end)
