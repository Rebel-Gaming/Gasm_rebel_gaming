--[[
    
    FizzleGlyph by dekimsey.
    This addon will highlight glyphs by their respective required class to make
    organinzing and identifying glyphs easier.
    
    The original Fizzle mod is by phyber and can be accessed at:
    http://www.wowinterface.com/downloads/info5018-Fizzle.html
    
--]]

FizzleGlyph = LibStub("AceAddon-3.0"):NewAddon("AceEvent-3.0", "AceEvent-3.0", "AceHook-3.0", "AceConsole-3.0")

local containerMax  = NUM_BAG_SLOTS + NUM_BANKBAGSLOTS
local gBankMax      = 98
local gBankGroupMax = 14
local _G            = getfenv(0)
local Gratuity      = LibStub:GetLibrary("Gratuity-2.0")

function FizzleGlyph:OnInitialize()
	--self:MakeBorders()
    self.borders = {}
end

function FizzleGlyph:OnEnable()
	self:SecureHook("ContainerFrame_OnShow", "ScanAllBags")
	self:RegisterEvent("BAG_UPDATE", "ScanBag")
    
	self:RegisterEvent("PLAYERBANKSLOTS_CHANGED", "ScanBank")
	self:RegisterEvent("PLAYERBANKBAGSLOTS_CHANGED", "ScanBank")
    self:RegisterEvent("BANKFRAME_OPENED", "ScanBank")
    --self:RegisterEvent("BANKFRAME_CLOSED", "ClearBank")
    
    self:RegisterEvent("GUILDBANK_UPDATE_TABS", "ScanGuildBank")
    self:RegisterEvent("GUILDBANKBAGSLOTS_CHANGED", "ScanGuildBank")
    self:RegisterEvent("GUILDBANK_ITEM_LOCK_CHANGED", "ScanGuildBank")
    self:RegisterEvent("GUILDBANKFRAME_OPENED", "ScanGuildBank")
    --self:RegisterEvent("GUILDBANKFRAME_CLOSED", "ClearGuildBank")
	self:ScanAllBags()
end

function FizzleGlyph:CreateBorder(slot, refPoint, slotName)
    local border = slot:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    border:SetBlendMode("ADD")
    border:SetVertexColor(0, 1, 0)
    --border:SetAlpha( .8 )
    --border:SetHeight(68)
    --border:SetWidth(68)
    border:SetHeight(70)
    border:SetWidth(70)
    border:SetPoint("CENTER", slot or refPoint)
    border:Hide()
    self.borders[slotName] = border
    return border
end


function FizzleGlyph:ScanGuildBank()
    local bankTab = GetCurrentGuildBankTab()
    for i=1, gBankMax do
        local index, column = self:walkGBank(i)
        local slotName  = "GuildBankColumn"..column.."Button"..index
        local slotFrame = _G[slotName]
        local itemLink  = GetGuildBankItemLink(bankTab, i)
        self:Colorize(itemLink, slotFrame, slotName)
    end
end

function FizzleGlyph:walkGBank(i)
    local index, column
    index = mod(i, gBankGroupMax)
    if ( index == 0 ) then
        index = gBankGroupMax
    end
    column = ceil((i-0.5)/gBankGroupMax)
    return index, column
end

function FizzleGlyph:Colorize(itemLink,slotFrame,slotName)
    local borderFrame = self:getBorderFrame(slotFrame,slotName)
    if itemLink and borderFrame then
        local r, g, b = self:determineColor(itemLink)
        if r ~= nil and g ~= nil and b ~= nil then
            borderFrame:SetVertexColor(r, g, b)
            borderFrame:Show()
        else
            borderFrame:Hide()
        end
    elseif borderFrame then
        borderFrame:Hide()
    end
end
function FizzleGlyph:determineColor(itemLink)
    local itemName = GetItemInfo(itemLink)
    if itemName:find('^Glyph of ') then
        Gratuity:SetHyperlink(itemLink)
        local _, _, class = Gratuity:Find('^Classes: ([%w ]+)$',1,3,nil,1)
        class = class:gsub('( )','')
        class = class:upper()
        local color = RAID_CLASS_COLORS[class]
        return color.r, color.g, color.b
    end
    return
end
function FizzleGlyph:getBorderFrame(slotFrame, slotName)
    if slotFrame == nil then
        return
    end
    local borderFrame = self.borders[slotName]
    if borderFrame == nil then
        borderFrame = self:CreateBorder(slotFrame, nil, slotName)
    end
    return borderFrame
end
function FizzleGlyph:clearSlot( slotName )
    return
    --_G[slotName] = nil
    --self.borders[slotName] = nil
end
function FizzleGlyph:ScanAllBags( )
	for containerIndex = 1, containerMax do
        self:_ScanBag(containerIndex)
	end
end
function FizzleGlyph:ScanBag(eventName, bagID )
    self:_ScanBag( bagID+1, bagID)
end
function FizzleGlyph:_ScanBag( containerIndex, bagIndex )
    local bagFrame = _G["ContainerFrame"..containerIndex]
    if bagFrame == nil then
        return
    end
    local bagIndex  = bagIndex or bagFrame:GetID()  -- deal with bank vs nonbank bag id issues.
    local bagSize   = GetContainerNumSlots(bagIndex)
    if bagFrame:IsVisible() then
        for itemIndex = 1, bagSize do
            local slotName  = "ContainerFrame"..containerIndex.."Item"..itemIndex
            local slotFrame = _G[slotName]
            local slotIndex = abs(itemIndex - (bagSize + 1))
            local itemLink  = GetContainerItemLink(bagIndex, slotIndex)
            if slotFrame and slotFrame:IsVisible() then
                self:Colorize(itemLink, slotFrame, slotName)
            end
        end
    end
end
function FizzleGlyph:ClearGuildBank()
    for bankTab = 1, MAX_GUILDBANK_TABS do
        for i=1, gBankMax do
            local index, column = self:walkGBank(i)
            local slotName  = "GuildBankColumn"..column.."Button"..index
            self:clearSlot(slotName)
        end
    end
end
function FizzleGlyph:ClearBank()
    for bankIndex = NUM_BAG_SLOTS + 1, NUM_BAG_SLOTS + NUM_BANKBAGSLOTS do
        local slotName  = "BankFrameItem"..bankIndex
        self:clearSlot(slotName)
    end
end
function FizzleGlyph:ScanBank()
    for bankIndex = 1, GetContainerNumSlots(-1) do
        local slotName  = "BankFrameItem"..bankIndex
		local slotFrame = _G[slotName]
        local itemLink  = GetContainerItemLink(-1, bankIndex)
		if slotFrame and slotFrame:IsVisible() then
			self:Colorize(itemLink, slotFrame, slotName)
		end
	end
end

