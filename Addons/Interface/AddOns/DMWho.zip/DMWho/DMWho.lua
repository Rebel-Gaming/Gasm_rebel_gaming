--[[$Id: DMWho.lua 58701 2008-01-18 02:46:44Z pernicius $]]

--------------------------------------------------------------------------------
-- Setup and utility functions
--------------------------------------------------------------------------------

_G.DMWho_Revision = max(_G.DMWho_Revision or 1, tonumber(("$Revision: 58701 $"):match("%d+")))

local numMeters = 5
local numLines = 20

DMWho = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0")


function DMWho:Print(text)
	if not text or tostring(text):len() == 0 then
		text = " "
	end
	text = "|cffffff78DMWho:|r " .. text
	DEFAULT_CHAT_FRAME:AddMessage(text)
end


--------------------------------------------------------------------------------
-- AceAddon init
--------------------------------------------------------------------------------


function DMWho:OnInitialize(name)
	self:Reset()
--[[
for x=1,40 do
	self.meters["DamageMeters"]["Debug"..x] = "MAGE"
end
self.meters["Recap"]["DbgHunter"] = "HUNTER"
self.meters["Recap"]["DbgWarlock"] = "WARLOCK"
self.meters["Recap"]["DbgPriest"] = "PRIEST"
self.meters["Recap"]["DbgPaladin"] = "PALADIN"
self.meters["Recap"]["DbgMage"] = "MAGE"
self.meters["Recap"]["DbgRogue"] = "ROGUE"
self.meters["Recap"]["DbgDruid"] = "DRUID"
self.meters["Recap"]["DbgShaman"] = "SHAMAN"
self.meters["Recap"]["DbgWarrior"] = "WARRIOR"
]]--
	self:CreateFrames()
	SLASH_DMWHO1 = "/dmwho"
	SlashCmdList["DMWHO"] = function(msg) DMWho:OnChatCmd(msg) end
end


function DMWho:OnEnable(first)
	self:RegisterEvent("CHAT_MSG_ADDON")
	self:Print("v" .. self.version .. "." .. _G.DMWho_Revision .. " by |cffA843EFPernicius|r loaded.")
	self:Print("\"/dmwho\" to toggle")
	self:Print("\"/dmwho reset\" to clear the list")
end


function DMWho:OnChatCmd(msg)
	if(msg == nil or msg == "") then
		
		if(self.frame:IsVisible()) then
			self.frame:Hide()
		else
			self:UpdateList()
			self.frame:Show()
		end
		
	elseif(msg == "reset") then
	
		self:Reset()
		self:UpdateList()
	
	end
end


function DMWho:Reset()
	self.meters = {
		["SWStats"] = {},
		["Recount"] = {},
		["Recap"] = {},
		["DamageMeters"] = {},
		["Violation"] = {},
		}
end


--------------------------------------------------------------------------------
-- GUI
--------------------------------------------------------------------------------


function DMWho:CreateFrames()
	
	local txtWidth = 100
	local txtHeight = 12
	local txtHSpace = 20
	local txtVSpace = 5
	
	local f = CreateFrame("Frame", nil, UIParent)
		f:SetWidth(5+numMeters*txtWidth+(numMeters-1)*txtHSpace+5)
		f:SetHeight(5+numLines*txtHeight+5)
		f:SetPoint("CENTER")
		f:SetFrameStrata("HIGH")
		f:SetToplevel(true)
		f:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
			edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
			tile = true, tileSize = 16, edgeSize = 16, 
			insets = { left = 4, right = 4, top = 4, bottom = 4 }});
		f:SetBackdropColor(0,0,0,0.8)
		f:EnableMouse(true)
		f:SetMovable(true)
		f:SetClampedToScreen(true)
		f:RegisterForDrag("LeftButton");
		f:Hide()
	f:SetScript("OnDragStart", function()
		if(arg1 == "LeftButton") then
			f:StartMoving();
		end
	end)
	f:SetScript("OnDragStop", function()
		f:StopMovingOrSizing()
	end)
	f:SetScript("OnMouseUp", function()
		f:StopMovingOrSizing()
	end)
	self.frame = f

	local fx = CreateFrame("Frame", nil, f)
		fx:SetWidth(5+numMeters*txtWidth+(numMeters-1)*txtHSpace+5 -20)
		fx:SetHeight(5+txtHeight+5)
		fx:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 0, -3)
		fx:SetFrameStrata("HIGH")
		fx:SetToplevel(true)
		fx:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
			edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
			tile = true, tileSize = 16, edgeSize = 16, 
			insets = { left = 4, right = 4, top = 4, bottom = 4 }});
		fx:SetBackdropColor(0,0,0,0.8)

	local fy = CreateFrame("Frame", nil, f)
		fy:SetWidth(5+numMeters*txtWidth+(numMeters-1)*txtHSpace+5)
		fy:SetHeight(5+txtHeight+5)
		fy:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 0, 3)
		fy:SetFrameStrata("HIGH")
		fy:SetToplevel(true)
		fy:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
			edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
			tile = true, tileSize = 16, edgeSize = 16, 
			insets = { left = 4, right = 4, top = 4, bottom = 4 }});
		fy:SetBackdropColor(0,0,0,0.8)
	
	local b = CreateFrame("Button", nil, f, "UIPanelCloseButton")
		b:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", 5, -8)
	
	local t = {"SWStats", "Recount", "Recap", "DamageMeters", "Violation"}
	for x=1,numMeters do
		local fs = fx:CreateFontString("DMWho_T"..x, "OVERLAY", "GameFontNormal")
			fs:SetPoint("LEFT", fx, "LEFT",
				5+(x-1)*(txtHSpace+txtWidth),
				0)
			fs:SetWidth(txtWidth)
			fs:SetHeight(txtHeight)
			fs:SetText(t[x])
	end
	for x=1,numMeters do
		for y=1,numLines do
			local fs = f:CreateFontString("DMWho_"..x.."_"..y, "ARTWORK", "GameFontNormal")
				fs:SetPoint("TOPLEFT", f, "TOPLEFT",
					5+(x-1)*(txtHSpace+txtWidth),
					-(5+(y-1)*txtHeight) )
				fs:SetWidth(txtWidth)
				fs:SetHeight(txtHeight)
		end
	end
	for x=1,numMeters do
		local fs = fy:CreateFontString("DMWho_S"..x, "OVERLAY", "GameFontNormal")
			fs:SetPoint("LEFT", fy, "LEFT",
				5+(x-1)*(txtHSpace+txtWidth),
				0 )
			fs:SetWidth(txtWidth)
			fs:SetHeight(txtHeight)
	end
	
end


RAID_CLASS_COLORS["unset"] = { r = 0.7, g = 0.7, b = 0.7 }
function DMWho:UpdateList()
	
	for x=1,numMeters do
		for y=1,numLines do
			getglobal("DMWho_"..x.."_"..y):SetText("|cff777777"..y.."|r")
		end
	end
	
	local function FormatName(name, class)
		local r = 255*RAID_CLASS_COLORS[class].r
		if(r < 17) then
			r = string.format("0%x", r)
		else
			r = string.format("%x", r)
		end
		local g = 255*RAID_CLASS_COLORS[class].g
		if(g < 17) then
			g = string.format("0%x", g)
		else
			g = string.format("%x", g)
		end
		local b = 255*RAID_CLASS_COLORS[class].b
		if(b < 17) then
			b = string.format("0%x", b)
		else
			b = string.format("%x", b)
		end
		return string.format("|cff%s%s%s%s|r", r, g, b, name)
	end
	
	local t = {"SWStats", "Recount", "Recap", "DamageMeters", "Violation"}
	local count
	for x=1,numMeters do
		count = 1
		table.foreach(self.meters[t[x]], function(k, v)
			if(count <= numLines) then
				getglobal("DMWho_"..x.."_"..count):SetText(FormatName(k, v))
			end
			count = count + 1
		end)
		getglobal("DMWho_S"..x):SetText(count-1 .. " Player")
	end
	
end


--------------------------------------------------------------------------------
-- AddonChatMsgSniffer
--------------------------------------------------------------------------------


function DMWho:AddUser(meter, user)
	if(self.meters[meter][user] == nil) then
		self:Print("|cffffff00"..user.."|r is using |cffffff00"..meter.."|r!")
		local _, enClass = UnitClass(user)
		if(not enClass) then
			enClass = "unset"
		end
		self.meters[meter][user] = enClass
	end
	if(self.frame:IsVisible()) then
		self:UpdateList()
	end
end


function DMWho:CHAT_MSG_ADDON()
	
	-- skip own messages
	if(arg4 == UnitName("player")) then
		return
	end
	
	-- **************************************************
	-- ** SW_Stats
	-- **************************************************
	-- "SWSVC7w7"; -- SW_CHAN_VC (VersionCheck)
	-- v2.1.x
	-- "SWSudX21"; -- SW_CHAN_MAIN
	-- "SWSHSX21"; -- SW_CHAN_HS (Handshake)
--	if(string.sub(arg1, 1, 3) == "SWS") then
	if(arg1 == "SWSVC7w7" or arg1 == "SWSudX21" or arg1 == "SWSHSX21") then
		self:AddUser("SWStats", arg4);
		return
	end
	
	-- **************************************************
	-- ** DamageMeters
	-- **************************************************
	if(arg1 == "DamageMeters") then
		self:AddUser("DamageMeters", arg4);
		return
	end
	
	-- **************************************************
	-- ** Recap (Ace2)
	-- **************************************************
	if(arg1 == self:GetAceCommHash("Recap")) then
		self:AddUser("Recap", arg4);
		return
	end
	
	-- **************************************************
	-- ** Recount (Ace2)
	-- **************************************************
	if(arg1 == self:GetAceCommHash("RECOUNT")) then
		self:AddUser("Recount", arg4);
		return
	end
	
	-- **************************************************
	-- ** Violation (Ace2)
	-- **************************************************
	if(arg1 == self:GetAceCommHash("Violation")) then
		self:AddUser("Violation", arg4);
		return
	end
	
--	DEFAULT_CHAT_FRAME:AddMessage("prefix:"..arg1)
--	DEFAULT_CHAT_FRAME:AddMessage("msg:"..arg2)
--	DEFAULT_CHAT_FRAME:AddMessage("type:"..arg3)
--	DEFAULT_CHAT_FRAME:AddMessage("sender:"..arg4)
end


DMWho.prefixToHash = {}
function DMWho:GetAceCommHash(prefix)
	
	if(self.prefixToHash[prefix] ~= nil) then
		return self.prefixToHash[text]
	end
	
	local function _NumericCheckSum(prefix)
		local counter = 1
		local len = prefix:len()
		for i = 1, len, 3 do
			counter = (counter*8257 % 16777259) +
				(prefix:byte(i)) +
				((prefix:byte(i+1) or 1)*127) +
				((prefix:byte(i+2) or 2)*16383)
		end
		return counter % 16777213
	end
	
	local function _TailoredNumericCheckSum(prefix)
		local hash = _NumericCheckSum(prefix)
		local a = math.floor(hash / 256^2)
		local b = math.floor(hash / 256) % 256
		local c = hash % 256
		-- \000, \n, |, \176, s, S, \015, \020
		if a == 0 or a == 10 or a == 124 or a == 176 or a == 115 or a == 83 or a == 15 or a == 20 or a == 37 then
			a = a + 1
		-- \t, \255
		elseif a == 9 or a == 255 then
			a = a - 1
		end
		if b == 0 or b == 10 or b == 124 or b == 176 or b == 115 or b == 83 or b == 15 or b == 20 or b == 37 then
			b = b + 1
		elseif b == 9 or b == 255 then
			b = b - 1
		end
		if c == 0 or c == 10 or c == 124 or c == 176 or c == 115 or c == 83 or c == 15 or c == 20 or c == 37 then
			c = c + 1
		elseif c == 9 or c == 255 then
			c = c - 1
		end
		return a * 256^2 + b * 256 + c
	end
	
	local num = _TailoredNumericCheckSum(prefix)
	self.prefixToHash[prefix] = string.char(math.floor(num / 256^2), math.floor(num / 256) % 256, num % 256)
	
	return self.prefixToHash[prefix]
	
end
