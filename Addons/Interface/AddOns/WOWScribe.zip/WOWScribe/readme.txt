WOWScribe 4.0.1
===============

WOWScribe is a small addon that allows you to log the chat channels of your 
choice (including the numbered channels).

The chat is logged to "[WOW directory]/Logs/WoWChatLog.txt".

Features:

You can set any chat channel (Say, Guild, Raid, Whisper, Emote, General)

You can also log channels by number (1, 2, 3, 4, 5, 6, 7, 8, 9)

Installation:

If you already have a "[WOW directory]/Interface/Addons" directory, skip to Step 4.

If you have never installed an addon, you must create the Addons directory:

1.  Go to your WoW installation directory.

2.  If the folder "Interface" does not exist, create it.

3.  In the folder "Interface", create the folder "Addons".

4.  Move/Copy the WOWScribe directory to the "Addons" folder.


Usage:
======

/wowscribe
    all by itself will give you the usage statement

/wowscribe start
    starts the logging

/wowscribe stop 
    stops the logging

/wowscribe status
    displays the current settings

/wowscribe add <channelname or number>
	adds the channel to the list being logged.
	using 'basic' as the channel will turn on guild, say, and emotes

/wowscribe remove <channelname or number>
	removes the channel from the list being logged
	using 'all' as the channel will turn all off
	
All commands and chat channel names are case insensitive.

Default channels logged are Guild, Say, and Emote.


Changes:
========

Updated for patch 4.0.1.

Fixed lua bug with new game patch (updated by Trickster).

Updated for patch 3.3.0.

Added support for party leader channel (added by Trickster).

Added support for raid leader and raid warning channels.

Notes:
======

Guild, Party, and Raid add a string that looks like "|Hchannel:raid|h[Raid]|h" or "|Hchannel:guild|h[Guild]|h" to the chat log. This is a WOW thing, not something added by WOWScribe. I have tried filtering it it out, but since all WOWScribe does is turn logging off and on for specific channels, there is nothing I can do about this.

If you have any questions, suggestions, or bugs, please contact me at: 
scartaris@mortshire.org
