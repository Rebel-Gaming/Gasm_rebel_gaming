local info = ChatTypeInfo["SYSTEM"];
local SName = GetCVar( "realmName" );
local PName = UnitName("player");
local version = "WOWScribe 4.0.1";
local SavedChatHandler = nil;

WSFirstUse = 0;
WSEnabled = 0;
WS_Channels = {};

local bLogOn = 0;

--function WS_OnLoad(self, event, ...)
	--self:RegisterEvent("VARIABLES_LOADED");
--end

function WS_OnEvent(self, event, ...)
	if (event == "VARIABLES_LOADED") then
		if (WSFirstUse == 0) then
		    WS_Channels["CHAT_MSG_EMOTE"] = 1;
		    WS_Channels["CHAT_MSG_TEXT_EMOTE"] = 1;
		    WS_Channels["CHAT_MSG_GUILD"] = 1;
		    WS_Channels["CHAT_MSG_SAY"] = 1;
		    WSFirstUse = 1;
		end

		messageReceived = 0;
		SlashCmdList["WOWScribeCOMMAND"] = WOWScribeSlash;
		SLASH_WOWScribeCOMMAND1 = "/wowscribe"; 
		
   -- Hook the chat event handler
        if (ChatFrame_OnEvent ~= SavedChatHandler) then
            SavedChatHandler = ChatFrame_OnEvent;
            ChatFrame_OnEvent = WOWScribeChat_OnEvent;
        end
		WS_Status();
	end
end

function WOWScribeChat_OnEvent(self,event,firstArg,secondArg,thirdArg,fourthArg,...)

    local channelNumber = event;
    local channelName = event;
	if (WSEnabled == 1) then -- don't bother if it's disabled
		if (event == "CHAT_MSG_CHANNEL" ) then
            channelNumber = string.sub(fourthArg, 1, 1); -- for numbered channels
            channelName = "CHAT_MSG_" .. string.upper(string.sub(fourthArg, 4)); -- for numbered channels
		end

        -- only worry about the channels we're logging
        if (WS_Channels[event] == 1) then
            WOWScribe_LogOn();
		elseif (WS_Channels[channelNumber] == 1) then
            WOWScribe_LogOn();
        elseif (WS_Channels[channelName] == 1) then
            WOWScribe_LogOn();
		else
			WOWScribe_LogOff(); -- not a channel to log
		end
	else
		WOWScribe_LogOff(); -- disabled, don't log
	end

	-- ok, continue
	SavedChatHandler(self,event,firstArg,secondArg,thirdArg,fourthArg,...);
	
end

function WOWScribeSlash(msg)
	local tag = string.lower(msg);
	local firsti, lasti, command, channel = string.find (tag, "(%w+) (%w+)");
	-- if there weren't 2, then command will be nil - check for one arg    
    if (command == nil) then
        firsti, lasti, command = string.find(tag, "(%w+)");
    end    

-- respond to commands
	if (command == nil) then
		WS_Help(); 
	elseif (command == "start") then
		WS_Message(version.." running!");
		WSEnabled = 1;
	elseif (command == "stop") then
		WS_Message(version.." stopped!");
		WSEnabled = 0;
	elseif (command == "add") then -- add a channel
		if (channel == nil) then
			WS_Help();
		elseif (channel == "basic") then
			WS_SetChannel("CHAT_MSG_GUILD", "on");
			WS_SetChannel("CHAT_MSG_SAY", "on");
			WS_SetChannel("CHAT_MSG_EMOTE", "on");
			WS_SetChannel("CHAT_MSG_TEXT_EMOTE", "on");
			WS_Status();
		elseif (channel == "emote") then
			WS_SetChannel("CHAT_MSG_EMOTE", "on");
			WS_SetChannel("CHAT_MSG_TEXT_EMOTE", "on");
			WS_Status();
		elseif (channel == "whisper") then
			WS_SetChannel("CHAT_MSG_WHISPER", "on");
			WS_SetChannel("CHAT_MSG_WHISPER_INFORM", "on");
			WS_Status();
		elseif (channel == "party") then
			WS_SetChannel("CHAT_MSG_PARTY", "on");
			WS_SetChannel("CHAT_MSG_PARTY_LEADER", "on");
			WS_Status();
		elseif (channel == "raid") then
			WS_SetChannel("CHAT_MSG_RAID", "on");
			WS_SetChannel("CHAT_MSG_RAID_LEADER", "on");
			WS_SetChannel("CHAT_MSG_RAID_WARNING", "on");
			WS_Status();
		elseif (channel >= "1" and channel <= "9") then
			WS_SetChannel(channel, "on");
			WS_Status();
		else
			WS_SetChannel("CHAT_MSG_".. string.upper(channel), "on");
			WS_Status();
		end
	elseif (command == "remove") then -- remove a channel
		if (channel == nil) then
			WS_Help();
		elseif (channel == "emote") then
			WS_SetChannel("CHAT_MSG_EMOTE", "off");
			WS_SetChannel("CHAT_MSG_TEXT_EMOTE", "off");
			WS_Message("Emote no longer logged");
			WS_Status();
		elseif (channel == "whisper") then
			WS_SetChannel("CHAT_MSG_WHISPER", "off");
			WS_SetChannel("CHAT_MSG_WHISPER_INFORM", "off");
			WS_Message("Whisper no longer logged");
			WS_Status();
		elseif (channel == "party") then
			WS_SetChannel("CHAT_MSG_PARTY", "off");
			WS_SetChannel("CHAT_MSG_PARTY_LEADER", "off");
			WS_Message("Party no longer logged");
			WS_Status();
		elseif (channel == "raid") then
			WS_SetChannel("CHAT_MSG_RAID", "off");
			WS_SetChannel("CHAT_MSG_RAID_LEADER", "off");
			WS_SetChannel("CHAT_MSG_RAID_WARNING", "off");
			WS_Message("Raid no longer logged");
			WS_Status();
		elseif (channel == "basic") then
			WS_Help();
		elseif (channel == "all") then
			WS_RemoveAll();
			WS_Status();
		elseif (channel >= "1" and channel <= "9") then
			WS_SetChannel(channel, "off");
			WS_Message(channel .. " no longer logged");
			WS_Status();
		else
			WS_SetChannel("CHAT_MSG_".. string.upper(channel), "off");
			WS_Message(channel .. " no longer logged");
			WS_Status();
		end
	elseif (command == "status") then
		WS_Status();
	else
		WS_Help(); 
	end
end

function WS_Status()
	if (WSEnabled == 0) then
    	WS_Message(version.." stopped!");
	else
    	WS_Message(version.." running!");
    end
    
	local str = "";
	table.foreach(WS_Channels, function(k,v) if (v == 1) then str = str..WS_MapChannel(k) end end);
	
	if (str == "") then
		str = "+Nothing+";
	end
	
	WS_Message("  Logging "..str);

end

function WS_RemoveAll()
	table.foreach(WS_Channels, function(k,v) WS_SetChannel(k,"off") end);
end

function WS_Message(msg)
	DEFAULT_CHAT_FRAME:AddMessage(msg, info.r, info.g, info.b, info.id);
end

function WS_Help()
	WS_Message("WoW Scribe - Use /wowscribe <start|stop|status>"); 
	WS_Message("    /wowscribe add <channelname or number>");
	WS_Message("    /wowscribe remove <channelname or number>");
	WS_Message("    	add basic  will add guild, say, and emote");
	WS_Message("    	remove all  will remove all");
end

function WS_SetChannel(channel, value)

	if (value == "on") then
		WS_Channels[channel] = 1;
		if (channel ~= "CHAT_MSG_TEXT_EMOTE" and channel ~= "CHAT_MSG_WHISPER_INFORM" and channel ~= "CHAT_MSG_PARTY_LEADER" and channel ~= "CHAT_MSG_RAID_LEADER" and channel ~= "CHAT_MSG_RAID_WARNING") then
			WS_Message(WS_MapChannel(channel) .. " being logged");
		end
	else
		WS_Channels[channel] = 0;
	end
end

function WS_MapChannel(channel)
	local str;
	
	if (channel == "CHAT_MSG_GUILD") then 
		str = "Guild "; 
	elseif (channel == "CHAT_MSG_YELL") then
		str = "Yell ";
	elseif (channel == "CHAT_MSG_WHISPER") then
		str = "Whisper ";
	elseif (channel == "CHAT_MSG_EMOTE") then
		str = "Emotes ";
	elseif (channel == "CHAT_MSG_PARTY") then
		str = "Party ";
	elseif (channel == "CHAT_MSG_RAID") then
		str = "Raid ";
	elseif (channel == "CHAT_MSG_SAY") then
		str = "Says ";
	elseif (channel == "CHAT_MSG_OFFICER") then
		str = "Officer ";
	elseif (channel == "CHAT_MSG_TEXT_EMOTE") then
		str = "";
	elseif (channel == "CHAT_MSG_WHISPER_INFORM") then
		str = "";
	elseif (channel == "CHAT_MSG_PARTY_LEADER") then
		str = "";
    elseif (string.sub(channel, 1, 9) == "CHAT_MSG_") then
        str = string.upper(string.sub(channel, 10, 10)) .. string.lower(string.sub(channel, 11)) .. " ";
	else
		str = channel .. " ";
	end

	return str;
end

function WOWScribe_LogOn()
--	if (bLogOn == 0) then -- currently off
		LoggingChat(true);
		bLogOn = 1;
--	end
end

function WOWScribe_LogOff()
	if (bLogOn == 1) then -- currently on
		LoggingChat(false);
		bLogOn = 0;
	end
end
