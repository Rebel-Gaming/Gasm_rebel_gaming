-- yleaf(yaroot@gmail.com)
if GetLocale() ~= "zhCN" then return end

DBM_LDB_TOOLTIP_HELP1	= "左键 打开DBM"
DBM_LDB_TOOLTIP_HELP2	= "右键 打开设置"

DBM_LDB_LOAD_MODS		= "载入首领模块"

DBM_LDB_CAT_WOTLK		= "巫妖王之怒"
DBM_LDB_CAT_BC			= "燃烧的远征"
DBM_LDB_CAT_CLASSIC 	= "艾泽拉斯"
DBM_LDB_CAT_OTHER		= "其他首领"

DBM_LDB_CAT_GENERAL		= "常规"
DBM_LDB_ENABLE_BOSS_MOD	= "启用首领模块"
DBM_LDB_ANNOUN_BOSS_MOD = "通告到团队"
