-- yleaf(yaroot@gmail.com)/Juha
if GetLocale() ~= "zhTW" then return end

DBM_LDB_TOOLTIP_HELP1	= "左鍵 開啟DBM"
DBM_LDB_TOOLTIP_HELP2	= "右鍵 開啟設置"

DBM_LDB_LOAD_MODS		= "載入首領模組"

DBM_LDB_CAT_WOTLK		= "巫妖王之怒"
DBM_LDB_CAT_BC			= "燃燒的遠征"
DBM_LDB_CAT_CLASSIC 	= "艾澤拉斯"
DBM_LDB_CAT_OTHER		= "其他首領"

DBM_LDB_CAT_GENERAL		= "一般"
DBM_LDB_ENABLE_BOSS_MOD	= "啟用首領模組"
DBM_LDB_ANNOUN_BOSS_MOD = "通告到團隊"
