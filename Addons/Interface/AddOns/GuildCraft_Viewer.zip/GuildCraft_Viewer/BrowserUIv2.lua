local projectVersion = "v3.5.4-release"
local projectRevision = "41fe740"
if projectVersion:find("project") then
	projectVersion = "git"
	projectRevision = "dev"
end

local tsort, tinsert, pairs, ssplit = table.sort, table.insert, pairs, string.split

local newTable, delTable
do
	-- Table Pool for recycling tables
	local tablePool = {};
	setmetatable(tablePool, {__mode = "kv"});	-- Weak table

	-- Get a new table
	function newTable()
		local t = next(tablePool) or {};
		tablePool[t] = nil;
		return t;
	end

	-- Delete table and add to table pool
	function delTable(t)
		if (type(t) == "table") then
			for k, v in pairs(t) do
				if (type(v) == "table") then
					delTable(v);	-- child tables get put into the pool
				end
				t[k] = nil;
			end
			setmetatable(t, nil);
			t[true] = true;
			t[true] = nil;
			tablePool[t] = true;
		end
		return nil;
	end
end
-------------------------------------------

local AddonParent = LibStub("AceAddon-3.0"):GetAddon("GuildCraft")
local Module = AddonParent:NewModule("ViewerUI")
local API = AddonParent.API
local AceGUI = LibStub("AceGUI-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("GuildCraft")

local BTS = LibStub("Mini-Bable-TradeSkill")
local LibGratuity = LibStub("LibGratuity-3.0")

assert(BTS, "Guild Craft Not Installed Properly, MiniBTS Missing. Reinstall From curse.com please")
assert(LibGratuity, "LibGratuity Not Found - Install dependancy or reinstall package from curse")


function Module:OnEnable()
	GuildCraftTT:SetBackdrop(nil)
	self:CreateViewer()
--	self:Debug("Browser UI Loaded")
end
local professionDropDownList = {}
local craftablesTreeList = {}

Module.professionDropDownList = professionDropDownList
Module.craftablesTreeList = craftablesTreeList

function Module:ToggleViewer()
--	self:Debug("Toggle Viewer Start")
	if not self.frame then
--		self:Debug("No frame, make it")
		self:CreateViewer()
		if not self:RefreshBrowser() then
			self:Print(L["No Tradeskill Data Available"])
			self.frame:Hide()
			return
		end
		self.frame:Show()
		self:RestoreSearch()
	else
		if self.frame.frame:IsShown() then
			self.frame:Hide()
		else

			if not self:RefreshBrowser() then
				self:Print(L["No Tradeskill Data Available"])
				self.frame:Hide()
				return
			end
			self.frame:Show()
			self:RestoreSearch()
		end
	end
	--Add code here later to actually toggle it
--	self:Debug("ToggleViewer Func End")
end

function Module:UpdateProfessionDopdown(tradeSkillDropdown)
--	self:Debug("Update ProfessionDropDown")
	for k,v in pairs(professionDropDownList) do
		professionDropDownList[k] = nil
	end
	for lName in pairs(API:GetGuildWideProfessions() ) do
		professionDropDownList[lName] = BTS(lName)
	end
	self.currentViewedProfession = self.currentViewedProfession or next(professionDropDownList)
	tradeSkillDropdown:SetList(professionDropDownList)
	tradeSkillDropdown:SetValue(self.currentViewedProfession)
--	self:Debug("Currently displayed profession:", self.currentViewedProfession)
end

local function treeSortFunc(a,b)
	return a.text < b.text
end

function Module:UpdateCraftablesTree(craftablesTree)
--	self:Debug("UpdateCraftablesTree")
	local profData = API:GetProfessionTable(self.currentViewedProfession)
--	self:Debug("Current profession", self.currentViewedProfession, "& table", profData)
	craftablesTreeList = delTable(craftablesTreeList) or newTable()		--funny syntax, delete the table & return nil, causing newTable() to be assigned.
	for k,v in pairs(profData) do
		local t = newTable()
		t.text = (GetSpellInfo(k)):gsub("Enchant ","")
		t.value = k
		tinsert( craftablesTreeList, t)
	end
	tsort(craftablesTreeList, treeSortFunc)
	craftablesTree:SetTree(craftablesTreeList)
end



do
	local function OpenHyperlink( owner, link )
		ShowUIPanel(GuildCraftTT);
		if ( not GuildCraftTT:IsShown() ) then
			GuildCraftTT:SetOwner(owner, "ANCHOR_NONE")
			GuildCraftTT:SetPoint("TOPLEFT", owner ,"BOTTOMLEFT", 5,-10)
		end
		GuildCraftTT:SetHyperlink(link);
	end

--	local function SendHyperlinkToChat( link )
--		if ChatFrameEditBox:IsVisible() then
--				ChatFrameEditBox:Insert( (GetSpellLink(link)) )
--		else
--			print( (GetSpellLink(link)) )
--		end
--	end
	--Locals for all objects as we use them all over the place...
		--Objects
	local BaseFrame, tradeSkillDropdown, craftablesTree, craftersLabel, searchBox, refreshBrowser
--	local sortMethodsDropDown
		--Functions
	local BaseFrame_OnClose, tradeSkillDropdown_OnValueChange, craftablesTree_OnSelect, craftablesTree_OnClick
	local searchBox_OnEnterPressed, sortMethodsDropDown_OnValueChange, refreshBrowser_OnClick, craftablesTree_OnEnter, craftablesTree_OnLeave
	--Open-Ze-Bitch()

---Ok..... Make the code look pritty and easy to read....
--This is the AceGUI Code for the browser...

	function Module:CreateViewer()
		if BaseFrame then
			return
		else
		--Setup Frame , and callbacks....
		BaseFrame = AceGUI:Create("Frame")
		BaseFrame:SetTitle(L["Guild Craft - Browser"])
		BaseFrame:SetLayout("Flow")
		BaseFrame:SetCallback("OnClose", BaseFrame_OnClose )
		self.frame = BaseFrame
		
		--Object1: TradeSkill Drop down box --- this drop down has all the available guild craftables in it..
		tradeSkillDropdown = AceGUI:Create("Dropdown")
		tradeSkillDropdown:SetLabel(TRADE_SKILLS)
		tradeSkillDropdown:SetList(professionDropDownList)
		tradeSkillDropdown:SetCallback("OnValueChanged", tradeSkillDropdown_OnValueChange)

		--Object2: craftablesTree ---This is a Tree View Object, tree list shows the craftable items for the selected TradeSkill chosen via "tradeSkillDropdown"
		craftablesTree = AceGUI:Create("TreeGroup")
		craftablesTree.width = "fill"
		craftablesTree.height = 'fill'
		craftablesTree:SetLayout("Flow")
		craftablesTree:SetCallback("OnGroupSelected", craftablesTree_OnSelect)
		craftablesTree:SetCallback("OnClick", craftablesTree_OnClick)
		craftablesTree:SetCallback("OnButtonEnter", craftablesTree_OnEnter)
		craftablesTree:SetCallback("OnButtonLeave", craftablesTree_OnLeave)
		craftablesTree:SetTreeWidth(263, true)
		craftablesTree:EnableButtonTooltips(false)

			--Object 2.5: Lable Added to right hand view as a child, this displays who can craft the item, now in Alpha sorted values... yay for tables >.>
			craftersLabel = AceGUI:Create("Label")
			craftersLabel:SetText(L["Select a Trade Skill from the List above and the craftables from the left"])
			craftersLabel.width = "fill"
		
		--Object 3: Search Box
		searchBox = AceGUI:Create("EditBox")
		searchBox:SetLabel(L["Search"])
		searchBox:SetCallback("OnEnterPressed", searchBox_OnEnterPressed)
	
		--Object 5: Browser Refresh Button
		refreshBrowser = AceGUI:Create("Button")
		refreshBrowser:SetText(L["Refresh"])
		refreshBrowser:SetCallback("OnClick", refreshBrowser_OnClick)
		refreshBrowser:SetCallback("OnEnter", refreshBrowser_OnEnter)
		refreshBrowser:SetCallback("OnLeave", refreshBrowser_OnLeave)

		--Object 6: Help Box
--		BaseFrame:SetStatusText(L["Searchbox can take several arguments. IE: searching Jewlcrafting for 'epic simple red' returns all gems that fit a red socket"])

		--Make Babies
		BaseFrame:AddChild(tradeSkillDropdown)
		BaseFrame:AddChild(searchBox)
		BaseFrame:AddChild(refreshBrowser)		
		BaseFrame:AddChild(craftablesTree)
			craftablesTree:AddChild(craftersLabel)
		
		BaseFrame:Hide()
		end --end of existance statement
	end		--End of toggle Function

	function Module:RestoreSearch()
		if self.searchValue then
			searchBox_OnEnterPressed(searchBox, "ForceIt" , self.searchValue)
		end
		if self.savedSelection then
			craftablesTree:SetSelected(self.savedSelection)
			craftablesTree_OnSelect(craftablesTree, "ForceIt", self.savedSelection)
		end
	end

	function Module:RefreshBrowser()
--		self:Debug("Refreshing Browser")
		API:InitCache(true)
		if not next(API.profCache) then
			return false
		end
		self:UpdateProfessionDopdown(tradeSkillDropdown)
		self:UpdateCraftablesTree(craftablesTree)
		return true
	end
	
	--Functions
	function BaseFrame_OnClose(widget, event, ...)
		HideUIPanel( GuildCraftTT )
		
	end
	
	function tradeSkillDropdown_OnValueChange(widget, event, value, ...)
		Module.currentViewedProfession = value
		Module:UpdateCraftablesTree(craftablesTree)
		--function for when the drop down box changes
	end
	
	function craftablesTree_OnSelect(widget, event, value, ...)
		local whoCanMakeIt = API:AlphaSortAddMainCSV( API:GetCraftersBySpecific(Module.currentViewedProfession, value) )
		craftersLabel:SetText( L["Can be crafted by:"].."\n"..whoCanMakeIt  )
		Module.savedSelection = value
		OpenHyperlink( craftersLabel.frame , "enchant:"..value)				
	end
	
	function craftablesTree_OnClick(widget, event, value, ...)
		if IsShiftKeyDown() then
			HandleModifiedItemClick(GetSpellLink(value))
			--SendHyperlinkToChat(value)		--Add Shift here, as it's not done in SendHyperlinkToChat()
		end
	end
	
	local searchFuncForGratuity = function(a) if a:lower() ~= a:upper() then return "["..a:lower()..a:upper().."]" end end
	_G.GC_NormalizeSearch = searchFuncForGratuity
	local function multiTooltipSearch(...)
		local found = 0		
		local numArgs = select("#", ...)
		for i = 1, numArgs do
			local v = (select(i, ...)) --:lower():gsub("%a", searchFuncForGratuity )	
			if LibGratuity:Find(v) then
				found = found + 1
			end
		end
		if found == numArgs then 
			return true
		else
			return false
		end
	end

	function searchBox_OnEnterPressed(widget, event , value, ...)
		Module.searchValue = value
--		Module:Debug(event, value)
		local profData = API:GetProfessionTable(Module.currentViewedProfession)
		if not profData then return false end
--		Module:Debug("Current profession", Module.currentViewedProfession, "& table", profData)
		craftablesTreeList = delTable(craftablesTreeList) or newTable()		--funny syntax, delete the table & return nil, causing newTable() to be assigned.

		value = value:gsub("([\192-\255]?%a?[\128-\191]*)", searchFuncForGratuity)
		Module:Debug("Search for:", value)
		for id, makers in pairs( profData ) do
			LibGratuity:SetHyperlink("enchant:"..id)
			if multiTooltipSearch( ssplit(" ", value)) or tostring(id):find(value) or makers:find(value) then	--LibGratuity:Find(value)
				local t = newTable()
--				if GetLocale() == "enUS" and currentTradeSkill == "Enchanting" then		--Enchanting is HOMO, and dosn't do this in other locales...
				t.text = (GetSpellInfo(id)):gsub("Enchant ","")
				t.value = id						--give it a pass value
				tinsert(craftablesTreeList, t)
			end
		end
		tsort(craftablesTreeList, treeSortFunc)
		craftablesTree:SetTree(craftablesTreeList)
		widget.editbox:ClearFocus()
	end
	
	function refreshBrowser_OnClick(widget, event, button, ...)
		if not Module:RefreshBrowser() then
			self:Print(L["No Tradeskill Data Available"])
			BaseFrame:Hide()
		end
		--Refresh browser should force the cache to reload entirely
	end

	function craftablesTree_OnEnter(widget, event, value, frame, ...)
		if not tostring(value) then return end
		GameTooltip:SetOwner(this, "ANCHOR_NONE")
	        GameTooltip:SetPoint("RIGHT",frame,"LEFT")
	        GameTooltip:SetHyperlink("enchant:"..value)
	end

	function craftablesTree_OnLeave(widget, event, value, frame, ...)
		GameTooltip:Hide()
	end
	
	--Hook the escape key here....
	local old_CloseSpecialWindows
	if not old_CloseSpecialWindows then
		old_CloseSpecialWindows = CloseSpecialWindows
		CloseSpecialWindows = function()
			local found = old_CloseSpecialWindows()
			if BaseFrame and BaseFrame.frame:IsVisible() then
				BaseFrame:Hide()
				return true
			end
			return found
		end
	end
	
end
