--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")

local _G = getfenv(0)

DaHud.objectsToUpdate = {}

--- ========================================================= ---
---  Local Functions
--- ========================================================= ---
local newT, delT
do
	local tableCache = setmetatable({}, {__mode='k'})
	function newT()
		local t = next(tableCache)
		if t then
			tableCache[t] = nil
			return t
		else
			return {}
		end
	end
	function delT(t)
		if not t then return end
		for k in pairs( t ) do
			t[k] = nil
		end
		tableCache[t] = true
		return nil
	end
end

DaHud.newTable = newT
DaHud.delTable = delT

local newL, delL
do
	local tableCache = setmetatable({}, {__mode='k'})
	function newL(...)
		local t = next(tableCache)
		local count = select("#", ...)
		
		if t then
			tableCache[t] = nil
			for i = 1, count do
				t[i] = select(i, ...)
			end
			return t
		else
			return {...}
		end
	end
	function delL(t)
		if not t then return end
		for k in pairs( t ) do
			t[k] = nil
		end
		tableCache[t] = true
		return nil
	end
end

DaHud.newList = newL
DaHud.delList = delL

local newFrame, delFrame
do
	local frameCount = {}
	local myFrames = {}
	
	function newFrame(kind, name, parent, ...)
		if type(kind) ~= "string" then
			error("Bad argument passed to CreateFrame")
		end
		
		if not parent then parent = UIParent end
	
		local frame
	
		frameCount[kind] = (frameCount[kind] or 0) + 1
		if not(name) then
			name = "DaHud"..kind..frameCount[kind]
		end
	
		if kind == "Texture" then
			frame = parent:CreateTexture(name, ...)
		elseif kind == "FontString" then
			frame = parent:CreateFontString(name, ...)
		elseif kind == "Cooldown" then
			frame = CreateFrame("Cooldown", name, parent, "CooldownFrameTemplate")
		else
			frame = CreateFrame(kind, name, parent, ...)
		end
	
		myFrames[frame] = true
	
		return frame
	end

	function delFrame(frame)
		if type(frame) ~= "table" then
			error("Bad argument passed to DeleteFrame")
		elseif type(frame.GetObjectType) ~= "function" then
			error("Attempt to delete non-frame object.")
		end
	
		if not myFrames[frame] then
			error("Attempt to delete foreign frame.")
		end
	
		local kind = frame:GetObjectType()
	
		if kind == "Frame" then
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "FontString" then
					child:SetText("")
				end
			end
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "Texture" then
					child:SetTexture(nil)
				end
			end
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "StatusBar" then
					child:SetStatusBarTexture(nil)
				end
			end
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "PlayerModel" then
					child:SetModelScale(0)
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "FontString" then
					region:SetText("")
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "Texture" then
					region:SetTexture(nil)
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "StatusBar" then
					region:SetStatusBarTexture(nil)
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "PlayerModel" then
					region:SetModelScale(0)
				end
			end
		elseif kind == "Button" then
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "FontString" then
					child:SetText("")
				end
			end
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "Texture" then
					child:SetTexture(nil)
				end
			end
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "StatusBar" then
					child:SetStatusBarTexture(nil)
				end
			end
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "PlayerModel" then
					child:SetModelScale(0)
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "FontString" then
					region:SetText("")
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "Texture" then
					region:SetTexture(nil)
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "StatusBar" then
					region:SetStatusBarTexture(nil)
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "PlayerModel" then
					region:SetModelScale(0)
				end
			end
		elseif kind == "StatusBar" then
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "FontString" then
					child:SetText("")
				end
			end
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "Texture" then
					child:SetTexture(nil)
				end
			end
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "StatusBar" then
					child:SetStatusBarTexture(nil)
				end
			end
			for i=frame:GetNumChildren(),1,-1 do
				local child = select(i, frame:GetChildren())
				if child:GetObjectType() == "PlayerModel" then
					child:SetModelScale(0)
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "FontString" then
					region:SetText("")
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "Texture" then
					region:SetTexture(nil)
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "StatusBar" then
					region:SetStatusBarTexture(nil)
				end
			end
			for i=frame:GetNumRegions(),1,-1 do
				local region = select(i, frame:GetRegions())
				if region:GetObjectType() == "PlayerModel" then
					region:SetModelScale(0)
				end
			end
			
			frame:SetStatusBarTexture(nil)
		elseif kind == "PlayerModel" then
			frame:SetModelScale(0)
		elseif kind == "FontString" then
			frame:SetText("")
		elseif kind == "Texture" then
			frame:SetTexture(nil)
		end
	
		frame:ClearAllPoints()
		frame:SetPoint("LEFT", UIParent, "RIGHT", 1e5, 0)
	
		frame:SetParent(UIParent)
		frame:SetAlpha(0)
		frame:SetHeight(0)
		frame:SetWidth(0)
		
		if frame.SetBackdrop then
			frame:SetBackdrop(nil)
		end
		
		frame:Hide()
	
		return nil
	end
end

DaHud.newFrame = newFrame
DaHud.delFrame = delFrame

--- ========================================================= ---
---  Set Config Mode
--- ========================================================= ---
function DaHud:SetConfigMode()
	if DaHud.db.profile.general.config then
		DaHud:Debug("Configuration Mode ON")
	else
		DaHud:Debug("Configuration Mode OFF")
	end
	
	DaHud:UpdateParentAlpha()
	
	for k, v in DaHud:IterateModules() do
		local moduleName = string.gsub(v.name, "DaHud_", "")
		for k2, v2 in pairs(DaHud.Frames[moduleName]) do
			local id = string.gsub(v2:GetName(), "DaHud_", "")

			DaHud:UpdateFrame(v, v2)
			DaHud:SetupWatch(v, v2, id)
		end
	end
end

--- ========================================================= ---
---  Create Parent Frame
--- ========================================================= ---
function DaHud:CreateParentFrame()
	local f = CreateFrame("Frame", "DaHudParent", UIParent)
	f:SetWidth(200)
	f:SetHeight(200)
	f:SetAlpha(1)
	f:SetPoint("CENTER", UIParent, "CENTER")
	f:Show()
	
	DaHud.Frames.ParentFrame = f
end

--- ========================================================= ---
---  Update Parent Frame
--- ========================================================= ---
function DaHud:UpdateParentFrame()
	_G["DaHudParent"]:SetScale(DaHud.db.profile.frame.scale)
end

--- ========================================================= ---
---  Update Parent Alpha
--- ========================================================= ---
function DaHud:UpdateParentAlpha()
	local alpha
	local powerType = UnitPowerType("player")
	
	if DaHud.db.profile.general.config then
		alpha = 1
	elseif DaHud.inCombat then
		alpha = DaHud.db.profile.alpha.combat
	elseif UnitExists("target") then
		alpha = DaHud.db.profile.alpha.target
	elseif UnitHealth("player") ~= UnitHealthMax("player") or
		(powerType == 0 and UnitMana("player") ~= UnitManaMax("player")) or
		(powerType == 1 and UnitMana("player") > 0) or
		(powerType == 3 and UnitMana("player") ~= UnitManaMax("player")) then
		alpha = DaHud.db.profile.alpha.regen
	elseif UnitCastingInfo("player") or UnitChannelInfo("player") then
	    alpha = DaHud.db.profile.alpha.casting
	else
		alpha = DaHud.db.profile.alpha.ooc
	end	
	
	if alpha ~= DaHud.alpha then
		DaHud.Alpha = alpha
		DaHud.Frames.ParentFrame:SetAlpha(alpha)
	end
end

--- ========================================================= ---
---  Register Update
--- ========================================================= ---
function DaHud:RegisterUpdate(myTable, method, name, frame, settings)
	if not(myTable) then return end
	if not(method) then return end
	if not(name) then return end
	if not(frame) then return end

	DaHud.objectsToUpdate[name] = {}
	DaHud.objectsToUpdate[name].myTable = myTable
	DaHud.objectsToUpdate[name].method = method
	DaHud.objectsToUpdate[name].frame = frame
	
	if settings then
		DaHud.objectsToUpdate[name].settings = settings
	end
end

--- ========================================================= ---
---  Process Update
--- ========================================================= ---
function DaHud:ProcessUpdate()
	for k, v in pairs(DaHud.objectsToUpdate) do
		local myTable = v.myTable
		local method = v.method
		local frame = v.frame
		local settings = v.settings
		
		if not(settings) then
			myTable[method](myTable, frame)
		else
			myTable[method](myTable, frame, settings)
		end
	end
end