--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:NewModule("Portraits")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

DaHud.Frames.Portraits = {}

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Portraits = {}

DaHud.Portraits.Type = {
	player = {},
	pet = {},
	pettarget = {},
	target = {},
	targettarget = {},
	targettargettarget = {},
	focus = {},
	focustarget = {},
	party1 = {},
	party1pet = {},
	party1target = {},
	party2 = {},
	party2pet = {},
	party2target = {},
	party3 = {},
	party3pet = {},
	party3target = {},
	party4 = {},
	party4pet = {},
	party4target = {},
}

DaHud.Portraits.Plugins = {
}

DaHud.Portraits.Textures = {
	dahud_portrait = L["DaHud Portrait"],
	custom = L["Custom"],
}

DaHud.Portraits.Elements = {
	textures = {
		dahud_portrait = "Interface\\Addons\\DaHud\\media\\Portrait",
	},		
	classIcons = {
		["WARRIOR"] = {0, 0.25, 0, 0.25},
		["MAGE"] = {0.25, 0.49609375, 0, 0.25},
		["ROGUE"] = {0.49609375, 0.7421875, 0, 0.25},
		["DRUID"] = {0.7421875, 0.98828125, 0, 0.25},
		["HUNTER"] = {0, 0.25, 0.25, 0.5},
		["SHAMAN"] = {0.25, 0.49609375, 0.25, 0.5},
		["PRIEST"] = {0.49609375, 0.7421875, 0.25, 0.5},
		["WARLOCK"] = {0.7421875, 0.98828125, 0.25, 0.5},
		["PALADIN"] = {0, 0.25, 0.5, 0.75},
	},
}

--- ========================================================= ---
---  Setup Database
--- ========================================================= ---
function mod:OnRegister()
	self:RegisterDefaults({
		portraits = {
			["**"] = {
				name = "Default",
				active = false,
				framestrata = "LOW",
				framelevel = 1,
				point = "CENTER",
				anchor = "UIParent",
				relative = "CENTER",
				posx = 0,
				posy = 0,
				width = 50,
				height = 50,
				unit = "player",
				type = "ani",
				border = "dahud_portrait",
				customBorder = "",
				interactive = false,
				hideinraid = false,
			},
			portrait1 = {
				name = "PlayerPortrait",
				active = true,
				posx = 0,
				posy = 0,
				unit = "player",
			},
			pluginsDisabled = {
			},
		}
	})
end

--- ========================================================= ---
---  System
--- ========================================================= ---
function mod:OnEnable()
	DaHud:EnableModule(mod)
end

function mod:OnDisable()
	DaHud:DisableModule(mod)
end