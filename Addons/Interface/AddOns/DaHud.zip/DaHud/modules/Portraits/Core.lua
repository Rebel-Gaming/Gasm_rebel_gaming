--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Portraits")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions(id, name)
	if not(id) or not(name) then return end

	DaHud.options.args.Portraits.args[id].args.Appearance.args.Group1 = {
		name = L["Border"],
		type = "group",
		inline = true,
		order = 1,
		args = {
			border = {
				name = L["Border"],
				type = "select",
				order = 1,
				values = function(info)
					return DaHud.Portraits.Textures
				end,
				get = function(info) 
					return DaHud.db.profile.portraits[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.portraits[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
			customBorder = {
				name = L["Custom"],
				type = "input",
				width = "full",
				order = 2,
				disabled = function(info) return DaHud.db.profile.portraits[info[#info-3]].border ~= "custom" end,
				get = function(info) 
					return DaHud.db.profile.portraits[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.portraits[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
		},
	}
	
	DaHud.options.args.Portraits.args[id].args.Appearance.args.Group2 = {
		name = L["Misc"],
		type = "group",
		inline = true,
		order = -1,
		args = {
			interactive = {
				name = L["Interactive"],
				type = "toggle",
				order = 1,
				get = function(info) 
					return DaHud.db.profile.portraits[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.portraits[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
			hideinraid = {
				name = L["Hide In Raid"],
				type = "toggle",
				order = 1,
				get = function(info) 
					return DaHud.db.profile.portraits[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.portraits[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
		},
	}
end

--- ========================================================= ---
---  Frame Type
--- ========================================================= ---
function mod:FrameType()
	return "Button", "SecureUnitButtonTemplate"
end

--- ========================================================= ---
---  Set Attributes
--- ========================================================= ---
function mod:SetAttributes(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Portraits[id]
	
	f.Portrait = newFrame("Texture", nil, f, "OVERLAY")
	f.Border = newFrame("Frame", nil, f)
	f.BorderTex = newFrame("Texture", nil, f.Border, "OVERLAY")
end

--- ========================================================= ---
---  On Hide
--- ========================================================= ---
function mod:OnHide(f)
	if not(f) then return end
	
	f.GUID = nil
end

--- ========================================================= ---
---  On Show
--- ========================================================= ---
function mod:OnShow(f)
	if not(f) then return end
	
	f.GUID = nil
	DaHud:UpdateFrame(mod, f)
end

--- ========================================================= ---
---  Refresh Frame
--- ========================================================= ---
function mod:RefreshFrame(id, oldValue)
	if not(id) then return end

	local f = DaHud.Frames.Portraits[id]
	local settings = DaHud.db.profile.portraits[id]
	
	DaHud:SetFrameChild(f.Portrait, f, settings)
	DaHud:SetFrameChild(f.Border, f, settings)
	DaHud:SetFrameChild(f.BorderTex, f.Border, settings)
	
	f:SetBackdropColor(0, 0, 0, 1)
	
	f.Border:SetFrameLevel(settings.framelevel + 1)
	
	if (settings.border == "custom") then
		f.BorderTex:SetTexture(settings.customBorder)
	else
		if DaHud.Portraits.Elements.textures[settings.border] then
			f.BorderTex:SetTexture(DaHud.Portraits.Elements.textures[settings.border])
		end
	end
end

--- ========================================================= ---
---  Update Frame
--- ========================================================= ---
function mod:UpdateFrame(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.portraits[id]

	if type(mod["Update_"..settings.type]) == "function" then
		mod["Update_"..settings.type](mod, f)
	end
end