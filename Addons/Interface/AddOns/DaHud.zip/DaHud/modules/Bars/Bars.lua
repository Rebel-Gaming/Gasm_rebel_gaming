--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:NewModule("Bars")
local SM = LibStub("LibSharedMedia-3.0")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

DaHud.Frames.Bars = {}

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Bars = {}

DaHud.Bars.Type = {
	player = {},
	pet = {},
	pettarget = {},
	target = {},
	targettarget = {},
	targettargettarget = {},
	focus = {},
	focustarget = {},
	party1 = {},
	party1pet = {},
	party1target = {},
	party2 = {},
	party2pet = {},
	party2target = {},
	party3 = {},
	party3pet = {},
	party3target = {},
	party4 = {},
	party4pet = {},
	party4target = {},
}

DaHud.Bars.Plugins = {
}

DaHud.Bars.Textures = {
	dahud_bar = L["(Bar) DaHud Bar"],
	dahud_left = L["(Border) DaHud Left"], 
	dahud_right = L["(Border) DaHud Right"], 
	dahud_center = L["(Border) DaHud Center"], 
	dahud_double = L["(Border) DaHud Double"],
	dahud_cbleft = L["(Casting) DaHud Left"], 
	dahud_cbright = L["(Casting) DaHud Right"], 
	dahud_cbcenter = L["(Casting) DaHud Center"], 
	dahud_cbdouble = L["(Casting) DaHud Double"], 
	custom = L["Custom"],
}

DaHud.Bars.Elements = {
	textures = {
		dahud_bar = "Interface\\Addons\\DaHud\\media\\Bar",
		dahud_left = "Interface\\Addons\\DaHud\\media\\LeftHud",
		dahud_right = "Interface\\Addons\\DaHud\\media\\RightHud",
		dahud_center = "Interface\\Addons\\DaHud\\media\\CenterHud",
		dahud_double = "Interface\\Addons\\DaHud\\media\\DoubleHud",
		dahud_cbleft = "Interface\\Addons\\DaHud\\media\\CBLeftHud.tga",
		dahud_cbright = "Interface\\Addons\\DaHud\\media\\CBRightHud.tga",
		dahud_cbcenter = "Interface\\Addons\\DaHud\\media\\CBCenterHud.tga",
		dahud_cbdouble = "Interface\\Addons\\DaHud\\media\\CBDoubleHud.tga",	
	},
}

--- ========================================================= ---
---  Setup Database
--- ========================================================= ---
function mod:OnRegister()
	self:RegisterDefaults({
		bars = {
			["**"] = {
				name = "Default",
				active = false,
				framestrata = "LOW",
				framelevel = 1,
				point = "CENTER",
				anchor = "UIParent",
				relative = "CENTER",
				posx = 0,
				posy = 0,
				width = 30,
				height = 250,
				unit = "player",
				type = "health",
				style = "vertical",
				background = "dahud_bar",
				customBackground = "",
				border = "dahud_center",
				customBorder = "",
				bar = "dahud_bar",
				customBar = "",
				colorByClass = false,
				colorByHostility = false,
				colorByPetHappiness = false,
				animate = true,
				interactive = false,
				hideinraid = false,
			},
			bar1 = {
				name = "PlayerHealth",
				active = true,
				posx = -155,
				posy = 0,
				unit = "player",
				type = "health",
				border = "dahud_left",
			},
			bar2 = {
				name = "PlayerMana",
				active = true,
				posx = -135,
				posy = 0,
				unit = "player",
				type = "power",
				border = "dahud_right",
			},
			bar3 = {
				name = "TargetHealth",
				active = true,
				posx = 155,
				posy = 0,
				unit = "target",
				type = "health",
				border = "dahud_right",
			},
			bar4 = {
				name = "TargetMana",
				active = true,
				posx = 135,
				posy = 0,
				unit = "target",
				type = "power",
				border = "dahud_left",
			},
			bar5 = {
				name = "PlayerHealthCasting",
				active = true,
				framelevel = 2,
				anchor = "DaHud_bar1",
				posx = 0,
				posy = 0,
				unit = "player",
				type = "casting",
				background = "custom",
				border = "custom",
				bar = "dahud_cbleft",
			},
			bar6 = {
				name = "PlayerManaCasting",
				active = true,
				framelevel = 2,
				anchor = "DaHud_bar2",
				posx = 0,
				posy = 0,
				unit = "player",
				type = "casting",
				background = "custom",
				border = "custom",
				bar = "dahud_cbright",
			},
			bar7 = {
				name = "TargetHealthCasting",
				active = true,
				framelevel = 2,
				anchor = "DaHud_bar3",
				posx = 0,
				posy = 0,
				unit = "target",
				type = "casting",
				background = "custom",
				border = "custom",
				bar = "dahud_cbright",
			},
			bar8 = {
				name = "TargetManaCasting",
				active = true,
				framelevel = 2,
				anchor = "DaHud_bar4",
				posx = 0,
				posy = 0,
				unit = "target",
				type = "casting",
				background = "custom",
				border = "custom",
				bar = "dahud_cbleft",
			},
			pluginsDisabled = {
			},
		}
	})
end

--- ========================================================= ---
---  System
--- ========================================================= ---
function mod:OnEnable()
	DaHud:EnableModule(mod)
end

function mod:OnDisable()
	DaHud:DisableModule(mod)
end