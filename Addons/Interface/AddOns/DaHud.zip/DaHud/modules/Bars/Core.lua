--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Bars")
local SM = LibStub("LibSharedMedia-3.0")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions(id, name)
	if not(id) or not(name) then return end

	DaHud.options.args.Bars.args[id].args.Appearance.args.Group1 = {
		name = L["Style"],
		type = "group",
		inline = true,
		order = 1,
		args = {
			style = {
				name = L["Style"],
				type = "select",
				order = 1,
				values = {vertical = L["Vertical"], horizontal = L["Horizontal"],},
				get = function(info) 
					return DaHud.db.profile.bars[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.bars[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
		},
	}
	
	DaHud.options.args.Bars.args[id].args.Appearance.args.Group2 = {
		name = L["Background"],
		type = "group",
		inline = true,
		order = 2,
		hidden = function(info) return DaHud.db.profile.bars[info[#info-2]].style ~= "vertical" end,
		args = {
			background = {
				name = L["Background"],
				type = "select",
				order = 1,
				disabled = function(info) 
					return DaHud.db.profile.bars[info[#info-3]].style ~= "vertical" 
				end,
				values = function(info)
					local id = info[#info-3]
					local style = DaHud.db.profile.bars[id].style
					
					if (style == "vertical") then
						return DaHud.Bars.Textures
					else
						return SM:List("statusbar")
					end
				end,
				get = function(info) 
					return DaHud.db.profile.bars[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.bars[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
			customBackground = {
				name = L["Custom"],
				type = "input",
				width = "full",
				order = 2,
				disabled = function(info) 
					return DaHud.db.profile.bars[info[#info-3]].background ~= "custom" 
				end,
				get = function(info) 
					return DaHud.db.profile.bars[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.bars[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
		},
	}

	DaHud.options.args.Bars.args[id].args.Appearance.args.Group3 = {
		name = L["Border"],
		type = "group",
		inline = true,
		order = 3,
		hidden = function(info) 
			return DaHud.db.profile.bars[info[#info-2]].style ~= "vertical" 
		end,
		args = {
			border = {
				name = L["Border"],
				type = "select",
				order = 1,
				disabled = function(info) return DaHud.db.profile.bars[info[#info-3]].style ~= "vertical" end,
				values = function(info)
					local id = info[#info-3]
					local style = DaHud.db.profile.bars[id].style
					
					if (style == "vertical") then
						return DaHud.Bars.Textures
					else
						return SM:List("statusbar")
					end
				end,
				get = function(info) 
					return DaHud.db.profile.bars[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.bars[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
			customBorder = {
				name = L["Custom"],
				type = "input",
				width = "full",
				order = 2,
				disabled = function(info) return DaHud.db.profile.bars[info[#info-3]].border ~= "custom" end,
				get = function(info) 
					return DaHud.db.profile.bars[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.bars[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
		},
	}
	
	DaHud.options.args.Bars.args[id].args.Appearance.args.Group4 = {
		name = L["Bar"],
		type = "group",
		inline = true,
		order = 4,
		args = {
			bar = {
				name = L["Bar"],
				type = "select",
				order = 1,
				values = function(info)
					local id = info[#info-3]
					local style = DaHud.db.profile.bars[id].style
					
					if (style == "vertical") then
						return DaHud.Bars.Textures
					else
						return SM:List("statusbar")
					end
				end,
				get = function(info)
					if DaHud.db.profile.bars[info[#info-3]].style == "vertical" then
						return DaHud.db.profile.bars[info[#info-3]][info[#info]]
					else
						local tbl = SM:List("statusbar")
						for k, v in pairs(tbl) do
							if DaHud.db.profile.bars[info[#info-3]][info[#info]] == v then
								return k
							end
						end
					end
				end,
				set = function(info, value)
					if DaHud.db.profile.bars[info[#info-3]].style == "vertical" then
						DaHud.db.profile.bars[info[#info-3]][info[#info]] = value
						DaHud:RefreshFrame(mod, info[#info-3])
					else
						local tbl = SM:List("statusbar")
						local tex = tbl[value]
						DaHud.db.profile.bars[info[#info-3]][info[#info]] = tex
						DaHud:RefreshFrame(mod, info[#info-3])
					end
				end,
			},
			customBar = {
				name = L["Custom"],
				type = "input",
				width = "full",
				order = 2,
				disabled = function(info) return DaHud.db.profile.bars[info[#info-3]].bar ~= "custom" end,
				hidden = function(info) return DaHud.db.profile.bars[info[#info-3]].style ~= "vertical" end,
				get = function(info) 
					return DaHud.db.profile.bars[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.bars[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
		},
	}
	
	DaHud.options.args.Bars.args[id].args.Appearance.args.Group5 = {
		name = L["Misc"],
		type = "group",
		inline = true,
		order = 5,
		args = {
			animate = {
				name = L["Animate"],
				type = "toggle",
				order = 1,
				get = function(info) 
					return DaHud.db.profile.bars[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.bars[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
			interactive = {
				name = L["Interactive"],
				type = "toggle",
				order = 1,
				get = function(info) 
					return DaHud.db.profile.bars[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.bars[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
			hideinraid = {
				name = L["Hide In Raid"],
				type = "toggle",
				order = 1,
				get = function(info) 
					return DaHud.db.profile.bars[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.bars[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
		},
	}
end

--- ========================================================= ---
---  Frame Type
--- ========================================================= ---
function mod:FrameType()
	return "Button", "SecureUnitButtonTemplate"
end

--- ========================================================= ---
---  Set Attributes
--- ========================================================= ---
function mod:SetAttributes(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Bars[id]

	f.Background = newFrame("Texture", nil, f, "BACKGROUND")
	f.SecBar = newFrame("Texture", nil, f, "ARTWORK")
	f.Bar = newFrame("Texture", nil, f, "OVERLAY")
	
	f.Border = newFrame("Frame", nil, f)
	f.BorderTex = newFrame("Texture", nil, f.Border, "OVERLAY")
	
	f.SecStatusBar = newFrame("StatusBar", nil, f)
	f.StatusBar = newFrame("StatusBar", nil, f)
end

--- ========================================================= ---
---  On Update
--- ========================================================= ---
function mod:OnUpdate(f)
	if not(f) then return end
	
	local name = string.gsub(f:GetName(), "DaHud_", "")

	local currentTime = GetTime()
	
	if f.animating then
		if not(f.animationEndTime) then
			f.animationEndTime = 0
		end
		
		local v = (1 - math.cos(1 - ((f.animationEndTime - currentTime) / 0.05) * math.pi )) / 2
		local value = (f.currentValue or 0) * (1 - v) + (f.targetValue or 0) * v

		f.currentValue = value

		if f.currentValue == f.targetValue then
		    f.animating = nil
		end
		
		DaHud:UpdateFrame(mod, f)
	end
end

--- ========================================================= ---
---  Refresh Frame
--- ========================================================= ---
function mod:RefreshFrame(id, oldValue)
	if not(id) then return end

	local f = DaHud.Frames.Bars[id]
	local settings = DaHud.db.profile.bars[id]
	
	DaHud:SetFrameChild(f.Background, f, settings)
	DaHud:SetFrameChild(f.SecBar, f, settings)
	DaHud:SetFrameChild(f.Bar, f, settings)
	
	DaHud:SetFrameChild(f.Border, f, settings)
	DaHud:SetFrameChild(f.BorderTex, f.Border, settings)
	
	DaHud:SetFrameStatusBar(f.SecStatusBar, f, settings)
	DaHud:SetFrameStatusBar(f.StatusBar, f, settings)
	
	f.SecBar:ClearAllPoints()
	f.SecBar:SetPoint("BOTTOM", f, "BOTTOM", 0, 0)
	f.SecBar:Hide()
	
	f.Bar:ClearAllPoints()
	f.Bar:SetPoint("BOTTOM", f, "BOTTOM", 0, 0)
	
	f.Border:SetFrameLevel(settings.framelevel + 1)
	
	f.SecStatusBar:Hide()
	
	f.StatusBar:SetFrameLevel(settings.framelevel + 1)

	if (settings.style == "vertical") then
		if (settings.background == "custom") then
			f.Background:SetTexture(settings.customBackground)
		else
			if DaHud.Bars.Elements.textures[settings.background] then
				f.Background:SetTexture(DaHud.Bars.Elements.textures[settings.background])
			end
		end
		
		if (settings.border == "custom") then
			f.BorderTex:SetTexture(settings.customBorder)
		else
			if DaHud.Bars.Elements.textures[settings.border] then
				f.BorderTex:SetTexture(DaHud.Bars.Elements.textures[settings.border])
			end
		end
		
		if (settings.bar == "custom") then
			f.SecBar:SetTexture(settings.customBar)
		else
			if DaHud.Bars.Elements.textures[settings.bar] then
				f.SecBar:SetTexture(DaHud.Bars.Elements.textures[settings.bar])
			end
		end
		
		if (settings.bar == "custom") then
			f.Bar:SetTexture(settings.customBar)
		else
			if DaHud.Bars.Elements.textures[settings.bar] then
				f.Bar:SetTexture(DaHud.Bars.Elements.textures[settings.bar])
			end
		end
		
		f.SecStatusBar:SetStatusBarTexture(nil)
		f.StatusBar:SetStatusBarTexture(nil)
		
		f:SetBackdropBorderColor(0, 0, 0, 0)
	else
		f.BorderTex:SetTexture(nil)
		f.SecBar:SetTexture(nil)
		f.Bar:SetTexture(nil)
		
		f.Background:SetTexture(SM:Fetch("statusbar", settings.bar))
		f.SecStatusBar:SetStatusBarTexture(SM:Fetch("statusbar", settings.bar))
		f.StatusBar:SetStatusBarTexture(SM:Fetch("statusbar", settings.bar))
		
		f:SetBackdropBorderColor(0, 0, 0, 1)
	end
end

--- ========================================================= ---
---  Update Frame
--- ========================================================= ---
function mod:UpdateFrame(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.bars[id]
	
	if type(mod["Update_"..settings.type]) == "function" then
		mod["Update_"..settings.type](mod, f)
	end
	
	local p = f.currentValue or 0
		
	if p > 1 then p = 1 end
	if p < 0 then p = 0 end
	
	local pSec = f.currentSecValue or 0
	
	if pSec > 1 then pSec = 1 end
	if pSec < 0 then pSec = 0 end
	
	if DaHud:InConfigMode() then
		p = 0.5
		f.currentValue = 0.5
		f.targetValue = 0.5
		f.animating = false
		
		pSec = 0.75
		f.currentSecValue = 0.75
		f.targetSecValue = 0.75
		
		f:SetAlpha(1)
	end

	local gapTop, gapBottom, gapLeft, gapRight = 0, 0, 0, 0
		
	local gapTopP = gapTop / settings.height
	local gapBottomP = gapBottom / settings.height
	local h = (settings.height - gapTop - gapBottom) * p
	local top = 1 - (p - gapTopP)
	local bottom = 1 - gapBottomP
	
	top = top - (gapTopP + gapBottomP) * (1 - p)
	
	local hSec = (settings.height - gapTop - gapBottom) * pSec
	local topSec = 1 - (pSec - gapTopP)
		
	topSec = topSec - (gapTopP + gapBottomP) * (1 - pSec)

	f.SecBar:SetHeight(hSec)
	f.SecBar:SetTexCoord(0, 1, topSec, bottom)	
	f.Bar:SetHeight(h)
	f.Bar:SetTexCoord(0, 1, top, bottom)
	
	f.SecStatusBar:SetValue(pSec)
	f.StatusBar:SetValue(p)
end