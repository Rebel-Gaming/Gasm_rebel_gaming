--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Text")
local SM = LibStub("LibSharedMedia-3.0")
local DogTag = LibStub("LibDogTag-3.0")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame
local newTable, delTable = DaHud.newTable, DaHud.delTable

local _G = getfenv(0)

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions(id, name)
	if not(id) or not(name) then return end

	DaHud.options.args.Text.args[id].args.Appearance.args.Group1 = {
		name = L["Font"],
		type = "group",
		inline = true,
		order = 1,
		args = {
			Group1 = {
				name = "",
				type = "group",
				order = 1,
				args = {
					font = {
						name = L["Font"],
						type = "select",
						order = 1,
						values = SM:List("font"),
						get = function(info)
							local tbl = SM:List("font")
							for k, v in pairs(tbl) do
								if DaHud.db.profile.text[info[#info-4]][info[#info]] == v then
									return k
								end
							end
						end,
						set = function(info, value)
							local tbl = SM:List("font")
							local tex = tbl[value]
							DaHud.db.profile.text[info[#info-4]][info[#info]] = tex
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
					fontsize= {
						name = L["Size"],
						type = "range",
						order = 2,
						min = 4,
						max = 38,
						step = 1,
						get = function(info) 
							return DaHud.db.profile.text[info[#info-4]][info[#info]]
						end,
						set = function(info, value) 
							DaHud.db.profile.text[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
				},
			},
			Group2 = {
				name = "",
				type = "group",
				order = 2,
				args = {
					fontalign = {
						name = L["Align"],
						type = "select",
						order = 1,
						values = {LEFT = L["LEFT"], CENTER = L["CENTER"], RIGHT = L["RIGHT"],},
						get = function(info) 
							return DaHud.db.profile.text[info[#info-4]][info[#info]]
						end,
						set = function(info, value) 
							DaHud.db.profile.text[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
				},
			},
			Group3 = {
				name = "",
				type = "group",
				order = 3,
				args = {
					fontoutline = {
						name = L["Outline"],
						type = "toggle",
						order = 1,
						get = function(info) 
							return DaHud.db.profile.text[info[#info-4]][info[#info]]
						end,
						set = function(info, value) 
							DaHud.db.profile.text[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
				},
			},
		},
	}
	
	DaHud.options.args.Text.args[id].args.Appearance.args.Group2 = {
		name = L["Misc"],
		type = "group",
		inline = true,
		order = 2,
		args = {
			interactive = {
				name = L["Interactive"],
				type = "toggle",
				order = 1,
				get = function(info) 
					return DaHud.db.profile.text[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.text[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
			hideinraid = {
				name = L["Hide In Raid"],
				type = "toggle",
				order = 1,
				get = function(info) 
					return DaHud.db.profile.text[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.text[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
		},
	}
	
	DaHud.options.args.Text.args[id].args.UnitType.args.Group2 = {
		name = L["Type"],
		type = "group",
		inline = true,
		order = 2,
		args = {
			Group1 = {
				name = "",
				type = "group",
				order = 1,
				args = {
					fonttype = {
						name = L["Type"],
						type = "select",
						order = 1,
						values = function(info)
							local tbl = {}
							for k, v in pairs(DaHud.Text.Elements) do
								tbl[k] = k
							end
							return tbl
						end,
						get = function(info)
							for k, v in pairs(DaHud.Text.Elements) do
								if DaHud.db.profile.text[info[#info-4]][info[#info]] == k then
									return k
								end
							end
						end,
						set = function(info, value)
							DaHud.db.profile.text[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
				},
			},
			Group2 = {
				name = "",
				type = "group",
				order = 2,
				args = {
					fontstyle = {
						name = L["Style"],
						type = "select",
						order = 1,
						hidden = function(info)
							local type = DaHud.db.profile.text[info[#info-4]].fonttype
							if type == "Custom" then
								return true
							else
								return false
							end
						end,
						values = function(info)
							local tbl = {}
							local type = DaHud.db.profile.text[info[#info-4]].fonttype
							if DaHud.Text.Elements[type] then
								for k, v in pairs(DaHud.Text.Elements[type]) do
									tbl[k] = k
								end
							end
							return tbl
						end,
						get = function(info)
							local type = DaHud.db.profile.text[info[#info-4]].fonttype
							if DaHud.Text.Elements[type] then
								for k, v in pairs(DaHud.Text.Elements[type]) do
									if DaHud.db.profile.text[info[#info-4]][info[#info]] == k then
										return k
									end
								end
							end
						end,
						set = function(info, value)
							DaHud.db.profile.text[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
					fontcustom = {
						name = L["Custom"],
						type = "input",
						order = 2,
						width = "full",
						multiline = true,
						hidden = function(info)
							local type = DaHud.db.profile.text[info[#info-4]].fonttype
							if type == "Custom" then
								return false
							else
								return true
							end
						end,
						get = function(info) 
							return DaHud.db.profile.text[info[#info-4]][info[#info]]
						end,
						set = function(info, value)
							DaHud.db.profile.text[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
					help = {
						name = L["Open DogTag Help"],
						type = "execute",
						order = 3,
						width = "full",
						hidden = function(info)
							local type = DaHud.db.profile.text[info[#info-4]].fonttype
							if type == "Custom" then
								return false
							else
								return true
							end
						end,
						func = function() DogTag:OpenHelp() end,
					},
				},
			},
		},
	}
	
end

--- ========================================================= ---
---  Frame Type
--- ========================================================= ---
function mod:FrameType()
	return "Button", "SecureUnitButtonTemplate"
end

--- ========================================================= ---
---  Set Attributes
--- ========================================================= ---
function mod:SetAttributes(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Text[id]
	
	f.Text = newFrame("FontString", nil, f, "OVERLAY")
end

--- ========================================================= ---
---  Refresh Frame
--- ========================================================= ---
function mod:RefreshFrame(id, oldValue)
	if not(id) then return end

	local f = DaHud.Frames.Text[id]
	local settings = DaHud.db.profile.text[id]
		
	DaHud:SetFrameChild(f.Text, f, settings)
	
	f.useConfigBackdropColor = true
	
	f.Text:SetFont(SM:Fetch("font", settings.font), settings.fontsize)
	f.Text:SetJustifyH(settings.fontalign)
	
	if settings.fontoutline then
		f.Text:SetShadowColor(0, 0, 0)
		f.Text:SetShadowOffset(0.8, -0.8)
	else
		f.Text:SetShadowColor(0, 0, 0)
		f.Text:SetShadowOffset(0, 0)
	end
	
	if (settings.fonttype == "Custom") then
		local string = settings.fontcustom
	
		local kwargs = newTable()
		kwargs.unit = settings.unit
		DogTag:AddFontString(f.Text, f, string, "Unit", kwargs )
		delTable(kwargs)
	else
		if DaHud.Text.Elements[settings.fonttype] and DaHud.Text.Elements[settings.fonttype][settings.fontstyle] then
			local string = DaHud.Text.Elements[settings.fonttype][settings.fontstyle]

			local kwargs = newTable()
			kwargs.unit = settings.unit
			DogTag:AddFontString(f.Text, f, string, "Unit", kwargs )
			delTable(kwargs)
		end
	end
end