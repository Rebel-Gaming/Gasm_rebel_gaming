--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:NewModule("Text")
local SM = LibStub("LibSharedMedia-3.0")
local DogTag = LibStub("LibDogTag-3.0")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

DaHud.Frames.Text = {}

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Text = {}

DaHud.Text.Elements = {
	[L["Name"]] = {
		[L["Standard"]]             = "[Name] [(AFK or DND):Angle]",
		[L["Hostility Colored"]]    = "[Name:HostileColor] [(AFK or DND):Angle]",
		[L["Class Colored"]]        = "[Name:ClassColor] [(AFK or DND):Angle]",
		[L["Long"]]                 = "[Level] [Name:ClassColor] [(AFK or DND):Angle]",
		[L["Long w/ Druid form"]]   = "[Level] [Name:ClassColor] [DruidForm:Paren] [(AFK or DND):Angle]",
	},
	[L["Class"]] = {
		[L["Standard"]]         	= "[Classification] [Level:DifficultyColor] [(if (IsPlayer or (IsEnemy and not IsPet)) then Class):ClassColor] [DruidForm:Paren] [SmartRace]",
		[L["Player Classes Only"]]  = "[Classification] [Level:DifficultyColor] [(if IsPlayer then Class):ClassColor] [DruidForm:Paren] [SmartRace]",
		[L["Short"]]                = "[(Level (if Classification then '+')):DifficultyColor] [SmartRace]",
	},
	[L["Guild"]] = {
		[L["Standard"]]				= "[Guild:Angle]",
	},
	[L["Health"]] = {
		[L["Absolute"]]       		= "[Status or FractionalHP(known=true):Green or PercentHP:Percent:Green]",
		[L["Absolute Short"]] 		= "[Status or FractionalHP(known=true):Short:Green or PercentHP:Percent:Green]",
		[L["Difference"]]     		= "[Status or -MissingHP:Hide(0):Green]",
		[L["Percent"]]        		= "[Status or PercentHP:Percent:Green]",
		[L["Mini"]]          		= "[HP:VeryShort:Green]",
		[L["Smart"]]          		= "[Status or (if IsFriend then MissingHP:Hide(0):Short:Color('ff7f7f') else FractionalHP(known=true):Short or PercentHP:Percent:Green)]",
		[L["Absolute and Percent"]] = "[Status or (FractionalHP:Short:Green ' ' PercentHP:Percent:Paren)]",
		[L["Informational"]]  		= "[Status or (Concatenate((if IsFriend then MissingHP:Hide(0):Short:Color('ff7f7f')), ' || ') FractionalHP:Short:Green ' ' PercentHP:Percent:Paren)]",
	},
	[L["Power"]] = {
		[L["Absolute"]]       		= "[if HasMP then FractionalMP:PowerColor]",
		[L["Absolute Short"]] 		= "[if HasMP then FractionalMP:Short:PowerColor]",
		[L["Difference"]]     		= "[-MissingMP:Hide(0):PowerColor]",
		[L["Percent"]]        		= "[PercentMP:Percent:PowerColor]",
		[L["Mini"]]           		= "[if HasMP then MP:VeryShort:PowerColor]",
		[L["Smart"]]         		= "[-MissingMP:Hide(0):Short:Color('7f7fff')]",
		[L["Absolute and Percent"]] = "[FractionalMP:Short:PowerColor ' ' PercentMP:Percent:Paren]",
	},
	[L["Druid Mana"]] = {
		[L["Absolute"]]       		= "[if not IsMana then FractionalDruidMP]",
		[L["Absolute Short"]] 		= "[if not IsMana then FractionalDruidMP:Short]",
		[L["Difference"]]     		= "[if not IsMana then -MissingDruidMP]",
		[L["Percent"]]        		= "[if not IsMana then PercentDruidMP:Percent]",
		[L["Mini"]]           		= "[if not IsMana then DruidMP:VeryShort]",
		[L["Smart"]]          		= "[if not IsMana then MissingDruidMP:Hide(0):Short:Color('7f7fff')]",
	},
	[L["Threat"]] = {
		[L["Absolute"]]       		= "[if HasThreat then Threat:Color('ff7f7f')]",
		[L["Absolute Short"]] 		= "[if HasThreat then Threat:Short:Color('ff7f7f')]",
		[L["Fractional"]]     		= "[if HasThreat then FractionalThreat:Color('ff7f7f')]",
		[L["Fractional Short"]]		= "[if HasThreat then FractionalThreat:Short:Color('ff7f7f')]",
		[L["Difference"]]     		= "[if HasThreat then -MissingThreat:Color('ff7f7f')]",
		[L["Percent"]]        		= "[if HasThreat then PercentThreat:Percent:Color('ff7f7f')]",
		[L["Mini"]]           		= "[if HasThreat then Threat:VeryShort:Color('ff7f7f')]",
	},
	[L["Cast"]] = {
		[L["Standard Name"]] 		= "[Alpha((-CastStopDuration or 0) + 1) CastStopMessage or (CastName ' ' CastTarget:Paren)]",
		[L["Standard Time"]] 		= "[if not CastStopDuration then Concatenate('+', CastDelay:Round(1):Hide(0)):Red ' ' [CastEndDuration >= 0 ? '%.1f':Format(CastEndDuration)]]",
	},
	[L["Combo"]] = {
		[L["Standard"]]       		= "[if IsEnergy(unit='player') then Combos:Hide(0)]" or "[Combos:Hide(0)]",
	},
	[L["Experience"]] = {
		[L["Absolute"]]				= "[FractionalXP:Fuchsia]",
		[L["Absolute Short"]]		= "[FractionalXP:Short:Fuchsia]",
		[L["Difference"]]			= "[MissingXP:Fuchsia]",
		[L["Percent"]]				= "[PercentXP:Percent:Fuchsia]",
		[L["Smart"]]				= "[FractionalXP:Fuchsia ' ' PercentXP:Percent:Paren]",
		[L["Informational"]]		= "[FractionalXP:Fuchsia ' ' PercentXP:Percent:Paren ' ' RestXP:Cyan ' ' PercentRestXP:Percent:Cyan:Paren]",
	},
	[L["Reputation"]] = {
		[L["Absolute"]]				= "[FractionalReputation:ReputationColor]",
		[L["Absolute Short"]]		= "[FractionalReputation:Short:ReputationColor]",
		[L["Difference"]]			= "[MissingReputation:ReputationColor]",
		[L["Percent"]]				= "[PercentReputation:Percent:ReputationColor]",
		[L["Smart"]]				= "[FractionalReputation:ReputationColor ' ' PercentReputation:Percent:Paren]",
	},
	[L["Range"]] = {
		[L["Standard"]]				= "[if Range then Range:Gray ' yds':Gray]",
	},
	[L["Custom"]] ={
	}
}

--- ========================================================= ---
---  Setup Database
--- ========================================================= ---
function mod:OnRegister()
	self:RegisterDefaults({
		text = {
			["**"] = {
				name = "Default",
				active = false,
				framestrata = "LOW",
				framelevel = 1,
				point = "CENTER",
				anchor = "UIParent",
				relative = "CENTER",
				posx = 0,
				posy = 0,
				width = 175,
				height = 20,
				unit = "player",
				font = "Arial Narrow",
				fontsize = 12,
				fontoutline = true,
				fontalign = "CENTER",
				fonttype = "Health",
				fontstyle = "Informational",
				fontcustom = "",
				interactive = false,
				hideinraid = false,
			},
			text1 = {
				name = "PlayerHealth",
				active = true,
				posx = -210,
				posy = -135,
				unit = "player",
				fontalign = "RIGHT",
				fonttype = "Health",
				fontstyle = "Absolute and Percent",
			},
			text2 = {
				name = "PlayerMana",
				active = true,
				posx = -210,
				posy = -155,
				unit = "player",
				fontalign = "RIGHT",
				fonttype = "Power",
				fontstyle = "Absolute and Percent",
			},
			text3 = {
				name = "TargetHealth",
				active = true,
				posx = 210,
				posy = -135,
				unit = "target",
				fontalign = "LEFT",
				fonttype = "Health",
				fontstyle = "Absolute and Percent",
			},
			text4 = {
				name = "TargetMana",
				active = true,
				posx = 210,
				posy = -155,
				unit = "target",
				fontalign = "LEFT",
				fonttype = "Power",
				fontstyle = "Absolute and Percent",		
			},
			text5 = {
				name = "PlayerCastingName",
				active = true,
				posx = -235,
				posy = 135,
				unit = "player",
				fontalign = "RIGHT",
				fonttype = "Cast",
				fontstyle = "Standard Name",
			},
			text6 = {
				name = "PlayerCastingTime",
				active = true,
				posx = -55,
				posy = 135,
				unit = "player",
				fontalign = "LEFT",
				fonttype = "Cast",
				fontstyle = "Standard Time",
			},
			text7 = {
				name = "TargetCastingName",
				active = true,
				posx = 235,
				posy = 135,
				unit = "target",
				fontalign = "LEFT",
				fonttype = "Cast",
				fontstyle = "Standard Name",
			},
			text8 = {
				name = "TargetCastingTime",
				active = true,
				posx = 55,
				posy = 135,
				unit = "target",
				fontalign = "RIGHT",
				fonttype = "Cast",
				fontstyle = "Standard Time",
			},
			pluginsDisabled = {
			},
		}
	})
end

--- ========================================================= ---
---  System
--- ========================================================= ---
function mod:OnEnable()
	DaHud:EnableModule(mod)
end

function mod:OnDisable()
	DaHud:DisableModule(mod)
end