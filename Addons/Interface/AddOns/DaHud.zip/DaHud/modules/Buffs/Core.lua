--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Buffs")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame
local newList, delList = DaHud.newList, DaHud.delList

local _G = getfenv(0)

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions(id, name)
	if not(id) or not(name) then return end

	DaHud.options.args.Buffs.args[id].args.Appearance.args.Group1 = {
		name = L["Style"],
		type = "group",
		inline = true,
		order = 1,
		args = {
			Group1 = {
				name = "",
				type = "group",
				order = 1,
				args = {
					direction = {
						name = L["Direction"],
						type = "select",
						order = 1,
						values = function(info, value)
							return DaHud.Buffs.Direction
						end,
						get = function(info) 
							return DaHud.db.profile.buffs[info[#info-4]][info[#info]]
						end,
						set = function(info, value)
							DaHud.db.profile.buffs[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
					maxaura = {
						name = L["Max Aura's"],
						type = "range",
						order = 2,
						min = 1,
						max = 40,
						step = 1,
						get = function(info) 
							return DaHud.db.profile.buffs[info[#info-4]][info[#info]]
						end,
						set = function(info, value)
							DaHud.db.profile.buffs[info[#info-4]][info[#info]] = value
							
							if DaHud.db.profile.buffs[info[#info-4]].columns > value then
								DaHud.db.profile.buffs[info[#info-4]].columns = value
							end
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
				},
			},
			Group2 = {
				name = "",
				type = "group",
				order = 2,
				args = {
					columns = {
						name = L["Columns"],
						type = "range",
						order = 2,
						min = 1,
						max = 40,
						step = 1,
						get = function(info) 
							return DaHud.db.profile.buffs[info[#info-4]][info[#info]]
						end,
						set = function(info, value)
							DaHud.db.profile.buffs[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
					spacing = {
						name = L["Spacing"],
						type = "range",
						order = 2,
						min = 0,
						max = 20,
						step = 1,
						get = function(info) 
							return DaHud.db.profile.buffs[info[#info-4]][info[#info]]
						end,
						set = function(info, value)
							DaHud.db.profile.buffs[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
				},
			},
		},
	}

	DaHud.options.args.Buffs.args[id].args.Appearance.args.Group2 = {
        name = L["Misc"],
        type = "group",
        inline = true,
        order = -1,
        args = {
            filter = {
                name = L["Filter"],
                type = "toggle",
                order = 1,
                get = function(info) 
                    return DaHud.db.profile.buffs[info[#info-3]][info[#info]]
                end,
                set = function(info, value) 
                    DaHud.db.profile.buffs[info[#info-3]][info[#info]] = value
                    DaHud:RefreshFrame(mod, info[#info-3])
                end,
            },
            hideinraid = {
                name = L["Hide In Raid"],
                type = "toggle",
                order = 2,
                get = function(info) 
                    return DaHud.db.profile.buffs[info[#info-3]][info[#info]]
                end,
                set = function(info, value) 
                    DaHud.db.profile.buffs[info[#info-3]][info[#info]] = value
                    DaHud:RefreshFrame(mod, info[#info-3])
                end,
            },
        },
	}	
end

--- ========================================================= ---
---  Set Attributes
--- ========================================================= ---
function mod:SetAttributes(id)
	if not(id) then return end

	local f = DaHud.Frames.Buffs[id]
	
	for i = 1, 40 do
		f["Buff"..i] = newFrame("Button", "DaHud_"..(id).."_Buff"..i, f)
		f["Buff"..i].Icon = newFrame("Texture", nil, f["Buff"..i], "BACKGROUND")
		f["Buff"..i].Count = newFrame("FontString", nil, f["Buff"..i], "OVERLAY")
		f["Buff"..i].cooldown = newFrame("Cooldown", nil, f["Buff"..i])
		f["Buff"..i].cooldownText = newFrame("FontString", nil, f["Buff"..i], "OVERLAY")
	end
end

--- ========================================================= ---
---  Refresh Frame
--- ========================================================= ---
function mod:RefreshFrame(id, oldValue)
	if not(id) then return end

	local f = DaHud.Frames.Buffs[id]
	local settings = DaHud.db.profile.buffs[id]
	
	for i = 1, 40 do
		f["Buff"..i]:RegisterForClicks("RightButtonUp")
		f["Buff"..i]:SetID(i)
		
		f["Buff"..i]:ClearAllPoints()
		f["Buff"..i]:SetWidth(settings.width)
		f["Buff"..i]:SetHeight(settings.height)
		
		f["Buff"..i]:SetBackdrop({
			bgFile = "Interface\\Buttons\\WHITE8X8", tile = true, tileSize = 8,
			edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
			insets = { left = 1, right = 1, top = 1, bottom = 1 },
		})
		f["Buff"..i]:SetBackdropColor(0, 0, 0, 0)
		f["Buff"..i]:SetBackdropBorderColor(0, 0, 0, 1)
		
		f["Buff"..i].Icon:SetTexture("Interface\\Icons\\INV_Misc_Ear_Human_02")
		f["Buff"..i].Icon:SetTexCoord(0.10, 0.90, 0.10, 0.90)
		f["Buff"..i].Icon:SetPoint("TOPLEFT", f["Buff"..i], "TOPLEFT", 1, -1)
		f["Buff"..i].Icon:SetPoint("BOTTOMRIGHT", f["Buff"..i], "BOTTOMRIGHT", -1, 1)
		
		f["Buff"..i].Count:SetJustifyH("RIGHT")
		f["Buff"..i].Count:SetJustifyV("BOTTOM")
		f["Buff"..i].Count:SetPoint("BOTTOMRIGHT", f["Buff"..i], "BOTTOMRIGHT", -1, 1)
		f["Buff"..i].Count:SetFontObject(NumberFontNormalSmall)
		
		f["Buff"..i].cooldown:SetReverse(true)
		f["Buff"..i].cooldown:SetPoint("TOPLEFT", f["Buff"..i], "TOPLEFT", 1, -1)
		f["Buff"..i].cooldown:SetPoint("BOTTOMRIGHT", f["Buff"..i], "BOTTOMRIGHT", -1, 1)
		
		f["Buff"..i].cooldownText:SetTextColor(1, 1, 1, 1)
		f["Buff"..i].cooldownText:SetShadowColor(0, 0, 0, 1)
		f["Buff"..i].cooldownText:SetShadowOffset(0.8, -0.8)
		f["Buff"..i].cooldownText:SetPoint("TOPLEFT", f["Buff"..i], "TOPLEFT", 1, -1)
		f["Buff"..i].cooldownText:SetPoint("BOTTOMRIGHT", f["Buff"..i], "BOTTOMRIGHT", -1, 1)
		f["Buff"..i].cooldownText:SetFontObject(NumberFontNormalSmall)
	end
end

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents(id)
	if not(id) then return end

	local f = DaHud.Frames.Buffs[id]
	
	local settings = DaHud.db.profile.buffs[id]
	
	if settings.unit == "player" then
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
		f:RegisterEvent("UNIT_AURA")
	elseif settings.unit == "pet" or settings.unit == "party1pet" or settings.unit == "party2pet" or settings.unit == "party3pet" or settings.unit == "party4pet" then
	    f:RegisterEvent("UNIT_PET")
		f:RegisterEvent("UNIT_AURA")
	elseif settings.unit == "target" then
		f:RegisterEvent("PLAYER_TARGET_CHANGED")
		f:RegisterEvent("UNIT_AURA")
	elseif settings.unit == "focus" then
		f:RegisterEvent("PLAYER_FOCUS_CHANGED")
		f:RegisterEvent("UNIT_AURA")
	elseif settings.unit == "party1" or settings.unit == "party2" or settings.unit == "party3" or settings.unit == "party4" then
		f:RegisterEvent("PARTY_MEMBERS_CHANGED")
		f:RegisterEvent("UNIT_AURA")
	else
		DaHud:RegisterUpdate(self, "UpdateUneventedUnit", id, id)
	end
end

--- ========================================================= ---
---  Update Unevented Unit
--- ========================================================= ---
function mod:UpdateUneventedUnit(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Buffs[id]
	
	mod:UpdateFrame(f)
end

--- ========================================================= ---
---  Update Frame
--- ========================================================= ---
function mod:UpdateFrame(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.buffs[id]
	
	local auras = newList()
	local filtering = settings.filter
	local isBuff = settings.type == "buffs"
	local filteredSpells
	
	if settings.filter then
		if isBuff then
			if UnitIsUnit(settings.unit, "player") or UnitIsUnit(settings.unit, "pet") or UnitIsFriend("player", settings.unit) then
				filteredSpells = mod.Spells.friendBuffs
			else
				filtering = false
			end
		else
			if UnitIsUnit(settings.unit, "player") or UnitIsUnit(settings.unit, "pet") or UnitIsFriend("player", settings.unit) then
				filteredSpells = mod.Spells.friendDebuffs
			else
				filteredSpells = mod.Spells.enemyDebuffs
			end
		end
	end
	
	for i=1, 40 do
		local name, rank, iconTexture, count, debuffType, duration, timeLeft
		if isBuff then
			name, rank, iconTexture, count, duration, timeLeft = UnitBuff(settings.unit, i)
		else
			name, rank, iconTexture, count, debuffType, duration, timeLeft = UnitDebuff(settings.unit, i)
		end

		if name then
			local filtered = false
	
			if filtering then
				if not(filteredSpells[name]) then
					filtered = true
				elseif isBuff then
					if UnitIsUnit(settings.unit, "pet") then
						filtered = not(mod.Spells.totalPetBuffs[name])
					elseif isFriend then
						filtered = not(mod.Spells.friendBuffs[name])
					end
				else
					if UnitIsUnit(settings.unit, "pet") then
						filtered = not(mod.Spells.canDispel[debuffType]) and not(mod.Spells.totalPetDebuffs[name])
					elseif UnitIsUnit(settings.unit, "player") or UnitIsUnit(settings.unit, "pet") or UnitIsFriend("player", settings.unit) then
						filtered = not(mod.Spells.canDispel[debuffType]) and not(mod.Spells.friendDebuffs[name])
					else
						filtered = not(mod.Spells.enemyDebuffs[name])
					end
				end
			end
				
			if not(filtered) then
				auras[#auras+1] = newList(i, name, iconTexture, count, debuffType, duration, timeLeft)
			end
		end
	end
	
	mod.auraSort__isFriend = UnitIsUnit(settings.unit, "player") or UnitIsUnit(settings.unit, "pet") or UnitIsFriend("player", settings.unit)
	mod.auraSort__isBuff = isBuff
	
	table.sort(auras, mod.auraSort)
	
	for i=41, #auras do
		auras[i] = delList(auras[i])
	end
	
	for i=1, 40 do
		if (i > settings.maxaura) then
			f["Buff"..i].id = nil
			f["Buff"..i].count = nil
			f["Buff"..i].duration = nil
			f["Buff"..i].startTime = nil
			f["Buff"..i].isLarge = nil
			
			f["Buff"..i]:Hide()
		else
			if (i <= #auras) then
				local id, name, texture, count, debuffType, duration, timeLeft = unpack(auras[i])
				
				f["Buff"..i].id = id
				f["Buff"..i].Icon:SetTexture(texture)
				
				if count and (count > 0) then
					f["Buff"..i].Count:SetText(count)
				else
					f["Buff"..i].Count:SetText("")
				end
				
				f["Buff"..i].duration = duration

				if duration and duration > 0 then
					f["Buff"..i].startTime = math.floor(GetTime() + timeLeft - duration)
					f["Buff"..i].cooldown:SetCooldown(GetTime() + timeLeft - duration, duration)
					f["Buff"..i].cooldown:Show()
				else
					f["Buff"..i].startTime = nil
					f["Buff"..i].cooldown:Hide()
				end
				
				f["Buff"..i]:Show()
			else
				if DaHud:InConfigMode() then
					f["Buff"..i].id = 0
					f["Buff"..i].Icon:SetTexture("Interface\\Icons\\INV_Misc_Ear_Human_02")
					f["Buff"..i].Count:SetText(i)
					f["Buff"..i].duration = nil
					f["Buff"..i].startTime = nil
					f["Buff"..i].isLarge = nil
					f["Buff"..i].cooldown:Hide()
	
					f["Buff"..i]:Show()
				else
					f["Buff"..i].id = nil
					f["Buff"..i].Icon:SetTexture(nil)
					f["Buff"..i].Count:SetText("")
					f["Buff"..i].duration = nil
					f["Buff"..i].startTime = nil
					f["Buff"..i].isLarge = nil
					f["Buff"..i].cooldown:Hide()
	
					f["Buff"..i]:Hide()
				end
			end
		end
	end
	
	local anchor, left = nil, nil
	local rowSize = math.ceil(settings.maxaura / settings.columns)
	local point, relative, posx, posy = unpack(DaHud.Buffs.Elements.direction[settings.direction][1])
	local point2, relative2, posx2, posy2 = unpack(DaHud.Buffs.Elements.direction[settings.direction][2])
	
	for i=1, 40 do
		f["Buff"..i]:ClearAllPoints()
		f["Buff"..i]:SetWidth(settings.width)
		f["Buff"..i]:SetHeight(settings.height)
		
		if (i == 1) then
			f["Buff"..i]:SetPoint(point, f, relative, 0, 0)

			left = rowSize - 1
			anchor = f["Buff"..i]
		else
			if (left > 0) then
				f["Buff"..i]:SetPoint(point, f["Buff"..(i - 1)], relative, posx * settings.spacing, posy * settings.spacing)
				left = left - 1
			else
				anchor = f["Buff"..(i - rowSize)]
				
				f["Buff"..i]:SetPoint(point2, anchor, relative2, posx2 * settings.spacing, posy2 * settings.spacing)
					
				left = rowSize - 1
				anchor = f["Buff"..i]
			end
		end
	end
	
	for i, v in ipairs(auras) do
		auras[i] = delList(auras[i])
	end
	
	auras = delList(auras)
end