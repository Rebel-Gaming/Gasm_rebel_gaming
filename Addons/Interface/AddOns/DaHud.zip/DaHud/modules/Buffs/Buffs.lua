--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:NewModule("Buffs")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

DaHud.Frames.Buffs = {}

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Buffs = {}

DaHud.Buffs.Type = {
	player = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	pet = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	pettarget = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	target = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	targettarget = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	targettargettarget = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	focus = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	focustarget = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party1 = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party1pet = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party1target = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party2 = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party2pet = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party2target = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party3 = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party3pet = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party3target = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party4 = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party4pet = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
	party4target = {
		buffs = L["Buffs"],
		debuffs = L["Debuffs"],
	},
}

DaHud.Buffs.Plugins = {
}

DaHud.Buffs.Direction = {
	LTD = L["Left, then Down"],
	RTD = L["Right, then Down"],
	LTU = L["Left, then Up"],
	RTU = L["Right, then Up"],
	DTL = L["Down, then Left"],
	DTR = L["Down, then Right"],
	UTL = L["Up, then Left"],
	UTR = L["Up, then Right"],
}

DaHud.Buffs.Elements = {
	direction = {
		RTD = {{"TOPLEFT", "TOPRIGHT", 1, 0}, {"TOPLEFT", "BOTTOMLEFT", 0, -1 },},
		RTU = {{"TOPLEFT", "TOPRIGHT", 1, 0}, {"BOTTOMLEFT", "TOPLEFT", 0, 1 }, },
		LTD = {{"TOPRIGHT", "TOPLEFT", -1, 0}, {"TOPRIGHT", "BOTTOMRIGHT", 0, -1 },},
		LTU = {{"TOPRIGHT", "TOPLEFT", -1, 0}, {"BOTTOMRIGHT", "TOPRIGHT", 0, 1 },},
		DTL = {{"TOPRIGHT", "BOTTOMRIGHT", 0, -1}, {"TOPRIGHT", "TOPLEFT", -1, 0 },},
		DTR = {{"TOPLEFT", "BOTTOMLEFT", 0, -1}, {"TOPLEFT", "TOPRIGHT", 1, 0 },},
		UTL = {{"BOTTOMRIGHT", "TOPRIGHT", 0, 1}, {"BOTTOMRIGHT", "BOTTOMLEFT", -1, 0 },},
		UTR = {{"BOTTOMLEFT", "TOPLEFT", 0, 1}, {"BOTTOMLEFT", "BOTTOMRIGHT", 1, 0 },},
	},
}

--- ========================================================= ---
---  Setup Database
--- ========================================================= ---
function mod:OnRegister()
	self:RegisterDefaults({
		buffs = {
			["**"] = {
				name = "Default",
				active = false,
				framestrata = "LOW",
				framelevel = 1,
				point = "CENTER",
				anchor = "UIParent",
				relative = "CENTER",
				posx = 0,
				posy = 0,
				width = 20,
				height = 20,
				unit = "player",
				type = "buffs",
				direction = "LTD",
				maxaura = 20,
				columns = 2,
				spacing = 5,
				filter = false,
				hideinraid = false,
			},
			buff1 = {
				name = "TargetBuffs",
				active = true,
				posx = -115,
				posy = -190,
				unit = "target",
				type = "buffs",
				direction = "LTD",
			},
			buff2 = {
				name = "TargetDebuffs",
				active = true,
				posx = 115,
				posy = -190,
				unit = "target",
				type = "debuffs",
				direction = "RTD",
			},
			pluginsDisabled = {
			},
		},
	})
end

--- ========================================================= ---
---  System
--- ========================================================= ---
function mod:OnEnable()
	DaHud:EnableModule(mod)
end

function mod:OnDisable()
	DaHud:DisableModule(mod)
end