--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:NewModule("Icons")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

DaHud.Frames.Icons = {}

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Icons = {}

DaHud.Icons.Type = {
	player = {},
	pet = {},
	pettarget = {},
	target = {},
	targettarget = {},
	targettargettarget = {},
	focus = {},
	focustarget = {},
	party1 = {},
	party1pet = {},
	party1target = {},
	party2 = {},
	party2pet = {},
	party2target = {},
	party3 = {},
	party3pet = {},
	party3target = {},
	party4 = {},
	party4pet = {},
	party4target = {},
}

DaHud.Icons.Plugins = {
}

DaHud.Icons.Elements = {
	textures = {},
}

--- ========================================================= ---
---  Setup Database
--- ========================================================= ---
function mod:OnRegister()
	self:RegisterDefaults({
		icons = {
			["**"] = {
				name = "Default",
				active = false,
				framestrata = "MEDIUM",
				framelevel = 1,
				point = "CENTER",
				anchor = "UIParent",
				relative = "CENTER",
				posx = 0,
				posy = 0,
				width = 15,
				height = 15,
				unit = "player",
				type = "raidtarget",
				interactive = false,
				hideinraid = false,
			},
			icon1 = {
				name = "PlayerResting",
				active = true,
				posx = -107,
				posy = 105,
				unit = "player",
				type = "resting",
			},
			icon2 = {
				name = "PlayerCombat",
				active = true,
				posx = -107,
				posy = 105,
				unit = "player",
				type = "combat",
			},
			icon3 = {
				name = "PlayerPvPFlag",
				active = true,
				posx = -107,
				posy = 80,
				unit = "player",
				type = "pvpflag",
			},
			icon4 = {
				name = "PlayerLeader",
				active = true,
				posx = -107,
				posy = 60,
				unit = "player",
				type = "leader",
			},
			icon5 = {
				name = "PlayerMasterLooter",
				active = true,
				posx = -107,
				posy = 40,
				unit = "player",
				type = "masterlooter",
			},
			icon6 = {
				name = "PlayerRaidTarget",
				active = true,
				posx = -145,
				posy = 115,
				width = 20,
				height = 20,
				unit = "player",
				type = "raidtarget",
			},
			icon7 = {
				name = "TargetCombat",
				active = true,
				posx = 107,
				posy = 105,
				unit = "target",
				type = "combat",
			},
			icon8 = {
				name = "TargetPvP",
				active = true,
				posx = 107,
				posy = 80,
				unit = "target",
				type = "pvpflag",
			},
			icon9 = {
				name = "TargetRaidTarget",
				active = true,
				posx = 145,
				posy = 115,
				width = 20,
				height = 20,
				unit = "target",
				type = "raidtarget",
			},
			icon10 = {
				name = "TargetComboPoints",
				active = true,
				point = "TOP",
				posx = 180,
				posy = 110,
				width = 18,
				height = 15,
				unit = "target",
				type = "combopoints",
				style = "dahud_combopoints",
			},
			pluginsDisabled = {
			},
		}
	})
end

--- ========================================================= ---
---  System
--- ========================================================= ---
function mod:OnEnable()
	DaHud:EnableModule(mod)
end

function mod:OnDisable()
	DaHud:DisableModule(mod)
end