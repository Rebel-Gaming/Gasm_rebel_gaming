--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Icons")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions(id, name)
	if not(id) or not(name) then return end

	DaHud.options.args.Icons.args[id].args.Appearance.args.Group1 = {
		name = L["Misc"],
		type = "group",
		inline = true,
		order = -1,
		args = {
			interactive = {
				name = L["Interactive"],
				type = "toggle",
				order = 1,
				get = function(info) 
					return DaHud.db.profile.icons[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.icons[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
			hideinraid = {
				name = L["Hide In Raid"],
				type = "toggle",
				order = 2,
				get = function(info) 
					return DaHud.db.profile.icons[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.icons[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
		},
	}
end

--- ========================================================= ---
---  Frame Type
--- ========================================================= ---
function mod:FrameType()
	return "Button", "SecureUnitButtonTemplate"
end

--- ========================================================= ---
---  Set Attributes
--- ========================================================= ---
function mod:SetAttributes(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Icons[id]
	
	f.Icon = newFrame("Texture", nil, f, "ARTWORK")
end

--- ========================================================= ---
---  On Event
--- ========================================================= ---
function mod:OnEvent(f, event, unit)
	mod:UpdateFrame(f)
end

--- ========================================================= ---
---  Refresh Frame
--- ========================================================= ---
function mod:RefreshFrame(id, oldValue)
	if not(id) then return end

	local f = DaHud.Frames.Icons[id]
	local settings = DaHud.db.profile.icons[id]
		
	DaHud:SetFrameChild(f.Icon, f, settings)
	
	f.Icon:SetTexture(DaHud.Icons.Elements.textures[settings.type])
end

--- ========================================================= ---
---  Update Frame
--- ========================================================= ---
function mod:UpdateFrame(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.icons[id]

	if DaHud:InConfigMode() then
		if type(mod["SetConfigMode_"..settings.type]) == "function" then
			mod["SetConfigMode_"..settings.type](mod, f)
			f:SetAlpha(1)
		end
		return 
	end

	if type(mod["Update_"..settings.type]) == "function" then
		mod["Update_"..settings.type](mod, f)
	end
end