--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local _G = getfenv(0)

--- ========================================================= ---
---  Setup HideBlizzardFrames
--- ========================================================= ---
function DaHud:Setup_HideBlizzardFrames()
	DaHud:Add_HideBlizzardFrames_Settings()
	DaHud:Add_HideBlizzardFrames_Options()
	DaHud:RefreshAllBlizzardFrames()
end

--- ========================================================= ---
---  Add HideBlizzardFrames Settings
--- ========================================================= ---
function DaHud:Add_HideBlizzardFrames_Settings()
	if not(DaHud.db.profile.hideBlizzard) then
		DaHud.db.profile.hideBlizzard = {
		    player = true,
		    party = true,
		    target = true,
		    castbar = true,
		    aura = true,
		}
	end
end

--- ========================================================= ---
---  Add HideBlizzardFrames Options
--- ========================================================= ---
function DaHud:Add_HideBlizzardFrames_Options()
	DaHud.options.args.general.args.hideBlizzardFrames = {
		name = L["Hide Blizzard Frames"],
		type= "group",
		order = 1,
		args = {
			hideBlizzardFrames = {
				name = L["Hide Blizzard Frames"],
				type= "group",
				order = 1,
				inline = true,
				get = function(info) 
					return DaHud.db.profile.hideBlizzard[info[#info]] 
				end,
				set = function(info, value)
					DaHud.db.profile.hideBlizzard[info[#info]] = value
					DaHud:RefreshAllBlizzardFrames()
				end,
				args = {
					player = {
						name = L["Player"],
						type = "toggle",
						order = 1,
					},
					target = {
						name = L["Target"],
						type = "toggle",
						order = 2,
					},
					party = {
						name = L["Party"],
						type = "toggle",
						order = 3,
					},
					castbar = {
						name = L["Casting Bar"],
						type = "toggle",
						order = 4,
					},
					aura = {
						name = L["Buffs / Debuffs"],
						type = "toggle",
						order = 5,
					},
				},
			},
		},
	}
end

--- ========================================================= ---
---  Update Blizzard Frames
--- ========================================================= ---
function DaHud:RefreshAllBlizzardFrames()
	DaHud:ToggleBlizzardPlayerFrame()
	DaHud:ToggleBlizzardTargetFrame()
	DaHud:ToggleBlizzardPartyFrames()
	DaHud:ToggleBlizzardCastingBar()
	DaHud:ToggleBlizzardAuraFrame()
end

--- ========================================================= ---
---  Toggle Blizzard Player Frame
--- ========================================================= ---
function DaHud:ToggleBlizzardPlayerFrame()
	local settings = DaHud.db.profile.hideBlizzard

	if not(settings.player) then
		PlayerFrame:RegisterEvent("UNIT_LEVEL")
		PlayerFrame:RegisterEvent("UNIT_COMBAT")
		PlayerFrame:RegisterEvent("UNIT_SPELLMISS")
		PlayerFrame:RegisterEvent("UNIT_PVP_UPDATE")
		PlayerFrame:RegisterEvent("UNIT_MAXMANA")
		PlayerFrame:RegisterEvent("PLAYER_ENTER_COMBAT")
		PlayerFrame:RegisterEvent("PLAYER_LEAVE_COMBAT")
		PlayerFrame:RegisterEvent("PLAYER_UPDATE_RESTING")
		PlayerFrame:RegisterEvent("PARTY_MEMBERS_CHANGED")
		PlayerFrame:RegisterEvent("PARTY_LEADER_CHANGED")
		PlayerFrame:RegisterEvent("PARTY_LOOT_METHOD_CHANGED")
		PlayerFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
		PlayerFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
		PlayerFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
		PlayerFrameHealthBar:RegisterEvent("UNIT_HEALTH")
		PlayerFrameHealthBar:RegisterEvent("UNIT_MAXHEALTH")
		PlayerFrameManaBar:RegisterEvent("UNIT_MANA")
		PlayerFrameManaBar:RegisterEvent("UNIT_RAGE")
		PlayerFrameManaBar:RegisterEvent("UNIT_FOCUS")
		PlayerFrameManaBar:RegisterEvent("UNIT_ENERGY")
		PlayerFrameManaBar:RegisterEvent("UNIT_HAPPINESS")
		PlayerFrameManaBar:RegisterEvent("UNIT_MAXMANA")
		PlayerFrameManaBar:RegisterEvent("UNIT_MAXRAGE")
		PlayerFrameManaBar:RegisterEvent("UNIT_MAXFOCUS")
		PlayerFrameManaBar:RegisterEvent("UNIT_MAXENERGY")
		PlayerFrameManaBar:RegisterEvent("UNIT_MAXHAPPINESS")
		PlayerFrameManaBar:RegisterEvent("UNIT_DISPLAYPOWER")
		PlayerFrame:RegisterEvent("UNIT_NAME_UPDATE")
		PlayerFrame:RegisterEvent("UNIT_PORTRAIT_UPDATE")
		PlayerFrame:RegisterEvent("UNIT_DISPLAYPOWER")
		PlayerFrame:Show()
	else
		PlayerFrame:UnregisterAllEvents()
		PlayerFrameHealthBar:UnregisterAllEvents()
		PlayerFrameManaBar:UnregisterAllEvents()
		PlayerFrame:Hide()
	end
end

--- ========================================================= ---
---  Toggle Blizzard Target Frame
--- ========================================================= ---
function DaHud:ToggleBlizzardTargetFrame()
	local settings = DaHud.db.profile.hideBlizzard

	if not(settings.target) then
		TargetFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
		TargetFrame:RegisterEvent("PLAYER_FOCUS_CHANGED")
		TargetFrame:RegisterEvent("UNIT_HEALTH")
		TargetFrame:RegisterEvent("UNIT_LEVEL")
		TargetFrame:RegisterEvent("UNIT_FACTION")
		TargetFrame:RegisterEvent("UNIT_CLASSIFICATION_CHANGED")
		TargetFrame:RegisterEvent("UNIT_AURA")
		TargetFrame:RegisterEvent("PLAYER_FLAGS_CHANGED")
		TargetFrame:RegisterEvent("PARTY_MEMBERS_CHANGED")
		
		local oldThis = _G.this
		_G.this = TargetFrame
		TargetFrame_Update()
		_G.this = oldThis
	
		ComboFrame:RegisterEvent("PLAYER_FOCUS_CHANGED")
		ComboFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
		ComboFrame:RegisterEvent("PLAYER_COMBO_POINTS")
	else
		TargetFrame:UnregisterAllEvents()
		TargetFrame:Hide()
	
		ComboFrame:UnregisterAllEvents()
	end
end

--- ========================================================= ---
---  Toggle Blizzard Party Frames
--- ========================================================= ---
function DaHud:ToggleBlizzardPartyFrames()
	local settings = DaHud.db.profile.hideBlizzard

	if not(settings.party) then
		for i = 1, 4 do
			local frame = _G["PartyMemberFrame"..i]
			frame.Show = nil
			frame:RegisterEvent("PARTY_MEMBERS_CHANGED")
			frame:RegisterEvent("PARTY_LEADER_CHANGED")
			frame:RegisterEvent("PARTY_MEMBER_ENABLE")
			frame:RegisterEvent("PARTY_MEMBER_DISABLE")
			frame:RegisterEvent("PARTY_LOOT_METHOD_CHANGED")
			frame:RegisterEvent("UNIT_PVP_UPDATE")
			frame:RegisterEvent("UNIT_AURA")
			frame:RegisterEvent("UNIT_PET")
			frame:RegisterEvent("VARIABLES_LOADED")
			frame:RegisterEvent("UNIT_NAME_UPDATE")
			frame:RegisterEvent("UNIT_PORTRAIT_UPDATE")
			frame:RegisterEvent("UNIT_DISPLAYPOWER")
	
			UnitFrame_OnEvent("PARTY_MEMBERS_CHANGED")
	
			local oldThis = _G.this
			_G.this = frame
			PartyMemberFrame_UpdateMember()
			_G.this = oldThis
		end
	
		UIParent:RegisterEvent("RAID_ROSTER_UPDATE")
	else
		for i = 1, 4 do
			local frame = _G["PartyMemberFrame"..i]
			frame:UnregisterAllEvents()
			frame:Hide()
			frame.Show = function() end
		end
	
		UIParent:UnregisterEvent("RAID_ROSTER_UPDATE")
	end
end

--- ========================================================= ---
---  Toggle Blizzard Casting Bar
--- ========================================================= ---
function DaHud:ToggleBlizzardCastingBar()
	local settings = DaHud.db.profile.hideBlizzard

	if not(settings.castbar) then
		local t = { CastingBarFrame, PetCastingBarFrame }
		
		for i,v in ipairs(t) do
			v:RegisterEvent("UNIT_SPELLCAST_START")
			v:RegisterEvent("UNIT_SPELLCAST_STOP")
			v:RegisterEvent("UNIT_SPELLCAST_FAILED")
			v:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
			v:RegisterEvent("UNIT_SPELLCAST_DELAYED")
			v:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
			v:RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE")
			v:RegisterEvent("PLAYER_ENTERING_WORLD")
		end
	
		PetCastingBarFrame:RegisterEvent("UNIT_PET")
	else
		CastingBarFrame:UnregisterAllEvents()
		PetCastingBarFrame:UnregisterAllEvents()	
	end
end

--- ========================================================= ---
---  Toggle Blizzard Aura Frame
--- ========================================================= ---
function DaHud:ToggleBlizzardAuraFrame()
	local settings = DaHud.db.profile.hideBlizzard

	if not(settings.aura) then
		BuffFrame:Show()
		TemporaryEnchantFrame:Show()
		BuffFrame:RegisterEvent("PLAYER_AURAS_CHANGED")
	
		BuffFrame_Update()
	else
		BuffFrame:Hide()
		TemporaryEnchantFrame:Hide()
		BuffFrame:UnregisterAllEvents()
	end
end