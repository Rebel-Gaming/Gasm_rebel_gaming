--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Styles = {}
DaHud.Styles.Bars = {}
DaHud.Styles.Text = {}
DaHud.Styles.Icons = {}
DaHud.Styles.Buffs = {}
DaHud.Styles.Portraits = {}

--- ========================================================= ---
---  Set Style
--- ========================================================= ---
function DaHud:SetStyle(styleAPI)
	for k, v in self:IterateModules() do
		local moduleName = string.gsub(v.name, "DaHud_", "")
		
		for k2, v2 in pairs(DaHud.db.profile[string.lower(moduleName)]) do
			DaHud.db.profile[string.lower(moduleName)][k2] = nil
		end
		
		if DaHud.Styles[moduleName][styleAPI] then
			for k2, v2 in pairs(DaHud.Styles[moduleName][styleAPI]) do
				DaHud:CreateFrameSettings(v, k2, "Default")
			
				for k3, v3 in pairs(DaHud.Styles[moduleName][styleAPI][k2]) do
					DaHud.db.profile[string.lower(moduleName)][k2][k3] = v3
				end
			end
		end
		
		DaHud:DisableModule(v)
		DaHud:EnableModule(v)
	end
	
	DaHud:SetConfigMode()
end