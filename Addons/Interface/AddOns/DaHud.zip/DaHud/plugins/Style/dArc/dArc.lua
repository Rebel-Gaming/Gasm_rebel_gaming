--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Style.dArcDefault = L["dArc Default"]

DaHud.Bars.Textures.darcleft = L["(Bar) dArc Left"]
DaHud.Bars.Textures.darcright = L["(Bar) dArc Right"]

DaHud.Bars.Elements.textures.darcleft = "Interface\\Addons\\DaHud\\plugins\\Style\\dArc\\media\\dArcLeft"
DaHud.Bars.Elements.textures.darcright = "Interface\\Addons\\DaHud\\plugins\\Style\\dArc\\media\\dArcRight"

--- ========================================================= ---
---  Styles
--- ========================================================= ---
DaHud.Styles.Bars.dArcDefault = {
	bar1 = {
		name = "PlayerHealth",
		active = true,
		posx = -155,
		posy = 0,
		width = 75,
		unit = "player",
		type = "health",
		background = "darcleft",
		border = "custom",
		bar = "darcleft",
		casting = "darcleft",
		castingbar = true
	},
	bar2 = {
		name = "PlayerMana",
		active = true,
		posx = -135,
		posy = 0,
		width = 75,
		unit = "player",
		type = "power",
		background = "darcleft",
		border = "custom",
		bar = "darcleft",
		casting = "darcleft",
		castingbar = true
	},
	bar3 = {
		name = "TargetHealth",
		active = true,
		posx = 155,
		posy = 0,
		width = 75,
		unit = "target",
		type = "health",
		background = "darcright",
		border = "custom",
		bar = "darcright",
		casting = "darcright",
		castingbar = true
	},
	bar4 = {
		name = "TargetMana",
		active = true,
		posx = 135,
		posy = 0,
		width = 75,
		unit = "target",
		type = "power",
		background = "darcright",
		border = "custom",
		bar = "darcright",
		casting = "darcright",
		castingbar = true
	},
}

DaHud.Styles.Text.dArcDefault = {
	text1 = {
		name = "PlayerHealth",
		active = true,
		posx = -210,
		posy = -135,
		unit = "player",
		fontalign = "RIGHT",
		fonttype = "Health",
		fontstyle = "Absolute and Percent",
	},
	text2 = {
		name = "PlayerMana",
		active = true,
		posx = -210,
		posy = -155,
		unit = "player",
		fontalign = "RIGHT",
		fonttype = "Power",
		fontstyle = "Absolute and Percent",
	},
	text3 = {
		name = "TargetHealth",
		active = true,
		posx = 210,
		posy = -135,
		unit = "target",
		fontalign = "LEFT",
		fonttype = "Health",
		fontstyle = "Absolute and Percent",
	},
	text4 = {
		name = "TargetMana",
		active = true,
		posx = 210,
		posy = -155,
		unit = "target",
		fontalign = "LEFT",
		fonttype = "Power",
		fontstyle = "Absolute and Percent",
	},
	text5 = {
		name = "PlayerCastingName",
		active = true,
		posx = -235,
		posy = 135,
		unit = "player",
		fontalign = "RIGHT",
		fonttype = "Cast",
		fontstyle = "Standard Name",
	},
	text6 = {
		name = "PlayerCastingTime",
		active = true,
		posx = -55,
		posy = 135,
		unit = "player",
		fontalign = "LEFT",
		fonttype = "Cast",
		fontstyle = "Standard Time",
	},
	text7 = {
		name = "TargetCastingName",
		active = true,
		posx = 235,
		posy = 135,
		unit = "target",
		fontalign = "LEFT",
		fonttype = "Cast",
		fontstyle = "Standard Name",
	},
	text8 = {
		name = "TargetCastingTime",
		active = true,
		posx = 55,
		posy = 135,
		unit = "target",
		fontalign = "RIGHT",
		fonttype = "Cast",
		fontstyle = "Standard Time",
	},
}

DaHud.Styles.Icons.dArcDefault = {
}

DaHud.Styles.Buffs.dArcDefault = {
	buff1 = {
		name = "TargetBuffs",
		active = true,
		posx = -115,
		posy = -190,
		width = 20,
		height = 20,
		unit = "target",
		type = "buffs",
		direction = "LTD",
		colorDebuff = true,
		large = true,
		tooltip = "always",
	},
	buff2 = {
		name = "TargetDebuffs",
		active = true,
		posx = 115,
		posy = -190,
		width = 20,
		height = 20,
		unit = "target",
		type = "debuffs",
		direction = "RTD",
		colorDebuff = true,
		large = true,
		tooltip = "always",
	},
}