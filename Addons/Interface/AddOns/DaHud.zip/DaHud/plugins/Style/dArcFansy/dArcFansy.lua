--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Style.dArcFansyDefault = L["dArcFansy Default"]

DaHud.Bars.Textures.darcfansyleft = L["(Bar) dArcFansy Left"]
DaHud.Bars.Textures.darcfansyright = L["(Bar) dArcFansy Right"]

DaHud.Bars.Elements.textures.darcfansyleft = "Interface\\Addons\\DaHud\\plugins\\Style\\dArcFansy\\media\\dArcFansyLeft"
DaHud.Bars.Elements.textures.darcfansyright = "Interface\\Addons\\DaHud\\plugins\\Style\\dArcFansy\\media\\dArcFansyRight"

--- ========================================================= ---
---  Styles
--- ========================================================= ---
DaHud.Styles.Bars.dArcFansyDefault = {
	bar1 = {
		name = "PlayerHealth",
		active = true,
		posx = -175,
		posy = 0,
		width = 75,
		unit = "player",
		type = "health",
		background = "darcfansyleft",
		border = "custom",
		bar = "darcfansyleft",
		casting = "darcfansyleft",
		castingbar = true
	},
	bar2 = {
		name = "PlayerMana",
		active = true,
		posx = -135,
		posy = 0,
		width = 75,
		unit = "player",
		type = "power",
		background = "darcfansyleft",
		border = "custom",
		bar = "darcfansyleft",
		casting = "darcfansyleft",
		castingbar = true
	},
	bar3 = {
		name = "TargetHealth",
		active = true,
		posx = 175,
		posy = 0,
		width = 75,
		unit = "target",
		type = "health",
		background = "darcfansyright",
		border = "custom",
		bar = "darcfansyright",
		casting = "darcfansyright",
		castingbar = true
	},
	bar4 = {
		name = "TargetMana",
		active = true,
		posx = 135,
		posy = 0,
		width = 75,
		unit = "target",
		type = "power",
		background = "darcfansyright",
		border = "custom",
		bar = "darcfansyright",
		casting = "darcfansyright",
		castingbar = true
	},
}

DaHud.Styles.Text.dArcFansyDefault = {
	text1 = {
		name = "PlayerHealth",
		active = true,
		posx = -210,
		posy = -135,
		unit = "player",
		fontalign = "RIGHT",
		fonttype = "Health",
		fontstyle = "Absolute and Percent",
	},
	text2 = {
		name = "PlayerMana",
		active = true,
		posx = -210,
		posy = -155,
		unit = "player",
		fontalign = "RIGHT",
		fonttype = "Power",
		fontstyle = "Absolute and Percent",
	},
	text3 = {
		name = "TargetHealth",
		active = true,
		posx = 210,
		posy = -135,
		unit = "target",
		fontalign = "LEFT",
		fonttype = "Health",
		fontstyle = "Absolute and Percent",
	},
	text4 = {
		name = "TargetMana",
		active = true,
		posx = 210,
		posy = -155,
		unit = "target",
		fontalign = "LEFT",
		fonttype = "Power",
		fontstyle = "Absolute and Percent",
	},
	text5 = {
		name = "PlayerCastingName",
		active = true,
		posx = -235,
		posy = 135,
		unit = "player",
		fontalign = "RIGHT",
		fonttype = "Cast",
		fontstyle = "Standard Name",
	},
	text6 = {
		name = "PlayerCastingTime",
		active = true,
		posx = -55,
		posy = 135,
		unit = "player",
		fontalign = "LEFT",
		fonttype = "Cast",
		fontstyle = "Standard Time",
	},
	text7 = {
		name = "TargetCastingName",
		active = true,
		posx = 235,
		posy = 135,
		unit = "target",
		fontalign = "LEFT",
		fonttype = "Cast",
		fontstyle = "Standard Name",
	},
	text8 = {
		name = "TargetCastingTime",
		active = true,
		posx = 55,
		posy = 135,
		unit = "target",
		fontalign = "RIGHT",
		fonttype = "Cast",
		fontstyle = "Standard Time",
	},
}

DaHud.Styles.Icons.dArcFansyDefault = {
}

DaHud.Styles.Buffs.dArcFansyDefault = {
	buff1 = {
		name = "TargetBuffs",
		active = true,
		posx = -115,
		posy = -190,
		width = 20,
		height = 20,
		unit = "target",
		type = "buffs",
		direction = "LTD",
		colorDebuff = true,
		large = true,
		tooltip = "always",
	},
	buff2 = {
		name = "TargetDebuffs",
		active = true,
		posx = 115,
		posy = -190,
		width = 20,
		height = 20,
		unit = "target",
		type = "debuffs",
		direction = "RTD",
		colorDebuff = true,
		large = true,
		tooltip = "always",
	},
}