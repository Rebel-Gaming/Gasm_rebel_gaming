--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Buffs", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Buffs.Plugins.large = L["Large Self Buffs"]

--- ========================================================= ---
---  Create Frame Settings
--- ========================================================= ---
function mod:CreateFrameSettings_large(id)
	if not(DaHud.db.profile.buffs[id].large) and (DaHud.db.profile.buffs[id].large ~= false) then
		DaHud.db.profile.buffs[id].large = true
	end
end

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions_large(name)
	DaHud.options.args.Buffs.args[name].args.Appearance.args.Group2.args.large = {
		name = L["Large Self Buffs"],
		type = "toggle",
		order = 1,
		hidden = function(info) 
			return DaHud.db.profile.buffs.pluginsDisabled.large
		end,
		get = function(info) 
			return DaHud.db.profile.buffs[info[#info-3]][info[#info]]
		end,
		set = function(info, value) 
			DaHud.db.profile.buffs[info[#info-3]][info[#info]] = value
			DaHud:RefreshFrame(mod, info[#info-3])
		end,
	}
end

--- ========================================================= ---
---  Update Frame
--- ========================================================= ---
function mod:UpdateFrame_large(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.buffs[id]
	
	for i=1, 40 do
		if settings.large and f["Buff"..i].duration then
			f["Buff"..i].isLarge = true
		else
			f["Buff"..i].isLarge = nil
		end
	end
	
	local anchor, left, large, firstLarge = nil, nil, nil, nil
	local rowSize = math.ceil(settings.maxaura / settings.columns)
	local point, relative, posx, posy = unpack(DaHud.Buffs.Elements.direction[settings.direction][1])
	local point2, relative2, posx2, posy2 = unpack(DaHud.Buffs.Elements.direction[settings.direction][2])

	for i=1, 40 do
		f["Buff"..i]:ClearAllPoints()
		
		if (i > settings.maxaura) then return end
		
		if (i == 1) then
			f["Buff"..i]:SetPoint(point, f, relative, 0, 0)
			
			if f["Buff"..i].isLarge then
				f["Buff"..i]:SetWidth((settings.width * 2) + settings.spacing)
				f["Buff"..i]:SetHeight((settings.height * 2) + settings.spacing)
				
				left = rowSize - 2
				anchor = f["Buff"..i]
				large = 1
				firstLarge = i
			else
				f["Buff"..i]:SetWidth(settings.width)
				f["Buff"..i]:SetHeight(settings.height)
				
				left = rowSize - 1
				anchor = f["Buff"..i]
			end
		else
			if (left > 0) then
				f["Buff"..i]:SetPoint(point, f["Buff"..(i - 1)], relative, posx * settings.spacing, posy * settings.spacing)
					
				if f["Buff"..i].isLarge then
					f["Buff"..i]:SetWidth((settings.width * 2) + settings.spacing)
					f["Buff"..i]:SetHeight((settings.height * 2) + settings.spacing)
						
					left = left - 2
					large = large + 1 or 1
				else
					f["Buff"..i]:SetWidth(settings.width)
					f["Buff"..i]:SetHeight(settings.height)
					
					left = left - 1
				end
			else
				if f["Buff"..i].isLarge then
					f["Buff"..i]:SetPoint(point2, f["Buff"..firstLarge], relative2, posx2 * settings.spacing, posy2 * settings.spacing)
					
					f["Buff"..i]:SetWidth((settings.width * 2) + settings.spacing)
					f["Buff"..i]:SetHeight((settings.height * 2) + settings.spacing)
					
					left = rowSize - 2
					anchor = f["Buff"..i]
					large = 1
					firstLarge = i
				else
					if large and ((rowSize - (large * 2)) ~= 0) then
						anchor = f["Buff"..(i - (rowSize - (large * 2)))]
					elseif firstLarge then
						anchor = f["Buff"..firstLarge]
						firstLarge = nil
					end
				
					f["Buff"..i]:SetPoint(point2, anchor, relative2, posx2 * settings.spacing, posy2 * settings.spacing)
					
					f["Buff"..i]:SetWidth(settings.width)
					f["Buff"..i]:SetHeight(settings.height)
					
					if large and ((rowSize - (large * 2)) ~= 0) then
						left = rowSize - (large * 2) - 1
						large = nil
					else
						left = rowSize - 1
					end
					
					anchor = f["Buff"..i]
				end
			end
		end
	end
end