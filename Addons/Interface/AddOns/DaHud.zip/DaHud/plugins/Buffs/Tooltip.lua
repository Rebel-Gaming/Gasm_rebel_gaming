--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Buffs", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Buffs.Plugins.tooltip = L["Tooltip"]

--- ========================================================= ---
---  Create Frame Settings
--- ========================================================= ---
function mod:CreateFrameSettings_tooltip(id)
	if not(DaHud.db.profile.buffs[id].tooltip) then
		DaHud.db.profile.buffs[id].tooltip = "always"
	end
end

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions_tooltip(name)
	DaHud.options.args.Buffs.args[name].args.Appearance.args.Tooltip = {
		name = L["Tooltip"],
		type = "group",
		inline = true,
		order = 5,
		args = {
			Group1 = {
				name = "",
				type = "group",
				order = 1,
				args = {
					tooltip = {
						name = L["Tooltip"],
						type = "select",
						order = 1,
						hidden = function(info) 
							return DaHud.db.profile.buffs.pluginsDisabled.tooltip
						end,
						values = {never = L["Never"], always = L["Always"], ooc = L["Out Of Combat"],},
						get = function(info) 
							return DaHud.db.profile.buffs[info[#info-4]][info[#info]]
						end,
						set = function(info, value)
							DaHud.db.profile.buffs[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
				},
			},
		},
	}
end

--- ========================================================= ---
---  Set Scripts
--- ========================================================= ---
function mod:SetScripts_tooltip(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Buffs[id]

	for i = 1, 40 do
		f["Buff"..i]:SetScript("OnEnter", function()
			local id = string.gsub(this:GetName(), "DaHud_", "")
			id = string.gsub(id, "_Buff"..i, "")
			
			local settings = DaHud.db.profile.buffs[id]

			if (settings.tooltip == "always") or (settings.tooltip == "ooc" and not(InCombatLockdown())) then
				if not(this:IsVisible() and this.id) or (DaHud:GetAlpha() == 0) then return end

				GameTooltip:SetOwner(this, "ANCHOR_BOTTOMRIGHT")

				if (this.id == 0) then
					if (settings.type == "buffs") then
						GameTooltip:SetText("Test Buff")
					else
						GameTooltip:SetText("Test Debuff")
					end
				elseif (settings.unit == "player") then
					if (settings.type == "buffs") then
					    local id = GetPlayerBuff(this.id, "HELPFUL")
						GameTooltip:SetPlayerBuff(id, "HELPFUL")
					else
					    local id = GetPlayerBuff(this.id, "HARMFUL")
						GameTooltip:SetPlayerBuff(id, "HARMFUL")
					end
				else
					if (settings.type == "buffs") then
						GameTooltip:SetUnitBuff(settings.unit, this.id)
					else
						GameTooltip:SetUnitDebuff(settings.unit, this.id)
					end
				end
				GameTooltip:Show()
			end
		end)

		f["Buff"..i]:SetScript("OnLeave", function()
			if GameTooltip:IsOwned(this) then
				GameTooltip:Hide()
			end
		end)

		f["Buff"..i]:SetScript("OnClick", function()
			local id = string.gsub(this:GetName(), "DaHud_", "")
			id = string.gsub(id, "_Buff"..i, "")
			
			local settings = DaHud.db.profile.buffs[id]
			
			if (settings.unit ~= "player") then return end

			CancelPlayerBuff(this.id)
		end)
	end
end