--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Buffs", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Buffs.Plugins.colorDebuff = L["Color Debuff Border"]

--- ========================================================= ---
---  Create Frame Settings
--- ========================================================= ---
function mod:CreateFrameSettings_colorDebuff(id)
	if not(DaHud.db.profile.buffs[id].colorDebuff) and (DaHud.db.profile.buffs[id].colorDebuff ~= false) then
		DaHud.db.profile.buffs[id].colorDebuff = true
	end
end

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions_colorDebuff(name)
	DaHud.options.args.Buffs.args[name].args.Appearance.args.Group2.args.colorDebuff = {
		name = L["Color Debuff Border"],
		type = "toggle",
		order = 2,
		disabled = function(info) 
			return DaHud.db.profile.buffs[info[#info-3]].type ~= "debuffs" 
		end,
		hidden = function(info) 
			return DaHud.db.profile.buffs.pluginsDisabled.colorDebuff
		end,
		get = function(info) 
			return DaHud.db.profile.buffs[info[#info-3]][info[#info]]
		end,
		set = function(info, value) 
			DaHud.db.profile.buffs[info[#info-3]][info[#info]] = value
			DaHud:RefreshFrame(mod, info[#info-3])
		end,
	}
end

--- ========================================================= ---
---  Update Frame
--- ========================================================= ---
function mod:UpdateFrame_colorDebuff(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.buffs[id]
	
	for i=1, 40 do
		if (settings.type == "debuffs") and settings.colorDebuff then
			local color = DebuffTypeColor[debuffType or "none"]

			f["Buff"..i]:SetBackdropBorderColor(color.r, color.g, color.b, 1)
		else
			f["Buff"..i]:SetBackdropBorderColor(0, 0, 0, 1)
		end
	end
end