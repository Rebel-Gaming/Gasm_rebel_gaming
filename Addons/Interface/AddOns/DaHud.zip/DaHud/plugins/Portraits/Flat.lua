--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Portraits", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Portraits.Plugins.flat = L["Flat"]

DaHud.Portraits.Type.player.flat = L["Flat"]
DaHud.Portraits.Type.pet.flat = L["Flat"]
DaHud.Portraits.Type.pettarget.flat = L["Flat"]
DaHud.Portraits.Type.target.flat = L["Flat"]
DaHud.Portraits.Type.targettarget.flat = L["Flat"]
DaHud.Portraits.Type.targettargettarget.flat = L["Flat"]
DaHud.Portraits.Type.focus.flat = L["Flat"]
DaHud.Portraits.Type.focustarget.flat = L["Flat"]
DaHud.Portraits.Type.party1.flat = L["Flat"]
DaHud.Portraits.Type.party1pet.flat = L["Flat"]
DaHud.Portraits.Type.party1target.flat = L["Flat"]
DaHud.Portraits.Type.party2.flat = L["Flat"]
DaHud.Portraits.Type.party2pet.flat = L["Flat"]
DaHud.Portraits.Type.party2target.flat = L["Flat"]
DaHud.Portraits.Type.party3.flat = L["Flat"]
DaHud.Portraits.Type.party3pet.flat = L["Flat"]
DaHud.Portraits.Type.party3target.flat = L["Flat"]
DaHud.Portraits.Type.party4.flat = L["Flat"]
DaHud.Portraits.Type.party4pet.flat = L["Flat"]
DaHud.Portraits.Type.party4target.flat = L["Flat"]

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_flat(id)
	if not(id) then return end

	local f = DaHud.Frames.Portraits[id]
	
	local settings = DaHud.db.profile.portraits[id]
	
	if (settings.type ~= "flat") then return end

	if settings.unit == "player" then
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "pet" or settings.unit == "party1pet" or settings.unit == "party2pet" or settings.unit == "party3pet" or settings.unit == "party4pet" then
	    f:RegisterEvent("UNIT_PET")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "target" then
		f:RegisterEvent("PLAYER_TARGET_CHANGED")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "focus" then
		f:RegisterEvent("PLAYER_FOCUS_CHANGED")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "party1" or settings.unit == "party2" or settings.unit == "party3" or settings.unit == "party4" then
		f:RegisterEvent("PARTY_MEMBERS_CHANGED")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	else
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
		DaHud:RegisterUpdate(self, "UpdateUneventedUnit_flat", id, id)
	end
end

--- ========================================================= ---
---  Update Unevented Unit
--- ========================================================= ---
function mod:UpdateUneventedUnit_flat(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Portraits[id]

	local settings = DaHud.db.profile.portraits[id]

	local guid = UnitGUID(settings.unit) or 0
	local guid = tonumber(guid, 16)
	
	if not(f.GUID) then
		f.GUID = guid
		DaHud:UpdateFrame(mod, f)
	else
		if (f.GUID ~= guid) then
			f.GUID = guid
			DaHud:UpdateFrame(mod, f)
		end		
	end
end

--- ========================================================= ---
---  Update Flat
--- ========================================================= ---
function mod:Update_flat(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.portraits[id]
	
	SetPortraitTexture(f.Portrait, settings.unit)
	f.Portrait:SetTexCoord(0, 1, 0, 1)
end