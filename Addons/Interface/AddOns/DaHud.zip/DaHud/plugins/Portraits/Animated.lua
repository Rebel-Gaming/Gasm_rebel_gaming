--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Portraits", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Portraits.Plugins.ani = L["Animated"]

DaHud.Portraits.Type.player.ani = L["Animated"]
DaHud.Portraits.Type.pet.ani = L["Animated"]
DaHud.Portraits.Type.pettarget.ani = L["Animated"]
DaHud.Portraits.Type.target.ani = L["Animated"]
DaHud.Portraits.Type.targettarget.ani = L["Animated"]
DaHud.Portraits.Type.targettargettarget.ani = L["Animated"]
DaHud.Portraits.Type.focus.ani = L["Animated"]
DaHud.Portraits.Type.focustarget.ani = L["Animated"]
DaHud.Portraits.Type.party1.ani = L["Animated"]
DaHud.Portraits.Type.party1pet.ani = L["Animated"]
DaHud.Portraits.Type.party1target.ani = L["Animated"]
DaHud.Portraits.Type.party2.ani = L["Animated"]
DaHud.Portraits.Type.party2pet.ani = L["Animated"]
DaHud.Portraits.Type.party2target.ani = L["Animated"]
DaHud.Portraits.Type.party3.ani = L["Animated"]
DaHud.Portraits.Type.party3pet.ani = L["Animated"]
DaHud.Portraits.Type.party3target.ani = L["Animated"]
DaHud.Portraits.Type.party4.ani = L["Animated"]
DaHud.Portraits.Type.party4pet.ani = L["Animated"]
DaHud.Portraits.Type.party4target.ani = L["Animated"]

--- ========================================================= ---
---  Refresh Frame
--- ========================================================= ---
function mod:RefreshFrame_ani(id, oldValue)
	if not(id) then return end
	
	local f = DaHud.Frames.Portraits[id]

	local settings = DaHud.db.profile.portraits[id]
	
	if (settings.type == "ani") then
		f.Portrait:SetTexture(nil)
		
		if DaHud.Frames.Portraits[id].Ani then
			delFrame(DaHud.Frames.Portraits[id].Ani)
		end
	
		f.Ani = newFrame("PlayerModel", nil, f)
		
		f.Ani:ClearAllPoints()
		f.Ani:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
		f.Ani:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
	elseif (oldValue == "ani") then
		if DaHud.Frames.Portraits[id].Ani then
			delFrame(DaHud.Frames.Portraits[id].Ani)
		end
	end
end

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_ani(id)
	if not(id) then return end

	local f = DaHud.Frames.Portraits[id]
	
	local settings = DaHud.db.profile.portraits[id]
	
	if (settings.type ~= "ani") then return end

	if settings.unit == "player" then
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "pet" or settings.unit == "party1pet" or settings.unit == "party2pet" or settings.unit == "party3pet" or settings.unit == "party4pet" then
	    f:RegisterEvent("UNIT_PET")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "target" then
		f:RegisterEvent("PLAYER_TARGET_CHANGED")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "focus" then
		f:RegisterEvent("PLAYER_FOCUS_CHANGED")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "party1" or settings.unit == "party2" or settings.unit == "party3" or settings.unit == "party4" then
		f:RegisterEvent("PARTY_MEMBERS_CHANGED")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	else
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
		DaHud:RegisterUpdate(self, "UpdateUneventedUnit_ani", id, id)
	end
end

--- ========================================================= ---
---  Update Unevented Unit
--- ========================================================= ---
function mod:UpdateUneventedUnit_ani(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Portraits[id]

	local settings = DaHud.db.profile.portraits[id]

	local guid = UnitGUID(settings.unit) or 0
	local guid = tonumber(guid, 16)
	
	if not(f.GUID) then
		f.GUID = guid
		DaHud:UpdateFrame(mod, f)
	else
		if (f.GUID ~= guid) then
			f.GUID = guid
			DaHud:UpdateFrame(mod, f)
		end		
	end
end

--- ========================================================= ---
---  Update Animated
--- ========================================================= ---
function mod:Update_ani(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.portraits[id]
	
	if not(DaHud.Frames.Portraits[id].Ani) then
		mod:RefreshFrame_ani(id)
	end
	
	if not(UnitExists(settings.unit)) or not(UnitIsConnected(settings.unit)) or not(UnitIsVisible(settings.unit)) then
		f.Ani:SetModelScale(4.25)
		f.Ani:SetPosition(0,0,-1.5)
		f.Ani:SetModel("Interface\\Buttons\\talktomequestionmark.mdx")
	else
		f.Ani:SetUnit(settings.unit)
		f.Ani:SetModelScale(1)
		f.Ani:SetCamera(1)
		self:ScheduleTimer("SetCamera", .1, f)
	end
end

--- ========================================================= ---
---  Set Camera
--- ========================================================= ---
function mod:SetCamera(f)
	f.Ani:SetCamera(0)
end