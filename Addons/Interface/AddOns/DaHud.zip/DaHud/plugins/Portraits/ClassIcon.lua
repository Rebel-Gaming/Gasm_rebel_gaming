--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Portraits", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Portraits.Plugins.class = L["Class Icon"]

DaHud.Portraits.Type.player.class = L["Class Icon"]
DaHud.Portraits.Type.pet.class = L["Class Icon"]
DaHud.Portraits.Type.pettarget.class = L["Class Icon"]
DaHud.Portraits.Type.target.class = L["Class Icon"]
DaHud.Portraits.Type.targettarget.class = L["Class Icon"]
DaHud.Portraits.Type.targettargettarget.class = L["Class Icon"]
DaHud.Portraits.Type.focus.class = L["Class Icon"]
DaHud.Portraits.Type.focustarget.class = L["Class Icon"]
DaHud.Portraits.Type.party1.class = L["Class Icon"]
DaHud.Portraits.Type.party1pet.class = L["Class Icon"]
DaHud.Portraits.Type.party1target.class = L["Class Icon"]
DaHud.Portraits.Type.party2.class = L["Class Icon"]
DaHud.Portraits.Type.party2pet.class = L["Class Icon"]
DaHud.Portraits.Type.party2target.class = L["Class Icon"]
DaHud.Portraits.Type.party3.class = L["Class Icon"]
DaHud.Portraits.Type.party3pet.class = L["Class Icon"]
DaHud.Portraits.Type.party3target.class = L["Class Icon"]
DaHud.Portraits.Type.party4.class = L["Class Icon"]
DaHud.Portraits.Type.party4pet.class = L["Class Icon"]
DaHud.Portraits.Type.party4target.class = L["Class Icon"]

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_class(id)
	if not(id) then return end

	local f = DaHud.Frames.Portraits[id]
	
	local settings = DaHud.db.profile.portraits[id]
	
	if (settings.type ~= "class") then return end

	if settings.unit == "player" then
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "pet" or settings.unit == "party1pet" or settings.unit == "party2pet" or settings.unit == "party3pet" or settings.unit == "party4pet" then
	    f:RegisterEvent("UNIT_PET")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "target" then
		f:RegisterEvent("PLAYER_TARGET_CHANGED")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "focus" then
		f:RegisterEvent("PLAYER_FOCUS_CHANGED")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	elseif settings.unit == "party1" or settings.unit == "party2" or settings.unit == "party3" or settings.unit == "party4" then
		f:RegisterEvent("PARTY_MEMBERS_CHANGED")
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
	else
		f:RegisterEvent("UNIT_PORTRAIT_UPDATE")
		DaHud:RegisterUpdate(self, "UpdateUneventedUnit_class", id, id)
	end
end

--- ========================================================= ---
---  Update Unevented Unit
--- ========================================================= ---
function mod:UpdateUneventedUnit_class(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Portraits[id]

	local settings = DaHud.db.profile.portraits[id]

	local guid = UnitGUID(settings.unit) or 0
	local guid = tonumber(guid, 16)
	
	if not(f.GUID) then
		f.GUID = guid
		DaHud:UpdateFrame(mod, f)
	else
		if (f.GUID ~= guid) then
			f.GUID = guid
			DaHud:UpdateFrame(mod, f)
		end		
	end
end

--- ========================================================= ---
---  Update Class Icon
--- ========================================================= ---
function mod:Update_class(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.portraits[id]
	
	local classname = select(2,UnitClass(settings.unit))
	if classname then
		local class = DaHud.Portraits.Elements.classIcons[classname]
		f.Portrait:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes")
		f.Portrait:SetTexCoord(class[1], class[2], class[3], class[4])
	else
		f.Portrait:SetTexture("Interface\\Icons\\Ability_Hunter_BeastCall")
		f.Portrait:SetTexCoord(0,1,0,1)
	end
end