--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Icons", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Icons.Plugins.masterlooter = L["Master Looter"]

DaHud.Icons.Type.player.masterlooter = L["Master Looter"]
DaHud.Icons.Type.party1.masterlooter = L["Master Looter"]
DaHud.Icons.Type.party2.masterlooter = L["Master Looter"]
DaHud.Icons.Type.party3.masterlooter = L["Master Looter"]
DaHud.Icons.Type.party4.masterlooter = L["Master Looter"]

DaHud.Icons.Elements.textures.masterlooter = "Interface\\GroupFrame\\UI-Group-MasterLooter"

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_masterlooter(id)
	if not(id) then return end

	local f = DaHud.Frames.Icons[id]
	
	local settings = DaHud.db.profile.icons[id]
	
	if (settings.type ~= "masterlooter") then return end
	
	f:RegisterEvent("PLAYER_ENTERING_WORLD")
	f:RegisterEvent("PARTY_LOOT_METHOD_CHANGED")
end

--- ========================================================= ---
---  Set Config Mode
--- ========================================================= ---
function mod:SetConfigMode_masterlooter(f)
	f.Icon:SetTexCoord(0, 1, 0, 1)
end

--- ========================================================= ---
---  Update Master Looter
--- ========================================================= ---
function mod:Update_masterlooter(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.icons[id]
	
	local _, lootMaster = GetLootMethod()
	
	if not(lootMaster) then 
		f:SetAlpha(0)
		return 
	end
	
	if (settings.unit == "player") then
		if (lootMaster == 0) then
			f:SetAlpha(1)
		else
			f:SetAlpha(0)
		end
	else
		if (settings.unit == "party"..lootMaster) then
			f:SetAlpha(1)
		else
			f:SetAlpha(0)
		end
	end
end