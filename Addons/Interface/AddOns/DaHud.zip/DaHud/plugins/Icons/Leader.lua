--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Icons", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Icons.Plugins.leader = L["Leader"]

DaHud.Icons.Type.player.leader = L["Leader"]
DaHud.Icons.Type.party1.leader = L["Leader"]
DaHud.Icons.Type.party2.leader = L["Leader"]
DaHud.Icons.Type.party3.leader = L["Leader"]
DaHud.Icons.Type.party4.leader = L["Leader"]

DaHud.Icons.Elements.textures.leader = "Interface\\GroupFrame\\UI-Group-LeaderIcon"

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_leader(id)
	if not(id) then return end

	local f = DaHud.Frames.Icons[id]
	
	local settings = DaHud.db.profile.icons[id]
	
	if (settings.type ~= "leader") then return end
	
	f:RegisterEvent("PLAYER_ENTERING_WORLD")
	f:RegisterEvent("PARTY_LEADER_CHANGED")
end

--- ========================================================= ---
---  Set Config Mode
--- ========================================================= ---
function mod:SetConfigMode_leader(f)
	f.Icon:SetTexCoord(0, 1, 0, 1)
end

--- ========================================================= ---
---  Update Leader
--- ========================================================= ---
function mod:Update_leader(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.icons[id]
	
	if (settings.unit == "player") then
		if IsPartyLeader() then
			f:SetAlpha(1)
		else
			f:SetAlpha(0)
		end
	else
		local leader = GetPartyLeaderIndex()
		if (settings.unit == "party"..leader) then
			f:SetAlpha(1)
		else
			f:SetAlpha(0)
		end
	end
end