--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Icons", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Icons.Plugins.raidtarget = L["Raid Target"]

DaHud.Icons.Type.player.raidtarget = L["Raid Target"]
DaHud.Icons.Type.pet.raidtarget = L["Raid Target"]
DaHud.Icons.Type.pettarget.raidtarget = L["Raid Target"]
DaHud.Icons.Type.target.raidtarget = L["Raid Target"]
DaHud.Icons.Type.targettarget.raidtarget = L["Raid Target"]
DaHud.Icons.Type.targettargettarget.raidtarget = L["Raid Target"]
DaHud.Icons.Type.focus.raidtarget = L["Raid Target"]
DaHud.Icons.Type.focustarget.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party1.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party1pet.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party1target.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party2.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party2pet.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party2target.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party3.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party3pet.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party3target.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party4.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party4pet.raidtarget = L["Raid Target"]
DaHud.Icons.Type.party4target.raidtarget = L["Raid Target"]

DaHud.Icons.Elements.textures.raidtarget = "Interface\\TargetingFrame\\UI-RaidTargetingIcons"

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_raidtarget(id)
	if not(id) then return end

	local f = DaHud.Frames.Icons[id]
	
	local settings = DaHud.db.profile.icons[id]
	
	if (settings.type ~= "raidtarget") then return end
	
	if settings.unit == "player" then
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
		f:RegisterEvent("RAID_TARGET_UPDATE")
	elseif settings.unit == "pet" or settings.unit == "party1pet" or settings.unit == "party2pet" or settings.unit == "party3pet" or settings.unit == "party4pet" then
	    f:RegisterEvent("UNIT_PET")
		f:RegisterEvent("RAID_TARGET_UPDATE")
	elseif settings.unit == "target" then
		f:RegisterEvent("PLAYER_TARGET_CHANGED")
		f:RegisterEvent("RAID_TARGET_UPDATE")
	elseif settings.unit == "focus" then
		f:RegisterEvent("PLAYER_FOCUS_CHANGED")
		f:RegisterEvent("RAID_TARGET_UPDATE")
	elseif settings.unit == "party1" or settings.unit == "party2" or settings.unit == "party3" or settings.unit == "party4" then
		f:RegisterEvent("PARTY_MEMBERS_CHANGED")
		f:RegisterEvent("RAID_TARGET_UPDATE")
	else
		DaHud:RegisterUpdate(self, "UpdateUneventedUnit_raidtarget", id, id)
	end
end

--- ========================================================= ---
---  Update Unevented Unit
--- ========================================================= ---
function mod:UpdateUneventedUnit_raidtarget(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Icons[id]
	
	DaHud:UpdateFrame(mod, f)
end

--- ========================================================= ---
---  Set Config Mode
--- ========================================================= ---
function mod:SetConfigMode_raidtarget(f)
	SetRaidTargetIconTexture(f.Icon, 8)
end

--- ========================================================= ---
---  Update Raid Target
--- ========================================================= ---
function mod:Update_raidtarget(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.icons[id]
	
	if UnitExists(settings.unit) then
		local icon = GetRaidTargetIndex(settings.unit)
		if (icon) then
			SetRaidTargetIconTexture(f.Icon, icon)
			f:SetAlpha(1)
		else
			f:SetAlpha(0)
        end
	else
		f:SetAlpha(0)
    end
end