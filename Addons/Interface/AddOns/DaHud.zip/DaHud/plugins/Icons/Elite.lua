--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Icons", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Icons.Plugins.elite = L["Elite"]

DaHud.Icons.Type.pettarget.elite = L["Elite"]
DaHud.Icons.Type.target.elite = L["Elite"]
DaHud.Icons.Type.targettarget.elite = L["Elite"]
DaHud.Icons.Type.targettargettarget.elite = L["Elite"]
DaHud.Icons.Type.focustarget.elite = L["Elite"]
DaHud.Icons.Type.party1target.elite = L["Elite"]
DaHud.Icons.Type.party2target.elite = L["Elite"]
DaHud.Icons.Type.party3target.elite = L["Elite"]
DaHud.Icons.Type.party4target.elite = L["Elite"]

DaHud.Icons.Elements.textures.elite = "Interface\\Addons\\DaHud\\media\\Elite"

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_elite(id)
	if not(id) then return end

	local f = DaHud.Frames.Icons[id]
	
	local settings = DaHud.db.profile.icons[id]
	
	if (settings.type ~= "elite") then return end
	
	if settings.unit == "target" then
		f:RegisterEvent("PLAYER_TARGET_CHANGED")
	elseif settings.unit == "focus" then
		f:RegisterEvent("PLAYER_FOCUS_CHANGED")
	else
		DaHud:RegisterUpdate(self, "UpdateUneventedUnit_elite", id, id)
	end
end

--- ========================================================= ---
---  Update Unevented Unit
--- ========================================================= ---
function mod:UpdateUneventedUnit_elite(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Icons[id]
	
	DaHud:UpdateFrame(mod, f)
end

--- ========================================================= ---
---  Set Config Mode
--- ========================================================= ---
function mod:SetConfigMode_elite(f)
	f.Icon:SetTexCoord(0, 1, 0, 1)
	f.Icon:SetTexture("Interface\\Addons\\DaHud\\media\\Elite")
end

--- ========================================================= ---
---  Update Elite
--- ========================================================= ---
function mod:Update_elite(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.icons[id]
	
	local classification = UnitClassification(settings.unit)
	if not(classification) or classification == "normal" then
		f:SetAlpha(0)
		return
	else
		if classification == "worldboss" or classification == "elite" then
			f.Icon:SetTexture("Interface\\Addons\\DaHud\\media\\Elite")
			f:SetAlpha(1)
		elseif classification == "rare" or classification == "rareelite" then
			f.Icon:SetTexture("Interface\\Addons\\DaHud\\media\\Rare")
			f:SetAlpha(1)
		else
			f:SetAlpha(0)
		end
	end
end