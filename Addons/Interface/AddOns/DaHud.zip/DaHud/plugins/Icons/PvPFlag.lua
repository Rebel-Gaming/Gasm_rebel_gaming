--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Icons", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Icons.Plugins.pvpflag = L["PvP Flag"]

DaHud.Icons.Type.player.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.pet.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.pettarget.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.target.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.targettarget.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.targettargettarget.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.focus.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.focustarget.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party1.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party1pet.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party1target.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party2.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party2pet.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party2target.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party3.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party3pet.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party3target.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party4.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party4pet.pvpflag = L["PvP Flag"]
DaHud.Icons.Type.party4target.pvpflag = L["PvP Flag"]

DaHud.Icons.Elements.textures.pvpflag = "Interface\\TargetingFrame\\UI-PVP-FFA"

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_pvpflag(id)
	if not(id) then return end

	local f = DaHud.Frames.Icons[id]
	
	local settings = DaHud.db.profile.icons[id]
	
	if (settings.type ~= "pvpflag") then return end
	
	DaHud:RegisterUpdate(self, "UpdateUneventedUnit_pvpflag", id, id)
end

--- ========================================================= ---
---  Update Unevented Unit
--- ========================================================= ---
function mod:UpdateUneventedUnit_pvpflag(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Icons[id]
	
	DaHud:UpdateFrame(mod, f)
end

--- ========================================================= ---
---  Set Config Mode
--- ========================================================= ---
function mod:SetConfigMode_pvpflag(f)
	f.Icon:SetTexCoord(0.05, 0.605, 0.015, 0.57)
end

--- ========================================================= ---
---  Update PvP Flag
--- ========================================================= ---
function mod:Update_pvpflag(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.icons[id]
	
	local has
	
	if UnitIsPVPFreeForAll(settings.unit) then
		has = 'FFA'
	else
		local faction = UnitFactionGroup(settings.unit)
		if faction and UnitIsPVP(settings.unit) then
			has = faction
		end
	end
	if (has) then
		f.Icon:SetTexture("Interface\\TargetingFrame\\UI-PVP-" .. has)
		if (has == "Horde") then
			f.Icon:SetTexCoord(0.08, 0.58, 0.045, 0.545)
		elseif (has == "Alliance") then
			f.Icon:SetTexCoord(0.07, 0.58, 0.06, 0.57)
		else
			f.Icon:SetTexCoord(0.05, 0.605, 0.015, 0.57)
		end
		f:SetAlpha(1)
	else
		f:SetAlpha(0)
	end
end