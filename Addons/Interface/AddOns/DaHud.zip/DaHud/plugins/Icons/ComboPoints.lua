--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Icons", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Icons.Plugins.combopoints = L["Combo Points"]

DaHud.Icons.Type.target.combopoints = L["Combo Points"]

DaHud.Icons.Elements.textures.combopoints = ""

DaHud.Icons.ComboPoints = {
	style = {
		dahud_combopoints = L["DaHud Combo Points"],
		custom = L["Custom"],
	},
	texture = {
		dahud_combopoints = "Interface\\Addons\\DaHud\\media\\ComboPoints.tga",
	},
}

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions_combopoints(id)
	DaHud.options.args.Icons.args[id].args.Appearance.args.ComboPoints = {
		name = L["Style"],
		type = "group",
		inline = true,
		order = 1,
		hidden = function(info) 
			if DaHud.db.profile.icons[info[#info-2]].type ~= "combopoints" and DaHud.db.profile.icons[info[#info-3]].type ~= "combopoints" then
				return true
			else
				return false
			end
		end,
		args = {
			style = {
				name = L["Style"],
				type = "select",
				order = 1,
				disabled = function(info) return DaHud.db.profile.icons[info[#info-3]].type ~= "combopoints" end,
				values = DaHud.Icons.ComboPoints.style,
				get = function(info) 
					return DaHud.db.profile.icons[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.icons[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
			customStyle = {
				name = L["Custom"],
				type = "input",
				width = "full",
				order = 2,
				disabled = function(info) return DaHud.db.profile.icons[info[#info-3]].style ~= "custom" end,
				get = function(info) 
					return DaHud.db.profile.icons[info[#info-3]][info[#info]]
				end,
				set = function(info, value) 
					DaHud.db.profile.icons[info[#info-3]][info[#info]] = value
					DaHud:RefreshFrame(mod, info[#info-3])
				end,
			},
		},
	}
end

--- ========================================================= ---
---  Refresh Frame
--- ========================================================= ---
function mod:RefreshFrame_combopoints(id, oldValue)
	if not(id) then return end
	
	local f = DaHud.Frames.Icons[id]

	local settings = DaHud.db.profile.icons[id]
	
	if (settings.type == "combopoints") then
		for i=2, 5 do
			if DaHud.Frames.Icons[id]["Icon"..i] then
				delFrame(DaHud.Frames.Icons[id]["Icon"..i])
			end
		end
		
		f.Icon2 = newFrame("Texture", nil, f, "ARTWORK")
		f.Icon3 = newFrame("Texture", nil, f, "ARTWORK")
		f.Icon4 = newFrame("Texture", nil, f, "ARTWORK")
		f.Icon5 = newFrame("Texture", nil, f, "ARTWORK")
		
		if (settings.style == "custom") then
			DaHud.Icons.Elements.textures.combopoints = settings.customStyle
			f.Icon:SetTexture(settings.customStyle)
			f.Icon2:SetTexture(settings.customStyle)
			f.Icon3:SetTexture(settings.customStyle)
			f.Icon4:SetTexture(settings.customStyle)
			f.Icon5:SetTexture(settings.customStyle)
		else
			if DaHud.Icons.ComboPoints.texture[settings.style] then
				DaHud.Icons.Elements.textures.combopoints = DaHud.Icons.ComboPoints.texture[settings.style]
				f.Icon:SetTexture(DaHud.Icons.ComboPoints.texture[settings.style])
				f.Icon2:SetTexture(DaHud.Icons.ComboPoints.texture[settings.style])
				f.Icon3:SetTexture(DaHud.Icons.ComboPoints.texture[settings.style])
				f.Icon4:SetTexture(DaHud.Icons.ComboPoints.texture[settings.style])
				f.Icon5:SetTexture(DaHud.Icons.ComboPoints.texture[settings.style])
			end
		end
		
		f.Icon:SetTexCoord(0, 1, 0, 0.20)
		
		f.Icon2:SetWidth(settings.width)
		f.Icon2:SetHeight(settings.height)
		f.Icon2:ClearAllPoints()
		f.Icon2:SetPoint("TOP", f.Icon, "BOTTOM", 0, 0)
		f.Icon2:SetTexture(DaHud.Icons.Elements.textures[settings.type])
		f.Icon2:SetTexCoord(0, 1, 0.20, 0.40)
		
		f.Icon3:SetWidth(settings.width)
		f.Icon3:SetHeight(settings.height)
		f.Icon3:ClearAllPoints()
		f.Icon3:SetPoint("TOP", f.Icon2, "BOTTOM", 0, 0)
		f.Icon3:SetTexture(DaHud.Icons.Elements.textures[settings.type])
		f.Icon3:SetTexCoord(0, 1, 0.40, 0.60)
		
		f.Icon4:SetWidth(settings.width)
		f.Icon4:SetHeight(settings.height)
		f.Icon4:ClearAllPoints()
		f.Icon4:SetPoint("TOP", f.Icon3, "BOTTOM", 0, 0)
		f.Icon4:SetTexture(DaHud.Icons.Elements.textures[settings.type])
		f.Icon4:SetTexCoord(0, 1, 0.60, 0.80)
		
		f.Icon5:SetWidth(settings.width)
		f.Icon5:SetHeight(settings.height)
		f.Icon5:ClearAllPoints()
		f.Icon5:SetPoint("TOP", f.Icon4, "BOTTOM", 0, 0)
		f.Icon5:SetTexture(DaHud.Icons.Elements.textures[settings.type])
		f.Icon5:SetTexCoord(0, 1, 0.80, 1)
	elseif (oldValue == "combopoints") then
		for i=2, 5 do
			if DaHud.Frames.Icons[id]["Icon"..i] then
				delFrame(DaHud.Frames.Icons[id]["Icon"..i])
			end
		end
	end
end

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_combopoints(id)
	if not(id) then return end

	local f = DaHud.Frames.Icons[id]
	
	local settings = DaHud.db.profile.icons[id]
	
	if (settings.type ~= "combopoints") then return end

	if settings.unit == "target" then
		f:RegisterEvent("PLAYER_TARGET_CHANGED")
		f:RegisterEvent("PLAYER_COMBO_POINTS")
	end
end

--- ========================================================= ---
---  Set Config Mode
--- ========================================================= ---
function mod:SetConfigMode_combopoints(f)
	f.Icon:SetAlpha(1)
	f.Icon2:SetAlpha(1)
	f.Icon3:SetAlpha(1)
	f.Icon4:SetAlpha(1)
	f.Icon5:SetAlpha(1)
end

--- ========================================================= ---
---  Update Combo Points
--- ========================================================= ---
function mod:Update_combopoints(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.icons[id]
	
	if not(DaHud.Frames.Icons[id].Icon2) then
		mod:RefreshFrame_combopoints(id)
	end

	local cp = GetComboPoints()

	if cp and (cp == 1) then
		f:SetAlpha(1)
		f.Icon:SetAlpha(1)
		f.Icon2:SetAlpha(0)
		f.Icon3:SetAlpha(0)
		f.Icon4:SetAlpha(0)
		f.Icon5:SetAlpha(0)
	elseif cp and (cp == 2) then
		f:SetAlpha(1)
		f.Icon:SetAlpha(1)
		f.Icon2:SetAlpha(1)
		f.Icon3:SetAlpha(0)
		f.Icon4:SetAlpha(0)
		f.Icon5:SetAlpha(0)
	elseif cp and (cp == 3) then
		f:SetAlpha(1)
		f.Icon:SetAlpha(1)
		f.Icon2:SetAlpha(1)
		f.Icon3:SetAlpha(1)
		f.Icon4:SetAlpha(0)
		f.Icon5:SetAlpha(0)
	elseif cp and (cp == 4) then
		f:SetAlpha(1)
		f.Icon:SetAlpha(1)
		f.Icon2:SetAlpha(1)
		f.Icon3:SetAlpha(1)
		f.Icon4:SetAlpha(1)
		f.Icon5:SetAlpha(0)
	elseif cp and (cp == 5) then
		f:SetAlpha(1)
		f.Icon:SetAlpha(1)
		f.Icon2:SetAlpha(1)
		f.Icon3:SetAlpha(1)
		f.Icon4:SetAlpha(1)
		f.Icon5:SetAlpha(1)
	else
		f:SetAlpha(0)
		f.Icon:SetAlpha(0)
		f.Icon2:SetAlpha(0)
		f.Icon3:SetAlpha(0)
		f.Icon4:SetAlpha(0)
		f.Icon5:SetAlpha(0)
	end
end