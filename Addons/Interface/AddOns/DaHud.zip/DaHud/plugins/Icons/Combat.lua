--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Icons", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Icons.Plugins.combat = L["Combat"]

DaHud.Icons.Type.player.combat = L["Combat"]
DaHud.Icons.Type.pet.combat = L["Combat"]
DaHud.Icons.Type.pettarget.combat = L["Combat"]
DaHud.Icons.Type.target.combat = L["Combat"]
DaHud.Icons.Type.targettarget.combat = L["Combat"]
DaHud.Icons.Type.targettargettarget.combat = L["Combat"]
DaHud.Icons.Type.focus.combat = L["Combat"]
DaHud.Icons.Type.focustarget.combat = L["Combat"]
DaHud.Icons.Type.party1.combat = L["Combat"]
DaHud.Icons.Type.party1pet.combat = L["Combat"]
DaHud.Icons.Type.party1target.combat = L["Combat"]
DaHud.Icons.Type.party2.combat = L["Combat"]
DaHud.Icons.Type.party2pet.combat = L["Combat"]
DaHud.Icons.Type.party2target.combat = L["Combat"]
DaHud.Icons.Type.party3.combat = L["Combat"]
DaHud.Icons.Type.party3pet.combat = L["Combat"]
DaHud.Icons.Type.party3target.combat = L["Combat"]
DaHud.Icons.Type.party4.combat = L["Combat"]
DaHud.Icons.Type.party4pet.combat = L["Combat"]
DaHud.Icons.Type.party4target.combat = L["Combat"]

DaHud.Icons.Elements.textures.combat =  "Interface\\CharacterFrame\\UI-StateIcon"

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_combat(id)
	if not(id) then return end

	local f = DaHud.Frames.Icons[id]
	
	local settings = DaHud.db.profile.icons[id]
	
	if (settings.type ~= "combat") then return end
	
	DaHud:RegisterUpdate(self, "UpdateUneventedUnit_combat", id, id)
end

--- ========================================================= ---
---  Update Unevented Unit
--- ========================================================= ---
function mod:UpdateUneventedUnit_combat(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Icons[id]
	
	DaHud:UpdateFrame(mod, f)
end

--- ========================================================= ---
---  Set Config Mode
--- ========================================================= ---
function mod:SetConfigMode_combat(f)
	f.Icon:SetTexCoord(0.57, 0.90, 0.08, 0.41)
end

--- ========================================================= ---
---  Update Combat
--- ========================================================= ---
function mod:Update_combat(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.icons[id]
	
	f.Icon:SetTexCoord(0.57, 0.90, 0.08, 0.41)
	
	if UnitAffectingCombat(settings.unit) then
		f:SetAlpha(1)
	else
		f:SetAlpha(0)
	end
end