--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Icons", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Icons.Plugins.pethappiness = L["Pet Happiness"]

DaHud.Icons.Type.pet.pethappiness = L["Pet Happiness"]

DaHud.Icons.Elements.textures.pethappiness = "Interface\\PetPaperDollFrame\\UI-PetHappiness"

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_pethappiness(id)
	if not(id) then return end

	local f = DaHud.Frames.Icons[id]
	
	local settings = DaHud.db.profile.icons[id]
	
	if (settings.type ~= "pethappiness") then return end
	
	f:RegisterEvent("UNIT_PET")
	f:RegisterEvent("UNIT_HAPPINESS")
end

--- ========================================================= ---
---  Set Config Mode
--- ========================================================= ---
function mod:SetConfigMode_pethappiness(f)
	f.Icon:SetTexCoord(0.1875, 0.375, 0, 0.359375)
end

--- ========================================================= ---
---  Update Pet Happiness
--- ========================================================= ---
function mod:Update_pethappiness(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.icons[id]
	
	local happiness, damagePercentage, loyaltyRate = GetPetHappiness()
	if not(happiness) then
		f:SetAlpha(0)
		return
	else
		if happiness == 3 then
			f.Icon:SetTexCoord(0, 0.1875, 0, 0.359375)
			f:SetAlpha(1)
		elseif happiness == 2 then
			f.Icon:SetTexCoord(0.1875, 0.375, 0, 0.359375)
			f:SetAlpha(1)
		elseif happiness == 1 then
			f.Icon:SetTexCoord(0.375, 0.5625, 0, 0.359375)
			f:SetAlpha(1)
		else
			f:SetAlpha(0)
		end
	end
end