--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Bars", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Bars.Plugins.power = L["Power"]

DaHud.Bars.Type.player.power = L["Power"]
DaHud.Bars.Type.pet.power = L["Power"]
DaHud.Bars.Type.pettarget.power = L["Power"]
DaHud.Bars.Type.target.power = L["Power"]
DaHud.Bars.Type.targettarget.power = L["Power"]
DaHud.Bars.Type.targettargettarget.power = L["Power"]
DaHud.Bars.Type.focus.power = L["Power"]
DaHud.Bars.Type.focustarget.power = L["Power"]
DaHud.Bars.Type.party1.power = L["Power"]
DaHud.Bars.Type.party1pet.power = L["Power"]
DaHud.Bars.Type.party1target.power = L["Power"]
DaHud.Bars.Type.party2.power = L["Power"]
DaHud.Bars.Type.party2pet.power = L["Power"]
DaHud.Bars.Type.party2target.power = L["Power"]
DaHud.Bars.Type.party3.power = L["Power"]
DaHud.Bars.Type.party3pet.power = L["Power"]
DaHud.Bars.Type.party3target.power = L["Power"]
DaHud.Bars.Type.party4.power = L["Power"]
DaHud.Bars.Type.party4pet.power = L["Power"]
DaHud.Bars.Type.party4target.power = L["Power"]

--- ========================================================= ---
---  Create Frame Settings
--- ========================================================= ---
function mod:CreateFrameSettings_power(id)
	if not(DaHud.db.profile.colors.power) then
		DaHud.db.profile.colors.power = {}
	end
	
	if not(DaHud.db.profile.colors.power.rage) then
		DaHud.db.profile.colors.power.rage = {1, 0, 0.25}
	end
	if not(DaHud.db.profile.colors.power.energy) then
		DaHud.db.profile.colors.power.energy = {1, 1, 0.2}
	end
	if not(DaHud.db.profile.colors.power.focus) then
		DaHud.db.profile.colors.power.focus = {1, 1, 0.2}
	end
	if not(DaHud.db.profile.colors.power.mana) then
		DaHud.db.profile.colors.power.mana = {0.25, 0.5, 0.75}
	end
end

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions_power()
	if not(DaHud.options.args.general.args.colors.args.power) then
		DaHud.options.args.general.args.colors.args.power ={
			name = L["Power"],
			type= "group",
			order = 4,
			args = {
			},
		}
	end
	
	local path = DaHud.options.args.general.args.colors.args
	DaHud:AddColorOption(path, L["Rage"], 1, "power", "rage")
	DaHud:AddColorOption(path, L["Energy"], 2, "power", "energy")
	DaHud:AddColorOption(path, L["Focus"], 3, "power", "focus")
	DaHud:AddColorOption(path, L["Mana"], 4, "power", "mana")
end

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_power(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Bars[id]
	
	local settings = DaHud.db.profile.bars[id]

	if (settings.type ~= "power") then return end

	if settings.unit == "player" then
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
		f:RegisterEvent("UNIT_MANA")
		f:RegisterEvent("UNIT_MAXMANA")
		f:RegisterEvent("UNIT_ENERGY")
		f:RegisterEvent("UNIT_MAXENERGY")
		f:RegisterEvent("UNIT_RAGE")
		f:RegisterEvent("UNIT_MAXRAGE")
		f:RegisterEvent("UNIT_DISPLAYPOWER")
	elseif settings.unit == "pet" or settings.unit == "party1pet" or settings.unit == "party2pet" or settings.unit == "party3pet" or settings.unit == "party4pet" then
	    f:RegisterEvent("UNIT_PET")
		f:RegisterEvent("UNIT_MANA")
		f:RegisterEvent("UNIT_MAXMANA")
		f:RegisterEvent("UNIT_ENERGY")
		f:RegisterEvent("UNIT_MAXENERGY")
		f:RegisterEvent("UNIT_RAGE")
		f:RegisterEvent("UNIT_MAXRAGE")
		f:RegisterEvent("UNIT_DISPLAYPOWER")
	elseif settings.unit == "target" then
		f:RegisterEvent("PLAYER_TARGET_CHANGED")
		f:RegisterEvent("UNIT_MANA")
		f:RegisterEvent("UNIT_MAXMANA")
		f:RegisterEvent("UNIT_ENERGY")
		f:RegisterEvent("UNIT_MAXENERGY")
		f:RegisterEvent("UNIT_RAGE")
		f:RegisterEvent("UNIT_MAXRAGE")
		f:RegisterEvent("UNIT_DISPLAYPOWER")
	elseif settings.unit == "focus" then
		f:RegisterEvent("PLAYER_FOCUS_CHANGED")
		f:RegisterEvent("UNIT_MANA")
		f:RegisterEvent("UNIT_MAXMANA")
		f:RegisterEvent("UNIT_ENERGY")
		f:RegisterEvent("UNIT_MAXENERGY")
		f:RegisterEvent("UNIT_RAGE")
		f:RegisterEvent("UNIT_MAXRAGE")
		f:RegisterEvent("UNIT_DISPLAYPOWER")
	elseif settings.unit == "party1" or settings.unit == "party2" or settings.unit == "party3" or settings.unit == "party4" then
		f:RegisterEvent("PARTY_MEMBERS_CHANGED")
		f:RegisterEvent("UNIT_MANA")
		f:RegisterEvent("UNIT_MAXMANA")
		f:RegisterEvent("UNIT_ENERGY")
		f:RegisterEvent("UNIT_MAXENERGY")
		f:RegisterEvent("UNIT_RAGE")
		f:RegisterEvent("UNIT_MAXRAGE")
		f:RegisterEvent("UNIT_DISPLAYPOWER")
	else
		DaHud:RegisterUpdate(self, "UpdateUneventedUnit_power", id, id)
	end
end

--- ========================================================= ---
---  Update Unevented Unit
--- ========================================================= ---
function mod:UpdateUneventedUnit_power(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Bars[id]
	
	DaHud:UpdateFrame(mod, f)
end

--- ========================================================= ---
---  Update Power
--- ========================================================= ---
function mod:Update_power(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.bars[id]
	
	local r, g, b = unpack(DaHud.db.profile.colors.power.mana)
	local powerType = UnitExists(settings.unit) and UnitPowerType(settings.unit) or -1
	
	local current, max = UnitMana(settings.unit), UnitManaMax(settings.unit)
		
	if max > 0 then
		current = current / max
	else
		current = 0
	end
		
	if powerType == 0 then
		r, g, b = unpack(DaHud.db.profile.colors.power.mana)
	elseif powerType == 1 then
		r, g, b = unpack(DaHud.db.profile.colors.power.rage)
	elseif powerType == 2 then
		r, g, b = unpack(DaHud.db.profile.colors.power.focus)
	elseif powerType == 3 then
		r, g, b = unpack(DaHud.db.profile.colors.power.energy)
	end
	
	f.Background:SetVertexColor(r, g, b, 0.4)
	f.Bar:SetVertexColor(r, g, b, 1)
	f.StatusBar:SetStatusBarColor(r, g, b, 1)
	
	if not(settings.animate) then
		f.currentValue = current
		f.targetValue = current
	else
		f.targetValue = current

		if f.currentValue ~= f.targetValue then
			f.animationEndTime = GetTime() + 0.5
			f.animating = true
		end
	end
end