--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Bars", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Bars.Plugins.experience = L["Experience"]

DaHud.Bars.Type.player.experience = L["Experience"]

--- ========================================================= ---
---  Create Frame Settings
--- ========================================================= ---
function mod:CreateFrameSettings_experience(id)
	if not(DaHud.db.profile.colors.other) then
		DaHud.db.profile.colors.other = {}
	end
	
	if not(DaHud.db.profile.colors.other.experience) then
		DaHud.db.profile.colors.other.experience = {0.75, 0, 0.75}
	end
	if not(DaHud.db.profile.colors.other.restedexp) then
		DaHud.db.profile.colors.other.restedexp = {0, 0.75, 0.75}
	end
end

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:SetupOptions_experience()
	if not(DaHud.options.args.general.args.colors.args.other) then
		DaHud.options.args.general.args.colors.args.other ={
			name = L["Other"],
			type= "group",
			order = 6,
			args = {
			},
		}
	end
	
	local path = DaHud.options.args.general.args.colors.args
	DaHud:AddColorOption(path, L["Experience"], 1, "other", "experience")
	DaHud:AddColorOption(path, L["Rested Experience"], 2, "other", "restedexp")
end

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_experience(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Bars[id]
	
	local settings = DaHud.db.profile.bars[id]
	
	if (settings.type ~= "experience") then return end
	
	if settings.unit == "player" then
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
		f:RegisterEvent("PLAYER_XP_UPDATE")
		f:RegisterEvent("PLAYER_LEVEL_UP")
	end
	
	f:RegisterEvent("UPDATE_EXHAUSTION")
end

--- ========================================================= ---
---  Update Experience
--- ========================================================= ---
function mod:Update_experience(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.bars[id]
	
	local r, g, b = unpack(DaHud.db.profile.colors.other.experience)
	local rSec, gSec, bSec = unpack(DaHud.db.profile.colors.other.restedexp)

	local current, max = UnitXP(settings.unit), UnitXPMax(settings.unit)

	if not(max) or max == 0 then
		current = 0
		max = 1
	else
		current = current/max
	end
	
	local rest = (settings.unit == "player" and GetXPExhaustion() or 0) / max
	
	if rest and (rest > 0) then
		if (settings.style == "vertical") then
			f.SecBar:Show()
			f.SecStatusBar:Hide()
		else
			f.SecBar:Hide()
			f.SecStatusBar:Show()
		end
		
		rest = rest + current
		
		f.currentSecValue = rest
		f.targetSecValue = rest
	else 
		f.SecBar:Hide()
		f.SecStatusBar:Hide()
	end
	
	f.Background:SetVertexColor(r, g, b, 0.4)
	f.Bar:SetVertexColor(r, g, b, 1)
	f.SecBar:SetVertexColor(rSec, gSec, bSec, 1)
	f.StatusBar:SetStatusBarColor(r, g, b, 1)
	f.SecStatusBar:SetStatusBarColor(rSec, gSec, bSec, 1)
	
	if not(settings.animate) then
		f.currentValue = current
		f.targetValue = current
	else
		f.targetValue = current

		if f.currentValue ~= f.targetValue then
			f.animationEndTime = GetTime() + 0.5
			f.animating = true
		end
	end
end