--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Bars", true)
local LibDruidMana = LibStub("LibDruidMana-1.0", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Bars.Plugins.druidmana = L["Druid Mana"]

DaHud.Bars.Type.player.druidmana = L["Druid Mana"]

--- ========================================================= ---
---  Create Frame Settings
--- ========================================================= ---
function mod:CreateFrameSettings_druidmana(id)
	if not(DaHud.db.profile.colors.power) then
		DaHud.db.profile.colors.power = {}
	end
	
	if not(DaHud.db.profile.colors.power.mana) then
		DaHud.db.profile.colors.power.mana = {0.25, 0.5, 0.75}
	end
end

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions_druidmana()
	if not(DaHud.options.args.general.args.colors.args.power) then
		DaHud.options.args.general.args.colors.args.power ={
			name = L["Power"],
			type= "group",
			order = 4,
			args = {
			},
		}
	end
	
	local path = DaHud.options.args.general.args.colors.args
	DaHud:AddColorOption(path, L["Mana"], 4, "power", "mana")
end

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_druidmana(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Bars[id]
	
	local settings = DaHud.db.profile.bars[id]

	if (settings.type ~= "druidmana") then return end

	if settings.unit == "player" then
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
	end

	f:RegisterEvent("UNIT_DISPLAYPOWER")
	
	local _, class = UnitClass("player")
	if (class == "DRUID") then
		LibDruidMana:AddListener(function()
			mod:Update_druidmana(f)
		end)
	end
end

--- ========================================================= ---
---  Update DruidMana
--- ========================================================= ---
function mod:Update_druidmana(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.bars[id]
	
	if not(settings.type == "druidmana") then return end
	
	local r, g, b = unpack(DaHud.db.profile.colors.power.mana)

	local current, max = 0, 0

	local _, class = UnitClass("player")
	if (class == "DRUID") then
		current = LibDruidMana:GetCurrentMana() or 0
		max =  LibDruidMana:GetMaximumMana() or 1
	end

	if max > 0 then
		current = current / max
	else
		current = 0
	end
	
	f.Background:SetVertexColor(r, g, b, 0.4)
	f.Bar:SetVertexColor(r, g, b, 1)
	f.StatusBar:SetStatusBarColor(r, g, b, 1)
	
	if not(settings.animate) then
		f.currentValue = current
		f.targetValue = current
	else
		f.targetValue = current

		if f.currentValue ~= f.targetValue then
			f.animationEndTime = GetTime() + 0.5
			f.animating = true
		end
	end
	
	if UnitPowerType("player") ~= 0 then
		local _, class = UnitClass("player")
		if (class == "DRUID") then
	    	f:SetAlpha(1)
		else
			f:SetAlpha(0)
		end
	else
	    f:SetAlpha(0)
	end
end