--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Bars", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Bars.Plugins.casting = L["Casting"]

DaHud.Bars.Type.player.casting = L["Casting"]
DaHud.Bars.Type.pet.casting = L["Casting"]
DaHud.Bars.Type.pettarget.casting = L["Casting"]
DaHud.Bars.Type.target.casting = L["Casting"]
DaHud.Bars.Type.targettarget.casting = L["Casting"]
DaHud.Bars.Type.targettargettarget.casting = L["Casting"]
DaHud.Bars.Type.focus.casting = L["Casting"]
DaHud.Bars.Type.focustarget.casting = L["Casting"]
DaHud.Bars.Type.party1.casting = L["Casting"]
DaHud.Bars.Type.party1pet.casting = L["Casting"]
DaHud.Bars.Type.party1target.casting = L["Casting"]
DaHud.Bars.Type.party2.casting = L["Casting"]
DaHud.Bars.Type.party2pet.casting = L["Casting"]
DaHud.Bars.Type.party2target.casting = L["Casting"]
DaHud.Bars.Type.party3.casting = L["Casting"]
DaHud.Bars.Type.party3pet.casting = L["Casting"]
DaHud.Bars.Type.party3target.casting = L["Casting"]
DaHud.Bars.Type.party4.casting = L["Casting"]
DaHud.Bars.Type.party4pet.casting = L["Casting"]
DaHud.Bars.Type.party4target.casting = L["Casting"]

--- ========================================================= ---
---  Create Frame Settings
--- ========================================================= ---
function mod:CreateFrameSettings_casting(id)
	if not(DaHud.db.profile.colors.cast) then
		DaHud.db.profile.colors.cast = {}
	end
	
	if not(DaHud.db.profile.colors.cast.casting) then
		DaHud.db.profile.colors.cast.casting = {0.25, 0.75, 0.25}
	end
	if not(DaHud.db.profile.colors.cast.channeling) then
		DaHud.db.profile.colors.cast.channeling = {0.25, 0.5, 0.75}
	end
	if not(DaHud.db.profile.colors.cast.failed) then
		DaHud.db.profile.colors.cast.failed = {1, 0, 0.25}
	end
	if not(DaHud.db.profile.colors.cast.interrupted) then
		DaHud.db.profile.colors.cast.interrupted = {1, 0, 0.25}
	end
end

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions_casting()
	if not(DaHud.options.args.general.args.colors.args.cast) then
		DaHud.options.args.general.args.colors.args.cast ={
			name = L["SpellCast"],
			type= "group",
			order = 5,
			args = {
			},
		}
	end
	
	local path = DaHud.options.args.general.args.colors.args
	DaHud:AddColorOption(path, L["Casting"], 1, "cast", "casting")
	DaHud:AddColorOption(path, L["Channeling"], 2, "cast", "channeling")
	DaHud:AddColorOption(path, L["Failed"], 3, "cast", "failed")
	DaHud:AddColorOption(path, L["Interrupted"], 4, "cast", "interrupted")
end

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_casting(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Bars[id]
	
	local settings = DaHud.db.profile.bars[id]
	
	if (settings.type ~= "casting") then return end
	
	if settings.unit == "target" then
		f:RegisterEvent("PLAYER_TARGET_CHANGED")
	elseif settings.unit == "focus" then
		f:RegisterEvent("PLAYER_FOCUS_CHANGED")
	end
	
	f:RegisterEvent("UNIT_SPELLCAST_START")
	f:RegisterEvent("UNIT_SPELLCAST_STOP" )
	f:RegisterEvent("UNIT_SPELLCAST_FAILED")
	f:RegisterEvent("UNIT_SPELLCAST_DELAYED")
	f:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
	f:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
	f:RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE")
	f:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
	f:RegisterEvent("UNIT_SPELLCAST_CHANNEL_INTERRUPTED")
end

--- ========================================================= ---
---  OnEvent
--- ========================================================= ---
function mod:OnEvent_casting(f, event, unit)
	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.bars[id]
	
	if (settings.type ~= "casting") then return end

	if (event == "UNIT_SPELLCAST_START") then
		if (f:GetAttribute("unit") == unit) then
			mod:UNIT_SPELLCAST_START(f, unit)
		end
	elseif (event == "UNIT_SPELLCAST_STOP") then
		if (f:GetAttribute("unit") == unit) then
			mod:UNIT_SPELLCAST_STOP(f, unit)
		end
	elseif (event == "UNIT_SPELLCAST_FAILED") then
		if (f:GetAttribute("unit") == unit) then
			mod:UNIT_SPELLCAST_FAILED(f, unit)
		end
	elseif (event == "UNIT_SPELLCAST_DELAYED") then
		if (f:GetAttribute("unit") == unit) then
			mod:UNIT_SPELLCAST_DELAYED(f, unit)
		end
	elseif (event == "UNIT_SPELLCAST_INTERRUPTED") then
		if (f:GetAttribute("unit") == unit) then
			mod:UNIT_SPELLCAST_INTERRUPTED(f, unit)
		end
	elseif (event == "UNIT_SPELLCAST_CHANNEL_START") then
		if (f:GetAttribute("unit") == unit) then
			mod:UNIT_SPELLCAST_CHANNEL_START(f, unit)
		end
	elseif (event == "UNIT_SPELLCAST_CHANNEL_UPDATE") then
		if (f:GetAttribute("unit") == unit) then
			mod:UNIT_SPELLCAST_CHANNEL_UPDATE(f, unit)
		end
	elseif (event == "UNIT_SPELLCAST_CHANNEL_STOP") then
		if (f:GetAttribute("unit") == unit) then
			mod:UNIT_SPELLCAST_CHANNEL_STOP(f, unit)
		end
	elseif (event == "UNIT_SPELLCAST_CHANNEL_INTERRUPTED") then
		if (f:GetAttribute("unit") == unit) then
			mod:UNIT_SPELLCAST_CHANNEL_INTERRUPTED(f, unit)
		end
	elseif (event == "PLAYER_TARGET_CHANGED") then
		if (f:GetAttribute("unit") == "target") then
			mod:CheckUnitSpellCast(f, "target")
		end
	elseif (event == "PLAYER_FOCUS_CHANGED") then
		if (f:GetAttribute("unit") == "focus") then
			mod:CheckUnitSpellCast(f, "focus")
		end
	end
end

--- ========================================================= ---
---  UNIT_SPELLCAST_START
--- ========================================================= ---
function mod:UNIT_SPELLCAST_START(f, unit)
	local spell, rank, displayName, icon, startTime, endTime = UnitCastingInfo(unit)

	if not(startTime) then
	    self.castingValue = 0
		mod:Update_casting(f)
		return
	end

	f.casting = true
	f.channeling = nil
	f.failed = nil
	f.interrupted = nil
	
	f.castStartTime = startTime / 1000
	f.castEndTime = endTime / 1000
	f.castDelay = 0

	f.currentValue = 0
	f.targetValue = 0
	
	f.fadeOut = nil
	f.alpha = 1
	
	mod:Update_casting(f)
end

--- ========================================================= ---
---  UNIT_SPELLCAST_STOP
--- ========================================================= ---
function mod:UNIT_SPELLCAST_STOP(f, unit)
	if f.casting then
		f.casting = nil
		f.channeling = nil
		f.failed = nil
		f.interrupted = nil
		
		f.stopTime = GetTime()

		f.currentValue = 1
		f.targetValue = 1
		
		f.fadeOut = true
		f.alpha = 1
		
		mod:Update_casting(f)
	end
end

--- ========================================================= ---
---  UNIT_SPELLCAST_FAILED
--- ========================================================= ---
function mod:UNIT_SPELLCAST_FAILED(f, unit)
	f.casting = nil
	f.channeling = nil
	f.failed = true
	f.interrupted = nil

	if not(f.stopTime) then
	    f.stopTime = GetTime()
	end

	f.currentValue = 1
	f.targetValue = 1
	
	f.fadeOut = true
	f.alpha = 1
	
	mod:Update_casting(f)
end

--- ========================================================= ---
---  UNIT_SPELLCAST_DELAYED
--- ========================================================= ---
function mod:UNIT_SPELLCAST_DELAYED(f, unit)
	local spell, rank, displayName, icon, startTime, endTime = UnitCastingInfo(unit)

	if startTime then
		local oldStartTime = f.castStartTime

	    f.castStartTime = startTime / 1000
	    f.castEndTime = endTime / 1000

	    f.castDelay = (f.castDelay or 0) + (startTime - (oldStartTime or startTime))
	end
end

--- ========================================================= ---
---  UNIT_SPELLCAST_INTERRUPTED
--- ========================================================= ---
function mod:UNIT_SPELLCAST_INTERRUPTED(f, unit)
	f.casting = nil
	f.channeling = nil
	f.failed = nil
	f.interrupted = true

	if not(f.stopTime) then
	    f.stopTime = GetTime()
	end

	f.currentValue = 1
	f.targetValue = 1
	
	f.fadeOut = true
	f.alpha = 1
	
	mod:Update_casting(f)
end

--- ========================================================= ---
---  UNIT_SPELLCAST_CHANNEL_START
--- ========================================================= ---
function mod:UNIT_SPELLCAST_CHANNEL_START(f, unit)
	local spell, rank, displayName, icon, startTime, endTime = UnitChannelInfo(unit)
	
	if not startTime then
	    self.castingValue = 0
		mod:Update_casting(f)
		return
	end

	f.casting = nil
	f.channeling = true
	f.failed = nil
	f.interrupted = nil
	
	f.castStartTime = startTime / 1000
	f.castEndTime = endTime / 1000
	f.castDelay = 0

	f.currentValue = 0
	f.targetValue = 0
	
	f.fadeOut = nil
	f.alpha = 1
	
	mod:Update_casting(f)
end

--- ========================================================= ---
---  UNIT_SPELLCAST_CHANNEL_UPDATE
--- ========================================================= ---
function mod:UNIT_SPELLCAST_CHANNEL_UPDATE(f, unit)
	local spell, rank, displayName, icon, startTime, endTime = UnitChannelInfo(unit)

	if startTime then
		local oldStartTime = f.castStartTime

	    f.castStartTime = startTime / 1000
	    f.castEndTime = endTime / 1000

	   f.castDelay = (f.castDelay or 0) + (startTime - (oldStartTime or startTime))
	end
end

--- ========================================================= ---
---  UNIT_SPELLCAST_CHANNEL_STOP
--- ========================================================= ---
function mod:UNIT_SPELLCAST_CHANNEL_STOP(f, unit)
	if f.channeling then
		f.casting = nil
		f.channeling = nil
		f.failed = nil
		f.interrupted = nil
		
		f.stopTime = GetTime()

		f.currentValue = 1
		f.targetValue = 1
		
		f.fadeOut = true
		f.alpha = 1
		
		mod:Update_casting(f)
	end
end

--- ========================================================= ---
---  UNIT_SPELLCAST_CHANNEL_INTERRUPTED
--- ========================================================= ---
function mod:UNIT_SPELLCAST_CHANNEL_INTERRUPTED(f, unit)
	f.casting = nil
	f.channeling = nil
	f.failed = nil
	f.interrupted = true

	if not(f.stopTime) then
	    f.stopTime = GetTime()
	end
	
	f.currentValue = 1
	f.targetValue = 1
	
	f.fadeOut = true
	f.alpha = 1
	
	mod:Update_casting(f)
end

--- ========================================================= ---
---  Check Unit Spell Cast
--- ========================================================= ---
function mod:CheckUnitSpellCast(f, unit)
	f.casting = nil
	f.channeling = nil
	f.failed = nil
	f.interrupted = nil
	
	f.fadeOut = nil
	f.alpha = 0
	
	if not(UnitExists(unit)) then
	    return
	end

	local spell, rank, displayName, icon, startTime, endTime = UnitCastingInfo(unit)

	if spell then
	    f.casting = true
	    f.channeling = nil
	    f.failed = nil
		f.interrupted = nil
		
		f.castStartTime = startTime / 1000
	    f.castEndTime = endTime / 1000
	    f.castDelay = 0
		
		f.fadeOut = nil
		f.alpha = 1
	else
	    spell, rank, displayName, icon, startTime, endTime = UnitChannelInfo(unit)

	    if spell then
		    f.casting = nil
		    f.channeling = true
		    f.failed = nil
			f.interrupted = nil

		    f.castStartTime = startTime / 1000
		    f.castEndTime = endTime / 1000
		    f.castDelay = 0
			
			f.fadeOut = nil
			f.alpha = 1
	    end
	end

	if f.casting or self.channeling then
		f.currentValue = 0
		f.targetValue = 0
		
		mod:Update_casting(f)
	end
end

--- ========================================================= ---
---  OnUpdate
--- ========================================================= ---
function mod:OnUpdate_casting()
	local id = string.gsub(this:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.bars[id]

	if (settings.type ~= "casting") then return end

	local currentTime = GetTime()
	
	if (this.currentValue ~= 0) then
		mod:UpdateFrame(this)
	end
	
	if this.casting then
	    if currentTime > this.castEndTime then
			this.casting = nil
			this.channeling = nil
			this.failed = nil
			this.interrupted = nil
			
			this.stopTime = currentTime
			
			this.fadeOut = true
		end

		local showTime = math.min(currentTime, this.castEndTime)
		local p = (showTime - this.castStartTime) / (this.castEndTime - this.castStartTime)

		this.currentValue = p
		this.targetValue = p
	elseif this.channeling then
	    if currentTime > this.castEndTime then
			this.casting = nil
			this.channeling = nil
			this.failed = nil
			this.interrupted = nil
			
	        this.stopTime = currentTime
			
			this.fadeOut = true
		end

		local remainingTime = this.castEndTime - currentTime
		local p = remainingTime / (this.castEndTime - this.castStartTime)

		this.currentValue = p
		this.targetValue = p
	elseif this.fadeOut then
	    if this.stopTime then
	        this.alpha = this.stopTime - currentTime + 1
	    else
			this.alpha = 0
	    end

	    if this.alpha >= 1 then
	        this.alpha = 1
		end

		if this.alpha <= 0 then
			this.casting = nil
			this.channeling = nil
			this.failed = nil
			this.interrupted = nil
			
			this.stopTime = nil
			
		    this.fadeOut = nil
		    
			this.currentValue = 0
			this.targetValue = 0
			
			mod:Update_casting(this)
		else
		    mod:Update_casting(this)
		end
	else
		this.currentValue = 0
		this.targetValue = 0
	end
	
	mod:Update_casting(this)
end

--- ========================================================= ---
---  Update Casting
--- ========================================================= ---
function mod:Update_casting(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.bars[id]
	
	local r, g, b = unpack(DaHud.db.profile.colors.cast.casting)
	
	if f.casting then
		r, g, b = unpack(DaHud.db.profile.colors.cast.casting)
	elseif f.channeling then
		r, g, b = unpack(DaHud.db.profile.colors.cast.channeling)
	elseif f.failed then
		r, g, b = unpack(DaHud.db.profile.colors.cast.failed)
	elseif f.interrupted then
		r, g, b = unpack(DaHud.db.profile.colors.cast.interrupted)
	end

	f.Background:SetVertexColor(r, g, b, 0.4)
	f.Bar:SetVertexColor(r, g, b, 1)
	f.StatusBar:SetStatusBarColor(r, g, b, 1)
	
	if not(DaHud:InConfigMode()) then
		f:SetAlpha(f.alpha or 0)
	end
end