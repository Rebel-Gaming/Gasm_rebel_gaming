--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Bars", true)
local Threat = LibStub("Threat-2.0", true)

if not(mod) then return end
if not(Threat) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Bars.Plugins.threat = L["Threat"]

DaHud.Bars.Type.player.threat = L["Threat"]

--- ========================================================= ---
---  Create Frame Settings
--- ========================================================= ---
function mod:CreateFrameSettings_threat(id)
	if not(DaHud.db.profile.colors.other) then
		DaHud.db.profile.colors.other = {}
	end
	
	if not(DaHud.db.profile.colors.other.threat) then
		DaHud.db.profile.colors.other.threat = {1, 0, 0.25}
	end
end

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions_threat()
	if not(DaHud.options.args.general.args.colors.args.other) then
		DaHud.options.args.general.args.colors.args.other ={
			name = L["Other"],
			type= "group",
			order = 6,
			args = {
			},
		}
	end
	
	local path = DaHud.options.args.general.args.colors.args
	DaHud:AddColorOption(path, L["Threat"], 1, "other", "threat")
end

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_threat(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Bars[id]
	
	local settings = DaHud.db.profile.bars[id]
	
	if (settings.type ~= "threat") then return end
	
	if settings.unit == "player" then
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
	end
	
	f:RegisterEvent("PLAYER_TARGET_CHANGED")
	
	Threat.RegisterCallback(self, "ThreatUpdated", "Update_threat", f)
end

--- ========================================================= ---
---  Update Threat
--- ========================================================= ---
function mod:Update_threat(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.bars[id]
	
	local r, g, b = unpack(DaHud.db.profile.colors.other.threat)

	local current = Threat:GetThreat(UnitGUID("player"), UnitGUID("target"))
	local max =  Threat:GetMaxThreatOnTarget(UnitGUID("target"))

	if not(max) or max == 0 then
		current = 0
		max = 1
	else
		current = current/max
	end
	
	f.Background:SetVertexColor(r, g, b, 0.4)
	f.Bar:SetVertexColor(r, g, b, 1)
	f.StatusBar:SetStatusBarColor(r, g, b, 1)
	
	if not(settings.animate) then
		f.currentValue = current
		f.targetValue = current
	else
		f.targetValue = current

		if f.currentValue ~= f.targetValue then
			f.animationEndTime = GetTime() + 0.5
			f.animating = true
		end
	end
	
	if Threat:IsActive() and UnitName("target") and UnitCanAttack("player", "target") then
	    f:SetAlpha(1)
	elseif not(DaHud:InConfigMode()) then
	    f:SetAlpha(0)
	end
end