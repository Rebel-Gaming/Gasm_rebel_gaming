--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")
local mod = DaHud:GetModule("Bars", true)

if not(mod) then return end

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

--- ========================================================= ---
---  API
--- ========================================================= ---
DaHud.Bars.Plugins.health = L["Health"]

DaHud.Bars.Type.player.health = L["Health"]
DaHud.Bars.Type.pet.health = L["Health"]
DaHud.Bars.Type.pettarget.health = L["Health"]
DaHud.Bars.Type.target.health = L["Health"]
DaHud.Bars.Type.targettarget.health = L["Health"]
DaHud.Bars.Type.targettargettarget.health = L["Health"]
DaHud.Bars.Type.focus.health = L["Health"]
DaHud.Bars.Type.focustarget.health = L["Health"]
DaHud.Bars.Type.party1.health = L["Health"]
DaHud.Bars.Type.party1pet.health = L["Health"]
DaHud.Bars.Type.party1target.health = L["Health"]
DaHud.Bars.Type.party2.health = L["Health"]
DaHud.Bars.Type.party2pet.health = L["Health"]
DaHud.Bars.Type.party2target.health = L["Health"]
DaHud.Bars.Type.party3.health = L["Health"]
DaHud.Bars.Type.party3pet.health = L["Health"]
DaHud.Bars.Type.party3target.health = L["Health"]
DaHud.Bars.Type.party4.health = L["Health"]
DaHud.Bars.Type.party4pet.health = L["Health"]
DaHud.Bars.Type.party4target.health = L["Health"]

--- ========================================================= ---
---  Create Frame Settings
--- ========================================================= ---
function mod:CreateFrameSettings_health(id)
	if not(DaHud.db.profile.colors.unit) then
		DaHud.db.profile.colors.unit = {}
	end

	if not(DaHud.db.profile.colors.unit.unknown) then
		DaHud.db.profile.colors.unit.unknown = {0.8, 0.8, 0.8}
	end
	if not(DaHud.db.profile.colors.unit.hostile) then
		DaHud.db.profile.colors.unit.hostile = {1, 0, 0.25}
	end
	if not(DaHud.db.profile.colors.unit.neutral) then
		DaHud.db.profile.colors.unit.neutral = {1, 1, 0.2}
	end
	if not(DaHud.db.profile.colors.unit.friendly) then
		DaHud.db.profile.colors.unit.friendly = {0.25, 0.75, 0.25}
	end
	if not(DaHud.db.profile.colors.unit.civilian) then
		DaHud.db.profile.colors.unit.civilian = {0.25, 0.5, 0.75}
	end
	if not(DaHud.db.profile.colors.unit.tapped) then
		DaHud.db.profile.colors.unit.tapped = {0.5, 0.5, 0.5}
	end
	if not(DaHud.db.profile.colors.unit.dead) then
		DaHud.db.profile.colors.unit.dead = {0.75, 0.75, 0.75}
	end
	if not(DaHud.db.profile.colors.unit.disconnected) then
		DaHud.db.profile.colors.unit.disconnected = {0.9, 0.9, 0.9}
	end
	if not(DaHud.db.profile.colors.unit.inCombat) then
		DaHud.db.profile.colors.unit.inCombat = {1, 0, 0.25}
	end
	
	if not(DaHud.db.profile.colors.pet) then
		DaHud.db.profile.colors.pet = {}
	end
	
	if not(DaHud.db.profile.colors.pet.happy) then
		DaHud.db.profile.colors.pet.happy = {0.25, 0.75, 0.25}
	end
	if not(DaHud.db.profile.colors.pet.neutral) then
		DaHud.db.profile.colors.pet.neutral = {1, 1, 0.2}
	end
	if not(DaHud.db.profile.colors.pet.angry) then
		DaHud.db.profile.colors.pet.angry = {1, 0, 0.25}
	end
	
	if not(DaHud.db.profile.colors.health) then
		DaHud.db.profile.colors.health = {}
	end
	
	if not(DaHud.db.profile.colors.health.low) then
		DaHud.db.profile.colors.health.low = {1, 0, 0.25}
	end
	if not(DaHud.db.profile.colors.health.half) then
		DaHud.db.profile.colors.health.half = {1, 1, 0.2}
	end
	if not(DaHud.db.profile.colors.health.full) then
		DaHud.db.profile.colors.health.full = {0.25, 0.75, 0.25}
	end
end

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function mod:CreateFrameOptions_health(name)
	if not(DaHud.options.args.general.args.colors.args.unit) then
		DaHud.options.args.general.args.colors.args.unit ={
			name = L["Unit"],
			type= "group",
			order = 1,
			args = {
			},
		}
	end
	
	if not(DaHud.options.args.general.args.colors.args.pet) then
		DaHud.options.args.general.args.colors.args.pet ={
			name = L["Pet"],
			type= "group",
			order = 2,
			args = {
			},
		}
	end

	if not(DaHud.options.args.general.args.colors.args.health) then
		DaHud.options.args.general.args.colors.args.health ={
			name = L["Health"],
			type= "group",
			order = 3,
			args = {
			},
		}
	end
	
	local path = DaHud.options.args.general.args.colors.args
	DaHud:AddColorOption(path, L["Unknown"], 1, "unit", "unknown")
	DaHud:AddColorOption(path, L["Hostile"], 2, "unit", "hostile")
	DaHud:AddColorOption(path, L["Neutral"], 3, "unit", "neutral")
	DaHud:AddColorOption(path, L["Friendly"], 4, "unit", "friendly")
	DaHud:AddColorOption(path, L["Civilian"], 5, "unit", "civilian")
	DaHud:AddColorOption(path, L["Tapped"], 6, "unit", "tapped")
	DaHud:AddColorOption(path, L["Dead"], 7, "unit", "dead")
	DaHud:AddColorOption(path, L["Disconnected"], 8, "unit", "disconnected")
	DaHud:AddColorOption(path, L["In Combat"], 9, "unit", "inCombat")
	
	DaHud:AddColorOption(path, L["Happy"], 1, "pet", "happy")
	DaHud:AddColorOption(path, L["Neutral"], 2, "pet", "neutral")
	DaHud:AddColorOption(path, L["Angry"], 3, "pet", "angry")
	
	DaHud:AddColorOption(path, L["Low Health"], 1, "health", "low")
	DaHud:AddColorOption(path, L["Half Health"], 2, "health", "half")
	DaHud:AddColorOption(path, L["Full Health"], 3, "health", "full")
	
	DaHud.options.args.Bars.args[name].args.UnitType.args.HealthMisc = {
		name = L["Misc"],
		type = "group",
		inline = true,
		order = 3,
		hidden = function(info) 
			if DaHud.db.profile.bars[name].type ~= "health" then
				return true
			else
				return false
			end
		end,
		args = {
			Group1 = {
				name = "",
				type = "group",
				order = 1,
				args = {
					colorByClass = {
						name = L["Color by Class"],
						type = "toggle",
						order = 1,
						hidden = function(info) 
							return (DaHud.db.profile.bars[name].type ~= "health") 
						end,	
						get = function(info) 
							return DaHud.db.profile.bars[info[#info-4]][info[#info]]
						end,
						set = function(info, value) 
							DaHud.db.profile.bars[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
					colorByHostility = {
						name = L["Color by Hostility"],
						type = "toggle",
						order = 2,
						hidden = function(info) 
							return (DaHud.db.profile.bars[name].type ~= "health") 
						end,	
						get = function(info) 
							return DaHud.db.profile.bars[info[#info-4]][info[#info]]
						end,
						set = function(info, value) 
							DaHud.db.profile.bars[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
					colorByPetHappiness = {
						name = L["Color by Pet Happiness"],
						type = "toggle",
						order = 2,
						hidden = function(info)
							if DaHud.db.profile.bars[name].type == "health" then
								if DaHud.db.profile.bars[name].unit == "pet" then
									return false
								else
									return true
								end
							else
								return true
							end
						end,
						get = function(info) 
							return DaHud.db.profile.bars[info[#info-4]][info[#info]]
						end,
						set = function(info, value) 
							DaHud.db.profile.bars[info[#info-4]][info[#info]] = value
							DaHud:RefreshFrame(mod, info[#info-4])
						end,
					},
				},
			},
		},
	}
end

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function mod:RegisterFrameEvents_health(id)
	if not(id) then return end

	local f = DaHud.Frames.Bars[id]
	
	local settings = DaHud.db.profile.bars[id]
	
	if (settings.type ~= "health") then return end

	if settings.unit == "player" then
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
		f:RegisterEvent("UNIT_HEALTH")
		f:RegisterEvent("UNIT_MAXHEALTH")
	elseif settings.unit == "pet" or settings.unit == "party1pet" or settings.unit == "party2pet" or settings.unit == "party3pet" or settings.unit == "party4pet" then
	    f:RegisterEvent("UNIT_PET")
		f:RegisterEvent("UNIT_HEALTH")
		f:RegisterEvent("UNIT_MAXHEALTH")
	elseif settings.unit == "target" then
		f:RegisterEvent("PLAYER_TARGET_CHANGED")
		f:RegisterEvent("UNIT_HEALTH")
		f:RegisterEvent("UNIT_MAXHEALTH")
	elseif settings.unit == "focus" then
		f:RegisterEvent("PLAYER_FOCUS_CHANGED")
		f:RegisterEvent("UNIT_HEALTH")
		f:RegisterEvent("UNIT_MAXHEALTH")
	elseif settings.unit == "party1" or settings.unit == "party2" or settings.unit == "party3" or settings.unit == "party4" then
		f:RegisterEvent("PARTY_MEMBERS_CHANGED")
		f:RegisterEvent("UNIT_HEALTH")
		f:RegisterEvent("UNIT_MAXHEALTH")
	else
		DaHud:RegisterUpdate(self, "UpdateUneventedUnit_health", id, id)
	end
end

--- ========================================================= ---
---  Update Unevented Unit
--- ========================================================= ---
function mod:UpdateUneventedUnit_health(id)
	if not(id) then return end
	
	local f = DaHud.Frames.Bars[id]
	
	DaHud:UpdateFrame(mod, f)
end

--- ========================================================= ---
---  Update Health
--- ========================================================= ---
function mod:Update_health(f)
	if not(f) then return end

	local id = string.gsub(f:GetName(), "DaHud_", "")
	local settings = DaHud.db.profile.bars[id]

	local current, max = UnitHealth(settings.unit), UnitHealthMax(settings.unit)
		
	if max > 0 then
		current = current / max
	else
		current = 0
	end

	local r, g, b = unpack(DaHud.db.profile.colors.health.full)
	local _, class = UnitClass(settings.unit)
	local rc = _G.RAID_CLASS_COLORS[class]
	
	if settings.colorByHostility then
		if UnitIsPlayer(settings.unit) or UnitPlayerControlled(settings.unit) then
			if UnitCanAttack(settings.unit, "player") then
				if UnitCanAttack("player", settings.unit) then
					r, g, b = unpack(DaHud.db.profile.colors.unit.hostile)
				else
					r, g, b = unpack(DaHud.db.profile.colors.unit.civilian)
				end
			elseif UnitCanAttack("player", settings.unit) then
				r, g, b = unpack(DaHud.db.profile.colors.unit.neutral)
			elseif UnitIsPVP(settings.unit) then
				if rc and settings.colorByClass then
				    r, g, b = rc.r, rc.g, rc.b
				else
					r, g, b = unpack(DaHud.db.profile.colors.unit.friendly)
				end
			else
				r, g, b = unpack(DaHud.db.profile.colors.unit.civilian)
			end
		elseif (UnitIsTapped(settings.unit) and not UnitIsTappedByPlayer(settings.unit)) or UnitIsDead(settings.unit) then
			r, g, b = unpack(DaHud.db.profile.colors.unit.tapped)
		else
			local reaction = UnitReaction(settings.unit, "player")
			if reaction then
				if reaction >= 5 then
					if rc and settings.colorByClass then
					    r, g, b = rc.r, rc.g, rc.b
					else
						r, g, b = unpack(DaHud.db.profile.colors.unit.friendly)
					end
				elseif reaction == 4 then
					r, g, b = unpack(DaHud.db.profile.colors.unit.neutral)
				else
					r, g, b = unpack(DaHud.db.profile.colors.unit.hostile)
				end
			else
				r, g, b = unpack(DaHud.db.profile.colors.unit.unknown)
			end
		end
	elseif settings.colorByClass then
		if rc then
			r, g, b = rc.r, rc.g, rc.b
		else
			r, g, b = unpack(DaHud.db.profile.colors.unit.unknown)
		end
	elseif settings.colorByPetHappiness and (settings.unit == "pet") then
		local _, class = UnitClass("player")
		if (class == "HUNTER") then
			local happy = GetPetHappiness()
			if happy == 3 then
				r, g, b = unpack(DaHud.db.profile.colors.pet.happy)
			elseif happy == 2 then
				r, g, b = unpack(DaHud.db.profile.colors.pet.neutral)
			elseif happy == 1 then
				r, g, b = unpack(DaHud.db.profile.colors.pet.angry)
			end
		end
	else
		if UnitExists(settings.unit) then
			if (UnitIsTapped(settings.unit) and not UnitIsTappedByPlayer(settings.unit)) or UnitIsDead(settings.unit) then
				r, g, b = unpack(DaHud.db.profile.colors.unit.tapped)
			else
				local perc = UnitHealth(settings.unit) / UnitHealthMax(settings.unit)
				local r1, g1, b1
				local r2, g2, b2
				if perc <= 0.5 then
					perc = perc * 2
					r1, g1, b1 = unpack(DaHud.db.profile.colors.health.low)
					r2, g2, b2 = unpack(DaHud.db.profile.colors.health.half)
				else
					perc = perc * 2 - 1
					r1, g1, b1 = unpack(DaHud.db.profile.colors.health.half)
					r2, g2, b2 = unpack(DaHud.db.profile.colors.health.full)
				end
				
				r, g, b =  r1 + (r2-r1)*perc, g1 + (g2-g1)*perc, b1 + (b2-b1)*perc
			end
		else
			r, g, b = unpack(DaHud.db.profile.colors.health.full)
		end
	end
	
	f.Background:SetVertexColor(r, g, b, 0.4)
	f.Bar:SetVertexColor(r, g, b, 1)
	f.StatusBar:SetStatusBarColor(r, g, b, 1)
	
	if not(settings.animate) then
		f.currentValue = current
		f.targetValue = current
	else
		f.targetValue = current

		if f.currentValue ~= f.targetValue then
			f.animationEndTime = GetTime() + 0.5
			f.animating = true
		end
	end
end
