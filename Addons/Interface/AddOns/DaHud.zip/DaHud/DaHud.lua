--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local DaHud = LibStub("AceAddon-3.0"):NewAddon("DaHud", "AceTimer-3.0", "AceEvent-3.0", "AceConsole-3.0")

local AceDB = LibStub("AceDB-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local SM = LibStub("LibSharedMedia-3.0")

local _G = getfenv(0)

DaHud.Frames = {}
DaHud.Style = {}
DaHud.objectsToUpdate = {}

DaHud.Alpha = 1
DaHud.inCombat = nil
DaHud.LoggedIn = nil

--- ========================================================= ---
---  Setup Revision, Version, Date and add to AceLibrary
--- ========================================================= ---
local VERSION = tonumber(("$Revision: 71116 $"):match("%d+"))
DaHud.version = "r" .. VERSION
DaHud.date = ("$Date: 2008-04-23 15:21:47 -0400 (Wed, 23 Apr 2008) $"):match("%d%d%d%d%-%d%d%-%d%d")

--- ========================================================= ---
---  Local Functions
--- ========================================================= ---
local function tblCopy(src, dest)
	for k,v in pairs(src) do
		if type(v) == "table" then
			if not (type(dest[k]) == "table") then
				dest[k] = {}
			end
			tblCopy(v, dest[k])
		else
			dest[k] = v
		end
	end
end

DaHud.tblCopy = tblCopy

--- ========================================================= ---
---  Debug
--- ========================================================= ---
DaHud.debugFrame = ChatFrame1
function DaHud:Debug(...)
	if self.debugging then
		DaHud:Print(DaHud.debugFrame, "DEBUG - ", ...)
	end
end

--- ========================================================= ---
---  Setup Database
--- ========================================================= ---
local defaultVars = {
	profile = {
		general = {
			config = false,
			debug = false,
		},
		alpha = {
			combat = 1,
			ooc = 0.50,
			regen = 0.75,
			target = 0.75,
			casting = 0.75,
		},
		colors = {
		},
		frame = {
			posx = 0, 
			posy = 0,
			scale = 1,
		},
		modulesDisabled = {
			DaHud_Portraits = true,
		},
	},
}

--- ========================================================= ---
---  System
--- ========================================================= ---
function DaHud:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("DaHudDB", defaultVars, "Default")
	
	self.debugFrame = DaHud.debugFrame
	self.debugging = self.db.profile.general.debug

	DaHud:CreateParentFrame()
end

function DaHud:OnEnable()
	DaHud:RegisterEvents()
	DaHud:Config()
	
	if not DaHud.db.profile.welcomeMessaged then
		self:Print("Welcome to DaHud! Type /dahud to configure.")
		DaHud.db.profile.welcomeMessaged = true
	end

	DaHud.inCombat = InCombatLockdown()
	
	if type(DaHud.Setup_HideBlizzardFrames) == "function" then
		DaHud:Setup_HideBlizzardFrames()
	end
	
	DaHud:SetConfigMode()
	DaHud:UpdateParentFrame()
	DaHud:UpdateParentAlpha()
end

--- ========================================================= ---
---  Module System
--- ========================================================= ---
local modPrototype = {}

function modPrototype:OnInitialize()
	if self.OnRegister then
		self:OnRegister()
	end
	if DaHud.db.profile.modulesDisabled[self.name] then
		self.enabledState = false
	end
end

modPrototype.ScheduleTimer = DaHud.ScheduleTimer

function modPrototype:RegisterDefaults(defaults)
	tblCopy(defaults, defaultVars.profile)
	DaHud.db = LibStub("AceDB-3.0"):New("DaHudDB", defaultVars)
end

DaHud:SetDefaultModulePrototype(modPrototype)

--- ========================================================= ---
---  Register Events
--- ========================================================= ---
function DaHud:RegisterEvents()
	self.db.RegisterCallback(self, "OnNewProfile", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
	
	self:RegisterEvent("PLAYER_LOGIN", "Handle_PlayerLogin")
	self:RegisterEvent("PLAYER_REGEN_DISABLED", "Handle_PlayerRegenDisabled")
	self:RegisterEvent("PLAYER_REGEN_ENABLED", "Handle_PlayerRegenEnabled")
	
	self:RegisterEvent("PLAYER_TARGET_CHANGED", "UpdateParentAlpha")
	
	self:RegisterEvent("UNIT_HEALTH", "Handle_UpdateParentAlpha")
	self:RegisterEvent("UNIT_MANA", "Handle_UpdateParentAlpha")
	self:RegisterEvent("UNIT_ENERGY", "Handle_UpdateParentAlpha")
	self:RegisterEvent("UNIT_RAGE", "Handle_UpdateParentAlpha")
	
    self:RegisterEvent("UNIT_SPELLCAST_START", "Handle_UpdateParentAlpha")
    self:RegisterEvent("UNIT_SPELLCAST_STOP", "Handle_UpdateParentAlpha")
    self:RegisterEvent("UNIT_SPELLCAST_FAILED", "Handle_UpdateParentAlpha")
    self:RegisterEvent("UNIT_SPELLCAST_DELAYED", "Handle_UpdateParentAlpha")
    self:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED", "Handle_UpdateParentAlpha")
    self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START", "Handle_UpdateParentAlpha")
    self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE", "Handle_UpdateParentAlpha")
    self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP", "Handle_UpdateParentAlpha")
	self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_INTERRUPTED", "Handle_UpdateParentAlpha")
	
	self:ScheduleRepeatingTimer("ProcessUpdate", 0.15 )
end

--- ========================================================= ---
---  On Profile Changed
--- ========================================================= ---
function DaHud:OnProfileChanged()
	DaHud:Debug("Profile Changed")
	
	self.debugging = self.db.profile.general.debug
	
	for k, v in self:IterateModules() do
		if DaHud.db.profile.modulesDisabled[v.name] then
			v:Disable()
		else
			v:Disable()
			v:Enable()
		end
		
		if type(v.ProfileChanged) == "function" then
			v:ProfileChanged(value)                  
		end
	end
	
	if type(DaHud.Setup_HideBlizzardFrames) == "function" then
		DaHud:Setup_HideBlizzardFrames()
	end
	
	DaHud:SetConfigMode()
	DaHud:UpdateParentFrame()
	DaHud:UpdateParentAlpha()
end

--- ========================================================= ---
---  Player Login
--- ========================================================= ---
function DaHud:Handle_PlayerLogin()
	DaHud.LoggedIn = true
	DaHud:SendMessage("DaHud_PlayerLogin")
end

--- ========================================================= ---
---  Player Regen Disabled
--- ========================================================= ---
function DaHud:Handle_PlayerRegenDisabled()
	DaHud.inCombat = true
	
	DaHud:UpdateParentAlpha()
end

--- ========================================================= ---
---  Player Regen Enabled
--- ========================================================= ---
function DaHud:Handle_PlayerRegenEnabled()
	DaHud.inCombat = nil
	
	DaHud:UpdateParentAlpha()
end

--- ========================================================= ---
---  Handle Update Alpha
--- ========================================================= ---
function DaHud:Handle_UpdateParentAlpha(event, unit)
	if unit ~= "player" then return end

	DaHud:UpdateParentAlpha()
end

--- ========================================================= ---
---  In Config Mode
--- ========================================================= ---
function DaHud:InConfigMode()
	return self.db.profile.general.config
end

--- ========================================================= ---
---  Get Alpha
--- ========================================================= ---
function DaHud:GetAlpha()
	return DaHud.Alpha
end