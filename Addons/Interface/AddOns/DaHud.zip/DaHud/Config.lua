--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local options = {}
local moduleOptions = {}

options.name = "DaHud"
options.type = "group"
options.icon = ""
options.args = {}
options.plugins = {}

local unitOptionsTable

--- ========================================================= ---
---  Local Functions
--- ========================================================= ---

local FAQ_TEXT = [[
|cFFFFFFFF
How do I change Styles?
In General, in the Style Dropdown you can select any preset style thats plugged in.
|r
How do I change the Alpha Settings?
In General, there is a Alpha Settings option.  Click it and you are able to change any Alpha Setting available.
|r
How do I change the Colors?
In General, there is a Colors option.  Click it and you are able to change any Colors Available.
|r
How do I Hide Blizzard Frames?
In General, there is a Hide Blizzard Frames option.  Click it and you are able to Show/Hide any Blizzard Frame available.
|r
How do I Enable/Disable Modules?
In Modules, it will list any Modules currently plugged in.  Check to Enable the Module, or Uncheck to Disable the Module.
|r
How do I put the addon into Config Mode?
In General, there is an Configuration Mode button.  Check to put into Config Mode, or Uncheck to take out of Config Mode.  When in Config Mode, everything will be visible so you can customize easier.
|r
What is Profiles and how can I change which it it uses?
In Profiles, you can find the available options for Profiles.
|r
|cffffff78---MODULES---|r
|cffffff78--------------------|r
|r
|cffffff78---Bars---|r
|cFFFFFFFF
How do I Create a New Bar?
In Bars, there is a button to click to create a New Bar.  The newly created bar will have default settings, so be sure to customize it afterwards.
|r
How do I Delete a Bar?
In Bars, Click the Bar for its options.  In the Frame Attributes Tab, there is a button to Delete the bar.
|r
How do I change the Frame Attributes for the Bar?
In Bars, Click the Bar for its options.  In the Frame Attributes Tab, there is a lot of options available for you to change.  You can change the FrameStrata/FrameLevel, Anchor, Positition, and Size here.
|r
How do I change the Appearance for the Bar?
In Bars, Click the Bar for its options.  In the Appearance Tab, there is a lot of options available for you to change.  You can change what if its a vertical or horizontal bar, and any of its textures you wish it to use.  You can also change whether or not the bar animates, has a casting bar, is interactive, and whether to hide when in raid here.
|r
How do I change the Unit/Type for the Bar?
In Bars, Click the Bar for its options.  In the Unit & Type Tab, there is a lot of options available for you to change.  You can change what Unit and Type it should be tracking, as well as available options for that Type here.
|r
|cffffff78---Buffs---|r
|cFFFFFFFF
How do I Create a New Buff?
In Buffs, there is a button to click to create a New Buff.  The newly created buff will have default settings, so be sure to customize it afterwards.
|r
How do I Delete a Buff?
In Buffs, Click the Buff for its options.  In the Frame Attributes Tab, there is a button to Delete the buff.
|r
How do I change the Frame Attributes for the Buff?
In Buffs, Click the Buff for its options.  In the Frame Attributes Tab, there is a lot of options available for you to change.  You can change the FrameStrata/FrameLevel, Anchor, Positition, and Size here.
|r
How do I change the Appearance for the Buff?
In Buffs, Click the Buff for its options.  In the Appearance Tab, there is a lot of options available for you to change.  You can change what direction the buffs go, max aura's to show, how many columns, spacing between each buff, when to show tooltips, and whether to hide when in raid here.
.  You can also have it filter buffs/debuffs than you can cast/cure as well as Enlarge your own self buffs/debuffs.
|r
How do I change the Unit/Type for the Buff?
In Buffs, Click the Buff for its options.  In the Unit & Type Tab, there is a lot of options available for you to change.  You can change what Unit and Type it should be tracking, as well as available options for that Type here.
|r
|cffffff78---Icons---|r
|cFFFFFFFF
How do I Create a New Icon?
In Icons, there is a button to click to create a New Icon.  The newly created icon will have default settings, so be sure to customize it afterwards.
|r
How do I Delete a Icon?
In Icons, Click the Icon for its options.  In the Frame Attributes Tab, there is a button to Delete the icon.
|r
How do I change the Frame Attributes for the Icon?
In Icons, Click the Icon for its options.  In the Frame Attributes Tab, there is a lot of options available for you to change.  You can change the FrameStrata/FrameLevel, Anchor, Positition, and Size here.
|r
How do I change the Appearance for the Icon?
In Icons, Click the Icon for its options.  In the Appearance Tab, you can choose whether or not to hide when in raid.
|r
How do I change the Unit/Type for the Icon?
In Icons, Click the Icon for its options.  In the Unit & Type Tab, there is a lot of options available for you to change.  You can change what Unit and Type it should be tracking, as well as available options for that Type here.
|r
|cffffff78---Portraits---|r
|cFFFFFFFF
How do I Create a New Portrait?
In Portraits, there is a button to click to create a New Portrait.  The newly created portrait will have default settings, so be sure to customize it afterwards.
|r
How do I Delete a Portrait?
In Portraits, Click the Portrait for its options.  In the Frame Attributes Tab, there is a button to Delete the portrait.
|r
How do I change the Frame Attributes for the Portrait?
In Portraits, Click the Portrait for its options.  In the Frame Attributes Tab, there is a lot of options available for you to change.  You can change the FrameStrata/FrameLevel, Anchor, Positition, and Size here.
|r
How do I change the Appearance for the Portrait?
In Portraits, Click the Portrait for its options.  In the Appearance Tab, there is a lot of options available for you to change.  You can change what style to use (2D, 3D, or Class Icon.  You can also change the texture to use for the background and border for the portrait, and whether or not to hide when in raid
|r
How do I change the Unit/Type for the Portrait?
In Portraits, Click the Portrait for its options.  In the Unit & Type Tab, there is a lot of options available for you to change.  You can change what Unit and Type it should be tracking, as well as available options for that Type here.
|r
|cffffff78---Texts---|r
|cFFFFFFFF
How do I Create a New Text?
In Texts, there is a button to click to create a New Text.  The newly created text will have default settings, so be sure to customize it afterwards.
|r
How do I Delete a Text?
In Texts, Click the Text for its options.  In the Frame Attributes Tab, there is a button to Delete the text.
|r
How do I change the Frame Attributes for the Text?
In Texts, Click the Text for its options.  In the Frame Attributes Tab, there is a lot of options available for you to change.  You can change the FrameStrata/FrameLevel, Anchor, Positition, and Size here.
|r
How do I change the Appearance for the Text?
In Texts, Click the Text for its options.  In the Appearance Tab, there is a lot of options available for you to change.  You can change what font, font size, and alignment you want the text to use.  You can also choose whether to hide when in raid here.
|r
How do I change the Unit/Type for the Text?
In Texts, Click the Text for its options.  In the Unit & Type Tab, there is a lot of options available for you to change.  You can change what Unit and Type it should be tracking, as well as available options for that Type here.
|r
|cffffff78---ADDON---|r
|cffffff78--------------------|r
|cFFFFFFFF
What the heck is Debug and what does it do?
|r
Debug is used for me to debug the addon in case bugs arise.  It is not recommended to be enabled as it will spam your chatframe with all sorts of messages.
|cFFFFFFFF
Who wrote this addon?
|r
Benumbed
]]

--- ========================================================= ---
---  Config
--- ========================================================= ---
function DaHud:Config()
	options.args.profile = LibStub("AceDBOptions-3.0"):GetOptionsTable(DaHud.db)
	self.options = options
	
	DaHud:PopulateOptions()
	
	LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("DaHud", options)
	self:RegisterChatCommand(L["dahud"], function() LibStub("AceConfigDialog-3.0"):Open("DaHud") end )
end

--- ========================================================= ---
---  Setup Options
--- ========================================================= ---
options.args.FAQ = {
	name = L["FAQ"],
	desc = L["Frequently Asked Questions"],
	type = "group",
	order = -1,
	args = {
		header = {
			name = L["Frequently Asked Questions"],
			type = "header",
			order = 0,
		},
		desc = {
			type = "description",
			name = L[FAQ_TEXT],
			order = 1,
		},
	},
}

options.args.general = {
	name = L["General"],
	type = "group",
	order = 1,
	args = {
		style = {
			name = L["Style"],
			type= "group",
			order = 1,
			inline = true,
			args = {
				unit = {
					name = L["Style"],
					type = "select",
					order = 1,
					values = function(info, value)
						return DaHud.Style
					end,
					get = function(info) 
						return
					end,
					set = function(info, value)
						DaHud:SetStyle(value)
					end,
				},
			},
		},
		general = {
			name = L["General Options"],
			type= "group",
			order = -1,
			inline = true,
			args = {
				config = {
					name = L["Configuration Mode"],
					desc = L["Toggles the addons configuration mode."],
					type = "toggle",
					order = 1,
					get = function(info) 
						return DaHud.db.profile.general[info[#info]] 
					end,
					set = function(info, value)
						DaHud.db.profile.general[info[#info]] = value
						DaHud:SetConfigMode()
					end,

				},
				debug = {
					name = L["Debug"],
					desc = L["Prints debug messages to the chatframe."],
					type = "toggle",
					order = 2,
					get = function(info) 
						return DaHud.db.profile.general[info[#info]] 
					end,
					set = function(info, value)
						DaHud.db.profile.general[info[#info]] = value
						DaHud.debugging = DaHud.db.profile.general.debug
					end,
				},
			},
		},

		alpha = {
			name = L["Alpha Settings"],
			type= "group",
			order = 1,
			args = {
				alpha = {
					name = L["Alpha Settings"],
					type= "group",
					order = 1,
					inline = true,
					get = function(info) 
						return DaHud.db.profile.alpha[info[#info]]
					end,
					set = function(info, value)
						DaHud.db.profile.alpha[info[#info]] = value
						DaHud:UpdateParentAlpha()
					end,
					args = {
						combat = {
							name = L["Combat"],
							type = "range",
							min = 0,
							max = 1,
							step = 0.01,
						},
						ooc = {
							name = L["Out of Combat"],
							type = "range",
							min = 0,
							max = 1,
							step = 0.01,
						},
						target = {
							name = L["Have target"],
							type = "range",
							min = 0,
							max = 1,
							step = 0.01,
						},
						regen = {
							name = L["Regenerating"],
							type = "range",
							min = 0,
							max = 1,
							step = 0.01,
						},
						casting = {
							name = L["Casting"],
							type = "range",
							min = 0,
							max = 1,
							step = 0.01,
						},
					},
				},
			},
		},
		colors = {
			name = L["Colors"],
			type= "group",
			order = 1,
			childGroups = "tab",
			args = {
				Header = {
					name = L["Colors"],
					type = "header",
					order = 1,
				},
			},
		},
		frame = {
			name = L["Frame Settings"],
			type= "group",
			order = 1,
			args = {
				scale = {
					name = L["Scale"],
					type= "group",
					order = 1,
					inline = true,
					get = function(info) 
						return DaHud.db.profile.frame[info[#info]]
					end,
					set = function(info, value)
						DaHud.db.profile.frame[info[#info]] = value
						DaHud:UpdateFrame()
					end,
					args = {
						scale = {
							name = L["Scale"],
							type = "range",
							min = -2,
							max = 2,
							step = 0.1,
						},
					},
				},
			},
		},
	},
}

options.args.Modules = {
	name = L["Modules"],
	type = "group",
	order = 100,
	args = {}
}

--- ========================================================= ---
---  Add Color Option
--- ========================================================= ---
function DaHud:AddColorOption(path, title, num, group, key)
	path[group].args[key] = {
		name = title,
		type = "color",
		order = num,
		get = function() return unpack( DaHud.db.profile.colors[group][key] ) end,
		set = function( info, r, g, b ) DaHud.db.profile.colors[group][key] = { r, g, b } end,
	}
end

--- ========================================================= ---
---  Add Color Options
--- ========================================================= ---
function DaHud:AddColorOptions()
	local path = options.args.general.args.colors.args
end

--- ========================================================= ---
---  Populate Units
--- ========================================================= ---
function DaHud:PopulateOptions()
	local path = options.args.Modules
	local values = {}
	
	path.args.EnabledModules = {
		name = L["Enabled Modules"],
		desc = L["Enable or disable this module"],
		type = "multiselect",
		get = function(info, modname)
            local module = DaHud.modules[modname]
			return module.enabledState
		end,
		set = function(info, modname)
			local module = DaHud.modules[modname]
			if module.enabledState then
                DaHud.db.profile.modulesDisabled[module.name] = true
				module:Disable()
			else
                DaHud.db.profile.modulesDisabled[module.name] = false
				module:Enable()
			end
		end,
	}
	
	for k,v in pairs(DaHud.modules) do
		values[k] = k
	end
	path.args.EnabledModules.values = values

	for k, v in pairs(DaHud.modules) do
		local name = string.gsub(v.name, "DaHud_", "")
		if not moduleOptions[name] then
			moduleOptions[name] = DaHud:RegisterOptions(v, name)
		end
		local tbl = moduleOptions[name]
		options.args[name] = {}
		options.args[name] = tbl
	end
	
	DaHud:AddColorOptions()
end