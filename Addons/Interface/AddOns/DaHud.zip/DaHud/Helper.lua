--- ========================================================= ---
---  Setup Locals
--- ========================================================= ---
local L = LibStub("AceLocale-3.0"):GetLocale("DaHud", true)
local DaHud = LibStub("AceAddon-3.0"):GetAddon("DaHud")

local localeTables = {}
function DaHud:L(name)
	if not localeTables[name] then
		localeTables[name] = setmetatable({}, {__index = function(self, key)
			self[key] = key
			return key
		end})
	end
	return localeTables[name]
end

local L = DaHud:L("DaHud")

local del, new = DaHud.del, DaHud.new
local newFrame, delFrame = DaHud.newFrame, DaHud.delFrame

local _G = getfenv(0)

--- ========================================================= ---
---  Local Functions
--- ========================================================= ---
local function DropDownUnit(unit)
	local type = nil

	if unit == "player" then
		type = PlayerFrameDropDown
	elseif unit == "target" then
		type = TargetFrameDropDown
	elseif unit == "pet" then
		type = PetFrameDropDown
	elseif unit == "party1" then
		type = _G["PartyMemberFrame1DropDown"]
	elseif unit == "party2" then
		type = _G["PartyMemberFrame2DropDown"]
	elseif unit == "party3" then
		type = _G["PartyMemberFrame3DropDown"]
	elseif unit == "party4" then
		type = _G["PartyMemberFrame4DropDown"]
	end

	if type then
		HideDropDownMenu(1)
		type.unit = unit
		type.name = UnitName(unit)
		ToggleDropDownMenu(1, nil, type, "cursor")
	end
end

DaHud.DropDownUnit = DropDownUnit

local function GetUnitsSupported()
	local units = {
		player = L["Player"],
		pet = L["Player Pet"], 
		pettarget = L["Player Pet Target"],
		target = L["Target"], 
		targettarget = L["Target of Target"], 
		targettargettarget= L["ToT of Target"],
		focus = L["Focus"], 
		focustarget = L["Focus Target"],
		party1 = L["Party1"], 
		party1pet = L["Party1 Pet"], 
		party1target = L["Party1 Target"],
		party2 = L["Party2"], 
		party2pet = L["Party2 Pet"], 
		party2target = L["Party2 Target"],
		party3 = L["Party3"], 
		party3pet = L["Party3 Pet"], 
		party3target = L["Party3 Target"],
		party4 = L["Party4"], 
		party4pet = L["Party4 Pet"], 
		party4target = L["Party4 Target"],
	}
	
	return units
end

--- ========================================================= ---
---  Enable Module
--- ========================================================= ---
function DaHud:EnableModule(module, frameType, ...)
	if not(module) then return end
	
	DaHud:CreateFrames(module, frameType, ...)
end

--- ========================================================= ---
---  Disable Module
--- ========================================================= ---
function DaHud:DisableModule(module)
	if not(module) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")

	for k, v in pairs(DaHud.Frames[moduleName]) do
		delFrame(DaHud.Frames[moduleName][k])
	
		DaHud.options.args[moduleName].args[k] = nil
	end
end

--- ========================================================= ---
---  Register Options
--- ========================================================= ---
function DaHud:RegisterOptions(module, name)
	if not(module) or not(name) then return end
	
	config = {
		name = L[name],
		type = 'group',
		order = 50, 
		hidden = function() 
			return not(module:IsEnabled())
		end,	
		args = {
			create = {
				name = L[name],
				type = "group",
				inline = true,
				order = 1,
				args = {
					create = {
						name = L["Create"],
						type = "execute",
						order = 1,
						func = function() 
							DaHud:CreateFrame(module) 
						end,
					},
				},
			},
			plugins = {
				name = L["Plugins"],
				desc = L["Enable or disable this plugin"],
				type = "multiselect",
				order = 2,
				hidden = function() 
					if DaHud[name].Plugins then
						return false
					else
						return true
					end
				end,
				values = function()
					if DaHud[name].Plugins then
						return DaHud[name].Plugins
					end
				end,
				get = function(info, plugin)
					return not(DaHud.db.profile[string.lower(name)].pluginsDisabled[plugin])
				end,
				set = function(info, plugin)
					if DaHud.db.profile[string.lower(name)].pluginsDisabled[plugin] then
						DaHud.db.profile[string.lower(name)].pluginsDisabled[plugin] = nil
					else
						DaHud.db.profile[string.lower(name)].pluginsDisabled[plugin] = true
					end
					
					for k, v in pairs(DaHud.Frames[name]) do
						local id = string.gsub(v:GetName(), "DaHud_", "")
						
						if DaHud.db.profile[string.lower(name)].pluginsDisabled[plugin] then
							DaHud:UnregisterFrameEvents(DaHud:GetModule(name), id)
						else
							DaHud:RegisterFrameEvents(DaHud:GetModule(name), id)
						end
						
						DaHud:SetupWatch(module, v, id)
						DaHud:UpdateFrame(module, v)
					end
					
				end,
			},
		},
	}

	return config
end

--- ========================================================= ---
---  Create Frame Settings
--- ========================================================= ---
function DaHud:CreateFrameSettings(module, id, name)
	if not(module) or not(id) or not(name) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	if not(DaHud.db.profile[string.lower(moduleName)][id].active) then
		DaHud.db.profile[string.lower(moduleName)][id].name = id
		DaHud.db.profile[string.lower(moduleName)][id].active = true
	end

	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["CreateFrameSettings_"..k]) == "function" then
				module["CreateFrameSettings_"..k](module, id)
			end
		end
	end
end

--- ========================================================= ---
---  Create Frame Options
--- ========================================================= ---
function DaHud:CreateFrameOptions(module, id, name)
	if not(module) or not(id) or not(name) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	DaHud.options.args[moduleName].args[id] = {
		name = L[name],
		type = "group",
		order = 1,
		hidden = function() 
			if DaHud.db.profile[string.lower(moduleName)].pluginsDisabled[DaHud.db.profile[string.lower(moduleName)][id].type] then
				return true
			else
				return false
			end
		end,
		childGroups = "tab",
		args = {
			Header = {
				name = L[name],
				type = "header",
				order = 1,
			},
			FrameStyle = {
				name = L["Frame Attributes"],
				type = "group",
				order = 1,
                childGroups = "select",
				args = {
					Group1 = {
						name = L["Name"],
						type = "group",
						inline = true,
						order = 1,
						args = {
							name = {
								name = L["Name"],
								type = "input",
								order = 1,
								validate = function(info, value)
									if string.find( value, "[ \(\[\]\)\.\:]" ) then
										return L["Invalid character in name."]
									end
						
									for k, v in pairs(DaHud.db.profile[string.lower(moduleName)]) do
										if v.name == value and value ~= name then 
											return L["This name is already in use."] 
										end
									end
								
									return true
								end,
								get = function(info) 
									return name
								end,
								set = function(info, value) 
									DaHud:RenameFrame(module, info, value) 
								end,
							},
							delete = {
								name = L["Delete"],
								type = "execute",
								order = 2,
								confirm = true,
								confirmText = L["Do you really want to delete this?"],
								func = function(info)
									DaHud:DeleteFrame(module, info)
								end,
							},
						},
					},
					Group2 = {
						name = L["Levels"],
						type = "group",
						inline = true,
						order = 2,
						args = {
							framestrata = {
								name = L["FrameStrata"],
								type = "select",
								order = 1,
								values = {BACKGROUND = L["Background"], LOW = L["Low"], MEDIUM = L["Medium"], HIGH = L["High"], DIALOG = L["Dialog"], TOOLTIP = L["Tooltip"],},
								get = function(info) 
									return DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]]
								end,
								set = function(info, value) 
									DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]] = value
									DaHud:RefreshFrame(module, info[#info-3])
								end,
							},
							framelevel = {
								name = L["FrameLevel"],
								desc = L["Adjust the level of the frame."],
								type = "range",
								order = 2,
								min = 0,
								max = 12,
								step = 1,
								get = function(info) 
									return DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]]
								end,
								set = function(info, value) 
									DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]] = value
									DaHud:RefreshFrame(module, info[#info-3])
								end,
							},
						},
					},
					Group3 = {
						name = L["Anchor"],
						type = "group",
						inline = true,
						order = 3,
						args = {
							Group1 = {
								name = L[""],
								type = "group",
								inline = true,
								order = 1,
								args = {
									anchor = {
										name = L["Anchor"],
										type = "input",
										order = 1,
										get = function(info) 
											return DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]]
										end,
										set = function(info, value) 
											DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]] = value
											DaHud:RefreshFrame(module, info[#info-4])
										end,
									},
								},
							},
							Group2 = {
								name = L[""],
								type = "group",
								inline = true,
								order = 2,
								args = {
									point = {
										name = L["Point"],
										type = "select",
										order = 1,
										values = {TOP = L["TOP"], BOTTOM = L["BOTTOM"], LEFT = L["LEFT"], RIGHT = L["RIGHT"], TOPLEFT = L["TOPLEFT"], TOPRIGHT = L["TOPRIGHT"], BOTTOMLEFT = L["BOTTOMLEFT"], BOTTOMRIGHT = L["BOTTOMRIGHT"], CENTER = L["CENTER"],},
										get = function(info) 
											return DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]]
										end,
										set = function(info, value) 
											DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]] = value
											DaHud:RefreshFrame(module, info[#info-4])
										end,
									},
									relative = {
										name = L["Relative"],
										type = "select",
										order = 2,
										values = {TOP = L["TOP"], BOTTOM = L["BOTTOM"], LEFT = L["LEFT"], RIGHT = L["RIGHT"], TOPLEFT = L["TOPLEFT"], TOPRIGHT = L["TOPRIGHT"], BOTTOMLEFT = L["BOTTOMLEFT"], BOTTOMRIGHT = L["BOTTOMRIGHT"], CENTER = L["CENTER"],},
										get = function(info) 
											return DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]]
										end,
										set = function(info, value) 
											DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]] = value
											DaHud:RefreshFrame(module, info[#info-4])
										end,
									},
								},
							},
						},
					},
					Group4 = {
						name = L["Position"],
						type = "group",
						inline = true,
						order = 4,
						args = {
							posx = {
								name = L["Pos X"],
								type = "range",
								order = 1,
								min = -1000,
								max = 1000,
								step = 1,
								get = function(info) 
									return DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]]
								end,
								set = function(info, value) 
									DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]] = value
									DaHud:RefreshFrame(module, info[#info-3])
								end,
							},
							posy = {
								name = L["Pos Y"],
								type = "range",
								order = 2,
								min = -1000,
								max = 1000,
								step = 1,
								get = function(info) 
									return DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]]
								end,
								set = function(info, value) 
									DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]] = value
									DaHud:RefreshFrame(module, info[#info-3])
								end,
							},
						},
					},
					Group5 = {
						name = L["Size"],
						type = "group",
						order = 5,
						inline = true,
						args = {
							width = {
								name = L["Width"],
								type = "range",
								order = 1,
								min = 10,
								max = 300,
								step = 1,
								get = function(info) 
									return DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]]
								end,
								set = function(info, value) 
									DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]] = value
									DaHud:RefreshFrame(module, info[#info-3])
								end,
							},
							height = {
								name = L["Height"],
								type = "range",
								order = 2,
								min = 10,
								max = 300,
								step = 1,
								get = function(info) 
									return DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]]
								end,
								set = function(info, value) 
									DaHud.db.profile[string.lower(moduleName)][info[#info-3]][info[#info]] = value
									DaHud:RefreshFrame(module, info[#info-3])
								end,
							},
						},
					},
				},
			},
			Appearance = {
				name = L["Appearance"],
				type = "group",
				order = 2,
                childGroups = "select",
				args = {
				},
			},
			UnitType = {
				name = L["Unit & Type"],
				type = "group",
				order = 3,
                childGroups = "select",
				args = {
					Group1 = {
						name = L["Unit"],
						type = "group",
						inline = true,
						order = 1,
						args = {
							Group1 = {
								name = "",
								type = "group",
								order = 1,
								args = {
									unit = {
										name = L["Unit"],
										type = "select",
										order = 1,
										values = function()
											return GetUnitsSupported()
										end,
										get = function(info) 
											return DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]]
										end,
										set = function(info, value)
											DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]] = value
											
											if not(DaHud[moduleName].Type[value][DaHud.db.profile[string.lower(moduleName)][info[#info-4]].type]) then
												DaHud.db.profile[string.lower(moduleName)][info[#info-4]].type = ""
											end
											DaHud:RefreshFrame(module, info[#info-4])
										end,
									},
								},
							},
						},
					},
					Group2 = {
						name = L["Type"],
						type = "group",
						inline = true,
						order = 2,
						args = {
							Group1 = {
								name = "",
								type = "group",
								order = 1,
								args = {
									type = {
										name = L["Type"],
										type = "select",
										order = 1,
										values = function(info)
											local tbl = {}
											for k, v in pairs(DaHud[moduleName].Type[DaHud.db.profile[string.lower(moduleName)][info[#info-4]].unit]) do
												if not(DaHud.db.profile[string.lower(moduleName)].pluginsDisabled[k]) then
													tbl[k] = v
												end
											end
										
											return tbl
										end,
										get = function(info) 
											return DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]]
										end,
										set = function(info, value)
											local oldValue = DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]]
											DaHud.db.profile[string.lower(moduleName)][info[#info-4]][info[#info]] = value
											
											if not(DaHud[moduleName].Type[DaHud.db.profile[string.lower(moduleName)][info[#info-4]].unit][value]) then
												DaHud.db.profile[string.lower(moduleName)][info[#info-4]].unit = "player"
											end
											DaHud:RefreshFrame(module, info[#info-4], oldValue)
										end,
									},
								},
							},
						},
					},
				},
			},
		},
	}
	
	if type(module.CreateFrameOptions) == "function" then
		module.CreateFrameOptions(module, id, name)
	end
	
	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["CreateFrameOptions_"..k]) == "function" then
				module["CreateFrameOptions_"..k](module, id)
			end
		end
	end
end

--- ========================================================= ---
---  Create Frames
--- ========================================================= ---
function DaHud:CreateFrames(module)
	if not(module) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	for k,v in pairs(DaHud.db.profile[string.lower(moduleName)]) do
		if v.active then
			if tonumber((k):match("%d+")) > (module.lastKnownNumber or 0) then
				module.lastKnownNumber = tonumber((k):match("%d+"))
			end

			DaHud:CreateFrame(module, k, v.name)
		end
	end
end

--- ========================================================= ---
---  Create Frame
--- ========================================================= ---
function DaHud:CreateFrame(module, id, name)
	if not(module) then return end

	local moduleName = string.gsub(module.name, "DaHud_", "")

	if not(id) then
		module.lastKnownNumber = ((module.lastKnownNumber or 0) + 1)
		
		local tmp = string.lower(moduleName)
		
		if (string.sub(tmp, -1) == "s") then
			tmp = string.sub(tmp, 1, -2)
		end

		id = tmp..""..(module.lastKnownNumber)
		name = tmp..""..(module.lastKnownNumber)
	end
	
	DaHud:CreateFrameSettings(module, id, name)
	DaHud:CreateFrameOptions(module, id, name)
	
	local frameName = "DaHud_"..(id)
	if not _G[frameName] then
		local frameType, frameExtra = "Frame", nil
		
		if type(module.FrameType) == "function" then
			frameType, frameExtra = module.FrameType(module)
		end
	
		local f = newFrame(frameType, frameName, UIParent, frameExtra)
		DaHud.Frames[moduleName][id] = f
		
		DaHud:SetAttributes(module, id)
		DaHud:SetScripts(module, id)
	else
		if not(DaHud.Frames[moduleName][id]) then
			DaHud.Frames[moduleName][id] = _G[frameName]
			
			DaHud:SetAttributes(module, id)
			DaHud:SetScripts(module, id)
		end
	end
	
	DaHud:RefreshFrame(module, id)
end

--- ========================================================= ---
---  Set Attributes
--- ========================================================= ---
function DaHud:SetAttributes(module, id)
	if not(module) or not(id) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	local f = DaHud.Frames[moduleName][id]
	f.moduleName = moduleName
	
	if type(module.SetAttributes) == "function" then
		module.SetAttributes(module, id)
	end
	
	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["SetAttributes_"..k]) == "function" then
				module["SetAttributes_"..k](module, id)
			end
		end
	end
end

--- ========================================================= ---
---  Set Scripts
--- ========================================================= ---
function DaHud:SetScripts(module, id)
	if not(module) or not(id) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	local f = DaHud.Frames[moduleName][id]

	f:SetScript("OnUpdate", DaHud.OnUpdate)
	f:SetScript("OnEvent", DaHud.OnEvent)
	f:SetScript("OnHide", DaHud.OnHide)
	f:SetScript("OnShow", DaHud.OnShow)

	if type(module.SetScripts) == "function" then
		module.SetScripts(module, id)
	end
	
	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["SetScripts_"..k]) == "function" then
				module["SetScripts_"..k](module, id)
			end
		end
	end
end

--- ========================================================= ---
---  On Update
--- ========================================================= ---
function DaHud:OnUpdate()
	local id = string.gsub(this:GetName(), "DaHud_", "")
	local module = DaHud:GetModule(this.moduleName)
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	if type(module.OnUpdate) == "function" then
		module.OnUpdate(module, this)
	end
	
	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["OnUpdate_"..k]) == "function" then
				if not(DaHud.db.profile[string.lower(moduleName)].pluginsDisabled[k]) then
					module["OnUpdate_"..k](module, this)
				end
			end
		end
	end
end

--- ========================================================= ---
---  On Event
--- ========================================================= ---
function DaHud:OnEvent(event, unit)
	local id = string.gsub(this:GetName(), "DaHud_", "")
	local module = DaHud:GetModule(this.moduleName)
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	if (event == "PLAYER_ENTERING_WORLD") then
		DaHud:UpdateFrame(module, this)
	elseif (event == "PLAYER_TARGET_CHANGED") then
		if (this:GetAttribute("unit") == "target") then
			DaHud:UpdateFrame(module, this)
		end
	elseif (event == "PLAYER_FOCUS_CHANGED") then
		if (this:GetAttribute("unit") == "focus") then
			DaHud:UpdateFrame(module, this)
		end
	else
		if (this:GetAttribute("unit") == unit) then
			DaHud:UpdateFrame(module, this)
		end
	end

	if (event == "PARTY_MEMBERS_CHANGED") then
		DaHud:RaidCheck(module, this, id)
	end

	if type(module.OnEvent) == "function" then
		module.OnEvent(module, this, event, unit)
	end
	
	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["OnEvent_"..k]) == "function" then
				if not(DaHud.db.profile[string.lower(moduleName)].pluginsDisabled[k]) then
					module["OnEvent_"..k](module, this, event, unit)
				end
			end
		end
	end
end

--- ========================================================= ---
---  On Hide
--- ========================================================= ---
function DaHud:OnHide()
	local id = string.gsub(this:GetName(), "DaHud_", "")
	local module = DaHud:GetModule(this.moduleName)
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	if type(module.OnHide) == "function" then
		module.OnHide(module, this)
	end
	
	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["OnHide_"..k]) == "function" then
				if not(DaHud.db.profile[string.lower(moduleName)].pluginsDisabled[k]) then
					module["OnHide_"..k](module, this)
				end
			end
		end
	end
end

--- ========================================================= ---
---  On Show
--- ========================================================= ---
function DaHud:OnShow()
	local id = string.gsub(this:GetName(), "DaHud_", "")
	local module = DaHud:GetModule(this.moduleName)
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	if type(module.OnShow) == "function" then
		module.OnShow(module, this)
	end
	
	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["OnShow_"..k]) == "function" then
				if not(DaHud.db.profile[string.lower(moduleName)].pluginsDisabled[k]) then
					module["OnShow_"..k](module, this)
				end
			end
		end
	end
end

--- ========================================================= ---
---  Refresh Frame
--- ========================================================= ---
function DaHud:RefreshFrame(module, id, oldValue)
	if not(module) or not(id) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	local f = DaHud.Frames[moduleName][id]
	local settings = DaHud.db.profile[string.lower(moduleName)][id]
	
	DaHud:SetFrame(f, settings)
	
	DaHud:UnregisterFrameEvents(module, id)
	DaHud:RegisterFrameEvents(module, id)
	
	if type(module.RefreshFrame) == "function" then
		module.RefreshFrame(module, id, oldValue)
	end
	
	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["RefreshFrame_"..k]) == "function" then
				if not(DaHud.db.profile[string.lower(moduleName)].pluginsDisabled[k]) then
					module["RefreshFrame_"..k](module, id, oldValue)
				end
			end
		end
	end
	
	DaHud:SetupWatch(module, f, id)
	DaHud:SetupInteractivity(module, f, id)
	DaHud:SetupRaidCheck(module, f, id)
	
	DaHud:UpdateFrame(module, f)
end

--- ========================================================= ---
---  Unregister Frame Events
--- ========================================================= ---
function DaHud:UnregisterFrameEvents(module, id)
	if not(module) or not(f) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	local f = DaHud.Frames[moduleName][id]
	
	f:UnregisterAllEvents()
end

--- ========================================================= ---
---  Register Frame Events
--- ========================================================= ---
function DaHud:RegisterFrameEvents(module, id)
	if not(module) or not(id) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	local f = DaHud.Frames[moduleName][id]
	
	if type(module.RegisterFrameEvents) == "function" then
		module.RegisterFrameEvents(module, id)
	end
	
	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["RegisterFrameEvents_"..k]) == "function" then
				if not(DaHud.db.profile[string.lower(moduleName)].pluginsDisabled[k]) then
					module["RegisterFrameEvents_"..k](module, id)
				end
			end
		end
	end
end

--- ========================================================= ---
---  Set Frame
--- ========================================================= ---
function DaHud:SetFrame(f, settings)
	f:ClearAllPoints()
	
	f:SetWidth(settings.width)
	f:SetHeight(settings.height)
	
	DaHud:SetFrameParent(f, settings)
	DaHud:SetFrameAnchor(f, settings)
	
	f:SetFrameStrata(settings.framestrata)
	f:SetFrameLevel(settings.framelevel)
	
	DaHud:SetFrameBackdrop(f, settings)
	
	f:SetAlpha(1)
end

--- ========================================================= ---
---  Set Frame StatusBar
--- ========================================================= ---
function DaHud:SetFrameStatusBar(f, anchor, settings)
	f:ClearAllPoints()
	f:SetOrientation("HORIZONTAL")
	f:SetMinMaxValues(0, 1)
	f:SetPoint("TOPLEFT", anchor, "TOPLEFT", 1, -1)
	f:SetPoint("BOTTOMRIGHT", anchor, "BOTTOMRIGHT", -1, 1)
end

--- ========================================================= ---
---  Set Frame Child
--- ========================================================= ---
function DaHud:SetFrameChild(f, anchor, settings)
	f:ClearAllPoints()
	f:SetWidth(settings.width)
	f:SetHeight(settings.height)
	f:SetAllPoints(anchor)
end

--- ========================================================= ---
---  Set Frame Parent
--- ========================================================= ---
function DaHud:SetFrameParent(f, settings)
	f:SetParent(_G["DaHudParent"])
end

--- ========================================================= ---
---  Set Frame Anchor
--- ========================================================= ---
function DaHud:SetFrameAnchor(f, settings)
	if not(f) or not(settings) then return end
	
	if DaHud.objectsToUpdate[settings.name] then
		DaHud.objectsToUpdate[settings.name] = nil
	end
	
	f:SetPoint(settings.point, _G[settings.anchor], settings.relative, settings.posx, settings.posy)
	
	if not(_G[settings.anchor]) then
		DaHud:RegisterUpdate(self, "SetFrameAnchor", settings.name, f, settings)
	end
end

--- ========================================================= ---
---  Set Frame Backdrop
--- ========================================================= ---
function DaHud:SetFrameBackdrop(f, settings)
	f:SetBackdrop( {
		bgFile = "Interface\\Buttons\\WHITE8X8", 
		edgeFile = "Interface\\Buttons\\WHITE8X8", 
		tile = true, tileSize = 8, edgeSize = 1,
		insets = {left = 1, right = 1, top = 1, bottom = 1},
		} )
	f:SetBackdropColor(0, 0, 0, 0)
	f:SetBackdropBorderColor(0, 0, 0, 0)
end

--- ========================================================= ---
---  Setup Watch
--- ========================================================= ---
function DaHud:SetupWatch(module, f, name)
	if not(module) or not(f) or not(name) then return end

	local moduleName = string.gsub(module.name, "DaHud_", "")
	local settings = DaHud.db.profile[string.lower(moduleName)][name]
	
	UnregisterUnitWatch(f)

	f:SetAttribute("unit", settings.unit)

	if DaHud:InConfigMode() then
		f:SetAlpha(1)
		f:Show()
		
		if f.useConfigBackdropColor then
			f:SetBackdropColor(0.25, 0.50, 0.75, 0.50)
		end
	else
		if ((UnitInRaid("player")) and (settings.hideinraid)) then
			f:Hide()
		else
			RegisterUnitWatch(f)
		end
		
		if f.useConfigBackdropColor then
			f:SetBackdropColor(0.25, 0.50, 0.75, 0)
		end
	end
	
	if DaHud.db.profile[string.lower(moduleName)].pluginsDisabled[settings.type] then
		UnregisterUnitWatch(f)
		f:Hide()
	end
end

--- ========================================================= ---
---  Setup Interactivity
--- ========================================================= ---
function DaHud:SetupInteractivity(module, f, id)
	if not(module) or not(f) or not(id) then return end
	
	if (f:GetObjectType() ~= "Button") then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	local settings = DaHud.db.profile[string.lower(moduleName)][id]
	
	ClickCastFrames = ClickCastFrames or {}

	if settings.interactive then
		f:SetAttribute("*type1", "target")
		f:SetAttribute("*type2", "menu")
		f:SetAttribute("*type3", "assist")
		f:EnableMouse(true)
		f:RegisterForClicks("AnyUp")
		
		f.menu = function(self)
			DaHud.DropDownUnit(settings.unit)
		end
		
		ClickCastFrames[f] = true
	else
		f:SetAttribute("*type1", nil)
		f:SetAttribute("*type2", nil)
		f:SetAttribute("*type3", nil)
		f:EnableMouse(false)
		f:RegisterForClicks()
		
		f.menu = nil
		
		ClickCastFrames[f] = nil
	end
end

--- ========================================================= ---
---  Setup Raid Check
--- ========================================================= ---
function DaHud:SetupRaidCheck(module, f, id)
	if not(module) or not(f) or not(id) then return end

	local moduleName = string.gsub(module.name, "DaHud_", "")
		
	f:RegisterEvent("PARTY_MEMBERS_CHANGED")
end

--- ========================================================= ---
---  Raid Check
--- ========================================================= ---
function DaHud:RaidCheck(module, f, name)
	if not(module) or not(f) or not(name) then return end

	local moduleName = string.gsub(module.name, "DaHud_", "")
	local settings = DaHud.db.profile[string.lower(moduleName)][name]
	
	if ((UnitInRaid("player")) and (settings.hideinraid)) then
		UnregisterUnitWatch(f)
		f:Hide()
	else
		RegisterUnitWatch(f)
	end
end

--- ========================================================= ---
---  Update Frame
--- ========================================================= ---
function DaHud:UpdateFrame(module, f)
	if not(module) or not(f) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	
	if type(module.UpdateFrame) == "function" then
		module.UpdateFrame(module, f)
	end

	if DaHud[moduleName].Plugins then
		for k, v in pairs(DaHud[moduleName].Plugins) do
			if type(module["UpdateFrame_"..k]) == "function" then
				if not(DaHud.db.profile[string.lower(moduleName)].pluginsDisabled[k]) then
					module["UpdateFrame_"..k](module, f)
				end
			end
		end
	end
end

--- ========================================================= ---
---  Rename Frame
--- ========================================================= ---
function DaHud:RenameFrame(module, info, value)
	if not(module) or not(info) or not(value) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	local id = info[#info-3]
	
	DaHud.db.profile[string.lower(moduleName)][id].name = value
	
	DaHud:CreateFrameOptions(module, id, value)
end

--- ========================================================= ---
---  Delete Frame
--- ========================================================= ---
function DaHud:DeleteFrame(module, info)
	if not(module) or not(info) then return end
	
	local moduleName = string.gsub(module.name, "DaHud_", "")
	local id = info[#info-3]
	
	DaHud.db.profile[string.lower(moduleName)][id] = nil
	DaHud.options.args[moduleName].args[id] = nil
	
	delFrame(DaHud.Frames[moduleName][id])
end