----------
-- Locals
----------

-- Itemid => skilllevel required
-- Item levels and IDs from wowhead
local lockboxes = {
	-- PickPocket Boxes
	[16882] = 1, -- Battered Junkbox
	[16883] = 70, -- Worn Junkbox
	[16884] = 175, -- Sturdy Junkbox
	[16885] = 250, -- Heavy Junkbox
	[29569] = 300, -- Strong junkbox
	[43575] = 350, -- Reinforced Junkbox
	-- Fishing Boxes
	[6354] = 1, -- Small Locked Chest
	[6355] = 70, -- Sturdy Locked Chest
	[13875] = 175, -- Ironbound Locked Chest
	[13918] = 250, -- Reinforced Locked Chest
	-- Lockboxes mob drops
	[4632] = 1, -- Ornate Bronze Lockbox
	[4633] = 25, -- Heavy Bronze Lockbox
	[4634] = 70, -- Iron Lockbox
	[4636] = 125, -- Strong Iron Lockbox
	[4637] = 175, -- Steel Lockbox
	[4638] = 225, -- Reinforced Steel Lockbox
	[5758] = 225, -- Mithril Lockbox
	[5759] = 225, -- Thorium Lockbox
	[5760] = 225, -- Eternium Lockbox
	[12033] = 275, -- Thaurissan Family Jewels
	[31952] = 325, -- Khorium Lockbox
	[43622] = 375, -- Froststeel Lockbox
	[45986] = 400, -- Tiny Titanium Lockbox
	[43624] = 400, -- Titanium Lockbox
	-- Crafted Locks
	[6712] = 1, -- Practice Lock, created by engineers
}

local pickspell = GetSpellInfo(1804)
local pickskill = GetSpellInfo(1809)

local tooltip = LockSmithTooltip
local hasspell
local busy = nil
local db
local defaults = {
	profile = {}
}
-----------
-- Addon Declaration
-----------

LockSmith = LibStub("AceAddon-3.0"):NewAddon("LockSmith", "AceEvent-3.0", "AceTimer-3.0", "AceBucket-3.0")
local addon = LockSmith

-----------
-- Addon Initialization
-----------

function addon:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("LockSmithDB", defaults, "Default")
	db = self.db
end

function addon:OnEnable()
	local class, enclass = UnitClass("player")
	if enclass == "ROGUE" then
		self:SetupButton()
		self:RegisterBucketEvent("BAG_UPDATE", 0.5, "ScanBags")
		self:RegisterEvent("LEARNED_SPELL_IN_TAB", "GetLockPickSpell")
		self:RegisterEvent("PLAYER_REGEN_ENABLED", "ScanBags")
		self:RegisterEvent("SKILL_LINES_CHANGED", "GetLockPickLevel")
		self:RegisterEvent("UNIT_SPELLCAST_SENT", "UnlockStart")
		self:RegisterEvent("UNIT_SPELLCAST_FAILED", "UnlockStop")
		self:RegisterEvent("UNIT_SPELLCAST_STOP", "UnlockStop")
		self:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED", "UnlockStop")
		self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED", "UnlockStop")
		self:RegisterMessage("LockSmith_ScanBags", "ScanBags")
		self:GetLockPickSpell()
		self:GetLockPickLevel()
			
		self:ScanBags()
	else
		DisableAddOn("LockSmith")
	end
end

function addon:OnDisable()
	self:HideButton()
end

------------
-- The gory innards
------------

local function FindLocked()
	for i=1,tooltip:NumLines() do
		if tooltip.L[i] == LOCKED then
			return true
		end
	end
	return false
end

function addon:ScanBags()
	if InCombatLockdown() then return end
	local itemid

	local boxbag, boxslot = nil,nil

	for bag = 0, 4, 1 do
		for slot = 1, GetContainerNumSlots(bag), 1 do
			_,_,itemid = string.find(GetContainerItemLink(bag,slot) or "", "item:(%d+):%d+:%d+:%d+")
			itemid = tonumber(itemid)
			if itemid then
				if not boxbag and lockboxes[itemid] and lockboxes[itemid] <= lockpickskill then
					tooltip:SetBagItem( bag, slot )
					if FindLocked() then
						boxbag = bag
						boxslot = slot
					end
				end
			end
		end
	end
	if hasspell and boxbag then
		self:SetButton(boxbag, boxslot)
	else
		self:HideButton()
	end
end

function addon:GetLockPickSpell()
	local i = 1
	local enspell, spell, subspell
	hasspell = nil

	while true do
		spell, subspell = GetSpellName(i, BOOKTYPE_SPELL)
		if not spell then
			do break end
		end
		if pickspell and pickspell == spell then
			hasspell = true
		end
		i = i + 1
	end

end

function addon:GetLockPickLevel()
	local numskills = GetNumSkillLines()
	local name, rank
	for i=1,numskills do
		name, _, _, rank = GetSkillLineInfo(i)
		if name == pickskill then
			lockpickskill = rank
			return
		end
	end
	lockpickskill = 0
end

function addon:UnlockStart(event, unit, spell, rank, target )
	if unit == "player" and spell == pickspell then
		busy = true
	end
end

local function timedScan()
	addon:SendMessage("LockSmith_ScanBags")
end

function addon:UnlockStop(event, unit)
	if unit == "player" and busy then
		busy = nil
		self:ScheduleTimer(timedScan, 1)
	end
end

function addon:SetButton(bag, slot)
	if InCombatLockdown() then 
		self:HideButton()
		return
	end
	-- secure attributes!
	local button = self.button
	button:SetAttribute( "type1", "macro" )
	button:SetAttribute( "macrotext1", "/cast "..pickspell.."\n/use "..bag.." "..slot)
	button:Show()
end

function addon:HideButton()
	if not self.button then return end
	self.button:Hide()
end

function addon:SetupButton()
	if self.button then return end

	self.button = CreateFrame("Button", "LockSmithButton", UIParent, "SecureActionButtonTemplate, ActionButtonTemplate")

	local button = self.button

	button:Hide()
	button:SetWidth( 32 )
	button:SetHeight( 32 )
	button:ClearAllPoints()
	button:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
	button:EnableMouse(true)
	button:RegisterForDrag("LeftButton")
	button:RegisterForClicks("AnyUp")
	button:SetMovable(true)
	button:SetScript("OnDragStart", function() if not InCombatLockdown() and IsAltKeyDown() then button:StartMoving() end end)
	button:SetScript("OnDragStop", function() if not InCombatLockdown() then button:StopMovingOrSizing() addon:SavePosition() end end)

	button.icon = LockSmithButtonIcon
	button.icon:SetTexture( "Interface\\Icons\\Spell_Nature_MoonKey"  )

	self:RestorePosition()
end

function addon:SavePosition()
	local f = self.button
	local s = f:GetEffectiveScale()

	self.db.profile.posx = f:GetLeft() * s
	self.db.profile.posy = f:GetTop() * s
end

function addon:RestorePosition()
	local x = self.db.profile.posx
	local y = self.db.profile.posy

	if not x or not y then return end

	local f = self.button
	local s = f:GetEffectiveScale()

	f:ClearAllPoints()
	f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x / s, y / s)
end
