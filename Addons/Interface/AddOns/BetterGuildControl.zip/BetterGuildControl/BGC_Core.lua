--[[
************************************************************************
Project				: BetterGuildControl
Author				: zhinjio
Project Revision	: 0.0.1-beta
Project Date		: 20090901082646

File				: BGC_Core.lua
Commit Author		: zhinjio
Commit Revision		: 19
Commit Date			: 20090901082646
************************************************************************
Description	:
	addon creation file, pretty much just a stub for NewAddon and
	local creation so they're avialable everywhere else

TODO		:

************************************************************************
(see bottom of file for changelog)
************************************************************************
--]]

local MODNAME = "BetterGuildControl"
local FULLNAME = "BetterGuildControl"

local BetterGuildControl = LibStub( "AceAddon-3.0" ):NewAddon( MODNAME, "AceEvent-3.0" )
local L = LibStub:GetLibrary( "AceLocale-3.0" ):GetLocale( MODNAME )

_G[ MODNAME ] = BetterGuildControl
local addon = BetterGuildControl

-- addon globals
-- addon.someValue = 0
addon.guild = ""
addon.GRUs = 0
addon.dataReady = false
addon.numGuildRanks = 0
addon.numGuildMembers = 0
addon.numGuildBankTabs = 0
addon.GuildRanks = {}
addon.BankTab = {}
addon.displayList = {}
addon.sortMethod = "name"
addon.sortAscend = 1

addon.permissionStrings = {
	L["Listen to Guild Chat"],
	L["Speak in Guild Chat"],
	L["Listen to Officer Chat"],
	L["Speak in Officer Chat"],
	L["Promote Member"],
	L["Demote Member"],
	L["Invite Member"],
	L["Remove Member"],
	L["Set MOTD"],
	L["Edit Public Note"],
	L["View Officer Note"],
	L["Edit Officer Note"],
	L["Modify Guild Info"],
	L["Guild Bank Withdraw Repair"],
	L["Guild Bank Withdraw Gold"],
	L["Create Guild Event"]
}

addon.CLASS_COLORS = {}
local COLOR_TABLE = CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS
for k, v in pairs(COLOR_TABLE) do
	addon.CLASS_COLORS[k] = string.format("%2x%2x%2x", v.r * 255, v.g * 255, v.b * 255)
end

--[[
************************************************************************
CHANGELOG:

08/12/09 : 
	Initial version
************************************************************************
]]--