--[[
************************************************************************
Project				: BetterGuildControl
Author				: zhinjio
Project Revision	: 0.0.1-beta
Project Date		: 20090901082646

File				: Locales\enUS.lua
Commit Author		: zhinjio
Commit Revision		: 17
Commit Date			: 20090820072729
************************************************************************
Description	:
	English translation strings
TODO		:
************************************************************************
--]]
local MODNAME = "BetterGuildControl"
-- prevent errors being thrown when using SVN pushes...
local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]
local L = LibStub:GetLibrary("AceLocale-3.0"):NewLocale( MODNAME, "enUS", true, debug )
if not L then return end

L["Author : "] = true
L["Build Date : "] = true
L["Class"] = true
L["Click to change rank title"] = true
L["Create Guild Event"] = true
L["Database Version : "] = true
L["Data cached"] = true
L["Data not yet cached"] = true
L["Demote Member"] = true
L["Deposit Item"] = true
L["DISPLAY_DEBUG_DESC"] = "Check to enable DEBUG messages"
L["Display Options"] = true
L["DISPLAY_OPTIONS_DESC"] = "Options dealing with the displays of the plugin"
L["Edit Officer Note"] = true
L["Edit Public Note"] = true
L["Enable DEBUG"] = true
L["GENERAL_INFO_DESC"] = "Version and author information"
L["General Information"] = true
L["Guild Bank Withdraw Gold"] = true
L["Guild Bank Withdraw Repair"] = true
L["Guild Information is now available"] = true
L["Helpful Translators (thank you) : %s"] = true
L["Invite Member"] = true
L["Left-Click to change displays"] = true
L["Left-Click to display guild information details"] = true
L["Left-Click to open main window"] = true
L["Level"] = true
L["Listen to Guild Chat"] = true
L["Listen to Officer Chat"] = true
L["Main Permissions by Rank "] = true
L["Modify Guild Info"] = true
L["n/a"] = true
L["Name"] = true
L["Note"] = true
L["Or guild info not yet available"] = true
L["Permission"] = true
L["Promote Member"] = true
L["Race"] = true
L["Rank"] = true
L["Rank Name"] = true
L["Rank Title Listing"] = true
L["Remove Member"] = true
L["Right-click for Configuration"] = true
L["Set MOTD"] = true
L["Speak in Guild Chat"] = true
L["Speak in Officer Chat"] = true
L["Tooltip Scale"] = true
L["TOOLTIP_SCALE_DESC"] = "Slide to change the size(scale) of the tooltip"
L["Update Tab Text"] = true
L["Version : "] = true
L["View Officer Note"] = true
L["View Tab"] = true
L["Withdraw Gold/day"] = true
L["Withdraw Stacks/day"] = true
L["You are not currently in a guild"] = true
L["Zone"] = true


--[[
************************************************************************
CHANGELOG:

Date : 5/1/09
	Initial version
************************************************************************
]]--