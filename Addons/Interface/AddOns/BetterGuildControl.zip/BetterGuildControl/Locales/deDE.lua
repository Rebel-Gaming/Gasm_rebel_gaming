--[[
************************************************************************
Project				: BetterGuildControl
Author				: zhinjio
Project Revision	: 0.0.1-beta
Project Date		: 20090901082646

File				: Locales\deDE.lua
Commit Author		: zhinjio
Commit Revision		: 14
Commit Date			: 20090814201122
************************************************************************
Description	:
	German translation strings
TODO		:
************************************************************************
--]]
local MODNAME = "BetterGuildControl"
local L = LibStub:GetLibrary("AceLocale-3.0"):NewLocale( MODNAME, "deDE" )
if not L then return end

L["Author : "] = "Urheber:"
L["Build Date : "] = "Erstellungsdatum:"
L["Class"] = "Klasse"
L["Click to change rank title"] = "Klicken, um Rang zu ändern"
L["Create Guild Event"] = "Gilden-Event erstellen"
L["Database Version : "] = "Datenbank Version:"
L["Data cached"] = "Daten zwischengespeichert"
L["Data not yet cached"] = "Daten noch nicht zwischengespeichert"
L["Demote Member"] = "Mitglied degradieren"
-- L["Deposit Item"] = "Deposit Item"
L["DISPLAY_DEBUG_DESC"] = "Markieren, um DEBUG-Mitteilungen zu aktivieren"
L["Display Options"] = "Anzeige-Optionen:"
L["DISPLAY_OPTIONS_DESC"] = "Anzeigeoptionen für das PlugIn"
L["Edit Officer Note"] = "Offiziersnotiz bearbeiten"
L["Edit Public Note"] = "Gildeninformation bearbeiten"
L["Enable DEBUG"] = "DEBUG aktivieren"
L["GENERAL_INFO_DESC"] = "Version und Urheberinformationen"
L["General Information"] = "Allgemeine Informationen"
L["Guild Bank Withdraw Gold"] = "Gildenbank Geldentahme"
L["Guild Bank Withdraw Repair"] = "Gildenbank Reparaturkosten-Entahme"
L["Guild Information is now available"] = "Gildeninformation ist jetzt Verfügbar"
L["Helpful Translators (thank you) : %s"] = "Hilfreiche Übersetzer (Danke): %s"
L["Invite Member"] = "Mitglied einladen"
L["Left-Click to change displays"] = "Linksklick, um Anzeige zu verändern"
L["Left-Click to display guild information details"] = "Linksklick, um die Details der Gildeninformationen anzuzeigen"
L["Left-Click to open main window"] = "Linksklick, um Hauptfenster zu öffnen"
L["Level"] = true
L["Listen to Guild Chat"] = "Gilden-Chat lesen"
L["Listen to Officer Chat"] = "Offiziers-Chat lesen"
L["Main Permissions by Rank "] = "Hauptberechtigungen nach Rang"
L["Modify Guild Info"] = "Gildeninformationen bearbeiten"
-- L["n/a"] = "n/a"
L["Name"] = true
L["Note"] = "Notiz"
L["Or guild info not yet available"] = "Alternativ dazu, könnten die Gildeninformationen noch nicht verfügbar sein"
L["Permission"] = "Erlaubnis"
L["Promote Member"] = "Mitglied befördern"
L["Race"] = "Rasse"
L["Rank"] = "Rang"
L["Rank Name"] = "Rangbezeichnung"
L["Rank Title Listing"] = "Auflistung Ränge"
L["Remove Member"] = "Mitglied entfernen"
L["Right-click for Configuration"] = "Rechtsklick zum Konfigurieren"
L["Set MOTD"] = "Gildennachricht des Tages erstellen"
L["Speak in Guild Chat"] = "Am Gilden-Chat teilnehmen"
L["Speak in Officer Chat"] = "Am Offiziers-Chat teilnehmen"
L["Tooltip Scale"] = "Tooltip Maßstab"
L["TOOLTIP_SCALE_DESC"] = "Verschieben, um die Größe (Maßstab) des Tooltips zu verändern"
-- L["Update Tab Text"] = "Update Tab Text"
L["Version : "] = "Version:"
L["View Officer Note"] = "Offiziersnotiz ansehen"
-- L["View Tab"] = "View Tab"
-- L["Withdraw Gold/day"] = "Withdraw Gold/day"
-- L["Withdraw Stacks/day"] = "Withdraw Stacks/day"
L["You are not currently in a guild"] = "Du bist derzeit in keiner Gilde"
L["Zone"] = true


--[[
************************************************************************
CHANGELOG:

Date : 08/14/09
	Initial version
************************************************************************
]]--