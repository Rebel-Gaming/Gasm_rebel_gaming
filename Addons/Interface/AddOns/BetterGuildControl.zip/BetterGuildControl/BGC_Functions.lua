--[[
************************************************************************
Project				: BetterGuildControl
Author				: zhinjio
Project Revision	: 0.0.1-beta
Project Date		: 20090901082646

File				: BGC_Functions.lua
Commit Author		: zhinjio
Commit Revision		: 19
Commit Date			: 20090901082646
************************************************************************
Description	:
	Functions that should be available everywhere

TODO		:

************************************************************************
(see bottom of file for changelog)
************************************************************************
--]]

local MODNAME = "BetterGuildControl"
local FULLNAME = "BetterGuildControl"

local BetterGuildControl = LibStub( "AceAddon-3.0" ):GetAddon( MODNAME )
local L = LibStub:GetLibrary( "AceLocale-3.0" ):GetLocale( MODNAME )

local addon = BetterGuildControl

function addon.Print( msg )
	local _, fh = DEFAULT_CHAT_FRAME:GetFont()
	fh = math.ceil( fh )
	local icon = "\124TInterface\\Addons\\" .. FULLNAME .. "\\icon:" .. fh .. "\124t"
	if ( msg ~= nil ) then
	   if( DEFAULT_CHAT_FRAME ) then
	      DEFAULT_CHAT_FRAME:AddMessage( icon .. " " .. MODNAME .. " : " .. msg, 0.6, 1.0, 1.0 )
	   end
	end
end

function addon.Debug( msg )
	local db = addon.db.factionrealm[addon.guild]
	if ( msg ~= nil ) then
		if ( db.options.display.debug ) then
			addon.Print( "DEBUG: " .. msg )
		end
	end
end

function addon.DDebug( msg )
	if ( msg ~= nil ) then
		addon.Print( "DDEBUG: " .. msg )
	end
end

-- coloring agents
--[[
local function Orange ( text ) return "|cffdea51c" .. text .. "|r" end
local function Yellow ( text ) return "|cffffff00" .. text .. "|r" end
local function Cyan ( text ) return "|cff00ffff" .. text .. "|r" end
]]--
function Grey ( text ) return "|cff999999" .. text .. "|r" end

function addon.TooltipDisplay( this, textLabel, useTrans )
	this:SetScript( "OnEnter",
		function ( this )
			GameTooltip_SetDefaultAnchor( GameTooltip, this )
			if ( useTrans == 1 ) then
				GameTooltip:SetText( L[ textLabel ], HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b )
			else
				GameTooltip:SetText( textLabel, HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b )
			end
			GameTooltip:Show()
		end
	)
	this:SetScript( "OnLeave",
		function( this )
			GameTooltip:Hide()
		end
	)
end

function addon.CreateTabButton( bName, bParent, bankTab )
	local cButton = CreateFrame( "Button", bName, bParent )
	cButton:SetWidth( 55 )
	cButton:SetHeight( 30 )
	cButton:SetAlpha( 1 )
	cButton:SetFrameStrata( "DIALOG" )
	cButton.bankTab = bankTab
	
	cButton:SetScript("OnClick", function() 
		addon:switchBankTabs( cButton )
	end)
	local bgTex = cButton:CreateTexture(cButton:GetName() .. "bgTex", "BACKGROUND")
		bgTex:SetTexture( 'Interface/PaperDollInfoFrame/UI-Character-InactiveTab' )
		bgTex:SetAllPoints( cButton )
--[[		bgTex:SetHeight( 30 )
		bgTex:SetWidth( 55 )
		bgTex:SetTexCoord(0, 1(43/64), 0, (43/64))
		bgTex:SetPoint("CENTER", cButton, "CENTER", 0, 0) ]]--
	local pushedTexture = cButton:CreateTexture(cButton:GetName() .. "pTex", "ARTWORK")
		pushedTexture:SetTexture('Interface/Buttons/UI-Quickslot-Depress')
		pushedTexture:SetAllPoints(cButton)
		cButton:SetPushedTexture(pushedTexture)
	local highlightTexture = cButton:CreateTexture()
		highlightTexture:SetTexture('Interface/Buttons/ButtonHilight-Square')
		highlightTexture:SetAllPoints(cButton)
		highlightTexture:SetBlendMode('ADD')
		cButton:SetHighlightTexture(highlightTexture)
	local text = cButton:CreateFontString(cButton:GetName() .. "_FontString", "ARTWORK")
	cButton:SetFontString(text)
	cButton.text = text
	text:SetPoint("LEFT", cButton, "LEFT", 7, 0)
	text:SetPoint("RIGHT", cButton, "RIGHT", -7, 0)
	text:SetJustifyH( "CENTER" )
	cButton:SetNormalFontObject( GameFontNormalSmall )
	cButton:SetHighlightFontObject( GameFontHighlightSmall )
	cButton:SetDisabledFontObject(GameFontDisableSmall)
		
	return cButton
end

function addon.CreateMainButton( bName, bParent, bTex )
	local cButton = CreateFrame( "CheckButton", bName, bParent )
	local ExpTextureSize = 33
	cButton:SetWidth(ExpTextureSize)
	cButton:SetHeight(ExpTextureSize)
	cButton:SetScript("OnClick", function() 
		addon:switchPanes( cButton )
	end)
	local bgTex = cButton:CreateTexture(cButton:GetName() .. "bgTex", "BACKGROUND")
		bgTex:SetTexture('Interface/SpellBook/UI-Spellbook-SpellBackground')
		bgTex:SetHeight(ExpTextureSize + 4)
		bgTex:SetWidth(ExpTextureSize + 4)
		bgTex:SetTexCoord(0, (43/64), 0, (43/64))
		bgTex:SetPoint("CENTER", cButton, "CENTER", 0, 0)
	local iconTex = cButton:CreateTexture(cButton:GetName() .. "iconTex", "BORDER")
		iconTex:SetTexture('Interface/Icons/' .. bTex)
		iconTex:SetAllPoints(cButton)
	local pushedTexture = cButton:CreateTexture(cButton:GetName() .. "pTex", "ARTWORK")
		pushedTexture:SetTexture('Interface/Buttons/UI-Quickslot-Depress')
		pushedTexture:SetAllPoints(cButton)
		cButton:SetPushedTexture(pushedTexture)
	local highlightTexture = cButton:CreateTexture()
		highlightTexture:SetTexture('Interface/Buttons/ButtonHilight-Square')
		highlightTexture:SetAllPoints(cButton)
		highlightTexture:SetBlendMode('ADD')
		cButton:SetHighlightTexture(highlightTexture)
	local checkedTexture = cButton:CreateTexture()
		checkedTexture:SetTexture('Interface/Buttons/CheckButtonHilight')
		checkedTexture:SetAllPoints(cButton)
		checkedTexture:SetBlendMode('ADD')
		cButton:SetCheckedTexture(checkedTexture)
	return cButton
end

function addon.CreateButton(
	bName, parentFrame,	bHeight, bWidth,
	anchorFrom, anchorFrame, anchorTo, xOffset, yOffset,
	bNormFont, bHighFont, initText, tAlign, tooltipText, noTextures )

	-- I hate stretchy buttons. Thanks very much to ckknight for this code

	-- when pressed, the button should look pressed
	local function button_OnMouseDown(this)
		if this:IsEnabled() == 1 then
			this.left:SetTexture([[Interface\Buttons\UI-Panel-Button-Down]])
			this.middle:SetTexture([[Interface\Buttons\UI-Panel-Button-Down]])
			this.right:SetTexture([[Interface\Buttons\UI-Panel-Button-Down]])
		end
	end
	-- when depressed, return to normal
	local function button_OnMouseUp(this)
		if this:IsEnabled() == 1 then
			this.left:SetTexture([[Interface\Buttons\UI-Panel-Button-Up]])
			this.middle:SetTexture([[Interface\Buttons\UI-Panel-Button-Up]])
			this.right:SetTexture([[Interface\Buttons\UI-Panel-Button-Up]])
		end
	end

	local function button_Disable(this)
		this.left:SetTexture([[Interface\Buttons\UI-Panel-Button-Disabled]])
		this.middle:SetTexture([[Interface\Buttons\UI-Panel-Button-Disabled]])
		this.right:SetTexture([[Interface\Buttons\UI-Panel-Button-Disabled]])
		this:__Disable()
		this:EnableMouse(false)
	end

	local function button_Enable(this)
		this.left:SetTexture([[Interface\Buttons\UI-Panel-Button-Up]])
		this.middle:SetTexture([[Interface\Buttons\UI-Panel-Button-Up]])
		this.right:SetTexture([[Interface\Buttons\UI-Panel-Button-Up]])
		this:__Enable()
		this:EnableMouse(true)
	end

	local button = CreateFrame( "Button", bName, parentFrame )

	button:SetWidth( bWidth )
	button:SetHeight( bHeight )

	if not ( noTextures == 1 ) then
		local left = button:CreateTexture(button:GetName() .. "_LeftTexture", "BACKGROUND")
		button.left = left
		local middle = button:CreateTexture(button:GetName() .. "_MiddleTexture", "BACKGROUND")
		button.middle = middle
		local right = button:CreateTexture(button:GetName() .. "_RightTexture", "BACKGROUND")
		button.right = right

		left:SetTexture([[Interface\Buttons\UI-Panel-Button-Up]])
		middle:SetTexture([[Interface\Buttons\UI-Panel-Button-Up]])
		right:SetTexture([[Interface\Buttons\UI-Panel-Button-Up]])

		left:SetPoint("TOPLEFT")
		left:SetPoint("BOTTOMLEFT")
		left:SetWidth(12)
		left:SetTexCoord(0, 0.09375, 0, 0.6875)

		right:SetPoint("TOPRIGHT")
		right:SetPoint("BOTTOMRIGHT")
		right:SetWidth(12)
		right:SetTexCoord(0.53125, 0.625, 0, 0.6875)

		middle:SetPoint("TOPLEFT", left, "TOPRIGHT")
		middle:SetPoint("BOTTOMRIGHT", right, "BOTTOMLEFT")
		middle:SetTexCoord(0.09375, 0.53125, 0, 0.6875)

		button:SetScript("OnMouseDown", button_OnMouseDown)
		button:SetScript("OnMouseUp", button_OnMouseUp)
		button:SetScript("OnEnter", SubControl_OnEnter)
		button:SetScript("OnLeave", SubControl_OnLeave)

		button.__Enable = button.Enable
		button.__Disable = button.Disable
		button.Enable = button_Enable
		button.Disable = button_Disable

		local highlight = button:CreateTexture(button:GetName() .. "_Highlight", "OVERLAY", "UIPanelButtonHighlightTexture")
		button:SetHighlightTexture(highlight)
	end

	local text = button:CreateFontString(button:GetName() .. "_FontString", "ARTWORK")
	button:SetFontString(text)
	button.text = text
	text:SetPoint("LEFT", button, "LEFT", 7, 0)
	text:SetPoint("RIGHT", button, "RIGHT", -7, 0)
	text:SetJustifyH( tAlign )

	button:SetNormalFontObject(bNormFont)
	button:SetHighlightFontObject(bHighFont)
	button:SetDisabledFontObject(GameFontDisableSmall)

	text:SetText( initText )		

	button:SetPoint( anchorFrom, anchorFrame, anchorTo, xOffset, yOffset )
	if ( tooltipText ~= "" ) then
		addon.TooltipDisplay( button, tooltipText, 1 )
	end

	return button
end

--[[
************************************************************************
CHANGELOG:

08/12/09 : 
	Initial version
************************************************************************
]]--