--[[
************************************************************************
Project				: BetterGuildControl
Author				: zhinjio
Project Revision	: 0.0.1-beta
Project Date		: 20090901082646

File				: BetterGuildControl.lua
Commit Author		: zhinjio
Commit Revision		: 19
Commit Date			: 20090901082646
************************************************************************
Description	:
	Main addon file. 

TODO		:

************************************************************************
(see bottom of file for changelog)
************************************************************************
--]]

local MODNAME = "BetterGuildControl"
local FULLNAME = "BetterGuildControl"

local BetterGuildControl = LibStub( "AceAddon-3.0" ):GetAddon( MODNAME )
local L = LibStub:GetLibrary( "AceLocale-3.0" ):GetLocale( MODNAME )

local AceConfig 		= LibStub("AceConfig-3.0")
local AceConfigReg 		= LibStub("AceConfigRegistry-3.0")
local AceConfigDialog 	= LibStub("AceConfigDialog-3.0")

local addon = BetterGuildControl

local addonversion = "0.0.1-beta"
local addonauthor = "zhinjio"
local builddate = "20090901082646"

local modularOptions = {}
local tooltip
local LTT = LibStub:GetLibrary( "LibQTip-1.0" )

local db

local function drawTooltip()
	tooltip:Hide()
	tooltip:Clear()
	local numCols = 1
	local lineNum = tooltip:AddLine( "b" )
	if ( addon.dataReady == false ) then
		tooltip:SetCell( lineNum, 1, L["You are not currently in a guild"], "LEFT", numCols )
		lineNum = tooltip:AddLine( "c" )
		tooltip:SetCell( lineNum, 1, L["Or guild info not yet available"], "LEFT", numCols )
	else
		tooltip:SetCell( lineNum, 1, L["Left-Click to open main window"], "LEFT", numCols)
		lineNum = tooltip:AddLine( "c" )
		tooltip:SetCell( lineNum, 1, L["Right-click for Configuration"], "LEFT", numCols )
	end
end

-- LDB stuff
local LDB = LibStub( "LibDataBroker-1.1" )
local launcher = LDB:NewDataObject( MODNAME, {
	type = "launcher",
	text = " ",
	label = FULLNAME,
	icon = "Interface\\Addons\\" .. FULLNAME .. "\\icon",
	OnClick = function( clickedframe, button )
				if ( addon.dataReady == true ) then
					if button == "RightButton" then
						addon:ShowConfig()
					else
						addon:ToggleMainPanel()
					end
				end
	end,
	OnEnter = function ( self )
		tooltip = LTT:Acquire( MODNAME.."TT", 1, "LEFT" )
		tooltip:SetAutoHideDelay( .1, self )
		if ( addon.dataReady == true ) then
			tooltip:SetScale( db.options.display.tipscale )
		end
		drawTooltip()
		tooltip:EnableMouse()
		tooltip:SmartAnchorTo( self )
		tooltip:Show()
	end,
	OnLeave = function ( self )
		-- stub. autohidedelay should handle frame recycling
		return
	end,
} )

function addon.upgradeDB()
	local olddb = addon.db.factionrealm[addon.guild]
	if ( olddb.options.display.dbVersion == "1.0" ) then
		olddb.options.display.dbVersion = "1.1"
		olddb.players = {}
		olddb.toons = {}
		-- Need to get rid of the old addon.me stuff
		baddb = addon.db.factionrealm[UnitName("player")]
		baddb = nil
		addon.Print( string.format( L["Database upgraded to %s"], "1.1" ) )
	end
end

-- options stuff
local displayOptions = nil
local function giveDisplay()
	if (not displayOptions) then
		displayOptions = {
			order = 2,
			type = "group",
			name = L["Display Options"],
			desc = L["DISPLAY_OPTIONS_DESC"],
			args = {
				header1 = {
					order	= 21,
					type	= "header",
					name	= L["Display Options"],
				},
				desc = {
					order	= 22,
					type	= "description",
					name	= L["DISPLAY_OPTIONS_DESC"],
				},
				sound = {
					order	= 23,
					type	= "toggle",
					name	= L["Enable DEBUG"],
					desc	= L["DISPLAY_DEBUG_DESC"],
					get		= function() return db.options.display.debug end,
					set		= function() db.options.display.debug = not db.options.display.debug end,
				},
				tooltipscale = {
					order	= 24,
					type	= "range",
					name	= L["Tooltip Scale"],
					desc	= L["TOOLTIP_SCALE_DESC"],
					min		= .7,
					max		= 1.3,
					step	= .05,
					bigStep = .05,
					get		= function() return db.options.display.tipscale end,
					set		= function( info, v ) 
								db.options.display.tipscale = v
								tooltip:SetScale( v )
							  end,
				},
			},
		}
	end
	return displayOptions
end

local options = nil
local function fullOptions()
	if (not options) then
		options = {
			type = "group",
			name = MODNAME,
			args = {
				general = {
					order	= 1,
					type	= "group",
					name	= L["General Information"],
					desc	= L["GENERAL_INFO_DESC"],
					args	= {
						header1 = {
							order	= 11,
							type	= "header",
							name	= L["General Information"],
						},
						desc = {
							order	= 12,
							type	= "description",
							name	= L["GENERAL_INFO_DESC"],
						},
						author = {
							order	= 13,
							type	= "description",
							name	= L["Author : "] .. addonauthor .. "\n",
						},
						version = {
							order	= 14,
							type	= "description",
							name	= L["Version : "] .. addonversion .. "\n",
						},
						builddate = {
							order	= 15,
							type	= "description",
							name	= L["Build Date : "] .. builddate .. "\n",
						},
						dbversion = {
							order	= 15,
							type	= "description",
							name	= L["Database Version : "] .. db.options.display.dbVersion .. "\n",
						},
						translators = {
							order	= 16,
							type	= "description",
							name	= string.format( L["Helpful Translators (thank you) : %s"], " \n" )
						},
					},
				},
			},
		}
	end
	
	for k,v in pairs(modularOptions) do
		options.args[k] = (type(v) == "function") and v() or v
	end

	return options
end

function addon:SetupOptions()
	AceConfigReg:RegisterOptionsTable(MODNAME, fullOptions)
	self.optionsFrame = AceConfigDialog:AddToBlizOptions(MODNAME, nil, nil, "general")

	-- Fill up our modular options...
	self:RegisterModuleOptions("Display", giveDisplay(), L["Display Options"])
end

function addon:RegisterModuleOptions(name, optionsTable, displayName)
	modularOptions[name] = optionsTable
	self.optionsFrame[name] = AceConfigDialog:AddToBlizOptions(MODNAME, displayName, MODNAME, name)
end

function addon:ShowConfig()
	-- Open the profiles tab before, so the menu expands
	InterfaceOptionsFrame_OpenToCategory( self.optionsFrame["Display"] )
end

function addon:OnInitialize()
	-- I don't really do anything with onInit. I don't really truly "load"
	-- until I'm sure I'm in a guild (GRUs received). So just stub this.
end

function addon:CreateSVDB()
	self.db = LibStub( "AceDB-3.0" ):New( MODNAME .. "_DB", nil, "Default" )
	-- do we have any data yet; for this toon? If not, init its table
	if not ( self.db.factionrealm[addon.guild] ) then
		self.db.factionrealm[addon.guild] = {
		-- Your saved variables stuff here
			options = {
				display = {
					debug = false,
					tipscale = 1,
					dbVersion = "1.1",
				},
			},
			players = {
			},
			toons = {
			},
		}
	else
		-- check if we need to upgrade the db
		addon.upgradeDB()
	end
	db = self.db.factionrealm[addon.guild]
end

function addon:updateSorting()
	table.sort( addon.displayList, function ( x, y )
		local a = x[addon.sortMethod]
		local b = y[addon.sortMethod]
		if ( addon.sortMethod ~= "name" ) then
			if ( a == b ) then
				a = x.name
				b = y.name
			end
		end
		if ( addon.sortAscend == 1 ) then
			return a < b
		else
			return b < a
		end
	end )
end

local function scanGuildInfo()
	local dbtn
	-- Gather guild info, start with the ranks
	addon.numGuildRanks = GuildControlGetNumRanks()
	addon.numGuildBankTabs = GetNumGuildBankTabs()
	addon.GuildRanks = addon.GuildRanks or {}
	addon.BankTab = addon.BankTab or {}
	for i = 1, addon.numGuildRanks do
		-- for each rank, get all the permissions info
		GuildControlSetRank( i )
		local rankdata = addon.GuildRanks[ i ] or {}
		addon.BankTab[i] = addon.BankTab[i] or {}
		rankdata.Name = GuildControlGetRankName( i )
		rankdata.Count = 0
--[[
		local guildchat_listen, guildchat_speak, officerchat_listen, officerchat_speak, promote, demote,
			invite_member, remove_member, set_motd, edit_public_note, view_officer_note, edit_officer_note,
			modify_guild_info, _, withdraw_repair, withdraw_gold, create_guild_event = GuildControlGetRankFlags()
	 1 = "Guildchat Listen"
	 2 = "Guildchat Speak"
	 3 = "Officerchat Listen"
	 4 = "Officerchat Speak"
	 5 = "Promote"
	 6 = "Demote"
	 7 = "Invite Member"
	 8 = "Remove Member"
	 9 = "Set MOTD"
	10 = "Edit Public Note"
	11 = "View Officer Note"
	12 = "Edit Officer Note"
	13 = "Modify Guild Info"
	xx = "Create Guild Event" <-- deprecated
	14 = "Repair"
	15 = "Gold"
	16 = "Create Guild Event"
	-- Found with separate calls after:
	17 = "Withdraw Gold/day"
]]
		rankdata[1], rankdata[2], rankdata[3], rankdata[4], rankdata[5], rankdata[6],
			rankdata[7], rankdata[8], rankdata[9], rankdata[10], rankdata[11], rankdata[12],
			rankdata[13], _, rankdata[14], rankdata[15], rankdata[16] = GuildControlGetRankFlags()
			rankdata[17] = GetGuildBankWithdrawLimit()
		addon.GuildRanks[ i ] = rankdata
		-- Handle Bank Tab Permissions
		for j = 1, GetNumGuildBankTabs() do
			-- SetCurrentGuildBankTab( j )
			local banktabdata = addon.BankTab[i][j] or {}
			--[[ GetGuildBankTabPermissions ...
			1 = View Tab
			2 = Deposit Item
			3 = Update Tab Text
			4 = Withdraw Stacks/day
			]]--
			banktabdata[1], banktabdata[2], banktabdata[3],
				banktabdata[4] = GetGuildBankTabPermissions( j )
			addon.BankTab[i][j] = banktabdata
		end
	end
	for i = addon.numGuildRanks + 1, #addon.GuildRanks do
		addon.GuildRanks[i] = nil
	end

	-- Get Guildie info
	addon.displayList = nil
	addon.displayList = {}
	addon.numGuildMembers = GetNumGuildMembers(true)
	wipe(db.toons)
	for i = 1, addon.numGuildMembers do
		local name, rank, rankIndex, level, class, zone, note, 
			officernote, online, status, classFileName = GetGuildRosterInfo(i)
		rankIndex = rankIndex + 1
		addon.GuildRanks[ rankIndex ].Count = addon.GuildRanks[ rankIndex ].Count + 1
		local memberdata = addon.displayList[i] or {}
		memberdata.name = name
		memberdata.rank = rank
		memberdata.rankIndex = rankIndex
		memberdata.level = level
		memberdata.class = class
		memberdata.enClass = classFileName
		memberdata.zone = zone or "UNKNOWN"
		memberdata.note = note
		memberdata.onote = officernote
		memberdata.status = status
		memberdata.online = online
		db.toons[name] = memberdata
		addon.displayList[i] = memberdata
	end
	for i = addon.numGuildMembers + 1, #addon.displayList do
		addon.displayList[i] = nil
	end
	addon:updateSorting()
end

function addon:GUILD_ROSTER_UPDATE()
	-- It doesn't appear to be necessary to wait for anything but the first GRU
	-- anymore, but just for good measure, I'm going to wait for the second one.
	if ( addon.GRUs < 2 ) then
		addon.GRUs = addon.GRUs + 1
	else
		-- if we're not in a guild, we don't do anything
		if ( IsInGuild() ) then
			-- Is this the first time we got here with this load? If so, we need to 
			-- go about setting up all our crap
			local GuildName, GuildRankName, GuildRankNum = GetGuildInfo( "player" )
			addon.guild = GuildName
			if ( addon.dataReady == false ) then
				-- Frame Creation stuff here
				addon:CreateSVDB()
				addon:CreateFrames()
				addon:InitializeList()
				addon:SetupOptions()
				scanGuildInfo()
				addon:UpdateFrames()
				addon.dataReady = true
				addon.Print( L["Guild Information is now available"] )
			else
				scanGuildInfo()
				addon:UpdateFrames()
			end
		end
	end
end
		
function addon:OnEnable()
    -- Called when the addon is loaded
	-- Very minimal stuff here since I don't know if I should
	-- load until I know I'm in a guild.

	-- Event listeners
    addon:RegisterEvent("GUILD_ROSTER_UPDATE")
end

--[[
************************************************************************
CHANGELOG:

08/10/09 :
	moved core functions and definitions to new files
5/1/09 : 
	Initial version
************************************************************************
]]--