--[[
************************************************************************
Project				: BetterGuildControl
Author				: zhinjio
Project Revision	: 0.0.1-beta
Project Date		: 20090901082646

File				: BGC_Frames.lua
Commit Author		: zhinjio
Commit Revision		: 19
Commit Date			: 20090901082646
************************************************************************
Description	:
	Frame creation/control file

TODO		:

************************************************************************
(see bottom of file for changelog)
************************************************************************
--]]

local MODNAME = "BetterGuildControl"
local FULLNAME = "BetterGuildControl"

local BetterGuildControl = LibStub( "AceAddon-3.0" ):GetAddon( MODNAME )
local L = LibStub:GetLibrary( "AceLocale-3.0" ):GetLocale( MODNAME )
local LTT = LibStub:GetLibrary( "LibQTip-1.0" )

local addon = BetterGuildControl

-- Scrolling list panel definitions...
local cell_widths = {
	["name"] = 92,
	["rank"] = 105,
	["zone"] = 190,
--	["race"] = 40,
--	["note"] = 195,
	["class"] = 80,
	["level"] = 40,
}
local cell_names = {
	[1] = "name",
	[2] = "rank",
	[3] = "zone",
--	[4] = "race",
--	[4] = "note",
	[4] = "class",
	[5] = "level",
}
-- How many lines in the scrollframe
local NUM_LINES = 27
local PADDING = 6
local lines = {}
-- Permissions constants
local numPerms = 17
local Permissions = {
	 [1] = L["Listen to Guild Chat"],
	 [2] = L["Speak in Guild Chat"],
	 [3] = L["Listen to Officer Chat"],
	 [4] = L["Speak in Officer Chat"],
	 [5] = L["Promote Member"],
	 [6] = L["Demote Member"],
	 [7] = L["Invite Member"],
	 [8] = L["Remove Member"],
	 [9] = L["Set MOTD"],
	[10] = L["Edit Public Note"],
	[11] = L["View Officer Note"],
	[12] = L["Edit Officer Note"],
	[13] = L["Modify Guild Info"],
	[14] = L["Guild Bank Withdraw Repair"],
	[15] = L["Guild Bank Withdraw Gold"],
	[16] = L["Create Guild Event"],
	[17] = L["Withdraw Gold/day"],
}
local tabPerms = {
	 [1] = L["View Tab"],
	 [2] = L["Deposit Item"],
	 [3] = L["Update Tab Text"],
	 [4] = L["Withdraw Stacks/day"],
}
-- define some local upvalues/frames
local GuildListButton, GuildPermButton
local mf, mf_TitleText
local mflist, mflist_headerbox, mflist_header, mflscrollbar
local pf, pfrankIndexTitle, pfrankButtons, pfpermGrid
local pfbankTabs, pfbTab, pftab_permGrid

local list_font = CreateFont(MODNAME.."ListFont")
list_font:SetFont("Fonts\\FRIZQT__.TTF", 11)		-- Hate this font. Good enough for now.

local highlight = CreateFrame("Frame", nil, UIParent)
highlight:SetFrameStrata("TOOLTIP")
highlight._texture = highlight:CreateTexture(nil, "OVERLAY")
highlight._texture:SetTexture("Interface\\BUTTONS\\UI-Listbox-Highlight2")
highlight._texture:SetBlendMode("ADD")
highlight._texture:SetAllPoints(highlight)
highlight:Hide()
-- icons used on permissions frame
local checkicon = "\124TInterface\\RAIDFRAME\\ReadyCheck-Ready:14\124t"
local xicon = "\124TInterface\\RAIDFRAME\\ReadyCheck-NotReady:14\124t"
local naicon = "\124TInterface\\ItemSocketingFrame\\UI-EmptySocket:14\124t"

function addon:ToggleMainPanel()
	if ( mf:IsVisible() ) then
		mf:Hide()
	else
		addon.UpdateFrames()
		mf:Show()
	end
end

local function ShowList(offset)
	if #addon.displayList <= NUM_LINES then
		mflscrollbar:Hide()
	else
		mflscrollbar:Show()
	end
	for i, line in ipairs(lines) do
		entry = addon.displayList[i + offset]
		if entry then
			line.name:SetText( entry.name )
			line.rank:SetText( entry.rank )
			line.zone:SetText( entry.zone )
--			line.race:SetText( entry.race )
			line.class:SetFormattedText("|cff%s|r", addon.CLASS_COLORS[entry.enClass]..entry.class)
			line.level:SetText( entry.level )
--			line.note:SetText( entry.note )
			line:Show()
--[[
			line:EnableMouse(true)
			line:SetScript("OnMouseUp", ListOnMouseUp)
			line:SetScript("OnEnter", ListOnEnter)
			line:SetScript("OnLeave", ListOnLeave)
			]]--
		else
			line:EnableMouse(false)
			line:SetScript("OnMouseUp", nil)
			line:SetScript("OnEnter", nil)
			line:SetScript("OnLeave", nil)
			line:Hide()
		end
	end
end

function addon:CreateFrames()
	-- Very generic frame creation. This will not do *any* setting of options, values
	-- or settings, since we won't know them yet at this point. There will be a subsequent
	-- cell to UpdateFrames that will be called once the db is present, etc.

------------------------------------------------
--------- Stuff used in several frames...
------------------------------------------------		
	local bgData = {
		bgFile = "Interface/AchievementFrame/UI-Achievement-Parchment-Horizontal-Desaturated",
		edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
		tile = false,
		tileSize = 32,
		edgeSize = 8,
		insets = { left = 2, right = 2, top = 2, bottom =2 }
	}
	local bgDataBlank = {
		bgFile = "Interface/GLUES/COMMON/Glue-Tooltip-Background",
		edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
		tile = false,
		tileSize = 32,
		edgeSize = 8,
		insets = { left = 2, right = 2, top = 2, bottom =2 }
	}
	local bgTab = {
--		bgFile = "Interface\\ChatFrame\\ChatFrameTab",
		bgFile = "Interface\\PaperDollInfoFrame\\UI-Character-InactiveTab",
		edgeFile = "",
		tile = false,
		tileSize = 32,
		edgeSize = 8,
		insets = { left = 2, right = 2, top = 2, bottom =2 }
	}
------------------------------------------------
--------- This block is for my top level frame
------------------------------------------------		
	do
		mf = CreateFrame( "Frame", MODNAME .. "_MainFrame", UIParent )
		mf:SetClampedToScreen( false )
		mf:SetHeight( 400 )
		mf:SetWidth( 800 )
		mf:SetPoint( "TOPLEFT", UIParent, "TOPLEFT", 100, -100 )
		mf:EnableMouse( true )
		mf:SetMovable( true )
		mf:SetFrameLevel( 1 )
		mf:SetFrameStrata( "DIALOG" )
		mf:SetHitRectInsets( 2, 5, 4, 4 )
		tinsert( UISpecialFrames, "BetterGuildControl_MainFrame" );
		mf:Hide()
		
		mf:RegisterForDrag( "LeftButton" )
		mf:SetScript( "OnDragStart",
			function(this)
				this:StartMoving()
			end
		)
		mf:SetScript( "OnDragStop", 
			function(this)
				this:StopMovingOrSizing()
				--[[
				eventually, we'll save frame position. For now, screw it
				local db = addon.db.factionrealm[addon.me]
				db.xPos = mf:GetLeft()
				db.yPos = mf:GetTop()
				]]--
			end
		)

		mf:SetBackdrop( bgData )
		mf:SetBackdropColor( 1, 0.7, 0.5, 1 )
		mf:SetBackdropBorderColor( 1, 0.34, 0.21, 1 )

		mf:EnableMouseWheel(1)
		mf:SetScript("OnMouseWheel", function(self, delta)
			local slider = mflscrollbar
			local currentValue = slider:GetValue()
			local minValue, maxValue = slider:GetMinMaxValues()

			if delta < 0 and currentValue < maxValue then
				slider:SetValue(math.min(maxValue, currentValue + 10))
			elseif delta > 0 and currentValue > minValue then
				slider:SetValue(math.max(minValue, currentValue - 10))
			end
		end)
		
		local mf_CloseButton = CreateFrame( "Button", "mf_CloseButton", mf, "UIPanelCloseButton" )
			mf_CloseButton:SetScript( "OnClick",
				function(this)
					this:GetParent():Hide()
				end
			)
			mf_CloseButton:SetPoint( "TOPRIGHT", mf, "TOPRIGHT", 3, 3 )
			mf_CloseButton:SetWidth( 24 )
			mf_CloseButton:SetHeight( 24 )

		mf_TitleText = mf:CreateFontString( "mf_TitleText", "OVERLAY", "GameFontHighlight" )
			mf_TitleText:SetText( "" )
			mf_TitleText:SetPoint( "TOP", mf, "TOP", 0, -3 )
			mf_TitleText:SetHeight( 14 )
			mf_TitleText:SetWidth( 400 )
	end
------------------------------------------------
--------- This block is for the the panel control buttons and such
------------------------------------------------		
	do 
		GuildListButton = addon.CreateMainButton( "GuildListButton", mf, "Spell_Holy_PrayerofSpirit" )
		GuildListButton:SetPoint( "TOPRIGHT", mf, "TOPRIGHT", -18, -18 )
		GuildListButton.switchArg = "guildlist"
		GuildListButton:SetChecked( true )
		GuildPermButton = addon.CreateMainButton( "GuildPermButton", mf, "INV_Misc_PunchCards_Yellow" )
		GuildPermButton:SetPoint( "TOP", GuildListButton, "BOTTOM", 0, -8 )
		GuildPermButton.switchArg = "permissions"
	end
------------------------------------------------
--------- This block is for the guild listing
------------------------------------------------		
	do
		-- Scrollframe stolen from GearGauge - Thanks Torhal
		mflist = CreateFrame( "Frame", MODNAME.."MainFrameList", mf )
		mflist:SetBackdrop( bgDataBlank )
		mflist:SetBackdropColor( 1, 1, 1, 0.5 )
		mflist:SetBackdropBorderColor( 1, 0.34, 0.21, 0.8 )
	--	mflist:SetBackdropColor(GameTooltip:GetBackdropColor())
	--	mflist:SetBackdropBorderColor(GameTooltip:GetBackdropBorderColor())
	--	mflist:SetScale(GameTooltip:GetScale())
		mflist:SetPoint( "TOPLEFT", mf, "TOPLEFT", 8, -45 )
		mflist:SetPoint( "BOTTOMRIGHT", mf, "BOTTOMRIGHT", -70, 8 )
		mflist:SetAlpha(1)
		mflist:SetFrameStrata("DIALOG")
	--	mflist:Hide() 	-- don't hide this one. Its the "default frame" that should show

		-- Column headers box + frame
		mflist_headerbox = CreateFrame( "Frame", nil, mflist )
		mflist_headerbox:SetBackdrop( bgDataBlank )
		mflist_headerbox:SetBackdropColor( 1, 1, 1, 0.5 )
		mflist_headerbox:SetBackdropBorderColor( 1, 0.34, 0.21, 0.8 )
		mflist_headerbox:SetAlpha(1)
		mflist_headerbox:SetHeight(25)
		mflist_headerbox:SetFrameStrata("DIALOG")
		mflist_headerbox:SetPoint( "BOTTOMLEFT", mflist, "TOPLEFT", 0, 1 )
		mflist_headerbox:SetPoint( "BOTTOMRIGHT", mflist, "TOPRIGHT", 0, 1 )
		mflist_headerbox:SetHeight( 25 )

		mflist_header = CreateFrame("Frame", nil, mflist_headerbox)
		mflist_header:SetFrameStrata("DIALOG")
		mflist_header:SetPoint( "TOPLEFT", mflist_headerbox, "TOPLEFT", PADDING, 1 )
		mflist_header:SetPoint( "BOTTOMRIGHT", mflist_headerbox, "BOTTOMRIGHT", -2, -2 )
	-------------------------------------------------------------------------------
	-- List pane scrollbar.
	-------------------------------------------------------------------------------
		mflscrollbar = CreateFrame("Slider", nil, mflist)
		mflscrollbar:SetWidth(12)
		mflscrollbar:SetOrientation("VERTICAL")
		mflscrollbar:SetBackdrop({
						bgFile = "Interface\\Buttons\\UI-SliderBar-Background",
						edgeFile = "Interface\\Buttons\\UI-SliderBar-Border",
						tile = true, tileSize = 8, edgeSize = 8,
						insets = { left = 3, right = 3, top = 3, bottom = 3 }
				  })
		mflscrollbar:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Vertical")
		mflscrollbar:SetMinMaxValues(0, 1)
		mflscrollbar:SetValueStep(1)
		mflscrollbar:SetValue(0)
		mflscrollbar:SetPoint("TOPRIGHT", mflist, "TOPRIGHT", -3, -3)
		mflscrollbar:SetPoint("BOTTOMRIGHT", mflist, "BOTTOMRIGHT", -3, 3)

		mflscrollbar:SetScript("OnValueChanged",
					function(self, value, ...)
						ShowList(math.floor(value))
					end)
	end
------------------------------------------------
--------- This block is for the permissions screen
------------------------------------------------		
	do
		pf = CreateFrame( "Frame", MODNAME.."PermsFrame", mf )
		pf:SetBackdrop( bgDataBlank )
		pf:SetBackdropColor( 1, 1, 1, 0.5 )
		pf:SetBackdropBorderColor( 1, 0.34, 0.21, 0.8 )
		pf:SetPoint( "TOPLEFT", mf, "TOPLEFT", 8, -19 )
		pf:SetPoint( "BOTTOMRIGHT", mf, "BOTTOMRIGHT", -70, 8 )
		pf:SetAlpha(1)
		pf:SetFrameStrata("DIALOG")
		pf:Hide()
		
		local pf_ranklistTitle = pf:CreateFontString( "pf_ranklistTitle", "OVERLAY", "GameFontHighlight" )
			pf_ranklistTitle:SetText( L["Rank Title Listing"] )
			pf_ranklistTitle:SetPoint( "TOPLEFT", pf, "TOPLEFT", 10, -3 )
			pf_ranklistTitle:SetHeight( 14 )
			pf_ranklistTitle:SetWidth( 200 )
			pf_ranklistTitle:SetJustifyH( "LEFT" )
		-- list of Ranks. Make the text a button so they can change them.
		local relative
		pfrankButtons = {}
		pfrankIndexTitle = {}
		pfpermGrid = {}
		pftab_permGrid = {}
		for i = 1, 10 do
			-- Text label
			local pf_rankIndexText = pf:CreateFontString( "pf_rankIndexText"..i, "OVERLAY", "GameFontNormalSmall" )
			pf_rankIndexText:SetText( i )
			pf_rankIndexText:SetHeight( 16 )
			pf_rankIndexText:SetWidth( 20 )
			pf_rankIndexText:SetJustifyH( "RIGHT" )
			if ( i == 1 ) then
				pf_rankIndexText:SetPoint( "TOPLEFT", pf_ranklistTitle, "BOTTOMLEFT", -10, -16 )
			else
				pf_rankIndexText:SetPoint( "TOPLEFT", relative, "BOTTOMLEFT", 0, -1 )
			end
			relative = pf_rankIndexText
			-- Make my button
			local pf_rankButton = addon.CreateButton(
				"pf_rankButton"..i, pf, 16, 170, "LEFT", pf_rankIndexText, "RIGHT", 5, 0,
				"GameFontNormalSmall", "GameFontHighlightSmall",
				"", "CENTER", L["Click to change rank title"], 0 )
			pfrankButtons[i] = pf_rankButton
		end
		local pf_mainpermsTitle = pf:CreateFontString( "pf_mainpermsTitle", "OVERLAY", "GameFontHighlight" )
			pf_mainpermsTitle:SetText( L["Main Permissions by Rank "] )
			pf_mainpermsTitle:SetPoint( "LEFT", pf_ranklistTitle, "RIGHT", 0, 0 )
			pf_mainpermsTitle:SetHeight( 14 )
			pf_mainpermsTitle:SetWidth( 300 )
			pf_mainpermsTitle:SetJustifyH( "CENTER" )
		for i = 1, 10 do
			local pf_permsrankIndex = pf:CreateFontString( "pf_permsrankIndex"..i, "OVERLAY", "GameFontNormalSmall" )
				pf_permsrankIndex:SetText( i )
				pf_permsrankIndex:SetHeight( 16 )
				pf_permsrankIndex:SetWidth( 35 )
				pf_permsrankIndex:SetJustifyH( "RIGHT" )
			if ( i == 1 ) then
				pf_permsrankIndex:SetPoint( "TOPLEFT", pf_mainpermsTitle, "BOTTOMLEFT", 132, -2 )
			else
				pf_permsrankIndex:SetPoint( "LEFT", relative, "RIGHT", 0, 0 )
			end
			relative = pf_permsrankIndex
			pfrankIndexTitle[i] = pf_permsrankIndex
		end
		for i = 1, numPerms do
			local pf_numperText = pf:CreateFontString( "pf_numperText"..i, "OVERLAY", "GameFontNormalSmall" )
				pf_numperText:SetText( Permissions[i] )
				pf_numperText:SetHeight( 13 )
				pf_numperText:SetWidth( 150 )
				pf_numperText:SetJustifyH( "RIGHT" )
			if ( i == 1 ) then
				pf_numperText:SetPoint( "TOPLEFT", pf_mainpermsTitle, "BOTTOMLEFT", -10, -16 )
			else
				pf_numperText:SetPoint( "TOPLEFT", relative, "BOTTOMLEFT", 0, 0 )
			end
			relative = pf_numperText
			local anchor
			pfpermGrid[i] = {}
			for j = 1, 10 do
				local pf_permGridEntry = pf:CreateFontString( "pf_permGridEntry"..i..j, "OVERLAY", "GameFontHighlightSmall" )
					pf_permGridEntry:SetText( "." )
					pf_permGridEntry:SetHeight( 16 )
					pf_permGridEntry:SetWidth( 35 )
					pf_permGridEntry:SetJustifyH( "RIGHT" )
				if ( j == 1 ) then
					pf_permGridEntry:SetPoint( "LEFT", relative, "RIGHT", -7, -1 )
				else
					pf_permGridEntry:SetPoint( "LEFT", anchor, "RIGHT", 0, 0 )
				end
				anchor = pf_permGridEntry
				pfpermGrid[i][j] = pf_permGridEntry
			end
		end
		-- Bank Tab stuff
		pfbankTabs = {}
		pfbTab = {}
		local tabanchor
		-- Since the titles for permissions and rank indeces are the same for each
		-- tab, I'm only going to make them once.
		for i = 1, 4 do
			local pftab_permTitle = pf:CreateFontString( "pftab_permTitle"..i, "OVERLAY", "GameFontNormalSmall" )
				pftab_permTitle:SetText( tabPerms[i] )
				pftab_permTitle:SetHeight( 13 )
				pftab_permTitle:SetWidth( 150 )
				pftab_permTitle:SetJustifyH( "RIGHT" )
			if ( i == 1 ) then
				pftab_permTitle:SetPoint( "TOPLEFT", relative, "BOTTOMLEFT", 0, -8 )
				tabanchor = pftab_permTitle
			else
				pftab_permTitle:SetPoint( "TOPLEFT", relative, "BOTTOMLEFT", 0, 0 )
			end
			relative = pftab_permTitle
		end
		for i = 1, 6 do
			pftab_permGrid[i] = {}
			local pfbanktab = CreateFrame( "Frame", MODNAME.."pfBankTab"..i, pf )
			pfbanktab:SetBackdrop( bgDataBlank )
			pfbanktab:SetBackdropColor( 1, 1, 1, 0.25 )
			pfbanktab:SetBackdropBorderColor( 1, 0.34, 0.21, 0.8 )
			pfbanktab:SetPoint( "TOPLEFT", tabanchor, "TOPRIGHT", 4, 6 )
			pfbanktab:SetPoint( "BOTTOMRIGHT", pf, "BOTTOMRIGHT", -22, 53 )
			pfbanktab:SetAlpha(1)
			pfbanktab:SetFrameStrata("DIALOG")
			if ( i ~= 1 ) then
				pfbanktab:Hide()
			end
			pfbankTabs[i] = pfbanktab
			-- tab textures
--			local pfbtab = CreateFrame( "Frame", MODNAME.."pfbTab"..i, pf )
			local pfbtab = addon.CreateTabButton( MODNAME.."pfbTab"..i, pf, i )
			--[[
			pfbtab:SetBackdrop( bgTab )
			pfbtab:SetBackdropColor( 1, 1, 1, 1 )
			pfbtab:SetBackdropBorderColor( 0, 0, 0, 0 )
			pfbtab:SetAlpha(1)
			pfbtab:SetFrameStrata("DIALOG") ]]--
			if ( i == 1 ) then
				pfbtab:SetPoint( "TOPLEFT", pfbanktab, "BOTTOMLEFT", 4, 5 )
			else
				pfbtab:SetPoint( "TOPLEFT", relative, "TOPRIGHT", 2, 0 )
			end
			relative = pfbtab
			pfbTab[i] = pfbtab
			-- contents of each tab...
			local first
			for j = 1, 4 do
				pftab_permGrid[i][j] = {}
				for k = 1, 10 do
					local pftab_permGridEntry = pfbanktab:CreateFontString( "pftab_permGridEntry"..i..j..k, "OVERLAY", "GameFontHighlightSmall" )
						pftab_permGridEntry:SetText( "." )
						pftab_permGridEntry:SetHeight( 16 )
						pftab_permGridEntry:SetWidth( 35 )
						pftab_permGridEntry:SetJustifyH( "RIGHT" )
					if ( k == 1 ) then
						if ( j == 1 ) then
							pftab_permGridEntry:SetPoint( "TOPLEFT", pfbanktab, "TOPLEFT", -11, -5 )
						else
							pftab_permGridEntry:SetPoint( "TOPLEFT", first, "BOTTOMLEFT", 0, 3 )
						end
						first = pftab_permGridEntry
					else
						pftab_permGridEntry:SetPoint( "LEFT", anchor, "RIGHT", 0, 0 )
					end
					anchor = pftab_permGridEntry
					pftab_permGrid[i][j][k] = pftab_permGridEntry
				end
			end
			
		end
	end
end
	
function addon:switchPanes( frame )
	local switchArg = frame.switchArg
	addon.Debug( "switchArg is " .. switchArg )
	local visibleFrame = {
		["guildlist"] = mflist,
		["permissions"] = pf,
	}
	local checkedButton = {
		["guildlist"] = GuildListButton,
		["permissions"] = GuildPermButton,
	}
	-- Hide and uncheck stuff
	for k, v in pairs( visibleFrame ) do
		local z = checkedButton[k]
		if ( k ~= switchArg ) then
			if ( v ) then v:Hide() end
			if ( z ) then z:SetChecked( false ) end
		end
	end
	-- and show the one we should be showing.
	if ( visibleFrame[switchArg] ) then
		visibleFrame[switchArg]:Show()
	end
end

function addon:switchBankTabs( button )
	local bankTab = button.bankTab
	addon.Debug( "bankTab is " .. bankTab )
	for i = 1, 6 do
		local pfbanktab = pfbankTabs[i]
		if ( i == bankTab ) then
			pfbanktab:Show()
		else
			pfbanktab:Hide()
		end
	end
end

function addon:UpdateFrames()
	-- This function will go through the frame values and make sure they match
	-- the current db settings, etc.
	
	local version = GetAddOnMetadata(MODNAME, "Version")
	version = string.gsub(version, "@project.version@", " - Development")
	mf_TitleText:SetText( FULLNAME .. " - " .. version )
	-- Repopulate/calibrate the slider	
	if ( #addon.displayList > NUM_LINES ) then
		mflscrollbar:SetMinMaxValues(0, (#addon.displayList - NUM_LINES ) )
	end
	local value = mflscrollbar:GetValue()
	ShowList(math.floor(value))
	-- Permissions button, rank text
	for i = 1, 10 do
		local pfrb = pfrankButtons[i]
		if ( i <= addon.numGuildRanks ) then
			local aGRI = addon.GuildRanks[i]
			addon.Debug( aGRI.Name )
			pfrb:SetText( aGRI.Name .. " ( " .. aGRI.Count .. " )" )
			pfrb:Enable()
		else
			addon.Debug( i )
			pfrb:SetText( " " )
			pfrb:Disable()
		end
	end
	-- Set the rank titles to grey text if the rank doesn't exist
	for i = 1, 10 do
		if ( i > addon.numGuildRanks ) then
			pfrankIndexTitle[i]:SetText( Grey( i ) )
		end
	end
	-- Set the check or x icons in the grid
	for i = 1, numPerms do
		for j = 1, 10 do
			if ( j > addon.numGuildRanks ) then
				if ( i == 17 ) then
					pfpermGrid[i][j]:SetText( Grey( L["n/a"] ) )
				else
					pfpermGrid[i][j]:SetText( naicon )
				end
			else
				if ( i == 17 ) then
					pfpermGrid[i][j]:SetText( addon.GuildRanks[j][i] )
				else
					if( addon.GuildRanks[j][i] == 1 ) then
						pfpermGrid[i][j]:SetText( checkicon )
					else
						pfpermGrid[i][j]:SetText( xicon )
					end
				end
			end
		end
	end
	-- Set the Bank tab permissions stuff
	for i = 1, 6 do
		-- for now, only do the first tab:
		if ( i > addon.numGuildBankTabs ) then
			pfbTab[i].text:SetText( Grey ( i ) )
			pfbTab[i]:Disable()
		else
			pfbTab[i].text:SetText( i )
			pfbTab[i]:Enable()
			for j = 1, 4 do
				for k = 1, 10 do
					if ( k > addon.numGuildRanks ) then
						if ( j == 4 ) then
							pftab_permGrid[i][j][k]:SetText( Grey( L["n/a"] ) )
						else
							pftab_permGrid[i][j][k]:SetText( naicon )
						end
					else
						local blort = addon.BankTab[k][i][j]
						if ( j == 4 ) then
							pftab_permGrid[i][j][k]:SetText( blort )
						else
							if ( blort == 1 ) then
								pftab_permGrid[i][j][k]:SetText( checkicon )
							else
								pftab_permGrid[i][j][k]:SetText( xicon )
							end
						end
					end
				end
			end
		end
	end
	-- The GL permissions should always be "n/a". Set those by hand...
	pfpermGrid[17][1]:SetText( Grey( L["n/a"] ) )
	for i = 1, 6 do pftab_permGrid[i][4][1]:SetText( Grey( L["n/a"] ) ) end
end

-- small routine to handle the header rows being clickable to set sorting method
function MakeClickable( frame, cell )
	frame.arg = cell
	frame:EnableMouse(true)
	frame:SetScript( "OnEnter", function( frame )
		highlight:SetParent( frame )
		highlight:SetAllPoints( frame )
		highlight:Show()
	end )
	frame:SetScript( "OnLeave", function()
		highlight:Hide()
		highlight:ClearAllPoints()
		highlight:SetParent(nil)
	end )
	frame:SetScript( "OnMouseUp", function( frame, button )
		addon.sortMethod = frame.arg
		if ( button == "RightButton" ) then
			addon.sortAscend = 0
		else
			addon.sortAscend = 1
		end
		addon.updateSorting()
		addon.UpdateFrames()
	end )
end
-------------------------------------------------------------------------------
-- Initialization functions
-------------------------------------------------------------------------------
-- Creates the lines and cells for the list panel, and normalizes the cell widths.
function addon:InitializeList()
	local function SetFormattedCellText(self, format, ...)
		local fs = self._string

		fs:SetJustifyH("LEFT")
		fs:SetFormattedText(tostring(format), ...)
		fs:SetPoint("TOPLEFT", self, "TOPLEFT", 0, 0)
		fs:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", 0, 0)
		fs:Show()

		local width = fs:GetStringWidth()
		local name = self._name

		if width > cell_widths[name] then
			addon.Debug(string.format("Changing a width - %s, from %d to %d.", name, cell_widths[name], width))
			cell_widths[name] = width
		else
			width = cell_widths[name]
		end
		self:SetWidth(width)

		local height = fs:GetHeight()
		self:SetHeight(height)

		local parent = self:GetParent()

		if height > parent.height then
			parent.height = height
			parent:SetHeight(height)
		end
	end

	local function SetCellText(self, value)
		local fs = self._string

		fs:SetJustifyH("LEFT")
		fs:SetText(tostring(value))
		fs:SetPoint("TOPLEFT", self, "TOPLEFT", 0, 0)
		fs:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", 0, 0)
		fs:Show()

		local width = fs:GetStringWidth()
		local name = self._name

		if width > cell_widths[name] then
			addon.Debug(string.format("Changing a width - %s, from %d to %d.", name, cell_widths[name], width))
			cell_widths[name] = width
		else
			width = cell_widths[name]
		end
		self:SetWidth(width)

		local height = fs:GetHeight()
		self:SetHeight(height)

		local parent = self:GetParent()

		if height > parent.height then
			parent.height = height
			parent:SetHeight(height)
		end
	end

	local function CreateLineCells(line, font)
		line.height = 1
		local cell, relative

		for idx, name in ipairs(cell_names) do
			cell = CreateFrame("Frame", nil, line)
			cell:SetPoint("TOP", line)
			cell:SetPoint("BOTTOM", line)

			if relative then
				cell:SetPoint("LEFT", relative, "RIGHT", PADDING, 0)
			else
				cell:SetPoint("LEFT", line, "LEFT", 0, 0)
			end
			local fstring = cell:CreateFontString()
			fstring:SetFontObject(font)

			cell._string = fstring
			cell._name = name
			cell.SetText = SetCellText
			cell.SetFormattedText = SetFormattedCellText
			cell:Show()

			line[name] = cell
			relative = cell
		end
	end
	local anchor

	for i = 1, NUM_LINES do
		local line = CreateFrame("Frame", nil, mflist)

		if anchor then
			line:SetPoint("TOP", anchor, "BOTTOM", 0, -1)
		else
			line:SetPoint("TOP", mflist, "TOP", 0, -5)
		end
		line:SetPoint("LEFT", mflist, "LEFT", PADDING + 2, 0)
		line:SetPoint("RIGHT", mflist, "RIGHT", -PADDING - 10, 0)

		CreateLineCells(line, list_font)
		anchor = line
		lines[i] = line
	end
	-- Initialize the list header.
	CreateLineCells(mflist_header, GameTooltipHeaderText)
	mflist_header.name:SetText( L["Name"] )
	MakeClickable( mflist_header.name, "name" )
	mflist_header.rank:SetText( L["Rank"] )
	MakeClickable( mflist_header.rank, "rankIndex" )
	mflist_header.zone:SetText( L["Zone"] )
	MakeClickable( mflist_header.zone, "zone" )
--	mflist_header.note:SetText( L["Note"] )
--	MakeClickable( mflist_header.note, "note" )
--	mflist_header.race:SetText( L["Race"] )
	mflist_header.class:SetText( L["Class"] )
	MakeClickable( mflist_header.class, "class" )
	mflist_header.level:SetText( L["Level"] )
	MakeClickable( mflist_header.level, "level" )
	self.InitializeList = nil
end

--[[
************************************************************************
CHANGELOG:

08/12/09 : 
	Initial version
************************************************************************
]]--