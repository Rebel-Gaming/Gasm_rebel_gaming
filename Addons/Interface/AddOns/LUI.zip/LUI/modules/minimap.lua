--[[
	Project....: LUI NextGenWoWUserInterface
	File.......: minimap.lua
	Description: Minimap Module
	Version....: 1.0
	Rev Date...: 08/07/2010
]] 

local LUI = LibStub("AceAddon-3.0"):GetAddon("LUI")
local LSM = LibStub("LibSharedMedia-3.0")
local widgetLists = AceGUIWidgetLSMlists
local LUIHook = LUI:GetModule("LUIHook")
local module = LUI:NewModule("Minimap", "AceHook-3.0")

local hooks = { }
local shouldntSetPoint = false
local numHookedCaptureFrames = 0

function LUIHook:OnEnable()
	self:SecureHook(DurabilityFrame, "SetPoint", "DurabilityFrame_SetPoint")
	self:SecureHook(VehicleSeatIndicator, "SetPoint", "VehicleSeatIndicator_SetPoint")
	self:SecureHook(WatchFrame, "SetPoint", "WatchFrame_SetPoint")
	self:SecureHook(WorldStateAlwaysUpFrame, "SetPoint", "WorldStateAlwaysUpFrame_SetPoint")
	self:SecureHook(TicketStatusFrame, "SetPoint", "TicketStatusFrame_SetPoint")
	self:SecureHook("WorldStateAlwaysUpFrame_Update")
end

function module:SetPosition(frame)
	shouldntSetPoint = true
	
	if frame == "worldState" then
		WorldStateAlwaysUpFrame:SetPoint("TOP", UIParent, "TOP", db.Minimap.AlwaysUpFrameX, db.Minimap.AlwaysUpFrameY)
	elseif frame == "vehicleSeats" then
		VehicleSeatIndicator:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", db.Minimap.VehicleSeatIndicatorX, db.Minimap.VehicleSeatIndicatorY)
	elseif frame == "durability" then
		DurabilityFrame:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", db.Minimap.DurabilityFrameX, db.Minimap.DurabilityFrameY)
	elseif frame == "questWatch" then
		WatchFrame:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", db.Minimap.WatchFrameX, db.Minimap.WatchFrameY)
	elseif frame == "ticketStatus" then
		TicketStatusFrame:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", db.Minimap.TicketX, db.Minimap.TicketY)
	elseif frame == "capture" then
		for i = 1, NUM_EXTENDED_UI_FRAMES do
			_G["WorldStateCaptureBar" .. i]:ClearAllPoints()
			_G["WorldStateCaptureBar" .. i]:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", db.Minimap.CaptureX, db.Minimap.CaptureY)
		end
	end
	
	shouldntSetPoint = false
end

function LUIHook:DurabilityFrame_SetPoint()
	if shouldntSetPoint then return end
	module:SetPosition('durability')
end

function LUIHook:WatchFrame_SetPoint()
	if shouldntSetPoint then return end
	module:SetPosition('questWatch')
end

function LUIHook:VehicleSeatIndicator_SetPoint()
	if shouldntSetPoint then return end
	module:SetPosition('vehicleSeats')
end

function LUIHook:WorldStateAlwaysUpFrame_SetPoint()
	if shouldntSetPoint then return end
	module:SetPosition('worldState')
end

function LUIHook:WorldStateCaptureBar_SetPoint()
	if shouldntSetPoint then return end
	module:SetPosition('capture')
end

function LUIHook:TicketStatusFrame_SetPoint()
	if shouldntSetPoint then return end
	module:SetPosition('ticketStatus')
end

function LUIHook:WorldStateAlwaysUpFrame_Update()
	while numHookedCaptureFrames < NUM_EXTENDED_UI_FRAMES do
		numHookedCaptureFrames = numHookedCaptureFrames + 1

		self:SecureHook(_G["WorldStateCaptureBar" .. numHookedCaptureFrames], "SetPoint", "WorldStateCaptureBar_SetPoint")
		self:WorldStateCaptureBar_SetPoint()
	end
end

function module:SetColors()
	local minimap_r, minimap_g, minimap_b, minimap_a = unpack(db.Colors.minimap)
	
	fminimap_border3:SetBackdropBorderColor(minimap_r,minimap_g,minimap_b,minimap_a)
	fminimap_border5:SetBackdropBorderColor(minimap_r,minimap_g,minimap_b,minimap_a)
	fminimap_border7:SetBackdropBorderColor(minimap_r,minimap_g,minimap_b,minimap_a)
	fminimap_border9:SetBackdropBorderColor(minimap_r,minimap_g,minimap_b,minimap_a)
end

function module:SetMinimapFrames()
	if db.Minimap.ShowTextures == true then
		local glowTex = LUI_Media.glowTex
		local minimap_r, minimap_g, minimap_b, minimap_a = unpack(db.Colors.minimap)
		
		local fminimap_border2 = LUI:CreateMeAFrame("FRAME","fminimap_border2",Minimap,143,143,1,"BACKGROUND",2,"CENTER",Minimap,"CENTER",0,0,1)
		fminimap_border2:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile=glowTex, tile=0, tileSize=0, edgeSize=7, insets={left=0, right=0, top=0, bottom=0}})
		fminimap_border2:SetBackdropColor(color_r,color_g,color_b,0)
		fminimap_border2:SetBackdropBorderColor(0,0,0,1)
		fminimap_border2:Show()
	
		local fminimap_border3 = LUI:CreateMeAFrame("FRAME","fminimap_border3",Minimap,50,50,1,"BACKGROUND",1,"BOTTOMLEFT",Minimap,"BOTTOMLEFT",-7,-7,1)
		fminimap_border3:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile=glowTex, tile=0, tileSize=0, edgeSize=4, insets={left=3, right=3, top=3, bottom=3}})
		fminimap_border3:SetBackdropColor(minimap_r,minimap_g,minimap_b,0)
		fminimap_border3:SetBackdropBorderColor(minimap_r,minimap_g,minimap_b,minimap_a)
		fminimap_border3:Show()  
	
		local fminimap_border4 = LUI:CreateMeAFrame("FRAME","fminimap_border4",Minimap,56,56,1,"BACKGROUND",0,"BOTTOMLEFT",Minimap,"BOTTOMLEFT",-10,-10,1)
		fminimap_border4:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile=glowTex, tile=0, tileSize=0, edgeSize=6, insets={left=3, right=3, top=3, bottom=3}})
		fminimap_border4:SetBackdropColor(color_r,color_g,color_b,0)
		fminimap_border4:SetBackdropBorderColor(0,0,0,1)
		fminimap_border4:Show() 
		
		local fminimap_border5 = LUI:CreateMeAFrame("FRAME","fminimap_border5",Minimap,50,50,1,"BACKGROUND",1,"BOTTOMRIGHT",Minimap,"BOTTOMRIGHT",7,-7,1)
		fminimap_border5:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile=glowTex, tile=0, tileSize=0, edgeSize=4, insets={left=3, right=3, top=3, bottom=3}})
		fminimap_border5:SetBackdropColor(minimap_r,minimap_g,minimap_b,0)
		fminimap_border5:SetBackdropBorderColor(minimap_r,minimap_g,minimap_b,minimap_a)
		fminimap_border5:Show()  
	
		local fminimap_border6 = LUI:CreateMeAFrame("FRAME","fminimap_border6",Minimap,56,56,1,"BACKGROUND",0,"BOTTOMRIGHT",Minimap,"BOTTOMRIGHT",10,-10,1)
		fminimap_border6:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile=glowTex, tile=0, tileSize=0, edgeSize=6, insets={left=3, right=3, top=3, bottom=3}})
		fminimap_border6:SetBackdropColor(color_r,color_g,color_b,0)
		fminimap_border6:SetBackdropBorderColor(0,0,0,1)
		fminimap_border6:Show() 
		
		local fminimap_border7 = LUI:CreateMeAFrame("FRAME","fminimap_border7",Minimap,50,50,1,"BACKGROUND",1,"TOPRIGHT",Minimap,"TOPRIGHT",7,7,1)
		fminimap_border7:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile=glowTex, tile=0, tileSize=0, edgeSize=4, insets={left=3, right=3, top=3, bottom=3}})
		fminimap_border7:SetBackdropColor(minimap_r,minimap_g,minimap_b,0)
		fminimap_border7:SetBackdropBorderColor(minimap_r,minimap_g,minimap_b,minimap_a)
		fminimap_border7:Show()  
	
		local fminimap_border8 = LUI:CreateMeAFrame("FRAME","fminimap_border8",Minimap,56,56,1,"BACKGROUND",0,"TOPRIGHT",Minimap,"TOPRIGHT",10,10,1)
		fminimap_border8:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile=glowTex, tile=0, tileSize=0, edgeSize=6, insets={left=3, right=3, top=3, bottom=3}})
		fminimap_border8:SetBackdropColor(color_r,color_g,color_b,0)
		fminimap_border8:SetBackdropBorderColor(0,0,0,1)
		fminimap_border8:Show() 
	
		local fminimap_border9 = LUI:CreateMeAFrame("FRAME","fminimap_border9",Minimap,50,50,1,"BACKGROUND",1,"TOPLEFT",Minimap,"TOPLEFT",-7,7,1)
		fminimap_border9:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile=glowTex, tile=0, tileSize=0, edgeSize=4, insets={left=3, right=3, top=3, bottom=3}})
		fminimap_border9:SetBackdropColor(minimap_r,minimap_g,minimap_b,0)
		fminimap_border9:SetBackdropBorderColor(minimap_r,minimap_g,minimap_b,minimap_a)
		fminimap_border9:Show()  
	
		local fminimap_border9 = LUI:CreateMeAFrame("FRAME","fminimap_border9",Minimap,56,56,1,"BACKGROUND",0,"TOPLEFT",Minimap,"TOPLEFT",-10,10,1)
		fminimap_border9:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile=glowTex, tile=0, tileSize=0, edgeSize=6, insets={left=3, right=3, top=3, bottom=3}})
		fminimap_border9:SetBackdropColor(color_r,color_g,color_b,0)
		fminimap_border9:SetBackdropBorderColor(0,0,0,1)
		fminimap_border9:Show()
	end
	
	local minimaptimerout, minimaptimerin = 0,0
	local minimap_timer = 0.3
	
	local MinimapAlphaIn = CreateFrame("Frame", "MinimapAlphaIn", UIParent)
	MinimapAlphaIn:Hide()
	MinimapAlphaIn:SetScript("OnUpdate", function(self,elapsed)
		minimaptimerin = minimaptimerin + elapsed
		Minimap:Show()
		if minimaptimerin < minimap_timer then
			local alpha = minimaptimerin / minimap_timer
			Minimap:SetAlpha(alpha)
		else
			Minimap:SetAlpha(1)
			minimaptimerin = 0
			self:Hide()
		end
	end)
	
	local MinimapAlphaOut = CreateFrame("Frame", "MinimapAlphaOut", UIParent)
	MinimapAlphaOut:Hide()
	MinimapAlphaOut:SetScript("OnUpdate", function(self,elapsed)
		minimaptimerout = minimaptimerout + elapsed
		if minimaptimerout < minimap_timer then
			local alpha = 1 - minimaptimerout / minimap_timer
			Minimap:SetAlpha(alpha)
		else
			Minimap:SetAlpha(0)
			Minimap:Hide()
			minimaptimerout = 0
			self:Hide()
		end
	end)
end

function module:SetMinimap()
	if db.Minimap.Enable ~= true then return end

	self:SetMinimapFrames()
	self:SetPosition('durability')
	self:SetPosition('questWatch')
	self:SetPosition('vehicleSeats')
	self:SetPosition('worldState')
	self:SetPosition('capture')
	self:SetPosition('ticketStatus')
	
	local FONT = LSM:Fetch("font", db.Info.Bags.Font)

	--------------------------------------------------------------------
	-- MINIMAP SETTINGS
	--------------------------------------------------------------------

	Minimap:ClearAllPoints()
	Minimap:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", LUI:Scale(-24), LUI:Scale(-80))
	Minimap:SetSize(LUI:Scale(135), LUI:Scale(135))

	-- Hide Border
	MinimapBorder:Hide()
	MinimapBorderTop:Hide()

	-- Hide Zoom Buttons
	MinimapZoomIn:Hide()
	MinimapZoomOut:Hide()
		
	-- GuildInstanceDifficulty
	GuildInstanceDifficulty:UnregisterAllEvents()
	GuildInstanceDifficulty.NewShow = MiniMapInstanceDifficulty.Show
	GuildInstanceDifficulty.Show = GuildInstanceDifficulty.Hide
	GuildInstanceDifficulty:Hide()
	
	MiniMapInstanceDifficulty.NewShow = MiniMapInstanceDifficulty.Show
	MiniMapInstanceDifficulty.Show = MiniMapInstanceDifficulty.Hide
	MiniMapInstanceDifficulty:Hide()
	
	-- Hide Voice Chat Frame
	MiniMapVoiceChatFrame:Hide()

	-- Hide North texture at top
	MinimapNorthTag:SetTexture(nil)
	
	-- Hide Zone Frame
	MinimapZoneTextButton:Hide()

	-- Hide Clock
	TimeManagerClockButton:Hide()
	LUI:Kill(TimeManagerClockButton)

	-- Hide Tracking Button
	MiniMapTracking:Hide()

	-- Hide Calendar Button
	GameTimeFrame:Hide()

	-- Hide Mail Button
	MiniMapMailFrame:ClearAllPoints()
	MiniMapMailFrame:SetPoint("TOPRIGHT", Minimap, LUI:Scale(3), LUI:Scale(4))
	MiniMapMailBorder:Hide()
	MiniMapMailIcon:SetTexture(LUI_Media.mail)

	-- Move battleground icon
	MiniMapBattlefieldFrame:ClearAllPoints()
	MiniMapBattlefieldFrame:SetPoint("BOTTOMRIGHT", Minimap, LUI:Scale(3), 0)
	MiniMapBattlefieldBorder:Hide()

	-- Hide world map button
	MiniMapWorldMapButton:Hide()

	-- shitty 3.3 flag to move
	MiniMapInstanceDifficulty:ClearAllPoints()
	MiniMapInstanceDifficulty:SetParent(Minimap)
	MiniMapInstanceDifficulty:SetPoint("TOPLEFT", Minimap, "TOPLEFT", 0, 0)

	local function UpdateLFG()
		MiniMapLFGFrame:ClearAllPoints()
		MiniMapLFGFrame:SetPoint("BOTTOMRIGHT", Minimap, "BOTTOMRIGHT", LUI:Scale(2), LUI:Scale(1))
		MiniMapLFGFrameBorder:Hide()
	end
	hooksecurefunc("MiniMapLFG_UpdateIsShown", UpdateLFG)

	-- Enable mouse scrolling
	Minimap:EnableMouseWheel(true)
	Minimap:SetScript("OnMouseWheel", function(self, d)
		if d > 0 then
			_G.MinimapZoomIn:Click()
		elseif d < 0 then
			_G.MinimapZoomOut:Click()
		end
	end)

	----------------------------------------------------------------------------------------
	-- Right click menu
	----------------------------------------------------------------------------------------

	local menuFrame = CreateFrame("Frame", "MinimapRightClickMenu", UIParent, "UIDropDownMenuTemplate")
	local menuList = {
		{text = CHARACTER_BUTTON,
		func = function() ToggleCharacter("PaperDollFrame") end},
		{text = SPELLBOOK_ABILITIES_BUTTON,
		func = function() ToggleFrame(SpellBookFrame) end},
		{text = TALENTS_BUTTON,
		func = function() ToggleTalentFrame() end},
		{text = ACHIEVEMENT_BUTTON,
		func = function() ToggleAchievementFrame() end},
		{text = QUESTLOG_BUTTON,
		func = function() ToggleFrame(QuestLogFrame) end},
		{text = SOCIAL_BUTTON,
		func = function() ToggleFriendsFrame(1) end},
		{text = PLAYER_V_PLAYER,
		func = function() ToggleFrame(PVPFrame) end},
		{text = ACHIEVEMENTS_GUILD_TAB,
		func = function() if IsInGuild() then if not GuildFrame then LoadAddOn("Blizzard_GuildUI") end GuildFrame_Toggle() end end},
		{text = LFG_TITLE,
		func = function() ToggleFrame(LFDParentFrame) end},
		{text = L_LFRAID,
		func = function() ToggleFrame(LFRParentFrame) end},
		{text = HELP_BUTTON,
		func = function() ToggleHelpFrame() end},
		{text = L_CALENDAR,
		func = function()
		if(not CalendarFrame) then LoadAddOn("Blizzard_Calendar") end
			Calendar_Toggle()
		end},
	}

	Minimap:SetScript("OnMouseUp", function(self, btn)
		if btn == "RightButton" then
			ToggleDropDownMenu(1, nil, MiniMapTrackingDropDown, self)
		elseif btn == "MiddleButton" then
			EasyMenu(menuList, menuFrame, "cursor", 0, 0, "MENU", 2)
		else
			Minimap_OnClick(self)
		end
	end)


	-- Set Square Map Mask
	Minimap:SetMaskTexture('Interface\\ChatFrame\\ChatFrameBackground')

	-- For others mods with a minimap button, set minimap buttons position in square mode.
	function GetMinimapShape() return 'SQUARE' end

	-- reskin LFG dropdown
	LFDSearchStatus:SetBackdrop({
	  bgFile = LUI_Media.blank, 
	  edgeFile = LUI_Media.blank, 
	  tile = false, tileSize = 0, edgeSize = mult, 
	  insets = { left = 0, right = 0, top = 0, bottom = 0}
	})
	LFDSearchStatus:SetBackdropColor(.1,.1,.1,1)
	LFDSearchStatus:SetBackdropBorderColor(.6,.6,.6,1)

	----------------------------------------------------------------------------------------
	-- Animation Coords and Current Zone. Awesome feature by AlleyKat.
	----------------------------------------------------------------------------------------
	 
	--Style Zone and Coord panels
	local m_zone = CreateFrame("Frame",nil,UIParent)
	LUI:CreatePanel(m_zone, 0, 20, "TOPLEFT", Minimap, "TOPLEFT",LUI:Scale(2),LUI:Scale(-2))
	m_zone:SetFrameLevel(5)
	m_zone:SetFrameStrata("LOW")
	m_zone:SetPoint("TOPRIGHT",Minimap,-2,-2)
	m_zone:Hide()
	
	local m_zone_text = m_zone:CreateFontString(nil,"Overlay")
	m_zone_text:SetFont(FONT,12)
	m_zone_text:SetPoint("Center",0,0)
	m_zone_text:SetJustifyH("CENTER")
	m_zone_text:SetJustifyV("MIDDLE")
	m_zone_text:SetHeight(LUI:Scale(12))
	m_zone_text:SetWidth(m_zone:GetWidth()-6)

	local m_coord = CreateFrame("Frame",nil,UIParent)
	LUI:CreatePanel(m_coord, 40, 20, "BOTTOMLEFT", Minimap, "BOTTOMLEFT",LUI:Scale(2),LUI:Scale(2))
	m_coord:SetFrameStrata("LOW")
	m_coord:Hide()

	local m_coord_text = m_coord:CreateFontString(nil,"Overlay")
	m_coord_text:SetFont(FONT,12)
	m_coord_text:SetPoint("Center",LUI:Scale(-1),0)
	m_coord_text:SetJustifyH("CENTER")
	m_coord_text:SetJustifyV("MIDDLE")
	m_coord_text:SetText("00,00")
	
	m_coord:SetScript("OnUpdate", function(self)
		local x,y = GetPlayerMapPosition("player")
		local xt,yt
		x = math.floor(100 * x)
		y = math.floor(100 * y)
		if x == 0 and y == 0 then
			m_coord_text:SetText("X _ X")
		else
			if x < 10 then
				xt = "0"..x
			else
				xt = x
			end
			if y < 10 then
				yt = "0"..y
			else
				yt = y
			end
			m_coord_text:SetText(xt..","..yt)
		end
	end)
	
	m_zone:SetScript("OnUpdate", function(self)
		local pvp = GetZonePVPInfo()
		m_zone_text:SetText(GetMinimapZoneText())
		if pvp == "friendly" then
			m_zone_text:SetTextColor(0.1, 1.0, 0.1)
		elseif pvp == "sanctuary" then
			m_zone_text:SetTextColor(0.41, 0.8, 0.94)
		elseif pvp == "arena" or pvp == "hostile" then
			m_zone_text:SetTextColor(1.0, 0.1, 0.1)
		elseif pvp == "contested" then
			m_zone_text:SetTextColor(1.0, 0.7, 0.0)
		else
			m_zone_text:SetTextColor(1.0, 1.0, 1.0)
		end
	end)
	
	-- Set Scripts and etc.
	Minimap:SetScript("OnEnter",function()
		m_zone:Show()
		m_coord:Show()
	end)
	 
	Minimap:SetScript("OnLeave",function()
		m_zone:Hide()
		m_coord:Hide()
	end)

end

local defaults = {
	Minimap = {
		Enable = true,
		ShowTextures = true,
		AlwaysUpFrameX = "300",
		AlwaysUpFrameY = "-35",
		VehicleSeatIndicatorX = "-10",
		VehicleSeatIndicatorY = "-225",
		DurabilityFrameX = "-20",
		DurabilityFrameY = "-220",
		WatchFrameX = "-100",
		WatchFrameY = "-300",
		Boss1TargetFrameX = "-20",
		Boss1TargetFrameY = "-150",
		CaptureX = "-5",
		CaptureY = "-205",
		TicketX = "-175",
		TicketY = "-70",
	},
}

function module:LoadOptions()
	local options = {
		Minimap = {
			name = "Minimap",
			type = "group",
			order = 40,
			disabled = function() return not db.Minimap.Enable end,
			childGroups = "select",
			args = {
				ShowTextures = {
					name = "Show Minimap Textures",
					desc = "Whether you want to show the Minimap Textures or not.\n",
					disabled = function() return not db.Minimap.Enable end,
					type = "toggle",
					width = "full",
					get = function() return db.Minimap.ShowTextures end,
					set = function(self, ShowTextures)
								db.Minimap.ShowTextures = not db.Minimap.ShowTextures
								StaticPopup_Show("RELOAD_UI")
							end,
					order = 1,
				},
				AlwaysUpFrame = {
					name = "AlwaysUpFrame",
					type = "group",
					disabled = function() return not db.Minimap.Enable end,
					order = 2,
					args = {
						AlwaysUpFrameText = {
							order = 3,
							width = "full",
							type = "description",
							name = "This Frame occurs in Battlegrounds, Thousendwinter and Instances. Example: Attempts left in Icecrown.",
						},
						AlwaysUpFrameX = {
							name = "X Value",
							desc = "X Value for your AlwaysUpFrame.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Minimap.AlwaysUpFrameX,
							type = "input",
							get = function() return db.Minimap.AlwaysUpFrameX end,
							set = function(self,AlwaysUpFrameX)
										if AlwaysUpFrameX == nil or AlwaysUpFrameX == "" then
											AlwaysUpFrameX = "0"
										end
										db.Minimap.AlwaysUpFrameX = AlwaysUpFrameX
										module:SetPosition("worldState")
									end,
							order = 4,
						},
						AlwaysUpFrameY = {
							name = "Y Value",
							desc = "Y Value for your AlwaysUpFrame.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.Minimap.AlwaysUpFrameY,
							type = "input",
							get = function() return db.Minimap.AlwaysUpFrameY end,
							set = function(self,AlwaysUpFrameY)
										if AlwaysUpFrameY == nil or AlwaysUpFrameY == "" then
											AlwaysUpFrameY = "0"
										end
										db.Minimap.AlwaysUpFrameY = AlwaysUpFrameY
										module:SetPosition("worldState")
									end,
							order = 5,
						},
					},
				},
				VehicleSeatIndicator = {
					name = "VehicleSeatIndicator",
					type = "group",
					disabled = function() return not db.Minimap.Enable end,
					order = 3,
					args = {
						VehicleSeatIndicatorText = {
							order = 9,
							width = "full",
							type = "description",
							name = "This Frame occurs in some special Mounts and Vehicles. Example: Traveler's Tundra Mammoth.",
						},
						VehicleSeatIndicatorX = {
							name = "X Value",
							desc = "X Value for your VehicleSeatIndicator.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Minimap.VehicleSeatIndicatorX,
							type = "input",
							get = function() return db.Minimap.VehicleSeatIndicatorX end,
							set = function(self,VehicleSeatIndicatorX)
										if VehicleSeatIndicatorX == nil or VehicleSeatIndicatorX == "" then
											VehicleSeatIndicatorX = "0"
										end
										db.Minimap.VehicleSeatIndicatorX = VehicleSeatIndicatorX
										module:SetPosition("vehicleSeats")
									end,
							order = 10,
						},
						VehicleSeatIndicatorY = {
							name = "Y Value",
							desc = "Y Value for your VehicleSeatIndicator.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.Minimap.VehicleSeatIndicatorY,
							type = "input",
							get = function() return db.Minimap.VehicleSeatIndicatorY end,
							set = function(self,VehicleSeatIndicatorY)
										if VehicleSeatIndicatorY == nil or VehicleSeatIndicatorY == "" then
											VehicleSeatIndicatorY = "0"
										end
										db.Minimap.VehicleSeatIndicatorY = VehicleSeatIndicatorY
										module:SetPosition("vehicleSeats")
									end,
							order = 11,
						},
					},
				},
				DurabilityFrame = {
					name = "DurabilityFrame",
					type = "group",
					disabled = function() return not db.Minimap.Enable end,
					order = 5,
					args = {
						DurabilityFrameX = {
							name = "X Value",
							desc = "X Value for your DurabilityFrame.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Minimap.DurabilityFrameX,
							type = "input",
							get = function() return db.Minimap.DurabilityFrameX end,
							set = function(self,DurabilityFrameX)
										if DurabilityFrameX == nil or DurabilityFrameX == "" then
											DurabilityFrameX = "0"
										end
										db.Minimap.DurabilityFrameX = DurabilityFrameX
										module:SetPosition("durability")
									end,
							order = 15,
						},
						DurabilityFrameY = {
							name = "Y Value",
							desc = "Y Value for your DurabilityFrame.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.Minimap.DurabilityFrameY,
							type = "input",
							get = function() return db.Minimap.DurabilityFrameY end,
							set = function(self,DurabilityFrameY)
										if DurabilityFrameY == nil or DurabilityFrameY == "" then
											DurabilityFrameY = "0"
										end
										db.Minimap.DurabilityFrameY = DurabilityFrameY
										module:SetPosition("durability")
									end,
							order = 16,
						},
					},
				},
				WatchFrame = {
					name = "WatchFrame",
					type = "group",
					disabled = function() return not db.Minimap.Enable end,
					order = 6,
					args = {
						WatchFrameText = {
							order = 20,
							width = "full",
							type = "description",
							name = "This Frame occurs when tracking Quests and Achievements.",
						},
						WatchFrameX = {
							name = "X Value",
							desc = "X Value for your WatchFrame.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Minimap.WatchFrameX,
							type = "input",
							get = function() return db.Minimap.WatchFrameX end,
							set = function(self,WatchFrameX)
										if WatchFrameX == nil or WatchFrameX == "" then
											WatchFrameX = "0"
										end
										db.Minimap.WatchFrameX = WatchFrameX
										module:SetPosition("questWatch")
									end,
							order = 21,
						},
						WatchFrameY = {
							name = "Y Value",
							desc = "Y Value for your WatchFrame.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.Minimap.WatchFrameY,
							type = "input",
							get = function() return db.Minimap.WatchFrameY end,
							set = function(self,WatchFrameY)
										if WatchFrameY == nil or WatchFrameY == "" then
											WatchFrameY = "0"
										end
										db.Minimap.WatchFrameY = WatchFrameY
										module:SetPosition("questWatch")
									end,
							order = 22,
						},
					},
				},
				TicketStatus = {
					name = "Ticket Status",
					type = "group",
					disabled = function() return not db.Minimap.Enable end,
					order = 7,
					args = {
						TicketX = {
							name = "X Value",
							desc = "X Value for your Ticket Status.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Minimap.TicketX,
							type = "input",
							get = function() return db.Minimap.TicketX end,
							set = function(self,TicketX)
										if TicketX == nil or TicketX == "" then
											TicketX = "0"
										end
										db.Minimap.TicketX = TicketX
										module:SetPosition("ticketStatus")
									end,
							order = 1,
						},
						TicketY = {
							name = "Y Value",
							desc = "Y Value for your Ticket Status.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.Minimap.TicketY,
							type = "input",
							get = function() return db.Minimap.TicketY end,
							set = function(self,TicketY)
										if TicketY == nil or TicketY == "" then
											TicketY = "0"
										end
										db.Minimap.TicketY = TicketY
										module:SetPosition("ticketStatus")
									end,
							order = 2,
						},
						spacer = {
							order = 3,
							width = "full",
							type = "description",
							name = " "
						},
						ShowTicket = {
							order = 4,
							type = "execute",
							name = "Show/Hide",
							func = function()
								if TicketStatusFrame:IsShown() then
									TicketStatusFrame:Hide()
								else
									TicketStatusFrame:Show()
								end
							end,
						},
					},
				},
				CaptureBar = {
					name = "Capture Bar",
					type = "group",
					disabled = function() return not db.Minimap.Enable end,
					order = 8,
					args = {
						CaptureX = {
							name = "X Value",
							desc = "X Value for your Capture Bar.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Minimap.CaptureX,
							type = "input",
							get = function() return db.Minimap.CaptureX end,
							set = function(self,CaptureX)
										if CaptureX == nil or CaptureX == "" then
											CaptureX = "0"
										end
										db.Minimap.CaptureX = CaptureX
										module:SetPosition("capture")
									end,
							order = 1,
						},
						CaptureY = {
							name = "Y Value",
							desc = "Y Value for your Capture Bar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.Minimap.CaptureY,
							type = "input",
							get = function() return db.Minimap.CaptureY end,
							set = function(self,CaptureY)
										if CaptureY == nil or CaptureY == "" then
											CaptureY = "0"
										end
										db.Minimap.CaptureY = CaptureY
										module:SetPosition("capture")
									end,
							order = 2,
						},
					},
				},
			},
		},
	}

	return options
end

function module:LoadModule()
	local module = {
		Minimap = {
			order = LUI:GetModuleCount(),
			type = "execute",
			name = function()
				if db.Minimap.Enable then
					return "|cff00ff00Minimap Enabled|r"
				else
					return "|cffFF0000Minimap Disabled|r"
				end
			end,
			func = function(self, Minimap)
				db.Minimap.Enable = not db.Minimap.Enable
				StaticPopup_Show("RELOAD_UI")
			end,
		},
	}
	
	return module
end

function module:OnInitialize()

	LUI:MergeDefaults(LUI.db.defaults.profile, defaults)
	LUI:RefreshDefaults()
	LUI:Refresh()
	
	self.db = LUI.db.profile
	db = self.db
end

function module:OnEnable()
	LUI:RegisterOptions(self:LoadOptions())
	LUI:RegisterModule(self:LoadModule())
	self:SetMinimap()
end
