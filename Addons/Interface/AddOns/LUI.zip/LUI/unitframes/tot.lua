--[[
	Project....: LUI NextGenWoWUserInterface
	File.......: tot.lua
	Description: oUF Target's Target Module
	Version....: 1.0
]] 

local LUI = LibStub("AceAddon-3.0"):GetAddon("LUI")
local module = LUI:NewModule("oUF_ToT")
local LSM = LibStub("LibSharedMedia-3.0")
local widgetLists = AceGUIWidgetLSMlists

local positions = {"TOP", "TOPRIGHT", "TOPLEFT","BOTTOM", "BOTTOMRIGHT", "BOTTOMLEFT","RIGHT", "LEFT", "CENTER"}
local fontflags = {'OUTLINE', 'THICKOUTLINE', 'MONOCHROME', 'NONE'}
local valueFormat = {'Absolut', 'Absolut & Percent', 'Absolut Short', 'Absolut Short & Percent', 'Standard', 'Standard Short'}
local nameFormat = {'Name', 'Name + Level', 'Name + Level + Class', 'Name + Level + Race + Class', 'Level + Name', 'Level + Name + Class', 'Level + Class + Name', 'Level + Name + Race + Class', 'Level + Race + Class + Name'}
local nameLenghts = {'Short', 'Medium', 'Long'}
local growthY = {"UP", "DOWN"}
local growthX = {"LEFT", "RIGHT"}

local defaults = {
	ToT = {
		Enable = true,
		Height = "24",
		Width = "200",
		X = "435",
		Y = "-250",
		Border = {
			EdgeFile = "glow",
			EdgeSize = 5,
			Insets = {
				Left = "3",
				Right = "3",
				Top = "3",
				Bottom = "3",
			},
			Color = {
				r = "0",
				g = "0",
				b = "0",
				a = "1",
			},
		},
		Backdrop = {
			Texture = "Blizzard Tooltip",
			Padding = {
				Left = "-4",
				Right = "4",
				Top = "4",
				Bottom = "-4",
			},
			Color = {
				r = 0,
				g = 0,
				b = 0,
				a = 1,
			},
		},
		Health = {
			Height = "24",
			Padding = "0",
			ColorClass = true,
			ColorGradient = false,
			Texture = "LUI_Gradient",
			TextureBG = "LUI_Gradient",
			BGAlpha = 1,
			BGMultiplier = 0.4,
			Smooth = true,
			IndividualColor = {
				Enable = false,
				r = 0.3,
				g = 0.3,
				b = 0.3,
			},
		},
		Power = {
			Enable = false,
			Height = "5",
			Padding = "-2",
			ColorClass = false,
			ColorType = true,
			Texture = "LUI_Minimalist",
			TextureBG = "LUI_Minimalist",
			BGAlpha = 1,
			BGMultiplier = 0.4,
			Smooth = true,
			IndividualColor = {
				Enable = false,
				r = 0.8,
				g = 0.8,
				b = 0.8,
			},
		},
		Full = {
			Enable = false,
			Height = "11",
			Texture = "LUI_Minimalist",
			Padding = "-7",
			Alpha = 1,
			Color = {
				r = "0.11",
				g = "0.11",
				b = "0.11",
				a = "1",
			},
		},
		Aura = {
			buffs_playeronly = false,
			buffs_enable = false,
			buffs_auratimer = false,
			buffsX = "-0.5",
			buffsY = "30",
			buffs_initialAnchor = "TOPLEFT",
			buffs_growthY = "UP",
			buffs_growthX = "RIGHT",
			buffs_size = "26",
			buffs_spacing = "2",
			buffs_num = "36",
			debuffs_colorbytype = false,
			debuffs_enable = false,
			debuffs_auratimer = false,
			debuffsX = "-0.5",
			debuffsY = "60",
			debuffs_initialAnchor = "TOPRIGHT",
			debuffs_growthY = "UP",
			debuffs_growthX = "LEFT",
			debuffs_size = "26",
			debuffs_spacing = "2",
			debuffs_num = "36",
		},
		Portrait = {
			Enable = false,
			Height = "43",
			Width = "90",
			X = "0",
			Y = "0",
		},
		Icons = {
			Lootmaster = {
				Enable = false,
				Size = 15,
				X = "16",
				Y = "10",
				Point = "TOPLEFT",
			},
			Leader = {
				Enable = false,
				Size = 17,
				X = "0",
				Y = "10",
				Point = "TOPLEFT",
			},
			Role = {
				Enable = false,
				Size = 22,
				X = "15",
				Y = "10",
				Point = "TOPRIGHT",
			},
			Raid = {
				Enable = true,
				Size = 55,
				X = "0",
				Y = "0",
				Point = "CENTER",
			},
			Resting = {
				Enable = false,
				Size = 27,
				X = "-12",
				Y = "13",
				Point = "TOPLEFT",
			},
			Combat = {
				Enable = false,
				Size = 27,
				X = "-15",
				Y = "-30",
				Point = "BOTTOMLEFT",
			},
			PvP = {
				Enable = false,
				Size = 35,
				X = "-12",
				Y = "10",
				Point = "TOPLEFT",
			},
		},
		Texts = {
			Name = {
				Enable = true,
				Font = "Prototype",
				Size = 15,
				X = "5",
				Y = "0",
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "LEFT",
				RelativePoint = "LEFT",
				Format = "Name",
				Length = "Medium",
				ColorNameByClass = false,
				ColorClassByClass = false,
				ColorLevelByDifficulty = false,
				ShowClassification = false,
				ShortClassification = false,
			},
			Health = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "-43",
				ColorClass = false,
				ColorGradient = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "BOTTOMLEFT",
				RelativePoint = "BOTTOMRIGHT",
				Format = "Absolut Short",
				ShowDead = false,
			},
			Power = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "-66",
				ColorClass = true,
				ColorType = false,
				IndividualColor = {
					Enable = false,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "BOTTOMLEFT",
				RelativePoint = "BOTTOMRIGHT",
				Format = "Absolut Short",
			},
			HealthPercent = {
				Enable = true,
				Font = "Prototype",
				Size = 14,
				X = "-5",
				Y = "0",
				ShowAlways = false,
				ColorClass = false,
				ColorGradient = false,
				IndividualColor = {
					Enable = true,
					r = "1",
					g = "1",
					b = "1",
				},
				Outline = "NONE",
				Point = "RIGHT",
				RelativePoint = "RIGHT",
				ShowDead = false,
			},
			PowerPercent = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "0",
				ShowAlways = false,
				ColorClass = false,
				ColorType = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "CENTER",
				RelativePoint = "CENTER",
			},
			HealthMissing = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "0",
				ShortValue = true,
				ShowAlways = false,
				ColorClass = false,
				ColorGradient = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "RIGHT",
				RelativePoint = "RIGHT",
			},
			PowerMissing = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "0",
				ShortValue = true,
				ShowAlways = false,
				ColorClass = false,
				ColorType = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "RIGHT",
				RelativePoint = "RIGHT",
			},
		},
	},	
}

function module:LoadOptions()
	local options = {
		ToT = {
			name = "ToT",
			type = "group",
			disabled = function() return not db.oUF.Settings.Enable end,
			order = 6,
			childGroups = "tab",
			args = {
				header1 = {
					name = "ToT",
					type = "header",
					order = 1,
				},
				General = {
					name = "General",
					type = "group",
					childGroups = "tab",
					order = 2,
					args = {
						General = {
							name = "General",
							type = "group",
							order = 0,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to use a ToT Frame or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Enable end,
									set = function(self,Enable)
												db.oUF.ToT.Enable = not db.oUF.ToT.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
							},
						},
						Positioning = {
							name = "Positioning",
							type = "group",
							disabled = function() return not db.oUF.ToT.Enable end,
							order = 1,
							args = {
								header1 = {
									name = "Frame Position",
									type = "header",
									order = 1,
								},
								ToTX = {
									name = "X Value",
									desc = "X Value for your ToT Frame.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.X,
									type = "input",
									get = function() return db.oUF.ToT.X end,
									set = function(self,ToTX)
												if ToTX == nil or ToTX == "" then
													ToTX = "0"
												end
												db.oUF.ToT.X = ToTX
												oUF_LUI_targettarget:SetPoint("CENTER", UIParent, "CENTER", tonumber(ToTX), tonumber(db.oUF.ToT.Y))
											end,
									order = 2,
								},
								ToTY = {
									name = "Y Value",
									desc = "Y Value for your ToT Frame.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Y,
									type = "input",
									get = function() return db.oUF.ToT.Y end,
									set = function(self,ToTY)
												if ToTY == nil or ToTY == "" then
													ToTY = "0"
												end
												db.oUF.ToT.Y = ToTY
												oUF_LUI_targettarget:SetPoint("CENTER", UIParent, "CENTER", tonumber(db.oUF.ToT.X), tonumber(ToTY))
											end,
									order = 3,
								},
							},
						},
						Size = {
							name = "Size",
							type = "group",
							order = 2,
							disabled = function() return not db.oUF.ToT.Enable end,
							args = {
								header1 = {
									name = "Frame Height/Width",
									type = "header",
									order = 1,
								},
								ToTHeight = {
									name = "Height",
									desc = "Decide the Height of your ToT Frame.\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Height,
									type = "input",
									get = function() return db.oUF.ToT.Height end,
									set = function(self,ToTHeight)
												if ToTHeight == nil or ToTHeight == "" then
													ToTHeight = "0"
												end
												db.oUF.ToT.Height = ToTHeight
												oUF_LUI_targettarget:SetHeight(tonumber(ToTHeight))
											end,
									order = 2,
								},
								ToTWidth = {
									name = "Width",
									desc = "Decide the Width of your ToT Frame.\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Width,
									type = "input",
									get = function() return db.oUF.ToT.Width end,
									set = function(self,ToTWidth)
												if ToTWidth == nil or ToTWidth == "" then
													ToTWidth = "0"
												end
												db.oUF.ToT.Width = ToTWidth
												oUF_LUI_targettarget:SetWidth(tonumber(ToTWidth))
												
												if db.oUF.ToT.Aura.buffs_enable == true then
													oUF_LUI_targettarget.Buffs:SetWidth(tonumber(ToTWidth))
												end
												
												if db.oUF.ToT.Aura.debuffs_enable == true then
													oUF_LUI_targettarget.Debuffs:SetWidth(tonumber(ToTWidth))
												end
											end,
									order = 3,
								},
							},
						},
						Appearance = {
							name = "Appearance",
							type = "group",
							disabled = function() return not db.oUF.ToT.Enable end,
							order = 3,
							args = {
								header1 = {
									name = "Backdrop Colors",
									type = "header",
									order = 1,
								},
								BackdropColor = {
									name = "Color",
									desc = "Choose a Backdrop Color.",
									type = "color",
									width = "full",
									hasAlpha = true,
									get = function() return db.oUF.ToT.Backdrop.Color.r, db.oUF.ToT.Backdrop.Color.g, db.oUF.ToT.Backdrop.Color.b, db.oUF.ToT.Backdrop.Color.a end,
									set = function(_,r,g,b,a)
											db.oUF.ToT.Backdrop.Color.r = r
											db.oUF.ToT.Backdrop.Color.g = g
											db.oUF.ToT.Backdrop.Color.b = b
											db.oUF.ToT.Backdrop.Color.a = a

											oUF_LUI_targettarget.FrameBackdrop:SetBackdropColor(r,g,b,a)
										end,
									order = 2,
								},
								BackdropBorderColor = {
									name = "Border Color",
									desc = "Choose a Backdrop Border Color.",
									type = "color",
									width = "full",
									hasAlpha = true,
									get = function() return db.oUF.ToT.Border.Color.r, db.oUF.ToT.Border.Color.g, db.oUF.ToT.Border.Color.b, db.oUF.ToT.Border.Color.a end,
									set = function(_,r,g,b,a)
											db.oUF.ToT.Border.Color.r = r
											db.oUF.ToT.Border.Color.g = g
											db.oUF.ToT.Border.Color.b = b
											db.oUF.ToT.Border.Color.a = a
											
											oUF_LUI_targettarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.ToT.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.ToT.Border.EdgeFile), edgeSize = tonumber(db.oUF.ToT.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.ToT.Border.Insets.Left), right = tonumber(db.oUF.ToT.Border.Insets.Right), top = tonumber(db.oUF.ToT.Border.Insets.Top), bottom = tonumber(db.oUF.ToT.Border.Insets.Bottom)}
											})
											
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.ToT.Backdrop.Color.r), tonumber(db.oUF.ToT.Backdrop.Color.g), tonumber(db.oUF.ToT.Backdrop.Color.b), tonumber(db.oUF.ToT.Backdrop.Color.a))
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.ToT.Border.Color.r), tonumber(db.oUF.ToT.Border.Color.g), tonumber(db.oUF.ToT.Border.Color.b), tonumber(db.oUF.ToT.Border.Color.a))
										end,
									order = 3,
								},
								header2 = {
									name = "Backdrop Settings",
									type = "header",
									order = 4,
								},
								BackdropTexture = {
									name = "Backdrop Texture",
									desc = "Choose your Backdrop Texture!\nDefault: "..LUI.defaults.profile.oUF.ToT.Backdrop.Texture,
									type = "select",
									dialogControl = "LSM30_Background",
									values = widgetLists.background,
									get = function() return db.oUF.ToT.Backdrop.Texture end,
									set = function(self, BackdropTexture)
											db.oUF.ToT.Backdrop.Texture = BackdropTexture
											oUF_LUI_targettarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.ToT.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.ToT.Border.EdgeFile), edgeSize = tonumber(db.oUF.ToT.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.ToT.Border.Insets.Left), right = tonumber(db.oUF.ToT.Border.Insets.Right), top = tonumber(db.oUF.ToT.Border.Insets.Top), bottom = tonumber(db.oUF.ToT.Border.Insets.Bottom)}
											})
											
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.ToT.Backdrop.Color.r), tonumber(db.oUF.ToT.Backdrop.Color.g), tonumber(db.oUF.ToT.Backdrop.Color.b), tonumber(db.oUF.ToT.Backdrop.Color.a))
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.ToT.Border.Color.r), tonumber(db.oUF.ToT.Border.Color.g), tonumber(db.oUF.ToT.Border.Color.b), tonumber(db.oUF.ToT.Border.Color.a))
										end,
									order = 5,
								},
								BorderTexture = {
									name = "Border Texture",
									desc = "Choose your Border Texture!\nDefault: "..LUI.defaults.profile.oUF.ToT.Border.EdgeFile,
									type = "select",
									dialogControl = "LSM30_Border",
									values = widgetLists.border,
									get = function() return db.oUF.ToT.Border.EdgeFile end,
									set = function(self, BorderTexture)
											db.oUF.ToT.Border.EdgeFile = BorderTexture
											oUF_LUI_targettarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.ToT.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.ToT.Border.EdgeFile), edgeSize = tonumber(db.oUF.ToT.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.ToT.Border.Insets.Left), right = tonumber(db.oUF.ToT.Border.Insets.Right), top = tonumber(db.oUF.ToT.Border.Insets.Top), bottom = tonumber(db.oUF.ToT.Border.Insets.Bottom)}
											})
											
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.ToT.Backdrop.Color.r), tonumber(db.oUF.ToT.Backdrop.Color.g), tonumber(db.oUF.ToT.Backdrop.Color.b), tonumber(db.oUF.ToT.Backdrop.Color.a))
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.ToT.Border.Color.r), tonumber(db.oUF.ToT.Border.Color.g), tonumber(db.oUF.ToT.Border.Color.b), tonumber(db.oUF.ToT.Border.Color.a))
										end,
									order = 6,
								},
								BorderSize = {
									name = "Edge Size",
									desc = "Choose the Edge Size for your Frame Border.\nDefault: "..LUI.defaults.profile.oUF.ToT.Border.EdgeSize,
									type = "range",
									min = 1,
									max = 50,
									step = 1,
									get = function() return db.oUF.ToT.Border.EdgeSize end,
									set = function(_, BorderSize) 
											db.oUF.ToT.Border.EdgeSize = BorderSize
											oUF_LUI_targettarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.ToT.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.ToT.Border.EdgeFile), edgeSize = tonumber(db.oUF.ToT.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.ToT.Border.Insets.Left), right = tonumber(db.oUF.ToT.Border.Insets.Right), top = tonumber(db.oUF.ToT.Border.Insets.Top), bottom = tonumber(db.oUF.ToT.Border.Insets.Bottom)}
											})
											
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.ToT.Backdrop.Color.r), tonumber(db.oUF.ToT.Backdrop.Color.g), tonumber(db.oUF.ToT.Backdrop.Color.b), tonumber(db.oUF.ToT.Backdrop.Color.a))
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.ToT.Border.Color.r), tonumber(db.oUF.ToT.Border.Color.g), tonumber(db.oUF.ToT.Border.Color.b), tonumber(db.oUF.ToT.Border.Color.a))
										end,
									order = 7,
								},
								header3 = {
									name = "Backdrop Padding",
									type = "header",
									order = 8,
								},
								PaddingLeft = {
									name = "Left",
									desc = "Value for the Left Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.ToT.Backdrop.Padding.Left,
									type = "input",
									width = "half",
									get = function() return db.oUF.ToT.Backdrop.Padding.Left end,
									set = function(self,PaddingLeft)
										if PaddingLeft == nil or PaddingLeft == "" then
											PaddingLeft = "0"
										end
										db.oUF.ToT.Backdrop.Padding.Left = PaddingLeft
										oUF_LUI_targettarget.FrameBackdrop:ClearAllPoints()
										oUF_LUI_targettarget.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_targettarget, "TOPLEFT", tonumber(db.oUF.ToT.Backdrop.Padding.Left), tonumber(db.oUF.ToT.Backdrop.Padding.Top))
										oUF_LUI_targettarget.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_targettarget, "BOTTOMRIGHT", tonumber(db.oUF.ToT.Backdrop.Padding.Right), tonumber(db.oUF.ToT.Backdrop.Padding.Bottom))
									end,
									order = 9,
								},
								PaddingRight = {
									name = "Right",
									desc = "Value for the Right Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.ToT.Backdrop.Padding.Right,
									type = "input",
									width = "half",
									get = function() return db.oUF.ToT.Backdrop.Padding.Right end,
									set = function(self,PaddingRight)
										if PaddingRight == nil or PaddingRight == "" then
											PaddingRight = "0"
										end
										db.oUF.ToT.Backdrop.Padding.Right = PaddingRight
										oUF_LUI_targettarget.FrameBackdrop:ClearAllPoints()
										oUF_LUI_targettarget.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_targettarget, "TOPLEFT", tonumber(db.oUF.ToT.Backdrop.Padding.Left), tonumber(db.oUF.ToT.Backdrop.Padding.Top))
										oUF_LUI_targettarget.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_targettarget, "BOTTOMRIGHT", tonumber(db.oUF.ToT.Backdrop.Padding.Right), tonumber(db.oUF.ToT.Backdrop.Padding.Bottom))
									end,
									order = 10,
								},
								PaddingTop = {
									name = "Top",
									desc = "Value for the Top Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.ToT.Backdrop.Padding.Top,
									type = "input",
									width = "half",
									get = function() return db.oUF.ToT.Backdrop.Padding.Top end,
									set = function(self,PaddingTop)
										if PaddingTop == nil or PaddingTop == "" then
											PaddingTop = "0"
										end
										db.oUF.ToT.Backdrop.Padding.Top = PaddingTop
										oUF_LUI_targettarget.FrameBackdrop:ClearAllPoints()
										oUF_LUI_targettarget.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_targettarget, "TOPLEFT", tonumber(db.oUF.ToT.Backdrop.Padding.Left), tonumber(db.oUF.ToT.Backdrop.Padding.Top))
										oUF_LUI_targettarget.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_targettarget, "BOTTOMRIGHT", tonumber(db.oUF.ToT.Backdrop.Padding.Right), tonumber(db.oUF.ToT.Backdrop.Padding.Bottom))
									end,
									order = 11,
								},
								PaddingBottom = {
									name = "Bottom",
									desc = "Value for the Bottom Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.ToT.Backdrop.Padding.Bottom,
									type = "input",
									width = "half",
									get = function() return db.oUF.ToT.Backdrop.Padding.Bottom end,
									set = function(self,PaddingBottom)
										if PaddingBottom == nil or PaddingBottom == "" then
											PaddingBottom = "0"
										end
										db.oUF.ToT.Backdrop.Padding.Bottom = PaddingBottom
										oUF_LUI_targettarget.FrameBackdrop:ClearAllPoints()
										oUF_LUI_targettarget.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_targettarget, "TOPLEFT", tonumber(db.oUF.ToT.Backdrop.Padding.Left), tonumber(db.oUF.ToT.Backdrop.Padding.Top))
										oUF_LUI_targettarget.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_targettarget, "BOTTOMRIGHT", tonumber(db.oUF.ToT.Backdrop.Padding.Right), tonumber(db.oUF.ToT.Backdrop.Padding.Bottom))
									end,
									order = 12,
								},
								header4 = {
									name = "Boder Insets",
									type = "header",
									order = 13,
								},
								InsetLeft = {
									name = "Left",
									desc = "Value for the Left Border Inset\nDefault: "..LUI.defaults.profile.oUF.ToT.Border.Insets.Left,
									type = "input",
									width = "half",
									get = function() return db.oUF.ToT.Border.Insets.Left end,
									set = function(self,InsetLeft)
										if InsetLeft == nil or InsetLeft == "" then
											InsetLeft = "0"
										end
										db.oUF.ToT.Border.Insets.Left = InsetLeft
										oUF_LUI_targettarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.ToT.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.ToT.Border.EdgeFile), edgeSize = tonumber(db.oUF.ToT.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.ToT.Border.Insets.Left), right = tonumber(db.oUF.ToT.Border.Insets.Right), top = tonumber(db.oUF.ToT.Border.Insets.Top), bottom = tonumber(db.oUF.ToT.Border.Insets.Bottom)}
											})
											
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.ToT.Backdrop.Color.r), tonumber(db.oUF.ToT.Backdrop.Color.g), tonumber(db.oUF.ToT.Backdrop.Color.b), tonumber(db.oUF.ToT.Backdrop.Color.a))
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.ToT.Border.Color.r), tonumber(db.oUF.ToT.Border.Color.g), tonumber(db.oUF.ToT.Border.Color.b), tonumber(db.oUF.ToT.Border.Color.a))
											end,
									order = 14,
								},
								InsetRight = {
									name = "Right",
									desc = "Value for the Right Border Inset\nDefault: "..LUI.defaults.profile.oUF.ToT.Border.Insets.Right,
									type = "input",
									width = "half",
									get = function() return db.oUF.ToT.Border.Insets.Right end,
									set = function(self,InsetRight)
										if InsetRight == nil or InsetRight == "" then
											InsetRight = "0"
										end
										db.oUF.ToT.Border.Insets.Right = InsetRight
										oUF_LUI_targettarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.ToT.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.ToT.Border.EdgeFile), edgeSize = tonumber(db.oUF.ToT.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.ToT.Border.Insets.Left), right = tonumber(db.oUF.ToT.Border.Insets.Right), top = tonumber(db.oUF.ToT.Border.Insets.Top), bottom = tonumber(db.oUF.ToT.Border.Insets.Bottom)}
											})
											
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.ToT.Backdrop.Color.r), tonumber(db.oUF.ToT.Backdrop.Color.g), tonumber(db.oUF.ToT.Backdrop.Color.b), tonumber(db.oUF.ToT.Backdrop.Color.a))
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.ToT.Border.Color.r), tonumber(db.oUF.ToT.Border.Color.g), tonumber(db.oUF.ToT.Border.Color.b), tonumber(db.oUF.ToT.Border.Color.a))
											end,
									order = 15,
								},
								InsetTop = {
									name = "Top",
									desc = "Value for the Top Border Inset\nDefault: "..LUI.defaults.profile.oUF.ToT.Border.Insets.Top,
									type = "input",
									width = "half",
									get = function() return db.oUF.ToT.Border.Insets.Top end,
									set = function(self,InsetTop)
										if InsetTop == nil or InsetTop == "" then
											InsetTop = "0"
										end
										db.oUF.ToT.Border.Insets.Top = InsetTop
										oUF_LUI_targettarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.ToT.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.ToT.Border.EdgeFile), edgeSize = tonumber(db.oUF.ToT.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.ToT.Border.Insets.Left), right = tonumber(db.oUF.ToT.Border.Insets.Right), top = tonumber(db.oUF.ToT.Border.Insets.Top), bottom = tonumber(db.oUF.ToT.Border.Insets.Bottom)}
											})
											
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.ToT.Backdrop.Color.r), tonumber(db.oUF.ToT.Backdrop.Color.g), tonumber(db.oUF.ToT.Backdrop.Color.b), tonumber(db.oUF.ToT.Backdrop.Color.a))
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.ToT.Border.Color.r), tonumber(db.oUF.ToT.Border.Color.g), tonumber(db.oUF.ToT.Border.Color.b), tonumber(db.oUF.ToT.Border.Color.a))
											end,
									order = 16,
								},
								InsetBottom = {
									name = "Bottom",
									desc = "Value for the Bottom Border Inset\nDefault: "..LUI.defaults.profile.oUF.ToT.Border.Insets.Bottom,
									type = "input",
									width = "half",
									get = function() return db.oUF.ToT.Border.Insets.Bottom end,
									set = function(self,InsetBottom)
										if InsetBottom == nil or InsetBottom == "" then
											InsetBottom = "0"
										end
										db.oUF.ToT.Border.Insets.Bottom = InsetBottom
										oUF_LUI_targettarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.ToT.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.ToT.Border.EdgeFile), edgeSize = tonumber(db.oUF.ToT.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.ToT.Border.Insets.Left), right = tonumber(db.oUF.ToT.Border.Insets.Right), top = tonumber(db.oUF.ToT.Border.Insets.Top), bottom = tonumber(db.oUF.ToT.Border.Insets.Bottom)}
											})
											
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.ToT.Backdrop.Color.r), tonumber(db.oUF.ToT.Backdrop.Color.g), tonumber(db.oUF.ToT.Backdrop.Color.b), tonumber(db.oUF.ToT.Backdrop.Color.a))
											oUF_LUI_targettarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.ToT.Border.Color.r), tonumber(db.oUF.ToT.Border.Color.g), tonumber(db.oUF.ToT.Border.Color.b), tonumber(db.oUF.ToT.Border.Color.a))
											end,
									order = 17,
								},
							},
						},
						AlphaFader = {
							name = "Fader",
							type = "group",
							order = 4,
							disabled = function() return not db.oUF.ToT.Enable end,
							args = {
								empty = {
									order = 1,
									width = "full",
									type = "description",
									name = "\n\n    coming soon...",
								},
							},
						},
					},
				},
				Bars = {
					name = "Bars",
					type = "group",
					childGroups = "tab",
					disabled = function() return not db.oUF.ToT.Enable end,
					order = 3,
					args = {
						Health = {
							name = "Health",
							type = "group",
							order = 1,
							args = {
								General = {
									name = "General Settings",
									type = "group",
									guiInline = true,
									order = 1,
									args = {
										Height = {
											name = "Height",
											desc = "Decide the Height of your ToT Health.\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Health.Height,
											type = "input",
											get = function() return db.oUF.ToT.Health.Height end,
											set = function(self,Height)
														if Height == nil or Height == "" then
															Height = "0"
														end
														db.oUF.ToT.Health.Height = Height
														oUF_LUI_targettarget.Health:SetHeight(tonumber(Height))
													end,
											order = 1,
										},
										Padding = {
											name = "Padding",
											desc = "Choose the Padding between Health & Powerbar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Health.Padding,
											type = "input",
											get = function() return db.oUF.ToT.Health.Padding end,
											set = function(self,Padding)
														if Padding == nil or Padding == "" then
															Padding = "0"
														end
														db.oUF.ToT.Health.Padding = Padding
														oUF_LUI_targettarget.Health:ClearAllPoints()
														oUF_LUI_targettarget.Health:SetPoint("TOPLEFT", oUF_LUI_targettarget, "TOPLEFT", 0, tonumber(Padding))
														oUF_LUI_targettarget.Health:SetPoint("TOPRIGHT", oUF_LUI_targettarget, "TOPRIGHT", 0, tonumber(Padding))
													end,
											order = 2,
										},
										Smooth = {
											name = "Enable Smooth Bar Animation",
											desc = "Wether you want to use Smooth Animations or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.ToT.Health.Smooth end,
											set = function(self,Smooth)
														db.oUF.ToT.Health.Smooth = not db.oUF.ToT.Health.Smooth
														StaticPopup_Show("RELOAD_UI")
													end,
											order = 3,
										},
									}
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									guiInline = true,
									order = 2,
									args = {
										HealthClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored HealthBars or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Health.ColorClass end,
											set = function(self,HealthClassColor)
														db.oUF.ToT.Health.ColorClass = not db.oUF.ToT.Health.ColorClass
														if HealthClassColor == true then
															db.oUF.ToT.Health.ColorGradient = false
															db.oUF.ToT.Health.IndividualColor.Enable = false
															
															print("ToT Healthbar Color will change once you gain/lose HP")
														end
													end,
											order = 1,
										},
										HealthGradientColor = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored HealthBars or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Health.ColorGradient end,
											set = function(self,HealthGradientColor)
														db.oUF.ToT.Health.ColorGradient = not db.oUF.ToT.Health.ColorGradient
														if HealthGradientColor == true then
															db.oUF.ToT.Health.ColorClass = false
															db.oUF.ToT.Health.IndividualColor.Enable = false
															
															print("ToT Healthbar Color will change once you gain/lose HP")
														end
													end,
											order = 2,
										},
										IndividualHealthColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual HealthBar Color or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Health.IndividualColor.Enable end,
											set = function(self,IndividualHealthColor)
														db.oUF.ToT.Health.IndividualColor.Enable = not db.oUF.ToT.Health.IndividualColor.Enable
														if IndividualHealthColor == true then
															db.oUF.ToT.Health.ColorClass = false
															db.oUF.ToT.Health.ColorGradient = false
															
															oUF_LUI_targettarget.Health:SetStatusBarColor(db.oUF.ToT.Health.IndividualColor.r, db.oUF.ToT.Health.IndividualColor.g, db.oUF.ToT.Health.IndividualColor.b)
															oUF_LUI_targettarget.Health.bg:SetVertexColor(db.oUF.ToT.Health.IndividualColor.r*tonumber(db.oUF.ToT.Health.BGMultiplier), db.oUF.ToT.Health.IndividualColor.g*tonumber(db.oUF.ToT.Health.BGMultiplier), db.oUF.ToT.Health.IndividualColor.b*tonumber(db.oUF.ToT.Health.BGMultiplier))
														end
													end,
											order = 3,
										},
										HealthColor = {
											name = "Individual Color",
											desc = "Choose an individual Healthbar Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.ToT.Health.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.ToT.Health.IndividualColor.r, db.oUF.ToT.Health.IndividualColor.g, db.oUF.ToT.Health.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.ToT.Health.IndividualColor.r = r
													db.oUF.ToT.Health.IndividualColor.g = g
													db.oUF.ToT.Health.IndividualColor.b = b
													
													oUF_LUI_targettarget.Health:SetStatusBarColor(r, g, b)
													oUF_LUI_targettarget.Health.bg:SetVertexColor(r*tonumber(db.oUF.ToT.Health.BGMultiplier), g*tonumber(db.oUF.ToT.Health.BGMultiplier), b*tonumber(db.oUF.ToT.Health.BGMultiplier))
												end,
											order = 4,
										},
									},
								},
								Textures = {
									name = "Texture Settings",
									type = "group",
									guiInline = true,
									order = 3,
									args = {
										HealthTex = {
											name = "Texture",
											desc = "Choose your Health Texture!\nDefault: "..LUI.defaults.profile.oUF.ToT.Health.Texture,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.ToT.Health.Texture
												end,
											set = function(self, HealthTex)
													db.oUF.ToT.Health.Texture = HealthTex
													oUF_LUI_targettarget.Health:SetStatusBarTexture(LSM:Fetch("statusbar", HealthTex))
												end,
											order = 1,
										},
										HealthTexBG = {
											name = "Background Texture",
											desc = "Choose your Health Background Texture!\nDefault: "..LUI.defaults.profile.oUF.ToT.Health.TextureBG,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.ToT.Health.TextureBG
												end,
											set = function(self, HealthTexBG)
													db.oUF.ToT.Health.TextureBG = HealthTexBG
													oUF_LUI_targettarget.Health.bg:SetTexture(LSM:Fetch("statusbar", HealthTexBG))
												end,
											order = 2,
										},
										HealthTexBGAlpha = {
											name = "Background Alpha",
											desc = "Choose the Alpha Value for your Health Background.\nDefault: "..LUI.defaults.profile.oUF.ToT.Health.BGAlpha,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.ToT.Health.BGAlpha end,
											set = function(_, HealthTexBGAlpha) 
													db.oUF.ToT.Health.BGAlpha  = HealthTexBGAlpha
													oUF_LUI_targettarget.Health.bg:SetAlpha(tonumber(HealthTexBGAlpha))
												end,
											order = 3,
										},
										HealthTexBGMultiplier = {
											name = "Background Muliplier",
											desc = "Choose the Multiplier which will be used to generate the BackgroundColor.\nDefault: "..LUI.defaults.profile.oUF.ToT.Health.BGMultiplier,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.ToT.Health.BGMultiplier end,
											set = function(_, HealthTexBGMultiplier) 
													db.oUF.ToT.Health.BGMultiplier  = HealthTexBGMultiplier
													oUF_LUI_targettarget.Health.bg.multiplier = tonumber(HealthTexBGMultiplier)
												end,
											order = 4,
										},
									},
								},
							},
						},
						Power = {
							name = "Power",
							type = "group",
							order = 2,
							args = {
								EnablePower = {
									name = "Enable",
									desc = "Wether you want to use a Powerbar or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Power.Enable end,
									set = function(self,EnablePower)
												db.oUF.ToT.Power.Enable = not db.oUF.ToT.Power.Enable
												if EnablePower == true then
													oUF_LUI_targettarget.Power:Show()
												else
													oUF_LUI_targettarget.Power:Hide()
												end
											end,
									order = 1,
								},
								General = {
									name = "General Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Power.Enable end,
									guiInline = true,
									order = 2,
									args = {
										Height = {
											name = "Height",
											desc = "Decide the Height of your ToT Power.\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Power.Height,
											type = "input",
											get = function() return db.oUF.ToT.Power.Height end,
											set = function(self,Height)
														if Height == nil or Height == "" then
															Height = "0"
														end
														db.oUF.ToT.Power.Height = Height
														oUF_LUI_targettarget.Power:SetHeight(tonumber(Height))
													end,
											order = 1,
										},
										Padding = {
											name = "Padding",
											desc = "Choose the Padding between Health & Powerbar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Power.Padding,
											type = "input",
											get = function() return db.oUF.ToT.Power.Padding end,
											set = function(self,Padding)
														if Padding == nil or Padding == "" then
															Padding = "0"
														end
														db.oUF.ToT.Power.Padding = Padding
														oUF_LUI_targettarget.Power:ClearAllPoints()
														oUF_LUI_targettarget.Power:SetPoint("TOPLEFT", oUF_LUI_targettarget.Health, "BOTTOMLEFT", 0, tonumber(Padding))
														oUF_LUI_targettarget.Power:SetPoint("TOPRIGHT", oUF_LUI_targettarget.Health, "BOTTOMRIGHT", 0, tonumber(Padding))
													end,
											order = 2,
										},
										Smooth = {
											name = "Enable Smooth Bar Animation",
											desc = "Wether you want to use Smooth Animations or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.ToT.Power.Smooth end,
											set = function(self,Smooth)
														db.oUF.ToT.Power.Smooth = not db.oUF.ToT.Power.Smooth
														StaticPopup_Show("RELOAD_UI")
													end,
											order = 3,
										},
									}
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Power.Enable end,
									guiInline = true,
									order = 3,
									args = {
										PowerClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored PowerBars or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Power.ColorClass end,
											set = function(self,PowerClassColor)
														db.oUF.ToT.Power.ColorClass = not db.oUF.ToT.Power.ColorClass
														if PowerClassColor == true then
															db.oUF.ToT.Power.ColorType = false
															db.oUF.ToT.Power.IndividualColor.Enable = false
															
															print("ToT Powerbar Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										PowerColorByType = {
											name = "Color by Type",
											desc = "Wether you want to use Power Type colored PowerBars or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Power.ColorType end,
											set = function(self,PowerColorByType)
														db.oUF.ToT.Power.ColorType = not db.oUF.ToT.Power.ColorType
														if PowerColorByType == true then
															db.oUF.ToT.Power.ColorClass = false
															db.oUF.ToT.Power.IndividualColor.Enable = false
															
															print("ToT Powerbar Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualPowerColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual PowerBar Color or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Power.IndividualColor.Enable end,
											set = function(self,IndividualPowerColor)
														db.oUF.ToT.Power.IndividualColor.Enable = not db.oUF.ToT.Power.IndividualColor.Enable
														if IndividualPowerColor == true then
															db.oUF.ToT.Power.ColorType = false
															db.oUF.ToT.Power.ColorClass = false
															
															oUF_LUI_targettarget.Power:SetStatusBarColor(db.oUF.ToT.Power.IndividualColor.r, db.oUF.ToT.Power.IndividualColor.g, db.oUF.ToT.Power.IndividualColor.b)
															oUF_LUI_targettarget.Power.bg:SetVertexColor(db.oUF.ToT.Power.IndividualColor.r*tonumber(db.oUF.ToT.Power.BGMultiplier), db.oUF.ToT.Power.IndividualColor.g*tonumber(db.oUF.ToT.Power.BGMultiplier), db.oUF.ToT.Power.IndividualColor.b*tonumber(db.oUF.ToT.Power.BGMultiplier))
														end
													end,
											order = 3,
										},
										PowerColor = {
											name = "Individual Color",
											desc = "Choose an individual Powerbar Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.ToT.Power.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.ToT.Power.IndividualColor.r, db.oUF.ToT.Power.IndividualColor.g, db.oUF.ToT.Power.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.ToT.Power.IndividualColor.r = r
													db.oUF.ToT.Power.IndividualColor.g = g
													db.oUF.ToT.Power.IndividualColor.b = b
													
													oUF_LUI_targettarget.Power:SetStatusBarColor(r, g, b)
													oUF_LUI_targettarget.Power.bg:SetVertexColor(r*tonumber(db.oUF.ToT.Power.BGMultiplier), g*tonumber(db.oUF.ToT.Power.BGMultiplier), b*tonumber(db.oUF.ToT.Power.BGMultiplier))
												end,
											order = 4,
										},
									},
								},
								Textures = {
									name = "Texture Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Power.Enable end,
									guiInline = true,
									order = 4,
									args = {
										PowerTex = {
											name = "Texture",
											desc = "Choose your Power Texture!\nDefault: "..LUI.defaults.profile.oUF.ToT.Power.Texture,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.ToT.Power.Texture
												end,
											set = function(self, PowerTex)
													db.oUF.ToT.Power.Texture = PowerTex
													oUF_LUI_targettarget.Power:SetStatusBarTexture(LSM:Fetch("statusbar", PowerTex))
												end,
											order = 1,
										},
										PowerTexBG = {
											name = "Background Texture",
											desc = "Choose your Power Background Texture!\nDefault: "..LUI.defaults.profile.oUF.ToT.Power.TextureBG,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.ToT.Power.TextureBG
												end,

											set = function(self, PowerTexBG)
													db.oUF.ToT.Power.TextureBG = PowerTexBG
													oUF_LUI_targettarget.Power.bg:SetTexture(LSM:Fetch("statusbar", PowerTexBG))
												end,
											order = 2,
										},
										PowerTexBGAlpha = {
											name = "Background Alpha",
											desc = "Choose the Alpha Value for your Power Background.\nDefault: "..LUI.defaults.profile.oUF.ToT.Power.BGAlpha,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.ToT.Power.BGAlpha end,
											set = function(_, PowerTexBGAlpha) 
													db.oUF.ToT.Power.BGAlpha  = PowerTexBGAlpha
													oUF_LUI_targettarget.Power.bg:SetAlpha(tonumber(PowerTexBGAlpha))
												end,
											order = 3,
										},
										PowerTexBGMultiplier = {
											name = "Background Muliplier",
											desc = "Choose the Multiplier which will be used to generate the BackgroundColor.\nDefault: "..LUI.defaults.profile.oUF.ToT.Power.BGMultiplier,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.ToT.Power.BGMultiplier end,
											set = function(_, PowerTexBGMultiplier) 
													db.oUF.ToT.Power.BGMultiplier  = PowerTexBGMultiplier
													oUF_LUI_targettarget.Power.bg.multiplier = tonumber(PowerTexBGMultiplier)
												end,
											order = 4,
										},
									},
								},
							},
						},
						Full = {
							name = "Fullbar",
							type = "group",
							order = 3,
							args = {
								EnableFullbar = {
									name = "Enable",
									desc = "Wether you want to use a Fullbar or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Full.Enable end,
									set = function(self,EnableFullbar)
												db.oUF.ToT.Full.Enable = not db.oUF.ToT.Full.Enable
												if EnableFullbar == true then
													oUF_LUI_targettarget.Full:Show()
												else
													oUF_LUI_targettarget.Full:Hide()
												end
											end,
									order = 1,
								},
								General = {
									name = "Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Full.Enable end,
									guiInline = true,
									order = 2,
									args = {
										Height = {
											name = "Height",
											desc = "Decide the Height of your Fullbar.\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Full.Height,
											type = "input",
											get = function() return db.oUF.ToT.Full.Height end,
											set = function(self,Height)
														if Height == nil or Height == "" then
															Height = "0"
														end
														db.oUF.ToT.Full.Height = Height
														oUF_LUI_targettarget.Full:SetHeight(tonumber(Height))
													end,
											order = 1,
										},
										Padding = {
											name = "Padding",
											desc = "Choose the Padding between Health & Fullbar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Full.Padding,
											type = "input",
											get = function() return db.oUF.ToT.Full.Padding end,
											set = function(self,Padding)
													if Padding == nil or Padding == "" then
														Padding = "0"
													end
													db.oUF.ToT.Full.Padding = Padding
													oUF_LUI_targettarget.Full:ClearAllPoints()
													oUF_LUI_targettarget.Full:SetPoint("TOPLEFT", oUF_LUI_targettarget.Health, "BOTTOMLEFT", 0, tonumber(Padding))
													oUF_LUI_targettarget.Full:SetPoint("TOPRIGHT", oUF_LUI_targettarget.Health, "BOTTOMRIGHT", 0, tonumber(Padding))
												end,
											order = 2,
										},
										FullTex = {
											name = "Texture",
											desc = "Choose your Fullbar Texture!\nDefault: "..LUI.defaults.profile.oUF.ToT.Full.Texture,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.ToT.Full.Texture
												end,
											set = function(self, FullTex)
													db.oUF.ToT.Full.Texture = FullTex
													oUF_LUI_targettarget.Full:SetStatusBarTexture(LSM:Fetch("statusbar", FullTex))
												end,
											order = 3,
										},
										FullAlpha = {
											name = "Alpha",
											desc = "Choose the Alpha Value for your Fullbar!\n Default: "..LUI.defaults.profile.oUF.ToT.Full.Alpha,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.ToT.Full.Alpha end,
											set = function(_, FullAlpha)
													db.oUF.ToT.Full.Alpha = FullAlpha
													oUF_LUI_targettarget.Full:SetAlpha(FullAlpha)
												end,
											order = 4,
										},
										Color = {
											name = "Color",
											desc = "Choose your Fullbar Color.",
											type = "color",
											hasAlpha = true,
											get = function() return db.oUF.ToT.Full.Color.r, db.oUF.ToT.Full.Color.g, db.oUF.ToT.Full.Color.b, db.oUF.ToT.Full.Color.a end,
											set = function(_,r,g,b,a)
													db.oUF.ToT.Full.Color.r = r
													db.oUF.ToT.Full.Color.g = g
													db.oUF.ToT.Full.Color.b = b
													db.oUF.ToT.Full.Color.a = a
													
													oUF_LUI_targettarget.Full:SetStatusBarColor(r, g, b, a)
												end,
											order = 5,
										},
									},
								},
							},
						},
					},
				},
				Texts = {
					name = "Texts",
					type = "group",
					childGroups = "tab",
					order = 6,
					disabled = function() return not db.oUF.ToT.Enable end,
					args = {
						Name = {
							name = "Name",
							type = "group",
							order = 1,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the ToT Name or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Texts.Name.Enable end,
									set = function(self,Enable)
												db.oUF.ToT.Texts.Name.Enable = not db.oUF.ToT.Texts.Name.Enable
												if Enable == true then
													oUF_LUI_targettarget.Info:Show()
												else
													oUF_LUI_targettarget.Info:Hide()
												end
											end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your ToT Name Fontsize!\n Default: "..LUI.defaults.profile.oUF.ToT.Texts.Name.Size,
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.ToT.Texts.Name.Size end,
											set = function(_, FontSize)
													db.oUF.ToT.Texts.Name.Size = FontSize
													oUF_LUI_targettarget.Info:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.Name.Font),db.oUF.ToT.Texts.Name.Size,db.oUF.ToT.Texts.Name.Outline)
												end,
											order = 1,
										},
										empty = {
											order = 2,
											width = "full",
											type = "description",
											name = " ",
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for ToT Name!\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Name.Font,
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.ToT.Texts.Name.Font end,
											set = function(self, Font)
													db.oUF.ToT.Texts.Name.Font = Font
													oUF_LUI_targettarget.Info:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.Name.Font),db.oUF.ToT.Texts.Name.Size,db.oUF.ToT.Texts.Name.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your ToT Name.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Name.Outline,
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.ToT.Texts.Name.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.ToT.Texts.Name.Outline = fontflags[FontFlag]
													oUF_LUI_targettarget.Info:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.Name.Font),db.oUF.ToT.Texts.Name.Size,db.oUF.ToT.Texts.Name.Outline)
												end,
											order = 4,
										},
										NameX = {
											name = "X Value",
											desc = "X Value for your ToT Name.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Name.X,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											get = function() return db.oUF.ToT.Texts.Name.X end,
											set = function(self,NameX)
														if NameX == nil or NameX == "" then
															NameX = "0"
														end
														db.oUF.ToT.Texts.Name.X = NameX
														oUF_LUI_targettarget.Info:ClearAllPoints()
														oUF_LUI_targettarget.Info:SetPoint(db.oUF.ToT.Texts.Name.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Name.RelativePoint, tonumber(db.oUF.ToT.Texts.Name.X), tonumber(db.oUF.ToT.Texts.Name.Y))
													end,
											order = 5,
										},
										NameY = {
											name = "Y Value",
											desc = "Y Value for your ToT Name.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Name.Y,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											get = function() return db.oUF.ToT.Texts.Name.Y end,
											set = function(self,NameY)
														if NameY == nil or NameY == "" then
															NameY = "0"
														end
														db.oUF.ToT.Texts.Name.Y = NameY
														oUF_LUI_targettarget.Info:ClearAllPoints()
														oUF_LUI_targettarget.Info:SetPoint(db.oUF.ToT.Texts.Name.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Name.RelativePoint, tonumber(db.oUF.ToT.Texts.Name.X), tonumber(db.oUF.ToT.Texts.Name.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your ToT Name.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Name.Point,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.Name.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.ToT.Texts.Name.Point = positions[Point]
													oUF_LUI_targettarget.Info:ClearAllPoints()
													oUF_LUI_targettarget.Info:SetPoint(db.oUF.ToT.Texts.Name.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Name.RelativePoint, tonumber(db.oUF.ToT.Texts.Name.X), tonumber(db.oUF.ToT.Texts.Name.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your ToT Name.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Name.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.Name.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.ToT.Texts.Name.RelativePoint = positions[RelativePoint]
													oUF_LUI_targettarget.Info:ClearAllPoints()
													oUF_LUI_targettarget.Info:SetPoint(db.oUF.ToT.Texts.Name.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Name.RelativePoint, tonumber(db.oUF.ToT.Texts.Name.X), tonumber(db.oUF.ToT.Texts.Name.Y))
												end,
											order = 8,
										},
									},
								},
								Settings = {
									name = "Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
									guiInline = true,
									order = 2,
									args = {
										Format = {
											name = "Format",
											desc = "Choose the Format for your ToT Name.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Name.Format,
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											type = "select",
											width = "full",
											values = nameFormat,
											get = function()
													for k, v in pairs(nameFormat) do
														if db.oUF.ToT.Texts.Name.Format == v then
															return k
														end
													end
												end,
											set = function(self, Format)
													db.oUF.ToT.Texts.Name.Format = nameFormat[Format]
												end,
											order = 1,
										},
										Length = {
											name = "Length",
											desc = "Choose the Length of your ToT Name.\n\nShort = 6 Letters\nMedium = 18 Letters\nLong = 36 Letters\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Name.Length,
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											type = "select",
											values = nameLenghts,
											get = function()
													for k, v in pairs(nameLenghts) do
														if db.oUF.ToT.Texts.Name.Length == v then
															return k
														end
													end
												end,
											set = function(self, Length)
													db.oUF.ToT.Texts.Name.Length = nameLenghts[Length]
												end,
											order = 2,
										},
										empty = {
											order = 3,
											width = "full",
											type = "description",
											name = " ",
										},
										ColorNameByClass = {
											name = "Color Name by Class",
											desc = "Wether you want to color the ToT Name by Class or not.",
											type = "toggle",
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											get = function() return db.oUF.ToT.Texts.Name.ColorNameByClass end,
											set = function(self,ColorNameByClass)
														db.oUF.ToT.Texts.Name.ColorNameByClass = not db.oUF.ToT.Texts.Name.ColorNameByClass
													end,
											order = 4,
										},
										ColorClassByClass = {
											name = "Color Class by Class",
											desc = "Wether you want to color the ToT Class by Class or not.",
											type = "toggle",
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											get = function() return db.oUF.ToT.Texts.Name.ColorClassByClass end,
											set = function(self,ColorClassByClass)
														db.oUF.ToT.Texts.Name.ColorClassByClass = not db.oUF.ToT.Texts.Name.ColorClassByClass
													end,
											order = 5,
										},
										ColorLevelByDifficulty = {
											name = "Color Level by Difficulty",
											desc = "Wether you want to color the Level by Difficulty or not.",
											type = "toggle",
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											get = function() return db.oUF.ToT.Texts.Name.ColorLevelByDifficulty end,
											set = function(self,ColorLevelByDifficulty)
														db.oUF.ToT.Texts.Name.ColorLevelByDifficulty = not db.oUF.ToT.Texts.Name.ColorLevelByDifficulty
													end,
											order = 6,
										},
										ShowClassification = {
											name = "Show Classification",
											desc = "Wether you want to show Classifications like Elite, Boss, Rar or not.",
											type = "toggle",
											disabled = function() return not db.oUF.ToT.Texts.Name.Enable end,
											get = function() return db.oUF.ToT.Texts.Name.ShowClassification end,
											set = function(self,ShowClassification)
														db.oUF.ToT.Texts.Name.ShowClassification = not db.oUF.ToT.Texts.Name.ShowClassification
													end,
											order = 7,
										},
										ShortClassification = {
											name = "Enable Short Classification",
											desc = "Wether you want to show short Classifications or not.",
											type = "toggle",
											width = "full",
											disabled = function() return not db.oUF.ToT.Texts.Name.ShowClassification end,
											get = function() return db.oUF.ToT.Texts.Name.ShortClassification end,
											set = function(self,ShortClassification)
														db.oUF.ToT.Texts.Name.ShortClassification = not db.oUF.ToT.Texts.Name.ShortClassification
													end,
											order = 8,
										},
									},
								},
							},
						},
						Health = {
							name = "Health",
							type = "group",
							order = 2,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the ToT Health or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Texts.Health.Enable end,
									set = function(self,Enable)
											db.oUF.ToT.Texts.Health.Enable = not db.oUF.ToT.Texts.Health.Enable
											if Enable == true then
												oUF_LUI_targettarget.Health.value:Show()
											else
												oUF_LUI_targettarget.Health.value:Hide()
											end
										end,
									order = 0,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.Health.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your ToT Health Fontsize!\n Default: "..LUI.defaults.profile.oUF.ToT.Texts.Health.Size,
											disabled = function() return not db.oUF.ToT.Texts.Health.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.ToT.Texts.Health.Size end,
											set = function(_, FontSize)
													db.oUF.ToT.Texts.Health.Size = FontSize
													oUF_LUI_targettarget.Health.value:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.Health.Font),db.oUF.ToT.Texts.Health.Size,db.oUF.ToT.Texts.Health.Outline)
												end,
											order = 1,
										},
										Format = {
											name = "Format",
											desc = "Choose the Format for your ToT Health.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Health.Format,
											disabled = function() return not db.oUF.ToT.Texts.Health.Enable end,
											type = "select",
											values = valueFormat,
											get = function()
													for k, v in pairs(valueFormat) do
														if db.oUF.ToT.Texts.Health.Format == v then
															return k
														end
													end
												end,
											set = function(self, Format)
													db.oUF.ToT.Texts.Health.Format = valueFormat[Format]
													print("ToT Health Value Format will change once you gain/lose Health")
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for ToT Health!\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Health.Font,
											disabled = function() return not db.oUF.ToT.Texts.Health.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.ToT.Texts.Health.Font end,
											set = function(self, Font)
													db.oUF.ToT.Texts.Health.Font = Font
													oUF_LUI_targettarget.Health.value:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.Health.Font),db.oUF.ToT.Texts.Health.Size,db.oUF.ToT.Texts.Health.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your ToT Health.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Health.Outline,
											disabled = function() return not db.oUF.ToT.Texts.Health.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.ToT.Texts.Health.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.ToT.Texts.Health.Outline = fontflags[FontFlag]
													oUF_LUI_targettarget.Health.value:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.Health.Font),db.oUF.ToT.Texts.Health.Size,db.oUF.ToT.Texts.Health.Outline)
												end,
											order = 4,
										},
										HealthX = {
											name = "X Value",
											desc = "X Value for your ToT Health.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Health.X,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.Health.Enable end,
											get = function() return db.oUF.ToT.Texts.Health.X end,
											set = function(self,HealthX)
														if HealthX == nil or HealthX == "" then
															HealthX = "0"
														end
														db.oUF.ToT.Texts.Health.X = HealthX
														oUF_LUI_targettarget.Health.value:ClearAllPoints()
														oUF_LUI_targettarget.Health.value:SetPoint(db.oUF.ToT.Texts.Health.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Health.RelativePoint, tonumber(db.oUF.ToT.Texts.Health.X), tonumber(db.oUF.ToT.Texts.Health.Y))
													end,
											order = 5,
										},
										HealthY = {
											name = "Y Value",
											desc = "Y Value for your ToT Health.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Health.Y,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.Health.Enable end,
											get = function() return db.oUF.ToT.Texts.Health.Y end,
											set = function(self,HealthY)
														if HealthY == nil or HealthY == "" then
															HealthY = "0"
														end
														db.oUF.ToT.Texts.Health.Y = HealthY
														oUF_LUI_targettarget.Health.value:ClearAllPoints()
														oUF_LUI_targettarget.Health.value:SetPoint(db.oUF.ToT.Texts.Health.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Health.RelativePoint, tonumber(db.oUF.ToT.Texts.Health.X), tonumber(db.oUF.ToT.Texts.Health.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your ToT Health.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Health.Point,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.Health.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.Health.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.ToT.Texts.Health.Point = positions[Point]
													oUF_LUI_targettarget.Health.value:ClearAllPoints()
													oUF_LUI_targettarget.Health.value:SetPoint(db.oUF.ToT.Texts.Health.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Health.RelativePoint, tonumber(db.oUF.ToT.Texts.Health.X), tonumber(db.oUF.ToT.Texts.Health.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your ToT Health.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Health.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.Health.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.Health.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.ToT.Texts.Health.RelativePoint = positions[RelativePoint]
													oUF_LUI_targettarget.Health.value:ClearAllPoints()
													oUF_LUI_targettarget.Health.value:SetPoint(db.oUF.ToT.Texts.Health.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Health.RelativePoint, tonumber(db.oUF.ToT.Texts.Health.X), tonumber(db.oUF.ToT.Texts.Health.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.Health.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored Health Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.Health.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.ToT.Texts.Health.ColorClass = not db.oUF.ToT.Texts.Health.ColorClass
														if ClassColor == true then
															db.oUF.ToT.Texts.Health.ColorGradient = false
															db.oUF.ToT.Texts.Health.IndividualColor.Enable = false
															
															print("ToT Health Value Color will change once you gain/lose Health")
														end
													end,
											order = 1,
										},
										ColorGradient = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored Health Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.Health.ColorGradient end,
											set = function(self,ColorGradient)
														db.oUF.ToT.Texts.Health.ColorGradient = not db.oUF.ToT.Texts.Health.ColorGradient
														if ColorGradient == true then
															db.oUF.ToT.Texts.Health.ColorClass = false
															db.oUF.ToT.Texts.Health.IndividualColor.Enable = false
															
															print("ToT Health Value Color will change once you gain/lose Health")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual ToT Health Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.Health.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.ToT.Texts.Health.IndividualColor.Enable = not db.oUF.ToT.Texts.Health.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.ToT.Texts.Health.ColorClass = false
															db.oUF.ToT.Texts.Health.ColorGradient = false
															
															oUF_LUI_targettarget.Health.value:SetTextColor(tonumber(db.oUF.ToT.Texts.Health.IndividualColor.r),tonumber(db.oUF.ToT.Texts.Health.IndividualColor.g),tonumber(db.oUF.ToT.Texts.Health.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual ToT Health Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.ToT.Texts.Health.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.ToT.Texts.Health.IndividualColor.r, db.oUF.ToT.Texts.Health.IndividualColor.g, db.oUF.ToT.Texts.Health.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.ToT.Texts.Health.IndividualColor.r = r
													db.oUF.ToT.Texts.Health.IndividualColor.g = g
													db.oUF.ToT.Texts.Health.IndividualColor.b = b
													
													oUF_LUI_targettarget.Health.value:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
								Settings = {
									name = "Settings",
									type = "group",
									guiInline = true,
									order = 3,
									args = {
										ShowDead = {
											name = "Show Dead/AFK/Disconnected Information",
											desc = "Wether you want to switch the Health Value to Dead/AFK/Disconnected or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.ToT.Texts.Health.ShowDead end,
											set = function(self,ShowDead)
														db.oUF.ToT.Texts.Health.ShowDead = not db.oUF.ToT.Texts.Health.ShowDead
													end,
											order = 1,
										},
									},
								},
							},
						},
						Power = {
							name = "Power",
							type = "group",
							order = 3,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the ToT Power or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Texts.Power.Enable end,
									set = function(self,Enable)
											db.oUF.ToT.Texts.Power.Enable = not db.oUF.ToT.Texts.Power.Enable
											if Enable == true then
												oUF_LUI_targettarget.Power.value:Show()
											else
												oUF_LUI_targettarget.Power.value:Hide()
											end
										end,
									order = 0,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.Power.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your ToT Power Fontsize!\n Default: "..LUI.defaults.profile.oUF.ToT.Texts.Power.Size,
											disabled = function() return not db.oUF.ToT.Texts.Power.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.ToT.Texts.Power.Size end,
											set = function(_, FontSize)
													db.oUF.ToT.Texts.Power.Size = FontSize
													oUF_LUI_targettarget.Power.value:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.Power.Font),db.oUF.ToT.Texts.Power.Size,db.oUF.ToT.Texts.Power.Outline)
												end,
											order = 1,
										},
										Format = {
											name = "Format",
											desc = "Choose the Format for your ToT Power.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Power.Format,
											disabled = function() return not db.oUF.ToT.Texts.Power.Enable end,
											type = "select",
											values = valueFormat,
											get = function()
													for k, v in pairs(valueFormat) do
														if db.oUF.ToT.Texts.Power.Format == v then
															return k
														end
													end
												end,
											set = function(self, Format)
													db.oUF.ToT.Texts.Power.Format = valueFormat[Format]
													print("ToT Power Value Format will change once you gain/lose Power")
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for ToT Power!\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Power.Font,
											disabled = function() return not db.oUF.ToT.Texts.Power.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.ToT.Texts.Power.Font end,
											set = function(self, Font)
													db.oUF.ToT.Texts.Power.Font = Font
													oUF_LUI_targettarget.Power.value:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.Power.Font),db.oUF.ToT.Texts.Power.Size,db.oUF.ToT.Texts.Power.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your ToT Power.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Power.Outline,
											disabled = function() return not db.oUF.ToT.Texts.Power.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.ToT.Texts.Power.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.ToT.Texts.Power.Outline = fontflags[FontFlag]
													oUF_LUI_targettarget.Power.value:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.Power.Font),db.oUF.ToT.Texts.Power.Size,db.oUF.ToT.Texts.Power.Outline)
												end,
											order = 4,
										},
										PowerX = {
											name = "X Value",
											desc = "X Value for your ToT Power.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Power.X,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.Power.Enable end,
											get = function() return db.oUF.ToT.Texts.Power.X end,
											set = function(self,PowerX)
														if PowerX == nil or PowerX == "" then
															PowerX = "0"
														end
														db.oUF.ToT.Texts.Power.X = PowerX
														oUF_LUI_targettarget.Power.value:ClearAllPoints()
														oUF_LUI_targettarget.Power.value:SetPoint(db.oUF.ToT.Texts.Power.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Power.RelativePoint, tonumber(db.oUF.ToT.Texts.Power.X), tonumber(db.oUF.ToT.Texts.Power.Y))
													end,
											order = 5,
										},
										PowerY = {
											name = "Y Value",
											desc = "Y Value for your ToT Power.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Power.Y,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.Power.Enable end,
											get = function() return db.oUF.ToT.Texts.Power.Y end,
											set = function(self,PowerY)
														if PowerY == nil or PowerY == "" then
															PowerY = "0"
														end
														db.oUF.ToT.Texts.Power.Y = PowerY
														oUF_LUI_targettarget.Power.value:ClearAllPoints()
														oUF_LUI_targettarget.Power.value:SetPoint(db.oUF.ToT.Texts.Power.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Power.RelativePoint, tonumber(db.oUF.ToT.Texts.Power.X), tonumber(db.oUF.ToT.Texts.Power.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your ToT Power.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Power.Point,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.Power.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.Power.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.ToT.Texts.Power.Point = positions[Point]
													oUF_LUI_targettarget.Power.value:ClearAllPoints()
													oUF_LUI_targettarget.Power.value:SetPoint(db.oUF.ToT.Texts.Power.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Power.RelativePoint, tonumber(db.oUF.ToT.Texts.Power.X), tonumber(db.oUF.ToT.Texts.Power.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your ToT Power.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.Power.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.Power.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.Power.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.ToT.Texts.Power.RelativePoint = positions[RelativePoint]
													oUF_LUI_targettarget.Power.value:ClearAllPoints()
													oUF_LUI_targettarget.Power.value:SetPoint(db.oUF.ToT.Texts.Power.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.Power.RelativePoint, tonumber(db.oUF.ToT.Texts.Power.X), tonumber(db.oUF.ToT.Texts.Power.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.Power.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored Power Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.Power.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.ToT.Texts.Power.ColorClass = not db.oUF.ToT.Texts.Power.ColorClass
														if ClassColor == true then
															db.oUF.ToT.Texts.Power.ColorType = false
															db.oUF.ToT.Texts.Power.IndividualColor.Enable = false
															
															print("ToT Power Value Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										ColorType = {
											name = "Color by Type",
											desc = "Wether you want to use Powertype colored Power Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.Power.ColorType end,
											set = function(self,ColorType)
														db.oUF.ToT.Texts.Power.ColorType = not db.oUF.ToT.Texts.Power.ColorType
														if ColorType == true then
															db.oUF.ToT.Texts.Power.ColorClass = false
															db.oUF.ToT.Texts.Power.IndividualColor.Enable = false
															
															print("ToT Power Value Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual ToT Power Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.Power.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.ToT.Texts.Power.IndividualColor.Enable = not db.oUF.ToT.Texts.Power.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.ToT.Texts.Power.ColorClass = false
															db.oUF.ToT.Texts.Power.ColorType = false
															
															oUF_LUI_targettarget.Power.value:SetTextColor(tonumber(db.oUF.ToT.Texts.Power.IndividualColor.r),tonumber(db.oUF.ToT.Texts.Power.IndividualColor.g),tonumber(db.oUF.ToT.Texts.Power.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual ToT Power Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.ToT.Texts.Power.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.ToT.Texts.Power.IndividualColor.r, db.oUF.ToT.Texts.Power.IndividualColor.g, db.oUF.ToT.Texts.Power.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.ToT.Texts.Power.IndividualColor.r = r
													db.oUF.ToT.Texts.Power.IndividualColor.g = g
													db.oUF.ToT.Texts.Power.IndividualColor.b = b
													
													oUF_LUI_targettarget.Power.value:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
						HealthPercent = {
							name = "HealthPercent",
							type = "group",
							order = 4,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the ToT HealthPercent or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Texts.HealthPercent.Enable end,
									set = function(self,Enable)
											db.oUF.ToT.Texts.HealthPercent.Enable = not db.oUF.ToT.Texts.HealthPercent.Enable
											if Enable == true then
												oUF_LUI_targettarget.Health.valuePercent:Show()
											else
												oUF_LUI_targettarget.Health.valuePercent:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.HealthPercent.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your ToT HealthPercent Fontsize!\n Default: "..LUI.defaults.profile.oUF.ToT.Texts.HealthPercent.Size,
											disabled = function() return not db.oUF.ToT.Texts.HealthPercent.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.ToT.Texts.HealthPercent.Size end,
											set = function(_, FontSize)
													db.oUF.ToT.Texts.HealthPercent.Size = FontSize
													oUF_LUI_targettarget.Health.valuePercent:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.HealthPercent.Font),db.oUF.ToT.Texts.HealthPercent.Size,db.oUF.ToT.Texts.HealthPercent.Outline)
												end,
											order = 1,
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show ToT HealthPercent or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.ToT.Texts.HealthPercent.Enable end,
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.HealthPercent.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.ToT.Texts.HealthPercent.ShowAlways = not db.oUF.ToT.Texts.HealthPercent.ShowAlways
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for ToT HealthPercent!\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthPercent.Font,
											disabled = function() return not db.oUF.ToT.Texts.HealthPercent.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.ToT.Texts.HealthPercent.Font end,
											set = function(self, Font)
													db.oUF.ToT.Texts.HealthPercent.Font = Font
													oUF_LUI_targettarget.Health.valuePercent:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.HealthPercent.Font),db.oUF.ToT.Texts.HealthPercent.Size,db.oUF.ToT.Texts.HealthPercent.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your ToT HealthPercent.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthPercent.Outline,
											disabled = function() return not db.oUF.ToT.Texts.HealthPercent.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.ToT.Texts.HealthPercent.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.ToT.Texts.HealthPercent.Outline = fontflags[FontFlag]
													oUF_LUI_targettarget.Health.valuePercent:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.HealthPercent.Font),db.oUF.ToT.Texts.HealthPercent.Size,db.oUF.ToT.Texts.HealthPercent.Outline)
												end,
											order = 4,
										},
										HealthPercentX = {
											name = "X Value",
											desc = "X Value for your ToT HealthPercent.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthPercent.X,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.HealthPercent.Enable end,
											get = function() return db.oUF.ToT.Texts.HealthPercent.X end,
											set = function(self,HealthPercentX)
														if HealthPercentX == nil or HealthPercentX == "" then
															HealthPercentX = "0"
														end
														db.oUF.ToT.Texts.HealthPercent.X = HealthPercentX
														oUF_LUI_targettarget.Health.valuePercent:ClearAllPoints()
														oUF_LUI_targettarget.Health.valuePercent:SetPoint(db.oUF.ToT.Texts.HealthPercent.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.ToT.Texts.HealthPercent.X), tonumber(db.oUF.ToT.Texts.HealthPercent.Y))
													end,
											order = 5,
										},
										HealthPercentY = {
											name = "Y Value",
											desc = "Y Value for your ToT HealthPercent.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthPercent.Y,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.HealthPercent.Enable end,
											get = function() return db.oUF.ToT.Texts.HealthPercent.Y end,
											set = function(self,HealthPercentY)
														if HealthPercentY == nil or HealthPercentY == "" then
															HealthPercentY = "0"
														end
														db.oUF.ToT.Texts.HealthPercent.Y = HealthPercentY
														oUF_LUI_targettarget.Health.valuePercent:ClearAllPoints()
														oUF_LUI_targettarget.Health.valuePercent:SetPoint(db.oUF.ToT.Texts.HealthPercent.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.ToT.Texts.HealthPercent.X), tonumber(db.oUF.ToT.Texts.HealthPercent.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your ToT HealthPercent.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthPercent.Point,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.HealthPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.HealthPercent.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.ToT.Texts.HealthPercent.Point = positions[Point]
													oUF_LUI_targettarget.Health.valuePercent:ClearAllPoints()
													oUF_LUI_targettarget.Health.valuePercent:SetPoint(db.oUF.ToT.Texts.HealthPercent.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.ToT.Texts.HealthPercent.X), tonumber(db.oUF.ToT.Texts.HealthPercent.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your ToT HealthPercent.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthPercent.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.HealthPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.HealthPercent.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.ToT.Texts.HealthPercent.RelativePoint = positions[RelativePoint]
													oUF_LUI_targettarget.Health.valuePercent:ClearAllPoints()
													oUF_LUI_targettarget.Health.valuePercent:SetPoint(db.oUF.ToT.Texts.HealthPercent.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.ToT.Texts.HealthPercent.X), tonumber(db.oUF.ToT.Texts.HealthPercent.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.HealthPercent.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored HealthPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.HealthPercent.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.ToT.Texts.HealthPercent.ColorClass = not db.oUF.ToT.Texts.HealthPercent.ColorClass
														if ClassColor == true then
															db.oUF.ToT.Texts.HealthPercent.ColorGradient = false
															db.oUF.ToT.Texts.HealthPercent.IndividualColor.Enable = false
															
															print("ToT HealthPercent Value Color will change once you gain/lose Health")
														end
													end,
											order = 1,
										},
										ColorGradient = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored HealthPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.HealthPercent.ColorGradient end,
											set = function(self,ColorGradient)
														db.oUF.ToT.Texts.HealthPercent.ColorGradient = not db.oUF.ToT.Texts.HealthPercent.ColorGradient
														if ColorGradient == true then
															db.oUF.ToT.Texts.HealthPercent.ColorClass = false
															db.oUF.ToT.Texts.HealthPercent.IndividualColor.Enable = false
															
															print("ToT HealthPercent Value Color will change once you gain/lose Health")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual ToT HealthPercent Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.HealthPercent.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.ToT.Texts.HealthPercent.IndividualColor.Enable = not db.oUF.ToT.Texts.HealthPercent.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.ToT.Texts.HealthPercent.ColorClass = false
															db.oUF.ToT.Texts.HealthPercent.ColorGradient = false
															
															oUF_LUI_targettarget.Health.valuePercent:SetTextColor(tonumber(db.oUF.ToT.Texts.HealthPercent.IndividualColor.r),tonumber(db.oUF.ToT.Texts.HealthPercent.IndividualColor.g),tonumber(db.oUF.ToT.Texts.HealthPercent.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual ToT HealthPercent Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.ToT.Texts.HealthPercent.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.ToT.Texts.HealthPercent.IndividualColor.r, db.oUF.ToT.Texts.HealthPercent.IndividualColor.g, db.oUF.ToT.Texts.HealthPercent.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.ToT.Texts.HealthPercent.IndividualColor.r = r
													db.oUF.ToT.Texts.HealthPercent.IndividualColor.g = g
													db.oUF.ToT.Texts.HealthPercent.IndividualColor.b = b
													
													oUF_LUI_targettarget.Health.valuePercent:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
								Settings = {
									name = "Settings",
									type = "group",
									guiInline = true,
									order = 3,
									args = {
										ShowDead = {
											name = "Show Dead/AFK/Disconnected Information",
											desc = "Wether you want to switch the HealthPercent Value to Dead/AFK/Disconnected or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.ToT.Texts.HealthPercent.ShowDead end,
											set = function(self,ShowDead)
														db.oUF.ToT.Texts.HealthPercent.ShowDead = not db.oUF.ToT.Texts.HealthPercent.ShowDead
													end,
											order = 1,
										},
									},
								},
							},
						},
						PowerPercent = {
							name = "PowerPercent",
							type = "group",
							order = 5,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the ToT PowerPercent or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Texts.PowerPercent.Enable end,
									set = function(self,Enable)
											db.oUF.ToT.Texts.PowerPercent.Enable = not db.oUF.ToT.Texts.PowerPercent.Enable
											if Enable == true then
												oUF_LUI_targettarget.Power.valuePercent:Show()
											else
												oUF_LUI_targettarget.Power.valuePercent:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.PowerPercent.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your ToT PowerPercent Fontsize!\n Default: "..LUI.defaults.profile.oUF.ToT.Texts.PowerPercent.Size,
											disabled = function() return not db.oUF.ToT.Texts.PowerPercent.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.ToT.Texts.PowerPercent.Size end,
											set = function(_, FontSize)
													db.oUF.ToT.Texts.PowerPercent.Size = FontSize
													oUF_LUI_targettarget.Power.valuePercent:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.PowerPercent.Font),db.oUF.ToT.Texts.PowerPercent.Size,db.oUF.ToT.Texts.PowerPercent.Outline)
												end,
											order = 1,
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show ToT PowerPercent or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.ToT.Texts.PowerPercent.Enable end,
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.PowerPercent.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.ToT.Texts.PowerPercent.ShowAlways = not db.oUF.ToT.Texts.PowerPercent.ShowAlways
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for ToT PowerPercent!\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerPercent.Font,
											disabled = function() return not db.oUF.ToT.Texts.PowerPercent.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.ToT.Texts.PowerPercent.Font end,
											set = function(self, Font)
													db.oUF.ToT.Texts.PowerPercent.Font = Font
													oUF_LUI_targettarget.Power.valuePercent:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.PowerPercent.Font),db.oUF.ToT.Texts.PowerPercent.Size,db.oUF.ToT.Texts.PowerPercent.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your ToT PowerPercent.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerPercent.Outline,
											disabled = function() return not db.oUF.ToT.Texts.PowerPercent.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.ToT.Texts.PowerPercent.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.ToT.Texts.PowerPercent.Outline = fontflags[FontFlag]
													oUF_LUI_targettarget.Power.valuePercent:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.PowerPercent.Font),db.oUF.ToT.Texts.PowerPercent.Size,db.oUF.ToT.Texts.PowerPercent.Outline)
												end,
											order = 4,
										},
										PowerPercentX = {
											name = "X Value",
											desc = "X Value for your ToT PowerPercent.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerPercent.X,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.PowerPercent.Enable end,
											get = function() return db.oUF.ToT.Texts.PowerPercent.X end,
											set = function(self,PowerPercentX)
														if PowerPercentX == nil or PowerPercentX == "" then
															PowerPercentX = "0"
														end
														db.oUF.ToT.Texts.PowerPercent.X = PowerPercentX
														oUF_LUI_targettarget.Power.valuePercent:ClearAllPoints()
														oUF_LUI_targettarget.Power.valuePercent:SetPoint(db.oUF.ToT.Texts.PowerPercent.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.ToT.Texts.PowerPercent.X), tonumber(db.oUF.ToT.Texts.PowerPercent.Y))
													end,
											order = 5,
										},
										PowerPercentY = {
											name = "Y Value",
											desc = "Y Value for your ToT PowerPercent.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerPercent.Y,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.PowerPercent.Enable end,
											get = function() return db.oUF.ToT.Texts.PowerPercent.Y end,
											set = function(self,PowerPercentY)
														if PowerPercentY == nil or PowerPercentY == "" then
															PowerPercentY = "0"
														end
														db.oUF.ToT.Texts.PowerPercent.Y = PowerPercentY
														oUF_LUI_targettarget.Power.valuePercent:ClearAllPoints()
														oUF_LUI_targettarget.Power.valuePercent:SetPoint(db.oUF.ToT.Texts.PowerPercent.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.ToT.Texts.PowerPercent.X), tonumber(db.oUF.ToT.Texts.PowerPercent.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your ToT PowerPercent.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerPercent.Point,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.PowerPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.PowerPercent.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.ToT.Texts.PowerPercent.Point = positions[Point]
													oUF_LUI_targettarget.Power.valuePercent:ClearAllPoints()
													oUF_LUI_targettarget.Power.valuePercent:SetPoint(db.oUF.ToT.Texts.PowerPercent.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.ToT.Texts.PowerPercent.X), tonumber(db.oUF.ToT.Texts.PowerPercent.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your ToT PowerPercent.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerPercent.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.PowerPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.PowerPercent.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.ToT.Texts.PowerPercent.RelativePoint = positions[RelativePoint]
													oUF_LUI_targettarget.Power.valuePercent:ClearAllPoints()
													oUF_LUI_targettarget.Power.valuePercent:SetPoint(db.oUF.ToT.Texts.PowerPercent.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.ToT.Texts.PowerPercent.X), tonumber(db.oUF.ToT.Texts.PowerPercent.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.PowerPercent.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored PowerPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.PowerPercent.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.ToT.Texts.PowerPercent.ColorClass = not db.oUF.ToT.Texts.PowerPercent.ColorClass
														if ClassColor == true then
															db.oUF.ToT.Texts.PowerPercent.ColorType = false
															db.oUF.ToT.Texts.PowerPercent.IndividualColor.Enable = false
															
															print("ToT PowerPercent Value Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										ColorType = {
											name = "Color by Type",
											desc = "Wether you want to use Type colored PowerPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.PowerPercent.ColorType end,
											set = function(self,ColorType)
														db.oUF.ToT.Texts.PowerPercent.ColorType = not db.oUF.ToT.Texts.PowerPercent.ColorType
														if ColorType == true then
															db.oUF.ToT.Texts.PowerPercent.ColorClass = false
															db.oUF.ToT.Texts.PowerPercent.IndividualColor.Enable = false
															
															print("ToT PowerPercent Value Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual ToT PowerPercent Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.PowerPercent.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.ToT.Texts.PowerPercent.IndividualColor.Enable = not db.oUF.ToT.Texts.PowerPercent.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.ToT.Texts.PowerPercent.ColorClass = false
															db.oUF.ToT.Texts.PowerPercent.ColorType = false
															
															oUF_LUI_targettarget.Power.valuePercent:SetTextColor(tonumber(db.oUF.ToT.Texts.PowerPercent.IndividualColor.r),tonumber(db.oUF.ToT.Texts.PowerPercent.IndividualColor.g),tonumber(db.oUF.ToT.Texts.PowerPercent.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual ToT PowerPercent Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.ToT.Texts.PowerPercent.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.ToT.Texts.PowerPercent.IndividualColor.r, db.oUF.ToT.Texts.PowerPercent.IndividualColor.g, db.oUF.ToT.Texts.PowerPercent.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.ToT.Texts.PowerPercent.IndividualColor.r = r
													db.oUF.ToT.Texts.PowerPercent.IndividualColor.g = g
													db.oUF.ToT.Texts.PowerPercent.IndividualColor.b = b
													
													oUF_LUI_targettarget.Power.valuePercent:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
						HealthMissing = {
							name = "HealthMissing",
							type = "group",
							order = 6,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the ToT HealthMissing or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Texts.HealthMissing.Enable end,
									set = function(self,Enable)
											db.oUF.ToT.Texts.HealthMissing.Enable = not db.oUF.ToT.Texts.HealthMissing.Enable
											if Enable == true then
												oUF_LUI_targettarget.Health.valueMissing:Show()
											else
												oUF_LUI_targettarget.Health.valueMissing:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your ToT HealthMissing Fontsize!\n Default: "..LUI.defaults.profile.oUF.ToT.Texts.HealthMissing.Size,
											disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.ToT.Texts.HealthMissing.Size end,
											set = function(_, FontSize)
													db.oUF.ToT.Texts.HealthMissing.Size = FontSize
													oUF_LUI_targettarget.Health.valueMissing:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.HealthMissing.Font),db.oUF.ToT.Texts.HealthMissing.Size,db.oUF.ToT.Texts.HealthMissing.Outline)
												end,
											order = 1,
										},
										empty = {
											order = 2,
											width = "full",
											type = "description",
											name = " ",
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show ToT HealthMissing or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.HealthMissing.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.ToT.Texts.HealthMissing.ShowAlways = not db.oUF.ToT.Texts.HealthMissing.ShowAlways
												end,
											order = 3,
										},
										ShortValue = {
											name = "Short Value",
											desc = "Show a Short or the Normal Value of the Missing HP",
											disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.HealthMissing.ShortValue end,
											set = function(self,ShortValue)
													db.oUF.ToT.Texts.HealthMissing.ShortValue = not db.oUF.ToT.Texts.HealthMissing.ShortValue
												end,
											order = 4,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for ToT HealthMissing!\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthMissing.Font,
											disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.ToT.Texts.HealthMissing.Font end,
											set = function(self, Font)
													db.oUF.ToT.Texts.HealthMissing.Font = Font
													oUF_LUI_targettarget.Health.valueMissing:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.HealthMissing.Font),db.oUF.ToT.Texts.HealthMissing.Size,db.oUF.ToT.Texts.HealthMissing.Outline)
												end,
											order = 5,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your ToT HealthMissing.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthMissing.Outline,
											disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.ToT.Texts.HealthMissing.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.ToT.Texts.HealthMissing.Outline = fontflags[FontFlag]
													oUF_LUI_targettarget.Health.valueMissing:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.HealthMissing.Font),db.oUF.ToT.Texts.HealthMissing.Size,db.oUF.ToT.Texts.HealthMissing.Outline)
												end,
											order = 6,
										},
										HealthMissingX = {
											name = "X Value",
											desc = "X Value for your ToT HealthMissing.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthMissing.X,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
											get = function() return db.oUF.ToT.Texts.HealthMissing.X end,
											set = function(self,HealthMissingX)
														if HealthMissingX == nil or HealthMissingX == "" then
															HealthMissingX = "0"
														end
														db.oUF.ToT.Texts.HealthMissing.X = HealthMissingX
														oUF_LUI_targettarget.Health.valueMissing:ClearAllPoints()
														oUF_LUI_targettarget.Health.valueMissing:SetPoint(db.oUF.ToT.Texts.HealthMissing.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.ToT.Texts.HealthMissing.X), tonumber(db.oUF.ToT.Texts.HealthMissing.Y))
													end,
											order = 7,
										},
										HealthMissingY = {
											name = "Y Value",
											desc = "Y Value for your ToT HealthMissing.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthMissing.Y,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
											get = function() return db.oUF.ToT.Texts.HealthMissing.Y end,
											set = function(self,HealthMissingY)
														if HealthMissingY == nil or HealthMissingY == "" then
															HealthMissingY = "0"
														end
														db.oUF.ToT.Texts.HealthMissing.Y = HealthMissingY
														oUF_LUI_targettarget.Health.valueMissing:ClearAllPoints()
														oUF_LUI_targettarget.Health.valueMissing:SetPoint(db.oUF.ToT.Texts.HealthMissing.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.ToT.Texts.HealthMissing.X), tonumber(db.oUF.ToT.Texts.HealthMissing.Y))
													end,
											order = 8,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your ToT HealthMissing.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthMissing.Point,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.HealthMissing.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.ToT.Texts.HealthMissing.Point = positions[Point]
													oUF_LUI_targettarget.Health.valueMissing:ClearAllPoints()
													oUF_LUI_targettarget.Health.valueMissing:SetPoint(db.oUF.ToT.Texts.HealthMissing.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.ToT.Texts.HealthMissing.X), tonumber(db.oUF.ToT.Texts.HealthMissing.Y))
												end,
											order = 9,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your ToT HealthMissing.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.HealthMissing.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.HealthMissing.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.ToT.Texts.HealthMissing.RelativePoint = positions[RelativePoint]
													oUF_LUI_targettarget.Health.valueMissing:ClearAllPoints()
													oUF_LUI_targettarget.Health.valueMissing:SetPoint(db.oUF.ToT.Texts.HealthMissing.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.ToT.Texts.HealthMissing.X), tonumber(db.oUF.ToT.Texts.HealthMissing.Y))
												end,
											order = 10,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.HealthMissing.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored HealthMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.HealthMissing.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.ToT.Texts.HealthMissing.ColorClass = not db.oUF.ToT.Texts.HealthMissing.ColorClass
														if ClassColor == true then
															db.oUF.ToT.Texts.HealthMissing.ColorGradient = false
															db.oUF.ToT.Texts.HealthMissing.IndividualColor.Enable = false
															
															print("ToT HealthMissing Value Color will change once you gain/lose Health")
														end
													end,
											order = 1,
										},
										ColorGradient = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored HealthMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.HealthMissing.ColorGradient end,
											set = function(self,ColorGradient)
														db.oUF.ToT.Texts.HealthMissing.ColorGradient = not db.oUF.ToT.Texts.HealthMissing.ColorGradient
														if ColorGradient == true then
															db.oUF.ToT.Texts.HealthMissing.ColorClass = false
															db.oUF.ToT.Texts.HealthMissing.IndividualColor.Enable = false
															
															print("ToT HealthMissing Value Color will change once you gain/lose Health")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual ToT HealthMissing Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.HealthMissing.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.ToT.Texts.HealthMissing.IndividualColor.Enable = not db.oUF.ToT.Texts.HealthMissing.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.ToT.Texts.HealthMissing.ColorClass = false
															db.oUF.ToT.Texts.HealthMissing.ColorGradient = false
															
															oUF_LUI_targettarget.Health.valueMissing:SetTextColor(tonumber(db.oUF.ToT.Texts.HealthMissing.IndividualColor.r),tonumber(db.oUF.ToT.Texts.HealthMissing.IndividualColor.g),tonumber(db.oUF.ToT.Texts.HealthMissing.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual ToT HealthMissing Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.ToT.Texts.HealthMissing.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.ToT.Texts.HealthMissing.IndividualColor.r, db.oUF.ToT.Texts.HealthMissing.IndividualColor.g, db.oUF.ToT.Texts.HealthMissing.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.ToT.Texts.HealthMissing.IndividualColor.r = r
													db.oUF.ToT.Texts.HealthMissing.IndividualColor.g = g
													db.oUF.ToT.Texts.HealthMissing.IndividualColor.b = b
													
													oUF_LUI_targettarget.Health.valueMissing:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
						PowerMissing = {
							name = "PowerMissing",
							type = "group",
							order = 7,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the ToT PowerMissing or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Texts.PowerMissing.Enable end,
									set = function(self,Enable)
											db.oUF.ToT.Texts.PowerMissing.Enable = not db.oUF.ToT.Texts.PowerMissing.Enable
											if Enable == true then
												oUF_LUI_targettarget.Power.valueMissing:Show()
											else
												oUF_LUI_targettarget.Power.valueMissing:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your ToT PowerMissing Fontsize!\n Default: "..LUI.defaults.profile.oUF.ToT.Texts.PowerMissing.Size,
											disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.ToT.Texts.PowerMissing.Size end,
											set = function(_, FontSize)
													db.oUF.ToT.Texts.PowerMissing.Size = FontSize
													oUF_LUI_targettarget.Power.valueMissing:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.PowerMissing.Font),db.oUF.ToT.Texts.PowerMissing.Size,db.oUF.ToT.Texts.PowerMissing.Outline)
												end,
											order = 1,
										},
										empty = {
											order = 2,
											width = "full",
											type = "description",
											name = " ",
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show ToT PowerMissing or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.PowerMissing.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.ToT.Texts.PowerMissing.ShowAlways = not db.oUF.ToT.Texts.PowerMissing.ShowAlways
												end,
											order = 3,
										},
										ShortValue = {
											name = "Short Value",
											desc = "Show a Short or the Normal Value of the Missing HP",
											disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.PowerMissing.ShortValue end,
											set = function(self,ShortValue)
													db.oUF.ToT.Texts.PowerMissing.ShortValue = not db.oUF.ToT.Texts.PowerMissing.ShortValue
												end,
											order = 4,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for ToT PowerMissing!\n\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerMissing.Font,
											disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.ToT.Texts.PowerMissing.Font end,
											set = function(self, Font)
													db.oUF.ToT.Texts.PowerMissing.Font = Font
													oUF_LUI_targettarget.Power.valueMissing:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.PowerMissing.Font),db.oUF.ToT.Texts.PowerMissing.Size,db.oUF.ToT.Texts.PowerMissing.Outline)
												end,
											order = 5,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your ToT PowerMissing.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerMissing.Outline,
											disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.ToT.Texts.PowerMissing.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.ToT.Texts.PowerMissing.Outline = fontflags[FontFlag]
													oUF_LUI_targettarget.Power.valueMissing:SetFont(LSM:Fetch("font", db.oUF.ToT.Texts.PowerMissing.Font),db.oUF.ToT.Texts.PowerMissing.Size,db.oUF.ToT.Texts.PowerMissing.Outline)
												end,
											order = 6,
										},
										PowerMissingX = {
											name = "X Value",
											desc = "X Value for your ToT PowerMissing.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerMissing.X,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
											get = function() return db.oUF.ToT.Texts.PowerMissing.X end,
											set = function(self,PowerMissingX)
														if PowerMissingX == nil or PowerMissingX == "" then
															PowerMissingX = "0"
														end
														db.oUF.ToT.Texts.PowerMissing.X = PowerMissingX
														oUF_LUI_targettarget.Power.valueMissing:ClearAllPoints()
														oUF_LUI_targettarget.Power.valueMissing:SetPoint(db.oUF.ToT.Texts.PowerMissing.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.ToT.Texts.PowerMissing.X), tonumber(db.oUF.ToT.Texts.PowerMissing.Y))
													end,
											order = 7,
										},
										PowerMissingY = {
											name = "Y Value",
											desc = "Y Value for your ToT PowerMissing.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerMissing.Y,
											type = "input",
											disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
											get = function() return db.oUF.ToT.Texts.PowerMissing.Y end,
											set = function(self,PowerMissingY)
														if PowerMissingY == nil or PowerMissingY == "" then
															PowerMissingY = "0"
														end
														db.oUF.ToT.Texts.PowerMissing.Y = PowerMissingY
														oUF_LUI_targettarget.Power.valueMissing:ClearAllPoints()
														oUF_LUI_targettarget.Power.valueMissing:SetPoint(db.oUF.ToT.Texts.PowerMissing.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.ToT.Texts.PowerMissing.X), tonumber(db.oUF.ToT.Texts.PowerMissing.Y))
													end,
											order = 8,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your ToT PowerMissing.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerMissing.Point,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.PowerMissing.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.ToT.Texts.PowerMissing.Point = positions[Point]
													oUF_LUI_targettarget.Power.valueMissing:ClearAllPoints()
													oUF_LUI_targettarget.Power.valueMissing:SetPoint(db.oUF.ToT.Texts.PowerMissing.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.ToT.Texts.PowerMissing.X), tonumber(db.oUF.ToT.Texts.PowerMissing.Y))
												end,
											order = 9,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your ToT PowerMissing.\nDefault: "..LUI.defaults.profile.oUF.ToT.Texts.PowerMissing.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.ToT.Texts.PowerMissing.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.ToT.Texts.PowerMissing.RelativePoint = positions[RelativePoint]
													oUF_LUI_targettarget.Power.valueMissing:ClearAllPoints()
													oUF_LUI_targettarget.Power.valueMissing:SetPoint(db.oUF.ToT.Texts.PowerMissing.Point, oUF_LUI_targettarget, db.oUF.ToT.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.ToT.Texts.PowerMissing.X), tonumber(db.oUF.ToT.Texts.PowerMissing.Y))
												end,
											order = 10,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.ToT.Texts.PowerMissing.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored PowerMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.PowerMissing.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.ToT.Texts.PowerMissing.ColorClass = not db.oUF.ToT.Texts.PowerMissing.ColorClass
														if ClassColor == true then
															db.oUF.ToT.Texts.PowerMissing.ColorType = false
															db.oUF.ToT.Texts.PowerMissing.IndividualColor.Enable = false
															
															print("ToT PowerMissing Value Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										ColorType = {
											name = "Color by Type",
											desc = "Wether you want to use Type colored PowerMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.PowerMissing.ColorType end,
											set = function(self,ColorType)
														db.oUF.ToT.Texts.PowerMissing.ColorType = not db.oUF.ToT.Texts.PowerMissing.ColorType
														if ColorType == true then
															db.oUF.ToT.Texts.PowerMissing.ColorClass = false
															db.oUF.ToT.Texts.PowerMissing.IndividualColor.Enable = false
															
															print("ToT PowerMissing Value Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual ToT PowerMissing Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.ToT.Texts.PowerMissing.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.ToT.Texts.PowerMissing.IndividualColor.Enable = not db.oUF.ToT.Texts.PowerMissing.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.ToT.Texts.PowerMissing.ColorClass = false
															db.oUF.ToT.Texts.PowerMissing.ColorType = false
															
															oUF_LUI_targettarget.Power.valueMissing:SetTextColor(tonumber(db.oUF.ToT.Texts.PowerMissing.IndividualColor.r),tonumber(db.oUF.ToT.Texts.PowerMissing.IndividualColor.g),tonumber(db.oUF.ToT.Texts.PowerMissing.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual ToT PowerMissing Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.ToT.Texts.PowerMissing.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.ToT.Texts.PowerMissing.IndividualColor.r, db.oUF.ToT.Texts.PowerMissing.IndividualColor.g, db.oUF.ToT.Texts.PowerMissing.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.ToT.Texts.PowerMissing.IndividualColor.r = r
													db.oUF.ToT.Texts.PowerMissing.IndividualColor.g = g
													db.oUF.ToT.Texts.PowerMissing.IndividualColor.b = b
													
													oUF_LUI_targettarget.Power.valueMissing:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
					},
				},
				Aura = {
					name = "Aura",
					type = "group",
					order = 7,
					disabled = function() return not db.oUF.ToT.Enable end,
					childGroups = "tab",
					args = {
						header1 = {
							name = "ToT Auras",
							type = "header",
							order = 1,
						},
						ToTBuffs = {
							name = "Buffs",
							type = "group",
							order = 2,
							args = {
								ToTBuffsEnable = {
									name = "Enable ToT Buffs",
									desc = "Wether you want to show Target's Target Buffs or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Aura.buffs_enable end,
									set = function(self,ToTBuffsEnable)
												db.oUF.ToT.Aura.buffs_enable = not db.oUF.ToT.Aura.buffs_enable
											end,
									order = 0,
								},
								ToTBuffsAuratimer = {
									name = "Enable Auratimer",
									desc = "Wether you want to show Auratimers or not.",
									type = "toggle",
									disabled = function() return not db.oUF.ToT.Aura.buffs_enable end,
									get = function() return db.oUF.ToT.Aura.buffs_auratimer end,
									set = function(self,ToTBuffsAuratimer)
												db.oUF.ToT.Aura.buffs_auratimer = not db.oUF.ToT.Aura.buffs_auratimer
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								ToTBuffsPlayerBuffsOnly = {
									name = "Player Buffs Only",
									desc = "Wether you want to show only your Buffs on ToT or not.",
									type = "toggle",
									disabled = function() return not db.oUF.ToT.Aura.buffs_enable end,
									get = function() return db.oUF.ToT.Aura.buffs_playeronly end,
									set = function(self,ToTBuffsPlayerBuffsOnly)
												db.oUF.ToT.Aura.buffs_playeronly = not db.oUF.ToT.Aura.buffs_playeronly
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 2,
								},
								ToTBuffsNum = {
									name = "Amount",
									desc = "Amount of your ToT Buffs.\nDefault: 36",
									type = "input",
									disabled = function() return not db.oUF.ToT.Aura.buffs_enable end,
									get = function() return db.oUF.ToT.Aura.buffs_num end,
									set = function(self,ToTBuffsNum)
												if ToTBuffsNum == nil or ToTBuffsNum == "" then
													ToTBuffsNum = "0"
												end
												db.oUF.ToT.Aura.buffs_num = ToTBuffsNum
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 3,
								},
								ToTBuffsSize = {
									name = "Size",
									desc = "Size for your ToT Buffs.\nDefault: 26",
									type = "input",
									disabled = function() return not db.oUF.ToT.Aura.buffs_enable end,
									get = function() return db.oUF.ToT.Aura.buffs_size end,
									set = function(self,ToTBuffsSize)
												if ToTBuffsSize == nil or ToTBuffsSize == "" then
													ToTBuffsSize = "0"
												end
												db.oUF.ToT.Aura.buffs_size = ToTBuffsSize
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 4,
								},
								ToTBuffsSpacing = {
									name = "Spacing",
									desc = "Spacing between your ToT Buffs.\nDefault: 2",
									type = "input",
									disabled = function() return not db.oUF.ToT.Aura.buffs_enable end,
									get = function() return db.oUF.ToT.Aura.buffs_spacing end,
									set = function(self,ToTBuffsSpacing)
												if ToTBuffsSpacing == nil or ToTBuffsSpacing == "" then
													ToTBuffsSpacing = "0"
												end
												db.oUF.ToT.Aura.buffs_spacing = ToTBuffsSpacing
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 5,
								},
								ToTBuffsX = {
									name = "X Value",
									desc = "X Value for your ToT Buffs.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: -0.5",
									type = "input",
									disabled = function() return not db.oUF.ToT.Aura.buffs_enable end,
									get = function() return db.oUF.ToT.Aura.buffsX end,
									set = function(self,ToTBuffsX)
												if ToTBuffsX == nil or ToTBuffsX == "" then
													ToTBuffsX = "0"
												end
												db.oUF.ToT.Aura.buffsX = ToTBuffsX
												oUF_LUI_targettarget.Buffs:SetPoint(db.oUF.ToT.Aura.buffs_initialAnchor, oUF_LUI_targettarget, db.oUF.ToT.Aura.buffs_initialAnchor, ToTBuffsX, db.oUF.ToT.Aura.buffsY)
											end,
									order = 6,
								},
								ToTBuffsY = {
									name = "Y Value",
									desc = "Y Value for your ToT Buffs.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: 32",
									type = "input",
									disabled = function() return not db.oUF.ToT.Aura.buffs_enable end,
									get = function() return db.oUF.ToT.Aura.buffsY end,
									set = function(self,ToTBuffsY)
												if ToTBuffsY == nil or ToTBuffsY == "" then
													ToTBuffsY = "0"
												end
												db.oUF.ToT.Aura.buffsY = ToTBuffsY
												oUF_LUI_targettarget.Buffs:SetPoint(db.oUF.ToT.Aura.buffs_initialAnchor, oUF_LUI_targettarget, db.oUF.ToT.Aura.buffs_initialAnchor, db.oUF.ToT.Aura.buffsX, ToTBuffsY)
											end,
									order = 7,
								},
								ToTBuffsGrowthY = {
									name = "Growth Y",
									desc = "Choose the growth Y direction for your ToT Buffs.\nDefault: UP",
									type = "select",
									disabled = function() return not db.oUF.ToT.Aura.buffs_enable end,
									values = growthY,
									get = function()
											for k, v in pairs(growthY) do
												if db.oUF.ToT.Aura.buffs_growthY == v then
													return k
												end
											end
										end,
									set = function(self, ToTBuffsGrowthY)
											db.oUF.ToT.Aura.buffs_growthY = growthY[ToTBuffsGrowthY]
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 8,
								},
								ToTBuffsGrowthX = {
									name = "Growth X",
									desc = "Choose the growth X direction for your ToT Buffs.\nDefault: RIGHT",
									type = "select",
									disabled = function() return not db.oUF.ToT.Aura.buffs_enable end,
									values = growthX,
									get = function()
											for k, v in pairs(growthX) do
												if db.oUF.ToT.Aura.buffs_growthX == v then
													return k
												end
											end
										end,
									set = function(self, ToTBuffsGrowthX)
											db.oUF.ToT.Aura.buffs_growthX = growthX[ToTBuffsGrowthX]
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 9,
								},
								ToTBuffsAnchor = {
									name = "Initial Anchor",
									desc = "Choose the initinal Anchor for your ToT Buffs.\nDefault: TOPLEFT",
									type = "select",
									disabled = function() return not db.oUF.ToT.Aura.buffs_enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.ToT.Aura.buffs_initialAnchor == v then
													return k
												end
											end
										end,
									set = function(self, ToTBuffsAnchor)
											db.oUF.ToT.Aura.buffs_initialAnchor = positions[ToTBuffsAnchor]
											oUF_LUI_targettarget.Buffs:SetPoint(positions[ToTBuffsAnchor], oUF_LUI_targettarget, positions[ToTBuffsAnchor], db.oUF.ToT.Aura.buffsX, db.oUF.ToT.Aura.buffsY)
										end,
									order = 10,
								},
							},
						},
						ToTDebuffs = {
							name = "Debuffs",
							type = "group",
							order = 3,
							args = {
								ToTDebuffsEnable = {
									name = "Enable ToT Debuffs",
									desc = "Wether you want to show Target's Target Debuffs or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Aura.debuffs_enable end,
									set = function(self,ToTDebuffsEnable)
												db.oUF.ToT.Aura.debuffs_enable = not db.oUF.ToT.Aura.debuffs_enable
											end,
									order = 0,
								},
								ToTDebuffsAuratimer = {
									name = "Enable Auratimer",
									desc = "Wether you want to show Auratimers or not.\nDefault: Off",
									type = "toggle",
									disabled = function() return not db.oUF.ToT.Aura.debuffs_enable end,
									get = function() return db.oUF.ToT.Aura.debuffs_auratimer end,
									set = function(self,ToTDebuffsAuratimer)
												db.oUF.ToT.Aura.debuffs_auratimer = not db.oUF.ToT.Aura.debuffs_auratimer
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								ToTDebuffsColorByType = {
									name = "Color by Type",
									desc = "Wether you want to color ToT Debuffs by Type or not.",
									type = "toggle",
									disabled = function() return not db.oUF.ToT.Aura.debuffs_enable end,
									get = function() return db.oUF.ToT.Aura.debuffs_colorbytype end,
									set = function(self,ToTDebuffsColorByType)
												db.oUF.ToT.Aura.debuffs_colorbytype = not db.oUF.ToT.Aura.debuffs_colorbytype
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 2,
								},
								ToTDebuffsNum = {
									name = "Amount",
									desc = "Amount of your ToT Debuffs.\nDefault: 36",
									type = "input",
									disabled = function() return not db.oUF.ToT.Aura.debuffs_enable end,
									get = function() return db.oUF.ToT.Aura.debuffs_num end,
									set = function(self,ToTDebuffsNum)
												if ToTDebuffsNum == nil or ToTDebuffsNum == "" then
													ToTDebuffsNum = "0"
												end
												db.oUF.ToT.Aura.debuffs_num = ToTDebuffsNum
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 3,
								},
								ToTDebuffsSize = {
									name = "Size",
									desc = "Size for your ToT Debuffs.\nDefault: 26",
									type = "input",
									disabled = function() return not db.oUF.ToT.Aura.debuffs_enable end,
									get = function() return db.oUF.ToT.Aura.debuffs_size end,
									set = function(self,ToTDebuffsSize)
												if ToTDebuffsSize == nil or ToTDebuffsSize == "" then
													ToTDebuffsSize = "0"
												end
												db.oUF.ToT.Aura.debuffs_size = ToTDebuffsSize
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 4,
								},
								ToTDebuffsSpacing = {
									name = "Spacing",
									desc = "Spacing between your ToT Debuffs.\nDefault: 2",
									type = "input",
									disabled = function() return not db.oUF.ToT.Aura.debuffs_enable end,
									get = function() return db.oUF.ToT.Aura.debuffs_spacing end,
									set = function(self,ToTDebuffsSpacing)
												if ToTDebuffsSpacing == nil or ToTDebuffsSpacing == "" then
													ToTDebuffsSpacing = "0"
												end
												db.oUF.ToT.Aura.debuffs_spacing = ToTDebuffsSpacing
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 5,
								},
								ToTDebuffsX = {
									name = "X Value",
									desc = "X Value for your ToT Debuffs.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: -0.5",
									type = "input",
									disabled = function() return not db.oUF.ToT.Aura.debuffs_enable end,
									get = function() return db.oUF.ToT.Aura.debuffsX end,
									set = function(self,ToTDebuffsX)
												if ToTDebuffsX == nil or ToTDebuffsX == "" then
													ToTDebuffsX = "0"
												end
												db.oUF.ToT.Aura.debuffsX = ToTDebuffsX
												oUF_LUI_targettarget.Debuffs:SetPoint(db.oUF.ToT.Aura.debuffs_initialAnchor, oUF_LUI_targettarget, db.oUF.ToT.Aura.debuffs_initialAnchor, ToTDebuffsX, db.oUF.ToT.Aura.debuffsY)
											end,
									order = 6,
								},
								ToTDebuffsY = {
									name = "Y Value",
									desc = "Y Value for your ToT Debuffs.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: 60",
									type = "input",
									disabled = function() return not db.oUF.ToT.Aura.debuffs_enable end,
									get = function() return db.oUF.ToT.Aura.debuffsY end,
									set = function(self,ToTDebuffsY)
												if ToTDebuffsY == nil or ToTDebuffsY == "" then
													ToTDebuffsY = "0"
												end
												db.oUF.ToT.Aura.debuffsY = ToTDebuffsY
												oUF_LUI_targettarget.Debuffs:SetPoint(db.oUF.ToT.Aura.debuffs_initialAnchor, oUF_LUI_targettarget, db.oUF.ToT.Aura.debuffs_initialAnchor, db.oUF.ToT.Aura.debuffsX, ToTDebuffsY)
											end,
									order = 7,
								},
								ToTDebuffsGrowthY = {
									name = "Growth Y",
									desc = "Choose the growth Y direction for your ToT Debuffs.\nDefault: UP",
									type = "select",
									disabled = function() return not db.oUF.ToT.Aura.debuffs_enable end,
									values = growthY,
									get = function()
											for k, v in pairs(growthY) do
												if db.oUF.ToT.Aura.debuffs_growthY == v then
													return k
												end
											end
										end,
									set = function(self, ToTDebuffsGrowthY)
											db.oUF.ToT.Aura.debuffs_growthY = growthY[ToTDebuffsGrowthY]
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 8,
								},
								ToTDebuffsGrowthX = {
									name = "Growth X",
									desc = "Choose the growth X direction for your ToT Debuffs.\nDefault: LEFT",
									type = "select",
									disabled = function() return not db.oUF.ToT.Aura.debuffs_enable end,
									values = growthX,
									get = function()
											for k, v in pairs(growthX) do
												if db.oUF.ToT.Aura.debuffs_growthX == v then
													return k
												end
											end
										end,
									set = function(self, ToTDebuffsGrowthX)
											db.oUF.ToT.Aura.debuffs_growthX = growthX[ToTDebuffsGrowthX]
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 9,
								},
								ToTDebuffsAnchor = {
									name = "Initial Anchor",
									desc = "Choose the initinal Anchor for your ToT Debuffs.\nDefault: TOPRIGHT",
									type = "select",
									disabled = function() return not db.oUF.ToT.Aura.debuffs_enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.ToT.Aura.debuffs_initialAnchor == v then
													return k
												end
											end
										end,
									set = function(self, ToTDebuffsAnchor)
											db.oUF.ToT.Aura.debuffs_initialAnchor = positions[ToTDebuffsAnchor]
											oUF_LUI_targettarget.Debuffs:SetPoint(positions[ToTDebuffsAnchor], oUF_LUI_targettarget, positions[ToTDebuffsAnchor], db.oUF.ToT.Aura.debuffsX, db.oUF.ToT.Aura.debuffsY)
										end,
									order = 10,
								},
							},
						},
					},
				},
				Portrait = {
					name = "Portrait",
					type = "group",
					disabled = function() return not db.oUF.ToT.Enable end,
					order = 8,
					args = {
						EnablePortrait = {
							name = "Enable",
							desc = "Wether you want to show the Portrait or not.",
							type = "toggle",
							width = "full",
							get = function() return db.oUF.ToT.Portrait.Enable end,
							set = function(self,EnablePortrait)
										db.oUF.ToT.Portrait.Enable = not db.oUF.ToT.Portrait.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 1,
						},
						PortraitWidth = {
							name = "Width",
							desc = "Choose the Width for your Portrait.\nDefault: "..LUI.defaults.profile.oUF.ToT.Portrait.Width,
							type = "input",
							disabled = function() return not db.oUF.ToT.Portrait.Enable end,
							get = function() return db.oUF.ToT.Portrait.Width end,
							set = function(self,PortraitWidth)
										if PortraitWidth == nil or PortraitWidth == "" then
											PortraitWidth = "0"
										end
										db.oUF.ToT.Portrait.Width = PortraitWidth
										oUF_LUI_targettarget.Portrait:SetWidth(tonumber(PortraitWidth))
									end,
							order = 2,
						},
						PortraitHeight = {
							name = "Height",
							desc = "Choose the Height for your Portrait.\nDefault: "..LUI.defaults.profile.oUF.ToT.Portrait.Width,
							type = "input",
							disabled = function() return not db.oUF.ToT.Portrait.Enable end,
							get = function() return db.oUF.ToT.Portrait.Height end,
							set = function(self,PortraitHeight)
										if PortraitHeight == nil or PortraitHeight == "" then
											PortraitHeight = "0"
										end
										db.oUF.ToT.Portrait.Height = PortraitHeight
										oUF_LUI_targettarget.Portrait:SetHeight(tonumber(PortraitHeight))
									end,
							order = 3,
						},
						PortraitX = {
							name = "X Value",
							desc = "X Value for your Portrait.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Portrait.X,
							type = "input",
							disabled = function() return not db.oUF.ToT.Portrait.Enable end,
							get = function() return db.oUF.ToT.Portrait.X end,
							set = function(self,PortraitX)
										if PortraitX == nil or PortraitX == "" then
											PortraitX = "0"
										end
										db.oUF.ToT.Portrait.X = PortraitX
										oUF_LUI_targettarget.Portrait:SetPoint("TOPLEFT", oUF_LUI_targettarget.Health, "TOPLEFT", PortraitX, db.oUF.ToT.Portrait.Y)
									end,
							order = 4,
						},
						PortraitY = {
							name = "Y Value",
							desc = "Y Value for your Portrait.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Portrait.Y,
							type = "input",
							disabled = function() return not db.oUF.ToT.Portrait.Enable end,
							get = function() return db.oUF.ToT.Portrait.Y end,
							set = function(self,PortraitY)
										if PortraitY == nil or PortraitY == "" then
											PortraitY = "0"
										end
										db.oUF.ToT.Portrait.Y = PortraitY
										oUF_LUI_targettarget.Portrait:SetPoint("TOPLEFT", oUF_LUI_targettarget.Health, "TOPLEFT", db.oUF.ToT.Portrait.X, PortraitY)
									end,
							order = 5,
						},
					},
				},
				Icons = {
					name = "Icons",
					type = "group",
					order = 9,
					disabled = function() return not db.oUF.ToT.Enable end,
					childGroups = "tab",
					args = {
						Lootmaster = {
							name = "Lootmaster",
							type = "group",
							order = 1,
							args = {
								LootMasterEnable = {
									name = "Enable",
									desc = "Wether you want to show the LootMaster Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Icons.Lootmaster.Enable end,
									set = function(self,LootMasterEnable)
												db.oUF.ToT.Icons.Lootmaster.Enable = not db.oUF.ToT.Icons.Lootmaster.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								LootMasterX = {
									name = "X Value",
									desc = "X Value for your LootMaster Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Lootmaster.X,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Lootmaster.Enable end,
									get = function() return db.oUF.ToT.Icons.Lootmaster.X end,
									set = function(self,LootMasterX)
												if LootMasterX == nil or LootMasterX == "" then
													LootMasterX = "0"
												end
												db.oUF.ToT.Icons.Lootmaster.X = LootMasterX
												oUF_LUI_targettarget.MasterLooter:ClearAllPoints()
												oUF_LUI_targettarget.MasterLooter:SetPoint(db.oUF.ToT.Icons.Lootmaster.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Lootmaster, tonumber(LootMasterX), tonumber(db.oUF.ToT.Icons.Lootmaster.Y))
											end,
									order = 2,
								},
								LootMasterY = {
									name = "Y Value",
									desc = "Y Value for your LootMaster Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Lootmaster.Y,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Lootmaster.Enable end,
									get = function() return db.oUF.ToT.Icons.Lootmaster.Y end,
									set = function(self,LootMasterY)
												if LootMasterY == nil or LootMasterY == "" then
													LootMasterY = "0"
												end
												db.oUF.ToT.Icons.Lootmaster.Y = LootMasterY
												oUF_LUI_targettarget.MasterLooter:ClearAllPoints()
												oUF_LUI_targettarget.MasterLooter:SetPoint(db.oUF.ToT.Icons.Lootmaster.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Lootmaster, tonumber(db.oUF.ToT.Icons.Lootmaster.X), tonumber(LootMasterY))
											end,
									order = 3,
								},
								LootMasterPoint = {
									name = "Position",
									desc = "Choose the Position for your LootMaster Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Lootmaster.Point,
									type = "select",
									disabled = function() return not db.oUF.ToT.Icons.Lootmaster.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.ToT.Icons.Lootmaster.Point == v then
													return k
												end
											end
										end,
									set = function(self, LootMasterPoint)
											db.oUF.ToT.Icons.Lootmaster.Point = positions[LootMasterPoint]
											oUF_LUI_targettarget.MasterLooter:ClearAllPoints()
											oUF_LUI_targettarget.MasterLooter:SetPoint(db.oUF.ToT.Icons.Lootmaster.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Lootmaster.Point, tonumber(db.oUF.ToT.Icons.Lootmaster.X), tonumber(db.oUF.ToT.Icons.Lootmaster.X))
										end,
									order = 4,
								},
								LootMasterSize = {
									name = "Size",
									desc = "Choose a size for your LootMaster Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Lootmaster.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.ToT.Icons.Lootmaster.Enable end,
									get = function() return db.oUF.ToT.Icons.Lootmaster.Size end,
									set = function(_, LootMasterSize) 
											db.oUF.ToT.Icons.Lootmaster.Size = LootMasterSize
											oUF_LUI_targettarget.MasterLooter:SetHeight(LootMasterSize)
											oUF_LUI_targettarget.MasterLooter:SetWidth(LootMasterSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.ToT.Icons.Lootmaster.Enable end,
									desc = "Toggles the LootMaster Icon",
									type = 'execute',
									func = function() if oUF_LUI_targettarget.MasterLooter:IsShown() then oUF_LUI_targettarget.MasterLooter:Hide() else oUF_LUI_targettarget.MasterLooter:Show() end end
								},
							},
						},
						Leader = {
							name = "Leader",
							type = "group",
							order = 2,
							args = {
								LeaderEnable = {
									name = "Enable",
									desc = "Wether you want to show the Leader Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Icons.Leader.Enable end,
									set = function(self,LeaderEnable)
												db.oUF.ToT.Icons.Leader.Enable = not db.oUF.ToT.Icons.Leader.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								LeaderX = {
									name = "X Value",
									desc = "X Value for your Leader Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Leader.X,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Leader.Enable end,
									get = function() return db.oUF.ToT.Icons.Leader.X end,
									set = function(self,LeaderX)
												if LeaderX == nil or LeaderX == "" then
													LeaderX = "0"
												end
												db.oUF.ToT.Icons.Leader.X = LeaderX
												oUF_LUI_targettarget.Leader:ClearAllPoints()
												oUF_LUI_targettarget.Leader:SetPoint(db.oUF.ToT.Icons.Leader.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Leader.Point, tonumber(LeaderX), tonumber(db.oUF.ToT.Icons.Leader.Y))
											end,
									order = 2,
								},
								LeaderY = {
									name = "Y Value",
									desc = "Y Value for your Leader Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Leader.Y,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Leader.Enable end,
									get = function() return db.oUF.ToT.Icons.Leader.Y end,
									set = function(self,LeaderY)
												if LeaderY == nil or LeaderY == "" then
													LeaderY = "0"
												end
												db.oUF.ToT.Icons.Leader.Y = LeaderY
												oUF_LUI_targettarget.Leader:ClearAllPoints()
												oUF_LUI_targettarget.Leader:SetPoint(db.oUF.ToT.Icons.Leader.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Leader.Point, tonumber(db.oUF.ToT.Icons.Leader.X), tonumber(LeaderY))
											end,
									order = 3,
								},
								LeaderPoint = {
									name = "Position",
									desc = "Choose the Position for your Leader Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Leader.Point,
									type = "select",
									disabled = function() return not db.oUF.ToT.Icons.Leader.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.ToT.Icons.Leader.Point == v then
													return k
												end
											end
										end,
									set = function(self, LeaderPoint)
											db.oUF.ToT.Icons.Leader.Point = positions[LeaderPoint]
											oUF_LUI_targettarget.Leader:ClearAllPoints()
											oUF_LUI_targettarget.Leader:SetPoint(db.oUF.ToT.Icons.Leader.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Leader.Point, tonumber(db.oUF.ToT.Icons.Leader.X), tonumber(db.oUF.ToT.Icons.Leader.X))
										end,
									order = 4,
								},
								LeaderSize = {
									name = "Size",
									desc = "Choose your Size for your Leader Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Leader.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.ToT.Icons.Leader.Enable end,
									get = function() return db.oUF.ToT.Icons.Leader.Size end,
									set = function(_, LeaderSize) 
											db.oUF.ToT.Icons.Leader.Size = LeaderSize
											oUF_LUI_targettarget.Leader:SetHeight(LeaderSize)
											oUF_LUI_targettarget.Leader:SetWidth(LeaderSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.ToT.Icons.Leader.Enable end,
									desc = "Toggles the Leader Icon",
									type = 'execute',
									func = function() if oUF_LUI_targettarget.Leader:IsShown() then oUF_LUI_targettarget.Leader:Hide() else oUF_LUI_targettarget.Leader:Show() end end
								},
							},
						},
						LFDRole = {
							name = "LFDRole",
							type = "group",
							order = 3,
							args = {
								RoleEnable = {
									name = "Enable",
									desc = "Wether you want to show the Group Role Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Icons.Role.Enable end,
									set = function(self,RoleEnable)
												db.oUF.ToT.Icons.Role.Enable = not db.oUF.ToT.Icons.Role.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								RoleX = {
									name = "X Value",
									desc = "X Value for your Group Role Icon Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Role.X,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Role.Enable end,
									get = function() return db.oUF.ToT.Icons.Role.X end,
									set = function(self,RoleX)
												if RoleX == nil or RoleX == "" then
													RoleX = "0"
												end
												db.oUF.ToT.Icons.Role.X = RoleX
												oUF_LUI_targettarget.LFDRole:ClearAllPoints()
												oUF_LUI_targettarget.LFDRole:SetPoint(db.oUF.ToT.Icons.Role.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Role.Point, tonumber(RoleX), tonumber(db.oUF.ToT.Icons.Role.Y))
											end,
									order = 2,
								},
								RoleY = {
									name = "Y Value",
									desc = "Y Value for your Role Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Role.Y,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Role.Enable end,
									get = function() return db.oUF.ToT.Icons.Role.Y end,
									set = function(self,RoleY)
												if RoleY == nil or RoleY == "" then
													RoleY = "0"
												end
												db.oUF.ToT.Icons.Role.Y = RoleY
												oUF_LUI_targettarget.LFDRole:ClearAllPoints()
												oUF_LUI_targettarget.LFDRole:SetPoint(db.oUF.ToT.Icons.Role.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Role.Point, tonumber(db.oUF.ToT.Icons.Role.X), tonumber(RoleY))
											end,
									order = 3,
								},
								RolePoint = {
									name = "Position",
									desc = "Choose the Position for your Role Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Role.Point,
									type = "select",
									disabled = function() return not db.oUF.ToT.Icons.Role.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.ToT.Icons.Role.Point == v then
													return k
												end
											end
										end,
									set = function(self, RolePoint)
											db.oUF.ToT.Icons.Role.Point = positions[RolePoint]
											oUF_LUI_targettarget.LFDRole:ClearAllPoints()
											oUF_LUI_targettarget.LFDRole:SetPoint(db.oUF.ToT.Icons.Role.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Role.Point, tonumber(db.oUF.ToT.Icons.Role.X), tonumber(db.oUF.ToT.Icons.Role.X))
										end,
									order = 4,
								},
								RoleSize = {
									name = "Size",
									desc = "Choose a Size for your Group Role Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Role.Size,
									type = "range",
									min = 5,
									max = 100,
									step = 1,
									disabled = function() return not db.oUF.ToT.Icons.Role.Enable end,
									get = function() return db.oUF.ToT.Icons.Role.Size end,
									set = function(_, RoleSize) 
											db.oUF.ToT.Icons.Role.Size = RoleSize
											oUF_LUI_targettarget.LFDRole:SetHeight(RoleSize)
											oUF_LUI_targettarget.LFDRole:SetWidth(RoleSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.ToT.Icons.Role.Enable end,
									desc = "Toggles the LFDRole Icon",
									type = 'execute',
									func = function() if oUF_LUI_targettarget.LFDRole:IsShown() then oUF_LUI_targettarget.LFDRole:Hide() else oUF_LUI_targettarget.LFDRole:Show() end end
								},
							},
						},
						Raid = {
							name = "RaidIcon",
							type = "group",
							order = 4,
							args = {
								RaidEnable = {
									name = "Enable",
									desc = "Wether you want to show the Raid Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Icons.Raid.Enable end,
									set = function(self,RaidEnable)
												db.oUF.ToT.Icons.Raid.Enable = not db.oUF.ToT.Icons.Raid.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								RaidX = {
									name = "X Value",
									desc = "X Value for your Raid Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Raid.X,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Raid.Enable end,
									get = function() return db.oUF.ToT.Icons.Raid.X end,
									set = function(self,RaidX)
												if RaidX == nil or RaidX == "" then
													RaidX = "0"
												end
												db.oUF.ToT.Icons.Raid.X = RaidX
												oUF_LUI_targettarget.RaidIcon:ClearAllPoints()
												oUF_LUI_targettarget.RaidIcon:SetPoint(db.oUF.ToT.Icons.Raid.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Raid.Point, tonumber(RaidX), tonumber(db.oUF.ToT.Icons.Raid.Y))
											end,
									order = 2,
								},
								RaidY = {
									name = "Y Value",
									desc = "Y Value for your Raid Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Raid.Y,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Raid.Enable end,
									get = function() return db.oUF.ToT.Icons.Raid.Y end,
									set = function(self,RaidY)
												if RaidY == nil or RaidY == "" then
													RaidY = "0"
												end
												db.oUF.ToT.Icons.Raid.Y = RaidY
												oUF_LUI_targettarget.RaidIcon:ClearAllPoints()
												oUF_LUI_targettarget.RaidIcon:SetPoint(db.oUF.ToT.Icons.Raid.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Raid.Point, tonumber(db.oUF.ToT.Icons.Raid.X), tonumber(RaidY))
											end,
									order = 3,
								},
								RaidPoint = {
									name = "Position",
									desc = "Choose the Position for your Raid Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Raid.Point,
									type = "select",
									disabled = function() return not db.oUF.ToT.Icons.Raid.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.ToT.Icons.Raid.Point == v then
													return k
												end
											end
										end,
									set = function(self, RaidPoint)
											db.oUF.ToT.Icons.Raid.Point = positions[RaidPoint]
											oUF_LUI_targettarget.RaidIcon:ClearAllPoints()
											oUF_LUI_targettarget.RaidIcon:SetPoint(db.oUF.ToT.Icons.Raid.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Raid.Point, tonumber(db.oUF.ToT.Icons.Raid.X), tonumber(db.oUF.ToT.Icons.Raid.X))
										end,
									order = 4,
								},
								RaidSize = {
									name = "Size",
									desc = "Choose a Size for your Raid Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Raid.Size,
									type = "range",
									min = 5,
									max = 200,
									step = 5,
									disabled = function() return not db.oUF.ToT.Icons.Raid.Enable end,
									get = function() return db.oUF.ToT.Icons.Raid.Size end,
									set = function(_, RaidSize) 
											db.oUF.ToT.Icons.Raid.Size = RaidSize
											oUF_LUI_targettarget.RaidIcon:SetHeight(RaidSize)
											oUF_LUI_targettarget.RaidIcon:SetWidth(RaidSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.ToT.Icons.Raid.Enable end,
									desc = "Toggles the RaidIcon",
									type = 'execute',
									func = function() if oUF_LUI_targettarget.RaidIcon:IsShown() then oUF_LUI_targettarget.RaidIcon:Hide() else oUF_LUI_targettarget.RaidIcon:Show() end end
								},
							},
						},
						Resting = {
							name = "Resting",
							type = "group",
							order = 5,
							args = {
								RestingEnable = {
									name = "Enable",
									desc = "Wether you want to show the Resting Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Icons.Resting.Enable end,
									set = function(self,RestingEnable)
												db.oUF.ToT.Icons.Resting.Enable = not db.oUF.ToT.Icons.Resting.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								RestingX = {
									name = "X Value",
									desc = "X Value for your Resting Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Resting.X,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Resting.Enable end,
									get = function() return db.oUF.ToT.Icons.Resting.X end,
									set = function(self,RestingX)
												if RestingX == nil or RestingX == "" then
													RestingX = "0"
												end
												db.oUF.ToT.Icons.Resting.X = RestingX
												oUF_LUI_targettarget.Resting:ClearAllPoints()
												oUF_LUI_targettarget.Resting:SetPoint(db.oUF.ToT.Icons.Resting.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Resting.Point, tonumber(RestingX), tonumber(db.oUF.ToT.Icons.Resting.Y))
											end,
									order = 2,
								},
								RestingY = {
									name = "Y Value",
									desc = "Y Value for your Resting Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Resting.Y,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Resting.Enable end,
									get = function() return db.oUF.ToT.Icons.Resting.Y end,
									set = function(self,RestingY)
												if RestingY == nil or RestingY == "" then
													RestingY = "0"
												end
												db.oUF.ToT.Icons.Resting.Y = RestingY
												oUF_LUI_targettarget.Resting:ClearAllPoints()
												oUF_LUI_targettarget.Resting:SetPoint(db.oUF.ToT.Icons.Resting.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Resting.Point, tonumber(db.oUF.ToT.Icons.Resting.X), tonumber(RestingY))
											end,
									order = 3,
								},
								RestingPoint = {
									name = "Position",
									desc = "Choose the Position for your Resting Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Resting.Point,
									type = "select",
									disabled = function() return not db.oUF.ToT.Icons.Resting.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.ToT.Icons.Resting.Point == v then
													return k
												end
											end
										end,
									set = function(self, RestingPoint)
											db.oUF.ToT.Icons.Resting.Point = positions[RestingPoint]
											oUF_LUI_targettarget.Resting:ClearAllPoints()
											oUF_LUI_targettarget.Resting:SetPoint(db.oUF.ToT.Icons.Resting.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Resting.Point, tonumber(db.oUF.ToT.Icons.Resting.X), tonumber(db.oUF.ToT.Icons.Resting.X))
										end,
									order = 4,
								},
								RestingSize = {
									name = "Size",
									desc = "Choose a Size for your Resting Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Resting.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.ToT.Icons.Resting.Enable end,
									get = function() return db.oUF.ToT.Icons.Resting.Size end,
									set = function(_, RestingSize) 
											db.oUF.ToT.Icons.Resting.Size = RestingSize
											oUF_LUI_targettarget.Resting:SetHeight(RestingSize)
											oUF_LUI_targettarget.Resting:SetWidth(RestingSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.ToT.Icons.Resting.Enable end,
									desc = "Toggles the Resting Icon",
									type = 'execute',
									func = function() if oUF_LUI_targettarget.Resting:IsShown() then oUF_LUI_targettarget.Resting:Hide() else oUF_LUI_targettarget.Resting:Show() end end
								},
							},
						},
						Combat = {
							name = "Combat",
							type = "group",
							order = 5,
							args = {
								CombatEnable = {
									name = "Enable",
									desc = "Wether you want to show the Combat Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Icons.Combat.Enable end,
									set = function(self,CombatEnable)
												db.oUF.ToT.Icons.Combat.Enable = not db.oUF.ToT.Icons.Combat.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								CombatX = {
									name = "X Value",
									desc = "X Value for your Combat Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Combat.X,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Combat.Enable end,
									get = function() return db.oUF.ToT.Icons.Combat.X end,
									set = function(self,CombatX)
												if CombatX == nil or CombatX == "" then
													CombatX = "0"
												end
												db.oUF.ToT.Icons.Combat.X = CombatX
												oUF_LUI_targettarget.Combat:ClearAllPoints()
												oUF_LUI_targettarget.Combat:SetPoint(db.oUF.ToT.Icons.Combat.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Combat.Point, tonumber(CombatX), tonumber(db.oUF.ToT.Icons.Combat.Y))
											end,
									order = 2,
								},
								CombatY = {
									name = "Y Value",
									desc = "Y Value for your Combat Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Combat.Y,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.Combat.Enable end,
									get = function() return db.oUF.ToT.Icons.Combat.Y end,
									set = function(self,CombatY)
												if CombatY == nil or CombatY == "" then
													CombatY = "0"
												end
												db.oUF.ToT.Icons.Combat.Y = CombatY
												oUF_LUI_targettarget.Combat:ClearAllPoints()
												oUF_LUI_targettarget.Combat:SetPoint(db.oUF.ToT.Icons.Combat.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Combat.Point, tonumber(db.oUF.ToT.Icons.Combat.X), tonumber(CombatY))
											end,
									order = 3,
								},
								CombatPoint = {
									name = "Position",
									desc = "Choose the Position for your Combat Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Combat.Point,
									type = "select",
									disabled = function() return not db.oUF.ToT.Icons.Combat.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.ToT.Icons.Combat.Point == v then
													return k
												end
											end
										end,
									set = function(self, CombatPoint)
											db.oUF.ToT.Icons.Combat.Point = positions[CombatPoint]
											oUF_LUI_targettarget.Combat:ClearAllPoints()
											oUF_LUI_targettarget.Combat:SetPoint(db.oUF.ToT.Icons.Combat.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.Combat.Point, tonumber(db.oUF.ToT.Icons.Combat.X), tonumber(db.oUF.ToT.Icons.Combat.X))
										end,
									order = 4,
								},
								CombatSize = {
									name = "Size",
									desc = "Choose a Size for your Combat Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.Combat.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.ToT.Icons.Combat.Enable end,
									get = function() return db.oUF.ToT.Icons.Combat.Size end,
									set = function(_, CombatSize) 
											db.oUF.ToT.Icons.Combat.Size = CombatSize
											oUF_LUI_targettarget.Combat:SetHeight(CombatSize)
											oUF_LUI_targettarget.Combat:SetWidth(CombatSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									disabled = function() return not db.oUF.ToT.Icons.Combat.Enable end,
									name = "Show/Hide",
									desc = "Toggles the Combat Icon",
									type = 'execute',
									func = function() if oUF_LUI_targettarget.Combat:IsShown() then oUF_LUI_targettarget.Combat:Hide() else oUF_LUI_targettarget.Combat:Show() end end
								},
							},
						},
						PvP = {
							name = "PvP",
							type = "group",
							order = 5,
							args = {
								PvPEnable = {
									name = "Enable",
									desc = "Wether you want to show the PvP Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.ToT.Icons.PvP.Enable end,
									set = function(self,PvPEnable)
												db.oUF.ToT.Icons.PvP.Enable = not db.oUF.ToT.Icons.PvP.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								PvPX = {
									name = "X Value",
									desc = "X Value for your PvP Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.PvP.X,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.PvP.Enable end,
									get = function() return db.oUF.ToT.Icons.PvP.X end,
									set = function(self,PvPX)
												if PvPX == nil or PvPX == "" then
													PvPX = "0"
												end
												db.oUF.ToT.Icons.PvP.X = PvPX
												oUF_LUI_targettarget.PvP:ClearAllPoints()
												oUF_LUI_targettarget.PvP:SetPoint(db.oUF.ToT.Icons.PvP.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.PvP.Point, tonumber(PvPX), tonumber(db.oUF.ToT.Icons.PvP.Y))
											end,
									order = 2,
								},
								PvPY = {
									name = "Y Value",
									desc = "Y Value for your PvP Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.PvP.Y,
									type = "input",
									disabled = function() return not db.oUF.ToT.Icons.PvP.Enable end,
									get = function() return db.oUF.ToT.Icons.PvP.Y end,
									set = function(self,PvPY)
												if PvPY == nil or PvPY == "" then
													PvPY = "0"
												end
												db.oUF.ToT.Icons.PvP.Y = PvPY
												oUF_LUI_targettarget.PvP:ClearAllPoints()
												oUF_LUI_targettarget.PvP:SetPoint(db.oUF.ToT.Icons.PvP.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.PvP.Point, tonumber(db.oUF.ToT.Icons.PvP.X), tonumber(PvPY))
											end,
									order = 3,
								},
								PvPPoint = {
									name = "Position",
									desc = "Choose the Position for your PvP Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.PvP.Point,
									type = "select",
									disabled = function() return not db.oUF.ToT.Icons.PvP.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.ToT.Icons.PvP.Point == v then
													return k
												end
											end
										end,
									set = function(self, PvPPoint)
											db.oUF.ToT.Icons.PvP.Point = positions[PvPPoint]
											oUF_LUI_targettarget.PvP:ClearAllPoints()
											oUF_LUI_targettarget.PvP:SetPoint(db.oUF.ToT.Icons.PvP.Point, oUF_LUI_targettarget, db.oUF.ToT.Icons.PvP.Point, tonumber(db.oUF.ToT.Icons.PvP.X), tonumber(db.oUF.ToT.Icons.PvP.X))
										end,
									order = 4,
								},
								PvPSize = {
									name = "Size",
									desc = "Choose a Size for your PvP Icon.\nDefault: "..LUI.defaults.profile.oUF.ToT.Icons.PvP.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.ToT.Icons.PvP.Enable end,
									get = function() return db.oUF.ToT.Icons.PvP.Size end,
									set = function(_, PvPSize) 
											db.oUF.ToT.Icons.PvP.Size = PvPSize
											oUF_LUI_targettarget.PvP:SetHeight(PvPSize)
											oUF_LUI_targettarget.PvP:SetWidth(PvPSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.ToT.Icons.PvP.Enable end,
									desc = "Toggles the PvP Icon",
									type = 'execute',
									func = function() if oUF_LUI_targettarget.PvP:IsShown() then oUF_LUI_targettarget.PvP:Hide() else oUF_LUI_targettarget.PvP:Show() end end
								},
							},
						},
					},
				},
			},
		},
	}
	
	return options
end

function module:OnInitialize()
	LUI:MergeDefaults(LUI.db.defaults.profile.oUF, defaults)
	LUI:RefreshDefaults()
	LUI:Refresh()
	
	self.db = LUI.db.profile
	db = self.db
end

function module:OnEnable()
	LUI:RegisterUnitFrame(self:LoadOptions())
end