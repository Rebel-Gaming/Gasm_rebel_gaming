--[[
	Project....: LUI NextGenWoWUserInterface
	File.......: target.lua
	Description: oUF Target Module
	Version....: 1.0
]] 

local LUI = LibStub("AceAddon-3.0"):GetAddon("LUI")
local module = LUI:NewModule("oUF_Target")
local LSM = LibStub("LibSharedMedia-3.0")
local widgetLists = AceGUIWidgetLSMlists

local positions = {"TOP", "TOPRIGHT", "TOPLEFT","BOTTOM", "BOTTOMRIGHT", "BOTTOMLEFT","RIGHT", "LEFT", "CENTER"}
local fontflags = {'OUTLINE', 'THICKOUTLINE', 'MONOCHROME', 'NONE'}
local valueFormat = {'Absolut', 'Absolut & Percent', 'Absolut Short', 'Absolut Short & Percent', 'Standard', 'Standard Short'}
local nameFormat = {'Name', 'Name + Level', 'Name + Level + Class', 'Name + Level + Race + Class', 'Level + Name', 'Level + Name + Class', 'Level + Class + Name', 'Level + Name + Race + Class', 'Level + Race + Class + Name'}
local nameLenghts = {'Short', 'Medium', 'Long'}
local growthY = {"UP", "DOWN"}
local growthX = {"LEFT", "RIGHT"}

local defaults = {
	Target = {
		Height = "43",
		Width = "250",
		X = "200",
		Y = "-200",
		Border = {
			EdgeFile = "glow",
			EdgeSize = 5,
			Insets = {
				Left = "3",
				Right = "3",
				Top = "3",
				Bottom = "3",
			},
			Color = {
				r = "0",
				g = "0",
				b = "0",
				a = "1",
			},
		},
		Backdrop = {
			Texture = "Blizzard Tooltip",
			Padding = {
				Left = "-4",
				Right = "4",
				Top = "4",
				Bottom = "-4",
			},
			Color = {
				r = 0,
				g = 0,
				b = 0,
				a = 1,
			},
		},
		Health = {
			Height = "30",
			Padding = "0",
			ColorClass = false,
			ColorGradient = false,
			Texture = "LUI_Gradient",
			TextureBG = "LUI_Gradient",
			BGAlpha = 1,
			BGMultiplier = 0.4,
			Smooth = true,
			Tapping = false,
			IndividualColor = {
				Enable = true,
				r = 0.2509803921568627,
				g = 0.2509803921568627,
				b = 0.2509803921568627,
			},
		},
		Power = {
			Enable = true,
			Height = "10",
			Padding = "-2",
			ColorClass = true,
			ColorType = false,
			Texture = "LUI_Minimalist",
			TextureBG = "LUI_Minimalist",
			BGAlpha = 1,
			BGMultiplier = 0.4,
			Smooth = true,
			IndividualColor = {
				Enable = false,
				r = 0.8,
				g = 0.8,
				b = 0.8,
			},
		},
		Full = {
			Enable = false,
			Height = "17",
			Texture = "LUI_Minimalist",
			Padding = "-12",
			Alpha = 1,
			Color = {
				r = "0.11",
				g = "0.11",
				b = "0.11",
				a = "1",
			},
		},
		ComboPoints = {
			Enable = true,
			ShowAlways = false,
			X = "0",
			Y = "0.5",
			Height = "5",
			Width = "249",
			Texture = "LUI_Ruben",
			Multiplier = 0.4,
			BackgroundColor = {
				Enable = true,
				r = 0.23,
				g = 0.23,
				b = 0.23,
			},
		},
		Aura = {
			buffs_playeronly = false,
			buffs_enable = true,
			buffs_auratimer = false,
			buffsX = "-0.5",
			buffsY = "30",
			buffs_initialAnchor = "TOPLEFT",
			buffs_growthY = "UP",
			buffs_growthX = "RIGHT",
			buffs_size = "26",
			buffs_spacing = "2",
			buffs_num = "36",
			debuffs_colorbytype = false,
			debuffs_playeronly = false,
			debuffs_enable = true,
			debuffs_auratimer = false,
			debuffsX = "-0.5",
			debuffsY = "60",
			debuffs_initialAnchor = "TOPRIGHT",
			debuffs_growthY = "UP",
			debuffs_growthX = "LEFT",
			debuffs_size = "26",
			debuffs_spacing = "2",
			debuffs_num = "36",
		},
		Castbar = {
			Enable = true,
			Height = "33",
			Width = "360",
			X = "13",
			Y = "205",
			Texture = "LUI_Gradient",
			TextureBG = "LUI_Minimalist",
			IndividualColor = false,
			Icon = true,
			Text = {
				Name = {
					Enable = true,
					Font = "neuropol",
					Size = 15,
					OffsetX = "5",
					OffsetY = "1",
				},
				Time = {
					Enable = true,
					ShowMax = true,
					Font = "neuropol",
					Size = 13,
					OffsetX = "-5",
					OffsetY = "1",
				},
			},
			Border = {
				Texture = "glow",
				Thickness = "4",
				Inset = {
					left = "3",
					right = "3",
					top = "3",
					bottom = "3",
				},
			},
			Colors = {
				Bar = {
					r = 0.13,
					g = 0.59,
					b = 1,
					a = 0.68,
				},
				Background = {
					r = 0.15,
					g = 0.15,
					b = 0.15,
					a = 0.67,
				},
				Border = {
					r = 0,
					g = 0,
					b = 0,
					a = 0.7,
				},
				Name = {
					r = 0.9,
					g = 0.9,
					b = 0.9,
				},
				Time = {
					r = 0.9,
					g = 0.9,
					b = 0.9,
				},
			},
		},
		Portrait = {
			Enable = false,
			Height = "43",
			Width = "90",
			X = "0",
			Y = "0",
		},
		Icons = {
			Lootmaster = {
				Enable = true,
				Size = 15,
				X = "16",
				Y = "10",
				Point = "TOPLEFT",
			},
			Leader = {
				Enable = true,
				Size = 17,
				X = "0",
				Y = "10",
				Point = "TOPLEFT",
			},
			Role = {
				Enable = true,
				Size = 22,
				X = "15",
				Y = "10",
				Point = "TOPRIGHT",
			},
			Raid = {
				Enable = true,
				Size = 55,
				X = "0",
				Y = "10",
				Point = "CENTER",
			},
			Resting = {
				Enable = false,
				Size = 27,
				X = "-12",
				Y = "13",
				Point = "TOPLEFT",
			},
			Combat = {
				Enable = false,
				Size = 27,
				X = "-15",
				Y = "-30",
				Point = "BOTTOMLEFT",
			},
			PvP = {
				Enable = false,
				Size = 35,
				X = "-12",
				Y = "10",
				Point = "TOPLEFT",
			},
		},
		Texts = {
			Name = {
				Enable = true,
				Font = "Prototype",
				Size = 25,
				X = "5",
				Y = "0",
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "BOTTOMLEFT",
				RelativePoint = "BOTTOMRIGHT",
				Format = "Level + Name",
				Length = "Medium",
				ColorNameByClass = true,
				ColorClassByClass = true,
				ColorLevelByDifficulty = true,
				ShowClassification = true,
				ShortClassification = false,
			},
			Health = {
				Enable = true,
				Font = "Prototype",
				Size = 28,
				X = "0",
				Y = "-31",
				ColorClass = false,
				ColorGradient = false,
				IndividualColor = {
					Enable = true,
					r = "1",
					g = "1",
					b = "1",
				},
				Outline = "NONE",
				Point = "BOTTOMLEFT",
				RelativePoint = "BOTTOMLEFT",
				Format = "Standard",
				ShowDead = false,
			},
			Power = {
				Enable = true,
				Font = "Prototype",
				Size = 21,
				X = "0",
				Y = "-51",
				ColorClass = true,
				ColorType = false,
				IndividualColor = {
					Enable = false,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "BOTTOMLEFT",
				RelativePoint = "BOTTOMLEFT",
				Format = "Standard",
			},
			HealthPercent = {
				Enable = true,
				Font = "Prototype",
				Size = 16,
				X = "0",
				Y = "6",
				ShowAlways = false,
				ColorClass = false,
				ColorGradient = false,
				IndividualColor = {
					Enable = true,
					r = "1",
					g = "1",
					b = "1",
				},
				Outline = "NONE",
				Point = "CENTER",
				RelativePoint = "CENTER",
				ShowDead = true,
			},
			PowerPercent = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "0",
				ShowAlways = false,
				ColorClass = false,
				ColorType = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "CENTER",
				RelativePoint = "CENTER",
			},
			HealthMissing = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "0",
				ShortValue = true,
				ShowAlways = false,
				ColorClass = false,
				ColorGradient = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "RIGHT",
				RelativePoint = "RIGHT",
			},
			PowerMissing = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "0",
				ShortValue = true,
				ShowAlways = false,
				ColorClass = false,
				ColorType = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "RIGHT",
				RelativePoint = "RIGHT",
			},
		},
	},
}

function module:LoadOptions()
	local options = {
		Target = {
			name = "Target",
			type = "group",
			order = 5,
			disabled = function() return not db.oUF.Settings.Enable end,
			childGroups = "tab",
			args = {
				header1 = {
					name = "Target",
					type = "header",
					order = 1,
				},
				General = {
					name = "General",
					type = "group",
					childGroups = "tab",
					order = 2,
					args = {
						Positioning = {
							name = "Positioning",
							type = "group",
							order = 1,
							args = {
								header1 = {
									name = "Frame Position",
									type = "header",
									order = 1,
								},
								TargetX = {
									name = "X Value",
									desc = "X Value for your Target Frame.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.X,
									type = "input",
									get = function() return db.oUF.Target.X end,
									set = function(self,TargetX)
												if TargetX == nil or TargetX == "" then
													TargetX = "0"
												end
												db.oUF.Target.X = TargetX
												oUF_LUI_target:SetPoint("CENTER", UIParent, "CENTER", tonumber(TargetX), tonumber(db.oUF.Target.Y))
											end,
									order = 2,
								},
								TargetY = {
									name = "Y Value",
									desc = "Y Value for your Target Frame.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Y,
									type = "input",
									get = function() return db.oUF.Target.Y end,
									set = function(self,TargetY)
												if TargetY == nil or TargetY == "" then
													TargetY = "0"
												end
												db.oUF.Target.Y = TargetY
												oUF_LUI_target:SetPoint("CENTER", UIParent, "CENTER", tonumber(db.oUF.Target.X), tonumber(TargetY))
											end,
									order = 3,
								},
							},
						},
						Size = {
							name = "Size",
							type = "group",
							order = 2,
							args = {
								header1 = {
									name = "Frame Height/Width",
									type = "header",
									order = 1,
								},
								TargetHeight = {
									name = "Height",
									desc = "Decide the Height of your Target Frame.\n\nDefault: "..LUI.defaults.profile.oUF.Target.Height,
									type = "input",
									get = function() return db.oUF.Target.Height end,
									set = function(self,TargetHeight)
												if TargetHeight == nil or TargetHeight == "" then
													TargetHeight = "0"
												end
												db.oUF.Target.Height = TargetHeight
												oUF_LUI_target:SetHeight(tonumber(TargetHeight))
											end,
									order = 2,
								},
								TargetWidth = {
									name = "Width",
									desc = "Decide the Width of your Target Frame.\n\nDefault: "..LUI.defaults.profile.oUF.Target.Width,
									type = "input",
									get = function() return db.oUF.Target.Width end,
									set = function(self,TargetWidth)
												if TargetWidth == nil or TargetWidth == "" then
													TargetWidth = "0"
												end
												db.oUF.Target.Width = TargetWidth
												oUF_LUI_target:SetWidth(tonumber(TargetWidth))
												
												if db.oUF.Target.Aura.buffs_enable == true then
													oUF_LUI_target.Buffs:SetWidth(tonumber(TargetWidth))
												end
												
												if db.oUF.Target.Aura.debuffs_enable == true then
													oUF_LUI_target.Debuffs:SetWidth(tonumber(TargetWidth))
												end
												
												db.oUF.Target.ComboPoints.Width = TargetWidth
												
												oUF_LUI_target.ComboPoints[1]:SetWidth((tonumber(TargetWidth) -4) / 5)
												oUF_LUI_target.ComboPoints[2]:SetWidth((tonumber(TargetWidth) -4) / 5)
												oUF_LUI_target.ComboPoints[3]:SetWidth((tonumber(TargetWidth) -4) / 5)
												oUF_LUI_target.ComboPoints[4]:SetWidth((tonumber(TargetWidth) -4) / 5)
												oUF_LUI_target.ComboPoints[5]:SetWidth((tonumber(TargetWidth) -4) / 5)
											end,
									order = 3,
								},
							},
						},
						Appearance = {
							name = "Appearance",
							type = "group",
							order = 3,
							args = {
								header1 = {
									name = "Backdrop Colors",
									type = "header",
									order = 1,
								},
								BackdropColor = {
									name = "Color",
									desc = "Choose a Backdrop Color.",
									type = "color",
									width = "full",
									hasAlpha = true,
									get = function() return db.oUF.Target.Backdrop.Color.r, db.oUF.Target.Backdrop.Color.g, db.oUF.Target.Backdrop.Color.b, db.oUF.Target.Backdrop.Color.a end,
									set = function(_,r,g,b,a)
											db.oUF.Target.Backdrop.Color.r = r
											db.oUF.Target.Backdrop.Color.g = g
											db.oUF.Target.Backdrop.Color.b = b
											db.oUF.Target.Backdrop.Color.a = a

											oUF_LUI_target.FrameBackdrop:SetBackdropColor(r,g,b,a)
										end,
									order = 2,
								},
								BackdropBorderColor = {
									name = "Border Color",
									desc = "Choose a Backdrop Border Color.",
									type = "color",
									width = "full",
									hasAlpha = true,
									get = function() return db.oUF.Target.Border.Color.r, db.oUF.Target.Border.Color.g, db.oUF.Target.Border.Color.b, db.oUF.Target.Border.Color.a end,
									set = function(_,r,g,b,a)
											db.oUF.Target.Border.Color.r = r
											db.oUF.Target.Border.Color.g = g
											db.oUF.Target.Border.Color.b = b
											db.oUF.Target.Border.Color.a = a
											
											oUF_LUI_target.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.Target.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.Target.Border.EdgeFile), edgeSize = tonumber(db.oUF.Target.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.Target.Border.Insets.Left), right = tonumber(db.oUF.Target.Border.Insets.Right), top = tonumber(db.oUF.Target.Border.Insets.Top), bottom = tonumber(db.oUF.Target.Border.Insets.Bottom)}
											})
											
											oUF_LUI_target.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.Target.Backdrop.Color.r), tonumber(db.oUF.Target.Backdrop.Color.g), tonumber(db.oUF.Target.Backdrop.Color.b), tonumber(db.oUF.Target.Backdrop.Color.a))
											oUF_LUI_target.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.Target.Border.Color.r), tonumber(db.oUF.Target.Border.Color.g), tonumber(db.oUF.Target.Border.Color.b), tonumber(db.oUF.Target.Border.Color.a))
										end,
									order = 3,
								},
								header2 = {
									name = "Backdrop Settings",
									type = "header",
									order = 4,
								},
								BackdropTexture = {
									name = "Backdrop Texture",
									desc = "Choose your Backdrop Texture!\nDefault: "..LUI.defaults.profile.oUF.Target.Backdrop.Texture,
									type = "select",
									dialogControl = "LSM30_Background",
									values = widgetLists.background,
									get = function() return db.oUF.Target.Backdrop.Texture end,
									set = function(self, BackdropTexture)
											db.oUF.Target.Backdrop.Texture = BackdropTexture
											oUF_LUI_target.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.Target.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.Target.Border.EdgeFile), edgeSize = tonumber(db.oUF.Target.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.Target.Border.Insets.Left), right = tonumber(db.oUF.Target.Border.Insets.Right), top = tonumber(db.oUF.Target.Border.Insets.Top), bottom = tonumber(db.oUF.Target.Border.Insets.Bottom)}
											})
											
											oUF_LUI_target.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.Target.Backdrop.Color.r), tonumber(db.oUF.Target.Backdrop.Color.g), tonumber(db.oUF.Target.Backdrop.Color.b), tonumber(db.oUF.Target.Backdrop.Color.a))
											oUF_LUI_target.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.Target.Border.Color.r), tonumber(db.oUF.Target.Border.Color.g), tonumber(db.oUF.Target.Border.Color.b), tonumber(db.oUF.Target.Border.Color.a))
										end,
									order = 5,
								},
								BorderTexture = {
									name = "Border Texture",
									desc = "Choose your Border Texture!\nDefault: "..LUI.defaults.profile.oUF.Target.Border.EdgeFile,
									type = "select",
									dialogControl = "LSM30_Border",
									values = widgetLists.border,
									get = function() return db.oUF.Target.Border.EdgeFile end,
									set = function(self, BorderTexture)
											db.oUF.Target.Border.EdgeFile = BorderTexture
											oUF_LUI_target.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.Target.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.Target.Border.EdgeFile), edgeSize = tonumber(db.oUF.Target.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.Target.Border.Insets.Left), right = tonumber(db.oUF.Target.Border.Insets.Right), top = tonumber(db.oUF.Target.Border.Insets.Top), bottom = tonumber(db.oUF.Target.Border.Insets.Bottom)}
											})
											
											oUF_LUI_target.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.Target.Backdrop.Color.r), tonumber(db.oUF.Target.Backdrop.Color.g), tonumber(db.oUF.Target.Backdrop.Color.b), tonumber(db.oUF.Target.Backdrop.Color.a))
											oUF_LUI_target.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.Target.Border.Color.r), tonumber(db.oUF.Target.Border.Color.g), tonumber(db.oUF.Target.Border.Color.b), tonumber(db.oUF.Target.Border.Color.a))
										end,
									order = 6,
								},
								BorderSize = {
									name = "Edge Size",
									desc = "Choose the Edge Size for your Frame Border.\nDefault: "..LUI.defaults.profile.oUF.Target.Border.EdgeSize,
									type = "range",
									min = 1,
									max = 50,
									step = 1,
									get = function() return db.oUF.Target.Border.EdgeSize end,
									set = function(_, BorderSize) 
											db.oUF.Target.Border.EdgeSize = BorderSize
											oUF_LUI_target.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.Target.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.Target.Border.EdgeFile), edgeSize = tonumber(db.oUF.Target.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.Target.Border.Insets.Left), right = tonumber(db.oUF.Target.Border.Insets.Right), top = tonumber(db.oUF.Target.Border.Insets.Top), bottom = tonumber(db.oUF.Target.Border.Insets.Bottom)}
											})
											
											oUF_LUI_target.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.Target.Backdrop.Color.r), tonumber(db.oUF.Target.Backdrop.Color.g), tonumber(db.oUF.Target.Backdrop.Color.b), tonumber(db.oUF.Target.Backdrop.Color.a))
											oUF_LUI_target.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.Target.Border.Color.r), tonumber(db.oUF.Target.Border.Color.g), tonumber(db.oUF.Target.Border.Color.b), tonumber(db.oUF.Target.Border.Color.a))
										end,
									order = 7,
								},
								header3 = {
									name = "Backdrop Padding",
									type = "header",
									order = 8,
								},
								PaddingLeft = {
									name = "Left",
									desc = "Value for the Left Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.Target.Backdrop.Padding.Left,
									type = "input",
									width = "half",
									get = function() return db.oUF.Target.Backdrop.Padding.Left end,
									set = function(self,PaddingLeft)
										if PaddingLeft == nil or PaddingLeft == "" then
											PaddingLeft = "0"
										end
										db.oUF.Target.Backdrop.Padding.Left = PaddingLeft
										oUF_LUI_target.FrameBackdrop:ClearAllPoints()
										oUF_LUI_target.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_target, "TOPLEFT", tonumber(db.oUF.Target.Backdrop.Padding.Left), tonumber(db.oUF.Target.Backdrop.Padding.Top))
										oUF_LUI_target.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_target, "BOTTOMRIGHT", tonumber(db.oUF.Target.Backdrop.Padding.Right), tonumber(db.oUF.Target.Backdrop.Padding.Bottom))
									end,
									order = 9,
								},
								PaddingRight = {
									name = "Right",
									desc = "Value for the Right Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.Target.Backdrop.Padding.Right,
									type = "input",
									width = "half",
									get = function() return db.oUF.Target.Backdrop.Padding.Right end,
									set = function(self,PaddingRight)
										if PaddingRight == nil or PaddingRight == "" then
											PaddingRight = "0"
										end
										db.oUF.Target.Backdrop.Padding.Right = PaddingRight
										oUF_LUI_target.FrameBackdrop:ClearAllPoints()
										oUF_LUI_target.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_target, "TOPLEFT", tonumber(db.oUF.Target.Backdrop.Padding.Left), tonumber(db.oUF.Target.Backdrop.Padding.Top))
										oUF_LUI_target.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_target, "BOTTOMRIGHT", tonumber(db.oUF.Target.Backdrop.Padding.Right), tonumber(db.oUF.Target.Backdrop.Padding.Bottom))
									end,
									order = 10,
								},
								PaddingTop = {
									name = "Top",
									desc = "Value for the Top Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.Target.Backdrop.Padding.Top,
									type = "input",
									width = "half",
									get = function() return db.oUF.Target.Backdrop.Padding.Top end,
									set = function(self,PaddingTop)
										if PaddingTop == nil or PaddingTop == "" then
											PaddingTop = "0"
										end
										db.oUF.Target.Backdrop.Padding.Top = PaddingTop
										oUF_LUI_target.FrameBackdrop:ClearAllPoints()
										oUF_LUI_target.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_target, "TOPLEFT", tonumber(db.oUF.Target.Backdrop.Padding.Left), tonumber(db.oUF.Target.Backdrop.Padding.Top))
										oUF_LUI_target.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_target, "BOTTOMRIGHT", tonumber(db.oUF.Target.Backdrop.Padding.Right), tonumber(db.oUF.Target.Backdrop.Padding.Bottom))
									end,
									order = 11,
								},
								PaddingBottom = {
									name = "Bottom",
									desc = "Value for the Bottom Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.Target.Backdrop.Padding.Bottom,
									type = "input",
									width = "half",
									get = function() return db.oUF.Target.Backdrop.Padding.Bottom end,
									set = function(self,PaddingBottom)
										if PaddingBottom == nil or PaddingBottom == "" then
											PaddingBottom = "0"
										end
										db.oUF.Target.Backdrop.Padding.Bottom = PaddingBottom
										oUF_LUI_target.FrameBackdrop:ClearAllPoints()
										oUF_LUI_target.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_target, "TOPLEFT", tonumber(db.oUF.Target.Backdrop.Padding.Left), tonumber(db.oUF.Target.Backdrop.Padding.Top))
										oUF_LUI_target.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_target, "BOTTOMRIGHT", tonumber(db.oUF.Target.Backdrop.Padding.Right), tonumber(db.oUF.Target.Backdrop.Padding.Bottom))
									end,
									order = 12,
								},
								header4 = {
									name = "Boder Insets",
									type = "header",
									order = 13,
								},
								InsetLeft = {
									name = "Left",
									desc = "Value for the Left Border Inset\nDefault: "..LUI.defaults.profile.oUF.Target.Border.Insets.Left,
									type = "input",
									width = "half",
									get = function() return db.oUF.Target.Border.Insets.Left end,
									set = function(self,InsetLeft)
										if InsetLeft == nil or InsetLeft == "" then
											InsetLeft = "0"
										end
										db.oUF.Target.Border.Insets.Left = InsetLeft
										oUF_LUI_target.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.Target.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.Target.Border.EdgeFile), edgeSize = tonumber(db.oUF.Target.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.Target.Border.Insets.Left), right = tonumber(db.oUF.Target.Border.Insets.Right), top = tonumber(db.oUF.Target.Border.Insets.Top), bottom = tonumber(db.oUF.Target.Border.Insets.Bottom)}
											})
											
											oUF_LUI_target.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.Target.Backdrop.Color.r), tonumber(db.oUF.Target.Backdrop.Color.g), tonumber(db.oUF.Target.Backdrop.Color.b), tonumber(db.oUF.Target.Backdrop.Color.a))
											oUF_LUI_target.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.Target.Border.Color.r), tonumber(db.oUF.Target.Border.Color.g), tonumber(db.oUF.Target.Border.Color.b), tonumber(db.oUF.Target.Border.Color.a))
											end,
									order = 14,
								},
								InsetRight = {
									name = "Right",
									desc = "Value for the Right Border Inset\nDefault: "..LUI.defaults.profile.oUF.Target.Border.Insets.Right,
									type = "input",
									width = "half",
									get = function() return db.oUF.Target.Border.Insets.Right end,
									set = function(self,InsetRight)
										if InsetRight == nil or InsetRight == "" then
											InsetRight = "0"
										end
										db.oUF.Target.Border.Insets.Right = InsetRight
										oUF_LUI_target.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.Target.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.Target.Border.EdgeFile), edgeSize = tonumber(db.oUF.Target.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.Target.Border.Insets.Left), right = tonumber(db.oUF.Target.Border.Insets.Right), top = tonumber(db.oUF.Target.Border.Insets.Top), bottom = tonumber(db.oUF.Target.Border.Insets.Bottom)}
											})
											
											oUF_LUI_target.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.Target.Backdrop.Color.r), tonumber(db.oUF.Target.Backdrop.Color.g), tonumber(db.oUF.Target.Backdrop.Color.b), tonumber(db.oUF.Target.Backdrop.Color.a))
											oUF_LUI_target.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.Target.Border.Color.r), tonumber(db.oUF.Target.Border.Color.g), tonumber(db.oUF.Target.Border.Color.b), tonumber(db.oUF.Target.Border.Color.a))
											end,
									order = 15,
								},
								InsetTop = {
									name = "Top",
									desc = "Value for the Top Border Inset\nDefault: "..LUI.defaults.profile.oUF.Target.Border.Insets.Top,
									type = "input",
									width = "half",
									get = function() return db.oUF.Target.Border.Insets.Top end,
									set = function(self,InsetTop)
										if InsetTop == nil or InsetTop == "" then
											InsetTop = "0"
										end
										db.oUF.Target.Border.Insets.Top = InsetTop
										oUF_LUI_target.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.Target.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.Target.Border.EdgeFile), edgeSize = tonumber(db.oUF.Target.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.Target.Border.Insets.Left), right = tonumber(db.oUF.Target.Border.Insets.Right), top = tonumber(db.oUF.Target.Border.Insets.Top), bottom = tonumber(db.oUF.Target.Border.Insets.Bottom)}
											})
											
											oUF_LUI_target.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.Target.Backdrop.Color.r), tonumber(db.oUF.Target.Backdrop.Color.g), tonumber(db.oUF.Target.Backdrop.Color.b), tonumber(db.oUF.Target.Backdrop.Color.a))
											oUF_LUI_target.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.Target.Border.Color.r), tonumber(db.oUF.Target.Border.Color.g), tonumber(db.oUF.Target.Border.Color.b), tonumber(db.oUF.Target.Border.Color.a))
											end,
									order = 16,
								},
								InsetBottom = {
									name = "Bottom",
									desc = "Value for the Bottom Border Inset\nDefault: "..LUI.defaults.profile.oUF.Target.Border.Insets.Bottom,
									type = "input",
									width = "half",
									get = function() return db.oUF.Target.Border.Insets.Bottom end,
									set = function(self,InsetBottom)
										if InsetBottom == nil or InsetBottom == "" then
											InsetBottom = "0"
										end
										db.oUF.Target.Border.Insets.Bottom = InsetBottom
										oUF_LUI_target.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.Target.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.Target.Border.EdgeFile), edgeSize = tonumber(db.oUF.Target.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.Target.Border.Insets.Left), right = tonumber(db.oUF.Target.Border.Insets.Right), top = tonumber(db.oUF.Target.Border.Insets.Top), bottom = tonumber(db.oUF.Target.Border.Insets.Bottom)}
											})
											
											oUF_LUI_target.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.Target.Backdrop.Color.r), tonumber(db.oUF.Target.Backdrop.Color.g), tonumber(db.oUF.Target.Backdrop.Color.b), tonumber(db.oUF.Target.Backdrop.Color.a))
											oUF_LUI_target.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.Target.Border.Color.r), tonumber(db.oUF.Target.Border.Color.g), tonumber(db.oUF.Target.Border.Color.b), tonumber(db.oUF.Target.Border.Color.a))
											end,
									order = 17,
								},
							},
						},
						AlphaFader = {
							name = "Fader",
							type = "group",
							order = 4,
							args = {
								empty = {
									order = 1,
									width = "full",
									type = "description",
									name = "\n\n    coming soon...",
								},
							},
						},
					},
				},
				Bars = {
					name = "Bars",
					type = "group",
					childGroups = "tab",
					order = 3,
					args = {
						Health = {
							name = "Health",
							type = "group",
							order = 1,
							args = {
								General = {
									name = "General Settings",
									type = "group",
									guiInline = true,
									order = 1,
									args = {
										Height = {
											name = "Height",
											desc = "Decide the Height of your Target Health.\n\nDefault: "..LUI.defaults.profile.oUF.Target.Health.Height,
											type = "input",
											get = function() return db.oUF.Target.Health.Height end,
											set = function(self,Height)
														if Height == nil or Height == "" then
															Height = "0"
														end
														db.oUF.Target.Health.Height = Height
														oUF_LUI_target.Health:SetHeight(tonumber(Height))
													end,
											order = 1,
										},
										Padding = {
											name = "Padding",
											desc = "Choose the Padding between Health & Powerbar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Health.Padding,
											type = "input",
											get = function() return db.oUF.Target.Health.Padding end,
											set = function(self,Padding)
														if Padding == nil or Padding == "" then
															Padding = "0"
														end
														db.oUF.Target.Health.Padding = Padding
														oUF_LUI_target.Health:ClearAllPoints()
														oUF_LUI_target.Health:SetPoint("TOPLEFT", oUF_LUI_target, "TOPLEFT", 0, tonumber(Padding))
														oUF_LUI_target.Health:SetPoint("TOPRIGHT", oUF_LUI_target, "TOPRIGHT", 0, tonumber(Padding))
													end,
											order = 2,
										},
										Smooth = {
											name = "Enable Smooth Bar Animation",
											desc = "Wether you want to use Smooth Animations or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.Target.Health.Smooth end,
											set = function(self,Smooth)
														db.oUF.Target.Health.Smooth = not db.oUF.Target.Health.Smooth
														StaticPopup_Show("RELOAD_UI")
													end,
											order = 3,
										},
									}
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									guiInline = true,
									order = 2,
									args = {
										HealthClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored HealthBars or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Health.ColorClass end,
											set = function(self,HealthClassColor)
														db.oUF.Target.Health.ColorClass = not db.oUF.Target.Health.ColorClass
														if HealthClassColor == true then
															db.oUF.Target.Health.ColorGradient = false
															db.oUF.Target.Health.IndividualColor.Enable = false
															
															print("Target Healthbar Color will change once you gain/lose HP")
														end
													end,
											order = 1,
										},
										HealthGradientColor = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored HealthBars or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Health.ColorGradient end,
											set = function(self,HealthGradientColor)
														db.oUF.Target.Health.ColorGradient = not db.oUF.Target.Health.ColorGradient
														if HealthGradientColor == true then
															db.oUF.Target.Health.ColorClass = false
															db.oUF.Target.Health.IndividualColor.Enable = false
															
															print("Target Healthbar Color will change once you gain/lose HP")
														end
													end,
											order = 2,
										},
										IndividualHealthColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual HealthBar Color or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Health.IndividualColor.Enable end,
											set = function(self,IndividualHealthColor)
														db.oUF.Target.Health.IndividualColor.Enable = not db.oUF.Target.Health.IndividualColor.Enable
														if IndividualHealthColor == true then
															db.oUF.Target.Health.ColorClass = false
															db.oUF.Target.Health.ColorGradient = false
															
															oUF_LUI_target.Health:SetStatusBarColor(db.oUF.Target.Health.IndividualColor.r, db.oUF.Target.Health.IndividualColor.g, db.oUF.Target.Health.IndividualColor.b)
															oUF_LUI_target.Health.bg:SetVertexColor(db.oUF.Target.Health.IndividualColor.r*tonumber(db.oUF.Target.Health.BGMultiplier), db.oUF.Target.Health.IndividualColor.g*tonumber(db.oUF.Target.Health.BGMultiplier), db.oUF.Target.Health.IndividualColor.b*tonumber(db.oUF.Target.Health.BGMultiplier))
														end
													end,
											order = 3,
										},
										HealthColor = {
											name = "Individual Color",
											desc = "Choose an individual Healthbar Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.Target.Health.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.Target.Health.IndividualColor.r, db.oUF.Target.Health.IndividualColor.g, db.oUF.Target.Health.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.Target.Health.IndividualColor.r = r
													db.oUF.Target.Health.IndividualColor.g = g
													db.oUF.Target.Health.IndividualColor.b = b
													
													oUF_LUI_target.Health:SetStatusBarColor(r, g, b)
													oUF_LUI_target.Health.bg:SetVertexColor(r*tonumber(db.oUF.Target.Health.BGMultiplier), g*tonumber(db.oUF.Target.Health.BGMultiplier), b*tonumber(db.oUF.Target.Health.BGMultiplier))
												end,
											order = 4,
										},
										Tapping = {
											name = "Enable Tapping",
											desc = "Wether you want to show Tapped Healthbars or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Health.Tapping end,
											set = function(self,Tapping)
													db.oUF.Target.Health.Tapping = db.oUF.Target.Health.Tapping
													StaticPopup_Show("RELOAD_UI")
												end,
											order = 5,
										},
									},
								},
								Textures = {
									name = "Texture Settings",
									type = "group",
									guiInline = true,
									order = 3,
									args = {
										HealthTex = {
											name = "Texture",
											desc = "Choose your Health Texture!\nDefault: "..LUI.defaults.profile.oUF.Target.Health.Texture,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.Target.Health.Texture
												end,
											set = function(self, HealthTex)
													db.oUF.Target.Health.Texture = HealthTex
													oUF_LUI_target.Health:SetStatusBarTexture(LSM:Fetch("statusbar", HealthTex))
												end,
											order = 1,
										},
										HealthTexBG = {
											name = "Background Texture",
											desc = "Choose your Health Background Texture!\nDefault: "..LUI.defaults.profile.oUF.Target.Health.TextureBG,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.Target.Health.TextureBG
												end,
											set = function(self, HealthTexBG)
													db.oUF.Target.Health.TextureBG = HealthTexBG
													oUF_LUI_target.Health.bg:SetTexture(LSM:Fetch("statusbar", HealthTexBG))
												end,
											order = 2,
										},
										HealthTexBGAlpha = {
											name = "Background Alpha",
											desc = "Choose the Alpha Value for your Health Background.\nDefault: "..LUI.defaults.profile.oUF.Target.Health.BGAlpha,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.Target.Health.BGAlpha end,
											set = function(_, HealthTexBGAlpha) 
													db.oUF.Target.Health.BGAlpha  = HealthTexBGAlpha
													oUF_LUI_target.Health.bg:SetAlpha(tonumber(HealthTexBGAlpha))
												end,
											order = 3,
										},
										HealthTexBGMultiplier = {
											name = "Background Muliplier",
											desc = "Choose the Multiplier which will be used to generate the BackgroundColor.\nDefault: "..LUI.defaults.profile.oUF.Target.Health.BGMultiplier,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.Target.Health.BGMultiplier end,
											set = function(_, HealthTexBGMultiplier) 
													db.oUF.Target.Health.BGMultiplier  = HealthTexBGMultiplier
													oUF_LUI_target.Health.bg.multiplier = tonumber(HealthTexBGMultiplier)
												end,
											order = 4,
										},
									},
								},
							},
						},
						Power = {
							name = "Power",
							type = "group",
							order = 2,
							args = {
								EnablePower = {
									name = "Enable",
									desc = "Wether you want to use a Powerbar or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Power.Enable end,
									set = function(self,EnablePower)
												db.oUF.Target.Power.Enable = not db.oUF.Target.Power.Enable
												if EnablePower == true then
													oUF_LUI_target.Power:Show()
												else
													oUF_LUI_target.Power:Hide()
												end
											end,
									order = 1,
								},
								General = {
									name = "General Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Power.Enable end,
									guiInline = true,
									order = 2,
									args = {
										Height = {
											name = "Height",
											desc = "Decide the Height of your Target Power.\n\nDefault: "..LUI.defaults.profile.oUF.Target.Power.Height,
											type = "input",
											get = function() return db.oUF.Target.Power.Height end,
											set = function(self,Height)
														if Height == nil or Height == "" then
															Height = "0"
														end
														db.oUF.Target.Power.Height = Height
														oUF_LUI_target.Power:SetHeight(tonumber(Height))
													end,
											order = 1,
										},
										Padding = {
											name = "Padding",
											desc = "Choose the Padding between Health & Powerbar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Power.Padding,
											type = "input",
											get = function() return db.oUF.Target.Power.Padding end,
											set = function(self,Padding)
														if Padding == nil or Padding == "" then
															Padding = "0"
														end
														db.oUF.Target.Power.Padding = Padding
														oUF_LUI_target.Power:ClearAllPoints()
														oUF_LUI_target.Power:SetPoint("TOPLEFT", oUF_LUI_target.Health, "BOTTOMLEFT", 0, tonumber(Padding))
														oUF_LUI_target.Power:SetPoint("TOPRIGHT", oUF_LUI_target.Health, "BOTTOMRIGHT", 0, tonumber(Padding))
													end,
											order = 2,
										},
										Smooth = {
											name = "Enable Smooth Bar Animation",
											desc = "Wether you want to use Smooth Animations or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.Target.Power.Smooth end,
											set = function(self,Smooth)
														db.oUF.Target.Power.Smooth = not db.oUF.Target.Power.Smooth
														StaticPopup_Show("RELOAD_UI")
													end,
											order = 3,
										},
									}
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Power.Enable end,
									guiInline = true,
									order = 3,
									args = {
										PowerClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored PowerBars or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Power.ColorClass end,
											set = function(self,PowerClassColor)
														db.oUF.Target.Power.ColorClass = not db.oUF.Target.Power.ColorClass
														if PowerClassColor == true then
															db.oUF.Target.Power.ColorType = false
															db.oUF.Target.Power.IndividualColor.Enable = false
															
															print("Target Powerbar Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										PowerColorByType = {
											name = "Color by Type",
											desc = "Wether you want to use Power Type colored PowerBars or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Power.ColorType end,
											set = function(self,PowerColorByType)
														db.oUF.Target.Power.ColorType = not db.oUF.Target.Power.ColorType
														if PowerColorByType == true then
															db.oUF.Target.Power.ColorClass = false
															db.oUF.Target.Power.IndividualColor.Enable = false
															
															print("Target Powerbar Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualPowerColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual PowerBar Color or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Power.IndividualColor.Enable end,
											set = function(self,IndividualPowerColor)
														db.oUF.Target.Power.IndividualColor.Enable = not db.oUF.Target.Power.IndividualColor.Enable
														if IndividualPowerColor == true then
															db.oUF.Target.Power.ColorType = false
															db.oUF.Target.Power.ColorClass = false
															
															oUF_LUI_target.Power:SetStatusBarColor(db.oUF.Target.Power.IndividualColor.r, db.oUF.Target.Power.IndividualColor.g, db.oUF.Target.Power.IndividualColor.b)
															oUF_LUI_target.Power.bg:SetVertexColor(db.oUF.Target.Power.IndividualColor.r*tonumber(db.oUF.Target.Power.BGMultiplier), db.oUF.Target.Power.IndividualColor.g*tonumber(db.oUF.Target.Power.BGMultiplier), db.oUF.Target.Power.IndividualColor.b*tonumber(db.oUF.Target.Power.BGMultiplier))
														end
													end,
											order = 3,
										},
										PowerColor = {
											name = "Individual Color",
											desc = "Choose an individual Powerbar Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.Target.Power.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.Target.Power.IndividualColor.r, db.oUF.Target.Power.IndividualColor.g, db.oUF.Target.Power.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.Target.Power.IndividualColor.r = r
													db.oUF.Target.Power.IndividualColor.g = g
													db.oUF.Target.Power.IndividualColor.b = b
													
													oUF_LUI_target.Power:SetStatusBarColor(r, g, b)
													oUF_LUI_target.Power.bg:SetVertexColor(r*tonumber(db.oUF.Target.Power.BGMultiplier), g*tonumber(db.oUF.Target.Power.BGMultiplier), b*tonumber(db.oUF.Target.Power.BGMultiplier))
												end,
											order = 4,
										},
									},
								},
								Textures = {
									name = "Texture Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Power.Enable end,
									guiInline = true,
									order = 4,
									args = {
										PowerTex = {
											name = "Texture",
											desc = "Choose your Power Texture!\nDefault: "..LUI.defaults.profile.oUF.Target.Power.Texture,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.Target.Power.Texture
												end,
											set = function(self, PowerTex)
													db.oUF.Target.Power.Texture = PowerTex
													oUF_LUI_target.Power:SetStatusBarTexture(LSM:Fetch("statusbar", PowerTex))
												end,
											order = 1,
										},
										PowerTexBG = {
											name = "Background Texture",
											desc = "Choose your Power Background Texture!\nDefault: "..LUI.defaults.profile.oUF.Target.Power.TextureBG,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.Target.Power.TextureBG
												end,

											set = function(self, PowerTexBG)
													db.oUF.Target.Power.TextureBG = PowerTexBG
													oUF_LUI_target.Power.bg:SetTexture(LSM:Fetch("statusbar", PowerTexBG))
												end,
											order = 2,
										},
										PowerTexBGAlpha = {
											name = "Background Alpha",
											desc = "Choose the Alpha Value for your Power Background.\nDefault: "..LUI.defaults.profile.oUF.Target.Power.BGAlpha,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.Target.Power.BGAlpha end,
											set = function(_, PowerTexBGAlpha) 
													db.oUF.Target.Power.BGAlpha  = PowerTexBGAlpha
													oUF_LUI_target.Power.bg:SetAlpha(tonumber(PowerTexBGAlpha))
												end,
											order = 3,
										},
										PowerTexBGMultiplier = {
											name = "Background Muliplier",
											desc = "Choose the Multiplier which will be used to generate the BackgroundColor.\nDefault: "..LUI.defaults.profile.oUF.Target.Power.BGMultiplier,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.Target.Power.BGMultiplier end,
											set = function(_, PowerTexBGMultiplier) 
													db.oUF.Target.Power.BGMultiplier  = PowerTexBGMultiplier
													oUF_LUI_target.Power.bg.multiplier = tonumber(PowerTexBGMultiplier)
												end,
											order = 4,
										},
									},
								},
							},
						},
						Full = {
							name = "Fullbar",
							type = "group",
							order = 3,
							args = {
								EnableFullbar = {
									name = "Enable",
									desc = "Wether you want to use a Fullbar or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Full.Enable end,
									set = function(self,EnableFullbar)
												db.oUF.Target.Full.Enable = not db.oUF.Target.Full.Enable
												if EnableFullbar == true then
													oUF_LUI_target.Full:Show()
												else
													oUF_LUI_target.Full:Hide()
												end
											end,
									order = 1,
								},
								General = {
									name = "Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Full.Enable end,
									guiInline = true,
									order = 2,
									args = {
										Height = {
											name = "Height",
											desc = "Decide the Height of your Fullbar.\n\nDefault: "..LUI.defaults.profile.oUF.Target.Full.Height,
											type = "input",
											get = function() return db.oUF.Target.Full.Height end,
											set = function(self,Height)
														if Height == nil or Height == "" then
															Height = "0"
														end
														db.oUF.Target.Full.Height = Height
														oUF_LUI_target.Full:SetHeight(tonumber(Height))
													end,
											order = 1,
										},
										Padding = {
											name = "Padding",
											desc = "Choose the Padding between Health & Fullbar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Full.Padding,
											type = "input",
											get = function() return db.oUF.Target.Full.Padding end,
											set = function(self,Padding)
													if Padding == nil or Padding == "" then
														Padding = "0"
													end
													db.oUF.Target.Full.Padding = Padding
													oUF_LUI_target.Full:ClearAllPoints()
													oUF_LUI_target.Full:SetPoint("TOPLEFT", oUF_LUI_target.Health, "BOTTOMLEFT", 0, tonumber(Padding))
													oUF_LUI_target.Full:SetPoint("TOPRIGHT", oUF_LUI_target.Health, "BOTTOMRIGHT", 0, tonumber(Padding))
												end,
											order = 2,
										},
										FullTex = {
											name = "Texture",
											desc = "Choose your Fullbar Texture!\nDefault: "..LUI.defaults.profile.oUF.Target.Full.Texture,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.Target.Full.Texture
												end,
											set = function(self, FullTex)
													db.oUF.Target.Full.Texture = FullTex
													oUF_LUI_target.Full:SetStatusBarTexture(LSM:Fetch("statusbar", FullTex))
												end,
											order = 3,
										},
										FullAlpha = {
											name = "Alpha",
											desc = "Choose the Alpha Value for your Fullbar!\n Default: "..LUI.defaults.profile.oUF.Target.Full.Alpha,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.Target.Full.Alpha end,
											set = function(_, FullAlpha)
													db.oUF.Target.Full.Alpha = FullAlpha
													oUF_LUI_target.Full:SetAlpha(FullAlpha)
												end,
											order = 4,
										},
										Color = {
											name = "Color",
											desc = "Choose your Fullbar Color.",
											type = "color",
											hasAlpha = true,
											get = function() return db.oUF.Target.Full.Color.r, db.oUF.Target.Full.Color.g, db.oUF.Target.Full.Color.b, db.oUF.Target.Full.Color.a end,
											set = function(_,r,g,b,a)
													db.oUF.Target.Full.Color.r = r
													db.oUF.Target.Full.Color.g = g
													db.oUF.Target.Full.Color.b = b
													db.oUF.Target.Full.Color.a = a
													
													oUF_LUI_target.Full:SetStatusBarColor(r, g, b, a)
												end,
											order = 5,
										},
									},
								},
							},
						},
						ComboPoints = {
							name = "Combo Points",
							type = "group",
							order = 6,
							args = {
								ComboPoints = {
									name = "Enable",
									desc = "Whether you want to show your ComboPoint Bar or not.\n",
									type = "toggle",
									get = function() return db.oUF.Target.ComboPoints.Enable end,
									set = function()
											db.oUF.Target.ComboPoints.Enable = not db.oUF.Target.ComboPoints.Enable
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 1,
								},
								ShowAlways = {
									name = "Show Always",
									desc = "Whether you want to always show your ComboPoint Bar or not.\n",
									type = "toggle",
									disabled = function() return not db.oUF.Target.ComboPoints.Enable end,
									get = function() return db.oUF.Target.ComboPoints.ShowAlways end,
									set = function()
											db.oUF.Target.ComboPoints.ShowAlways = not db.oUF.Target.ComboPoints.ShowAlways
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 2,
								},
								empty = {
									name = " ",
									width = "full",
									type = "description",
									order = 3,
								},
								desc = {
									name = "|cff3399ffImportant:|r\nTo Change the Color for each ComboPoint\nplease go to UnitFrames->Colors->Other",
									width = "full",
									type = "description",
									order = 4,
								},
								empty2 = {
									name = " ",
									width = "full",
									type = "description",
									order = 5,
								},
								Settings = {
									name = "Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.ComboPoints.Enable end,
									guiInline = true,
									order = 6,
									args = {
										XValue = {
											name = "X Value",
											desc = "Choose the X Value for your ComboPoints.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.ComboPoints.X,
											type = "input",
											get = function() return db.oUF.Target.ComboPoints.X end,
											set = function(self,XValue)
													if XValue == nil or XValue == "" then
														XValue = "0"
													end
													db.oUF.Target.ComboPoints.X = XValue
													oUF_LUI_target.ComboPoints[1]:SetPoint("BOTTOMLEFT", oUF_LUI_target, "TOPLEFT", db.oUF.Target.ComboPoints.X, db.oUF.Target.ComboPoints.Y)
												end,
											order = 2,
										},
										YValue = {
											name = "Y Value",
											desc = "Choose the Y Value for your ComboPoints.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.ComboPoints.Y,
											type = "input",
											get = function() return db.oUF.Target.ComboPoints.Y end,
											set = function(self,YValue)
													if YValue == nil or YValue == "" then
														YValue = "0"
													end
													db.oUF.Target.ComboPoints.Y = YValue
													oUF_LUI_target.ComboPoints[1]:SetPoint("BOTTOMLEFT", oUF_LUI_target, "TOPLEFT", db.oUF.Target.ComboPoints.X, db.oUF.Target.ComboPoints.Y)
												end,
											order = 3,
										},
										Width = {
											name = "Width",
											desc = "Choose your ComboPoints Width.\n\nDefault: "..LUI.defaults.profile.oUF.Target.ComboPoints.Width,
											type = "input",
											get = function() return db.oUF.Target.ComboPoints.Width end,
											set = function(self,Width)
													if Width == nil or Width == "" then
														Width = "0"
													end
													db.oUF.Target.ComboPoints.Width = Width
													
													oUF_LUI_target.ComboPoints[1]:SetWidth((tonumber(Width) -4) / 5)
													oUF_LUI_target.ComboPoints[2]:SetWidth((tonumber(Width) -4) / 5)
													oUF_LUI_target.ComboPoints[3]:SetWidth((tonumber(Width) -4) / 5)
													oUF_LUI_target.ComboPoints[4]:SetWidth((tonumber(Width) -4) / 5)
													oUF_LUI_target.ComboPoints[5]:SetWidth((tonumber(Width) -4) / 5)
												end,
											order = 4,
										},
										Height = {
											name = "Height",
											desc = "Choose your ComboPoints Height.\n\nDefault: "..LUI.defaults.profile.oUF.Target.ComboPoints.Height,
											type = "input",
											get = function() return db.oUF.Target.ComboPoints.Height end,
											set = function(self,Height)
													if Height == nil or Height == "" then
														Height = "0"
													end
													db.oUF.Target.ComboPoints.Height = Height
													
													oUF_LUI_target.ComboPoints[1]:SetHeight(Height)
													oUF_LUI_target.ComboPoints[2]:SetHeight(Height)
													oUF_LUI_target.ComboPoints[3]:SetHeight(Height)
													oUF_LUI_target.ComboPoints[4]:SetHeight(Height)
													oUF_LUI_target.ComboPoints[5]:SetHeight(Height)
												end,
											order = 5,
										},
										Texture = {
											name = "Texture",
											desc = "Choose your ComboPoints Texture!\nDefault: "..LUI.defaults.profile.oUF.Target.ComboPoints.Texture,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function() return db.oUF.Target.ComboPoints.Texture end,
											set = function(self, Texture)
													db.oUF.Target.ComboPoints.Texture = Texture
													
													oUF_LUI_target.ComboPoints[1]:SetStatusBarTexture(LSM:Fetch("statusbar", Texture))
													oUF_LUI_target.ComboPoints[2]:SetStatusBarTexture(LSM:Fetch("statusbar", Texture))
													oUF_LUI_target.ComboPoints[3]:SetStatusBarTexture(LSM:Fetch("statusbar", Texture))
													oUF_LUI_target.ComboPoints[4]:SetStatusBarTexture(LSM:Fetch("statusbar", Texture))
													oUF_LUI_target.ComboPoints[5]:SetStatusBarTexture(LSM:Fetch("statusbar", Texture))
													
													oUF_LUI_target.ComboPoints[1].bg:SetTexture(LSM:Fetch("statusbar", Texture))
													oUF_LUI_target.ComboPoints[2].bg:SetTexture(LSM:Fetch("statusbar", Texture))
													oUF_LUI_target.ComboPoints[3].bg:SetTexture(LSM:Fetch("statusbar", Texture))
													oUF_LUI_target.ComboPoints[4].bg:SetTexture(LSM:Fetch("statusbar", Texture))
													oUF_LUI_target.ComboPoints[5].bg:SetTexture(LSM:Fetch("statusbar", Texture))
												end,
											order = 6,
										},
										Multiplier = {
											name = "Multiplier",
											desc = "Choose your ComboPoints Background Multiplier!\n Default: "..LUI.defaults.profile.oUF.Target.ComboPoints.Multiplier,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											disabled = function() return db.oUF.Target.ComboPoints.BackgroundColor.Enable end,
											get = function() return db.oUF.Target.ComboPoints.Multiplier end,
											set = function(_, Multiplier)
													db.oUF.Target.ComboPoints.Multiplier = Multiplier
													
													r1 = db.oUF.Colors.ComboPoints.Combo1.r * Multiplier
													g1 = db.oUF.Colors.ComboPoints.Combo1.g * Multiplier
													b1 = db.oUF.Colors.ComboPoints.Combo1.b * Multiplier
													
													r2 = db.oUF.Colors.ComboPoints.Combo2.r * Multiplier
													g2 = db.oUF.Colors.ComboPoints.Combo2.g * Multiplier
													b2 = db.oUF.Colors.ComboPoints.Combo2.b * Multiplier
													
													r3 = db.oUF.Colors.ComboPoints.Combo3.r * Multiplier
													g3 = db.oUF.Colors.ComboPoints.Combo3.g * Multiplier
													b3 = db.oUF.Colors.ComboPoints.Combo3.b * Multiplier
													
													r4 = db.oUF.Colors.ComboPoints.Combo4.r * Multiplier
													g4 = db.oUF.Colors.ComboPoints.Combo4.g * Multiplier
													b4 = db.oUF.Colors.ComboPoints.Combo4.b * Multiplier
													
													r5 = db.oUF.Colors.ComboPoints.Combo5.r * Multiplier
													g5 = db.oUF.Colors.ComboPoints.Combo5.g * Multiplier
													b5 = db.oUF.Colors.ComboPoints.Combo5.b * Multiplier
													
													oUF_LUI_target.ComboPoints[1].bg:SetVertexColor(r1, g1, b1)
													oUF_LUI_target.ComboPoints[2].bg:SetVertexColor(r2, g2, b2) 
													oUF_LUI_target.ComboPoints[3].bg:SetVertexColor(r3, g3, b3) 
													oUF_LUI_target.ComboPoints[4].bg:SetVertexColor(r4, g4, b4) 
													oUF_LUI_target.ComboPoints[5].bg:SetVertexColor(r5, g5, b5)
												end,
											order = 7,
										},
										IndividualBackgroundColor = {
											name = "Individual Background Color",
											desc = "Wether you want to use an individual Background Color or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.Target.ComboPoints.BackgroundColor.Enable end,
											set = function(self,IndividualBackgroundColor)
														db.oUF.Target.ComboPoints.BackgroundColor.Enable = not db.oUF.Target.ComboPoints.BackgroundColor.Enable
														if IndividualBackgroundColor == true then
															r = db.oUF.Target.ComboPoints.BackgroundColor.r
															g = db.oUF.Target.ComboPoints.BackgroundColor.g
															b = db.oUF.Target.ComboPoints.BackgroundColor.b
														
															oUF_LUI_target.ComboPoints[1].bg:SetVertexColor(r, g, b)
															oUF_LUI_target.ComboPoints[2].bg:SetVertexColor(r, g, b) 
															oUF_LUI_target.ComboPoints[3].bg:SetVertexColor(r, g, b) 
															oUF_LUI_target.ComboPoints[4].bg:SetVertexColor(r, g, b) 
															oUF_LUI_target.ComboPoints[5].bg:SetVertexColor(r, g, b)
														else
															r1 = db.oUF.Colors.ComboPoints.Combo1.r * db.oUF.Player.ComboPoints.Multiplier
															g1 = db.oUF.Colors.ComboPoints.Combo1.g * db.oUF.Player.ComboPoints.Multiplier
															b1 = db.oUF.Colors.ComboPoints.Combo1.b * db.oUF.Player.ComboPoints.Multiplier
															
															r2 = db.oUF.Colors.ComboPoints.Combo2.r * db.oUF.Player.ComboPoints.Multiplier
															g2 = db.oUF.Colors.ComboPoints.Combo2.g * db.oUF.Player.ComboPoints.Multiplier
															b2 = db.oUF.Colors.ComboPoints.Combo2.b * db.oUF.Player.ComboPoints.Multiplier
															
															r3 = db.oUF.Colors.ComboPoints.Combo3.r * db.oUF.Player.ComboPoints.Multiplier
															g3 = db.oUF.Colors.ComboPoints.Combo3.g * db.oUF.Player.ComboPoints.Multiplier
															b3 = db.oUF.Colors.ComboPoints.Combo3.b * db.oUF.Player.ComboPoints.Multiplier
															
															r4 = db.oUF.Colors.ComboPoints.Combo4.r * db.oUF.Player.ComboPoints.Multiplier
															g4 = db.oUF.Colors.ComboPoints.Combo4.g * db.oUF.Player.ComboPoints.Multiplier
															b4 = db.oUF.Colors.ComboPoints.Combo4.b * db.oUF.Player.ComboPoints.Multiplier
															
															r5 = db.oUF.Colors.ComboPoints.Combo5.r * db.oUF.Player.ComboPoints.Multiplier
															g5 = db.oUF.Colors.ComboPoints.Combo5.g * db.oUF.Player.ComboPoints.Multiplier
															b5 = db.oUF.Colors.ComboPoints.Combo5.b * db.oUF.Player.ComboPoints.Multiplier
															
															oUF_LUI_target.ComboPoints[1].bg:SetVertexColor(r1, g1, b1)
															oUF_LUI_target.ComboPoints[2].bg:SetVertexColor(r2, g2, b2) 
															oUF_LUI_target.ComboPoints[3].bg:SetVertexColor(r3, g3, b3) 
															oUF_LUI_target.ComboPoints[4].bg:SetVertexColor(r4, g4, b4) 
															oUF_LUI_target.ComboPoints[5].bg:SetVertexColor(r5, g5, b5)
														end
													end,
											order = 8,
										},
										BackgroundColor = {
											name = "Individual Color",
											desc = "Choose an individual Background Color Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.Target.Texts.Health.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.Target.ComboPoints.BackgroundColor.r, db.oUF.Target.ComboPoints.BackgroundColor.g, db.oUF.Target.ComboPoints.BackgroundColor.b end,
											set = function(_,r,g,b)
													db.oUF.Target.ComboPoints.BackgroundColor.r = r
													db.oUF.Target.ComboPoints.BackgroundColor.g = g
													db.oUF.Target.ComboPoints.BackgroundColor.b = b
													
													oUF_LUI_target.ComboPoints[1].bg:SetVertexColor(r, g, b)
													oUF_LUI_target.ComboPoints[2].bg:SetVertexColor(r, g, b) 
													oUF_LUI_target.ComboPoints[3].bg:SetVertexColor(r, g, b) 
													oUF_LUI_target.ComboPoints[4].bg:SetVertexColor(r, g, b) 
													oUF_LUI_target.ComboPoints[5].bg:SetVertexColor(r, g, b) 
												end,
											order = 9,
										},
									},
								},
							},
						},
					},
				},
				Texts = {
					name = "Texts",
					type = "group",
					childGroups = "tab",
					order = 6,
					args = {
						Name = {
							name = "Name",
							type = "group",
							order = 1,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the Target Name or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Texts.Name.Enable end,
									set = function(self,Enable)
												db.oUF.Target.Texts.Name.Enable = not db.oUF.Target.Texts.Name.Enable
												if Enable == true then
													oUF_LUI_target.Info:Show()
												else
													oUF_LUI_target.Info:Hide()
												end
											end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your Target Name Fontsize!\n Default: "..LUI.defaults.profile.oUF.Target.Texts.Name.Size,
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.Target.Texts.Name.Size end,
											set = function(_, FontSize)
													db.oUF.Target.Texts.Name.Size = FontSize
													oUF_LUI_target.Info:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.Name.Font),db.oUF.Target.Texts.Name.Size,db.oUF.Target.Texts.Name.Outline)
												end,
											order = 1,
										},
										empty = {
											order = 2,
											width = "full",
											type = "description",
											name = " ",
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for Target Name!\n\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Name.Font,
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.Target.Texts.Name.Font end,
											set = function(self, Font)
													db.oUF.Target.Texts.Name.Font = Font
													oUF_LUI_target.Info:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.Name.Font),db.oUF.Target.Texts.Name.Size,db.oUF.Target.Texts.Name.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your Target Name.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Name.Outline,
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.Target.Texts.Name.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.Target.Texts.Name.Outline = fontflags[FontFlag]
													oUF_LUI_target.Info:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.Name.Font),db.oUF.Target.Texts.Name.Size,db.oUF.Target.Texts.Name.Outline)
												end,
											order = 4,
										},
										NameX = {
											name = "X Value",
											desc = "X Value for your Target Name.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Name.X,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											get = function() return db.oUF.Target.Texts.Name.X end,
											set = function(self,NameX)
														if NameX == nil or NameX == "" then
															NameX = "0"
														end
														db.oUF.Target.Texts.Name.X = NameX
														oUF_LUI_target.Info:ClearAllPoints()
														oUF_LUI_target.Info:SetPoint(db.oUF.Target.Texts.Name.Point, oUF_LUI_target, db.oUF.Target.Texts.Name.RelativePoint, tonumber(db.oUF.Target.Texts.Name.X), tonumber(db.oUF.Target.Texts.Name.Y))
													end,
											order = 5,
										},
										NameY = {
											name = "Y Value",
											desc = "Y Value for your Target Name.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Name.Y,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											get = function() return db.oUF.Target.Texts.Name.Y end,
											set = function(self,NameY)
														if NameY == nil or NameY == "" then
															NameY = "0"
														end
														db.oUF.Target.Texts.Name.Y = NameY
														oUF_LUI_target.Info:ClearAllPoints()
														oUF_LUI_target.Info:SetPoint(db.oUF.Target.Texts.Name.Point, oUF_LUI_target, db.oUF.Target.Texts.Name.RelativePoint, tonumber(db.oUF.Target.Texts.Name.X), tonumber(db.oUF.Target.Texts.Name.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your Target Name.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Name.Point,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.Name.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.Target.Texts.Name.Point = positions[Point]
													oUF_LUI_target.Info:ClearAllPoints()
													oUF_LUI_target.Info:SetPoint(db.oUF.Target.Texts.Name.Point, oUF_LUI_target, db.oUF.Target.Texts.Name.RelativePoint, tonumber(db.oUF.Target.Texts.Name.X), tonumber(db.oUF.Target.Texts.Name.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your Target Name.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Name.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.Name.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.Target.Texts.Name.RelativePoint = positions[RelativePoint]
													oUF_LUI_target.Info:ClearAllPoints()
													oUF_LUI_target.Info:SetPoint(db.oUF.Target.Texts.Name.Point, oUF_LUI_target, db.oUF.Target.Texts.Name.RelativePoint, tonumber(db.oUF.Target.Texts.Name.X), tonumber(db.oUF.Target.Texts.Name.Y))
												end,
											order = 8,
										},
									},
								},
								Settings = {
									name = "Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
									guiInline = true,
									order = 2,
									args = {
										Format = {
											name = "Format",
											desc = "Choose the Format for your Target Name.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Name.Format,
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											type = "select",
											width = "full",
											values = nameFormat,
											get = function()
													for k, v in pairs(nameFormat) do
														if db.oUF.Target.Texts.Name.Format == v then
															return k
														end
													end
												end,
											set = function(self, Format)
													db.oUF.Target.Texts.Name.Format = nameFormat[Format]
												end,
											order = 1,
										},
										Length = {
											name = "Length",
											desc = "Choose the Length of your Target Name.\n\nShort = 6 Letters\nMedium = 18 Letters\nLong = 36 Letters\n\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Name.Length,
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											type = "select",
											values = nameLenghts,
											get = function()
													for k, v in pairs(nameLenghts) do
														if db.oUF.Target.Texts.Name.Length == v then
															return k
														end
													end
												end,
											set = function(self, Length)
													db.oUF.Target.Texts.Name.Length = nameLenghts[Length]
												end,
											order = 2,
										},
										empty = {
											order = 3,
											width = "full",
											type = "description",
											name = " ",
										},
										ColorNameByClass = {
											name = "Color Name by Class",
											desc = "Wether you want to color the Target Name by Class or not.",
											type = "toggle",
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											get = function() return db.oUF.Target.Texts.Name.ColorNameByClass end,
											set = function(self,ColorNameByClass)
														db.oUF.Target.Texts.Name.ColorNameByClass = not db.oUF.Target.Texts.Name.ColorNameByClass
													end,
											order = 4,
										},
										ColorClassByClass = {
											name = "Color Class by Class",
											desc = "Wether you want to color the Target Class by Class or not.",
											type = "toggle",
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											get = function() return db.oUF.Target.Texts.Name.ColorClassByClass end,
											set = function(self,ColorClassByClass)
														db.oUF.Target.Texts.Name.ColorClassByClass = not db.oUF.Target.Texts.Name.ColorClassByClass
													end,
											order = 5,
										},
										ColorLevelByDifficulty = {
											name = "Color Level by Difficulty",
											desc = "Wether you want to color the Level by Difficulty or not.",
											type = "toggle",
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											get = function() return db.oUF.Target.Texts.Name.ColorLevelByDifficulty end,
											set = function(self,ColorLevelByDifficulty)
														db.oUF.Target.Texts.Name.ColorLevelByDifficulty = not db.oUF.Target.Texts.Name.ColorLevelByDifficulty
													end,
											order = 6,
										},
										ShowClassification = {
											name = "Show Classification",
											desc = "Wether you want to show Classifications like Elite, Boss, Rar or not.",
											type = "toggle",
											disabled = function() return not db.oUF.Target.Texts.Name.Enable end,
											get = function() return db.oUF.Target.Texts.Name.ShowClassification end,
											set = function(self,ShowClassification)
														db.oUF.Target.Texts.Name.ShowClassification = not db.oUF.Target.Texts.Name.ShowClassification
													end,
											order = 7,
										},
										ShortClassification = {
											name = "Enable Short Classification",
											desc = "Wether you want to show short Classifications or not.",
											type = "toggle",
											width = "full",
											disabled = function() return not db.oUF.Target.Texts.Name.ShowClassification end,
											get = function() return db.oUF.Target.Texts.Name.ShortClassification end,
											set = function(self,ShortClassification)
														db.oUF.Target.Texts.Name.ShortClassification = not db.oUF.Target.Texts.Name.ShortClassification
													end,
											order = 8,
										},
									},
								},
							},
						},
						Health = {
							name = "Health",
							type = "group",
							order = 2,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the Target Health or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Texts.Health.Enable end,
									set = function(self,Enable)
											db.oUF.Target.Texts.Health.Enable = not db.oUF.Target.Texts.Health.Enable
											if Enable == true then
												oUF_LUI_target.Health.value:Show()
											else
												oUF_LUI_target.Health.value:Hide()
											end
										end,
									order = 0,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.Health.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your Target Health Fontsize!\n Default: "..LUI.defaults.profile.oUF.Target.Texts.Health.Size,
											disabled = function() return not db.oUF.Target.Texts.Health.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.Target.Texts.Health.Size end,
											set = function(_, FontSize)
													db.oUF.Target.Texts.Health.Size = FontSize
													oUF_LUI_target.Health.value:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.Health.Font),db.oUF.Target.Texts.Health.Size,db.oUF.Target.Texts.Health.Outline)
												end,
											order = 1,
										},
										Format = {
											name = "Format",
											desc = "Choose the Format for your Target Health.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Health.Format,
											disabled = function() return not db.oUF.Target.Texts.Health.Enable end,
											type = "select",
											values = valueFormat,
											get = function()
													for k, v in pairs(valueFormat) do
														if db.oUF.Target.Texts.Health.Format == v then
															return k
														end
													end
												end,
											set = function(self, Format)
													db.oUF.Target.Texts.Health.Format = valueFormat[Format]
													print("Target Health Value Format will change once you gain/lose Health")
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for Target Health!\n\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Health.Font,
											disabled = function() return not db.oUF.Target.Texts.Health.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.Target.Texts.Health.Font end,
											set = function(self, Font)
													db.oUF.Target.Texts.Health.Font = Font
													oUF_LUI_target.Health.value:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.Health.Font),db.oUF.Target.Texts.Health.Size,db.oUF.Target.Texts.Health.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your Target Health.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Health.Outline,
											disabled = function() return not db.oUF.Target.Texts.Health.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.Target.Texts.Health.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.Target.Texts.Health.Outline = fontflags[FontFlag]
													oUF_LUI_target.Health.value:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.Health.Font),db.oUF.Target.Texts.Health.Size,db.oUF.Target.Texts.Health.Outline)
												end,
											order = 4,
										},
										HealthX = {
											name = "X Value",
											desc = "X Value for your Target Health.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Health.X,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.Health.Enable end,
											get = function() return db.oUF.Target.Texts.Health.X end,
											set = function(self,HealthX)
														if HealthX == nil or HealthX == "" then
															HealthX = "0"
														end
														db.oUF.Target.Texts.Health.X = HealthX
														oUF_LUI_target.Health.value:ClearAllPoints()
														oUF_LUI_target.Health.value:SetPoint(db.oUF.Target.Texts.Health.Point, oUF_LUI_target, db.oUF.Target.Texts.Health.RelativePoint, tonumber(db.oUF.Target.Texts.Health.X), tonumber(db.oUF.Target.Texts.Health.Y))
													end,
											order = 5,
										},
										HealthY = {
											name = "Y Value",
											desc = "Y Value for your Target Health.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Health.Y,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.Health.Enable end,
											get = function() return db.oUF.Target.Texts.Health.Y end,
											set = function(self,HealthY)
														if HealthY == nil or HealthY == "" then
															HealthY = "0"
														end
														db.oUF.Target.Texts.Health.Y = HealthY
														oUF_LUI_target.Health.value:ClearAllPoints()
														oUF_LUI_target.Health.value:SetPoint(db.oUF.Target.Texts.Health.Point, oUF_LUI_target, db.oUF.Target.Texts.Health.RelativePoint, tonumber(db.oUF.Target.Texts.Health.X), tonumber(db.oUF.Target.Texts.Health.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your Target Health.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Health.Point,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.Health.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.Health.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.Target.Texts.Health.Point = positions[Point]
													oUF_LUI_target.Health.value:ClearAllPoints()
													oUF_LUI_target.Health.value:SetPoint(db.oUF.Target.Texts.Health.Point, oUF_LUI_target, db.oUF.Target.Texts.Health.RelativePoint, tonumber(db.oUF.Target.Texts.Health.X), tonumber(db.oUF.Target.Texts.Health.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your Target Health.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Health.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.Health.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.Health.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.Target.Texts.Health.RelativePoint = positions[RelativePoint]
													oUF_LUI_target.Health.value:ClearAllPoints()
													oUF_LUI_target.Health.value:SetPoint(db.oUF.Target.Texts.Health.Point, oUF_LUI_target, db.oUF.Target.Texts.Health.RelativePoint, tonumber(db.oUF.Target.Texts.Health.X), tonumber(db.oUF.Target.Texts.Health.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.Health.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored Health Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.Health.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.Target.Texts.Health.ColorClass = not db.oUF.Target.Texts.Health.ColorClass
														if ClassColor == true then
															db.oUF.Target.Texts.Health.ColorGradient = false
															db.oUF.Target.Texts.Health.IndividualColor.Enable = false
															
															print("Target Health Value Color will change once you gain/lose Health")
														end
													end,
											order = 1,
										},
										ColorGradient = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored Health Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.Health.ColorGradient end,
											set = function(self,ColorGradient)
														db.oUF.Target.Texts.Health.ColorGradient = not db.oUF.Target.Texts.Health.ColorGradient
														if ColorGradient == true then
															db.oUF.Target.Texts.Health.ColorClass = false
															db.oUF.Target.Texts.Health.IndividualColor.Enable = false
															
															print("Target Health Value Color will change once you gain/lose Health")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual Target Health Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.Health.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.Target.Texts.Health.IndividualColor.Enable = not db.oUF.Target.Texts.Health.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.Target.Texts.Health.ColorClass = false
															db.oUF.Target.Texts.Health.ColorGradient = false
															
															oUF_LUI_target.Health.value:SetTextColor(tonumber(db.oUF.Target.Texts.Health.IndividualColor.r),tonumber(db.oUF.Target.Texts.Health.IndividualColor.g),tonumber(db.oUF.Target.Texts.Health.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual Target Health Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.Target.Texts.Health.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.Target.Texts.Health.IndividualColor.r, db.oUF.Target.Texts.Health.IndividualColor.g, db.oUF.Target.Texts.Health.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.Target.Texts.Health.IndividualColor.r = r
													db.oUF.Target.Texts.Health.IndividualColor.g = g
													db.oUF.Target.Texts.Health.IndividualColor.b = b
													
													oUF_LUI_target.Health.value:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
								Settings = {
									name = "Settings",
									type = "group",
									guiInline = true,
									order = 3,
									args = {
										ShowDead = {
											name = "Show Dead/AFK/Disconnected Information",
											desc = "Wether you want to switch the Health Value to Dead/AFK/Disconnected or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.Target.Texts.Health.ShowDead end,
											set = function(self,ShowDead)
														db.oUF.Target.Texts.Health.ShowDead = not db.oUF.Target.Texts.Health.ShowDead
													end,
											order = 1,
										},
									},
								},
							},
						},
						Power = {
							name = "Power",
							type = "group",
							order = 3,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the Target Power or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Texts.Power.Enable end,
									set = function(self,Enable)
											db.oUF.Target.Texts.Power.Enable = not db.oUF.Target.Texts.Power.Enable
											if Enable == true then
												oUF_LUI_target.Power.value:Show()
											else
												oUF_LUI_target.Power.value:Hide()
											end
										end,
									order = 0,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.Power.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your Target Power Fontsize!\n Default: "..LUI.defaults.profile.oUF.Target.Texts.Power.Size,
											disabled = function() return not db.oUF.Target.Texts.Power.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.Target.Texts.Power.Size end,
											set = function(_, FontSize)
													db.oUF.Target.Texts.Power.Size = FontSize
													oUF_LUI_target.Power.value:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.Power.Font),db.oUF.Target.Texts.Power.Size,db.oUF.Target.Texts.Power.Outline)
												end,
											order = 1,
										},
										Format = {
											name = "Format",
											desc = "Choose the Format for your Target Power.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Power.Format,
											disabled = function() return not db.oUF.Target.Texts.Power.Enable end,
											type = "select",
											values = valueFormat,
											get = function()
													for k, v in pairs(valueFormat) do
														if db.oUF.Target.Texts.Power.Format == v then
															return k
														end
													end
												end,
											set = function(self, Format)
													db.oUF.Target.Texts.Power.Format = valueFormat[Format]
													print("Target Power Value Format will change once you gain/lose Power")
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for Target Power!\n\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Power.Font,
											disabled = function() return not db.oUF.Target.Texts.Power.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.Target.Texts.Power.Font end,
											set = function(self, Font)
													db.oUF.Target.Texts.Power.Font = Font
													oUF_LUI_target.Power.value:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.Power.Font),db.oUF.Target.Texts.Power.Size,db.oUF.Target.Texts.Power.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your Target Power.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Power.Outline,
											disabled = function() return not db.oUF.Target.Texts.Power.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.Target.Texts.Power.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.Target.Texts.Power.Outline = fontflags[FontFlag]
													oUF_LUI_target.Power.value:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.Power.Font),db.oUF.Target.Texts.Power.Size,db.oUF.Target.Texts.Power.Outline)
												end,
											order = 4,
										},
										PowerX = {
											name = "X Value",
											desc = "X Value for your Target Power.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Power.X,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.Power.Enable end,
											get = function() return db.oUF.Target.Texts.Power.X end,
											set = function(self,PowerX)
														if PowerX == nil or PowerX == "" then
															PowerX = "0"
														end
														db.oUF.Target.Texts.Power.X = PowerX
														oUF_LUI_target.Power.value:ClearAllPoints()
														oUF_LUI_target.Power.value:SetPoint(db.oUF.Target.Texts.Power.Point, oUF_LUI_target, db.oUF.Target.Texts.Power.RelativePoint, tonumber(db.oUF.Target.Texts.Power.X), tonumber(db.oUF.Target.Texts.Power.Y))
													end,
											order = 5,
										},
										PowerY = {
											name = "Y Value",
											desc = "Y Value for your Target Power.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Power.Y,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.Power.Enable end,
											get = function() return db.oUF.Target.Texts.Power.Y end,
											set = function(self,PowerY)
														if PowerY == nil or PowerY == "" then
															PowerY = "0"
														end
														db.oUF.Target.Texts.Power.Y = PowerY
														oUF_LUI_target.Power.value:ClearAllPoints()
														oUF_LUI_target.Power.value:SetPoint(db.oUF.Target.Texts.Power.Point, oUF_LUI_target, db.oUF.Target.Texts.Power.RelativePoint, tonumber(db.oUF.Target.Texts.Power.X), tonumber(db.oUF.Target.Texts.Power.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your Target Power.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Power.Point,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.Power.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.Power.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.Target.Texts.Power.Point = positions[Point]
													oUF_LUI_target.Power.value:ClearAllPoints()
													oUF_LUI_target.Power.value:SetPoint(db.oUF.Target.Texts.Power.Point, oUF_LUI_target, db.oUF.Target.Texts.Power.RelativePoint, tonumber(db.oUF.Target.Texts.Power.X), tonumber(db.oUF.Target.Texts.Power.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your Target Power.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.Power.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.Power.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.Power.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.Target.Texts.Power.RelativePoint = positions[RelativePoint]
													oUF_LUI_target.Power.value:ClearAllPoints()
													oUF_LUI_target.Power.value:SetPoint(db.oUF.Target.Texts.Power.Point, oUF_LUI_target, db.oUF.Target.Texts.Power.RelativePoint, tonumber(db.oUF.Target.Texts.Power.X), tonumber(db.oUF.Target.Texts.Power.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.Power.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored Power Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.Power.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.Target.Texts.Power.ColorClass = not db.oUF.Target.Texts.Power.ColorClass
														if ClassColor == true then
															db.oUF.Target.Texts.Power.ColorType = false
															db.oUF.Target.Texts.Power.IndividualColor.Enable = false
															
															print("Target Power Value Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										ColorType = {
											name = "Color by Type",
											desc = "Wether you want to use Powertype colored Power Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.Power.ColorType end,
											set = function(self,ColorType)
														db.oUF.Target.Texts.Power.ColorType = not db.oUF.Target.Texts.Power.ColorType
														if ColorType == true then
															db.oUF.Target.Texts.Power.ColorClass = false
															db.oUF.Target.Texts.Power.IndividualColor.Enable = false
															
															print("Target Power Value Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual Target Power Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.Power.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.Target.Texts.Power.IndividualColor.Enable = not db.oUF.Target.Texts.Power.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.Target.Texts.Power.ColorClass = false
															db.oUF.Target.Texts.Power.ColorType = false
															
															oUF_LUI_target.Power.value:SetTextColor(tonumber(db.oUF.Target.Texts.Power.IndividualColor.r),tonumber(db.oUF.Target.Texts.Power.IndividualColor.g),tonumber(db.oUF.Target.Texts.Power.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual Target Power Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.Target.Texts.Power.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.Target.Texts.Power.IndividualColor.r, db.oUF.Target.Texts.Power.IndividualColor.g, db.oUF.Target.Texts.Power.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.Target.Texts.Power.IndividualColor.r = r
													db.oUF.Target.Texts.Power.IndividualColor.g = g
													db.oUF.Target.Texts.Power.IndividualColor.b = b
													
													oUF_LUI_target.Power.value:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
						HealthPercent = {
							name = "HealthPercent",
							type = "group",
							order = 4,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the Target HealthPercent or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Texts.HealthPercent.Enable end,
									set = function(self,Enable)
											db.oUF.Target.Texts.HealthPercent.Enable = not db.oUF.Target.Texts.HealthPercent.Enable
											if Enable == true then
												oUF_LUI_target.Health.valuePercent:Show()
											else
												oUF_LUI_target.Health.valuePercent:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.HealthPercent.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your Target HealthPercent Fontsize!\n Default: "..LUI.defaults.profile.oUF.Target.Texts.HealthPercent.Size,
											disabled = function() return not db.oUF.Target.Texts.HealthPercent.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.Target.Texts.HealthPercent.Size end,
											set = function(_, FontSize)
													db.oUF.Target.Texts.HealthPercent.Size = FontSize
													oUF_LUI_target.Health.valuePercent:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.HealthPercent.Font),db.oUF.Target.Texts.HealthPercent.Size,db.oUF.Target.Texts.HealthPercent.Outline)
												end,
											order = 1,
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show Target HealthPercent or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.Target.Texts.HealthPercent.Enable end,
											type = "toggle",
											get = function() return db.oUF.Target.Texts.HealthPercent.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.Target.Texts.HealthPercent.ShowAlways = not db.oUF.Target.Texts.HealthPercent.ShowAlways
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for Target HealthPercent!\n\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthPercent.Font,
											disabled = function() return not db.oUF.Target.Texts.HealthPercent.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.Target.Texts.HealthPercent.Font end,
											set = function(self, Font)
													db.oUF.Target.Texts.HealthPercent.Font = Font
													oUF_LUI_target.Health.valuePercent:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.HealthPercent.Font),db.oUF.Target.Texts.HealthPercent.Size,db.oUF.Target.Texts.HealthPercent.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your Target HealthPercent.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthPercent.Outline,
											disabled = function() return not db.oUF.Target.Texts.HealthPercent.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.Target.Texts.HealthPercent.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.Target.Texts.HealthPercent.Outline = fontflags[FontFlag]
													oUF_LUI_target.Health.valuePercent:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.HealthPercent.Font),db.oUF.Target.Texts.HealthPercent.Size,db.oUF.Target.Texts.HealthPercent.Outline)
												end,
											order = 4,
										},
										HealthPercentX = {
											name = "X Value",
											desc = "X Value for your Target HealthPercent.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthPercent.X,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.HealthPercent.Enable end,
											get = function() return db.oUF.Target.Texts.HealthPercent.X end,
											set = function(self,HealthPercentX)
														if HealthPercentX == nil or HealthPercentX == "" then
															HealthPercentX = "0"
														end
														db.oUF.Target.Texts.HealthPercent.X = HealthPercentX
														oUF_LUI_target.Health.valuePercent:ClearAllPoints()
														oUF_LUI_target.Health.valuePercent:SetPoint(db.oUF.Target.Texts.HealthPercent.Point, oUF_LUI_target, db.oUF.Target.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.Target.Texts.HealthPercent.X), tonumber(db.oUF.Target.Texts.HealthPercent.Y))
													end,
											order = 5,
										},
										HealthPercentY = {
											name = "Y Value",
											desc = "Y Value for your Target HealthPercent.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthPercent.Y,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.HealthPercent.Enable end,
											get = function() return db.oUF.Target.Texts.HealthPercent.Y end,
											set = function(self,HealthPercentY)
														if HealthPercentY == nil or HealthPercentY == "" then
															HealthPercentY = "0"
														end
														db.oUF.Target.Texts.HealthPercent.Y = HealthPercentY
														oUF_LUI_target.Health.valuePercent:ClearAllPoints()
														oUF_LUI_target.Health.valuePercent:SetPoint(db.oUF.Target.Texts.HealthPercent.Point, oUF_LUI_target, db.oUF.Target.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.Target.Texts.HealthPercent.X), tonumber(db.oUF.Target.Texts.HealthPercent.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your Target HealthPercent.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthPercent.Point,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.HealthPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.HealthPercent.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.Target.Texts.HealthPercent.Point = positions[Point]
													oUF_LUI_target.Health.valuePercent:ClearAllPoints()
													oUF_LUI_target.Health.valuePercent:SetPoint(db.oUF.Target.Texts.HealthPercent.Point, oUF_LUI_target, db.oUF.Target.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.Target.Texts.HealthPercent.X), tonumber(db.oUF.Target.Texts.HealthPercent.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your Target HealthPercent.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthPercent.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.HealthPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.HealthPercent.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.Target.Texts.HealthPercent.RelativePoint = positions[RelativePoint]
													oUF_LUI_target.Health.valuePercent:ClearAllPoints()
													oUF_LUI_target.Health.valuePercent:SetPoint(db.oUF.Target.Texts.HealthPercent.Point, oUF_LUI_target, db.oUF.Target.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.Target.Texts.HealthPercent.X), tonumber(db.oUF.Target.Texts.HealthPercent.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.HealthPercent.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored HealthPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.HealthPercent.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.Target.Texts.HealthPercent.ColorClass = not db.oUF.Target.Texts.HealthPercent.ColorClass
														if ClassColor == true then
															db.oUF.Target.Texts.HealthPercent.ColorGradient = false
															db.oUF.Target.Texts.HealthPercent.IndividualColor.Enable = false
															
															print("Target HealthPercent Value Color will change once you gain/lose Health")
														end
													end,
											order = 1,
										},
										ColorGradient = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored HealthPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.HealthPercent.ColorGradient end,
											set = function(self,ColorGradient)
														db.oUF.Target.Texts.HealthPercent.ColorGradient = not db.oUF.Target.Texts.HealthPercent.ColorGradient
														if ColorGradient == true then
															db.oUF.Target.Texts.HealthPercent.ColorClass = false
															db.oUF.Target.Texts.HealthPercent.IndividualColor.Enable = false
															
															print("Target HealthPercent Value Color will change once you gain/lose Health")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual Target HealthPercent Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.HealthPercent.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.Target.Texts.HealthPercent.IndividualColor.Enable = not db.oUF.Target.Texts.HealthPercent.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.Target.Texts.HealthPercent.ColorClass = false
															db.oUF.Target.Texts.HealthPercent.ColorGradient = false
															
															oUF_LUI_target.Health.valuePercent:SetTextColor(tonumber(db.oUF.Target.Texts.HealthPercent.IndividualColor.r),tonumber(db.oUF.Target.Texts.HealthPercent.IndividualColor.g),tonumber(db.oUF.Target.Texts.HealthPercent.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual Target HealthPercent Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.Target.Texts.HealthPercent.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.Target.Texts.HealthPercent.IndividualColor.r, db.oUF.Target.Texts.HealthPercent.IndividualColor.g, db.oUF.Target.Texts.HealthPercent.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.Target.Texts.HealthPercent.IndividualColor.r = r
													db.oUF.Target.Texts.HealthPercent.IndividualColor.g = g
													db.oUF.Target.Texts.HealthPercent.IndividualColor.b = b
													
													oUF_LUI_target.Health.valuePercent:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
								Settings = {
									name = "Settings",
									type = "group",
									guiInline = true,
									order = 3,
									args = {
										ShowDead = {
											name = "Show Dead/AFK/Disconnected Information",
											desc = "Wether you want to switch the HealthPercent Value to Dead/AFK/Disconnected or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.Target.Texts.HealthPercent.ShowDead end,
											set = function(self,ShowDead)
														db.oUF.Target.Texts.HealthPercent.ShowDead = not db.oUF.Target.Texts.HealthPercent.ShowDead
													end,
											order = 1,
										},
									},
								},
							},
						},
						PowerPercent = {
							name = "PowerPercent",
							type = "group",
							order = 5,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the Target PowerPercent or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Texts.PowerPercent.Enable end,
									set = function(self,Enable)
											db.oUF.Target.Texts.PowerPercent.Enable = not db.oUF.Target.Texts.PowerPercent.Enable
											if Enable == true then
												oUF_LUI_target.Power.valuePercent:Show()
											else
												oUF_LUI_target.Power.valuePercent:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.PowerPercent.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your Target PowerPercent Fontsize!\n Default: "..LUI.defaults.profile.oUF.Target.Texts.PowerPercent.Size,
											disabled = function() return not db.oUF.Target.Texts.PowerPercent.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.Target.Texts.PowerPercent.Size end,
											set = function(_, FontSize)
													db.oUF.Target.Texts.PowerPercent.Size = FontSize
													oUF_LUI_target.Power.valuePercent:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.PowerPercent.Font),db.oUF.Target.Texts.PowerPercent.Size,db.oUF.Target.Texts.PowerPercent.Outline)
												end,
											order = 1,
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show Target PowerPercent or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.Target.Texts.PowerPercent.Enable end,
											type = "toggle",
											get = function() return db.oUF.Target.Texts.PowerPercent.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.Target.Texts.PowerPercent.ShowAlways = not db.oUF.Target.Texts.PowerPercent.ShowAlways
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for Target PowerPercent!\n\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerPercent.Font,
											disabled = function() return not db.oUF.Target.Texts.PowerPercent.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.Target.Texts.PowerPercent.Font end,
											set = function(self, Font)
													db.oUF.Target.Texts.PowerPercent.Font = Font
													oUF_LUI_target.Power.valuePercent:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.PowerPercent.Font),db.oUF.Target.Texts.PowerPercent.Size,db.oUF.Target.Texts.PowerPercent.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your Target PowerPercent.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerPercent.Outline,
											disabled = function() return not db.oUF.Target.Texts.PowerPercent.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.Target.Texts.PowerPercent.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.Target.Texts.PowerPercent.Outline = fontflags[FontFlag]
													oUF_LUI_target.Power.valuePercent:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.PowerPercent.Font),db.oUF.Target.Texts.PowerPercent.Size,db.oUF.Target.Texts.PowerPercent.Outline)
												end,
											order = 4,
										},
										PowerPercentX = {
											name = "X Value",
											desc = "X Value for your Target PowerPercent.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerPercent.X,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.PowerPercent.Enable end,
											get = function() return db.oUF.Target.Texts.PowerPercent.X end,
											set = function(self,PowerPercentX)
														if PowerPercentX == nil or PowerPercentX == "" then
															PowerPercentX = "0"
														end
														db.oUF.Target.Texts.PowerPercent.X = PowerPercentX
														oUF_LUI_target.Power.valuePercent:ClearAllPoints()
														oUF_LUI_target.Power.valuePercent:SetPoint(db.oUF.Target.Texts.PowerPercent.Point, oUF_LUI_target, db.oUF.Target.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.Target.Texts.PowerPercent.X), tonumber(db.oUF.Target.Texts.PowerPercent.Y))
													end,
											order = 5,
										},
										PowerPercentY = {
											name = "Y Value",
											desc = "Y Value for your Target PowerPercent.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerPercent.Y,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.PowerPercent.Enable end,
											get = function() return db.oUF.Target.Texts.PowerPercent.Y end,
											set = function(self,PowerPercentY)
														if PowerPercentY == nil or PowerPercentY == "" then
															PowerPercentY = "0"
														end
														db.oUF.Target.Texts.PowerPercent.Y = PowerPercentY
														oUF_LUI_target.Power.valuePercent:ClearAllPoints()
														oUF_LUI_target.Power.valuePercent:SetPoint(db.oUF.Target.Texts.PowerPercent.Point, oUF_LUI_target, db.oUF.Target.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.Target.Texts.PowerPercent.X), tonumber(db.oUF.Target.Texts.PowerPercent.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your Target PowerPercent.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerPercent.Point,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.PowerPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.PowerPercent.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.Target.Texts.PowerPercent.Point = positions[Point]
													oUF_LUI_target.Power.valuePercent:ClearAllPoints()
													oUF_LUI_target.Power.valuePercent:SetPoint(db.oUF.Target.Texts.PowerPercent.Point, oUF_LUI_target, db.oUF.Target.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.Target.Texts.PowerPercent.X), tonumber(db.oUF.Target.Texts.PowerPercent.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your Target PowerPercent.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerPercent.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.PowerPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.PowerPercent.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.Target.Texts.PowerPercent.RelativePoint = positions[RelativePoint]
													oUF_LUI_target.Power.valuePercent:ClearAllPoints()
													oUF_LUI_target.Power.valuePercent:SetPoint(db.oUF.Target.Texts.PowerPercent.Point, oUF_LUI_target, db.oUF.Target.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.Target.Texts.PowerPercent.X), tonumber(db.oUF.Target.Texts.PowerPercent.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.PowerPercent.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored PowerPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.PowerPercent.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.Target.Texts.PowerPercent.ColorClass = not db.oUF.Target.Texts.PowerPercent.ColorClass
														if ClassColor == true then
															db.oUF.Target.Texts.PowerPercent.ColorType = false
															db.oUF.Target.Texts.PowerPercent.IndividualColor.Enable = false
															
															print("Target PowerPercent Value Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										ColorType = {
											name = "Color by Type",
											desc = "Wether you want to use Type colored PowerPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.PowerPercent.ColorType end,
											set = function(self,ColorType)
														db.oUF.Target.Texts.PowerPercent.ColorType = not db.oUF.Target.Texts.PowerPercent.ColorType
														if ColorType == true then
															db.oUF.Target.Texts.PowerPercent.ColorClass = false
															db.oUF.Target.Texts.PowerPercent.IndividualColor.Enable = false
															
															print("Target PowerPercent Value Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual Target PowerPercent Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.PowerPercent.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.Target.Texts.PowerPercent.IndividualColor.Enable = not db.oUF.Target.Texts.PowerPercent.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.Target.Texts.PowerPercent.ColorClass = false
															db.oUF.Target.Texts.PowerPercent.ColorType = false
															
															oUF_LUI_target.Power.valuePercent:SetTextColor(tonumber(db.oUF.Target.Texts.PowerPercent.IndividualColor.r),tonumber(db.oUF.Target.Texts.PowerPercent.IndividualColor.g),tonumber(db.oUF.Target.Texts.PowerPercent.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual Target PowerPercent Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.Target.Texts.PowerPercent.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.Target.Texts.PowerPercent.IndividualColor.r, db.oUF.Target.Texts.PowerPercent.IndividualColor.g, db.oUF.Target.Texts.PowerPercent.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.Target.Texts.PowerPercent.IndividualColor.r = r
													db.oUF.Target.Texts.PowerPercent.IndividualColor.g = g
													db.oUF.Target.Texts.PowerPercent.IndividualColor.b = b
													
													oUF_LUI_target.Power.valuePercent:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
						HealthMissing = {
							name = "HealthMissing",
							type = "group",
							order = 6,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the Target HealthMissing or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Texts.HealthMissing.Enable end,
									set = function(self,Enable)
											db.oUF.Target.Texts.HealthMissing.Enable = not db.oUF.Target.Texts.HealthMissing.Enable
											if Enable == true then
												oUF_LUI_target.Health.valueMissing:Show()
											else
												oUF_LUI_target.Health.valueMissing:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your Target HealthMissing Fontsize!\n Default: "..LUI.defaults.profile.oUF.Target.Texts.HealthMissing.Size,
											disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.Target.Texts.HealthMissing.Size end,
											set = function(_, FontSize)
													db.oUF.Target.Texts.HealthMissing.Size = FontSize
													oUF_LUI_target.Health.valueMissing:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.HealthMissing.Font),db.oUF.Target.Texts.HealthMissing.Size,db.oUF.Target.Texts.HealthMissing.Outline)
												end,
											order = 1,
										},
										empty = {
											order = 2,
											width = "full",
											type = "description",
											name = " ",
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show Target HealthMissing or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.Target.Texts.HealthMissing.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.Target.Texts.HealthMissing.ShowAlways = not db.oUF.Target.Texts.HealthMissing.ShowAlways
												end,
											order = 3,
										},
										ShortValue = {
											name = "Short Value",
											desc = "Show a Short or the Normal Value of the Missing HP",
											disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.Target.Texts.HealthMissing.ShortValue end,
											set = function(self,ShortValue)
													db.oUF.Target.Texts.HealthMissing.ShortValue = not db.oUF.Target.Texts.HealthMissing.ShortValue
												end,
											order = 4,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for Target HealthMissing!\n\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthMissing.Font,
											disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.Target.Texts.HealthMissing.Font end,
											set = function(self, Font)
													db.oUF.Target.Texts.HealthMissing.Font = Font
													oUF_LUI_target.Health.valueMissing:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.HealthMissing.Font),db.oUF.Target.Texts.HealthMissing.Size,db.oUF.Target.Texts.HealthMissing.Outline)
												end,
											order = 5,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your Target HealthMissing.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthMissing.Outline,
											disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.Target.Texts.HealthMissing.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.Target.Texts.HealthMissing.Outline = fontflags[FontFlag]
													oUF_LUI_target.Health.valueMissing:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.HealthMissing.Font),db.oUF.Target.Texts.HealthMissing.Size,db.oUF.Target.Texts.HealthMissing.Outline)
												end,
											order = 6,
										},
										HealthMissingX = {
											name = "X Value",
											desc = "X Value for your Target HealthMissing.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthMissing.X,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
											get = function() return db.oUF.Target.Texts.HealthMissing.X end,
											set = function(self,HealthMissingX)
														if HealthMissingX == nil or HealthMissingX == "" then
															HealthMissingX = "0"
														end
														db.oUF.Target.Texts.HealthMissing.X = HealthMissingX
														oUF_LUI_target.Health.valueMissing:ClearAllPoints()
														oUF_LUI_target.Health.valueMissing:SetPoint(db.oUF.Target.Texts.HealthMissing.Point, oUF_LUI_target, db.oUF.Target.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.Target.Texts.HealthMissing.X), tonumber(db.oUF.Target.Texts.HealthMissing.Y))
													end,
											order = 7,
										},
										HealthMissingY = {
											name = "Y Value",
											desc = "Y Value for your Target HealthMissing.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthMissing.Y,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
											get = function() return db.oUF.Target.Texts.HealthMissing.Y end,
											set = function(self,HealthMissingY)
														if HealthMissingY == nil or HealthMissingY == "" then
															HealthMissingY = "0"
														end
														db.oUF.Target.Texts.HealthMissing.Y = HealthMissingY
														oUF_LUI_target.Health.valueMissing:ClearAllPoints()
														oUF_LUI_target.Health.valueMissing:SetPoint(db.oUF.Target.Texts.HealthMissing.Point, oUF_LUI_target, db.oUF.Target.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.Target.Texts.HealthMissing.X), tonumber(db.oUF.Target.Texts.HealthMissing.Y))
													end,
											order = 8,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your Target HealthMissing.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthMissing.Point,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.HealthMissing.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.Target.Texts.HealthMissing.Point = positions[Point]
													oUF_LUI_target.Health.valueMissing:ClearAllPoints()
													oUF_LUI_target.Health.valueMissing:SetPoint(db.oUF.Target.Texts.HealthMissing.Point, oUF_LUI_target, db.oUF.Target.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.Target.Texts.HealthMissing.X), tonumber(db.oUF.Target.Texts.HealthMissing.Y))
												end,
											order = 9,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your Target HealthMissing.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.HealthMissing.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.HealthMissing.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.Target.Texts.HealthMissing.RelativePoint = positions[RelativePoint]
													oUF_LUI_target.Health.valueMissing:ClearAllPoints()
													oUF_LUI_target.Health.valueMissing:SetPoint(db.oUF.Target.Texts.HealthMissing.Point, oUF_LUI_target, db.oUF.Target.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.Target.Texts.HealthMissing.X), tonumber(db.oUF.Target.Texts.HealthMissing.Y))
												end,
											order = 10,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.HealthMissing.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored HealthMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.HealthMissing.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.Target.Texts.HealthMissing.ColorClass = not db.oUF.Target.Texts.HealthMissing.ColorClass
														if ClassColor == true then
															db.oUF.Target.Texts.HealthMissing.ColorGradient = false
															db.oUF.Target.Texts.HealthMissing.IndividualColor.Enable = false
															
															print("Target HealthMissing Value Color will change once you gain/lose Health")
														end
													end,
											order = 1,
										},
										ColorGradient = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored HealthMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.HealthMissing.ColorGradient end,
											set = function(self,ColorGradient)
														db.oUF.Target.Texts.HealthMissing.ColorGradient = not db.oUF.Target.Texts.HealthMissing.ColorGradient
														if ColorGradient == true then
															db.oUF.Target.Texts.HealthMissing.ColorClass = false
															db.oUF.Target.Texts.HealthMissing.IndividualColor.Enable = false
															
															print("Target HealthMissing Value Color will change once you gain/lose Health")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual Target HealthMissing Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.HealthMissing.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.Target.Texts.HealthMissing.IndividualColor.Enable = not db.oUF.Target.Texts.HealthMissing.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.Target.Texts.HealthMissing.ColorClass = false
															db.oUF.Target.Texts.HealthMissing.ColorGradient = false
															
															oUF_LUI_target.Health.valueMissing:SetTextColor(tonumber(db.oUF.Target.Texts.HealthMissing.IndividualColor.r),tonumber(db.oUF.Target.Texts.HealthMissing.IndividualColor.g),tonumber(db.oUF.Target.Texts.HealthMissing.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual Target HealthMissing Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.Target.Texts.HealthMissing.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.Target.Texts.HealthMissing.IndividualColor.r, db.oUF.Target.Texts.HealthMissing.IndividualColor.g, db.oUF.Target.Texts.HealthMissing.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.Target.Texts.HealthMissing.IndividualColor.r = r
													db.oUF.Target.Texts.HealthMissing.IndividualColor.g = g
													db.oUF.Target.Texts.HealthMissing.IndividualColor.b = b
													
													oUF_LUI_target.Health.valueMissing:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
						PowerMissing = {
							name = "PowerMissing",
							type = "group",
							order = 7,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the Target PowerMissing or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Texts.PowerMissing.Enable end,
									set = function(self,Enable)
											db.oUF.Target.Texts.PowerMissing.Enable = not db.oUF.Target.Texts.PowerMissing.Enable
											if Enable == true then
												oUF_LUI_target.Power.valueMissing:Show()
											else
												oUF_LUI_target.Power.valueMissing:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your Target PowerMissing Fontsize!\n Default: "..LUI.defaults.profile.oUF.Target.Texts.PowerMissing.Size,
											disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.Target.Texts.PowerMissing.Size end,
											set = function(_, FontSize)
													db.oUF.Target.Texts.PowerMissing.Size = FontSize
													oUF_LUI_target.Power.valueMissing:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.PowerMissing.Font),db.oUF.Target.Texts.PowerMissing.Size,db.oUF.Target.Texts.PowerMissing.Outline)
												end,
											order = 1,
										},
										empty = {
											order = 2,
											width = "full",
											type = "description",
											name = " ",
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show Target PowerMissing or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.Target.Texts.PowerMissing.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.Target.Texts.PowerMissing.ShowAlways = not db.oUF.Target.Texts.PowerMissing.ShowAlways
												end,
											order = 3,
										},
										ShortValue = {
											name = "Short Value",
											desc = "Show a Short or the Normal Value of the Missing HP",
											disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.Target.Texts.PowerMissing.ShortValue end,
											set = function(self,ShortValue)
													db.oUF.Target.Texts.PowerMissing.ShortValue = not db.oUF.Target.Texts.PowerMissing.ShortValue
												end,
											order = 4,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for Target PowerMissing!\n\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerMissing.Font,
											disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.Target.Texts.PowerMissing.Font end,
											set = function(self, Font)
													db.oUF.Target.Texts.PowerMissing.Font = Font
													oUF_LUI_target.Power.valueMissing:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.PowerMissing.Font),db.oUF.Target.Texts.PowerMissing.Size,db.oUF.Target.Texts.PowerMissing.Outline)
												end,
											order = 5,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your Target PowerMissing.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerMissing.Outline,
											disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.Target.Texts.PowerMissing.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.Target.Texts.PowerMissing.Outline = fontflags[FontFlag]
													oUF_LUI_target.Power.valueMissing:SetFont(LSM:Fetch("font", db.oUF.Target.Texts.PowerMissing.Font),db.oUF.Target.Texts.PowerMissing.Size,db.oUF.Target.Texts.PowerMissing.Outline)
												end,
											order = 6,
										},
										PowerMissingX = {
											name = "X Value",
											desc = "X Value for your Target PowerMissing.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerMissing.X,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
											get = function() return db.oUF.Target.Texts.PowerMissing.X end,
											set = function(self,PowerMissingX)
														if PowerMissingX == nil or PowerMissingX == "" then
															PowerMissingX = "0"
														end
														db.oUF.Target.Texts.PowerMissing.X = PowerMissingX
														oUF_LUI_target.Power.valueMissing:ClearAllPoints()
														oUF_LUI_target.Power.valueMissing:SetPoint(db.oUF.Target.Texts.PowerMissing.Point, oUF_LUI_target, db.oUF.Target.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.Target.Texts.PowerMissing.X), tonumber(db.oUF.Target.Texts.PowerMissing.Y))
													end,
											order = 7,
										},
										PowerMissingY = {
											name = "Y Value",
											desc = "Y Value for your Target PowerMissing.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerMissing.Y,
											type = "input",
											disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
											get = function() return db.oUF.Target.Texts.PowerMissing.Y end,
											set = function(self,PowerMissingY)
														if PowerMissingY == nil or PowerMissingY == "" then
															PowerMissingY = "0"
														end
														db.oUF.Target.Texts.PowerMissing.Y = PowerMissingY
														oUF_LUI_target.Power.valueMissing:ClearAllPoints()
														oUF_LUI_target.Power.valueMissing:SetPoint(db.oUF.Target.Texts.PowerMissing.Point, oUF_LUI_target, db.oUF.Target.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.Target.Texts.PowerMissing.X), tonumber(db.oUF.Target.Texts.PowerMissing.Y))
													end,
											order = 8,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your Target PowerMissing.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerMissing.Point,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.PowerMissing.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.Target.Texts.PowerMissing.Point = positions[Point]
													oUF_LUI_target.Power.valueMissing:ClearAllPoints()
													oUF_LUI_target.Power.valueMissing:SetPoint(db.oUF.Target.Texts.PowerMissing.Point, oUF_LUI_target, db.oUF.Target.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.Target.Texts.PowerMissing.X), tonumber(db.oUF.Target.Texts.PowerMissing.Y))
												end,
											order = 9,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your Target PowerMissing.\nDefault: "..LUI.defaults.profile.oUF.Target.Texts.PowerMissing.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.Target.Texts.PowerMissing.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.Target.Texts.PowerMissing.RelativePoint = positions[RelativePoint]
													oUF_LUI_target.Power.valueMissing:ClearAllPoints()
													oUF_LUI_target.Power.valueMissing:SetPoint(db.oUF.Target.Texts.PowerMissing.Point, oUF_LUI_target, db.oUF.Target.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.Target.Texts.PowerMissing.X), tonumber(db.oUF.Target.Texts.PowerMissing.Y))
												end,
											order = 10,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.Target.Texts.PowerMissing.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored PowerMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.PowerMissing.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.Target.Texts.PowerMissing.ColorClass = not db.oUF.Target.Texts.PowerMissing.ColorClass
														if ClassColor == true then
															db.oUF.Target.Texts.PowerMissing.ColorType = false
															db.oUF.Target.Texts.PowerMissing.IndividualColor.Enable = false
															
															print("Target PowerMissing Value Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										ColorType = {
											name = "Color by Type",
											desc = "Wether you want to use Type colored PowerMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.PowerMissing.ColorType end,
											set = function(self,ColorType)
														db.oUF.Target.Texts.PowerMissing.ColorType = not db.oUF.Target.Texts.PowerMissing.ColorType
														if ColorType == true then
															db.oUF.Target.Texts.PowerMissing.ColorClass = false
															db.oUF.Target.Texts.PowerMissing.IndividualColor.Enable = false
															
															print("Target PowerMissing Value Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual Target PowerMissing Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.Target.Texts.PowerMissing.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.Target.Texts.PowerMissing.IndividualColor.Enable = not db.oUF.Target.Texts.PowerMissing.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.Target.Texts.PowerMissing.ColorClass = false
															db.oUF.Target.Texts.PowerMissing.ColorType = false
															
															oUF_LUI_target.Power.valueMissing:SetTextColor(tonumber(db.oUF.Target.Texts.PowerMissing.IndividualColor.r),tonumber(db.oUF.Target.Texts.PowerMissing.IndividualColor.g),tonumber(db.oUF.Target.Texts.PowerMissing.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual Target PowerMissing Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.Target.Texts.PowerMissing.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.Target.Texts.PowerMissing.IndividualColor.r, db.oUF.Target.Texts.PowerMissing.IndividualColor.g, db.oUF.Target.Texts.PowerMissing.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.Target.Texts.PowerMissing.IndividualColor.r = r
													db.oUF.Target.Texts.PowerMissing.IndividualColor.g = g
													db.oUF.Target.Texts.PowerMissing.IndividualColor.b = b
													
													oUF_LUI_target.Power.valueMissing:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
					},
				},
				Castbar = {
					name = "Castbar",
					disabled = function() return not db.oUF.Settings.Castbars end,
					type = "group",
					order = 7,
					childGroups = "tab",
					args = {
						header1 = {
							name = "Target Castbar",
							type = "header",
							order = 1,
						},
						General = {
							name = "General",
							type = "group",
							order = 2,
							args = {
								CastbarEnable = {
									name = "Enable",
									desc = "Wether you want to show your Target Castbar or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Castbar.Enable end,
									set = function(self,CastbarEnable)
												db.oUF.Target.Castbar.Enable = not db.oUF.Target.Castbar.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 2,
								},
								CastbarSize = {
									name = "Size/Position",
									type = "group",
									disabled = function()
										if db.oUF.Settings.Castbars and db.oUF.Target.Castbar.Enable then
											return false
										else
											return true
										end
									end,
									guiInline = true,
									order = 3,
									args = {
										CastbarHeight = {
											name = "Height",
											desc = "Castbar Height.\n\nDefault: 30",
											type = "input",
											get = function() return db.oUF.Target.Castbar.Height end,
											set = function(self,CastbarHeight)
														if CastbarHeight == nil or CastbarHeight == "" then
															CastbarHeight = "0"
														end
														db.oUF.Target.Castbar.Height = CastbarHeight
														oUF_LUI_target.Castbar:SetHeight(CastbarHeight)
													end,
											order = 1,
										},
										CastbarWidth = {
											name = "Width",
											desc = "Castbar Width.\n\nDefault: 360",
											type = "input",
											get = function() return db.oUF.Target.Castbar.Width end,
											set = function(self,CastbarWidth)
														if CastbarWidth == nil or CastbarWidth == "" then
															CastbarWidth = "0"
														end
														db.oUF.Target.Castbar.Width = CastbarWidth
														oUF_LUI_target.Castbar:SetWidth(CastbarWidth)
													end,
											order = 2,
										},
										CastbarX = {
											name = "X Value",
											desc = "X Value for your Castbar.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: 20",
											type = "input",
											get = function() return db.oUF.Target.Castbar.X end,
											set = function(self,CastbarX)
														if CastbarX == nil or CastbarX == "" then
															CastbarX = "0"
														end
														db.oUF.Target.Castbar.X = CastbarX
														oUF_LUI_target.Castbar:SetPoint("BOTTOM", UIParent, "BOTTOM", CastbarX, db.oUF.Target.Castbar.Y)
													end,
											order = 3,
										},
										CastbarY = {
											name = "Y Value",
											desc = "Y Value for your Castbar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: 205",
											type = "input",
											get = function() return db.oUF.Target.Castbar.Y end,
											set = function(self,CastbarY)
														if CastbarY == nil or CastbarY == "" then
															CastbarY = "0"
														end
														db.oUF.Target.Castbar.Y = CastbarY
														oUF_LUI_target.Castbar:SetPoint("BOTTOM", UIParent, "BOTTOM", db.oUF.Target.Castbar.X, CastbarY)
													end,
											order = 4,
										},
									},
								},
							},
						},
						CastbarColors = {
							name = "Colors",
							type = "group",
							disabled = function()
								if db.oUF.Settings.Castbars and db.oUF.Target.Castbar.Enable then
									return false
								else
									return true
								end
							end,
							order = 3,
							args = {
								Colors = {
									name = "Castbar Colors",
									type = "group",
									guiInline = true,
									order = 1,
									args = {
										CBColorEnable = {
											name = "Individual Castbar Color",
											desc = "Wether you want an individual Castbar Color or not.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.Target.Castbar.IndividualColor end,
											set = function(self,CBColorEnable)
														db.oUF.Target.Castbar.IndividualColor = not db.oUF.Target.Castbar.IndividualColor
														StaticPopup_Show("RELOAD_UI")
													end,
											order = 1,
										},
										CBColor = {
											name = "Castbar Color",
											desc = "Choose an individual Castbar-Color.\n\nDefault: "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Bar.r.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Bar.r.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Bar.b.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Bar.a,
											type = "color",
											width = "full",
											disabled = function() return not db.oUF.Target.Castbar.IndividualColor end,
											hasAlpha = true,
											get = function() return db.oUF.Target.Castbar.Colors.Bar.r, db.oUF.Target.Castbar.Colors.Bar.g, db.oUF.Target.Castbar.Colors.Bar.b, db.oUF.Target.Castbar.Colors.Bar.a end,
											set = function(_,r,g,b,a)
													db.oUF.Target.Castbar.Colors.Bar.r = r
													db.oUF.Target.Castbar.Colors.Bar.g = g
													db.oUF.Target.Castbar.Colors.Bar.b = b
													db.oUF.Target.Castbar.Colors.Bar.a = a
													oUF_LUI_target.Castbar:SetStatusBarColor(r,g,b,a)
												end,
											order = 2,
										},
										CBBGColor = {
											name = "Castbar BG Color",
											desc = "Choose an individual Castbar-Background-Color.\n\nDefault: "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Background.r.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Background.g.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Background.b.." / "..1-LUI.defaults.profile.oUF.Target.Castbar.Colors.Background.a,
											type = "color",
											width = "full",
											disabled = function() return not db.oUF.Target.Castbar.IndividualColor end,
											hasAlpha = true,
											get = function() return db.oUF.Target.Castbar.Colors.Background.r, db.oUF.Target.Castbar.Colors.Background.g, db.oUF.Target.Castbar.Colors.Background.b, db.oUF.Target.Castbar.Colors.Background.a end,
											set = function(_,r,g,b,a)
													db.oUF.Target.Castbar.Colors.Background.r = r
													db.oUF.Target.Castbar.Colors.Background.g = g
													db.oUF.Target.Castbar.Colors.Background.b = b
													db.oUF.Target.Castbar.Colors.Background.a = a
													oUF_LUI_target.Castbar.bg:SetVertexColor(r,g,b,a)
												end,
											order = 3,
										},
										CBBorderColor = {
											name = "Castbar Border Color",
											desc = "Choose an individual Castbar-Border-Color.\n\nDefaults: "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Border.r.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Border.g.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Border.b.." / "..1-LUI.defaults.profile.oUF.Target.Castbar.Colors.Border.a,
											type = "color",
											width = "full",
											disabled = function() return not db.oUF.Target.Castbar.IndividualColor end,
											hasAlpha = true,
											get = function() return db.oUF.Target.Castbar.Colors.Border.r, db.oUF.Target.Castbar.Colors.Border.g, db.oUF.Target.Castbar.Colors.Border.b, db.oUF.Target.Castbar.Colors.Border.a end,
											set = function(_,r,g,b,a)
													db.oUF.Target.Castbar.Colors.Border.r = r
													db.oUF.Target.Castbar.Colors.Border.g = g
													db.oUF.Target.Castbar.Colors.Border.b = b
													db.oUF.Target.Castbar.Colors.Border.a = a
													oUF_LUI_target.CastbarBackdrop:SetBackdropBorderColor(r,g,b,a)
												end,
											order = 4, 
										},
										CBNameColor = {
											name = "Castbar Name Text Color",
											desc = "Choose an individual Castbar Name Text Color.\n\nDefaults: "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Name.r.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Name.g.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Name.b,
											type = "color",
											width = "full",
											disabled = function() return not db.oUF.Target.Castbar.IndividualColor end,
											hasAlpha = false,
											get = function() return db.oUF.Target.Castbar.Colors.Name.r, db.oUF.Target.Castbar.Colors.Name.g, db.oUF.Target.Castbar.Colors.Name.b end,
											set = function(_,r,g,b)
													db.oUF.Target.Castbar.Colors.Name.r = r
													db.oUF.Target.Castbar.Colors.Name.g = g
													db.oUF.Target.Castbar.Colors.Name.b = b
													oUF_LUI_target.Castbar.Text:SetTextColor(r, g, b)
												end,
											order = 5, 
										},
										CBTimeColor = {
											name = "Castbar Time Text Color",
											desc = "Choose an individual Castbar Time Text Color.\n\nDefaults: "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Time.r.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Time.g.." / "..LUI.defaults.profile.oUF.Target.Castbar.Colors.Time.b,
											type = "color",
											width = "full",
											disabled = function() return not db.oUF.Target.Castbar.IndividualColor end,
											hasAlpha = false,
											get = function() return db.oUF.Target.Castbar.Colors.Time.r, db.oUF.Target.Castbar.Colors.Time.g, db.oUF.Target.Castbar.Colors.Time.b end,
											set = function(_,r,g,b)
													db.oUF.Target.Castbar.Colors.Time.r = r
													db.oUF.Target.Castbar.Colors.Time.g = g
													db.oUF.Target.Castbar.Colors.Time.b = b
													oUF_LUI_target.Castbar.Time:SetTextColor(r, g, b)
												end,
											order = 6, 
										},
									},
								},
								CastbarTexture = {
									name = "Castbar Textures",
									type = "group",
									guiInline = true,
									order = 2,
									args = {
										CBTexture = {
											name = "Bar Texture",
											desc = "Choose your Castbar Texture!\nDefault: LUI_Gradient",
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function() return db.oUF.Target.Castbar.Texture end,
											set = function(self, CBTexture)
													db.oUF.Target.Castbar.Texture = CBTexture
													oUF_LUI_target.Castbar:SetStatusBarTexture(LSM:Fetch("statusbar", CBTexture))
												end,
											order = 1,
										},
										CBTextureBG = {
											name = "Background Texture",
											desc = "Choose your Castbar Background Texture!\nDefault: LUI_Minimalist",
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function() return db.oUF.Target.Castbar.TextureBG end,
											set = function(self, CBTextureBG)
													db.oUF.Target.Castbar.TextureBG = CBTextureBG
													oUF_LUI_target.Castbar.bg:SetTexture(LSM:Fetch("statusbar", CBTextureBG))
												end,
											order = 2,
										},
									},
								},
							},
						},
						Texts = {
							name = "Texts",
							type = "group",
							order = 4,
							args = {
								CastbarText = {
									name = "Castbar Text",
									type = "group",
									guiInline = true,
									disabled = function()
										if db.oUF.Settings.Castbars and db.oUF.Target.Castbar.Enable then
											return false
										else
											return true
										end
									end,
									order = 7,
									args = {
										CastbarNameFont = {
											name = "Name Font",
											desc = "Choose your Font for your Castbar Name Text!\n\nDefault: vibrocen",
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.Target.Castbar.Text.Name.Font end,
											set = function(self, CastbarNameFont)
													db.oUF.Target.Castbar.Text.Name.Font = CastbarNameFont
													oUF_LUI_target.Castbar.Text:SetFont(LSM:Fetch("font", CastbarNameFont),db.oUF.Target.Castbar.Text.Name.Size)
												end,
											order = 1,
										},
										CastbarNameFontsize = {
											name = "Size",
											desc = "Choose your Castbar Name Text Fontsize!\n Default: 14",
											type = "range",
											min = 10,
											max = 40,
											step = 1,
											get = function() return db.oUF.Target.Castbar.Text.Name.Size end,
											set = function(_, CastbarNameFontsize) 
													db.oUF.Target.Castbar.Text.Name.Size = CastbarNameFontsize
													oUF_LUI_target.Castbar.Text:SetFont(LSM:Fetch("font", db.oUF.Target.Castbar.Text.Name.Font),CastbarNameFontsize)
												end,
											order = 2,
										},
										CastbarTimeFont = {
											name = "Time Font",
											desc = "Choose your Font for your Castbar Time Text!\n\nDefault: vibrocen",
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function()
													return db.oUF.Target.Castbar.Text.Time.Font
												end,
											set = function(self, CastbarTimeFont)
													db.oUF.Target.Castbar.Text.Time.Font = CastbarTimeFont
													oUF_LUI_target.Castbar.Time:SetFont(LSM:Fetch("font", CastbarTimeFont),db.oUF.Target.Castbar.Text.Time.Size)
												end,
											order = 3,
										},
										CastbarTimeFontsize = {
											name = "Size",
											desc = "Choose your Castbar Time Text Fontsize!\n Default: 14",
											type = "range",
											min = 10,
											max = 40,
											step = 1,
											get = function() return db.oUF.Target.Castbar.Text.Time.Size end,
											set = function(_, CastbarTimeFontsize) 
													db.oUF.Target.Castbar.Text.Time.Size = CastbarTimeFontsize
													oUF_LUI_target.Castbar.Time:SetFont(LSM:Fetch("font", db.oUF.Target.Castbar.Text.Time.Font),CastbarTimeFontsize)
												end,
											order = 4,
										},
										CastbarName = {
											name = "Show Name Text",
											desc = "Wether you want to show your Castbar Name Text or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.Target.Castbar.Text.Name.Enable end,
											set = function(self,CastbarName)
														db.oUF.Target.Castbar.Text.Name.Enable = not db.oUF.Target.Castbar.Text.Name.Enable
														if CastbarName == true then
															oUF_LUI_target.Castbar.Text:Show()
														else
															oUF_LUI_target.Castbar.Text:Hide()
														end
													end,
											order = 5,
										},
										CastbarTime = {
											name = "Show Time Text",
											desc = "Wether you want to show your Castbar Time Text or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.Target.Castbar.Text.Time.Enable end,
											set = function(self,CastbarTime)
														db.oUF.Target.Castbar.Text.Time.Enable = not db.oUF.Target.Castbar.Text.Time.Enable
														if CastbarTime == true then
															oUF_LUI_target.Castbar.Time:Show()
														else
															oUF_LUI_target.Castbar.Time:Hide()
														end
													end,
											order = 6,
										},
										CastbarTimeMax = {
											name = "Show Cast Time",
											desc = "Wether you want to show your Castbar Cast Time or not.",
											type = "toggle",
											width = "full",
											disabled = function()
												if db.oUF.Settings.Castbars then
													if db.oUF.Target.Castbar.Enable then
														if db.oUF.Target.Castbar.Text.Time.Enable then
															return false
														else
															return true
														end
													else
														return true
													end
												else
													return true
												end
											end,
											get = function() return db.oUF.Target.Castbar.Text.Time.ShowMax end,
											set = function(self,CastbarTimeMax)
														db.oUF.Target.Castbar.Text.Time.ShowMax = not db.oUF.Target.Castbar.Text.Time.ShowMax
														StaticPopup_Show("RELOAD_UI")
													end,
											order = 7,
										},
										CastbarNameOffsetX = {
											name = "Name Text X Offset",
											desc = "Castbar Name Text X Offset.\nDefault: 5",
											disabled = function()
												if db.oUF.Settings.Castbars then
													if db.oUF.Target.Castbar.Enable then
														if db.oUF.Target.Castbar.Text.Name.Enable then
															return false
														else
															return true
														end
													else
														return true
													end
												else
													return true
												end
											end,
											type = "input",
											get = function() return db.oUF.Target.Castbar.Text.Name.OffsetX end,
											set = function(self,CastbarNameOffsetX)
														if CastbarNameOffsetX == nil or CastbarNameOffsetX == "" then
															CastbarNameOffsetX = "0"
														end
														db.oUF.Target.Castbar.Text.Name.OffsetX = CastbarNameOffsetX
														oUF_LUI_target.Castbar.Text:SetPoint("LEFT", tonumber(CastbarNameOffsetX), tonumber(db.oUF.Target.Castbar.Text.Name.OffsetY))
													end,
											order = 8,
										},
										CastbarNameOffsetY = {
											name = "Name Text Y Offset",
											desc = "Castbar Name Text Y Offset.\nDefault: 0",
											disabled = function()
												if db.oUF.Settings.Castbars then
													if db.oUF.Target.Castbar.Enable then
														if db.oUF.Target.Castbar.Text.Name.Enable then
															return false
														else
															return true
														end
													else
														return true
													end
												else
													return true
												end
											end,
											type = "input",
											get = function() return db.oUF.Target.Castbar.Text.Name.OffsetY end,
											set = function(self,CastbarNameOffsetY)
														if CastbarNameOffsetY == nil or CastbarNameOffsetY == "" then
															CastbarNameOffsetY = "0"
														end
														db.oUF.Target.Castbar.Text.Name.OffsetY = CastbarNameOffsetY
														oUF_LUI_target.Castbar.Text:SetPoint("LEFT", tonumber(db.oUF.Target.Castbar.Text.Name.OffsetX), tonumber(CastbarNameOffsetY))
													end,
											order = 9,
										},
										CastbarTimeOffsetX = {
											name = "Time Text X Offset",
											desc = "Castbar Time Text X Offset.\nDefault: -5",
											disabled = function()
												if db.oUF.Settings.Castbars then
													if db.oUF.Target.Castbar.Enable then
														if db.oUF.Target.Castbar.Text.Time.Enable then
															return false
														else
															return true
														end
													else
														return true
													end
												else
													return true
												end
											end,
											type = "input",
											get = function() return db.oUF.Target.Castbar.Text.Time.OffsetX end,
											set = function(self,CastbarTimeOffsetX)
														if CastbarTimeOffsetX == nil or CastbarTimeOffsetX == "" then
															CastbarTimeOffsetX = "0"
														end
														db.oUF.Target.Castbar.Text.Time.OffsetX = CastbarTimeOffsetX
														oUF_LUI_target.Castbar.Time:SetPoint("RIGHT", tonumber(CastbarTimeOffsetX), tonumber(db.oUF.Target.Castbar.Text.Time.OffsetY))
													end,
											order = 10,
										},
										CastbarTimeOffsetY = {
											name = "Time Text Y Offset",
											desc = "Castbar Time Text Y Offset.\nDefault: 0",
											disabled = function()
												if db.oUF.Settings.Castbars then
													if db.oUF.Target.Castbar.Enable then
														if db.oUF.Target.Castbar.Text.Time.Enable then
															return false
														else
															return true
														end
													else
														return true
													end
												else
													return true
												end
											end,
											type = "input",
											get = function() return db.oUF.Target.Castbar.Text.Time.OffsetY end,
											set = function(self,CastbarTimeOffsetY)
														if CastbarTimeOffsetY == nil or CastbarTimeOffsetY == "" then
															CastbarTimeOffsetY = "0"
														end
														db.oUF.Target.Castbar.Text.Time.OffsetY = CastbarTimeOffsetY
														oUF_LUI_target.Castbar.Time:SetPoint("RIGHT", tonumber(db.oUF.Target.Castbar.Text.Time.OffsetX), tonumber(CastbarTimeOffsetY))
													end,
											order = 11,
										},
									},
								},
							},
						},
						Border = {
							name = "Border",
							type = "group",
							order = 5,
							args = {
								CastbarBorder = {
									name = "Castbar Border",
									type = "group",
									disabled = function()
										if db.oUF.Settings.Castbars and db.oUF.Target.Castbar.Enable then
											return false
										else
											return true
										end
									end,
									guiInline = true,
									order = 6,
									args = {
										CBBorder = {
											name = "Border Texture",
											desc = "Choose your Border Texture!\nDefault: glow",
											type = "select",
											dialogControl = "LSM30_Border",
											values = widgetLists.border,
											get = function() return db.oUF.Target.Castbar.Border.Texture end,
											set = function(self, CBBorder)
													db.oUF.Target.Castbar.Border.Texture = CBBorder
													oUF_LUI_target.CastbarBackdrop:SetBackdrop({
													edgeFile = LSM:Fetch("border", CBBorder), edgeSize = db.oUF.Target.Castbar.Border.Thickness,
														insets = {left = db.oUF.Target.Castbar.Border.Inset.left, right = db.oUF.Target.Castbar.Border.Inset.right, top = db.oUF.Target.Castbar.Border.Inset.top, bottom = db.oUF.Target.Castbar.Border.Inset.bottom}
													})
													oUF_LUI_target.CastbarBackdrop:SetBackdropColor(0, 0, 0, 0)
						oUF_LUI_target.CastbarBackdrop:SetBackdropBorderColor(db.oUF.Target.Castbar.Colors.Border.r,db.oUF.Target.Castbar.Colors.Border.g,db.oUF.Target.Castbar.Colors.Border.b,db.oUF.Target.Castbar.Colors.Border.a)
												end,
											order = 1,
										},
										CBBorderThickness = {
											name = "Edge Size",
											desc = "Value for your Castbar Border Edge Size\nDefault: 4",
											type = "input",
											width = "half",
											get = function() return db.oUF.Target.Castbar.Border.Thickness end,
											set = function(self,CBBorderThickness)
														if CBBorderThickness == nil or CBBorderThickness == "" then
															CBBorderThickness = "0"
														end
														db.oUF.Target.Castbar.Border.Thickness = CBBorderThickness
														oUF_LUI_target.CastbarBackdrop:SetBackdrop({
													edgeFile = LSM:Fetch("border", db.oUF.Target.Castbar.Border.Texture), edgeSize = CBBorderThickness,
														insets = {left = db.oUF.Target.Castbar.Border.Inset.left, right = db.oUF.Target.Castbar.Border.Inset.right, top = db.oUF.Target.Castbar.Border.Inset.top, bottom = db.oUF.Target.Castbar.Border.Inset.bottom}
													})
													oUF_LUI_target.CastbarBackdrop:SetBackdropColor(0, 0, 0, 0)
						oUF_LUI_target.CastbarBackdrop:SetBackdropBorderColor(db.oUF.Target.Castbar.Colors.Border.r,db.oUF.Target.Castbar.Colors.Border.g,db.oUF.Target.Castbar.Colors.Border.b,db.oUF.Target.Castbar.Colors.Border.a)
													end,
											order = 2,
										},
										empty235 = {
											name = "   ",
											type = "description",
											order = 3,
										},
										CBBorderInsetLeft = {
											name = "Left",
											desc = "Value for the Left Border Inset\nDefault: 3",
											type = "input",
											width = "half",
											get = function() return db.oUF.Target.Castbar.Border.Inset.left end,
											set = function(self,CBBorderInsetLeft)
														if CBBorderInsetLeft == nil or CBBorderInsetLeft == "" then
															CBBorderInsetLeft = "0"
														end
														db.oUF.Target.Castbar.Border.Inset.left = CBBorderInsetLeft
														oUF_LUI_target.CastbarBackdrop:SetBackdrop({
													edgeFile = LSM:Fetch("border", db.oUF.Target.Castbar.Border.Texture), edgeSize = db.oUF.Target.Castbar.Border.Thickness,
														insets = {left = CBBorderInsetLeft, right = db.oUF.Target.Castbar.Border.Inset.right, top = db.oUF.Target.Castbar.Border.Inset.top, bottom = db.oUF.Target.Castbar.Border.Inset.bottom}
													})
													oUF_LUI_target.CastbarBackdrop:SetBackdropColor(0, 0, 0, 0)
						oUF_LUI_target.CastbarBackdrop:SetBackdropBorderColor(db.oUF.Target.Castbar.Colors.Border.r,db.oUF.Target.Castbar.Colors.Border.g,db.oUF.Target.Castbar.Colors.Border.b,db.oUF.Target.Castbar.Colors.Border.a)
													end,
											order = 4,
										},
										CBBorderInsetRight = {
											name = "Right",
											desc = "Value for the Right Border Inset\nDefault: 3",
											type = "input",
											width = "half",
											get = function() return db.oUF.Target.Castbar.Border.Inset.right end,
											set = function(self,CBBorderInsetRight)
														if CBBorderInsetRight == nil or CBBorderInsetRight == "" then
															CBBorderInsetRight = "0"
														end
														db.oUF.Target.Castbar.Border.Inset.right = CBBorderInsetRight
														oUF_LUI_target.CastbarBackdrop:SetBackdrop({
													edgeFile = LSM:Fetch("border", db.oUF.Target.Castbar.Border.Texture), edgeSize = db.oUF.Target.Castbar.Border.Thickness,
														insets = {left = db.oUF.Target.Castbar.Border.Inset.left, right = CBBorderInsetRight, top = db.oUF.Target.Castbar.Border.Inset.top, bottom = db.oUF.Target.Castbar.Border.Inset.bottom}
													})
													oUF_LUI_target.CastbarBackdrop:SetBackdropColor(0, 0, 0, 0)
						oUF_LUI_target.CastbarBackdrop:SetBackdropBorderColor(db.oUF.Target.Castbar.Colors.Border.r,db.oUF.Target.Castbar.Colors.Border.g,db.oUF.Target.Castbar.Colors.Border.b,db.oUF.Target.Castbar.Colors.Border.a)
													end,
											order = 5,
										},
										CBBorderInsetTop = {
											name = "Top",
											desc = "Value for the Top Border Inset\nDefault: 3",
											type = "input",
											width = "half",
											get = function() return db.oUF.Target.Castbar.Border.Inset.top end,
											set = function(self,CBBorderInsetTop)
														if CBBorderInsetTop == nil or CBBorderInsetTop == "" then
															CBBorderInsetTop = "0"
														end
														db.oUF.Target.Castbar.Border.Inset.top = CBBorderInsetTop
														oUF_LUI_target.CastbarBackdrop:SetBackdrop({
													edgeFile = LSM:Fetch("border", db.oUF.Target.Castbar.Border.Texture), edgeSize = db.oUF.Target.Castbar.Border.Thickness,
														insets = {left = db.oUF.Target.Castbar.Border.Inset.left, right = db.oUF.Target.Castbar.Border.Inset.right, top = CBBorderInsetTop, bottom = db.oUF.Target.Castbar.Border.Inset.bottom}
													})
													oUF_LUI_target.CastbarBackdrop:SetBackdropColor(0, 0, 0, 0)
						oUF_LUI_target.CastbarBackdrop:SetBackdropBorderColor(db.oUF.Target.Castbar.Colors.Border.r,db.oUF.Target.Castbar.Colors.Border.g,db.oUF.Target.Castbar.Colors.Border.b,db.oUF.Target.Castbar.Colors.Border.a)
													end,
											order = 6,
										},
										CBBorderInsetBottom = {
											name = "Bottom",
											desc = "Value for the Bottom Border Inset\nDefault: 3",
											type = "input",
											width = "half",
											get = function() return db.oUF.Target.Castbar.Border.Inset.bottom end,
											set = function(self,CBBorderInsetBottom)
														if CBBorderInsetBottom == nil or CBBorderInsetBottom == "" then
															CBBorderInsetBottom = "0"
														end
														db.oUF.Target.Castbar.Border.Inset.bottom = CBBorderInsetBottom
														oUF_LUI_target.CastbarBackdrop:SetBackdrop({
													edgeFile = LSM:Fetch("border", db.oUF.Target.Castbar.Border.Texture), edgeSize = db.oUF.Target.Castbar.Border.Thickness,
														insets = {left = db.oUF.Target.Castbar.Border.Inset.left, right = db.oUF.Target.Castbar.Border.Inset.right, top = db.oUF.Target.Castbar.Border.Inset.top, bottom = CBBorderInsetBottom}
													})
													oUF_LUI_target.CastbarBackdrop:SetBackdropColor(0, 0, 0, 0)
						oUF_LUI_target.CastbarBackdrop:SetBackdropBorderColor(db.oUF.Target.Castbar.Colors.Border.r,db.oUF.Target.Castbar.Colors.Border.g,db.oUF.Target.Castbar.Colors.Border.b,db.oUF.Target.Castbar.Colors.Border.a)
													end,
											order = 7,
										},
									},
								},
							},
						},
					},
				},
				Aura = {
					name = "Aura",
					type = "group",
					childGroups = "tab",
					order = 8,
					args = {
						TargetBuffs = {
							name = "Buffs",
							type = "group",
							order = 2,
							args = {
								TargetBuffsEnable = {
									name = "Enable Target Buffs",
									desc = "Wether you want to show Target Buffs or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Aura.buffs_enable end,
									set = function(self,TargetBuffsEnable)
												db.oUF.Target.Aura.buffs_enable = not db.oUF.Target.Aura.buffs_enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 0,
								},
								TargetBuffsAuratimer = {
									name = "Enable Auratimer",
									desc = "Wether you want to show Auratimers or not.",
									type = "toggle",
									disabled = function() return not db.oUF.Target.Aura.buffs_enable end,
									get = function() return db.oUF.Target.Aura.buffs_auratimer end,
									set = function(self,TargetBuffsAuratimer)
												db.oUF.Target.Aura.buffs_auratimer = not db.oUF.Target.Aura.buffs_auratimer
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								TargetBuffsPlayerBuffsOnly = {
									name = "Player Buffs Only",
									desc = "Wether you want to show only your Buffs on Target or not.",
									type = "toggle",
									disabled = function() return not db.oUF.Target.Aura.buffs_enable end,
									get = function() return db.oUF.Target.Aura.buffs_playeronly end,
									set = function(self,TargetBuffsPlayerBuffsOnly)
												db.oUF.Target.Aura.buffs_playeronly = not db.oUF.Target.Aura.buffs_playeronly
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 2,
								},
								TargetBuffsNum = {
									name = "Amount",
									desc = "Amount of your Target Buffs.\nDefault: 36",
									type = "input",
									disabled = function() return not db.oUF.Target.Aura.buffs_enable end,
									get = function() return db.oUF.Target.Aura.buffs_num end,
									set = function(self,TargetBuffsNum)
												if TargetBuffsNum == nil or TargetBuffsNum == "" then
													TargetBuffsNum = "0"
												end
												db.oUF.Target.Aura.buffs_num = TargetBuffsNum
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 3,
								},
								TargetBuffsSize = {
									name = "Size",
									desc = "Size for your Target Buffs.\nDefault: 26",
									type = "input",
									disabled = function() return not db.oUF.Target.Aura.buffs_enable end,
									get = function() return db.oUF.Target.Aura.buffs_size end,
									set = function(self,TargetBuffsSize)
												if TargetBuffsSize == nil or TargetBuffsSize == "" then
													TargetBuffsSize = "0"
												end
												db.oUF.Target.Aura.buffs_size = TargetBuffsSize
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 4,
								},
								TargetBuffsSpacing = {
									name = "Spacing",
									desc = "Spacing between your Target Buffs.\nDefault: 2",
									type = "input",
									disabled = function() return not db.oUF.Target.Aura.buffs_enable end,
									get = function() return db.oUF.Target.Aura.buffs_spacing end,
									set = function(self,TargetBuffsSpacing)
												if TargetBuffsSpacing == nil or TargetBuffsSpacing == "" then
													TargetBuffsSpacing = "0"
												end
												db.oUF.Target.Aura.buffs_spacing = TargetBuffsSpacing
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 5,
								},
								TargetBuffsX = {
									name = "X Value",
									desc = "X Value for your Target Buffs.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: -0.5",
									type = "input",
									disabled = function() return not db.oUF.Target.Aura.buffs_enable end,
									get = function() return db.oUF.Target.Aura.buffsX end,
									set = function(self,TargetBuffsX)
												if TargetBuffsX == nil or TargetBuffsX == "" then
													TargetBuffsX = "0"
												end
												db.oUF.Target.Aura.buffsX = TargetBuffsX
												oUF_LUI_target.Buffs:SetPoint(db.oUF.Target.Aura.buffs_initialAnchor, oUF_LUI_target, db.oUF.Target.Aura.buffs_initialAnchor, TargetBuffsX, db.oUF.Target.Aura.buffsY)
											end,
									order = 6,
								},
								TargetBuffsY = {
									name = "Y Value",
									desc = "Y Value for your Target Buffs.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: 32",
									type = "input",
									disabled = function() return not db.oUF.Target.Aura.buffs_enable end,
									get = function() return db.oUF.Target.Aura.buffsY end,
									set = function(self,TargetBuffsY)
												if TargetBuffsY == nil or TargetBuffsY == "" then
													TargetBuffsY = "0"
												end
												db.oUF.Target.Aura.buffsY = TargetBuffsY
												oUF_LUI_target.Buffs:SetPoint(db.oUF.Target.Aura.buffs_initialAnchor, oUF_LUI_target, db.oUF.Target.Aura.buffs_initialAnchor, db.oUF.Target.Aura.buffsX, TargetBuffsY)
											end,
									order = 7,
								},
								TargetBuffsGrowthY = {
									name = "Growth Y",
									desc = "Choose the growth Y direction for your Target Buffs.\nDefault: UP",
									type = "select",
									disabled = function() return not db.oUF.Target.Aura.buffs_enable end,
									values = growthY,
									get = function()
											for k, v in pairs(growthY) do
												if db.oUF.Target.Aura.buffs_growthY == v then
													return k
												end
											end
										end,
									set = function(self, TargetBuffsGrowthY)
											db.oUF.Target.Aura.buffs_growthY = growthY[TargetBuffsGrowthY]
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 8,
								},
								TargetBuffsGrowthX = {
									name = "Growth X",
									desc = "Choose the growth X direction for your Target Buffs.\nDefault: RIGHT",
									type = "select",
									disabled = function() return not db.oUF.Target.Aura.buffs_enable end,
									values = growthX,
									get = function()
											for k, v in pairs(growthX) do
												if db.oUF.Target.Aura.buffs_growthX == v then
													return k
												end
											end
										end,
									set = function(self, TargetBuffsGrowthX)
											db.oUF.Target.Aura.buffs_growthX = growthX[TargetBuffsGrowthX]
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 9,
								},
								TargetBuffsAnchor = {
									name = "Initial Anchor",
									desc = "Choose the initinal Anchor for your Target Buffs.\nDefault: TOPLEFT",
									type = "select",
									disabled = function() return not db.oUF.Target.Aura.buffs_enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.Target.Aura.buffs_initialAnchor == v then
													return k
												end
											end
										end,
									set = function(self, TargetBuffsAnchor)
											db.oUF.Target.Aura.buffs_initialAnchor = positions[TargetBuffsAnchor]
											oUF_LUI_target.Buffs:SetPoint(positions[TargetBuffsAnchor], oUF_LUI_target, positions[TargetBuffsAnchor], db.oUF.Target.Aura.buffsX, db.oUF.Target.Aura.buffsY)
										end,
									order = 10,
								},
							},
						},
						TargetDebuffs = {
							name = "Debuffs",
							type = "group",
							order = 3,
							args = {
								TargetDebuffsEnable = {
									name = "Enable Target Debuffs",
									desc = "Wether you want to show Target Debuffs or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Aura.debuffs_enable end,
									set = function(self,TargetDebuffsEnable)
												db.oUF.Target.Aura.debuffs_enable = not db.oUF.Target.Aura.debuffs_enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 0,
								},
								TargetDebuffsAuratimer = {
									name = "Enable Auratimer",
									desc = "Wether you want to show Auratimers or not.\nDefault: Off",
									type = "toggle",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									get = function() return db.oUF.Target.Aura.debuffs_auratimer end,
									set = function(self,TargetDebuffsAuratimer)
												db.oUF.Target.Aura.debuffs_auratimer = not db.oUF.Target.Aura.debuffs_auratimer
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								TargetDebuffsPlayerDebuffsOnly = {
									name = "Player Debuffs Only",
									desc = "Wether you want to show only your Debuffs on Target or not.",
									type = "toggle",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									get = function() return db.oUF.Target.Aura.debuffs_playeronly end,
									set = function(self,TargetDebuffsPlayerDebuffsOnly)
												db.oUF.Target.Aura.debuffs_playeronly = not db.oUF.Target.Aura.debuffs_playeronly
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 2,
								},
								TargetDebuffsColorByType = {
									name = "Color by Type",
									desc = "Wether you want to color Target Debuffs by Type or not.",
									type = "toggle",
									width = "full",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									get = function() return db.oUF.Target.Aura.debuffs_colorbytype end,
									set = function(self,TargetDebuffsColorByType)
												db.oUF.Target.Aura.debuffs_colorbytype = not db.oUF.Target.Aura.debuffs_colorbytype
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 3,
								},
								TargetDebuffsNum = {
									name = "Amount",
									desc = "Amount of your Target Debuffs.\nDefault: 36",
									type = "input",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									get = function() return db.oUF.Target.Aura.debuffs_num end,
									set = function(self,TargetDebuffsNum)
												if TargetDebuffsNum == nil or TargetDebuffsNum == "" then
													TargetDebuffsNum = "0"
												end
												db.oUF.Target.Aura.debuffs_num = TargetDebuffsNum
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 4,
								},
								TargetDebuffsSize = {
									name = "Size",
									desc = "Size for your Target Debuffs.\nDefault: 26",
									type = "input",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									get = function() return db.oUF.Target.Aura.debuffs_size end,
									set = function(self,TargetDebuffsSize)
												if TargetDebuffsSize == nil or TargetDebuffsSize == "" then
													TargetDebuffsSize = "0"
												end
												db.oUF.Target.Aura.debuffs_size = TargetDebuffsSize
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 5,
								},
								TargetDebuffsSpacing = {
									name = "Spacing",
									desc = "Spacing between your Target Debuffs.\nDefault: 2",
									type = "input",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									get = function() return db.oUF.Target.Aura.debuffs_spacing end,
									set = function(self,TargetDebuffsSpacing)
												if TargetDebuffsSpacing == nil or TargetDebuffsSpacing == "" then
													TargetDebuffsSpacing = "0"
												end
												db.oUF.Target.Aura.debuffs_spacing = TargetDebuffsSpacing
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 6,
								},
								TargetDebuffsX = {
									name = "X Value",
									desc = "X Value for your Target Debuffs.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: -0.5",
									type = "input",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									get = function() return db.oUF.Target.Aura.debuffsX end,
									set = function(self,TargetDebuffsX)
												if TargetDebuffsX == nil or TargetDebuffsX == "" then
													TargetDebuffsX = "0"
												end
												db.oUF.Target.Aura.debuffsX = TargetDebuffsX
												oUF_LUI_target.Debuffs:SetPoint(db.oUF.Target.Aura.debuffs_initialAnchor, oUF_LUI_target, db.oUF.Target.Aura.debuffs_initialAnchor, TargetDebuffsX, db.oUF.Target.Aura.debuffsY)
											end,
									order = 7,
								},
								TargetDebuffsY = {
									name = "Y Value",
									desc = "Y Value for your Target Debuffs.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: 60",
									type = "input",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									get = function() return db.oUF.Target.Aura.debuffsY end,
									set = function(self,TargetDebuffsY)
												if TargetDebuffsY == nil or TargetDebuffsY == "" then
													TargetDebuffsY = "0"
												end
												db.oUF.Target.Aura.debuffsY = TargetDebuffsY
												oUF_LUI_target.Debuffs:SetPoint(db.oUF.Target.Aura.debuffs_initialAnchor, oUF_LUI_target, db.oUF.Target.Aura.debuffs_initialAnchor, db.oUF.Target.Aura.debuffsX, TargetDebuffsY)
											end,
									order = 8,
								},
								TargetDebuffsGrowthY = {
									name = "Growth Y",
									desc = "Choose the growth Y direction for your Target Debuffs.\nDefault: UP",
									type = "select",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									values = growthY,
									get = function()
											for k, v in pairs(growthY) do
												if db.oUF.Target.Aura.debuffs_growthY == v then
													return k
												end
											end
										end,
									set = function(self, TargetDebuffsGrowthY)
											db.oUF.Target.Aura.debuffs_growthY = growthY[TargetDebuffsGrowthY]
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 9,
								},
								TargetDebuffsGrowthX = {
									name = "Growth X",
									desc = "Choose the growth X direction for your Target Debuffs.\nDefault: LEFT",
									type = "select",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									values = growthX,
									get = function()
											for k, v in pairs(growthX) do
												if db.oUF.Target.Aura.debuffs_growthX == v then
													return k
												end
											end
										end,
									set = function(self, TargetDebuffsGrowthX)
											db.oUF.Target.Aura.debuffs_growthX = growthX[TargetDebuffsGrowthX]
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 10,
								},
								TargetDebuffsAnchor = {
									name = "Initial Anchor",
									desc = "Choose the initinal Anchor for your Target Debuffs.\nDefault: TOPRIGHT",
									type = "select",
									disabled = function() return not db.oUF.Target.Aura.debuffs_enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.Target.Aura.debuffs_initialAnchor == v then
													return k
												end
											end
										end,
									set = function(self, TargetDebuffsAnchor)
											db.oUF.Target.Aura.debuffs_initialAnchor = positions[TargetDebuffsAnchor]
											oUF_LUI_target.Debuffs:SetPoint(positions[TargetDebuffsAnchor], oUF_LUI_target, positions[TargetDebuffsAnchor], db.oUF.Target.Aura.debuffsX, db.oUF.Target.Aura.debuffsY)
										end,
									order = 11,
								},
							},
						},
					},
				},
				Portrait = {
					name = "Portrait",
					type = "group",
					order = 9,
					args = {
						EnablePortrait = {
							name = "Enable",
							desc = "Wether you want to show the Portrait or not.",
							type = "toggle",
							width = "full",
							get = function() return db.oUF.Target.Portrait.Enable end,
							set = function(self,EnablePortrait)
										db.oUF.Target.Portrait.Enable = not db.oUF.Target.Portrait.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 1,
						},
						PortraitWidth = {
							name = "Width",
							desc = "Choose the Width for your Portrait.\nDefault: "..LUI.defaults.profile.oUF.Target.Portrait.Width,
							type = "input",
							disabled = function() return not db.oUF.Target.Portrait.Enable end,
							get = function() return db.oUF.Target.Portrait.Width end,
							set = function(self,PortraitWidth)
										if PortraitWidth == nil or PortraitWidth == "" then
											PortraitWidth = "0"
										end
										db.oUF.Target.Portrait.Width = PortraitWidth
										oUF_LUI_target.Portrait:SetWidth(tonumber(PortraitWidth))
									end,
							order = 2,
						},
						PortraitHeight = {
							name = "Height",
							desc = "Choose the Height for your Portrait.\nDefault: "..LUI.defaults.profile.oUF.Target.Portrait.Width,
							type = "input",
							disabled = function() return not db.oUF.Target.Portrait.Enable end,
							get = function() return db.oUF.Target.Portrait.Height end,
							set = function(self,PortraitHeight)
										if PortraitHeight == nil or PortraitHeight == "" then
											PortraitHeight = "0"
										end
										db.oUF.Target.Portrait.Height = PortraitHeight
										oUF_LUI_target.Portrait:SetHeight(tonumber(PortraitHeight))
									end,
							order = 3,
						},
						PortraitX = {
							name = "X Value",
							desc = "X Value for your Portrait.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Portrait.X,
							type = "input",
							disabled = function() return not db.oUF.Target.Portrait.Enable end,
							get = function() return db.oUF.Target.Portrait.X end,
							set = function(self,PortraitX)
										if PortraitX == nil or PortraitX == "" then
											PortraitX = "0"
										end
										db.oUF.Target.Portrait.X = PortraitX
										oUF_LUI_target.Portrait:SetPoint("TOPLEFT", oUF_LUI_target.Health, "TOPLEFT", PortraitX, db.oUF.Target.Portrait.Y)
									end,
							order = 4,
						},
						PortraitY = {
							name = "Y Value",
							desc = "Y Value for your Portrait.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Portrait.Y,
							type = "input",
							disabled = function() return not db.oUF.Target.Portrait.Enable end,
							get = function() return db.oUF.Target.Portrait.Y end,
							set = function(self,PortraitY)
										if PortraitY == nil or PortraitY == "" then
											PortraitY = "0"
										end
										db.oUF.Target.Portrait.Y = PortraitY
										oUF_LUI_target.Portrait:SetPoint("TOPLEFT", oUF_LUI_target.Health, "TOPLEFT", db.oUF.Target.Portrait.X, PortraitY)
									end,
							order = 5,
						},
					},
				},
				Icons = {
					name = "Icons",
					type = "group",
					order = 10,
					childGroups = "tab",
					args = {
						Lootmaster = {
							name = "Lootmaster",
							type = "group",
							order = 1,
							args = {
								LootMasterEnable = {
									name = "Enable",
									desc = "Wether you want to show the LootMaster Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Icons.Lootmaster.Enable end,
									set = function(self,LootMasterEnable)
												db.oUF.Target.Icons.Lootmaster.Enable = not db.oUF.Target.Icons.Lootmaster.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								LootMasterX = {
									name = "X Value",
									desc = "X Value for your LootMaster Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Lootmaster.X,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Lootmaster.Enable end,
									get = function() return db.oUF.Target.Icons.Lootmaster.X end,
									set = function(self,LootMasterX)
												if LootMasterX == nil or LootMasterX == "" then
													LootMasterX = "0"
												end
												db.oUF.Target.Icons.Lootmaster.X = LootMasterX
												oUF_LUI_target.MasterLooter:ClearAllPoints()
												oUF_LUI_target.MasterLooter:SetPoint(db.oUF.Target.Icons.Lootmaster.Point, oUF_LUI_target, db.oUF.Target.Icons.Lootmaster, tonumber(LootMasterX), tonumber(db.oUF.Target.Icons.Lootmaster.Y))
											end,
									order = 2,
								},
								LootMasterY = {
									name = "Y Value",
									desc = "Y Value for your LootMaster Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Lootmaster.Y,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Lootmaster.Enable end,
									get = function() return db.oUF.Target.Icons.Lootmaster.Y end,
									set = function(self,LootMasterY)
												if LootMasterY == nil or LootMasterY == "" then
													LootMasterY = "0"
												end
												db.oUF.Target.Icons.Lootmaster.Y = LootMasterY
												oUF_LUI_target.MasterLooter:ClearAllPoints()
												oUF_LUI_target.MasterLooter:SetPoint(db.oUF.Target.Icons.Lootmaster.Point, oUF_LUI_target, db.oUF.Target.Icons.Lootmaster, tonumber(db.oUF.Target.Icons.Lootmaster.X), tonumber(LootMasterY))
											end,
									order = 3,
								},
								LootMasterPoint = {
									name = "Position",
									desc = "Choose the Position for your LootMaster Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Lootmaster.Point,
									type = "select",
									disabled = function() return not db.oUF.Target.Icons.Lootmaster.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.Target.Icons.Lootmaster.Point == v then
													return k
												end
											end
										end,
									set = function(self, LootMasterPoint)
											db.oUF.Target.Icons.Lootmaster.Point = positions[LootMasterPoint]
											oUF_LUI_target.MasterLooter:ClearAllPoints()
											oUF_LUI_target.MasterLooter:SetPoint(db.oUF.Target.Icons.Lootmaster.Point, oUF_LUI_target, db.oUF.Target.Icons.Lootmaster.Point, tonumber(db.oUF.Target.Icons.Lootmaster.X), tonumber(db.oUF.Target.Icons.Lootmaster.X))
										end,
									order = 4,
								},
								LootMasterSize = {
									name = "Size",
									desc = "Choose a size for your LootMaster Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Lootmaster.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.Target.Icons.Lootmaster.Enable end,
									get = function() return db.oUF.Target.Icons.Lootmaster.Size end,
									set = function(_, LootMasterSize) 
											db.oUF.Target.Icons.Lootmaster.Size = LootMasterSize
											oUF_LUI_target.MasterLooter:SetHeight(LootMasterSize)
											oUF_LUI_target.MasterLooter:SetWidth(LootMasterSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.Target.Icons.Lootmaster.Enable end,
									desc = "Toggles the LootMaster Icon",
									type = 'execute',
									func = function() if oUF_LUI_target.MasterLooter:IsShown() then oUF_LUI_target.MasterLooter:Hide() else oUF_LUI_target.MasterLooter:Show() end end
								},
							},
						},
						Leader = {
							name = "Leader",
							type = "group",
							order = 2,
							args = {
								LeaderEnable = {
									name = "Enable",
									desc = "Wether you want to show the Leader Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Icons.Leader.Enable end,
									set = function(self,LeaderEnable)
												db.oUF.Target.Icons.Leader.Enable = not db.oUF.Target.Icons.Leader.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								LeaderX = {
									name = "X Value",
									desc = "X Value for your Leader Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Leader.X,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Leader.Enable end,
									get = function() return db.oUF.Target.Icons.Leader.X end,
									set = function(self,LeaderX)
												if LeaderX == nil or LeaderX == "" then
													LeaderX = "0"
												end
												db.oUF.Target.Icons.Leader.X = LeaderX
												oUF_LUI_target.Leader:ClearAllPoints()
												oUF_LUI_target.Leader:SetPoint(db.oUF.Target.Icons.Leader.Point, oUF_LUI_target, db.oUF.Target.Icons.Leader.Point, tonumber(LeaderX), tonumber(db.oUF.Target.Icons.Leader.Y))
											end,
									order = 2,
								},
								LeaderY = {
									name = "Y Value",
									desc = "Y Value for your Leader Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Leader.Y,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Leader.Enable end,
									get = function() return db.oUF.Target.Icons.Leader.Y end,
									set = function(self,LeaderY)
												if LeaderY == nil or LeaderY == "" then
													LeaderY = "0"
												end
												db.oUF.Target.Icons.Leader.Y = LeaderY
												oUF_LUI_target.Leader:ClearAllPoints()
												oUF_LUI_target.Leader:SetPoint(db.oUF.Target.Icons.Leader.Point, oUF_LUI_target, db.oUF.Target.Icons.Leader.Point, tonumber(db.oUF.Target.Icons.Leader.X), tonumber(LeaderY))
											end,
									order = 3,
								},
								LeaderPoint = {
									name = "Position",
									desc = "Choose the Position for your Leader Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Leader.Point,
									type = "select",
									disabled = function() return not db.oUF.Target.Icons.Leader.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.Target.Icons.Leader.Point == v then
													return k
												end
											end
										end,
									set = function(self, LeaderPoint)
											db.oUF.Target.Icons.Leader.Point = positions[LeaderPoint]
											oUF_LUI_target.Leader:ClearAllPoints()
											oUF_LUI_target.Leader:SetPoint(db.oUF.Target.Icons.Leader.Point, oUF_LUI_target, db.oUF.Target.Icons.Leader.Point, tonumber(db.oUF.Target.Icons.Leader.X), tonumber(db.oUF.Target.Icons.Leader.X))
										end,
									order = 4,
								},
								LeaderSize = {
									name = "Size",
									desc = "Choose your Size for your Leader Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Leader.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.Target.Icons.Leader.Enable end,
									get = function() return db.oUF.Target.Icons.Leader.Size end,
									set = function(_, LeaderSize) 
											db.oUF.Target.Icons.Leader.Size = LeaderSize
											oUF_LUI_target.Leader:SetHeight(LeaderSize)
											oUF_LUI_target.Leader:SetWidth(LeaderSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.Target.Icons.Leader.Enable end,
									desc = "Toggles the Leader Icon",
									type = 'execute',
									func = function() if oUF_LUI_target.Leader:IsShown() then oUF_LUI_target.Leader:Hide() else oUF_LUI_target.Leader:Show() end end
								},
							},
						},
						LFDRole = {
							name = "LFDRole",
							type = "group",
							order = 3,
							args = {
								RoleEnable = {
									name = "Enable",
									desc = "Wether you want to show the Group Role Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Icons.Role.Enable end,
									set = function(self,RoleEnable)
												db.oUF.Target.Icons.Role.Enable = not db.oUF.Target.Icons.Role.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								RoleX = {
									name = "X Value",
									desc = "X Value for your Group Role Icon Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Role.X,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Role.Enable end,
									get = function() return db.oUF.Target.Icons.Role.X end,
									set = function(self,RoleX)
												if RoleX == nil or RoleX == "" then
													RoleX = "0"
												end
												db.oUF.Target.Icons.Role.X = RoleX
												oUF_LUI_target.LFDRole:ClearAllPoints()
												oUF_LUI_target.LFDRole:SetPoint(db.oUF.Target.Icons.Role.Point, oUF_LUI_target, db.oUF.Target.Icons.Role.Point, tonumber(RoleX), tonumber(db.oUF.Target.Icons.Role.Y))
											end,
									order = 2,
								},
								RoleY = {
									name = "Y Value",
									desc = "Y Value for your Role Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Role.Y,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Role.Enable end,
									get = function() return db.oUF.Target.Icons.Role.Y end,
									set = function(self,RoleY)
												if RoleY == nil or RoleY == "" then
													RoleY = "0"
												end
												db.oUF.Target.Icons.Role.Y = RoleY
												oUF_LUI_target.LFDRole:ClearAllPoints()
												oUF_LUI_target.LFDRole:SetPoint(db.oUF.Target.Icons.Role.Point, oUF_LUI_target, db.oUF.Target.Icons.Role.Point, tonumber(db.oUF.Target.Icons.Role.X), tonumber(RoleY))
											end,
									order = 3,
								},
								RolePoint = {
									name = "Position",
									desc = "Choose the Position for your Role Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Role.Point,
									type = "select",
									disabled = function() return not db.oUF.Target.Icons.Role.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.Target.Icons.Role.Point == v then
													return k
												end
											end
										end,
									set = function(self, RolePoint)
											db.oUF.Target.Icons.Role.Point = positions[RolePoint]
											oUF_LUI_target.LFDRole:ClearAllPoints()
											oUF_LUI_target.LFDRole:SetPoint(db.oUF.Target.Icons.Role.Point, oUF_LUI_target, db.oUF.Target.Icons.Role.Point, tonumber(db.oUF.Target.Icons.Role.X), tonumber(db.oUF.Target.Icons.Role.X))
										end,
									order = 4,
								},
								RoleSize = {
									name = "Size",
									desc = "Choose a Size for your Group Role Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Role.Size,
									type = "range",
									min = 5,
									max = 100,
									step = 1,
									disabled = function() return not db.oUF.Target.Icons.Role.Enable end,
									get = function() return db.oUF.Target.Icons.Role.Size end,
									set = function(_, RoleSize) 
											db.oUF.Target.Icons.Role.Size = RoleSize
											oUF_LUI_target.LFDRole:SetHeight(RoleSize)
											oUF_LUI_target.LFDRole:SetWidth(RoleSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.Target.Icons.Role.Enable end,
									desc = "Toggles the LFDRole Icon",
									type = 'execute',
									func = function() if oUF_LUI_target.LFDRole:IsShown() then oUF_LUI_target.LFDRole:Hide() else oUF_LUI_target.LFDRole:Show() end end
								},
							},
						},
						Raid = {
							name = "RaidIcon",
							type = "group",
							order = 4,
							args = {
								RaidEnable = {
									name = "Enable",
									desc = "Wether you want to show the Raid Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Icons.Raid.Enable end,
									set = function(self,RaidEnable)
												db.oUF.Target.Icons.Raid.Enable = not db.oUF.Target.Icons.Raid.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								RaidX = {
									name = "X Value",
									desc = "X Value for your Raid Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Raid.X,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Raid.Enable end,
									get = function() return db.oUF.Target.Icons.Raid.X end,
									set = function(self,RaidX)
												if RaidX == nil or RaidX == "" then
													RaidX = "0"
												end
												db.oUF.Target.Icons.Raid.X = RaidX
												oUF_LUI_target.RaidIcon:ClearAllPoints()
												oUF_LUI_target.RaidIcon:SetPoint(db.oUF.Target.Icons.Raid.Point, oUF_LUI_target, db.oUF.Target.Icons.Raid.Point, tonumber(RaidX), tonumber(db.oUF.Target.Icons.Raid.Y))
											end,
									order = 2,
								},
								RaidY = {
									name = "Y Value",
									desc = "Y Value for your Raid Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Raid.Y,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Raid.Enable end,
									get = function() return db.oUF.Target.Icons.Raid.Y end,
									set = function(self,RaidY)
												if RaidY == nil or RaidY == "" then
													RaidY = "0"
												end
												db.oUF.Target.Icons.Raid.Y = RaidY
												oUF_LUI_target.RaidIcon:ClearAllPoints()
												oUF_LUI_target.RaidIcon:SetPoint(db.oUF.Target.Icons.Raid.Point, oUF_LUI_target, db.oUF.Target.Icons.Raid.Point, tonumber(db.oUF.Target.Icons.Raid.X), tonumber(RaidY))
											end,
									order = 3,
								},
								RaidPoint = {
									name = "Position",
									desc = "Choose the Position for your Raid Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Raid.Point,
									type = "select",
									disabled = function() return not db.oUF.Target.Icons.Raid.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.Target.Icons.Raid.Point == v then
													return k
												end
											end
										end,
									set = function(self, RaidPoint)
											db.oUF.Target.Icons.Raid.Point = positions[RaidPoint]
											oUF_LUI_target.RaidIcon:ClearAllPoints()
											oUF_LUI_target.RaidIcon:SetPoint(db.oUF.Target.Icons.Raid.Point, oUF_LUI_target, db.oUF.Target.Icons.Raid.Point, tonumber(db.oUF.Target.Icons.Raid.X), tonumber(db.oUF.Target.Icons.Raid.X))
										end,
									order = 4,
								},
								RaidSize = {
									name = "Size",
									desc = "Choose a Size for your Raid Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Raid.Size,
									type = "range",
									min = 5,
									max = 200,
									step = 5,
									disabled = function() return not db.oUF.Target.Icons.Raid.Enable end,
									get = function() return db.oUF.Target.Icons.Raid.Size end,
									set = function(_, RaidSize) 
											db.oUF.Target.Icons.Raid.Size = RaidSize
											oUF_LUI_target.RaidIcon:SetHeight(RaidSize)
											oUF_LUI_target.RaidIcon:SetWidth(RaidSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.Target.Icons.Raid.Enable end,
									desc = "Toggles the RaidIcon",
									type = 'execute',
									func = function() if oUF_LUI_target.RaidIcon:IsShown() then oUF_LUI_target.RaidIcon:Hide() else oUF_LUI_target.RaidIcon:Show() end end
								},
							},
						},
						Resting = {
							name = "Resting",
							type = "group",
							order = 5,
							args = {
								RestingEnable = {
									name = "Enable",
									desc = "Wether you want to show the Resting Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Icons.Resting.Enable end,
									set = function(self,RestingEnable)
												db.oUF.Target.Icons.Resting.Enable = not db.oUF.Target.Icons.Resting.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								RestingX = {
									name = "X Value",
									desc = "X Value for your Resting Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Resting.X,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Resting.Enable end,
									get = function() return db.oUF.Target.Icons.Resting.X end,
									set = function(self,RestingX)
												if RestingX == nil or RestingX == "" then
													RestingX = "0"
												end
												db.oUF.Target.Icons.Resting.X = RestingX
												oUF_LUI_target.Resting:ClearAllPoints()
												oUF_LUI_target.Resting:SetPoint(db.oUF.Target.Icons.Resting.Point, oUF_LUI_target, db.oUF.Target.Icons.Resting.Point, tonumber(RestingX), tonumber(db.oUF.Target.Icons.Resting.Y))
											end,
									order = 2,
								},
								RestingY = {
									name = "Y Value",
									desc = "Y Value for your Resting Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Resting.Y,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Resting.Enable end,
									get = function() return db.oUF.Target.Icons.Resting.Y end,
									set = function(self,RestingY)
												if RestingY == nil or RestingY == "" then
													RestingY = "0"
												end
												db.oUF.Target.Icons.Resting.Y = RestingY
												oUF_LUI_target.Resting:ClearAllPoints()
												oUF_LUI_target.Resting:SetPoint(db.oUF.Target.Icons.Resting.Point, oUF_LUI_target, db.oUF.Target.Icons.Resting.Point, tonumber(db.oUF.Target.Icons.Resting.X), tonumber(RestingY))
											end,
									order = 3,
								},
								RestingPoint = {
									name = "Position",
									desc = "Choose the Position for your Resting Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Resting.Point,
									type = "select",
									disabled = function() return not db.oUF.Target.Icons.Resting.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.Target.Icons.Resting.Point == v then
													return k
												end
											end
										end,
									set = function(self, RestingPoint)
											db.oUF.Target.Icons.Resting.Point = positions[RestingPoint]
											oUF_LUI_target.Resting:ClearAllPoints()
											oUF_LUI_target.Resting:SetPoint(db.oUF.Target.Icons.Resting.Point, oUF_LUI_target, db.oUF.Target.Icons.Resting.Point, tonumber(db.oUF.Target.Icons.Resting.X), tonumber(db.oUF.Target.Icons.Resting.X))
										end,
									order = 4,
								},
								RestingSize = {
									name = "Size",
									desc = "Choose a Size for your Resting Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Resting.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.Target.Icons.Resting.Enable end,
									get = function() return db.oUF.Target.Icons.Resting.Size end,
									set = function(_, RestingSize) 
											db.oUF.Target.Icons.Resting.Size = RestingSize
											oUF_LUI_target.Resting:SetHeight(RestingSize)
											oUF_LUI_target.Resting:SetWidth(RestingSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.Target.Icons.Resting.Enable end,
									desc = "Toggles the Resting Icon",
									type = 'execute',
									func = function() if oUF_LUI_target.Resting:IsShown() then oUF_LUI_target.Resting:Hide() else oUF_LUI_target.Resting:Show() end end
								},
							},
						},
						Combat = {
							name = "Combat",
							type = "group",
							order = 5,
							args = {
								CombatEnable = {
									name = "Enable",
									desc = "Wether you want to show the Combat Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Icons.Combat.Enable end,
									set = function(self,CombatEnable)
												db.oUF.Target.Icons.Combat.Enable = not db.oUF.Target.Icons.Combat.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								CombatX = {
									name = "X Value",
									desc = "X Value for your Combat Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Combat.X,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Combat.Enable end,
									get = function() return db.oUF.Target.Icons.Combat.X end,
									set = function(self,CombatX)
												if CombatX == nil or CombatX == "" then
													CombatX = "0"
												end
												db.oUF.Target.Icons.Combat.X = CombatX
												oUF_LUI_target.Combat:ClearAllPoints()
												oUF_LUI_target.Combat:SetPoint(db.oUF.Target.Icons.Combat.Point, oUF_LUI_target, db.oUF.Target.Icons.Combat.Point, tonumber(CombatX), tonumber(db.oUF.Target.Icons.Combat.Y))
											end,
									order = 2,
								},
								CombatY = {
									name = "Y Value",
									desc = "Y Value for your Combat Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Combat.Y,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.Combat.Enable end,
									get = function() return db.oUF.Target.Icons.Combat.Y end,
									set = function(self,CombatY)
												if CombatY == nil or CombatY == "" then
													CombatY = "0"
												end
												db.oUF.Target.Icons.Combat.Y = CombatY
												oUF_LUI_target.Combat:ClearAllPoints()
												oUF_LUI_target.Combat:SetPoint(db.oUF.Target.Icons.Combat.Point, oUF_LUI_target, db.oUF.Target.Icons.Combat.Point, tonumber(db.oUF.Target.Icons.Combat.X), tonumber(CombatY))
											end,
									order = 3,
								},
								CombatPoint = {
									name = "Position",
									desc = "Choose the Position for your Combat Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Combat.Point,
									type = "select",
									disabled = function() return not db.oUF.Target.Icons.Combat.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.Target.Icons.Combat.Point == v then
													return k
												end
											end
										end,
									set = function(self, CombatPoint)
											db.oUF.Target.Icons.Combat.Point = positions[CombatPoint]
											oUF_LUI_target.Combat:ClearAllPoints()
											oUF_LUI_target.Combat:SetPoint(db.oUF.Target.Icons.Combat.Point, oUF_LUI_target, db.oUF.Target.Icons.Combat.Point, tonumber(db.oUF.Target.Icons.Combat.X), tonumber(db.oUF.Target.Icons.Combat.X))
										end,
									order = 4,
								},
								CombatSize = {
									name = "Size",
									desc = "Choose a Size for your Combat Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.Combat.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.Target.Icons.Combat.Enable end,
									get = function() return db.oUF.Target.Icons.Combat.Size end,
									set = function(_, CombatSize) 
											db.oUF.Target.Icons.Combat.Size = CombatSize
											oUF_LUI_target.Combat:SetHeight(CombatSize)
											oUF_LUI_target.Combat:SetWidth(CombatSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									disabled = function() return not db.oUF.Target.Icons.Combat.Enable end,
									name = "Show/Hide",
									desc = "Toggles the Combat Icon",
									type = 'execute',
									func = function() if oUF_LUI_target.Combat:IsShown() then oUF_LUI_target.Combat:Hide() else oUF_LUI_target.Combat:Show() end end
								},
							},
						},
						PvP = {
							name = "PvP",
							type = "group",
							order = 5,
							args = {
								PvPEnable = {
									name = "Enable",
									desc = "Wether you want to show the PvP Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Target.Icons.PvP.Enable end,
									set = function(self,PvPEnable)
												db.oUF.Target.Icons.PvP.Enable = not db.oUF.Target.Icons.PvP.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								PvPX = {
									name = "X Value",
									desc = "X Value for your PvP Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.PvP.X,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.PvP.Enable end,
									get = function() return db.oUF.Target.Icons.PvP.X end,
									set = function(self,PvPX)
												if PvPX == nil or PvPX == "" then
													PvPX = "0"
												end
												db.oUF.Target.Icons.PvP.X = PvPX
												oUF_LUI_target.PvP:ClearAllPoints()
												oUF_LUI_target.PvP:SetPoint(db.oUF.Target.Icons.PvP.Point, oUF_LUI_target, db.oUF.Target.Icons.PvP.Point, tonumber(PvPX), tonumber(db.oUF.Target.Icons.PvP.Y))
											end,
									order = 2,
								},
								PvPY = {
									name = "Y Value",
									desc = "Y Value for your PvP Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.PvP.Y,
									type = "input",
									disabled = function() return not db.oUF.Target.Icons.PvP.Enable end,
									get = function() return db.oUF.Target.Icons.PvP.Y end,
									set = function(self,PvPY)
												if PvPY == nil or PvPY == "" then
													PvPY = "0"
												end
												db.oUF.Target.Icons.PvP.Y = PvPY
												oUF_LUI_target.PvP:ClearAllPoints()
												oUF_LUI_target.PvP:SetPoint(db.oUF.Target.Icons.PvP.Point, oUF_LUI_target, db.oUF.Target.Icons.PvP.Point, tonumber(db.oUF.Target.Icons.PvP.X), tonumber(PvPY))
											end,
									order = 3,
								},
								PvPPoint = {
									name = "Position",
									desc = "Choose the Position for your PvP Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.PvP.Point,
									type = "select",
									disabled = function() return not db.oUF.Target.Icons.PvP.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.Target.Icons.PvP.Point == v then
													return k
												end
											end
										end,
									set = function(self, PvPPoint)
											db.oUF.Target.Icons.PvP.Point = positions[PvPPoint]
											oUF_LUI_target.PvP:ClearAllPoints()
											oUF_LUI_target.PvP:SetPoint(db.oUF.Target.Icons.PvP.Point, oUF_LUI_target, db.oUF.Target.Icons.PvP.Point, tonumber(db.oUF.Target.Icons.PvP.X), tonumber(db.oUF.Target.Icons.PvP.X))
										end,
									order = 4,
								},
								PvPSize = {
									name = "Size",
									desc = "Choose a Size for your PvP Icon.\nDefault: "..LUI.defaults.profile.oUF.Target.Icons.PvP.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.Target.Icons.PvP.Enable end,
									get = function() return db.oUF.Target.Icons.PvP.Size end,
									set = function(_, PvPSize) 
											db.oUF.Target.Icons.PvP.Size = PvPSize
											oUF_LUI_target.PvP:SetHeight(PvPSize)
											oUF_LUI_target.PvP:SetWidth(PvPSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.Target.Icons.PvP.Enable end,
									desc = "Toggles the PvP Icon",
									type = 'execute',
									func = function() if oUF_LUI_target.PvP:IsShown() then oUF_LUI_target.PvP:Hide() else oUF_LUI_target.PvP:Show() end end
								},
							},
						},
					},
				},
			},
		},
	}
	
	return options
end

function module:OnInitialize()
	LUI:MergeDefaults(LUI.db.defaults.profile.oUF, defaults)
	LUI:RefreshDefaults()
	LUI:Refresh()
	
	self.db = LUI.db.profile
	db = self.db
end

function module:OnEnable()
	LUI:RegisterUnitFrame(self:LoadOptions())
end