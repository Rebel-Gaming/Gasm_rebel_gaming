if IsAddOnLoaded("Talented") then return end

local prev_ToggleTalentFrame = ToggleTalentFrame
local prev_ToggleGlyphFrame = ToggleGlyphFrame

local function LoadTalented()
	ToggleTalentFrame = prev_ToggleTalentFrame
	ToggleGlyphFrame = prev_ToggleGlyphFrame
	TalentMicroButton:SetScript("OnClick", prev_ToggleTalentFrame)
	SlashCmdList.JERRY_TALENTED = nil
	SLASH_JERRY_TALENTED1 = nil
	hash_SlashCmdList["/TALENTED"] = nil
	UIParent:RegisterEvent"USE_GLYPH"
	UIParent:RegisterEvent"CONFIRM_TALENT_WIPE"
	TalentedFrame:SetScript("OnEvent", nil)
	TalentedFrame:UnregisterAllEvents()
	TalentedFrame:SetScript("OnShow", nil)
	local categories = INTERFACEOPTIONS_ADDONCATEGORIES
	for i = 1, #categories do
		if categories[i] == TalentedFrame then
			table.remove(categories, i)
			break
		end
	end
	for key, value in pairs(TalentedFrame) do
		if type(value) ~= "userdata" then
			TalentedFrame[key] = nil
		end
	end
	TalentedFrame:SetParent(UIParent)
	LoadAddOn"Talented"
	LoadTalented = nil
end
SlashCmdList.JERRY_TALENTED = function (...)
	LoadTalented()
	Talented:OnChatCommand(...)
end
SLASH_JERRY_TALENTED1 = "/TALENTED"

function ToggleTalentFrame()
	LoadTalented()
	if Talented then
		Talented:ToggleTalentFrame()
	else
		prev_ToggleTalentFrame()
	end
end
TalentMicroButton:SetScript("OnClick", ToggleTalentFrame)

function ToggleGlyphFrame()
	LoadTalented()
	if Talented then
		Talented:ToggleGlyphFrame()
	else
		prev_ToggleGlyphFrame()
	end
end

local frame = CreateFrame("Frame", "TalentedFrame", UIParent)
frame:SetScript("OnEvent", function (self, event, ...)
	if event == "INSPECT_TALENT_READY" and (not InspectFrame or not InspectFrame:IsShown()) then return end
	LoadTalented()
	if Talented then
		Talented[event](Talented, event, ...)
	end
end)
frame:RegisterEvent"INSPECT_TALENT_READY"
frame:RegisterEvent"USE_GLYPH"
frame:RegisterEvent"CONFIRM_TALENT_WIPE"
UIParent:UnregisterEvent"USE_GLYPH"
UIParent:UnregisterEvent"CONFIRM_TALENT_WIPE"

frame.name = "Talented"
frame:Hide()
frame:SetScript("OnShow", function (self)
	self:Hide()
	LoadTalented()
	if Talented then
		InterfaceOptionsFrame_OpenToCategory(Talented.optionsFrame)
	end
end)
InterfaceOptions_AddCategory(frame)
