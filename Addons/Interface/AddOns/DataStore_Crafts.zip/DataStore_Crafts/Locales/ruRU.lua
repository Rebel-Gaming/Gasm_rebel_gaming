local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Crafts", "ruRU" )

if not L then return end

L["Professions"] = "Профессии"
L["Secondary Skills"] = "Разное"

