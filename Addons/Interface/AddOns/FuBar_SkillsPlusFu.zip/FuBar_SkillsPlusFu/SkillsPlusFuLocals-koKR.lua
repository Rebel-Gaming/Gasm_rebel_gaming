﻿-- binding labels
BINDING_HEADER_SKILLSPLUSHEADER = 'SkillsPlusFu'
BINDING_NAME_SKILLSPLUSNAME     = '선택한 전문/보조기술을 사용합니다.'

-- constants
COOLDOWN_TIMER_FREQUENCY =  30     -- metrognome update interval
COOLDOWN_NOTIFYTIME      = 300     -- warning when ready in less than five minutes
 
local AceLocale = AceLibrary("AceLocale-2.2"):new("SkillsPlusFu")

AceLocale:RegisterTranslations("koKR", function() 
    return {   
        -- general labels
        ["NAME"] = 'FuBar - SkillsPlusFu',
        ["DESCRIPTION"] = '전문/보조 기술을 사용하고 재사용 대기시간을 표시합니다.',
        ["CMD_OPTIONS"] = {'/spfu', '/skillsplusfu'},
        
        ["SP_FACTION"] = '평판',
        ["SP_FACTION_ALLIANCE"] = '얼라이언스',
        ["SP_FACTION_HORDE"] = '호드',
        
        ["TOOLTIP_HINT"] = '\n클릭: 선택된 기술창 열기.\n오른쪽 클릭: 전문/보조 기술 선택.',

        ["FUBAR_LABEL"] = '전문/보조기술',
        
        -- skill labels
        ["CATEGORY_LANGUAGES"] = '언어',
        ["CATEGORY_WEAPON_SKILLS"] = '무기 숙련',
        
        -- menu labels
        ["MENU_SHOW_BOOLEAN_SKILLS"] = '직업 기술 보기',
        ["MENU_SHOW_LANGUAGE_SKILLS"] = '언어 숙련 보기',
        ["MENU_SHOW_WEAPON_SKILLS"] = '무기 숙련 보기',
        ["MENU_SHOW_OTHER_TOON_SKILLS"] = '다른 캐릭터 기술 보기',
        ["MENU_HIDE_TOON"] = "모두 숨기기",
        ["MENU_SHOW_SKILL_LABEL"] = '기술명 보기',
        ["MENU_SHOW_CROSS_FACTION_SKILLS"] = '크로스 팩션 스킬 보기',
        ["MENU_PURGE_CHARACTER"] = '캐릭터 합쳐서 보기',
        ["MENU_SHOW_TOON_NAMES"] = '플레이어 이름 보기',
        ["MENU_SHOW_NOTIFICATION"]  = '쿨다운 알림 보기',
        ["MENU_CLEAR_COOLDOWN_DATA"] = '현재 쿨다운 데이터 초기화',
        ["MENU_HIDE_COOLDOWN_FOR"] = '쿨다운 데이터 숨기기',

        -- cooldown labels
        ["COOLDOWN_IS_READY"] = '|cff00FF00쿨다운:|r %s 서버 %s: %s 가 재사용 가능합니다..',
        ["COOLDOWN_WILL_BE_READY"] = '|cff00FF00쿨다운:|r %s 서버 %s: %s 가 5분후에 재사용 가능합니다.',

        ["COOLDOWN_CATEGORY"] = '재사용 대기시간',
        ["COOLDOWN_READY"] = '준비완료!',

        ["COOLDOWN_ELUNES_LANTERN"] = '엘룬의 등불',
        ["COOLDOWN_ELUNE_STONE"] = '엘룬의 돌',
        ["COOLDOWN_REFINED_SALT"] = '정제된 깊은바다 소금',
        ["COOLDOWN_SALT_SHAKER"] = '소금 정제기',
        ["COOLDOWN_SNOWMASTER"] = '눈뭉치제조기 9000',
        ["COOLDOWN_SNOWBALL"] = '눈뭉치',
		["COOLDOWN_ENCHANTING"] = "마법부여 변환",
        ["COOLDOWN_TRANSMUTE_MATCH"] = '변환식',
        ["COOLDOWN_TRANSMUTES"] = '변환',
        ["COOLDOWN_CREATE_ITEM"] = '아이템을 획득했습니다',

        ["COOLDOWN_TIME_FORMAT"] = "%d일 %02d:%02d",
     }

end)