-- binding labels
BINDING_HEADER_SKILLSPLUSHEADER = "SkillsPlusFu"
BINDING_NAME_SKILLSPLUSNAME = "Selektierten Skill nutzen."

-- constants
COOLDOWN_TIMER_FREQUENCY =  30     -- update interval
COOLDOWN_NOTIFYTIME      = 300     -- warning when ready in less than five minutes
 
local AceLocale = AceLibrary("AceLocale-2.2"):new("SkillsPlusFu")

AceLocale:RegisterTranslations("deDE", function() 
-- courtesy of Xanatandor
    return {
        -- general labels
        ["NAME"] = "FuBar - SkillsPlusFu",
        ["DESCRIPTION"] = "Ansicht und Zugriff auf Skills, zeigt auch Cooldowns.",
        ["CMD_OPTIONS"] = {'/spfu', '/skillsplusfu'},

        ["SP_FACTION"] = "Fraktion",
        ["SP_FACTION_ALLIANCE"] = "Allianz",
        ["SP_FACTION_HORDE"] = "Horde",

        ["TOOLTIP_HINT"] = "|cffeda55fKlick|r um Skill anzuwenden.\n|cffeda55fRechtsklick|r um Skill auszuw\195\164hlen.",

        ["FUBAR_LABEL"] = "Skills",

        -- skill labels
        ["CATEGORY_LANGUAGES"] = "Sprachen",
        ["CATEGORY_WEAPON_SKILLS"] = "Waffenfertigkeiten",

        -- menu labels
        ["MENU_SHOW_BOOLEAN_SKILLS"] = "Zeige zweiwertige Skills",
        ["MENU_SHOW_LANGUAGE_SKILLS"] = "Zeige Sprachen",
        ["MENU_SHOW_WEAPON_SKILLS"] = "Zeige Waffenfertigkeiten",
        ["MENU_SHOW_OTHER_TOON_SKILLS"] = "Zeige Skills anderer Charaktere",
        ["MENU_HIDE_TOON"] = "Hide all",
        ["MENU_SHOW_SKILL_LABEL"] = "Zeige Skilltext",
        ["MENU_SHOW_CROSS_FACTION_SKILLS"] = "Zeige Skills anderer Fraktion",
        ["MENU_PURGE_CHARACTER"] = "Charakter entfernen",
        ["MENU_SHOW_TOON_NAMES"] = "Zeige Charakternamen",
        ["MENU_SHOW_NOTIFICATION"] = "Zeige Cooldown Benachrichtigung",
        ["MENU_CLEAR_COOLDOWN_DATA"] = "L\195\182sche aktuelle Cooldowndaten",
        ["MENU_HIDE_COOLDOWN_FOR"] = "Hide cooldown data for",        

        -- cooldown labels
        ["COOLDOWN_IS_READY"] = "|cff00FF00Cooldown:|r %s f\195\188r %s: %s ist bereit.",
        ["COOLDOWN_WILL_BE_READY"] = "|cff00FF00Cooldown:|r %s f\195\188r %s: %s ist in weniger als 5 Minuten bereit.",

        ["COOLDOWN_CATEGORY"] = "Cooldown",
        ["COOLDOWN_READY"] = "Bereit!",

        ["COOLDOWN_ELUNES_LANTERN"] = "Elunes Laterne",
        ["COOLDOWN_ELUNE_STONE"] = "Elunes Stein",
        ["COOLDOWN_REFINED_SALT"] = "Raffiniertes Tiefsteinsalz",
        ["COOLDOWN_SALT_SHAKER"] = "Salzstreuer",
        ["COOLDOWN_SNOWMASTER"] = "Schneemeister 9000",
        ["COOLDOWN_SNOWBALL"] = "Schneeball",
		["COOLDOWN_ENCHANTING"] = "Enchanting Transmute",
        ["COOLDOWN_TRANSMUTE_MATCH"] = "Transmutieren",
        ["COOLDOWN_TRANSMUTES"] = "Transmutationen",
        ["COOLDOWN_CREATE_ITEM"] = "Ihr stellt her",
 
        ["COOLDOWN_TIME_FORMAT"] = "%dD %02d:%02d",
    }

end)