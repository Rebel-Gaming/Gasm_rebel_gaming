if GetLocale() == "zhTW" then

-- binding labels
BINDING_HEADER_SKILLSPLUSHEADER = "SkillsPlusFu"
BINDING_NAME_SKILLSPLUSNAME     = "使用選擇的技能。"

-- constants
COOLDOWN_TIMER_FREQUENCY =  30     -- update interval
COOLDOWN_NOTIFYTIME      = 300     -- warning when ready in less than five minutes

end
 
local AceLocale = AceLibrary("AceLocale-2.2"):new("SkillsPlusFu")

AceLocale:RegisterTranslations("zhTW", function() 
    return {
        -- general labels
        ["NAME"] = "FuBar - SkillsPlusFu",
        ["DESCRIPTION"] = "選擇技能，使用技能及顯示冷卻時間。",
        ["CMD_OPTIONS"] = {"/spfu", "/skillsplusfu"},
        
        ["SP_FACTION"] = "陣營",
        ["SP_FACTION_ALLIANCE"] = "聯盟",
        ["SP_FACTION_HORDE"] = "部落",
        
        ["TOOLTIP_HINT"] = "\n|cffeda55f左擊: |r檢視選擇的技能。\n|cffeda55f右擊: |r選擇技能。",

        ["FUBAR_LABEL"] = "技能",
        
        -- skill labels
        ["CATEGORY_LANGUAGES"] = "語言",
        ["CATEGORY_WEAPON_SKILLS"] = "武器技能",
        
        -- menu labels
        ["MENU_SHOW_BOOLEAN_SKILLS"] = "顯示無等級技能",
        ["MENU_SHOW_LANGUAGE_SKILLS"] = "顯示語言",
        ["MENU_SHOW_WEAPON_SKILLS"] = "顯示武器技能",
        ["MENU_SHOW_OTHER_TOON_SKILLS"] = "顯示分身技能",
        ["MENU_HIDE_TOON"] = "全部隱藏",        
        ["MENU_SHOW_SKILL_LABEL"] = "顯示技能標籤",
        ["MENU_SHOW_CROSS_FACTION_SKILLS"] = "顯示跨陣營技能",
        ["MENU_PURGE_CHARACTER"] = "清空角色資料",
        ["MENU_SHOW_TOON_NAMES"] = "顯示角色名稱",
        ["MENU_SHOW_NOTIFICATION"]  = "顯示冷卻通知",
        ["MENU_CLEAR_COOLDOWN_DATA"] = "清除當前冷卻時間資料",
        ["MENU_HIDE_COOLDOWN_FOR"] = "隱藏冷卻時間資料: ",

        -- cooldown labels
        ["COOLDOWN_IS_READY"] = "|cff00FF00冷卻: |r %s - %s: %s 就緒。",
        ["COOLDOWN_WILL_BE_READY"] = "|cff00FF00冷卻: |r %s - %s: %s 將在5秒內就緒。",

        ["COOLDOWN_CATEGORY"] = "冷卻",
        ["COOLDOWN_READY"] = "就緒!",

        ["COOLDOWN_ELUNES_LANTERN"] = "伊露恩的燈籠",
        ["COOLDOWN_ELUNE_STONE"] = "伊露恩之石",
        ["COOLDOWN_REFINED_SALT"] = "精煉石中鹽",
        ["COOLDOWN_SALT_SHAKER"] = "篩鹽器",
        ["COOLDOWN_SNOWMASTER"] = "雪王9000型",
        ["COOLDOWN_SNOWBALL"] = "雪球",
		["COOLDOWN_ENCHANTING"] = "附魔轉化",
        ["COOLDOWN_TRANSMUTE_MATCH"] = "轉化",
        ["COOLDOWN_TRANSMUTES"] = "轉化",
        ["COOLDOWN_CREATE_ITEM"] = "你製造了",

        ["COOLDOWN_TIME_FORMAT"] = "%d日 %02d:%02d",
     }

end)