-- binding labels
BINDING_HEADER_SKILLSPLUSHEADER = "SkillsPlusFu"
BINDING_NAME_SKILLSPLUSNAME     = "Use the selected skill."

-- constants
COOLDOWN_TIMER_FREQUENCY =  30     -- update interval
COOLDOWN_NOTIFYTIME      = 300     -- warning when ready in less than five minutes
 
local AceLocale = AceLibrary("AceLocale-2.2"):new("SkillsPlusFu")

AceLocale:RegisterTranslations("frFR", function() 
-- courtesy of sturmy
    return {
        -- general labels
        ["NAME"] = "FuBar - SkillsPlusFu",
        ["DESCRIPTION"] = "Montre et acc\195\168de aux comp\195\169tences, affiche \195\168galement les cooldowns.",
        ["CMD_OPTIONS"] = {"/spfu", "/skillsplusfu"},
        
        ["SP_FACTION"] = "Faction",
        ["SP_FACTION_ALLIANCE"] = "Alliance",
        ["SP_FACTION_HORDE"] = "Horde",
        
        ["TOOLTIP_HINT"] = "|cffeda55fClic|r pour acc\195\169der a la comp\195\169tence affich\195\169e.\n|cffeda55fClic droit|r pour choisir une comp\195\169tence.",

        ["FUBAR_LABEL"] = "Comp\195\169tences",
        
        -- skill labels
        ["CATEGORY_LANGUAGES"] = "Langues",
        ["CATEGORY_WEAPON_SKILLS"] = "Comp\195\169tences d\'arme",

        -- menu labels
        ["MENU_SHOW_BOOLEAN_SKILLS"] = "Montrer comp\195\168tences bool\195\168ennes",
        ["MENU_SHOW_LANGUAGE_SKILLS"] = "Montrer langues",
        ["MENU_SHOW_WEAPON_SKILLS"] = "Montrer comp\195\168tences d\'armes",
        ["MENU_SHOW_OTHER_TOON_SKILLS"] = "Montrer les comp\195\168tences des autres personnages",
        ["MENU_HIDE_TOON"] = "Hide all",
        ["MENU_SHOW_SKILL_LABEL"] = "Montrer le nom de comp\195\168tence",
        ["MENU_SHOW_CROSS_FACTION_SKILLS"] = "Montrer les comp\195\168tences de l\'autre faction",
        ["MENU_PURGE_CHARACTER"] = "Purger personnage",
        ["MENU_SHOW_TOON_NAMES"] = "Montrer nom des personnages",
        ["MENU_SHOW_NOTIFICATION"] = "Montrer les notifications de cooldown",
        ["MENU_CLEAR_COOLDOWN_DATA"] = "Effacer les informations actuelles de cooldown",
        ["MENU_HIDE_COOLDOWN_FOR"] = "Hide cooldown data for",

        -- cooldown labels
        ["COOLDOWN_IS_READY"] = "|cff00FF00Cooldown:|r %s pour %s: %s est pr\195\170t.",
        ["COOLDOWN_WILL_BE_READY"] = "|cff00FF00Cooldown:|r %s pour %s: %s sera pr\195\170t dans moins de 5 minutes.",

        ["COOLDOWN_CATEGORY"] = "Cooldown",
        ["COOLDOWN_READY"] = "Pr\195\170t!",

        ["COOLDOWN_ELUNES_LANTERN"] = "Lanterne d\'Elune",
        ["COOLDOWN_ELUNE_STONE"] = "Pierre d\'Elune",
        ["COOLDOWN_REFINED_SALT"] = "Sel de Fonderoc raffin\195\169",
        ["COOLDOWN_SALT_SHAKER"] = "Tamis \195\160 sel",
        ["COOLDOWN_SNOWMASTER"] = "Ma\195\174tre-Neige 9000",
        ["COOLDOWN_SNOWBALL"] = "Boule de neige",
		["COOLDOWN_ENCHANTING"] = "Enchanting Transmute",
        ["COOLDOWN_TRANSMUTE_MATCH"] = "Transmutation",
        ["COOLDOWN_TRANSMUTES"] = "Transmute",
        ["COOLDOWN_CREATE_ITEM"] = "Vous cr\195\169ez",
 
        ["COOLDOWN_TIME_FORMAT"] = "%dD %02d:%02d",
    }

end)