FuBar - SkillsPlusFu v3.3.1

Author: Jayhawk
Release Date: 2010-03-31

Shows all skills in a tool tip and allows you to quickly select/reselect one of them. Also handles Cooldown information.

Use
The FuBar menu will display either Skills or the name of a skill that can be used to make things (so, say, Mining doesn't show, but Smelting does). Behind the skill (name and/or icon depending on your preferences) the number of cooldown items is displayed. This display show (total item - items ready) This will not be shown when you have no cooldown items for any of the toons you play.

By selecting the (right-click) menu you see all skills that you can use to make things with for your current toon. Selecting one of these skills will open the relevant skill window and put it's name/icon up in the FuBar. Clicking this later will open the associated skill window again. The last used skill is saved between sessions.

Options
Show skill label - Toggles the display of the skill name (or the text skills) on the FuBar. Use this when you want to show only the icon and the cooldown info.
Show boolean skills - Toggles skills that do not progress, this includes proficiencies.
Show languages - Toggles the Language category
Show weapon skills - Toggles the Weapon skills category
Show other player skills - Allows you to select which other toons and skills are shown. 
Show cross faction skills - Toggles whether the skills mentioned above include those of other faction toons.

Show player names - Toggles display of the player names in the cooldown info
Show cooldown notification - Toggles displaying the cooldown info on the FuBar
Clear current cooldown data - Clears the current cooldown database.
Hide cooldown data for - Allows you to hide a specific cooldown

Changelog
3.3.1 - removed cooldowns for Titansteel Bar, Moonshroud, Spellweave and Ebonweave (Patch 3.3.3).
	added cooldown for Glacial Bag (Patch 3.3.3).
3.3.0 - updated TOC
3.2.0 - added cooldown for new Alchemy transmutes (3.2)
        updated TOC
3.1.0 - updated TOC
3.0.6 - added cooldowns for Mooshroud, Ebonweave, Spellweave and Icy Prism (serious2)
3.0.5 - removed level 70 cloth cooldowns (patch 3.0.8)
3.0.4 - fixed a possible reason for cooldowns resetting
3.0.3 - added cooldown for Smelt Titansteel (Calesta)
	added cooldown for Transmute: Titanium
	added cooldown for Northrend Alchemy Research
3.0.2 - added safety catch for viewing other people's trade skills (Myster)
           removed link to TradeSkillInfo as it was broken (Zidomo)
           more rework to try and fix bug with cooldown issues for Alchemy and Enchanting 

3.0.1 - bugfix embed.xml, Salt Shaker cooldown 
3.0.0 - updated for WotLK, streamlined code, added Inscriptions
2.4.7 - bugfix for alchemy cooldoown issue, added transmutes for WotLK
2.4.6 - removed cooldown for Mooncloth (Patch 2.4.3)
2.4.5 - updated cooldowns (Patch 2.4.2), cleaned up code, fixed problem with Achemy cooldown failing 
2.4.4 - updated TOC, redone cooldowns for V. and P. spheres (by Ackis), redone Salt Shaker, Elune's Lantarn and Snowmaster 9000 (thanks Seerah), removed Alchemy Hack (Ackis)
2.4.3 - updated TOC, zhTW localisation updated (helium), koKR localisation added (7destiny/ochocobo) 
2.4.2 - redone cooldowns for v. and p. spheres (by Ackis), updated T.O.C. Fixed Blood Elf issue. Hacked alchemy issue.
2.4.1 - attempted to add cooldowns for void and prismatic spheres
2.4.0 - updated TOC
           added herbalism, mining and skinning to the Other toons skills
           Traditional Chinese (zhTW) localisation added by helium
2.3.1 - fixed bug as located by Crokk
           locally fixed BabbleRace problem with Blood Elf capitalisation
2.3.0 - added interface to hide specific cooldowns and skills (or a specific toon) as suggested by Highend
2.2.8 - added cooldown support for Primal Mooncloth, Shadowcloth and Spellcloth
           added Blood elfs to faction check
2.2.7 - added Jewelcrafting
2.2.6 - fixed some more library issues
          changed datamodel for better functionality
          fixed Purge option
          added fishing skill back to the list of saved skills for other toons
          added a partial French translation for the Cooldown functionality (ID1755)
2.2.5 - actually removed unnecessary call to dewdrop:Close (ID2400) 
2.2.4 - added German translation to TOC again (ID2631)
2.2.3 - finally really fixed dependencies
2.2.2 - added German translation (provided by Xanatandor)
          added CloseWhenClicked to dewdrops (ID2400) 
2.2.1 - fixed sloppy references
           removed unnecessary libraries
2.2.0 - updated to WoW 2.0
          updated libraries
          removed disenchanting, fishing and lock picking menus as they violate Blizzard code rules
2.1.5 - removed unnecessary call to dewdrop:Close (ID2400)
2.1.4 - fixed bug with Snowmaster 9000
2.1.3 - added options to hide languages and weapon skills
          added option to Purge toons (ID1588)  
2.1.2 - fixed bug with non-FuBar 2.0 library
2.1.1 - fixed bug with Engineering not being saved
2.1.0 - updated to use BabbleLib (Race,Spell)
2.0.0 - updated to FuBar 2.0
0.7.0 - added option to show/hide showing skills of other faction toons
          added support to show last used skill when reloading
          removed showing (0/0) when no cooldown items are present
          fixed bug in "Show skill label"
0.6.2 - updated TOC and fixed bug with snowball.
0.6.1 - no changes, needed for upload
0.6.0 - added option to keep track of the skills of your other toons.
0.5.3 - added notification option
0.5.2 - added option for displaying name before cooldown item.
0.5.1 - added key binding support, and warning timer message.
0.5.0 - complete rewrite of attempt at cooldown support, actually saved data, flexible menu label (non-released).
0.4.0 - complete rewrite of attempt at cooldown support, included timers (non-released).
0.3.0 - first attempt at cooldown support, only showed cooldown items (non-released).
0.2.1 - added fubar icon support.


Acknowledgements
This add-on is based on avngr's FuBar_ProfessionsFu, Kemayo's FuBar_KungFu, and smuggles FubarTradeCooldownFu. Thanks guys!

Install: extract the FuBar_SkillsPlusFu folder into

	\World of Warcraft\Interface\AddOns\


>>>>>>> .r26367
This add-on was downloaded from http://www.wowinterface.com/
