
local addon = CreateFrame("Frame") --select(2,...)

GuildDelta_memberdata = {}
GuildDelta_chatframe = 2
GuildDelta_fields = {
	rank   = true,
	level  = false,
	notes  = true,
}

local l10n
--if GetLocale() == "enUS" then
	l10n= {
		["LEFT"] = "Players who have left the guild:  ",
		["JOINED"] = "Players who have joined the guild:  ",
		["RANK"] = "Players whose rank has changed:",
		["LEVEL"] = "Players whose level has changed:",
		["NOTES"] = "Players whose notes have changed:",

		["FIELD_rank"] = "Rank",
		["FIELD_level"] = "Level",
		["FIELD_notes"] = "Player/Officer notes",
	}
--elseif .... end

addon.options = {
	name = "Guild Delta",
	type = 'group',
	handler = addon,    -- functions listed as strings called as addon:func
	args = {
		version = {
			--name = filled in during OnEnable
			type = 'description',
			fontSize = "large",
			--image = "Interface\\AddOns\\GuildDelta\\test2",
			cmdHidden = true,
			order = 1,
		},
		note = {
			--name = filled in locals section
			type = 'description',
			cmdHidden = true,
			width = 'full',
			order = 2,
		},
		reset = {
			name = "Reset Output",
			desc = "Restores default output settings",
			type = 'execute',
			order = 5,
			func = "SetChat",
			arg = 3,
		},
		spacer2 = {
			name = '',
			type = 'description',
			cmdHidden = true,
			width = 'full',
			order = 6,
		},
		print_chatframes = {
			name = "Print Chatframe Numbers",
			desc = "Print each chat window number in its frame, for easy reference in the next slider option",
			type = 'execute',
			--func = print_chatframes filled in below
			order = 10,
		},
		chatframe_num = {
			name = "Output Chatframe",
			desc = "Which chat window to use for printing all the output during login",
			type = 'range',
			min  = 1,
			max  = NUM_CHAT_WINDOWS,
			step = 1,
			get = function() return tonumber(GuildDelta_chatframe) or 2 end,
			set = "SetChat",
			order = 15,
		},
		chatframe_name = {
			name = "Chatframe Override",
			desc = "<Advanced>  If blank, uses the numerical slider.  If set, it is the NAME of a frame with AddMessage capability to use for output.",
			type = 'input',
			get = function()
				return type(GuildDelta_chatframe) == "string" and GuildDelta_chatframe or nil
			end,
			set = "SetChat",
			order = 16,
		},
		fields = {
			name = "Fields",
			desc = "Track changes to these player fields",
			type = 'multiselect',
			order = 20,
			-- these need to be of function type rather than string keys of members
			values = function(info) return addon:MakeFieldList() end,
			get = function(info,x) return GuildDelta_fields[x] end,
			set = function(info,x,val) GuildDelta_fields[x] = val end,
		},
		spacer1 = {
			name = '',
			type = 'description',
			cmdHidden = true,
			width = 'full',
			order = 29,
		},
		guilds = {
			name = "Guilds",
			desc = "Guilds for which a roster is known",
			type = 'select',
			order = 30,
			width = 'double',
			values = function(info) return addon:MakeGuildList() end,
			get = function(info) return guild_selection end,
			set = function(info,val) guild_selection = val end,
		},
		clearguild = {
			name = "Reset Guild",
			desc = "Erase stored data for selected guild; information will be scanned from scratch on next login.",
			type = 'execute',
			order = 32,
			disabled = function() return not guild_selection end,
			func = function()
				assert(type(guild_selection)=="string")
				local g,r = guild_selection:match("<([^>]+)> %- (.*)")
				local m = GuildDelta_memberdata[r]
				if m then
					m[g] = nil
				else
					addon:Print("Hm, error.", r, "can't be matched as a realm name.  Please report this as a bug, including the name of the realm and guild.")
				end
			end,
		},
	}
}


-----------------------------------------------------------------------------
-- other locals
local tinsert = table.insert
local chatframe, fieldlist, guild_selection
local function prt (...)
	return chatframe:AddMessage(...)
end
local function cprt (...)
	return prt(..., 255/255, 26/255, 160/255)
end

function addon:current_guild_info (N)
	local ret = {}
	for i = 1, N do
		local name,rank_as_string,_,level,_,_,publicnote,officernote = GetGuildRosterInfo(i)
		-- This technically does not work out to the same as A?B:C, combined
		-- with the logic below.  It does, however, still result in the entry
		-- not appearing in the returned table.
		publicnote = publicnote ~= "" and publicnote or nil
		officernote = officernote ~= "" and officernote or nil
		if name then -- redundant, but apparently happens on extreme lag
			tinsert(ret,
				{name   = name,
				 rank   = GuildDelta_fields.rank and rank_as_string or nil,
				 level  = GuildDelta_fields.level and level or nil,
				 pnote  = GuildDelta_fields.notes and publicnote or nil,
				 onote  = GuildDelta_fields.notes and officernote or nil,
				})
		end
	end
	table.sort(ret, function (l,r) return l.name < r.name end)
	return ret
end

function addon.options.args.print_chatframes.func()
	for i = 1, NUM_CHAT_WINDOWS do
		local cf = _G["ChatFrame"..i]
		if not cf then break end
		addon:Print(cf, "This is frame number", i)
	end
end

addon.options.args.note.name = 
"You can use the '/guilddelta' command to open the options window.\n\n"..
"The guild roster has already been scanned by the time you see this.  Therefore, "..
"if you make any changes to the Fields section below, you should probably relog "..
"immediately to begin tracking the changed fields.  Changes to the contents *OF* "..
"those fields will not be noticed until the first login after *that*.\n\n"


-----------------------------------------------------------------------------
addon = LibStub("AceAddon-3.0"):NewAddon(addon, "GuildDelta",
		        "AceConsole-3.0")

--[[
function addon:OnInitialize()
	self.OnInitialize = nil
end
]]

function addon:unload()
	LibStub("AceAddon-3.0").addons["GuildDelta"] = nil
	l10n = nil; addon = nil; prt = nil; cprt = nil
	-- put the userdata back so it counts as a Frame object again
	local ud = self[0]
	table.wipe(self)
	self[0] = ud
end

function addon:OnEnable()
	if not IsInGuild() then
		self:Print("You are not in a guild, not loading.")
		return self:unload()
	end

	AutoCompleteInfoDelayer:HookScript("OnFinished",
		function() self:RegisterEvent("GUILD_ROSTER_UPDATE") end)
	self:SetScript("OnEvent", self.GuildUpdate)

	self.options.args.version.name =
		"|cff30adffVersion " .. (GetAddOnMetadata("GuildDelta", "Version") or "?") .. "|r"
	LibStub("AceConfig-3.0"):RegisterOptionsTable("GuildDelta", self.options)
	--[[self.optionsFrame =]] LibStub("AceConfigDialog-3.0"):AddToBlizOptions("GuildDelta", "Guild Delta")
	self:RegisterChatCommand("guilddelta", "OnChatCommand")
	self:SetChat(false)
	self.OnEnable = nil
end


function addon:OnChatCommand (input)
	if not input or input:trim() == "" then
		LibStub("AceConfigDialog-3.0"):Open("GuildDelta")
	else
		LibStub("AceConfigCmd-3.0").HandleCommand(self, "guilddelta", "GuildDelta", input)
	end
end


function addon:SetChat (info, value)
	if info then
		local n = info.arg or value or 2
		if n == "" then n = 2 end
		GuildDelta_chatframe = n
	end
	if type(GuildDelta_chatframe) == "number" then
		chatframe = _G["ChatFrame"..GuildDelta_chatframe]
	else
		chatframe = _G[GuildDelta_chatframe] --[[fallback for safety]] or ChatFrame2
	end
	if type(info) ~= "boolean" then
		self:Print("Now printing to chat frame", GuildDelta_chatframe)
	end
end


function addon:GuildUpdate()
	local current_n = GetNumGuildMembers(true)
	if current_n <= 0 then
		-- catch the hell up, servers...
		return GuildRoster()
	end
	self:UnregisterEvent("GUILD_ROSTER_UPDATE")
	self:SetScript("OnEvent", nil)
	self.GuildUpdate = nil

	local guild, realm = (GetGuildInfo("player")), GetRealmName()
	local mdata = GuildDelta_memberdata
	if mdata[realm] 
	   and mdata[realm][guild]
	   and #(mdata[realm][guild]) > 0
	then
		-- moved the normal case below
	else
		-- new user, or new guild, or ...
		self:Print("GuildDelta initializing roster...")
		mdata[realm] = mdata[realm] or {}
		mdata[realm][guild] = self:current_guild_info(current_n)
		return
	end

	-- table.insert with notes if available
	local function tins (t, x)
		local s = x.name
		if x.onote and (x.onote ~= "") then
			s = s .. "(O: " .. x.onote .. ")"
		end
		if x.pnote and (x.pnote ~= "") then
			s = s .. "(" .. x.pnote .. ")"
		end
		tinsert(t, s)
	end

	-- build the current list
	local previous, current = mdata[realm][guild],
							  self:current_guild_info(current_n)
	local previous_n = #previous

	-- walk both and do equivalence comparison
	local joined, left, rank, level, notes = {}, {}, {}, {}, {}
	local p, c = 1, 1
	while p <= previous_n and c <= current_n do
		local P, C = previous[p], current[c]

		if P.name == C.name then
			-- normal case
			p = p + 1
			c = c + 1
			-- but can now compare details
			if C.rank and P.rank and (P.rank ~= C.rank) then
				tinsert(rank, {C.name, P.rank.." --> "..C.rank})
			end
			if C.level and P.level and (P.level ~= C.level) then
				tinsert(level, {C.name, P.level.." --> "..C.level})
			end
			if C.pnote and (P.pnote ~= C.pnote) then
				tinsert(notes, {C.name, C.pnote})
			end
			if C.onote and (P.onote ~= C.onote) then
				tinsert(notes, {C.name, "[O]: "..C.onote})
			end

		elseif P.name < C.name then
			-- entry at index p not at c -> somebody has left
			tins (left, P)
			p = p + 1

		else
			-- entry at index c not at p -> somebody has joined
			tins (joined, C)
			c = c + 1
		end
	end

	-- leftovers
	for i = p, previous_n do
		tins (left, previous[i])
	end
	for i = c, current_n do
		tins (joined, current[i])
	end

	-- show results
	local m
	if #left > 0 then
		m = l10n.LEFT .. table.concat(left, ", ")
		cprt(m)
	end

	if #joined > 0 then
		m = l10n.JOINED .. table.concat(joined, ", ")
		cprt(m)
	end

	if #rank > 0 then
		cprt(l10n.RANK)
		for i = 1, #rank do
			cprt(rank[i][1]..':  '..rank[i][2])
		end
	end

	if #level > 0 then
		cprt(l10n.LEVEL)
		for i = 1, #level do
			cprt(level[i][1]..':  '..level[i][2])
		end
	end

	if #notes > 0 then
		cprt(l10n.NOTES)
		for i = 1, #notes do
			cprt(notes[i][1]..': "'..notes[i][2]..'"')
		end
	end

	mdata[realm][guild] = current
end


function addon:MakeFieldList()
	if not fieldlist then
		fieldlist = {}
		for name in pairs(GuildDelta_fields) do
			fieldlist[name] = l10n["FIELD_"..name]
		end
	end
	return fieldlist
end

function addon:MakeGuildList()
	local list = {}
	local K
	for rname,rdata in pairs(GuildDelta_memberdata) do
		for g in pairs(rdata) do
			K = ("<%s> - %s"):format(g,rname)
			list[K] = K
		end
	end
	return list
end


-- vim:noet
