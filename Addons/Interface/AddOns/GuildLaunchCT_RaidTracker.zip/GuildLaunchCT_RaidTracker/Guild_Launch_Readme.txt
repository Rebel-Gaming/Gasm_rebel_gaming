This is a modded version that was started from Version 1.3.4 of the CT_RaidTracker(Eng/Ger/Fr=EQDkp Modded) Add-On.

This addon was originally developed by http://www.ctmod.net/ and was then Modded by Alason aka Freddy.

The original (non Guild Launch) mod can be found here: 
http://wow.curse-gaming.com/en/files/details/4197/ct-raidtracker-enggerfreqdkp-modded/

The mod was then modified to work other DKP systems:

http://wow-en.curse-gaming.com/downloads/details/5892/

We are using version 1.5.0beta17 of the MLdkp modded version as the basis for our mod going forward.

http://www.mldkp.net/index.php?option=com_smf&Itemid=10&topic=65.0

This Guild Launch version is another modded version modified to work with the Guild Launch Rapid Raid DKP System.

We chose to use this version, since we consider this mod to be "Best of Breed" when it comes to straightforward DKP imports. This version is the most up to date for boss tracking. We preselect a few options to work better with our system and repackage the mod.

This mod is modified to work specifically with the Guild Launch rapid raid system available to guilds hosted by Guild Launch at http://www.guildlaunch.com/ Guild Launch chose to create a new fork of this mod in order to implement our own changes seperate from the original mod and give us the ability to introduce features specific to our Rapid Raid DKP system. In addition the fork allows us to control the version of this mod that we support.

Support for Guild Launch guilds, and the usage of this mod with Guild Launch guilds, is available at http://www.guildlaunch.com/support/ or at support@guildlaunch.com

Enjoy!
Stephen
http://www.guildlaunch.com/



