﻿local ldb = LibStub:GetLibrary("LibDataBroker-1.1")
local FL = LibStub:GetLibrary("LibFishing-1.0")
local LT = LibStub("LibTourist-3.0")
local Crayon = LibStub("LibCrayon-3.0")

local switchSetting = "ClickToSwitch";
local function MenuInit()
   FishingBuddy.MakeDropDown(FBConstants.CLICKTOSWITCH_ONOFF, switchSetting)
end

local function Do_OnClick(self, button)
	if ( FishingBuddy and FishingBuddy.IsLoaded() ) then
		if ( button == "LeftButton" ) then
			if ( FishingBuddy.IsSwitchClick() ) then
				FishingBuddy.Command(FBConstants.SWITCH)
			else
				FishingBuddy.Command("")
			end
		else
			local menu = FB_Broker_Menu
			if (not menu) then
				menu = CreateFrame("FRAME", "FB_Broker_Menu", self, "UIDropDownMenuTemplate")
			end
			UIDropDownMenu_Initialize(menu, MenuInit, "MENU")
			menu.point = "TOPRIGHT"
			menu.relativePoint = "CENTER"
			ToggleDropDownMenu(1, nil, menu, self, 0, 0)
		end
	end
end

local dataobj = ldb:NewDataObject("Fishing Broker", {
    type = "launcher",
    icon = "Interface\\Icons\\Trade_Fishing",
    OnClick = Do_OnClick,
    tocname = "FB_Broker",
    label = "Skill",
})

dataobj.lastSkillCheck = nil

local f = CreateFrame("frame")
f.dataobj = dataobj

f:RegisterEvent("SKILL_LINES_CHANGED")
f:RegisterEvent("ZONE_CHANGED")
f:RegisterEvent("ZONE_CHANGED_INDOORS")
f:RegisterEvent("ZONE_CHANGED_NEW_AREA")
f:RegisterEvent("LOOT_OPENED")


local tab = FBConstants
function dataobj:OnTooltipShow()
    local hint
    if ( FishingBuddy and FishingBuddy.IsLoaded() ) then
		if ( FishingBuddy.GetSettingBool(switchSetting) ) then
			hint = tab.TOOLTIP_HINTSWITCH
		else
			hint = tab.TOOLTIP_HINTTOGGLE
		end
	else
		local _, fishing = FL:GetFishingSkillInfo()
		hint = CHAT_MSG_SKILL.." ("..fishing..")"
	end
	self:AddLine(Crayon:Green(hint))
end

function dataobj:UpdateSkill()
    local line = FL:GetFishingSkillLine(1)
    local needed
    self.lastSkillCheck, self.caughtSoFar, needed = FL:GetSkillUpInfo(self.lastSkillCheck, self.caughtSoFar)
	if ( needed ) then
		line = line.." ("..self.caughtSoFar.."/~"..needed..")"
	end
	self.text = line
	self.label = line
end

f:SetScript("OnEvent", function(self, event, ...)
	if ( IsFishingLoot() and event == "LOOT_OPENED" ) then
	 	if ( not f.dataobj.caughtSoFar ) then
	 		f.dataobj.caughtSoFar = 1
	 	else
			f.dataobj.caughtSoFar = f.dataobj.caughtSoFar + 1
		end
	end
	f.dataobj:UpdateSkill()
end)

dataobj:UpdateSkill()
