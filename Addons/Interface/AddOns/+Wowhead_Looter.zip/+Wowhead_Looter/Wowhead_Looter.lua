-----------------------------------------
--                                     --
--     W o w h e a d   L o o t e r     --
--                                     --
--                                     --
--      Patch: 3.3.3a (11723)          --
--    Updated: June 1, 2010            --
--                                     --
--    Authors: mystadio, tecnobrat     --
--     E-mail: feedback@wowhead.com    --
--                                     --
-----------------------------------------

WL_NAME    = "Wowhead Looter";
WL_VERSION = 30316;



-- SavedVariables
wlVersion, wlUploaded, wlStats, wlExportData, wlRealmList = 0, 0, "", "", {};
wlAuction, wlEvent, wlItemSuffix, wlObject, wlProfile, wlUnit = {}, {}, {}, {}, {}, {};
wlGlobalSetting = {};

-- SavedVariablesPerCharacter
wlSetting = {};
wlScans = {
	quests = {},
	recipes = {},
	pets = { MOUNT = "", CRITTER = "" },
	skills = "",
	titles = "",
	timePlayerTotal = 0,
	timePlayedWhen = nil,
};



local _G = _G;
local CalendarGetDate = _G.CalendarGetDate;
local CanMerchantRepair = _G.CanMerchantRepair;
local CheckInteractDistance = _G.CheckInteractDistance;
local CollapseFactionHeader = _G.CollapseFactionHeader;
local CollapseQuestHeader = _G.CollapseQuestHeader;
local CollapseTradeSkillSubClass = _G.CollapseTradeSkillSubClass;
local ExpandFactionHeader = _G.ExpandFactionHeader;
local ExpandQuestHeader = _G.ExpandQuestHeader;
local ExpandTradeSkillSubClass = _G.ExpandTradeSkillSubClass;
local GetAddOnInfo = _G.GetAddOnInfo;
local GetAddOnMetadata = _G.GetAddOnMetadata;
local GetAuctionItemInfo = _G.GetAuctionItemInfo;
local GetAuctionItemLink = _G.GetAuctionItemLink;
local GetBuildInfo = _G.GetBuildInfo;
local GetContainerItemLink = _G.GetContainerItemLink;
local GetCurrentMapDungeonLevel = _G.GetCurrentMapDungeonLevel;
local GetCursorPosition = _G.GetCursorPosition;
local GetCVar = _G.GetCVar;
local GetFactionInfo = _G.GetFactionInfo;
local GetGameTime = _G.GetGameTime;
local GetGossipOptions = _G.GetGossipOptions;
local GetInstanceInfo = _G.GetInstanceInfo;
local GetItemCount = _G.GetItemCount;
local GetItemInfo = _G.GetItemInfo;
local GetLanguageByIndex = _G.GetLanguageByIndex;
local GetLocale = _G.GetLocale;
local GetLootSlotInfo = _G.GetLootSlotInfo;
local GetLootSlotLink = _G.GetLootSlotLink;
local GetMerchantItemCostInfo = _G.GetMerchantItemCostInfo;
local GetMerchantItemCostItem = _G.GetMerchantItemCostItem;
local GetMerchantItemInfo = _G.GetMerchantItemInfo;
local GetMerchantItemLink = _G.GetMerchantItemLink;
local GetMerchantNumItems = _G.GetMerchantNumItems;
local GetNetStats = _G.GetNetStats;
local GetNumAddOns = _G.GetNumAddOns;
local GetNumDungeonMapLevels = _G.GetNumDungeonMapLevels;
local GetNumFactions = _G.GetNumFactions;
local GetNumLanguages = _G.GetNumLanguages;
local GetNumLootItems = _G.GetNumLootItems;
local GetNumPartyMembers = _G.GetNumPartyMembers;
local GetNumQuestLeaderBoards = _G.GetNumQuestLeaderBoards;
local GetNumQuestLogEntries = _G.GetNumQuestLogEntries;
local GetNumRaidMembers = _G.GetNumRaidMembers;
local GetNumTradeSkills = _G.GetNumTradeSkills;
local GetNumTrainerServices = _G.GetNumTrainerServices;
local GetPetActionInfo = GetPetActionInfo;
local GetPlayerMapPosition = _G.GetPlayerMapPosition;
local GetProgressText = _G.GetProgressText;
local GetQuestsCompleted = _G.GetQuestsCompleted;
local GetQuestLink = _G.GetQuestLink;
local GetQuestLogLeaderBoard = _G.GetQuestLogLeaderBoard;
local GetQuestLogPushable = _G.GetQuestLogPushable;
local GetQuestLogSelection = _G.GetQuestLogSelection;
local GetQuestLogTimeLeft = _G.GetQuestLogTimeLeft;
local GetQuestLogTitle = _G.GetQuestLogTitle;
local GetRealmName = _G.GetRealmName;
local GetRealZoneText = _G.GetRealZoneText;
local GetRewardText = _G.GetRewardText;
local GetSpellInfo = _G.GetSpellInfo;
local GetTime = _G.GetTime;
local GetTitleText = _G.GetTitleText;
local GetTradeSkillInfo = _G.GetTradeSkillInfo;
local GetTradeSkillLine = _G.GetTradeSkillLine;
local GetTradeSkillRecipeLink = _G.GetTradeSkillRecipeLink;
local GetTrainerServiceCost = _G.GetTrainerServiceCost;
local GetTrainerServiceInfo = _G.GetTrainerServiceInfo;
local GetTrainerServiceLevelReq = _G.GetTrainerServiceLevelReq;
local GetTrainerServiceSkillReq = _G.GetTrainerServiceSkillReq;
local GetTrainerServiceTypeFilter = _G.GetTrainerServiceTypeFilter;
local IsEquippedItem = _G.IsEquippedItem;
local IsFishingLoot = _G.IsFishingLoot;
local ItemTextGetItem = _G.ItemTextGetItem;
local LootSlotIsCoin = _G.LootSlotIsCoin;
local LootSlotIsItem = _G.LootSlotIsItem;
local QueryQuestsCompleted = _G.QueryQuestsCompleted;
local SelectQuestLogEntry = _G.SelectQuestLogEntry;
local SendAddonMessage = _G.SendAddonMessage;
local SetDungeonMapLevel = _G.SetDungeonMapLevel;
local SetMapToCurrentZone = _G.SetMapToCurrentZone;
local SetTrainerServiceTypeFilter = _G.SetTrainerServiceTypeFilter;
local UnitClass = _G.UnitClass;
local UnitExists = _G.UnitExists;
local UnitFactionGroup = _G.UnitFactionGroup;
local UnitGUID = _G.UnitGUID;
local UnitHealthMax = _G.UnitHealthMax;
local UnitIsDead = _G.UnitIsDead;
local UnitIsFriend = _G.UnitIsFriend;
local UnitIsPlayer = _G.UnitIsPlayer;
local UnitIsTapped = _G.UnitIsTapped;
local UnitIsTappedByPlayer = _G.UnitIsTappedByPlayer;
local UnitIsTrivial = _G.UnitIsTrivial;
local UnitLevel = _G.UnitLevel;
local UnitManaMax = _G.UnitManaMax;
local UnitName = _G.UnitName;
local UnitPlayerControlled = _G.UnitPlayerControlled;
local UnitPowerType = _G.UnitPowerType;
local UnitRace = _G.UnitRace;
local UnitReaction = _G.UnitReaction;
local UnitSex = _G.UnitSex;

-- Hooks
local wlDefaultAcceptQuest, wlDefaultCompleteQuest, wlDefaultGetQuestReward, wlDefaultQuestFrameRewardPanel_OnShow;

-- Local Variables
local wlTracker = {};
local wlNpcInfo = {};
local wlLootCooldown = {};
local wlCollapsedHeaders = {};
local wlFaction = {};
local wlCurrentMindControlTarget = nil;
local wlTimers = {};
local wlMessages = {};
local wlMsgCollected = nil;
local wlUserCollected = false;

local wlId = nil;
local wlN = 0;
local wlEventId = 1;

local wlRepDiscount = {
	[5] = 0.95, -- Friend:   5%
	[6] = 0.90, -- Honored: 10%
	[7] = 0.85, -- Revered: 15%
	[8] = 0.80, -- Exalted: 20%
};

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlGetNextEventId()
	if not wlEvent or not wlEvent[wlId] or not wlEvent[wlId][wlN] or not wlEvent[wlId][wlN][wlEventId] then
		return wlEventId;
	else
		wlEventId = wlEventId + 1;
		return wlEventId;
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_PLAYER_LOGIN(self)
	if wlVersion ~= WL_VERSION or wlUploaded == 1 then
		wlReset();
	end

	wlHook();
	wlClearTracker("quest", "rep", "spell");

	wlRealmList[GetCVar("realmList") or "nil"] = 1;

	wlId = wlConcat(wlSelectOne(1, UnitName("player")), GetRealmName());

	wlUpdateVariable(wlProfile, wlId, "init", {
		faction = UnitFactionGroup("player"),
		race    = select(2, UnitRace("player")),
		class   = select(2, UnitClass("player")),
		sex     = UnitSex("player"),
		n       = 0,
	});

	wlN = wlUpdateVariable(wlProfile, wlId, "n", "add", 1);

	wlUpdateVariable(wlEvent, wlId, wlN, wlGetNextEventId(), "set", {
		what = "login",
		date = wlConcat(wlGetDate()),
	});

	-- Restore settings
	if wlSetting.locMap then
		wlLocMapFrame:Show();
	end

	if wlSetting.locTooltip then
		wlLocTooltipFrame:Show();
	end

	if wlSetting.idTooltip then
		wlIdTooltipFrame:Show();
	end

	-- Temp fix: moving nospam to global (30311)
	if type(wlGlobalSetting.noSpam) == "nil" then
		wlGlobalSetting.noSpam = wlSetting.noSpam;
		wlSetting.noSpam = nil;
	end

	wlNumQuestCompleted = wlGetNumLoremasterQuestCompleted();

	wlScans.timePlayedWhen = nil;
	wlTimers.autoCollect = wlGetTime() + 10000; -- 10 seconds timeout

	wlMessage(WL_LOADED:format(WL_NAME, WL_VERSION), true);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_PLAYER_LOGOUT(self)
	wlRefreshExportData();
	wlUnhook();
	wlRegisterStats();
end

--**--**--**--**--**--**--**-- **--**--**--**--**--**--**--**--**--**--**--



-------------------------
-------------------------
--                     --
--   UNIT  FUNCTIONS   --
--                     --
-------------------------
-------------------------

function wlUnitName(unit)
	local name = UnitName(unit);

	if wlIsValidName(name) then
		return name;
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlUnitGUID(unit)
	local id, kind = wlParseGUID(UnitGUID(unit));

	if id and kind == "npc" then
		wlUpdateVariable(wlNpcInfo, name, "time", "set", wlGetTime());
		wlUpdateVariable(wlNpcInfo, name, "id", "set", id);
		wlUpdateVariable(wlNpcInfo, name, "isTrivial", "set", UnitIsTrivial(unit));
	end

	return id, kind;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_PLAYER_TARGET_CHANGED(self)
	if not UnitExists("target") or UnitPlayerControlled("target") then
		return;
	end

	local id, kind = wlUnitGUID("target");

	if not id or kind ~= "npc" then
		return;
	end

	wlUpdateVariable(wlUnit, id, "init", {
		class = select(2, UnitClass("target")),
	});

	wlUpdateVariable(wlUnit, id, "sex", UnitSex("target"), "add", 1);

	if not wlUnit[id].faction then
		wlUnit[id].faction = wlUnitFaction("target");
	end

	wlUpdateVariable(wlUnit, id, "reaction", wlConcat(UnitLevel("player"), UnitFactionGroup("player"), UnitReaction("player", "target")), "init", wlGetTime());

	local dd, level = wlGetInstanceDifficulty(), UnitLevel("target");

	wlUpdateVariable(wlUnit, id, "spec", dd, level, "init", {
		health    = UnitHealthMax("target"),
		powermax  = UnitManaMax("target"),
		powertype = UnitPowerType("target"),
	});
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlUnitIsClose(unit)
	return CheckInteractDistance(unit, 1) and CheckInteractDistance(unit, 2) and CheckInteractDistance(unit, 3) and CheckInteractDistance(unit, 4);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlRegisterUnitLocation(id, level)
	local dd = wlGetInstanceDifficulty();
	local zone, x, y, dl = wlGetLocation();

	wlUpdateVariable(wlUnit, id, "spec", dd, level, "loc", zone, "init", { n = 0 });

	local i = wlGetLocationIndex(wlUnit[id].spec[dd][level].loc[zone], x, y, dl, 5);
	if i then
		local n = wlUnit[id].spec[dd][level].loc[zone][i].n;

		wlUnit[id].spec[dd][level].loc[zone][i].x = math.floor((wlUnit[id].spec[dd][level].loc[zone][i].x * n + x) / (n + 1) + 0.5);
		wlUnit[id].spec[dd][level].loc[zone][i].y = math.floor((wlUnit[id].spec[dd][level].loc[zone][i].y * n + y) / (n + 1) + 0.5);
		wlUnit[id].spec[dd][level].loc[zone][i].n = n + 1;
	else
		i = wlUpdateVariable(wlUnit, id, "spec", dd, level, "loc", zone, "n", "add", 1);
		wlUpdateVariable(wlUnit, id, "spec", dd, level, "loc", zone, i, "set", {
			x  = x,
			y  = y,
			dl = dl,
			n  = 1,
		});
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_CHAT_MSG_MONSTER_SAY(self, text, name, language)
	wlRegisterUnitQuote(name, "say", language, text);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_CHAT_MSG_MONSTER_WHISPER(self, text, name, language)
	wlRegisterUnitQuote(name, "whisper", language, text);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_CHAT_MSG_MONSTER_YELL(self, text, name, language)
	wlRegisterUnitQuote(name, "yell", language, text);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlLanguage = nil;
function wlRegisterUnitQuote(name, how, language, text)
	-- Init
	if not wlLanguage then
		wlLanguage = {};

		for i = 1, GetNumLanguages() do
			wlLanguage[GetLanguageByIndex(i)] = 1;
		end	
	end

	-- language -> language known
	if (language ~= "" and not wlLanguage[language]) or not name or not wlNpcInfo[name] or not wlUnit[wlNpcInfo[name].id] then
		return;
	end

	wlUpdateVariable(wlUnit, wlNpcInfo[name].id, "quote", how, text, "set", language);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_GOSSIP_SHOW(self)
	local gossips = { GetGossipOptions() };

	for i = 1, #gossips, 2 do
		if gossips[i + 1] ~= "gossip" then
			wlRegisterUnitGossip(gossips[i + 1]);
		end
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_AUCTION_HOUSE_SHOW(self)
	wlRegisterUnitGossip("auctioneer");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_BANKFRAME_OPENED(self)
	wlRegisterUnitGossip("banker");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_BATTLEFIELDS_SHOW(self)
	wlRegisterUnitGossip("battlemaster");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_CONFIRM_BINDER(self)
	wlRegisterUnitGossip("binder");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_CONFIRM_PET_UNLEARN(self)
	wlRegisterUnitGossip("pettrainer");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_CONFIRM_TALENT_WIPE(self)
	wlRegisterUnitGossip("talentwiper");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_GOSSIP_ENTER_CODE(self, codeId)
	wlRegisterUnitGossip("code" .. codeId);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_OPEN_TABARD_FRAME(self)
	wlRegisterUnitGossip("tabard");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_PET_STABLE_SHOW(self)
	wlRegisterUnitGossip("stable");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_TAXIMAP_OPENED(self)
	wlRegisterUnitGossip("taxi");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlRegisterUnitGossip(gossip)
	if not gossip or gossip == "" then
		return;
	end

	local id, kind = wlUnitGUID("npc");

	if not id or kind ~= "npc" or not wlUnit[id] then
		return;
	end

	wlUpdateVariable(wlUnit, id, "gossip", gossip, "add", 1);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_PET_BAR_UPDATE(self)
	wlCurrentMindControlTarget = nil;
	if wlTracker.spell and wlTracker.spell.time and wlTracker.spell.action == "MindControl" and wlTracker.spell.event == "SUCCEEDED" then
		local id, kind = wlUnitGUID("pet");

		if id and kind == "npc" and wlUnit[id] and id == wlTracker.spell.id then
			wlCurrentMindControlTarget = id;
		end

		wlClearTracker("spell");
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_MERCHANT_SHOW(self)
	wlRegisterUnitGossip("vendor");
	wlEvent_MERCHANT_UPDATE(self);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlMerchantItemList, wlMerchantCurrencies = {}, {};
function wlEvent_MERCHANT_UPDATE(self)
	local id, kind = wlUnitGUID("npc");

	if not id or kind ~= "npc" or not wlUnit[id] then
		return;
	end

	local standing = select(2, wlUnitFaction("npc"));
	local noError = true;
	wlTableClear(wlMerchantItemList);

	for slot = 1, GetMerchantNumItems() do
		local _, _, price, stack, numAvailable, _, extendedCost = GetMerchantItemInfo(slot);
		local id, subId = wlParseItemLink(GetMerchantItemLink(slot));
		if id ~= 0 then
			if standing and wlRepDiscount[standing] then
				price = math.ceil(price / wlRepDiscount[standing]);
			end

			if extendedCost then
				local honorPoints, arenaPoints, itemCount = GetMerchantItemCostInfo(slot);
				local personalRating = 0;

				wlGameTooltip:ClearLines();
				wlGameTooltip:SetMerchantItem(slot);

				for i = 2, wlGameTooltip:NumLines() do
					local line = getglobal("wlGameTooltipTextLeft" .. i);

					if not line then
						break;
					end

					local pts = wlParseString("^" .. ITEM_REQ_ARENA_RATING .. "$", line:GetText());
					if pts then
						personalRating = pts;
						break;
					end

					local pts = wlParseString("^" .. ITEM_REQ_ARENA_RATING_3V3 .. "$", line:GetText());
					if pts then
						personalRating = pts + 1000000; -- 3v3 or 5v5 flag
						break;
					end

					local pts = wlParseString("^" .. ITEM_REQ_ARENA_RATING_5V5 .. "$", line:GetText());
					if pts then
						personalRating = pts + 2000000; -- 5v5 flag
						break;
					end
				end

				extendedCost = honorPoints .. "#".. arenaPoints .. "#".. personalRating;

				if itemCount > 0 then
					-- Clear array
					while table.remove(wlMerchantCurrencies) do end

					for i = 1, itemCount do
						local _, qty, currency = GetMerchantItemCostItem(slot, i);
						local currencyId = wlParseItemLink(currency);

						if not currencyId or currencyId == "" or currencyId == 0 or not qty or qty == "" or qty == 0 then
							noError = false;
							break;
						end

						table.insert(wlMerchantCurrencies, { currencyId, qty });
					end

					if not noError then
						break;
					end

					table.sort(wlMerchantCurrencies, function(l, r) return l[1] < r[1] end);

					for _, currency in ipairs(wlMerchantCurrencies) do
						extendedCost = extendedCost .. "#" .. currency[1] .. "x" .. currency[2];
					end
				end

				price = wlConcat(price, extendedCost);
			end

			wlMerchantItemList[wlConcat(id, subId, stack, price)] = numAvailable;
		end
	end

	if noError then
		for link, numAvailable in pairs(wlMerchantItemList) do
			wlUpdateVariable(wlUnit, id, "merchant", link, "max", numAvailable);
		end
	end

	if CanMerchantRepair() then
		wlUpdateVariable(wlUnit, id, "canRepair", "init", 1);
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_TRAINER_SHOW(self)
	wlRegisterUnitGossip("trainer");

	local id, kind = wlUnitGUID("npc");

	if not id or kind ~= "npc" or not wlUnit[id] then
		return;
	end

	local fAvail, fUnavail, fUsed = GetTrainerServiceTypeFilter("available"), GetTrainerServiceTypeFilter("unavailable"), GetTrainerServiceTypeFilter("used");
	SetTrainerServiceTypeFilter("available", 1);
	SetTrainerServiceTypeFilter("unavailable", 1);
	SetTrainerServiceTypeFilter("used", 1);

	local standing = select(2, wlUnitFaction("npc"));

	for i = 1, GetNumTrainerServices() do
		local spell, _, category = GetTrainerServiceInfo(i);

		if spell and category then
			if category ~= "header" then
				wlGameTooltip:SetTrainerService(i);
				local spellId = select(3, wlGameTooltip:GetSpell());

				local skill, skillRank = GetTrainerServiceSkillReq(i);
				if not skill then
					skill = "";
					skillRank = 0;
				end

				local level = GetTrainerServiceLevelReq(i) or 0;
				local cost  = GetTrainerServiceCost(i)     or 0;

				if standing and wlRepDiscount[standing] then
					cost = math.ceil(cost / wlRepDiscount[standing]);
				end

				wlUpdateVariable(wlUnit, id, "training", wlSelectOne(2, UnitClass("player")), wlConcat(spellId, skill, skillRank, level, cost), "init", 1);
			end
		end
	end

	SetTrainerServiceTypeFilter("available", fAvail or 0);
	SetTrainerServiceTypeFilter("unavailable", fUnavail or 0);
	SetTrainerServiceTypeFilter("used", fUsed or 0);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_CHAT_MSG_MONSTER_EMOTE(self, emote, name)
	if emote == WL_RUNSAWAY then
		if not name or not wlNpcInfo[name] or not wlUnit[wlNpcInfo[name].id] then
			return;
		end

		wlUpdateVariable(wlUnit, wlNpcInfo[name].id, "runsaway", "init", 1);
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlNpcFlags = bit.bor(COMBATLOG_OBJECT_TYPE_NPC, COMBATLOG_OBJECT_TYPE_GUARDIAN, COMBATLOG_OBJECT_CONTROL_NPC, COMBATLOG_OBJECT_AFFILIATION_OUTSIDER);
local wlMindControlFlags = bit.bor(COMBATLOG_OBJECT_TYPE_PET, COMBATLOG_OBJECT_CONTROL_PLAYER, COMBATLOG_OBJECT_REACTION_FRIENDLY, COMBATLOG_OBJECT_AFFILIATION_MINE);

function wlEvent_COMBAT_LOG_EVENT_UNFILTERED(self, timestamp, event, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, ...)
	if event == "PARTY_KILL" then
		wlClearTracker("rep");

		local id = wlParseGUID(destGUID);

		-- npc check
		if not string.match(destGUID, "^0xF.[35]") or not id or id == 0 or not wlUnit[id] then
			return;
		end

		local now = wlGetTime();
		if wlNpcInfo[destName] and wlNpcInfo[destName].id == id and wlIsValidInterval(wlNpcInfo[destName].time, now, 15000) then
			wlTracker.rep.time  = now;
			wlTracker.rep.id    = id;
			wlTracker.rep.flags = wlNpcInfo[destName].isTrivial and 1 or 0;
		end

	elseif event == "SPELL_CAST_SUCCESS" and sourceGUID == UnitGUID("player") and select(1, ...) == 30427 then
		wlClearTracker("spell");
		wlTracker.spell.time   = wlGetTime();
		wlTracker.spell.action = 30427;

	elseif event == "SPELL_CAST_START" or event == "SPELL_CAST_SUCCESS" then
		local unitId = wlParseGUID(sourceGUID);
		local spellId, spellName = ...;

		-- npc check
		if not string.match(sourceGUID, "^0xF.[35]") or not unitId or unitId == 0 or not wlUnit[unitId] then
			return;
		end

		if bit.band(wlNpcFlags, sourceFlags) ~= 0 then
			wlUpdateVariable(wlUnit, unitId, "spec", wlGetInstanceDifficulty(), "spell", spellId, "add", 1);

		elseif bit.band(wlMindControlFlags, sourceFlags) ~= 0 and wlCurrentMindControlTarget == id then

			for i = 1, NUM_PET_ACTION_SLOTS do
				local petSpellName, _, _, _, autoCastAllowed = GetPetActionInfo(i);

				if petSpellName == spellName then
					wlUpdateVariable(wlUnit, unitId, "spec", wlGetInstanceDifficulty(), "mcspell", i, "init", wlConcat(spellId, autoCastAllowed or 0));
					break;
				end
			end
		end

	elseif event == "UNIT_DISSIPATES" then
		-- Register cloud's location
		if wlTracker.spell.action == 30427 and wlIsValidInterval(wlTracker.spell.time or 0, wlGetTime(), 5000) then
			local unitId = wlParseGUID(destGUID);
			wlRegisterUnitLocation(unitId, 1);

			wlClearTracker("spell");
		end
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--



----------------------------
----------------------------
--                        --
--   FACTION  FUNCTIONS   --
--                        --
----------------------------
----------------------------

local wlEvent_UPDATE_FACTION_running = false;
function wlEvent_UPDATE_FACTION(self)
	if wlEvent_UPDATE_FACTION_running then
		return;
	end

	wlEvent_UPDATE_FACTION_running = true;
	self:UnregisterEvent("UPDATE_FACTION");

	wlTableClear(wlCollapsedHeaders);

	local i = 1;
	while i <= GetNumFactions() do
		local name, _, standing, _, _, _, _, _, isHeader, isCollapsed = GetFactionInfo(i);

		if name then
			if isHeader then
				if isCollapsed then
					ExpandFactionHeader(i);
					wlCollapsedHeaders[name] = 1;
				end
			else
				wlFaction[name] = standing;
			end
		end

		i = i + 1;
	end

	-- Restore headers
	i = 1;
	while i <= GetNumFactions() do
		local name, _, _, _, _, _, _, _, isHeader = GetFactionInfo(i);

		if name and isHeader and wlCollapsedHeaders[name] then
			CollapseFactionHeader(i);
		end

		i = i + 1;
	end

	self:RegisterEvent("UPDATE_FACTION");
	wlEvent_UPDATE_FACTION_running = false;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlUnitFaction(unit)
	wlGameTooltip:ClearLines();
	wlGameTooltip:SetUnit(unit);

	for line = 2, wlGameTooltip:NumLines() do
		local faction = getglobal("wlGameTooltipTextLeft" .. line):GetText();
		if wlFaction[faction] then
			return faction, wlFaction[faction];
		end
	end

	return nil, nil;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--



---------------------------
---------------------------
--                       --
--   OBJECT  FUNCTIONS   --
--                       --
---------------------------
---------------------------

function wlEvent_ITEM_TEXT_BEGIN(self)
	local id, kind = wlUnitGUID("npc");

	if wlUnitName("npc") == ItemTextGetItem() and id and kind == "object" then
		wlRegisterObject(id);
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_MAIL_SHOW(self)
	wlRegisterObject(wlUnitGUID("npc"));
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlRegisterObject(id)
	if not id then
		return;
	end

	local zone, x, y, dl = wlGetLocation();

	zone = wlConcat(wlGetInstanceDifficulty(), zone);

	wlUpdateVariable(wlObject, id, zone, "init", { n = 0 });

	local i = wlGetLocationIndex(wlObject[id][zone], x, y, dl, 5);
	if i then
		local n = wlObject[id][zone][i].n;

		wlObject[id][zone][i].x = math.floor((wlObject[id][zone][i].x * n + x) / (n + 1) + 0.5);
		wlObject[id][zone][i].y = math.floor((wlObject[id][zone][i].y * n + y) / (n + 1) + 0.5);
		wlObject[id][zone][i].n = n + 1;
	else
		i = wlUpdateVariable(wlObject, id, zone, "n", "add", 1);
		wlUpdateVariable(wlObject, id, zone, i, "set", {
			x  = x,
			y  = y,
			dl = dl,
			n  = 1,
		});
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--



--------------------------
--------------------------
--                      --
--   QUEST  FUNCTIONS   --
--                      --
--------------------------
--------------------------

local wlQuestLog, wlQuestObjectives, wlCurrentQuestObj = {}, { {}, {} }, 1;
local wlQuestHasProgressText, wlNumQuestCompleted = false, -1;

local wlEvent_QUEST_LOG_UPDATE_running = false;
function wlEvent_QUEST_LOG_UPDATE(self)
	if wlEvent_QUEST_LOG_UPDATE_running or not wlEvent or not wlId or not wlEvent[wlId] or not wlN or not wlEvent[wlId][wlN] then
		return;
	end

	wlEvent_QUEST_LOG_UPDATE_running = true;

	wlGlobalUnregister("QUEST_LOG_UPDATE");

	local eventId = wlGetNextEventId();

	local selectedQuest = GetQuestLogSelection();
	wlTableClear(wlCollapsedHeaders);

	-- "erase" all
	for k, _ in ipairs(wlQuestLog) do
		wlQuestLog[k].id = nil;
	end

	wlCurrentQuestObj = 3 - wlCurrentQuestObj; -- toggle: 1 <-> 2

	for k, _ in ipairs(wlQuestObjectives[wlCurrentQuestObj]) do
		wlQuestObjectives[wlCurrentQuestObj][k].questId = nil;
	end


	local i, cQ, cO = 1, 1, 1;
	while i <= GetNumQuestLogEntries() do
		local title, _, _, _, isHeader, isCollapsed = GetQuestLogTitle(i);

		if title then
			if isHeader then
				if isCollapsed then
					ExpandQuestHeader(i);
					wlCollapsedHeaders[title] = 1;
				end
			else
				SelectQuestLogEntry(i);
				local questId = wlSelectOne(1, wlParseQuestLink(GetQuestLink(i)));

				wlUpdateVariable(wlQuestLog, cQ, "title", "set", title);

				wlQuestLog[cQ].id         = questId;
				wlQuestLog[cQ].timer      = math.ceil((GetQuestLogTimeLeft() or 0) / 15) * 15;
				wlQuestLog[cQ].sharable   = GetQuestLogPushable() and 1 or 0;

				cQ = cQ + 1;

				for objId = 1, GetNumQuestLeaderBoards() do
					local _, kind, done = GetQuestLogLeaderBoard(objId);

					if kind == "item" or kind == "event" then
						wlUpdateVariable(wlQuestObjectives, wlCurrentQuestObj, cO, "questId", "set", questId);

						wlQuestObjectives[wlCurrentQuestObj][cO].objId = objId;
						wlQuestObjectives[wlCurrentQuestObj][cO].done  = done;

						cO = cO + 1;

						local index = wlTableFind(wlQuestObjectives[3 - wlCurrentQuestObj], function(a, questId, objId) return a.questId == questId and a.objId == objId; end, questId, objId)
						if (index and wlQuestObjectives[3 - wlCurrentQuestObj][index].done ~= done) or (not index and not done) then
							wlUpdateVariable(wlEvent, wlId, wlN, eventId, "initArray", 0);
							wlEvent[wlId][wlN][eventId].what = "questStatus";
							wlEvent[wlId][wlN][eventId][wlConcat(questId, objId, done or 0)] = done and kind == "event" and wlConcat(wlGetLocation()) or 1;
						end
					end
				end

			end
		end

		i = i + 1;
	end

	-- Restore headers
	i = 1;
	while i <= GetNumQuestLogEntries() do
		local title, _, _, _, isHeader = GetQuestLogTitle(i);

		if title and isHeader and wlCollapsedHeaders[title] then
			CollapseQuestHeader(i);
		end

		i = i + 1;
	end

	SelectQuestLogEntry(selectedQuest);

	wlGlobalRegister("QUEST_LOG_UPDATE");

	-- abandoned quest
	for k, v in ipairs(wlQuestObjectives[3 - wlCurrentQuestObj]) do
		if v.questId and not v.done then
			local index = wlTableFind(wlQuestObjectives[wlCurrentQuestObj], function(a, questId, objId) return a.questId == questId and a.objId == objId; end, v.questId, v.objId)
			if not index then
				wlUpdateVariable(wlEvent, wlId, wlN, eventId, "initArray", 0);
				wlEvent[wlId][wlN][eventId].what = "questStatus";
				wlEvent[wlId][wlN][eventId][wlConcat(v.questId, v.objId, 1)] = 1;
			end
		end
	end

	if wlTracker.quest.time and wlTracker.quest.action == "accept" then
		i = wlTableFind(wlQuestLog, function (a, v) return a.id and a.title == v; end, wlTracker.quest.title);
		if i and wlIsValidInterval(wlTracker.quest.time, wlGetTime(), 5000) then
			wlRegisterQuestAccept(i);
		end
	end

	wlEvent_QUEST_LOG_UPDATE_running = false;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlQuestAchievements = { 1677, 1676, 1678, 1680, 1358, 36, 1356, 38, 1359, 1357, 39, 40, 33, 36, 34, 38, 35, 37, 39, 40, 1189, 1191, 1193, 1195, 1190, 1192, 1194, 1271, 1272, 1193, 1195, 1190, 1273, 1194 };
function wlGetNumLoremasterQuestCompleted()
	local nQuestCompleted = 0;

	for _, id in ipairs(wlQuestAchievements) do
		nQuestCompleted = nQuestCompleted + wlSelectOne(4, GetAchievementCriteriaInfo(id, 1));
	end

	return nQuestCompleted;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlAcceptQuest(...)  -- Accept
	local success, msg = pcall(wlSecureAcceptQuest);

	if not success then
		error(msg);
	end

	return wlDefaultAcceptQuest(...);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlSecureAcceptQuest()
	local name, id, kind = wlUnitName("npc"), wlUnitGUID("npc");

	if not name or not id then
		return;
	end

	if kind == "object" then
		wlRegisterObject(id);
	end

	wlTracker.quest.time        = wlGetTime();
	wlTracker.quest.action      = "accept";
	wlTracker.quest.title       = GetTitleText();
	wlTracker.quest.targetname  = name;
	wlTracker.quest.targetkind  = kind;
	wlTracker.quest.targetid    = id;

	-- ...Wait for the quest log refresh to register the quest
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlCompleteQuest(...) -- Complete (Progress)
	local success, msg = pcall(wlSecureCompleteQuest);

	if not success then
		error(msg);
	end

	return wlDefaultCompleteQuest(...);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlCompleteQuestTime = -999999;
function wlSecureCompleteQuest()
	wlCompleteQuestTime = wlGetTime();
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlQuestFrameRewardPanel_OnShow(...) -- Complete (Progress)
	local success, msg = pcall(wlSecureQuestFrameRewardPanel_OnShow);

	if not success then
		error(msg);
	end

	return wlDefaultQuestFrameRewardPanel_OnShow(...);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlSecureQuestFrameRewardPanel_OnShow()
	if wlIsValidInterval(wlCompleteQuestTime or 0, wlGetTime(), 1000) then
		wlQuestHasProgressText = true;
	else
		wlQuestHasProgressText = false;
	end

	wlCompleteQuestTime = -999999;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlGetQuestReward(...)  -- Turn-in
	local success, msg = pcall(wlSecureGetQuestReward);

	if not success then
		error(msg);
	end

	return wlDefaultGetQuestReward(...);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlSecureGetQuestReward()
	wlRegisterQuestReturn();

	wlQuestHasProgressText = false;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlRegisterQuestAccept(index)
	if not wlEvent or not wlId or not wlEvent[wlId] or not wlN or not wlEvent[wlId][wlN] then
		return;
	end

	local eventId = wlGetNextEventId();

	wlUpdateVariable(wlEvent, wlId, wlN, eventId, "initArray", 0);

	wlEvent[wlId][wlN][eventId].what   = "quest";
	wlEvent[wlId][wlN][eventId].action = "accept";

	wlEvent[wlId][wlN][eventId].questid  = wlQuestLog[index].id;
	wlEvent[wlId][wlN][eventId].timer    = wlQuestLog[index].timer;
	wlEvent[wlId][wlN][eventId].sharable = wlQuestLog[index].sharable;

	wlEvent[wlId][wlN][eventId].targetname  = wlTracker.quest.targetname;
	wlEvent[wlId][wlN][eventId].targetkind  = wlTracker.quest.targetkind;
	wlEvent[wlId][wlN][eventId].targetid    = wlTracker.quest.targetid;

	wlClearTracker("quest");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlRegisterQuestReturn()
	local name, id, kind = wlUnitName("npc"), wlUnitGUID("npc");

	if not name or not id then
		return;
	end

	if kind == "object" then
		wlRegisterObject(id);
	end

	if not wlEvent or not wlId or not wlEvent[wlId] or not wlN or not wlEvent[wlId][wlN] then
		return;
	end

	local eventId = wlGetNextEventId();

	local title = GetTitleText();
	local questid = wlTableFind(wlQuestLog, function (a, v) return a.id and a.title == v; end, title);
	if not questid then
		questid = wlConcat(wlSelectOne(1, wlGetLocation()), title);
	else
		questid = wlQuestLog[questid].id;
		wlScans.quests[questid] = true;
	end

	wlUpdateVariable(wlEvent, wlId, wlN, eventId, "initArray", 0);

	wlEvent[wlId][wlN][eventId].what   = "quest";
	wlEvent[wlId][wlN][eventId].action = "turn-in";

	wlEvent[wlId][wlN][eventId].questid   = questid;
	wlEvent[wlId][wlN][eventId].progress  = wlQuestHasProgressText and wlGetSourceText(GetProgressText()) or "";
	wlEvent[wlId][wlN][eventId].complete  = wlGetSourceText(GetRewardText());

	wlEvent[wlId][wlN][eventId].targetname = name;
	wlEvent[wlId][wlN][eventId].targetkind = kind;
	wlEvent[wlId][wlN][eventId].targetid   = id;

	oldNumQuestCompleted, wlNumQuestCompleted = wlNumQuestCompleted, wlGetNumLoremasterQuestCompleted();

	if oldNumQuestCompleted ~= wlNumQuestCompleted then
		wlEvent[wlId][wlN][eventId].loremaster = 1;
	end

	wlTracker.quest.time = wlGetTime();
	wlTracker.quest.eventId = eventId;
	wlTracker.quest.action = "turn-in";
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_COMBAT_TEXT_UPDATE(self, messageType, param1, param2)
	if messageType == "FACTION" then
		if wlIsValidInterval(wlTracker.quest.time or 0, wlGetTime(), 1000) and wlTracker.quest.action == "turn-in" then
			return; -- Quest reputation
		elseif not wlIsValidInterval(wlTracker.rep.time or 0, wlGetTime(), 1000) or not wlFaction[param1] then
			return; -- Not kill reputation
		end

		if wlSelectOne(2, UnitRace("player")) == "Human" and param2 > 0 then	-- Racial +10%
			param2 = math.floor(param2 / 1.1 + 0.5);
		end

		wlUpdateVariable(wlUnit, wlTracker.rep.id, "spec", wlGetInstanceDifficulty(), "rep", wlConcat(param1, wlFaction[param1], param2, wlTracker.rep.flags), "add", 1);
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlGetInstanceDifficulty()
	local _, instanceType, instanceDifficulty, _, _, dynamicDifficulty = GetInstanceInfo();

	if type(dynamicDifficulty) ~= "nil" and dynamicDifficulty == 1 then
		if instanceDifficulty == 1 then
			instanceDifficulty = 3;
		elseif instanceDifficulty == 2 then
			instanceDifficulty = 4;
		end
	end

	if instanceType == "party" then
		return -instanceDifficulty;

	elseif instanceType == "raid" then
		return instanceDifficulty;

	else
		return 0;
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_QUEST_QUERY_COMPLETE(self, ...)
	GetQuestsCompleted(wlScans.quests);

	if wlTableIsEmpty(wlScans.quests) then
		-- Query quests again until something is collected
		wlTimers.quests = wlGetTime() + 30000; -- 30 seconds timeout
	else
		wlTimers.quests = nil;
		wlAppendMsgCollected(WL_COLLECT_QUESTS);
	end
end



-------------------------
-------------------------
--                     --
--   LOOT  FUNCTIONS   --
--                     --
-------------------------
-------------------------


local wlNPC, wlOBJECT, wlITEM, wlZONE = 1, 2, 4, 64;

--	ID = { spellName, sourceFlags, isLootSpell }
local wlSpells = {
	Disenchanting = { GetSpellInfo(13262) or "",                    wlITEM         , 1 },
	Engineering   = { GetSpellInfo(4036)  or "", wlNPC                             , 1 },
	Fishing       = { GetSpellInfo(7620)  or "",                             wlZONE, 1 },
	HerbGathering = { GetSpellInfo(2366)  or "", wlNPC + wlOBJECT                  , 1 },
	Milling       = { GetSpellInfo(51005) or "",                    wlITEM         , 1 },
	Mining        = { GetSpellInfo(2575)  or "", wlNPC + wlOBJECT                  , 1 },
	Opening       = { GetSpellInfo(3365)  or "",         wlOBJECT + wlITEM         , 2 },
	PickLocking   = { GetSpellInfo(1804)  or "",         wlOBJECT                  , 1 },
	PickPocketing = { GetSpellInfo(921)   or "", wlNPC                             , 2 },
	Prospecting   = { GetSpellInfo(31252) or "",                    wlITEM         , 1 },
	Skinning      = { GetSpellInfo(8613)  or "", wlNPC                             , 1 },
	MindControl   = { GetSpellInfo(605)   or "", wlNPC                             , nil },
	BeastLore     = { GetSpellInfo(1462)  or "", wlNPC                             , nil },
};

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlFindSpell(name)
	for k, v in pairs(wlSpells) do
		if string.match(name, "^" .. v[1]) then
			return k;
		end
	end

	return nil;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_UNIT_SPELLCAST_SENT(self, unit, spell, rank, target)
	if unit ~= "player" or not target then
		return;
	end

	wlClearTracker("spell");

	local spellId = wlFindSpell(spell);

	if spellId then
		local npcName, npcUnit = GameTooltip:GetUnit();
		if not npcName and wlUnitName("target") == target then
			npcName, npcUnit = target, "target";
		end

		local itemName, itemLink = GameTooltip:GetItem();

		-- npc
		if bit.band(wlSpells[spellId][2], wlNPC) ~= 0 and npcName and not itemName then

			local name, id = wlUnitName(npcUnit or ""), wlUnitGUID(npcUnit or "");

			if npcName ~= target or name ~= target or not id then
				return;
			end

			wlTracker.spell.kind = "npc";
			wlTracker.spell.id   = id;
			wlTracker.spell.name = name;

		-- item
		elseif bit.band(wlSpells[spellId][2], wlITEM) ~= 0 and not npcName and itemName then

			wlTracker.spell.kind = "item";

			if itemName and itemName == target then
				wlTracker.spell.id   = wlParseItemLink(itemLink);
				wlTracker.spell.name = itemName;

			elseif target ~= "" then
				wlTracker.spell.id   = wlParseItemLink(wlSelectOne(2, GetItemInfo(target)));
				wlTracker.spell.name = target;

			else
				wlTracker.spell.id   = nil;
				wlTracker.spell.name = nil;
			end

		-- object
		elseif bit.band(wlSpells[spellId][2], wlOBJECT) ~= 0 and not npcName and not itemName then

			if target == "" then
				return;
			end

			local zone, x, y, dl = wlGetLocation();

			wlRegisterObject(wlConcat(spellId, zone, target));

			wlTracker.spell.kind = "object";
			wlTracker.spell.name = target;
			wlTracker.spell.zone = zone;
			wlTracker.spell.x    = x;
			wlTracker.spell.y    = y;
			wlTracker.spell.dl   = dl;

		-- zone
		elseif bit.band(wlSpells[spellId][2], wlZONE) ~= 0 and not npcName and not itemName then

			if target ~= "" then
				return;
			end

			local zone, x, y, dl = wlGetLocation();

			wlTracker.spell.kind = "zone";
			wlTracker.spell.zone = zone;
			wlTracker.spell.x    = x;
			wlTracker.spell.y    = y;
			wlTracker.spell.dl   = dl;

		else
			return;
		end

		wlTracker.spell.time   = wlGetTime();
		wlTracker.spell.event  = "SENT";
		wlTracker.spell.action = spellId;
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_UNIT_SPELLCAST_SUCCEEDED(self, unit, spell, rank)
	if unit ~= "player" then
		return;
	end

	if wlTracker.spell.time and wlTracker.spell.event == "SENT" and wlTracker.spell.action == wlFindSpell(spell) then
		wlTracker.spell.event = "SUCCEEDED";
		wlTracker.spell.time = wlGetTime();
	else
		wlClearTracker("spell");
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_UNIT_SPELLCAST_FAILED(self, unit)
	if unit == "player" then
		wlClearTracker("spell");
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlUseContainerItem(bag, slot, ...)
	local now = wlGetTime();

	if wlIsValidInterval(wlTracker.spell.time or 0, now, 250) and wlTracker.spell.kind == "item" then
		local id, _, _, _, _, _, _, name = wlParseItemLink(GetContainerItemLink(bag, slot));

		if (wlTracker.spell.id and wlTracker.spell.id ~= id) or (wlTracker.spell.name and wlTracker.spell.name ~= name) then
			wlClearTracker("spell");
			return;			
		end

		if not wlTracker.spell.id or not wlTracker.spell.name then
			wlTracker.spell.id   = id;
			wlTracker.spell.name = name;
		end

		return;
	end

	if not MerchantFrame:IsShown() and bag and slot then
		local id = wlParseItemLink(GetContainerItemLink(bag, slot));

		wlGameTooltip:ClearLines();
		wlGameTooltip:SetBagItem(bag, slot);

		for i = 2, wlGameTooltip:NumLines() do
			local text = getglobal("wlGameTooltipTextLeft" .. i):GetText()
			if text == ITEM_OPENABLE then
				wlClearTracker("spell");

				wlTracker.spell.time   = now;
				wlTracker.spell.event  = "SUCCEEDED";
				wlTracker.spell.action = "Opening";
				wlTracker.spell.kind = "item";
				wlTracker.spell.id   = id;
				wlTracker.spell.name = wlGameTooltipTextLeft1:GetText();
				break;
			end
		end
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local tempLoot = {};
function wlEvent_LOOT_OPENED(self)
	if not wlEvent or not wlId or not wlEvent[wlId] or not wlN or not wlEvent[wlId][wlN] then
		return;
	end

	local eventId = wlGetNextEventId();
	local now = wlGetTime();

	-- Clean wlLootCooldown variable
	for k, v in pairs(wlLootCooldown) do
		if v < now - 300000 then -- 5min
			wlLootCooldown[k] = nil;
		end
	end

	if wlTracker.spell.time then
		if (not wlIsValidInterval(wlTracker.spell.time or 0, now, 1000) and not IsFishingLoot()) or wlTracker.spell.event ~= "SUCCEEDED" or not wlSpells[wlTracker.spell.action][3] then
			wlClearTracker("spell");
			return;
		end

		if wlTracker.spell.id then
			wlTracker.spell.name = nil;
		end

		wlTracker.spell.time  = nil;
		wlTracker.spell.event = nil;

	elseif wlIsValidName(UnitName("target")) and UnitIsTappedByPlayer("target") and wlUnitIsClose("target") and UnitIsDead("target") and not UnitIsFriend("player", "target") then
		if UnitIsPlayer("target") then
			wlTracker.spell.action = "Killing";
			wlTracker.spell.kind   = "player";
			wlTracker.spell.id     = wlConcat(wlSelectOne(2, UnitRace("target")), wlSelectOne(2, UnitClass("target")));

		elseif not UnitPlayerControlled("target") then
			wlTracker.spell.action = "Killing";
			wlTracker.spell.kind   = "npc";
			wlTracker.spell.id     = wlUnitGUID("target");

		else -- pets
			return;
		end

	else
		return;
	end

	-- Loot cooldown
	if wlTracker.spell.action == "Killing" or (wlSpells[wlTracker.spell.action] and wlSpells[wlTracker.spell.action][3] == 1) then
		local guid = nil;

		if wlTracker.spell.kind == "npc" then
			guid = wlConcat(wlTracker.spell.action, UnitGUID("target"));
		elseif wlTracker.spell.kind == "object" then
			guid = wlConcat(wlTracker.spell.action, wlTracker.spell.zone, wlTracker.spell.name);
		end

		if wlLootCooldown[guid] then
			wlClearTracker("spell");
			return;
		end

		if wlIsInParty() then
			SendAddonMessage("WL_LOOT_COOLDOWN", guid, "RAID");
		else
			wlEvent_CHAT_MSG_ADDON(self, "WL_LOOT_COOLDOWN", guid, "RAID", UnitName("player"));
		end
	end

	wlUpdateVariable(wlEvent, wlId, wlN, eventId, "initArray", 0);
	wlEvent[wlId][wlN][eventId].what = "loot";
	wlTableCopy(wlEvent[wlId][wlN][eventId], wlTracker.spell);

	wlEvent[wlId][wlN][eventId].dd = wlGetInstanceDifficulty();

	local flags = 0;

	-- Vitreous Focuser
	if GetItemCount(13370) > 0 then
		flags = flags + 64;
	end

	-- Argent Dawn Trinket
	if IsEquippedItem(12846) or IsEquippedItem(13209) or IsEquippedItem(19812) or IsEquippedItem(23206) or IsEquippedItem(23207) then
		flags = flags + 128;
	end

	-- Alliance or Horde
	local faction = UnitFactionGroup("player");
	if faction == "Alliance" then
		flags = flags + 1024;
	elseif faction == "Horde" then
		flags = flags + 2048;
	end

	wlEvent[wlId][wlN][eventId].flags = flags;

	wlTableClear(tempLoot);

	local i = 1;
	for slot = 1, GetNumLootItems() do
		if LootSlotIsItem(slot) then
			local itemId = wlParseItemLink(GetLootSlotLink(slot));
			tempLoot[itemId] = (tempLoot[itemId] or 0) + wlSelectOne(3, GetLootSlotInfo(slot));
		elseif LootSlotIsCoin(slot) then
			wlUpdateVariable(wlEvent, wlId, wlN, eventId, "drop", i, "set", wlConcat("coin", wlParseCoin(select(2, GetLootSlotInfo(slot)))));
			i = i + 1;
		end
	end

	for itemId, qty in pairs(tempLoot) do
		if qty then
			wlUpdateVariable(wlEvent, wlId, wlN, eventId, "drop", i, "set", wlConcat(itemId, qty));
			i = i + 1;
		end
	end

	wlClearTracker("spell");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_CHAT_MSG_ADDON(self, id, msg, channel, source)
	if id == "WL_LOOT_COOLDOWN" and msg and msg ~= "" then
		wlLootCooldown[msg] = wlGetTime();
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlIsInParty()
	return GetNumPartyMembers() > 0 or GetNumRaidMembers() > 1;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--



----------------------------
----------------------------
--                        --
--   AUCTION  FUNCTIONS   --
--                        --
----------------------------
----------------------------

function wlPlaceAuctionBid(aType, aIndex, bid)
	local id, subId, enchant, socket1, socket2, socket3, socket4 = wlParseItemLink(GetAuctionItemLink(aType, aIndex));
	local count, _, _, _, _, _, buyoutPrice = select(3, GetAuctionItemInfo(aType, aIndex));

	if bid == buyoutPrice and id ~= 0 and enchant == 0 and socket1 == 0 and socket2 == 0 and socket3 == 0 and socket4 == 0 and count > 0 then
		local server = GetRealmName();
		local zone = wlGetLocation();

		wlUpdateVariable(wlAuction, server, zone, wlConcat(id, subId, math.floor(buyoutPrice / count)), "add", 1);
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--



-------------------------------
-------------------------------
--                           --
--   COMPLETIST  FUNCTIONS   --
--                           --
-------------------------------
-------------------------------

function wlCollect(userInitiated)
	local now = wlGetTime();

	wlUserCollected = userInitiated;
	wlMsgCollected = "";

	QueryQuestsCompleted();
	wlTimers.quests = now + 10000; -- 10 seconds timeout

	if userInitiated and wlScanAllProfessions() then
		wlAppendMsgCollected(WL_COLLECT_PROFESSIONS);
	end

	if wlScanCompanions("MOUNT") then
		wlAppendMsgCollected(WL_COLLECT_MOUNTS);
	end

	if wlScanCompanions("CRITTER") then
		wlAppendMsgCollected(WL_COLLECT_CRITTERS);
	end

	if wlScanTitles() then
		wlAppendMsgCollected(WL_COLLECT_TITLES);
	end

	if wlScanSkills() then
		wlAppendMsgCollected(WL_COLLECT_SKILLS);
	else
		wlTimers.skills = now + 5000; -- 5 seconds timeout
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlAppendMsgCollected(value)
	if not wlMsgCollected or wlMsgCollected == "" then
		wlMsgCollected = value;
	elseif wlMsgCollected:match(value) then
		-- do nothing
	elseif not wlMsgCollected:match(WL_COLLECT_LASTSEP) then
		wlMsgCollected = value .. WL_COLLECT_LASTSEP .. wlMsgCollected;
	else
		wlMsgCollected = value .. WL_COLLECT_SEP .. wlMsgCollected;
	end

	wlTimers.printCollected = wlGetTime() + 1000; -- 1 second timeout (wait for other stuff!)
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlDefaultChatFrame_DisplayTimePlayed = ChatFrame_DisplayTimePlayed;
function wlEvent_TIME_PLAYED_MSG(self, total, thisLevel)
	wlScans.timePlayedTotal = total;
	wlScans.timePlayedWhen = wlGetTime();
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlQueryTimePlayed()
	-- Don't display time played in chat frame if not queried by player
	ChatFrame_DisplayTimePlayed = function() ChatFrame_DisplayTimePlayed = wlDefaultChatFrame_DisplayTimePlayed; end;

	RequestTimePlayed();
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local collectReminded = false;
function wlEvent_TRADE_SKILL_SHOW(self, ...)
	local skillLineName = wlScanProfession();

	if skillLineName then
		wlMessage(WL_MESSAGE_TEMPLATE:format(WL_NAME, WL_COLLECT_MSG:format(skillLineName)), false, skillLineName);

		if not collectReminded then
			collectReminded = true;
			wlMessage(WL_MESSAGE_TEMPLATE:format(WL_NAME, WL_COLLECT_TIP));
		end
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlScanProfession()
	local skillLineName = GetTradeSkillLine();
	if not wlIsValidName(skillLineName) or IsTradeSkillLinked() then
		return;
	end

--  **** wlTableClear is broken for unknown reason since 3.3.3
--	if wlScans.recipes[skillLineName] then
--		wlTableClear(wlScans.recipes[skillLineName]);
--	else
		wlScans.recipes[skillLineName] = {};
--	end

	TradeSkillFrame:UnregisterEvent("TRADE_SKILL_UPDATE");

	wlTableClear(wlCollapsedHeaders);

	-- Clear all filters
	local showMakeable = TradeSkillFrameAvailableFilterCheckButton:GetChecked();

	local invSlot = 0;
	for i = 0, select("#", GetTradeSkillInvSlots()) - 1 do
		if GetTradeSkillInvSlotFilter(i) then
			invSlot = i;
			break;
		end
	end

	local subClass = 0;
	for i = 0, select("#", GetTradeSkillSubClasses()) - 1 do
		if GetTradeSkillSubClassFilter(i) then
			subClass = i;
			break;
		end
	end

	TradeSkillOnlyShowMakeable(false);
	SetTradeSkillSubClassFilter(0, 1, 1);
	SetTradeSkillInvSlotFilter(0, 1, 1);

	local i = 1;
	while i <= GetNumTradeSkills() do
		local name, category, _, isExpanded = GetTradeSkillInfo(i);
		if name then
			if category == "header" then
				if not isExpanded then
					ExpandTradeSkillSubClass(i);
					wlCollapsedHeaders[name] = 1;
				end
			else
				local _, _, spellId = string.find(GetTradeSkillRecipeLink(i), "^|%x+|Henchant:(.+)|h%[.+%]");

				wlScans.recipes[skillLineName][spellId] = true;
			end
		end

		i = i + 1;
	end

	-- Restore headers
	i = 1;
	while i <= GetNumFactions() do
		local name, category, _, isExpanded = GetTradeSkillInfo(i);

		if name and category == "header" and wlCollapsedHeaders[name] then
			CollapseTradeSkillSubClass(i);
		end

		i = i + 1;
	end

	-- Restore filters
	TradeSkillOnlyShowMakeable(showMakeable);
	SetTradeSkillSubClassFilter(subClass, 1, 1);
	SetTradeSkillInvSlotFilter(invSlot, 1, 1);

	TradeSkillFrame:RegisterEvent("TRADE_SKILL_UPDATE");

	return skillLineName;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlProfessionSpells = {
	2259,  -- Alchemy
	2018,  -- Blacksmith
	7411,  -- Enchanting
	4036,  -- Engineering
	45357, -- Inscription
	25229, -- Jewelcrafting
	2108,  -- Leatherworking
	2656,  -- Smelting (Mining)
	3908,  -- Tailoring
	2550,  -- Cooking
	3273   -- First Aid
};
function wlScanAllProfessions()
	if not IsAddOnLoaded("Blizzard_TradeSkillUI") then
		LoadAddOn("Blizzard_TradeSkillUI");
	end

	-- Clear unlearned professions
	for spellName, ids in pairs(wlScans.recipes) do
		if not IsUsableSpell(spellName) then
			wlScans.recipes[spellName] = nil;
		end
	end

	local atLeastOneSuccess = false;

	-- Disable sounds
	local sound = GetCVar("Sound_EnableSFX");
	SetCVar("Sound_EnableSFX", 0);

	CloseTradeSkill();

	wlFrame:UnregisterEvent("TRADE_SKILL_SHOW");
	TradeSkillFrame:UnregisterEvent("TRADE_SKILL_SHOW");
	TradeSkillFrame:UnregisterEvent("TRADE_SKILL_CLOSE");

	for _, spellId in ipairs(wlProfessionSpells) do
		local spellName = GetSpellInfo(spellId);
		if IsUsableSpell(spellName) then
			CastSpellByName(spellName);
			atLeastOneSuccess = atLeastOneSuccess or (wlScanProfession() and true or false);
		end
	end

	CloseTradeSkill();

	TradeSkillFrame:RegisterEvent("TRADE_SKILL_CLOSE");
	TradeSkillFrame:RegisterEvent("TRADE_SKILL_SHOW");
	wlFrame:RegisterEvent("TRADE_SKILL_SHOW");

	-- Restore sound setting
	SetCVar("Sound_EnableSFX", sound);

	return atLeastOneSuccess;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlScanCompanions(kind) -- "CRITTER" or "MOUNT"
	local ids = "";

	for i = 1, GetNumCompanions(kind) do
		if i > 1 then
			ids = ids .. ",";
		end

		ids = ids .. select(3, GetCompanionInfo(kind, i));
	end

	if ids ~= "" then
		wlScans.pets[kind] = ids;
		return true;
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlScanSkills()
	local ids, first = "", true;

	local i = 1;
	while i <= GetNumSkillLines() do
		local name, isHeader, isExpanded, rank, _, _, maxRank, _, _, _, _, _, description = GetSkillLineInfo(i);

		if name then
			if isHeader then
				if not isExpanded then
					ExpandSkillHeader(i);
				end

			elseif maxRank > 1 and description ~= "" then

				if first then
					first = false;
				else
					ids = ids .. ",";
				end

				ids = ids .. name .. "," .. rank .. "," .. maxRank;
			end
		end

		i = i + 1;
	end

	if ids ~= "" then
		wlScans.skills = ids;
		return true;
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlScanTitles(userInitiated)
	local ids, first = "", true;

	for i = 1, GetNumTitles() do
		if IsTitleKnown(i) ~= 0 then
			if first then
				first = false;
			else
				ids = ids .. ",";
			end

			ids = ids .. i;
		end
	end

	if ids ~= "" then
		wlScans.titles = ids;
		return true;
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlRefreshExportData()
	wlUserCollected = false;
	wlScanCompanions("MOUNT");
	wlScanCompanions("CRITTER");
	wlScanSkills();
	wlScanTitles();

	local timePlayed = 0;

	if wlScans.timePlayedTotal and wlScans.timePlayedWhen then
		-- Correct timePlayedTotal by adding amount of seconds since last update
		timePlayed = wlScans.timePlayedTotal + math.floor((wlGetTime() - wlScans.timePlayedWhen) / 1000);
	end

	local key = "who=" .. wlConcatToken(",", GetCVar("realmList"), GetRealmName(), wlSelectOne(1, UnitName("player")), GetAccountExpansionLevel());
	local value = "&quests=" .. wlTableConcatKeys(wlScans.quests, ",");
	value = value .. "&mounts=" .. wlScans.pets.MOUNT;
	value = value .. "&companions=" .. wlScans.pets.CRITTER;
	value = value .. "&recipes=" .. wlTableConcatKeys(wlScans.recipes, ",");
	value = value .. "&skills=" .. wlScans.skills;
	value = value .. "&titles=" .. wlScans.titles;
	value = value .. "&timePlayedTotal=" .. timePlayed;

	if wlExportData:find(key) then
		wlExportData = wlExportData:gsub(key .. "[^;]*", key .. value); -- replace
	else
		wlExportData = wlExportData .. key .. value .. ";";
	end
end



--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--
--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--
--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlGetLocation()
	local zone = GetRealZoneText() or "";
	local x, y = GetPlayerMapPosition("player");
	local dl   = GetCurrentMapDungeonLevel() or 0;

	if not x or not y then
		x, y = 0, 0;
	end

	if x == 0 and x == 0 then
		for level = 1, GetNumDungeonMapLevels() do
			SetDungeonMapLevel(level);
			x, y = GetPlayerMapPosition("player");

			if x and y and (x > 0 or y > 0) then
				SetDungeonMapLevel(dl); -- Restore
				dl = level;
				break;
			end

			x, y = 0, 0;
		end
	end

	if DungeonUsesTerrainMap() then
		dl = dl - 1;
	end

	return zone, math.floor(x * 1000 + 0.5), math.floor(y * 1000 + 0.5), dl;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlGetLocationIndex(array, x, y, dl, delta)
	for i = 1, array.n do
		if wlIsEqualValues(x, array[i].x, delta) and wlIsEqualValues(y, array[i].y, delta) and array[i].dl == dl then
			return i;
		end
	end

	return nil;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlRound(n, p)
	local p = math.pow(10, p);
	return math.floor(n * p + 0.5) / p;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlClearTracker(...)
	for i = 1, select("#", ...) do
		local n = wlSelectOne(i, ...);
		wlUpdateVariable(wlTracker, n, "time", "set", nil);

		for k, _ in pairs(wlTracker[n]) do
			wlTracker[n][k] = nil;
		end
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--



--------------------------
--------------------------
--                      --
--   FRAME  FUNCTIONS   --
--                      --
--------------------------
--------------------------

local wlEvents = {
	-- player
	PLAYER_LOGIN                   = wlEvent_PLAYER_LOGIN,
	PLAYER_LOGOUT                  = wlEvent_PLAYER_LOGOUT,

	-- npc
	PLAYER_TARGET_CHANGED          = wlEvent_PLAYER_TARGET_CHANGED,
	CHAT_MSG_MONSTER_SAY           = wlEvent_CHAT_MSG_MONSTER_SAY,
	CHAT_MSG_MONSTER_WHISPER       = wlEvent_CHAT_MSG_MONSTER_WHISPER,
	CHAT_MSG_MONSTER_YELL          = wlEvent_CHAT_MSG_MONSTER_YELL,
	GOSSIP_SHOW                    = wlEvent_GOSSIP_SHOW,
	AUCTION_HOUSE_SHOW             = wlEvent_AUCTION_HOUSE_SHOW,
	BANKFRAME_OPENED               = wlEvent_BANKFRAME_OPENED,
	BATTLEFIELDS_SHOW              = wlEvent_BATTLEFIELDS_SHOW,
	CONFIRM_BINDER                 = wlEvent_CONFIRM_BINDER,
	CONFIRM_PET_UNLEARN            = wlEvent_CONFIRM_PET_UNLEARN,
	CONFIRM_TALENT_WIPE            = wlEvent_CONFIRM_TALENT_WIPE,
	GOSSIP_ENTER_CODE              = wlEvent_GOSSIP_ENTER_CODE,
	OPEN_TABARD_FRAME              = wlEvent_OPEN_TABARD_FRAME,
	PET_STABLE_SHOW                = wlEvent_PET_STABLE_SHOW,
	TAXIMAP_OPENED                 = wlEvent_TAXIMAP_OPENED,

	PET_BAR_UPDATE                 = wlEvent_PET_BAR_UPDATE,
	MERCHANT_SHOW                  = wlEvent_MERCHANT_SHOW,
	MERCHANT_UPDATE                = wlEvent_MERCHANT_UPDATE,
	TRAINER_SHOW                   = wlEvent_TRAINER_SHOW,
	CHAT_MSG_MONSTER_EMOTE         = wlEvent_CHAT_MSG_MONSTER_EMOTE,
	COMBAT_LOG_EVENT_UNFILTERED    = wlEvent_COMBAT_LOG_EVENT_UNFILTERED,

	UPDATE_FACTION                 = wlEvent_UPDATE_FACTION,

	-- drops
	LOOT_OPENED                    = wlEvent_LOOT_OPENED,
	CHAT_MSG_ADDON                 = wlEvent_CHAT_MSG_ADDON,

	UNIT_SPELLCAST_SENT            = wlEvent_UNIT_SPELLCAST_SENT,
	UNIT_SPELLCAST_SUCCEEDED       = wlEvent_UNIT_SPELLCAST_SUCCEEDED,
	UNIT_SPELLCAST_FAILED          = wlEvent_UNIT_SPELLCAST_FAILED,
	UNIT_SPELLCAST_INTERRUPTED     = wlEvent_UNIT_SPELLCAST_FAILED,
	UNIT_SPELLCAST_FAILED_QUIET    = wlEvent_UNIT_SPELLCAST_FAILED,

	-- object
	ITEM_TEXT_BEGIN                = wlEvent_ITEM_TEXT_BEGIN,
	MAIL_SHOW                      = wlEvent_MAIL_SHOW,

	-- quest
	QUEST_LOG_UPDATE               = wlEvent_QUEST_LOG_UPDATE,
	COMBAT_TEXT_UPDATE             = wlEvent_COMBAT_TEXT_UPDATE,
	CHAT_MSG_COMBAT_FACTION_CHANGE = wlEvent_CHAT_MSG_COMBAT_FACTION_CHANGE,
	CHAT_MSG_COMBAT_HONOR_GAIN     = wlEvent_CHAT_MSG_COMBAT_HONOR_GAIN,
	QUEST_QUERY_COMPLETE           = wlEvent_QUEST_QUERY_COMPLETE,

	-- coords tooltip
	PLAYER_ENTERING_WORLD          = wlEvent_ZONE_CHANGED,
	ZONE_CHANGED                   = wlEvent_ZONE_CHANGED,
	ZONE_CHANGED_NEW_AREA          = wlEvent_ZONE_CHANGED,

	-- completist
	TIME_PLAYED_MSG                = wlEvent_TIME_PLAYED_MSG,
	TRADE_SKILL_SHOW               = wlEvent_TRADE_SKILL_SHOW,
};

function wl_OnLoad(self)
	CreateFrame("Frame", "wlUpdateFrame", UIParent);
	wlUpdateFrame:SetScript('OnUpdate', wl_OnUpdate);
	wlUpdateFrame:Show();

	for event, _ in pairs(wlEvents) do
		self:RegisterEvent(event);
	end

	SlashCmdList["WOWHEAD_LOOTER"] = wlParseCommand;
	SLASH_WOWHEAD_LOOTER1 = "/wl";

	table.insert(UISpecialFrames, "wlDebugFrame");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wl_OnEvent(self, event, ...)
	if event and wlEvents[event] then
		wlEvents[event](self, ...);
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local uploadReminder = false;
function wl_OnUpdate(self)
	local now = wlGetTime();

	for name, timeout in pairs(wlTimers) do
		if timeout and now - timeout >= 0 then
			wlTimers[name] = false; -- Clear timer

			if name == "quests" then
				QueryQuestsCompleted();
				wlTimers.quests = now + 10000; -- 10 seconds timeout

			elseif name == "skills" then
				if wlScanSkills() then
					wlAppendMsgCollected(WL_COLLECT_SKILLS);
				else
					wlTimers.skills = now + 5000; -- 5 seconds timeout
				end

			elseif name == "autoCollect" then
				wlQueryTimePlayed();
				wlCollect();

			elseif name == "printCollected" then
				if wlMsgCollected and wlMsgCollected ~= "" then
					wlMessage(WL_MESSAGE_TEMPLATE:format(WL_NAME, WL_COLLECT_MSG:format(wlMsgCollected)), wlUserCollected);
					wlMsgCollected = nil;

					if not uploadReminder then
						uploadReminder = true;
						wlMessage(WL_MESSAGE_TEMPLATE:format(WL_NAME, WL_UPLOAD_REMINDER), wlUserCollected);
					end
				end
			end
		end
	end

	if not UnitExists("target") or UnitPlayerControlled("target") or UnitIsTapped("target") or not wlUnitIsClose("target") then
		return;
	end

	local id, kind = wlUnitGUID("target");

	if id and kind == "npc" then
		wlRegisterUnitLocation(id, UnitLevel("target"));
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlParseCommand(cmd)
	local param1, param2, param3 = cmd:lower():match("^([%S]+)%s*([%S]*)%s*(.*)$");
	param1, param2 = param1 or "", param2 or "";

	if param1 == "debug" then

		if param2 == "show" then
			wlDebugFrame:Show();
		elseif param2 == "hide" then
			wlDebugFrame:Hide();
		elseif param2 == "clear" then
			wlDebugEdit:SetText("");
		elseif param2 == "toggle" then
			if wlDebugFrame:IsShown() then
				wlDebugFrame:Hide();
			else
				wlDebugFrame:Show();
			end
		elseif param2 == "reset" then
			wlReset();
			ReloadUI();
		elseif param2 == "test" then
			wlTest(cmd);
		end

	elseif param1 == "loc" then

		if param2 == "map" then
			wlFrameToggle(wlLocMapFrame, WL_LOC_MAP, "locMap");
		elseif param2 == "tooltip" then
			wlFrameToggle(wlLocTooltipFrame, WL_LOC_TOOLTIP, "locTooltip");
		elseif param2 == "reset" then
			wlFrameReset(wlLocTooltipFrame);
		else
			local _, x, y = wlGetLocation();
			wlMessage(WL_MESSAGE_TEMPLATE:format(WL_NAME, WL_LOC:format(x / 10, y / 10)), true);
		end

	elseif param1 == "id" then

		if param2 == "reset" then
			wlFrameReset(wlIdTooltipFrame);
		else
			wlFrameToggle(wlIdTooltipFrame, WL_ID_TOOLTIP, "idTooltip");
		end

	elseif param1:match("^collect$") then
		wlTimers["autoCollect"] = nil; -- Cancel auto-collect
		collectReminded = true; -- Don't tip the user about the command s/he just used
		wlCollect(true);

	elseif param1:match("^recipes?$") then
		local skillLineName = GetTradeSkillLine();
		if wlIsValidName(skillLineName) and not IsTradeSkillLinked() and wlScans.recipes[skillLineName] then
			wlPopupBox(string.format(WL_LIST_RECIPES, skillLineName), wlTableConcatKeys(wlScans.recipes[skillLineName], ","));
		end

	elseif param1:match("^mounts?$") then
		wlUserCollected = false; -- Don't the user twice
		wlScanCompanions("MOUNT");
		wlPopupBox(WL_LIST_MOUNTS, wlScans.pets.MOUNT);

	elseif param1:match("^companions?$") then
		wlUserCollected = false; -- Don't the user twice
		wlScanCompanions("CRITTER");
		wlPopupBox(WL_LIST_COMPANIONS, wlScans.pets.CRITTER);

	elseif param1:match("^quests?$") then
		wlPopupBox(WL_LIST_QUESTS, wlTableConcatKeys(wlScans.quests, ","));

	elseif param1:match("^nospam$") then
		wlGlobalSetting.noSpam = not wlGlobalSetting.noSpam;
		wlMessage(WL_MESSAGE_TEMPLATE:format(WL_NAME, WL_NOSPAM:format(wlEnabledDisabled(not wlGlobalSetting.noSpam))), true);

	else -- Show help
		for _, msg in ipairs(WL_HELP) do
			wlMessage(msg, true);
		end
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlFrameToggle(frame, msg, savename)
	wlSetting[savename] = not wlSetting[savename];

	if wlSetting[savename] then
		frame:Show();
	else
		frame:Hide();
	end

	wlMessage(WL_MESSAGE_TEMPLATE:format(WL_NAME, msg:format(wlEnabledDisabled(wlSetting[savename]))), true);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlFrameReset(frame)
	frame:ClearAllPoints();
	frame:SetPoint("CENTER");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlLastMapSize = nil; -- 0: big, 1: small
function wlLocMapFrame_OnUpdate()
	if WorldMapFrame.sizedDown and wlLastMapSize ~= 0 then
		wlLastMapSize = 0;
		wlLocMapFrameText:ClearAllPoints();
		wlLocMapFrameText:SetPoint("BOTTOMLEFT", WorldMapDetailFrame, "BOTTOMLEFT", 4, -19);
		wlLocMapFrameText:Show();

	elseif not WorldMapFrame.sizedDown and wlLastMapSize ~= 1 then
		wlLastMapSize = 1;
		wlLocMapFrameText:ClearAllPoints();
		wlLocMapFrameText:SetPoint("BOTTOMLEFT", WorldMapPositioningGuide, "BOTTOMLEFT", 16, 11);
		wlLocMapFrameText:Show();
	end

	-- Player
	local pX, pY = GetPlayerMapPosition("player");

	local playerStr = UnitName("player") .. ": |cffffffff";
	if pX == 0 or pY == 0 then
		playerStr = playerStr .. WL_NA;
	else
		playerStr = string.format("%s%.1f, %.1f", playerStr, pX * 100, pY * 100);
	end

	-- Cursor
	local width, height, scale = WorldMapDetailFrame:GetWidth(), WorldMapDetailFrame:GetHeight(), WorldMapDetailFrame:GetEffectiveScale();
	local cX, cY = WorldMapDetailFrame:GetCenter();
	local left, bottom = cX - width / 2, cY + height / 2;

	cX, cY = GetCursorPosition();
	cX, cY = (cX / scale - left) / width * 100, (bottom - cY / scale) / height * 100;

	local cursorStr = WL_LOC_CURSOR .. ": |cffffffff";
	if cX < 0 or cX > 100 or cY < 0 or cY > 100 then
		cursorStr = cursorStr .. WL_NA;
	else
		cursorStr = string.format("%s%.1f, %.1f", cursorStr, cX, cY);
	end

	wlLocMapFrameText:SetText(playerStr .. "|r  -  " .. cursorStr .. "|r");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEvent_ZONE_CHANGED()
	if (not WorldMapFrame or not WorldMapFrame:IsShown()) and (not BattlefieldMinimap or not BattlefieldMinimap:IsShown()) then
		SetMapToCurrentZone();
	end

	wlLocTooltipFrame_OnUpdate();
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlLocTooltipFrame_OnUpdate()
	local pX, pY = GetPlayerMapPosition("player");

	-- Hide tooltip
	if pX == 0 and pY == 0 then
		wlLocTooltipFrame:Hide();

	elseif wlSetting.locTooltip then
		wlLocTooltipFrameText:SetText(string.format("%.1f, %.1f", pX * 100, pY * 100));
		wlLocTooltipFrame:SetWidth(wlLocTooltipFrameText:GetStringWidth() + 14);

		wlLocTooltipFrame:Show();
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlIdTooltipFrame_OnUpdate()
	local name, id, kind = wlUnitName("npc"), wlUnitGUID("npc");

	if not name or not id then
		name, id, kind = wlUnitName("target"), wlUnitGUID("target");

		if not name or not id then
			name, id, kind = wlUnitName("mouseover"), wlUnitGUID("mouseover");

			if not name or not id then
				wlIdTooltipFrameText:SetText(WL_NA);
			end
		end
	end

	if name and id then
		wlIdTooltipFrameText:SetText(name .. "|n" .. WL_MESSAGE_TEMPLATE:format(kind, id));
	end

	wlIdTooltipFrame:SetWidth(wlIdTooltipFrameText:GetStringWidth() + 14);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlPopupBox(staticText, editText)

	wlPopupFrameCaption:SetText(staticText or "");
	wlPopupFrameEdit:SetText(editText or "");
	wlPopupFrame:Show();
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlMessage(msg, userInitiated, timedMsg)
	if userInitiated then
		if timedMsg then
			wlMessages[timedMsg] = wlGetTime() + 1800000; -- 30 minutes
		end

		DEFAULT_CHAT_FRAME:AddMessage(msg);

	elseif not wlGlobalSetting.noSpam then
		if timedMsg then
			local now = wlGetTime();

			if wlMessages[timedMsg] and wlMessages[timedMsg] - now > 0 then
				return;
			end

			wlMessages[timedMsg] = now + 1800000; -- 30 minutes
		end

		DEFAULT_CHAT_FRAME:AddMessage(msg);
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlEnabledDisabled(good)
	if good then
		return WL_ENABLED;
	else
		return WL_DISABLED;
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlPrint(...)
	wlDebugEdit:SetText(wlDebugEdit:GetText() .. wlConcatToken(" : ", ...) .. "\n");
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlGlobalEvents = {};
function wlGlobalUnregister(eventName)
	if wlGlobalEvents[eventName] then
		return;
	end

	wlGlobalEvents[eventName] = { GetFramesRegisteredForEvent(eventName) };

	for _, frame in ipairs(wlGlobalEvents[eventName]) do
		frame:UnregisterEvent(eventName);
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlGlobalRegister(eventName)
	if type(wlGlobalEvents[eventName]) ~= "table" then
		return;
	end

	for _, frame in ipairs(wlGlobalEvents[eventName]) do
		frame:RegisterEvent(eventName);
	end

	wlGlobalEvents[eventName] = nil;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--



--------------------------
--------------------------
--                      --
--   PARSE  FUNCTIONS   --
--                      --
--------------------------
--------------------------

--	|cff1eff00|Hitem:24742:0:0:0:0:0:-32:1036648482|h[Ranger Boots of Fire Protection]|h|r
--	|cff0070dd|Hitem:18694:464:0:0:0:0:0:0|h[Shadowy Mail Greaves]|h|r

--	(color) : (id) : (enchant) : (1st socket) : (2nd socket) : (3rd socket) : (4th socket) : (subid) : (guid) : (playerLevel) : (name)
local WL_ITEMLINK = "|c(%x+)|Hitem:(%d+):(%-?%d+):(%-?%d+):(%-?%d+):(%-?%d+):(%-?%d+):(%-?%d+):(%-?%d+):(%-?%d+)|h%[(.+)%]|h|r";

function wlParseItemLink(link)
	if link then
		local found, _, color, id, enchant, socket1, socket2, socket3, socket4, subId, guid, pLevel, name = string.find(link, WL_ITEMLINK);

		if found then
			id, subId, guid = tonumber(id), tonumber(subId), tonumber(guid);

			if subId ~= 0 then
				wlUpdateVariable(wlItemSuffix, id, subId, "add", 1);

				if subId < 0 then
					wlUpdateVariable(wlItemSuffix, id, "sF", "set", bit.band(guid, 65535));
				end
			end

			return id, subId, tonumber(enchant), tonumber(socket1), tonumber(socket2), tonumber(socket3), tonumber(socket4), name, color, guid, tonumber(pLevel);
		end
	end

	return 0, 0, 0, 0, 0, 0, 0, "", "", 0, 0;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

-- |cffffff00|Hquest:10002:64|h[The Firewing Liaison]|h|r
-- |cffffff00|Hquest:11506:-1|h[Spirits of Auchindoun]|h|r
-- (color) : (id) : (level) : (name)
local WL_QUESTLINK = "|c(%x+)|Hquest:(%d+):(-?%d+)|h%[(.+)%]|h|r";

function wlParseQuestLink(link)
	if link then
		for color, id, level, name in string.gmatch(link, WL_QUESTLINK) do
			return tonumber(id), tonumber(level), name, color;
		end
	end

	return 0, 0, "", "";
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

-- (id) : (color) : (name)
local WL_SPELLLINK = "|Hspell:(%d+)|h|r|c(%x+)%[(.+)%]|r|h";

function wlParseSpellLink(link)
	if link then
		for id, color, name in string.gmatch(link, WL_SPELLLINK) do
			return tonumber(id), name, color;
		end
	end

	return 0, "", "";
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

 local WL_CURRENCY = {
	["1"]     = string.gsub(COPPER_AMOUNT, "%%d ", ""),
	["100"]   = string.gsub(SILVER_AMOUNT, "%%d ", ""),
	["10000"] = string.gsub(GOLD_AMOUNT,   "%%d ", ""),
 };

function wlParseCoin(strCoin)
	local coin = 0;
	for k, v in pairs(WL_CURRENCY) do
		local found, _, a = string.find(strCoin, "(%d+) " .. v);
		if found then
			coin = coin + a * tonumber(k);
		end
	end

	return coin;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlParseGUID(guid)
	if not guid then
		return;
	end

	local id, kind;

	if guid:match("^0x4") then
		if guid == UnitGUID("npc") then
			id, kind = wlParseItemLink(wlSelectOne(2, GetItemInfo(UnitName("npc")))), "item";
		else
			return nil, "item";
		end

	elseif string.match(guid, "^0xF.1") then
		id, kind = tonumber(string.sub(guid, 6, 12), 16), "object";

	elseif string.match(guid, "^0xF.[35]") then
		id, kind = tonumber(string.sub(guid, 9, 12), 16), "npc";
	end

	if id == 0 then
		id = nil;
	end

	return id, kind;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlParseString(template, str)
	if not template or not str then
		return nil;
	end

	template = string.gsub(template, "%%s", "(.+)");
	template = string.gsub(template, "%%d", "(%%d+)");

	return wlParseFind(string.find(str, template));
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlParseFind(found, _, ...)
	if not found then
		return nil;
	end

	return ...;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlQuestKeywords = nil;
function wlGetSourceText(str, nameOnly) -- @BUG@

	if GetLocale() == "ruRU" then
		return str;
	end

	-- Init
	if not wlQuestKeywords then
		wlQuestKeywords = {};

		-- Race
		local race = UnitRace("player");
		wlQuestKeywords[race] = "R" .. (wlQuestKeywords[race] or "");

		-- Class
		local class = UnitClass("player");
		wlQuestKeywords[class] = "C" .. (wlQuestKeywords[class] or "");

		-- Player name
		local name = UnitName("player");
		wlQuestKeywords[name] = "N" .. (wlQuestKeywords[name] or "");
	end

	if not str or str == "" then
		return "";
	end


	-- Mapping function
	local findNreplace = function(str, word, key)
		-- all string
		if str == word then
			return "$" .. key;
		end

		-- start of string
		str = str:gsub("^" .. word .. "([^%w])", "$" .. key .. "%1");

		-- middle of string
		str = str:gsub("([^%w])" .. word .. "([^%w])", "%1$" .. key .. "%2");

		-- end of string
		str = str:gsub("([^%w])" .. word .. "$", "%1$" .. key);

		return str;
	end;

	-- Scanning...
	for word, key in pairs(wlQuestKeywords) do
		if not nameOnly or key == "N" then
			str = findNreplace(str, word, key); -- Uppercase
			str = findNreplace(str, string.lower(word), string.lower(key)); -- Lowercase
		end
	end

	return str;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--



----------------------------
----------------------------
--                        --
--   COMPUTE  FUNCTIONS   --
--                        --
----------------------------
----------------------------

local WL_OPS = {
	init      = function(a, b) if type(a) ~= "nil" then return a; end return b; end, -- <false> is a valid init state
	initArray = function(a, _) if type(a) ~= "nil" then return a; end return {}; end, -- <false> is a valid init state
	set       = function(_, b) return b; end,
	add       = function(a, b) return (tonumber(a) or 0) + b; end,
	multiply  = function(a, b) return (tonumber(a) or 1) * b; end,
	concat    = function(a, b) return (a or "") .. b; end,
	min       = function(a, b) a, b = tonumber(a), tonumber(b); return a and b and math.min(a, b) or a or b; end,
	max       = function(a, b) a, b = tonumber(a), tonumber(b); return a and b and math.max(a, b) or a or b; end,
};

function wlUpdateVariable(master, first, ...)

	local nParams = select("#", ...);

	if not master or not first or nParams <= 1 then
		return nil;

	elseif nParams == 2 then
		if not WL_OPS[wlSelectOne(1, ...)] then
			return nil;
		end

		master[first] = WL_OPS[wlSelectOne(1, ...)](master[first], wlSelectOne(2, ...));
		return master[first];

	else
		if not master[first] then
			master[first] = {};
		end

		return wlUpdateVariable(master[first], ...);
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlSelectOne(i, ...)
	-- We only want the first returned value
	local v = select(i, ...);

	return v;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlTableWalk(a, f)
	for k, v in pairs(a) do
		a[k] = f(k, v);
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlTableClear(a)
	wlTableWalk(a, function() return false; end);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlGetDate()
	return select(2, CalendarGetDate());
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local wlTimeOffset = nil;
function wlGetTime()
	-- Init
	if not wlTimeOffset then
		local mo, d, y = wlGetDate();
		local h, mi = GetGameTime();

		wlTimeOffset = math.floor((time({ year = y, month = mo, day = d, hour = h, min = mi }) - GetTime()) * 1000);
	end

	return wlTimeOffset + math.floor(GetTime() * 1000);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlIsValidInterval(value1, value2, delta)
	return math.abs(value1 - value2) <= (wlSelectOne(3, GetNetStats()) + delta);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlIsEqualValues(value1, value2, delta)
	return math.abs(value1 - value2) <= delta;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

local UNKNOWNOBJECT, UKNOWNBEING, UNKNOWN = _G.UNKNOWNOBJECT:lower(), _G.UKNOWNBEING:lower(), _G.UNKNOWN:lower();
function wlIsValidName(name)
	return name and name ~= "" and name:lower() ~= UNKNOWNOBJECT and name:lower() ~= UKNOWNBEING and name:lower() ~= UNKNOWN;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlConcat(...)
	return wlConcatToken("^", ...);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlConcatToken(token, ...)
	local str = wlToString(wlSelectOne(1, ...));

	for i = 2, select("#", ...) do
		str = str .. token .. wlToString(wlSelectOne(i, ...));
	end

	return str;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlToString(v)
	local typeV = type(v);

	if typeV == "table" or typeV == "function" or typeV == "thread" or typeV == "userdata" then
		return "<" .. typeV .. ">";

	elseif typeV == "boolean" then
		return v and "<true>" or "<false>";
	end

	return v or "<nil>";
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlTableCopy(Tr, Tx)
	for k, v in pairs(Tx) do
		Tr[k] = v;
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlTableFind(a, f, ...)
	for k, v2 in pairs(a) do
		if type(f) == "function" then
			if f(v2, ...) then
				return k;
			end
		else
			if f == v2 then
				return k;
			end
		end
	end

	for k, v2 in ipairs(a) do
		if type(f) == "function" then
			if f(v2, ...) then
				return k;
			end
		else
			if f == v2 then
				return k;
			end
		end
	end

	return nil;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlTablePrint(t, indent)
	indent = indent or "";

	for k, v in pairs(t) do
		local typeK, typeV = type(k), type(v);

		if typeK == "number" then
			k = indent .. "[" .. k .. "]" .. " = ";
		else
			k = indent .. "[\"" .. k .. "\"]" .. " = ";
		end

		if typeV == "table" then
			wlPrint(k .. "{");
			wlTablePrint(v, indent .. "    ");
			wlPrint(indent .. "},");

		elseif typeV == "function" or typeV == "thread" or typeV == "userdata" then
			wlPrint(k .. "<" .. typeV .. "> ...,");

		elseif typeV == "boolean" then
			wlPrint(k .. "<boolean> " .. (v and "true" or "false") .. ",");

		elseif typeV == "string" then
			wlPrint(k .. "<string> \"" .. v .. "\",");

		else
			wlPrint(k .. "<" .. typeV .. "> " .. (v or k) .. ",");
		end
	end
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlTableConcatKeys(t, token)
	local text, first, temp = "", true;

	for key, value in pairs(t) do
		if type(value) == "table" then
			temp = wlTableConcatKeys(value, token);
		else
			temp = key;
		end

		if temp and temp ~= "" then
			if first then
				first = false;
				text = temp;
			else
				text = text .. token .. temp;
			end
		end
	end

	return text;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlTableIsEmpty(t)
	if type(t) == "table" then
		for _ in pairs(t) do
			return false;
		end
	end

	return true;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--



-------------------------
-------------------------
--                     --
--   HOOK  FUNCTIONS   --
--                     --
-------------------------
-------------------------

function wlHook()
	wlDefaultAcceptQuest = AcceptQuest;
	wlDefaultCompleteQuest = CompleteQuest;
	wlDefaultGetQuestReward = GetQuestReward;
	wlDefaultQuestFrameRewardPanel_OnShow = QuestFrameRewardPanel_OnShow;

	AcceptQuest = wlAcceptQuest;
	CompleteQuest = wlCompleteQuest;
	GetQuestReward = wlGetQuestReward;
	QuestFrameRewardPanel_OnShow = wlQuestFrameRewardPanel_OnShow;

	hooksecurefunc("UseContainerItem", wlUseContainerItem);
	hooksecurefunc("PlaceAuctionBid", wlPlaceAuctionBid);
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlUnhook()
	AcceptQuest = wlDefaultAcceptQuest;
	CompleteQuest = wlDefaultCompleteQuest;
	GetQuestReward = wlDefaultGetQuestReward;
	QuestFrameRewardPanel_OnShow = wlDefaultQuestFrameRewardPanel_OnShow;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--



--------------------------
--------------------------
--                      --
--   STATS  FUNCTIONS   --
--                      --
--------------------------
--------------------------

function wlReset()
	wlVersion, wlUploaded, wlStats, wlExportData, wlRealmList = WL_VERSION, 0, "", "", {};
	wlAuction, wlEvent, wlItemSuffix, wlObject, wlProfile, wlUnit = {}, {}, {}, {}, {}, {};
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlRegisterStats()
	local nDrops, nQuests, nCharacters, _ = 0, 0, 0;

	for _, a in pairs(wlEvent) do
		for _, b in pairs(a) do
			for _, c in pairs(b) do
				if c.what == "loot" then
					nDrops = nDrops + 1;
				elseif c.what == "quest" then
					nQuests = nQuests + 1;
				end
			end
		end
	end

	_, nCharacters = wlExportData:gsub(";", "");

	wlStats = wlConcat(wlArrayLength(wlUnit), wlArrayLength(wlObject), nQuests, nDrops, wlArrayLength(wlAuction, 2), nCharacters, GetLocale(), wlSelectOne(2, GetBuildInfo()));
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlArrayLength(array, depth)
	if not array then
		return 0;
	end

	local count = 0;

	depth = depth or 0;
	if depth > 0 then
		for _, sub in pairs(array) do
			count = count + wlArrayLength(sub, depth - 1);
		end
	else
		for _, _ in pairs(array) do
			count = count + 1;
		end
	end

	return count;
end

--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--

function wlTest(...)
--	wlTablePrint(WorldMapBlobFrame);
--	wlPrint("------------");
--	wlTablePrint(getmetatable(WorldMapBlobFrame));
end
