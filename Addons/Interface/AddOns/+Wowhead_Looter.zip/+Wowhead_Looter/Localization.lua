WL_LOADED = "%s loaded (%d)";
WL_HELP = {
	"|cffffff00Wowhead Looter help:|r",
	"  |cffffff7f/wl nospam|r - Activate/Deactivate the Looter's automatic messages.",
	"  |cffffff7f/wl loc|r - Display your current location in the chat box.",
	"  |cffffff7f/wl loc map|r - Show/hide your location in the world map interface.",
	"  |cffffff7f/wl loc tooltip|r - Show/hide your location in a movable tooltip.",
	"  |cffffff7f/wl loc reset|r - Reset the location tooltip's position.",
	"  |cffffff7f/wl collect|r - Collect completist data.",
	"  |cffffff7f/wl recipes|r - Show the list of known recipes for the profession panel currently opened.",
	"  |cffffff7f/wl mounts|r - List the mounts you own.",
	"  |cffffff7f/wl companions|r - List the companions you own.",
	"  |cffffff7f/wl quests|r - List the quests you have completed.",
};

WL_MESSAGE_TEMPLATE = "%s: %s";
WL_ENABLED     = "|cff00ff00enabled|r";
WL_DISABLED    = "|cffff0000disabled|r";
WL_NA          = NOT_APPLICABLE;
WL_NOSPAM      = "Automatic messages are now %s.";

-- Coordinate
WL_LOC         = "Your current location is %.1f, %.1f.";
WL_LOC_MAP     = "World map coordinates are now %s.";
WL_LOC_TOOLTIP = "Tooltip coordinates are now %s.";
WL_LOC_CURSOR  = "Cursor";

-- Id
WL_ID_TOOLTIP   = "Tooltip ids are now %s.";

-- Completist
WL_UPLOAD_REMINDER     = "Don't forget to upload your collected data using the Wowhead Client!"
WL_COLLECT_DONE        = "Completist data has been collected successfully.";
WL_COLLECT_MSG         = "Character data for %s has been collected successfully.";
WL_COLLECT_PROFESSIONS = "professions";
WL_COLLECT_CRITTERS    = "companions";
WL_COLLECT_MOUNTS      = "mounts";
WL_COLLECT_QUESTS      = "quests";
WL_COLLECT_SKILLS      = "skills";
WL_COLLECT_TITLES      = "titles";
WL_COLLECT_SEP         = ", ";
WL_COLLECT_LASTSEP     = " and ";
WL_COLLECT_TIP         = "Type /wl collect to gather all professions more easily.";

-- Listing
WL_LIST_RECIPES    = "List of known %s recipes:";
WL_LIST_MOUNTS     = "My mounts:";
WL_LIST_COMPANIONS = "My companions:";
WL_LIST_QUESTS     = "Quests I've completed:";

-- Misc
WL_RUNSAWAY = "%s attempts to run away in fear!";


--******************************************************************************


local clientLocale = GetLocale();

if clientLocale == "esES" then

	WL_LOADED = "%s cargado (%d)";

	WL_ENABLED     = "|cff00ff00activadas|r";
	WL_DISABLED    = "|cffff0000desactivadas|r";

	-- Coordinate
	WL_LOC         = "Tu localizaci�n actual es %.1f, %.1f.";
	WL_LOC_MAP     = "Las coordenadas del mapa del Mundo est�n ahora %s.";
	WL_LOC_TOOLTIP = "Las coordenadas de la sugerencia emergente est�n ahora %s.";
	WL_LOC_CURSOR  = "Cursor";

	-- Listing
	WL_LIST_RECIPES = "Lista de %s recetas conocidas:";

	-- Misc
	WL_RUNSAWAY = "�%s intenta huir atemorizado!";
end