local addonname, MOVANY = ...

MovAny.lVirtualMovers = {
	UIPanelMover1 = {
		w = 384,
		h = 512,
		point = {"TOPLEFT", "UIParent", "TOPLEFT", 0, -104},
		OnMAAttach = MovAny.ShowUIPanel,
		OnMAPosition = MovAny.ShowUIPanel,
		OnMAAlpha = MovAny.ShowUIPanel,
		OnMAScale = MovAny.ShowUIPanel,
	},
	UIPanelMover2 = {
		w = 384,
		h = 512,
		point = {"TOPLEFT", "UIParent", "TOPLEFT", 384, -104},
		OnMAAttach = MovAny.ShowUIPanel,
		OnMAPosition = MovAny.ShowUIPanel,
		OnMAAlpha = MovAny.ShowUIPanel,
		OnMAScale = MovAny.ShowUIPanel,
	},
	TooltipMover = {
		frameStrata="TOOLTIP",
		w = 150,
		h = 80,
		point = {"TOP", "UIParent", 0, 0},
		OnShow = function()
			self:SetFrameLevel(GameTooltip:GetFrameLevel() + 1)
		end,
		OnMAPostHook = function(self)
			MovAny:HookTooltip(self)
		end,
		OnMAPosition = function(self)
			MovAny:HookTooltip(self)
		end,
		OnMAPreReset = function(self, opt)
			local tooltip = GameTooltip
			MovAny:UnlockPoint(tooltip)
			MovAny:ResetScale(tooltip, opt, true)
			MovAny:ResetAlpha(tooltip, opt, true)
			MovAny:ResetHide(tooltip, opt, true)
		end,
	},
	BagItemTooltipMover = {
		frameStrata="TOOLTIP",
		w = 150,
		h = 80,
		point = {"TOP", "UIParent", 0, 0},
		OnLoad = function(self)
			self:SetFrameLevel(GameTooltip:GetFrameLevel() + 1)
		end,
		OnMAPreReset = function(self, opt)
			local tooltip = GameTooltip
			MovAny:UnlockPoint(tooltip)
			MovAny:ResetScale(tooltip, opt, true)
			MovAny:ResetAlpha(tooltip, opt, true)
			MovAny:ResetHide(tooltip, opt, true)
		end
	},
	BagButtonsMover = {
		w = 196,
		h = 44,
		point = {"BOTTOMRIGHT", "MainMenuBarArtFrame", "BOTTOMRIGHT", -6, -2},
		excludes = "BagButtonsVerticalMover",
		children = {
			"MainMenuBarBackpackButton",
			"CharacterBag0Slot",
			"CharacterBag1Slot",
			"CharacterBag2Slot",
			"CharacterBag3Slot",
		},
		OnMAFoundChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("RIGHT", self, "RIGHT", 0, 0)
			else
				child:SetPoint("RIGHT", self.lastChild, "LEFT", -4, 0)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("BOTTOMRIGHT", "MainMenuBarArtFrame", "BOTTOMRIGHT", -6, -2)
			else
				child:SetPoint("RIGHT", self.lastChild, "LEFT", -4, 0)
			end
		end,
	},
	BagButtonsVerticalMover = {
		w = 44,
		h = 173,
		point = {"BOTTOMRIGHT", "MainMenuBarArtFrame", "BOTTOMRIGHT", -6, -2},
		excludes = "BagButtonsMover",
		notMAParent = true,
		children = {
			"MainMenuBarBackpackButton",
			"CharacterBag0Slot",
			"CharacterBag1Slot",
			"CharacterBag2Slot",
			"CharacterBag3Slot",
		},
		OnMAFoundChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("BOTTOM", self, "BOTTOM", 0, 0)
			else
				child:SetPoint("BOTTOM", self.lastChild, "TOP", 0, 3)
			end
			child.MAParent = self
		end,
		OnMAReleaseChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("BOTTOMRIGHT", "MainMenuBarArtFrame", "BOTTOMRIGHT", -6, -2)
			else
				child:SetPoint("RIGHT", self.lastChild, "LEFT", -4, 0)
			end
			child.MAParent = "BagButtonsMover"
		end,
	},
	BagFrame1 = {
		inherits = "MovableBagFrame",
		id = 0,
	},
	BagFrame2 = {
		inherits = "MovableBagFrame",
		id = 1,
	},
	BagFrame3 = {
		inherits = "MovableBagFrame",
		id = 2,
	},
	BagFrame4 = {
		inherits = "MovableBagFrame",
		id = 3,
	},
	BagFrame5 = {
		inherits = "MovableBagFrame",
		id = 4,
	},
	BankBagFrame1 = {
		inherits = "MovableBagFrame",
		id = 5,
	},
	BankBagFrame2 = {
		inherits = "MovableBagFrame",
		id = 6,
	},
	BankBagFrame3 = {
		inherits = "MovableBagFrame",
		id = 7,
	},
	BankBagFrame4 = {
		inherits = "MovableBagFrame",
		id = 8,
	},
	BankBagFrame5 = {
		inherits = "MovableBagFrame",
		id = 9,
	},
	BankBagFrame6 = {
		inherits = "MovableBagFrame",
		id = 10,
	},
	BankBagFrame7 = {
		inherits = "MovableBagFrame",
		id = 11,
	},
	KeyRingFrame = {
		inherits = "MovableBagFrame",
		id = -2,
	},
	MicroButtonsMover = {
		w = 253,
		h = 36,
		point = {"BOTTOMLEFT", "MainMenuBarArtFrame", "BOTTOMLEFT", 549, 2},
		excludes = "MicroButtonsVerticalMover",
		children = { CharacterMicroButton, SpellbookMicroButton,
			TalentMicroButton, AchievementMicroButton, QuestLogMicroButton,
			GuildMicroButton, PVPMicroButton, LFDMicroButton,
			MainMenuMicroButton, HelpMicroButton },
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT")
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("BOTTOMLEFT", "MainMenuBarArtFrame", "BOTTOMLEFT", 548, 2)
			end
		end,
	},
	MicroButtonsVerticalMover = {
		w = 28,
		h = 340,
		point = {"BOTTOMLEFT", "MainMenuBarArtFrame", "BOTTOMLEFT", 546, 2},
		excludes = "MicroButtonsMover",
		notMAParent = true,
		children = { CharacterMicroButton, SpellbookMicroButton,
			TalentMicroButton, AchievementMicroButton, QuestLogMicroButton,
			GuildMicroButton, PVPMicroButton, LFDMicroButton,
			MainMenuMicroButton, HelpMicroButton },
		OnMAFoundChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("TOPLEFT", self, "TOPLEFT", 0, 24)
			else
				child:SetPoint("TOPLEFT", self.lastChild, "BOTTOMLEFT", 0, 24)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			child.MAParent = "MicroButtonsMover"
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("BOTTOMLEFT", "MainMenuBarArtFrame", "BOTTOMLEFT", 546, 2)
			else
				child:SetPoint("BOTTOMLEFT", self.lastChild, "BOTTOMRIGHT", -2, 0)
			end
		end,
	},
	BasicActionButtonsMover = {
		w = 498,
		h = 38,
		point = {"BOTTOMLEFT", "MainMenuBarArtFrame", "BOTTOMLEFT", 8, 3},
		protected = true,
		excludes = "BasicActionButtonsVerticalMover",
		prefix = "ActionButton",
		count = 12,
		--[[
		prefix1 = "BonusActionButton",
		OnMAFoundChild = function(self, index, child, prefix)
			if prefix == 0 then
				if index == 1 then
					child:SetPoint("LEFT", self, "LEFT")
				else
					child:SetPoint("LEFT", self.lastChild, "RIGHT", 6, 0)
				end
			else
				child:SetPoint("CENTER", self.prefix..index, "CENTER")
			end
		end,
		OnMAReleaseChild = function(self, index, child, prefix)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("BOTTOMLEFT", "MainMenuBarArtFrame", "BOTTOMLEFT", 546, 2)
			else
				child:SetPoint("BOTTOMLEFT", prefix, "BOTTOMRIGHT", -2, 0)
			end
		end,
		]]
		OnMAHook = function(self)
			local b, bab
			ActionButton1:ClearAllPoints()
			if ActionButton1.MASetPoint then
				ActionButton1:MASetPoint("LEFT", self, "LEFT")
			else
				ActionButton1:SetPoint("LEFT", self, "LEFT")
			end
			ActionBarUpButton:ClearAllPoints()
			ActionBarUpButton:SetPoint("TOPLEFT", "ActionButton12", "TOPRIGHT", 0, 7)
			ActionBarDownButton:ClearAllPoints()
			ActionBarDownButton:SetPoint("BOTTOMLEFT", "ActionButton12", "BOTTOMRIGHT", 0, -9)
			for i = 1, 12, 1 do
				b = _G["ActionButton"..i]
				if i > 1 then
					b:ClearAllPoints()
					b:SetPoint("LEFT", "ActionButton"..(i-1), "RIGHT", 6, 0)
				end
				bab = _G[ "BonusActionButton"..i ]
				bab:ClearAllPoints()
				bab:SetPoint("CENTER", b, "CENTER")
				bab.MAParent = self
				tinsert(self.attachedChildren, _G["BonusActionButton"..i])
			end
			tinsert(self.attachedChildren, ActionBarUpButton)
			tinsert(self.attachedChildren, ActionBarDownButton)
			
			MovAny:LockPoint(ActionButton1)
			MovAny:LockPoint(BonusActionButton1)
		end,
		OnMAPostReset = function(self)
			MovAny:UnlockPoint(ActionButton1)
			MovAny:UnlockPoint(BonusActionButton1)
			local b
			ActionButton1:ClearAllPoints()
			if ActionButton1.MASetPoint then
				ActionButton1:MASetPoint("BOTTOMLEFT", "MainMenuBarArtFrame", "BOTTOMLEFT", 8, 4)
			else
				ActionButton1:SetPoint("BOTTOMLEFT", "MainMenuBarArtFrame", "BOTTOMLEFT", 8, 4)
			end
			ActionBarUpButton:ClearAllPoints()
			ActionBarUpButton:SetPoint("CENTER", "MainMenuBarArtFrame", "TOPLEFT", 522, -22)
			ActionBarDownButton:ClearAllPoints()
			ActionBarDownButton:SetPoint("CENTER", "MainMenuBarArtFrame", "TOPLEFT", 522, -42)
			for i = 1, 12, 1 do
				b = _G[ "ActionButton"..i ]
				if i > 1 then
					b:ClearAllPoints()
					b:SetPoint("LEFT", "ActionButton"..(i-1), "RIGHT", 6, 0)
				end
				_G[ "BonusActionButton"..i ]:ClearAllPoints()
				_G[ "BonusActionButton"..i ]:SetPoint("CENTER", b, "CENTER")
			end
		end,
	},
	BasicActionButtonsVerticalMover = {
		w = 38,
		h = 475,
		point = {"BOTTOMLEFT", "MainMenuBarArtFrame", "BOTTOMLEFT", 8, 4},
		protected = true,
		excludes = "BasicActionButtonsMover",
		OnMAHook = function(self)
			local b, pb
			ActionButton1:ClearAllPoints()
			ActionButton1:SetPoint("TOP", self, "TOP", 0, 0)
			for i = 1, 12, 1 do
				b = _G[ "ActionButton"..i ]
				tinsert(self.attachedChildren, _G[ "ActionButton"..i ])
				tinsert(self.attachedChildren, _G[ "BonusActionButton"..i ])
				if i > 1 then
					pb = _G[ "ActionButton"..(i-1) ]
					b:ClearAllPoints()
					b:SetPoint("TOP", pb, "BOTTOM", 0, -2)
				end
				b.MAParent = self
				_G[ "BonusActionButton"..i ]:ClearAllPoints()
				_G[ "BonusActionButton"..i ]:SetPoint("CENTER", b, "CENTER")
			end
			tinsert(self.attachedChildren, ActionBarUpButton)
			tinsert(self.attachedChildren, ActionBarDownButton)
			ActionBarUpButton:ClearAllPoints()
			ActionBarUpButton:SetPoint("TOPLEFT", "ActionButton12", "BOTTOMLEFT", -8, 4)
			ActionBarDownButton:ClearAllPoints()
			ActionBarDownButton:SetPoint("TOPRIGHT", "ActionButton12", "BOTTOMRIGHT", 8, 4)
		end,
		OnMAPostReset = function(self)
			local b, pb
			ActionButton1:ClearAllPoints()
			ActionButton1:SetPoint("BOTTOMLEFT", "MainMenuBarArtFrame", "BOTTOMLEFT", 8, 4)
			ActionBarUpButton:ClearAllPoints()
			ActionBarUpButton:SetPoint("CENTER", "MainMenuBarArtFrame", "TOPLEFT", 522, -22)
			ActionBarDownButton:ClearAllPoints()
			ActionBarDownButton:SetPoint("CENTER", "MainMenuBarArtFrame", "TOPLEFT", 522, -42)
			for i = 1, 12, 1 do
				b = _G[ "ActionButton"..i ]
				b.MAParent = BasicActionButtonsMover
				if i > 1 then
					pb = _G[ "ActionButton"..(i-1) ]
					b:ClearAllPoints()
					b:SetPoint("LEFT", pb, "RIGHT", 6, 0)
				end
				_G[ "BonusActionButton"..i ]:ClearAllPoints()
				_G[ "BonusActionButton"..i ]:SetPoint("CENTER", b, "CENTER")
			end
		end,
	},
	PetActionButtonsMover = {
		w = 370,
		h = 32,
		point = {"BOTTOMLEFT", "PetActionBarFrame", "BOTTOMLEFT", 370, 32},
		excludes = "PetActionButtonsVerticalMover",
		protected = true,
		prefix = "PetActionButton",
		count = 10,
		OnMAFoundChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("LEFT", self, "LEFT", 0, 0)
			else
				child:SetPoint("LEFT", self.lastChild, "RIGHT", 4, 0)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("BOTTOMLEFT", "PetActionBarFrame", "BOTTOMLEFT", 36, 1)
			else
				child:SetPoint("LEFT", self.lastChild, "RIGHT", 8, 0)
			end
		end,
	},
	PetActionButtonsVerticalMover = {
		w = 43,
		h = 370,
		point = {"BOTTOMLEFT", "PetActionBarFrame", "BOTTOMLEFT", 36, 1},
		excludes = "PetActionButtonsMover",
		notMAParent = true,
		protected = true,
		prefix = "PetActionButton",
		count = 10,
		OnMAFoundChild = function(self, index, child)
			child.MAParent = self
			if index == 1 then
				child:SetPoint("TOP", self, "TOP", 0, 0)
			else
				child:SetPoint("TOP", self.lastChild, "BOTTOM", 0, -3)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			child.MAParent = "PetActionButtonsMover"
			if index == 1 then
				child:SetPoint("BOTTOMLEFT", "PetActionBarFrame", "BOTTOMLEFT", 36, 1)
			else
				child:SetPoint("LEFT", self.lastChild, "RIGHT", 8, 0)
			end
		end,
	},
	ShapeshiftButtonsMover = {
		w = 225,
		h = 32,
		point = {"BOTTOMLEFT", "MainMenuBar", "TOPLEFT", 30, 0},
		excludes = "ShapeshiftButtonsVerticalMover",
		protected = true,
		prefix = "ShapeshiftButton",
		count = 10,
		OnMAHook = function(self)
			ShapeshiftBarFrame:DisableDrawLayer("BACKGROUND")
			ShapeshiftBarFrame:DisableDrawLayer("BORDER")
			MovAny:UnlockPoint(ShapeshiftBarFrame)
			ShapeshiftBarFrame:ClearAllPoints()
			ShapeshiftBarFrame:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 0, 0)
			MovAny:LockPoint(ShapeshiftBarFrame)
		end,
		OnMAPosition = function(self)
			MovAny:UnlockPoint(ShapeshiftBarFrame)
			ShapeshiftBarFrame:ClearAllPoints()
			ShapeshiftBarFrame:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 0, 0)
			MovAny:LockPoint(ShapeshiftBarFrame)
		end,
		OnMAAttach = function(self, mover)
			MovAny:UnlockPoint(ShapeshiftBarFrame)
			ShapeshiftBarFrame:ClearAllPoints()
			ShapeshiftBarFrame:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 0, 0)
			MovAny:LockPoint(ShapeshiftBarFrame)
		end,
		OnMAPreReset = function(self)
			MovAny:UnlockPoint(ShapeshiftBarFrame)
		end,
		OnMAPostReset = function(self)
			ShapeshiftBarFrame:EnableDrawLayer("BACKGROUND")
			ShapeshiftBarFrame:EnableDrawLayer("BORDER")
		end,
		OnMAHide = function(self, hidden)
			if hidden then
				MovAny:LockVisibility(ShapeshiftBarFrame)
			else
				MovAny:UnlockVisibility(ShapeshiftBarFrame)
			end
		end,
	},
	ShapeshiftButtonsVerticalMover = {
		w = 32,
		h = 225,
		point = {"BOTTOMLEFT", "ShapeshiftBarFrame", "BOTTOMLEFT", 11, 3},
		excludes = "ShapeshiftButtonsMover",
		notMAParent = true,
		protected = true,
		prefix = "ShapeshiftButton",
		count = 10,
		OnMAHook = function(self)
			ShapeshiftBarFrame:DisableDrawLayer("BACKGROUND")
			ShapeshiftBarFrame:DisableDrawLayer("BORDER")
		end,
		OnMAPostReset = function(self)
			ShapeshiftBarFrame:EnableDrawLayer("BACKGROUND")
			ShapeshiftBarFrame:EnableDrawLayer("BORDER")
		end,
		OnMAFoundChild = function(self, index, child)
			child.MAParent = self
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("TOP", self, "TOP", 0, -7)
			else
				child:SetPoint("TOP", self.lastChild, "BOTTOM", 0, -7)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			child.MAParent = "PetActionButtonsMover"
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("BOTTOMLEFT", "ShapeshiftBarFrame", "BOTTOMLEFT", 11, 3)
			else
				child:SetPoint("LEFT", self.lastChild, "RIGHT", 8, 0)
			end
		end,
	},
	MultiBarRightHorizontalMover = {
		w = 498,
		h = 38,
		point = {"BOTTOM", "UIParent", "BOTTOM", 0, 250},
		excludes = "MultiBarRight",
		notMAParent = true,
		protected = true,
		prefix = "MultiBarRightButton",
		count = 12,
		OnMAFoundChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("TOPLEFT", self)
			else
				child:SetPoint("LEFT", self.lastChild, "RIGHT", 6, 0)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("TOPRIGHT", "MultiBarRight")
			else
				child:SetPoint("TOP", self.lastChild, "BOTTOM", 0, -6)
			end
			child.MAParent = nil
		end,
	},
	MultiBarLeftHorizontalMover = {
		w = 498,
		h = 38,
		point = {"BOTTOM", "UIParent", "BOTTOM", 0, 285},
		excludes = "MultiBarLeft",
		notMAParent = true,
		protected = true,
		prefix = "MultiBarLeftButton",
		count = 12,
		OnMAFoundChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("TOPLEFT", self)
			else
				child:SetPoint("LEFT", self.lastChild, "RIGHT", 6, 0)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			child:ClearAllPoints()
			if index == 1 then
				child:SetPoint("TOPRIGHT", "MultiBarLeft")
			else
				child:SetPoint("TOP", self.lastChild, "BOTTOM", 0, -6)
			end
			child.MAParent = nil
		end,
	},
	PartyMember1DebuffsMover = {
		w = 66,
		h = 15,
		point = {"TOPLEFT", "PartyMemberFrame1", "TOPLEFT", 48, -32},
		prefix = "PartyMemberFrame1Debuff",
		count = MAX_PARTY_DEBUFFS,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", "PartyMemberFrame1", 48, -32)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["PartyMemberFrame1"]:GetEffectiveScale() / UIParent:GetScale())
		end,
	},
	PartyMember2DebuffsMover = {
		w = 66,
		h = 15,
		point = {"TOPLEFT", "PartyMemberFrame2", "TOPLEFT", 48, -32},
		prefix = "PartyMemberFrame2Debuff",
		count = MAX_PARTY_DEBUFFS,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", "PartyMemberFrame2", 48, -32)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["PartyMemberFrame2"]:GetEffectiveScale() / UIParent:GetScale())
		end,
	},
	PartyMember3DebuffsMover = {
		w = 66,
		h = 15,
		point = {"TOPLEFT", "PartyMemberFrame3", "TOPLEFT", 48, -32},
		prefix = "PartyMemberFrame3Debuff",
		count = MAX_PARTY_DEBUFFS,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", "PartyMemberFrame3", 48, -32)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["PartyMemberFrame3"]:GetEffectiveScale() / UIParent:GetScale())
		end,
	},
	PartyMember4DebuffsMover = {
		w = 66,
		h = 17,
		point = {"TOPLEFT", "PartyMemberFrame4", "TOPLEFT", 48, -32},
		prefix = "PartyMemberFrame4Debuff",
		count = MAX_PARTY_DEBUFFS,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", "PartyMemberFrame4", 48, -32)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["PartyMemberFrame4"]:GetEffectiveScale() / UIParent:GetScale())
		end,
	},
	PetDebuffsMover = {
		w = 66,
		h = 17,
		point = {"TOPLEFT", "PetFrame", "TOPLEFT", 48, -42},
		prefix = "PetFrameDebuff",
		count = 4,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self, "TOPLEFT", 1, -1)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", "PetFrame", 48, -42)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["PetFrame"]:GetEffectiveScale() / UIParent:GetScale())
		end,
	},
	TargetBuffsMover = {
		w = 122,
		h = 17,
		point = {"TOPLEFT", "TargetFrame", "BOTTOMLEFT", 5, 32},
		prefix = "TargetFrameBuff",
		count = MAX_TARGET_BUFFS,
		OnLoad = function(self)
			if TargetFrame_UpdateAuras then
				hooksecurefunc("TargetFrame_UpdateAuras", function(frame)
					if frame == TargetFrame and MovAny:IsModified(self, nil, self.opt) then
						self:MAScanForChildren()
					end
				end)
			end
		end,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", TargetFrame, "BOTTOMLEFT", 5, 32)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["TargetFrame"]:GetEffectiveScale() / UIParent:GetScale())
		end,
	},
	TargetDebuffsMover = {
		w = 122,
		h = 23,
		point = {"TOPLEFT", "TargetFrame", "BOTTOMLEFT", 5, 35},
		prefix = "TargetFrameDebuff",
		count = MAX_TARGET_DEBUFFS,
		--dontLock = true,
		OnLoad = function(self)
			if TargetFrame_UpdateAuras then
				hooksecurefunc("TargetFrame_UpdateAuras", function(frame)
					if frame == TargetFrame and MovAny:IsModified(self, nil, self.opt) then
						self:MAScanForChildren()
					end
				end)
			end
		end,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self, "TOPLEFT", 1, -1)
				--MovAny:LockPoint(child)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				--MovAny:UnlockPoint(child)
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", TargetFrame, "BOTTOMLEFT", 5, 35)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["TargetFrame"]:GetEffectiveScale() / UIParent:GetScale())
		end,
		--[[
		OnMAPostReset = function(self)
			--XXX should prolly call TargetFrame_UpdateAuras(TargetFrame) providing it has already been called
		end,]]
	},
	FocusBuffsMover = {
		w = 124,
		h = 23,
		point = {"TOPLEFT", "FocusFrame", "BOTTOMLEFT", 4, 33},
		prefix = "FocusFrameBuff",
		count = MAX_TARGET_BUFFS,
		OnLoad = function(self)
			if TargetFrame_UpdateAuras then
				hooksecurefunc("TargetFrame_UpdateAuras", function(frame)
					if frame == FocusFrame and MovAny:IsModified(self, nil, self.opt) then
						self:MAScanForChildren()
					end
				end)
			end
		end,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self, "TOPLEFT", 1, -1)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", FocusFrame, "BOTTOMLEFT", 5, 35)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["FocusFrame"]:GetEffectiveScale() / UIParent:GetScale())
		end,
		--[[
		OnMAPostReset = function(self)
			--XXX should prolly call TargetFrame_UpdateAuras(FocusFrame) providing it has already been called
		end,
		]]
	},
	FocusDebuffsMover = {
		w = 124,
		h = 21,
		point = {"TOPLEFT", "FocusFrame", "BOTTOMLEFT", 4, 33},
		prefix = "FocusFrameDebuff",
		count = MAX_TARGET_DEBUFFS,
		OnLoad = function(self)
			if TargetFrame_UpdateAuras then
				hooksecurefunc("TargetFrame_UpdateAuras", function(frame)
					if frame == FocusFrame and MovAny:IsModified(self, nil, self.opt) then
						self:MAScanForChildren()
					end
				end)
			end
		end,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self, "TOPLEFT", 1, -1)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", FocusFrame, "BOTTOMLEFT", 4, 33)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["FocusFrame"]:GetEffectiveScale() / UIParent:GetScale())
		end,
		--[[
		OnMAPostReset = function(self)
			--XXX should prolly call TargetFrame_UpdateAuras(FocusFrame) providing it has already been called
		end,
		]]
	},
	TargetFrameToTDebuffsMover = {
		w = 30,
		h = 30,
		point = {"TOPLEFT", "TargetFrameToT", "TOPRIGHT", 3, -9},
		prefix = "TargetFrameToTDebuff",
		count = 4,
		OnLoad = function(self)
			if TargetFrame_CreateTargetofTarget then
				hooksecurefunc("TargetFrame_CreateTargetofTarget", function(frame)
					if frame == TargetFrame and MovAny:IsModified(self, nil, self.opt) then
						self:MAScanForChildren()
					end
				end)
			end
		end,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self, "TOPLEFT", 1, -1)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", TargetFrameToT, "TOPRIGHT", 4, -10)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["TargetFrameToT"]:GetEffectiveScale() / UIParent:GetScale())
		end,
	},
	PlayerBuffsMover = {
		w = 31,
		h = 31,
		point = {"TOPRIGHT", "UIParent", "TOPRIGHT", -205, -13},
		prefix = "BuffButton",
		count = 32,
		dontHide = true,
		dontLock = true,
		OnLoad = function(self)
			if BuffFrame_Update then
				local opt
				hooksecurefunc("BuffFrame_Update", function()
					opt = self.opt
					if opt and not opt.disabled and MovAny:IsModified(self, nil, opt) then
						self:MAScanForChildren()
						if not opt.hidden and self.attachedChildren and GetCVar("consolidateBuffs") == "1" and self.opt.scale then
							self.cb:SetScale(self.opt.scale)
							for i, v in pairs(self.attachedChildren) do
								MovAny:UnlockScale(v)
								if v:GetParent() ~= BuffFrame then
									v:SetScale(1)
								else
									v:SetScale(self.opt.scale)
								end
								MovAny:LockScale(v)
							end
						end
					end
				end)
			end
		end,
		OnMAHook = function(self)
			local b = _G["BuffFrame"]
			self:SetScale(b:GetEffectiveScale() / UIParent:GetScale())
			b:SetPoint("TOPRIGHT", self, "TOPRIGHT", 0, 0)
			MovAny:LockPoint(b)
			b = _G["ConsolidatedBuffs"]
			b:SetPoint("TOPRIGHT", self, "TOPRIGHT", 0, 0)
			MovAny:LockPoint(b)
			self.cb = b
			if self.opt and self.opt.scale then
				b:SetScale(self.opt.scale)
			end
			if BuffFrame.numConsolidated == 0 then
				b:Hide()
			end
			if self.attachedChildren and GetCVar("consolidateBuffs") == "1" then
				if self.opt and self.opt.scale then
					self.cb:SetScale(self.opt.scale)
					if self.attachedChildren then
						for i, v in pairs(self.attachedChildren) do
							MovAny:UnlockScale(v)
							if v:GetParent() ~= BuffFrame then
								v:SetScale(1)
							else
								v:SetScale(self.opt.scale)
							end
							MovAny:LockScale(v)
						end
					end
				end
			end
		end,
		OnMAPostReset = function(self)
			local b = _G["BuffFrame"]
			MovAny:UnlockPoint(b)
			b:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -205, -13)
			b = _G["ConsolidatedBuffs"]
			MovAny:UnlockPoint(b)
			b:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -180, -13)
		end,
		OnMAHide = function(self, hidden)
			if hidden then
				MovAny:LockVisibility(_G["ConsolidatedBuffs"])
				MovAny:LockVisibility(_G["BuffFrame"])
			else
				MovAny:UnlockVisibility(_G["ConsolidatedBuffs"])
				MovAny:UnlockVisibility(_G["BuffFrame"])
			end
		end,
	},
	PlayerDebuffsMover = {
		w = 31,
		h = 31,
		prefix = "DebuffButton",
		count = 16,
		point = {"TOPRIGHT", "BuffFrame", "BOTTOMRIGHT", 0, -50},
		OnLoad = function(self)
			if BuffFrame_Update then
				hooksecurefunc("BuffFrame_Update", function()
					if MovAny:IsModified(self, nil, self.opt) then
						self:MAScanForChildren()
					end
				end)
			end
		end,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPRIGHT", self, "TOPRIGHT", -1, -1)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPRIGHT", ConsolidatedBuffs, "BOTTOMRIGHT", 0, -TempEnchant1:GetHeight()*3)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["BuffFrame"]:GetEffectiveScale() / UIParent:GetScale())
		end,
	},
	TargetOfFocusDebuffsMover = {
		w = 30,
		h = 30,
		point = {"BOTTOMLEFT", "TargetOfFocusFrame", "BOTTOMLEFT", 13, 12},
		prefix = "TargetOfFocusFrameDebuff",
		count = 8,
		OnMAFoundChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("TOPLEFT", self)
			end
		end,
		OnMAReleaseChild = function(self, index, child)
			if index == 1 then
				child:ClearAllPoints()
				child:SetPoint("BOTTOMLEFT", "FocusFrame", 13, 12)
			end
		end,
		OnMAHook = function(self)
			self:SetScale(_G["TargetOfFocusFrame"]:GetEffectiveScale() / UIParent:GetScale())
		end,
	},
}