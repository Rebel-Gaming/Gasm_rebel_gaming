WoW WotLK Daily Calculator Help File

1. How to use it
2. Known Bugs
3. How to Remove
4. Copyright

1. How to use it

Just select the dailies you want to do. Beside each daily is the gold amount, rep amount and any other
rewards. If you are a human, select the Human Rep Bonus checkbox (read below on a current error). To
start over just hit the Reset button.

2. Known Bugs

Deselecting the Human 10% Rep Bonus Button will not work properly. You have to use the reset button
to get things back to normal. This will most likely not be fixed due to having to recode entire program.

3. How to Remove

Go Start Menu > Control Panel > Add/Remove Programs
Now find "WoW WotLK Daily Calculator" in the list, select it and press "Change/Remove"
Now make sure "Remove Application" is selected and press "ok"
Your done!

4. Copyright

I don't really care if you publish this somewhere else. Just send me an email telling me where your
putting it so I know.

Email: aaron-221@hotmail.com
