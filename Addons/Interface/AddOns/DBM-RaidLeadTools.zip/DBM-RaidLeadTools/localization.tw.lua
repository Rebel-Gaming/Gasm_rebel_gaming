
if GetLocale() ~= "zhTW" then return end
local L = DBM_Raidlead_Translation

