
if GetLocale() ~= "deDE" then return end
local L = DBM_Raidlead_Translation

L.Area_Raidleadtool				= "Zusätzliche Raidleitungs Optionen"
L.ShowWarningForLootMaster		= "Zeige eine Warnung wenn bei Kampfanfang kein Plündermeister eingestellt ist"


L.Warning_NoLootMaster			= "Plündermeister ist aus! - Bitte vergiss nicht Plündermeister zu aktivieren!"



