
if GetLocale() ~= "zhCN" then return end
local L = DBM_Raidlead_Translation


