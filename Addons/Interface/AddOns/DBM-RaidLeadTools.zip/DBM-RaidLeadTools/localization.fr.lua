
if GetLocale() ~= "frFR" then return end
local L = DBM_Raidlead_Translation


