
DBM_Raidlead_Translation = {}

local L = DBM_Raidlead_Translation

L.Area_Raidleadtool				= "Additional Raidlead options"
L.ShowWarningForLootMaster		= "Show a warning on combatstart if Masterloot is not enabled"

L.Warning_NoLootMaster			= "Lootmaster is currently disabled! - Please enable Lootmaster now!"

L.StickyIcons					= "Always set Raidicons back to as they where on Combatstart"


