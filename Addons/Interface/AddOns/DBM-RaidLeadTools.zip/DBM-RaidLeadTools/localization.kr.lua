
if GetLocale() ~= "koKR" then return end
local L = DBM_Raidlead_Translation


