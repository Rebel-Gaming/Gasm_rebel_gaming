﻿--[[---------------------------------------------------------------------------

Copyright (c) 2009 by Rich Cushing
All Rights Reserved

E-mail: < brillynt@gmail.com >

This file is a addon to nUI.

    nUI is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    nUI is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with nUI.  If not, see <http://www.gnu.org/licenses/>.
	
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

--]]---------------------------------------------------------------------------

if not nUI_InfoPanels then nUI_InfoPanels = {}; end

local CreateFrame = CreateFrame;
local MouseIsOver = MouseIsOver;

nUI_INFOMODE_HEALBOT  = 9;
nUI_INFOPANEL_HEALBOT = "nUI_InfoPanel_HealBot";

nUI_L[nUI_INFOPANEL_HEALBOT]	      		= "Info Panel: HealBot Mode";
nUI_L[nUI_INFOPANEL_HEALBOT.."Label"]		= "HealBot";


local CreateFrame = CreateFrame;
local GetTime     = GetTime;

-------------------------------------------------------------------------------
-- default configuration for the HealBot info panel

nUI_InfoPanels[nUI_INFOPANEL_HEALBOT] =
{	
	enabled   = true,
	desc      = nUI_L[nUI_INFOPANEL_HEALBOT],			-- player friendly name/description of the panel
	label     = nUI_L[nUI_INFOPANEL_HEALBOT.."Label"],	-- label to use on the panel selection button face
	rotation  = nUI_INFOMODE_HEALBOT,					-- index or position this panel appears on/in when clicking the selector button
	full_size = true;									-- this plugin requires the entire info panel port without the button bag
	
	options  =
	{
		enabled  = true,
	},
};

-------------------------------------------------------------------------------
-- master frame for the plugin

local plugin    = CreateFrame( "Frame", nUI_INFOPANEL_HEALBOT, nUI_Dashboard.Anchor );
plugin.active   = true;

local function onHealBotEvent()
	
	if event == "VARIABLES_LOADED" then
		
		if not IsAddOnLoaded( "HealBot" ) then 
			LoadAddOn( "HealBot" );
		end
		
		plugin.active = IsAddOnLoaded( "HealBot" );

	end	
	
end

plugin:SetScript( "OnEvent", onHealBotEvent );
plugin:RegisterEvent( "VARIABLES_LOADED" );

-------------------------------------------------------------------------------

plugin.initPanel = function( container, options )

	plugin.container = container;
	plugin.options   = options;

	if options and options.enabled then
			
		plugin.setEnabled( true );
		
	end
end

-------------------------------------------------------------------------------

plugin.sizeChanged = function( scale, height, width )
	
	local options  = plugin.options;
	local HB_Frame   = plugin.HB_Frame;
	
	plugin.scale = scale;

	nUI_Movers:lockFrame( HB_Frame, false, nil );
	
	HealBot_Options_DisableHealBot:SetChecked(1);
	HealBot_Options_ToggleHealBot(1);

	HB_Frame:SetWidth( width + 10); 
	HB_Frame:SetHeight( height + 10 ); 

    HealBot_Options_DisableHealBot:SetChecked(0);
    HealBot_Options_ToggleHealBot(0);
	
	nUI_Movers:lockFrame( HB_Frame, true, nil );
			
end	

-------------------------------------------------------------------------------

plugin.setEnabled = function( enabled )

	if plugin.enabled ~= enabled then
		
		plugin.enabled = enabled;
		
		if not enabled then

			local HB_Frame = plugin.HB_Frame;
			
			if HB_Frame.saved_parent then

				nUI_Movers:lockFrame( HB_Frame, false, nil );
				
				HB_Frame:SetParent( HB_Frame.saved_parent );
				HB_Frame:SetBackdropBorderColor( HB_Frame.border_color );
				HB_Frame:SetBackdropColor( HB_Frame.backdrop_color );

				HealBot_Options_DisableHealBot:SetChecked(1);
				HealBot_Options_ToggleHealBot(1);
				
			end
		
		else

			local HB_Frame = HealBot_Action;
			
			plugin.HB_Frame = HB_Frame;
			
			if not HB_Frame.saved_parent then
				HB_Frame.saved_parent   = HB_Frame:GetParent();
				HB_Frame.border_color   = HB_Frame:GetBackdropBorderColor();
				HB_Frame.backdrop_color = HB_Frame:GetBackdropColor();
			end
			
			HB_Frame:SetParent( plugin.container );
			HB_Frame:SetPoint( "TOPLEFT", plugin.container, "TOPLEFT", -10, 10 );
			HB_Frame:SetPoint( "BOTTOMRIGHT", plugin.container, "BOTTOMRIGHT", 0, 0 );
			HB_Frame:SetFrameStrata( plugin.container:GetFrameStrata() );
			HB_Frame:SetFrameLevel( plugin.container:GetFrameLevel()+1 );
			HB_Frame:SetBackdropBorderColor( 0, 0, 0, 1 );
			HB_Frame:SetBackdropColor( 0, 0, 0, 0 );
			
			HealBot_Config.HideOptions = 1;
			HealBot_Options_DisableHealBot:SetChecked(0);
			HealBot_Options_ToggleHealBot(0);
			nUI_Movers:lockFrame( HB_Frame, true, nil );
			
		end				
	end			
end

-------------------------------------------------------------------------------

plugin.setSelected = function( selected )

	if selected ~= plugin.selected then

		plugin.selected = selected;
		
		if selected then
			
			
		else
			
			
		end
	end
end
