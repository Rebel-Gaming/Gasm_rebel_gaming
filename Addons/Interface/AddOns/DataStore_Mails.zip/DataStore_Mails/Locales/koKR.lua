﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Mails", "koKR" )

if not L then return end

L["Mail Expiry Warning"] = "우편 소멸 경고"
L["Scan mail body (marks it as read)"] = "우편물 내용을 검색 (읽은 것으로 표시됨)"
L["Warn when mail expires in less days than this value"] = "우편물의 소멸 날짜가 이 값보다 더 적으면 경고"

