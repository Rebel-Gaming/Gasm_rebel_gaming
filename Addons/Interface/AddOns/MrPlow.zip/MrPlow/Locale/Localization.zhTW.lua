local L = LibStub("AceLocale-3.0"):NewLocale("MrPlow", "zhTW")
if not L then return end

L["Armor"] = "盔甲"
L["Consumable"] = "消耗品"
L["Container"] = "容器"
L["Gem"] = "珠寶"
L["Key"] = "鑰匙"
L["Miscellaneous"] = "雜項"
L["Projectile"] = "射彈"
L["Quest"] = "任務"
L["Quiver"] = "箭袋"
L["Reagent"] = "試劑"
L["Recipe"] = "食譜"
L["Trade Goods"] = "交易商品"
L["Weapon"] = "武器"


