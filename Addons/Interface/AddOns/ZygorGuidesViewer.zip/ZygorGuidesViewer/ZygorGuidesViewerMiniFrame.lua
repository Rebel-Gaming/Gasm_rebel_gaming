--ZYGORGUIDESVIEWERFRAME_TITLE = "Zygor Guides Viewer";

local ZGV = ZygorGuidesViewer

function ZygorGuidesViewerMiniFrame_OnLoad()
--	this.selectedButtonID = 2;
--	this:RegisterEvent("QUEST_LOG_UPDATE");
--	this:RegisterEvent("QUEST_WATCH_UPDATE");
--	this:RegisterEvent("UPDATE_FACTION");
--	this:RegisterEvent("UNIT_QUEST_LOG_CHANGED");
--	this:RegisterEvent("PARTY_MEMBERS_CHANGED");
--	this:RegisterEvent("PARTY_MEMBER_ENABLE");
--	this:RegisterEvent("PARTY_MEMBER_DISABLE");
	if ZygorGuidesViewer then
		--
	end

	ZygorGuidesViewerMiniFrame:SetMinResize(320,100)
end

function ZygorGuidesViewerMiniFrame_OnHide()
	ZGV:MiniFrame_OnHide();
end

function ZygorGuidesViewerMiniFrame_OnShow()
	ZGV:MiniFrame_OnShow();
end

