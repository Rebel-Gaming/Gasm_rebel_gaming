assert(ZygorGuidesViewer,"Zygor Guides Viewer failed to load.")
ZygorGuidesViewer.revision = tonumber(string.sub("$Revision: 742 $", 12, -3))
ZygorGuidesViewer.version = "2.0." .. ZygorGuidesViewer.revision
ZygorGuidesViewer.date = string.sub("$Date: 2010-01-08 03:39:04 -0500 (Fri, 08 Jan 2010) $", 8, 17)
--2010/01/08 03:38:42
