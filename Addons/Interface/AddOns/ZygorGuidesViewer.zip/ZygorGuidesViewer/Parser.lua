local me = ZygorGuidesViewer
if not me then return end
local L = ZygorGuidesViewer_L("Main")

function toboolean(value)
	if value then return true else return false end
end
--[[
local function split (s,t)
	local l = {n=0}
	local f = function (s)
		l.n = l.n + 1
		l[l.n] = s
	end
	local p = "%s*(.-)%s*"..t.."%s*"
	s = string.gsub(s,"^%s+","")
	s = string.gsub(s,"%s+$","")
	s = string.gsub(s,p,f)
	l.n = l.n + 1
	l[l.n] = string.gsub(s,"(%s%s*)$","")
	return l
end
--]]

me.actionmeta = {
	goto = { skippable = true },
	fpath = { skippable = true },
	home = { skippable = true },
	hearth = { skippable = true },
}

local function split(str,sep)
	fields = {}
	str = str..sep
	str:gsub("(.-)"..sep, function(c) table.insert(fields, c) end)
	return fields
end

function me:ParseMapXYDist(text)
	local map,x,y,dist
	_,_,map,x,y,dist = string.find(text,"^(.+),([0-9%.]+),([0-9%.]+),([0-9%.]+)$")
	if not _ then _,_,x,y,dist = string.find(text,"^([0-9%.]+),([0-9%.]+),([0-9%.]+)$") end
	if not _ then _,_,map,x,y = string.find(text,"^(.+),([0-9%.]+),([0-9%.]+)$") end
	if not _ then _,_,x,y = string.find(text,"^([0-9%.]+),([0-9%.]+)$") end
	if not _ then _,_,dist = string.find(text,"^([0-9%.]+)$") end
	if not _ then map = text end
	
	x = tonumber(x)
	y = tonumber(y)
--	if x then x=x/100 end
--	if y then y=y/100 end
--	if dist then dist=dist/100 or 0.2 end
	if not dist then dist=0.2 end
	if map and #map<5 then map=nil end

	return { map=map,x=x,y=y,dist=dist }
end

function me:ParseID(str)
	local name,id,nid,obj
	name,id = str:match("(.*)##([0-9/]*)")
	if not name then id = str:match("^([0-9/]*)$") end
	if id then
		nid,obj = id:match("([0-9]*)/([0-9]*)")
		if nid then
			id=nid
		end
	end
	if id then id = tonumber(id) end
	if obj then obj = tonumber(obj) end
	if not name and not id then name=str end
	return name, id, obj
end

--- parse just the header, until the first 'step' tag. No chunking, just header data extraction.
function me:ParseHeader(text)
	if not text then return {} end
	local guides = {}
	local index = 1
	local st,en

	text = text .. "\n"

	local linecount=0

	local header = {}

	while (index<#text) do
		st,en,line=string.find(text,"(.-)\n",index)
		if not en then break end
		index = en + 1

		linecount=linecount+1
		if linecount>100000 then
			return nil,linecount,"More than 100000 lines!?"
		end

		line = line:gsub("^[%s	]+","")
		line = line:gsub("[%s	]+$","")
		line = line:gsub("//.*$","")
		line = line:gsub("||","|")

		cmd,params = line:match("([^%s]*)%s?(.*)")

		if cmd then
			if cmd=="step" then
				break
			else
				header[cmd]=params
			end
		end
	end

	if header['guide'] then
		header['title']=header['guide']
		header['guide']=nil
	end

	return header
end

--- parse ONE guide section into usable arrays.
function me:ParseEntry(text)
	if not text then return nil,"No text!",0 end
	local guides = {}
	local index = 1
	local st,en

	local guide,step

	local prevmap
	local prevlevel = 1

	guide = { ["steps"] = {}, ["quests"] = {} }

	text = text .. "\n"

	local linecount=0

	local noobsoletequests = {}

	local function COLOR_LOC(s) return "|cffffee77"..s.."|r" end

	while (index<#text) do
		st,en,line=string.find(text,"(.-)\n",index)
		if not en then break end
		index = en + 1

		linecount=linecount+1
		if linecount>100000 then
			return nil,linecount,"More than 100000 lines!?"
		end

		line = line:gsub("^[%s	]+","")
		line = line:gsub("[%s	]+$","")
		line = line:gsub("//.*$","")
		line = line:gsub("||","|")

		indent,line = line:match("^(%.*)(.*)")

		line = line .. "|"
		local goal={}

		local chunkcount=1

		for chunk in line:gmatch("(.-)|") do
			chunk = chunk:gsub("^'%s*","' ")
			chunk = chunk:gsub("^turn in ","turnin ")
			chunk = chunk:gsub("^@(%S)","@ %1")
			chunk = chunk:gsub("^[%s	]+","")
			chunk = chunk:gsub("[%s	]+$","")

			cmd,params = chunk:match("([^%s]*)%s?(.*)")

			-- guide parameters
			if cmd=="defaultfor" then
				guide[cmd]=params
			elseif cmd=="next" then
				guide[cmd]=params
			elseif cmd=="guide" then
				guide['title']=params
			elseif cmd=="author" then
				guide[cmd]=params
			elseif cmd=="faction" then
				guide[cmd]=params
			elseif cmd=="startlevel" then
				prevlevel=tonumber(params)

			elseif cmd=="step" then
				step = { goals = {}, map = prevmap, level = prevlevel, num = #guide.steps+1, parentGuide=guide }
				guide.steps[#guide.steps+1] = step

				setmetatable(step,ZGV.StepProto_mt)

			-- step parameters
			elseif cmd=="level" then
				step[cmd]=params
				prevlevel=tonumber(params)
			elseif cmd=="title" then
				step[cmd]=params
				if chunkcount>1 then goal[cmd]=params end
			elseif cmd=="info" then
				local moved
				for i=1,10 do
					if step.goals[i] and step.goals[i].action=="talk" then
						step.goals[i].tooltip=step.goals[i].tooltip or params
						moved=true
						break
					end
				end
				if not moved then
					step[cmd]=params
				end
			elseif cmd=="info2" then
				step[cmd]=params
			elseif cmd=="map" then
				step.map= params
				if self.BZL[step.map] then step.map=self.BZL[step.map] end
				prevmap = step.map
--[[
			elseif cmd=="@" then
				local map,x,y
				map,x,y = params:match("(.+),([0-9.]+),([0-9.]+)")
				if not map then
					x,y = params:match("([0-9.]+),([0-9.]+)")
				end
				if not x then
					map = params
				end
				if not map then
					map = prevmap
				end
				step['map']=map
				prevmap=map
				if x or y then
					step['x']=x
					step['y']=y
				end
--]]
			elseif cmd=="only" then
				if goal.action or goal.text or chunkcount>1 then
					if not ZGV:RaceClassMatch(split(params,",")) then
						goal={}
						break
					end -- skip goal line altogether
				else
					step.requirement=split(params,",")
				end

			-- goal commands
			elseif cmd=="accept" or cmd=="turnin" then
				goal.action = goal.action or cmd
				if not params then return nil,"no quest parameter",linecount,chunk end
				goal.quest,goal.questid = self:ParseID(params)
				local q,qp = goal.quest:match("^(.-)%s-%((%d+)%)$")
				if q then goal.quest,goal.questpart=q,qp end
				if not goal.quest and not goal.questid then return nil,"no quest parameter",linecount,chunk end

				if goal.questid then
					guide.quests[goal.questid]=step.level
					if not step.level then return nil,"Missing step level information",linecount,chunk end
					if ZygorGuidesViewer.Chains then
						goal.questreqs = ZygorGuidesViewer.Chains[goal.questid]
						if type(goal.questreqs)=="table" then
							local oper = goal.questreqs[1]
							if oper=="OR" then
								table.remove(goal.questreqs,1)
							elseif oper=="AND" then
								table.remove(goal.questreqs,1)
								goal.questreqsAND=true
							end
						else
							goal.questreqs={goal.questreqs}
						end
					end
				end

			elseif cmd=="talk" then
				goal.action = goal.action or cmd
				if not params then return nil,"no npc",linecount,chunk end
				goal.npc,goal.npcid = self:ParseID(params)
				if not goal.npc then return nil,"no npc",linecount,chunk end
			elseif cmd=="goto" or cmd=="at" then
				goal.action = goal.action or cmd
				local data = self:ParseMapXYDist(params)

				if self.BZL[data.map] then data.map=self.BZL[data.map] end

				goal.map = data.map or goal.map or step.map or prevmap
				step.map = goal.map
				prevmap = step.map

				goal.x = data.x or goal.x
				goal.y = data.y or goal.y
				goal.dist = goal.dist or data.dist

				if (goal.action=="accept" or goal.action=="turnin" 	or goal.action=="kill" 	or goal.action=="get" 	or goal.action=="talk" 	or goal.action=="goal" 	or goal.action=="use") then
					goal.autotitle = goal.param or goal.target or goal.quest
				end

				if not goal.map then
					return nil,"'"..cmd.."' has no map parameter, neither has one been given before.",linecount,chunk
				end

			elseif cmd=="kill" or cmd=="get" or cmd=="collect" or cmd=="goal" or cmd=="buy" then
				goal.action = goal.action or cmd
				local count,excl,object = params:match("^([0-9]+)(!?) (.*)")
				goal.count = tonumber(count) or 1
				local object,objectid = self:ParseID(object or params)
				goal.target = object or params
				goal.targetid = objectid
				if excl=="!" then
					goal.exact = 1
				end
				if not goal.target then return nil,"no parameter",linecount,chunk end
				--[[
				if goal.target:match("%+%+") then
					if goal.target:match("%+%+$") then
						goal.target = goal.target:gsub("%+%+","")
						goal.targets = goal.target
					else
						local sing,pl = goal.target:match("(.+)%+%+%+(.+)")
						if not sing or not pl then
							sing = goal.target:gsub("([^%s%+]+)++([^%s%+]+)","%1")
							pl = goal.target:gsub("([^%s%+]+)++([^%s%+]+)","%2")
						end
						goal.target = sing
						goal.targets = pl
					end
				end
				--]]
			elseif cmd=="from" then
				goal.action = goal.action or cmd
				params=params:gsub(",%s+",",")
				goal.mobsraw = params
				local mobs = split(params,",")
				goal.mobspre = mobs
				goal.mobs = {}
				for i,mob in ipairs(mobs) do
					local name,plural = mob:match("^(.+)(%+)$")
					if not plural then name=mob end

					local nm,id = self:ParseID(name)
					
					table.insert(goal.mobs,{name=nm,id=id,pl=plural and true or false})
				end
			elseif cmd=="complete" then
				goal.action = goal.action or cmd
				goal.quest,goal.questid,goal.objnum = self:ParseID(params)
				if not goal.quest and not goal.questid then return nil,"no quest parameter",linecount,chunk end
			elseif cmd=="ding" then
				goal.action = goal.action or cmd
				goal.level = tonumber(params)
				if not goal.level then return nil,"'ding': invalid level value",linecount,chunk end
				prevlevel = tonumber(params)
			elseif cmd=="cast" then
				goal.action = goal.action or cmd
				goal.castspell,goal.castspellid = self:ParseID(params)
				if not goal.castspell and not goal.castspellid then return nil,"no parameter",linecount,chunk end
			elseif cmd=="petaction" then
				goal.action = goal.action or cmd
				goal.petaction = tonumber(params)
				if not goal.petaction then goal.petaction = params end
				if not goal.petaction then return nil,"petaction needs an action number",linecount,chunk end
			elseif cmd=="use" then
				goal.action = goal.action or cmd
				goal.useitem,goal.useitemid = self:ParseID(params)
				if not goal.useitem and not goal.useitemid then return nil,"no parameter",linecount,chunk end
			elseif cmd=="fpath" or cmd=="home" then
				goal.action = goal.action or cmd
				goal.param = params
				if not goal.param then return nil,"no parameter",linecount,chunk end
			elseif cmd=="havebuff" then
				goal.action = goal.action or cmd
				goal.buff = params
				if not goal.buff then return nil,"no parameter",linecount,chunk end
			elseif cmd=="nobuff" then
				goal.action = goal.action or cmd
				goal.buff = params
				if not goal.buff then return nil,"no parameter",linecount,chunk end
			elseif cmd=="invehicle" then
				goal.action = goal.action or cmd
			elseif cmd=="outvehicle" then
				goal.action = goal.action or cmd
			elseif cmd=="script" then
				goal.script = params
			elseif cmd=="autoscript" then
				goal.autoscript = params
			elseif cmd=="equipped" then
				goal.action = goal.action or cmd
				local slot,item = params:match("^([a-zA-Z]+) (.*)")
				slot,_ = GetInventorySlotInfo(slot)
				if not slot then return nil,"equipped needs proper slot" end
				if not item then return nil,"equipped needs item" end
				goal.slot=slot
				goal.item=item

			elseif cmd=="hearth" then
				goal.action = cmd
				goal.useitem = "Hearthstone"
				goal.useitemid = 6948
				goal.param = params
				goal.force_noway = true
			
			elseif cmd=="n" then
				goal.force_nocomplete = true
			elseif cmd=="c" then
				goal.force_complete = true
			elseif cmd=="noway" then
				goal.force_noway = true
			elseif cmd=="sticky" then
				goal.force_sticky = true
			elseif cmd=="noobsolete" then
				goal.noobsolete = true
				noobsoletequests[goal.questid] = true

			elseif cmd=="tip" then
				goal.tooltip = params
			elseif cmd=="image" then
				goal.image = params
			elseif cmd=="quest" or cmd=="q" then
				goal.quest,goal.questid,goal.objnum = self:ParseID(params)
				if not goal.quest and not goal.questid then return nil,"no quest parameter",linecount,chunk end
			elseif cmd=="follows" then
				--[[
				goal.questreq,goal.questreqid = self:ParseID(params)
				if goal.questreq=="^" then
					goal.questreq,goal.questreqid = step.goals[#step.goals].quest,step.goals[#step.goals].questid
				end
				if not goal.questreq and not goal.questreqid then 
					self:Debug("Warning: |follows found no quest data at "..linecount.." of '"..chunk.."'")
					self:Debug("Next "..(guide.next or "?"))
					goal.questreq=nil
					goal.questreqid=nil
				end
				--]]
			elseif cmd=="dontuseid" then
				goal.dontuseid=true
			elseif #chunk>1 then -- text
				-- snag coordinates for waypointing, with distance
				local st,en,x,y,d
				st,en = 1,1

				st,en,x,y,d = params:find("([0-9%.]+),([0-9%.]+)(,([0-9%.]+))?",en)
				if not x then
					-- without distance, perhaps?
					d=0.2
					st,en,x,y = params:find("([0-9%.]+),([0-9%.]+)",en)
				end

				if x and y then
					goal.x = tonumber(x)
					goal.y = tonumber(y)
					goal.dist = tonumber(d)
					params = params:sub(1,st-1) .. COLOR_LOC(L['coords']:format(x,y)) .. params:sub(en+1)
				end

				if goal.x then goal.map = prevmap end

				goal.text=(cmd=="'") and params or chunk
			end

			chunkcount=chunkcount+1
			if chunkcount>20 then
				return nil,"More than 20 chunks in line",linecount,line
			end
		end

		if #TableKeys(goal)>0 then
			if not step then return nil,"What? Unknown data before first 'step' tag, or what?",linecount,line end

			-- so there's something to record? go ahead.

			setmetatable(goal,ZGV.GoalProto_mt)

			if not goal.action and (goal.x or goal.map) then
				goal.action = "goto"
			end

			if goal.questid and noobsoletequests[goal.questid] then
				goal.noobsolete = true
			end


			goal.parentStep = step
			goal.num = #step.goals+1

			step.goals[#step.goals+1] = goal
		end

		if goal then goal.indent = #indent end

	end
	return guide
end
