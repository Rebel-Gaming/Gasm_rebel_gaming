ZygorGuidesViewer_L("Main", "koKR", function() return {
	-- ["English"] = "Localized",
} end)
