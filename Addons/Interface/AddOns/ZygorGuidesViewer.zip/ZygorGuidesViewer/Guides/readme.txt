Place your guides in files Guide01.txt, Guide02.txt, ... in this directory, to have them auto-loaded and startup.
