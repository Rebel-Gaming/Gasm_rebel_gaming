Introduction
Welcome to ShockAndAwe and Enhancement Shammy max dps addon.  This addon was written to enhance Enhancement shamans dps and build on the work done with DisqoDice. Its aim is to provide a fully configurable addon you can adjust to suit your own particular UI layout. Use /saa config to access the configuration menu 


Timer Bars
There are bars for Maelstrom Weapon, Shocks, Shields, Stormstrike, Windfury, Lava Lash and Global cooldown. You can change their colours,  textures, scale the frame and change its width in the config options. As well as turning them on or off. You can also configure the Maelstrom sounds to play on 4 and 5 stacks, as well as configuring the maelstrom bar to flash  when 5 stacks are achieved. If you wish you can also configure the bars to  hide when out of combat, and you can display icons next to each bar to help you remember which is which. 


Priority Frame
The priority frame comes with default configuration options. You can change these to whatever priority of skills you want to use. The default is set to use Lightning bolt on 5 maelstrom, StormStrike, Earth Shock, Lava Lash. You can also turn on and off the ability to show Shamanistic rage on low mana, and availability of your feral spirits. You can also choose to display the maelstrom weapon stacks as 'combo points' on the priority frame. 


Uptime Frame
The optional uptime frame will show you the percentage uptime each of your main buffs was present for. This shows your data since last login/reload and the data from the last fight. There is a reset session button to clear data so far this session. 


Export to Sim
You can use the /saa export command to export your paper doll stats to the EnhSim enhancement shammy simulator which is available for download at http://code.google.com/p/enhsim/downloads/list To use this open the config.txt file from EnhSim in Wordpad or similar editor (Notepad doesn't work) and find the section at the end of the config file which tells you to replace that data with the data pasted from ShockAndAwe. Once you delete the old data switch to WoW and simply  type /saa export and press ctrl-c when the frame opens,then go back to  your text editor and paste the data into the file at the end. Save this new config file eg: I use Levva.txt and the run the sim.

Use EnhSimGUI.exe if you want to change other things like buffs etc. as the visual display of the settings is easier to use if you are not sure what to do. The Simulate button will give your expected DPS and the  Calculate EP values button will calculate what stats eg:AP/Crit to look for when you are looking for new gear. The higher the EP number the sim calculates the more you need that stat. 


Keybindings
You can also use ShockAndAwe to keybind your Water Shield and  Lightning Shields, as well as keybinding your main and off hand weapon buffs. 


General
Windfury & Stormstrike cumulative totals can be shown in Scrolling  Combat text addon or in a default warning frame.   All of the frames in ShockAndAwe can be moved using /saa moveframes  There are dozens and dozens of configurable options in ShockAndAwe use  /saa config to view them all  ShockAndAwe can warn you if you enter combat without your weapon buffs,  it can also be configured to warn you when your shield and weapon buffs   expire. You can view this news at any time by typing /saa news 


Bugs
Please also report any bugs you find to the website below. However before you post a bug report PLEASE do a /saa version and quote the full version number when you post a bug. A report without a version number is practically useless. 