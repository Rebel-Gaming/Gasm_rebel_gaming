﻿--Slash Commands
SLASH_Diablo1 = "/Diablo";
local PShown = "Percentages Enabled.";
local PHidden = "Percentages Disabled.";
--Percenthidden is saved in the SavedVariables file.

--Function for slash commands.
SlashCmdList["Diablo"] = function(msg, editBox)
	if msg == "Percent" or msg == "percent" then
			if Percenthidden then
			DEFAULT_CHAT_FRAME:AddMessage(PShown);
			DiabloMod_HealthText_Percent:Show();
			DiabloMod_ManaText_Percent:Show();
			Percenthidden = false;
		else
			DEFAULT_CHAT_FRAME:AddMessage(PHidden);
			DiabloMod_HealthText_Percent:Hide();
			DiabloMod_ManaText_Percent:Hide();
			Percenthidden = true;
		end
	else
		DEFAULT_CHAT_FRAME:AddMessage("'/Diablo percent' Toggles showing Percentages.");
	end
end

--Load function to register events
function DiabloMod_OnLoad()
	this:RegisterEvent("ADDON_LOADED");
	this:RegisterEvent("UNIT_HEALTH");
	this:RegisterEvent("UNIT_MAXHEALTH");
	this:RegisterEvent("UNIT_RAGE");
	this:RegisterEvent("UNIT_ENERGY");
	this:RegisterEvent("UNIT_MANA");
	this:RegisterEvent("UNIT_RUNIC_POWER");
	this:RegisterEvent("UNIT_DISPLAYPOWER");
	this:RegisterEvent("PLAYER_ENTERING_WORLD");
	this:RegisterEvent("RUNE_REGEN_UPDATE");
	this:RegisterEvent("PLAYER_REGEN_DISABLED");
	this:RegisterEvent("PLAYER_REGEN_ENABLED");
	this:RegisterEvent("RUNE_POWER_UPDATE");
	this:RegisterEvent("COMBAT_LOG_EVENT");
	MainMenuBarArtFrame:RegisterEvent('KNOWN_CURRENCY_TYPES_UPDATE')
	MainMenuBarArtFrame:RegisterEvent('CURRENCY_DISPLAY_UPDATE') 
	DEFAULT_CHAT_FRAME:AddMessage("Diablo Mod Loaded: type /Diablo for options.");
end  

--Borrowed from a lua guide page so I can use rounding for percentages.
function round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

--Adjusts the location of the orbs.
function DiabloMod_AdjustOrbs()
	---------------------Health Bubble---------------------------------------------------------
	local healthPercent = (UnitHealth("player")/UnitHealthMax("player"));
	DiabloMod_HealthText:SetText(UnitHealth("player").." / ".. UnitHealthMax("player"));
	DiabloMod_HealthText_Percent:SetText(round(healthPercent * 100) .. "%");
	DiabloMod_RedOrb:SetHeight(healthPercent*86);
	DiabloMod_RedOrb:SetTexCoord(0, 1, 1-healthPercent, 1);
	--Hide the mana bubble if it is zero, otherwise I get some crazy line.
	if (healthPercent == 0) then
	DiabloMod_RedOrb:Hide();
	else
	DiabloMod_RedOrb:Show();
	end
	---------------------Power Bubble---------------------------------------------------------
	local manaPercent = (UnitMana("player")/UnitManaMax("player"));
	DiabloMod_ManaText:SetText(UnitMana("player").." / ".. UnitManaMax("player"));
	DiabloMod_ManaText_Percent:SetText(round(manaPercent * 100) .. "%");
	DiabloMod_BlueOrb:SetTexCoord(0, 1, 1-manaPercent, 1); 
	DiabloMod_BlueOrb:SetHeight(manaPercent*86);
	--Hide the mana bubble if it is zero, otherwise I get some crazy line.
	if (manaPercent == 0) then
	DiabloMod_BlueOrb:Hide();
	else
	DiabloMod_BlueOrb:Show();
	end
end        

--Handle the saved variable and adjusting / initializing the orbs.
function DiabloMod_OnEvent(event)
	if (event=="ADDON_LOADED") then
		if (Percenthidden == nil) then
			Percenthidden = false; -- This is the first time this addon is loaded; initialize the count to 0.
		end
	end
	
	if (event=="PLAYER_ENTERING_WORLD") then 
		DiabloMod_InitialiseOrbs();
		DiabloMod_AdjustOrbs();
		return;
	end 
	
	if (event=="UNIT_DISPLAYPOWER") then 
		DiabloMod_InitialiseOrbs();
		DiabloMod_AdjustOrbs();
		return;
	end
	
	if (event=="UNIT_HEALTH") then 
		DiabloMod_AdjustOrbs()
	return;
	end

if (event=="UNIT_MANA" or event=="UNIT_RAGE" or event=="UNIT_ENERGY" or event=="UNIT_RUNIC_POWER" or event == "RUNE_POWER_UPDATE" or event == "RUNE_REGEN_UPDATE" or event == "PLAYER_REGEN_ENABLED" or event == "RUNE_POWER_UPDATE") then     
	DiabloMod_AdjustOrbs()
	return;
	end
end
--Load the textures and tint them.
function DiabloMod_InitialiseOrbs()
	--Load Textures.
	DiabloMod_RedOrb:SetTexture("Interface\\addons\\DiabloMod\\art\\orb_health.tga");
	--Setup the Texture for the blue orb.
	local powerType = UnitPowerType("player");
	if (powerType == 0) then -- Mana
		DiabloMod_BlueOrb:SetTexture("Interface\\addons\\DiabloMod\\art\\orb_mana.tga");
	end
	if (powerType == 1) then -- Rage
		DiabloMod_BlueOrb:SetTexture("Interface\\addons\\DiabloMod\\art\\orb_health.tga");
	end
	if (powerType == 3) then -- Energy
		DiabloMod_BlueOrb:SetTexture("Interface\\addons\\DiabloMod\\art\\orb_energy.tga");
	end
	if (powerType == 6) then -- Runic_Power
		DiabloMod_BlueOrb:SetTexture("Interface\\addons\\DiabloMod\\art\\orb_mana.tga");
	end
	--This adds a dark tone to the orbs.
	DiabloMod_RedOrb:SetVertexColor(0.4,0.4,0.4);
	DiabloMod_BlueOrb:SetVertexColor(0.4,0.4,0.4);
	if Percenthidden  then		
		DiabloMod_HealthText_Percent:Hide();
		DiabloMod_ManaText_Percent:Hide();
	end
end