FB_ODFTranslations["esES"] = {
   DESCRIPTION = "Maneja tu ca\195\177a de pescar.",

   -- Tab labels and tooltips
   OUTFITS_INFO = "Desviste los que llevas cuando pescas",
   OUTFITS_TAB = "Equipos",

   SWITCHOUTFIT = "Cambia",
   SWITCHOUTFIT_INFO = "Cambia entre el equipo de pesca y lo que llevabas puesto.",

   -- Option names and tooltips
   CONFIG_SKILL_INFO		= "Bonus de equipo total.",
   CONFIG_SKILL_TEXT		= "Pescando ",
   CONFIG_STYLISH_TEXT		= "Estilo: ",

   -- messages
   CURSORBUSYMSG = "no pudo cambiar por estar el cursor ocupado!",
   NOOUTFITDEFINED = "No tienes objetos en tu equipo de pesca.",
   POLEALREADYEQUIPPED = "Ya estas equipado para pescar.",
   CANTSWITCHBACK = "Ya te has quitado el equipamiento de pesca.",
};


