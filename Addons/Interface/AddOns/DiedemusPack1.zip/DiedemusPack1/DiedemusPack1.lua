SunnArt.options.args.theme.values["DiedemusPack1\\d3_"]="Diablo 3"
SunnArt.overlap["DiedemusPack1\\d3_"]=55.00
SunnArt.options.args.theme.values["DiedemusPack1\\lk_"]="LichKing"
SunnArt.overlap["DiedemusPack1\\lk_"]=95.00
SunnArt.options.args.theme.values["DiedemusPack1\\lk2_"]="LichKing 2"
SunnArt.overlap["DiedemusPack1\\lk2_"]=85.00
DEFAULT_CHAT_FRAME:AddMessage("|cFF0000FFDiedemusPack1|r: Loaded")