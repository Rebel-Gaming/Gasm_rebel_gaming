﻿--[[
    Language Localization: esES
    Translated by: name <email address>
]]

WIM.AddLocale("esES", {

    -- Talent Spec --
    ["Affliction"] = "Aflicción",
    ["Arcane"] = "Arcano",
    ["Arms"] = "Armas",
    ["Assassination"] = "Asesinato",
    ["Balance"] = "Equilibrio",
    ["Beast Mastery"] = "Dominio de bestias",
    ["Blood"] = "Sangre",
    ["Combat"] = "Combate",
    ["Demonology"] = "Demonología",
    ["Destruction"] = "Destrucción",
    ["Discipline"] = "Disciplina",
    ["Elemental"] = "Elemental",
    ["Enhancement"] = "Mejora",
    ["Feral Combat"] = "Combate Feral",
    ["Fire"] = "Fuego",
    ["Frost"] = "Escarcha",
    ["Fury"] = "Furia",
    ["Holy"] = "Sagrado",
    ["Hybrid"] = "Híbrido",
    ["Marksmanship"] = "Puntería",
    ["Protection"] = "Protección",
    ["Restoration"] = "Restauración",
    ["Retribution"] = "Reprensión",
    ["Shadow"] = "Sombras",
    ["Subtlety"] = "Sutileza",
    ["Survival"] = "Supervivencia",
    ["Unholy"] = "Profano",

});