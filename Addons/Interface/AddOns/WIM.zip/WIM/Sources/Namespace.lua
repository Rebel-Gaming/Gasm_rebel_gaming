-- This file is just a namespace declaration for WIM.
-- try not to blind yourself with all the code.

WIM = {};