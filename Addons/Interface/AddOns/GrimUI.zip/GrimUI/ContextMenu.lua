local addonName, addon = ...

addon:RegisterDefaultSetting("showContextMenu", false)

--[[-----------------------------------------------------------------------------
This is used to set the default button ids . These buttons do not conflict with
known stance/form/stealth bars.  These settings are not ideal, but are the best
compromise I could come up with short of writing virtual action buttons.

Default Blizzard IDs:
1-12		Main Bar (Unused by Warriors)
13-24		Second Bar
25-36		Side Bar 1
37-48		Side Bar 2
49-60		Bottom Right Bar
61-72		Bottom Left Bar
73-84		Warrior Battle, Druid Cat, Rogue Stealth, Priest Shadowform
85-96		Warrior Defensive, Druid Tree
97-108	Warrior Berserker, Druid Bear
109-120	Druid Moonkin
121-132	Possess Bar (Unusable)
-------------------------------------------------------------------------------]]
local actionID, class = UnitClass('player')

if class == 'DRUID' then
	actionID = {
		48, --01
		49, --02
		50, --03
		51, --04
		52, --05
		53, --06
		54, --07
		55, --08
		56, --09
		57, --10
		58, --11
		59, --12
		60, --13
		61, --14
		62, --15
		63, --16
		64, --17
		65, --18
		66, --19
		67, --20
		68, --21
		69, --22
		70, --23
		71, --24
		72  --25
	}
elseif class == 'WARRIOR' then
	actionID = {
		1, --01
		2, --02
		3, --03
		4, --04
		5, --05
		6, --06
		7, --07
		8, --08
		9, --09
		10, --10
		11, --11
		12, --12
		72, --13, Pesky warriors.
		109, --14
		110, --15
		111, --16
		112, --17
		113, --18
		114, --19
		115, --20
		116, --21
		117, --22
		118, --23
		119, --24
		120  --25
	}
else
	actionID = {
		96, --01
		97, --02
		98, --03
		99, --04
		100, --05
		101, --06
		102, --07
		103, --08
		104, --09
		105, --10
		106, --11
		107, --12
		108, --13
		109, --14
		110, --15
		111, --16
		112, --17
		113, --18
		114, --19
		115, --20
		116, --21
		117, --22
		118, --23
		119, --24
		120  --25
	}
end

local contextMenu = CreateFrame('Frame', nil, UIParent, 'SecureFrameTemplate')
contextMenu:SetPoint('RIGHT', UIParent, 'RIGHT', -280, -120)

local buttons = { }
for index = 1, #actionID do
	local button = CreateFrame('CheckButton', addonName .. "ContextMenuButton" .. index, contextMenu, 'ActionBarButtonTemplate')
	buttons[index] = button
	if (index - 1) % 5 ~= 0 then
		button:SetPoint('LEFT', buttons[index - 1], 'RIGHT', 2, 0)
	elseif index ~= 1 then
		button:SetPoint('TOPLEFT', buttons[index - 5], 'BOTTOMLEFT', 0, -2)
	else
		button:SetPoint('TOPLEFT')
	end
	button:SetAttribute('type', 'action')
	button:SetAttribute('action', actionID[index])
end

contextMenu:SetHeight(buttons[1]:GetHeight() * 5 + 8)
contextMenu:SetWidth(buttons[1]:GetWidth() * 5 + 8)
contextMenu:SetScale(0.8)

local texture = contextMenu:CreateTexture(nil, 'ARTWORK')
texture:SetTexture([[Interface\DialogFrame\UI-DialogBox-Background]])
texture:SetVertexColor(1, 1, 1, 0.5)
texture:SetPoint('CENTER')
texture:SetWidth(36)
texture:SetHeight(36)

local title = contextMenu:CreateFontString(nil, 'OVERLAY')
title:SetFont([[Fonts\FRIZQT__.TTF]], 12, 'OVERLAY')
title:SetTextColor(1, 1, 0, 0.8)
title:SetPoint('TOP', texture, 'TOP', 0, -1)
title:SetText('GCM')

--[[-----------------------------------------------------------------------------
Context "hot spot" button
-------------------------------------------------------------------------------]]
local hotSpot = CreateFrame('Button', nil, UIParent, 'SecureHandlerClickTemplate')
hotSpot:SetPoint('BOTTOMRIGHT', -370, 220)
hotSpot:SetHeight(15)
hotSpot:SetWidth(15)

hotSpot:SetFrameRef("contextMenu", contextMenu)
hotSpot:RegisterForClicks('LeftButtonUp', 'RightButtonUp')
hotSpot:SetAttribute('_onclick', [[
	local frame = self:GetFrameRef("contextMenu")
	if button == 'LeftButton' then
		if frame:IsVisible() then
			frame:Hide(true)
		else
			frame:Show(true)
		end
	elseif button == 'RightButton' then
		control:CallMethod("ToggleCombatLog")
	end
]])

 hotSpot:SetScript('OnEnter', function(self)
	GameTooltip:SetOwner(self, 'ANCHOR_TOP', 0, 1)
	GameTooltip:AddLine("|cffeda55fLeft Click|r for ContextMenu", 0.2, 1, 0.2)
	GameTooltip:AddLine("|cffeda55fRight Click|r toggle CombatLog", 0.2, 1, 0.2)
	GameTooltip:Show()
end)

hotSpot:SetScript('OnLeave', addon.HideTooltip)

function hotSpot:ToggleCombatLog()
	addon.settings.showCombatLog = not addon.settings.showCombatLog
	addon:ConfigureCombatLog()
end

--[[-----------------------------------------------------------------------------
Initialize
-------------------------------------------------------------------------------]]
addon.RegisterEvent("ContextMenu-Initialize", 'PLAYER_ENTERING_WORLD', function(self, event)
	addon.UnregisterEvent(self, event)

	if not addon.settings.showContextMenu then
		contextMenu:Hide()
	end
end)

--[[-----------------------------------------------------------------------------
Save setting on logout
-------------------------------------------------------------------------------]]
addon.RegisterEvent("ContextMenu-SaveState", 'PLAYER_LOGOUT', function()
	addon.settings.showContextMenu = contextMenu:IsShown() or false
end)
