local addonName, addon = ...

addon:RegisterDefaultSetting("xpBarvar", "xpTot")




local GrimExpRepBar = CreateFrame("Frame", nil, UIParent)
GrimExpRepBar:RegisterEvent("PLAYER_ENTERING_WORLD")
GrimExpRepBar:RegisterEvent("PLAYER_XP_UPDATE")
GrimExpRepBar:RegisterEvent("PLAYER_LEVEL_UP", "level")
GrimExpRepBar:RegisterEvent("UPDATE_EXHAUSTION")
GrimExpRepBar:RegisterEvent("UNIT_PET", "player")
GrimExpRepBar:RegisterEvent("UNIT_PET_EXPERIENCE", "player")


--[[-----------------------------------------------------------------------------
Initialize
-------------------------------------------------------------------------------]]
addon.RegisterEvent("InitializeExpRepBar", 'PLAYER_ENTERING_WORLD', function(self, event)
	addon.UnregisterEvent(self, event)

	GrimExpRepBar:GetScript('OnEvent')(GrimExpRepBar)
end)


local border = CreateFrame('Button', "xpBarClick", GrimExpRepBar)
border:SetHeight(20)
border:SetWidth(235)
border:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 50, 250)
border:SetFrameStrata("HIGH")
border:SetFrameLevel("4")

local xpBar = CreateFrame("StatusBar", nil, GrimExpRepBar, "TextStatusBar")
xpBar:SetWidth(235)
xpBar:SetHeight(20)
xpBar:SetPoint("CENTER", border, "CENTER", 0, 0)
xpBar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\BarTexture]])
xpBar:SetStatusBarColor(0.5, 0.1, 0.9, 1)
xpBar:SetFrameLevel("3")



local xpText = xpBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
xpText:SetPoint("LEFT", border, "LEFT", 3, -2)
xpText:SetTextColor(1, 1, 1, 1)
xpText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font-1.ttf]], 11.5, "OUTLINE")


local restXPbar = CreateFrame("StatusBar", nil, GrimExpRepBar, "TextStatusBar")
restXPbar:SetWidth(235)
restXPbar:SetHeight(20)
restXPbar:SetPoint("CENTER", border, "CENTER", 0, 0)
restXPbar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\BarTexture]])
restXPbar:SetStatusBarColor(.290, .305, .878, 1)
restXPbar:SetFrameLevel("2")



local bg = xpBar:CreateTexture(nil, "BACKGROUND")
bg:SetTexture(0, 0, 0, 0)
bg:SetWidth(235)
bg:SetHeight(20)
bg:SetPoint("CENTER", border, "CENTER", 0, 0)

GrimExpRepBar:SetScript("OnEvent", function(self) 
	local currXP, nextXP = UnitXP("Player"), UnitXPMax("Player") 
	local leftXP = (nextXP - currXP)
	local _, myClass = UnitClass("Player")
	local petXPcur, petXPnex = GetPetExperience()
	local petXPleft = (petXPnex - petXPcur)
	local restXP, percentXP = GetXPExhaustion(), floor(currXP / nextXP * 100) 
	
	local str 
	
	
	if restXP == nil then -- nill is being delt with
		if addon.settings.xpBarvar == "xpLeft" and myClass == "HUNTER" then 
		str = ("%s left  %s Pet"):format(leftXP,  petXPleft) 
		elseif addon.settings.xpBarvar == "xpLeft" and myClass ~= "HUNTER" then
		str = ("%s left "):format(leftXP)
		elseif addon.settings.xpBarvar == "xpTot" and myClass == "HUNTER" then
		str = ("%s/%s  P %s/%s"):format(currXP, nextXP, petXPcur, petXPnex)
		elseif addon.settings.xpBarvar == "xpTot" and myClass ~= "HUNTER" then
		str = ("%s/%s "):format(currXP, nextXP)
		end
		restXPbar:SetMinMaxValues(min(0, currXP), nextXP) -- dont forget restXP must be a value or nil must be delt with
		restXPbar:SetValue(currXP) -- dont forget restXP must be a value or nil must be delt with
	else 
		local percentRestXP = floor(restXP / nextXP * 100)
		if addon.settings.xpBarvar == "xpLeft" and myClass == "HUNTER" then 
		str = ("%s left (%s %s%%R) P %s"):format(leftXP, restXP, percentRestXP, petXPleft) 
		elseif addon.settings.xpBarvar == "xpLeft" and myClass ~= "HUNTER" then
		str = ("%s left (%s %s%%R)"):format(leftXP, restXP, percentRestXP)
		elseif addon.settings.xpBarvar == "xpTot" and myClass == "HUNTER" then
		str = ("%s/%s (%s%%R) P %s/%s"):format(currXP, nextXP, percentRestXP, petXPcur, petXPnex)
		elseif addon.settings.xpBarvar == "xpTot" and myClass ~= "HUNTER" then
		str = ("%s/%s (%s%%R)"):format(currXP, nextXP, percentRestXP)
		end
		restXPbar:SetMinMaxValues(min(0, restXP), nextXP) -- dont forget restXP must be a value or nil must be delt with
		restXPbar:SetValue(currXP + restXP) -- dont forget restXP must be a value or nil must be delt with
	
	end
	
	xpText:SetText(str) 
	xpBar:SetMinMaxValues(min(0, currXP), nextXP) 
	xpBar:SetValue(currXP) 

	
end)

border:RegisterForClicks('LeftButtonUp', 'RightButtonUp')
border:SetScript('OnClick', function(self, button)
	if button == "LeftButton" then
		if addon.settings.xpBarvar == "xpLeft" then
			addon.settings.xpBarvar = "xpTot"
		elseif addon.settings.xpBarvar == "xpTot" then
			addon.settings.xpBarvar = "xpLeft"
		end
		GrimExpRepBar:GetScript("OnEvent")(GrimExpRepBar)
	end	
end)
