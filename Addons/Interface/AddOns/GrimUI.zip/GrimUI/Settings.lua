local addonName, addon = ...

local defaults = {
	class = true
}

--[[-----------------------------------------------------------------------------
RegisterDefaultSetting - Allow modules to set their defaults
-------------------------------------------------------------------------------]]
function addon:RegisterDefaultSetting(key, value)											-- Use caution if using this after ADDON_LOADED
	defaults[key] = value
end

--[[-----------------------------------------------------------------------------
Load settings, apply version conversions as needed, and link to defaults
-------------------------------------------------------------------------------]]
addon.RegisterEvent("Settings-Load", 'ADDON_LOADED', function(self, event, name)
	if name ~= addonName then return end
	addon.UnregisterEvent(self, event)

	local name, class = UnitClass('player')
	name = UnitName('player')
	local realm = GetRealmName()

	local settings = _G[addonName .. "Settings"]
	if type(settings) ~= 'table' then
		settings = { }
		_G[addonName .. "Settings"] = settings
	end
	if type(settings[realm]) ~= 'table' then
		settings[realm] = { }
	end
	if type(settings[realm][name]) ~= 'table' then
		settings[realm][name] = { class = class }
	end

	settings.version = nil																			-- Reset value on logout (so can iterate over data without issue)
	addon.settings = setmetatable(settings[realm][name], { __index = defaults })
	return settings
end)

--[[-----------------------------------------------------------------------------
Remove unused settings or settings that are the same as defaults
-------------------------------------------------------------------------------]]
addon.RegisterEvent("Settings-Unload", 'PLAYER_LOGOUT', function()
	local settings = addon.settings
	for key, value in pairs(settings) do
		if value == defaults[key] or defaults[key] == nil then
			settings[key] = nil
		end
	end
	_G[addonName .. "Settings"].version = GetAddOnMetadata(addonName, 'Version')
end)

--[[-----------------------------------------------------------------------------
LOD Configuration
-------------------------------------------------------------------------------]]
local LOA = LibStub and LibStub('LibOptionsAssist-1.0', true)
if not (LOA and select(2, GetAddOnInfo(addonName .. "_Config"))) then return end	-- Make sure config support exists

addon.configPanel = LOA:AddEntry(addonName, nil, addonName .. "_Config")

_G['SLASH_' .. addonName .. 1] = '/' .. addonName
_G['SLASH_' .. addonName .. 2] = '/' .. addonName:lower()
_G['SLASH_' .. addonName .. 3] = '/' .. addonName:upper()
SlashCmdList[addonName] = addon.configPanel
