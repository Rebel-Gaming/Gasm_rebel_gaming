local addonName, addon = ...

_G[addonName] = addon

local function DoNothing()
end
addon.DoNothing = DoNothing

--[[-----------------------------------------------------------------------------
Event handling - Use one frame to process multiple individual OnEvent needs
-------------------------------------------------------------------------------]]
do
	local frame, select, next, events = CreateFrame('Frame'), select, pairs({ })
	local register, unregister = frame.RegisterEvent, frame.UnregisterEvent
	frame:Hide()

	frame:SetScript('OnEvent', function(self, event, ...)
		for reference, func in next, events[event], nil do
			func(reference, event, ...)
		end
	end)

	function addon.RegisterEvent(reference, event, func)
		if not events[event] then
			events[event] = { }
			register(frame, event)
		end
		events[event][reference] = func
	end

	function addon.RegisterEvents(reference, func, ...)
		local event
		for index = 1, select('#', ...) do
			event = select(index, ...)
			if not events[event] then
				events[event] = { }
				register(frame, event)
			end
			events[event][reference] = func
		end
	end

	function addon.UnregisterEvent(reference, event)
		if events[event] then
			events[event][reference] = nil
			if not next(events[event]) then
				events[event] = nil
				unregister(frame, event)
			end
		end
	end

	function addon.UnregisterAllEvents(reference)
		for event, registry in next, events, nil do
			registry[reference] = nil
			if not next(registry) then
				events[event] = nil
				unregister(frame, event)
			end
		end
	end
end

--[[-----------------------------------------------------------------------------
SafeCall - Queue a method of addon to run once combat ends if needed
-------------------------------------------------------------------------------]]
do
	local combatLockdown, queue = InCombatLockdown(), { }

	addon.RegisterEvent("Core-SafeCall-EnterCombat", 'PLAYER_REGEN_DISABLED', function(self)
		combatLockdown = true
	end)

	addon.RegisterEvent("Core-SafeCall-LeaveCombat", 'PLAYER_REGEN_ENABLED', function(self)
		combatLockdown = nil
		for method, arg in pairs(queue) do
			addon[method](addon, arg)
			queue[method] = nil
		end
	end)

	function addon:SafeCall(method, arg)
		if combatLockdown then
			queue[method] = arg or false
		else
			addon[method](addon, arg)
		end
	end
end

--[[-----------------------------------------------------------------------------
Localized class name to file class name look up table
-------------------------------------------------------------------------------]]
local CLASS = { }
for fileName, localName in pairs(LOCALIZED_CLASS_NAMES_MALE) do
	CLASS[localName] = fileName
end
for fileName, localName in pairs(LOCALIZED_CLASS_NAMES_FEMALE) do
	CLASS[localName] = fileName
end
addon.CLASS = CLASS

--[[-----------------------------------------------------------------------------
MoneyToString - Get formatted text from an ammount of copper
-------------------------------------------------------------------------------]]
function addon:MoneyToString(ammount, forceIcons)
	local cu = ammount % 100
	ammount = floor(ammount / 100)
	local ag, au = ammount % 100, floor(ammount / 100)
	local cuInd, agInd, auInd
	if GetCVarBool('showChatIcons') or forceIcons then
		cuInd = [[|TInterface\MoneyFrame\UI-CopperIcon:0|t]]
		agInd = [[|TInterface\MoneyFrame\UI-SilverIcon:0|t ]]
		auInd = [[|TInterface\MoneyFrame\UI-GoldIcon:0|t ]]
	else
		cuInd = "|cffeda55fc|r"
		agInd = "|cffc7c7cfs|r "
		auInd = "|cffffd700g|r "
	end
	local string = ""
	if au > 0 then
		string = au .. auInd .. ag .. agInd
	elseif ag > 0 then
		string = ag .. agInd
	end
	return string .. cu .. cuInd
end

--[[-----------------------------------------------------------------------------
HideTooltip - Hide GameTooltip (several frames use this)
-------------------------------------------------------------------------------]]
function addon:HideTooltip()
	GameTooltip:Hide()
	self.tooltip = nil
end

--[[-----------------------------------------------------------------------------
HideFrame - Hide a frame, prevents it from being reshown
-------------------------------------------------------------------------------]]
function addon:HideFrame(reference)
	local frame = type(reference) == 'string' and _G[reference] or reference
	if type(frame) ~= 'table' then return end
	frame.Show = DoNothing
	frame:Hide()
end

--[[-----------------------------------------------------------------------------
ShowFrame - Show a frame, undoing :HideFrame behavior
-------------------------------------------------------------------------------]]
function addon:ShowFrame(reference)
	local frame = type(reference) == 'string' and _G[reference] or reference
	if type(frame) ~= 'table' then return end
	frame.Show = nil
	frame:Show()
end

--[[-----------------------------------------------------------------------------
LockFrame - Lock a frame, prevents SetPoint and ClearAllPoints from working
-------------------------------------------------------------------------------]]
function addon:LockFrame(reference)
	local frame = type(reference) == 'string' and _G[reference] or reference
	if type(frame) ~= 'table' then return end
	frame.SetPoint = DoNothing
	frame.ClearAllPoints = DoNothing
end

--[[-----------------------------------------------------------------------------
UnlockFrame - Undo :LockFrame
-------------------------------------------------------------------------------]]
function addon:UnlockFrame(reference)
	local frame = type(reference) == 'string' and _G[reference] or reference
	if type(frame) ~= 'table' then return end
	frame.SetPoint = nil
	frame.ClearAllPoints = nil
end

--[[-----------------------------------------------------------------------------
RunSlashCmd
-------------------------------------------------------------------------------]]
function addon:RunSlashCmd(cmd)
	local slash, rest = cmd:match("^(%S+)%s*(.-)$")
	for name, func in pairs(SlashCmdList) do
		local i, slashCmd = 1
		repeat
			slashCmd = _G['SLASH_' .. name .. i]
			if slashCmd == slash then
				func(rest)
				return true
			end
			i = i + 1
		until not slashCmd
	end
end

--[[-----------------------------------------------------------------------------
LibSharedMedia support
-------------------------------------------------------------------------------]]
local LSM = LibStub('LibSharedMedia-3.0')

LSM:Register('background', addonName, [[Interface\Addons\]] .. addonName .. [[\Media\MainBG]])

LSM:Register('font', "Franklin Gothing Medium", [[Interface\Addons\]] .. addonName .. [[\Media\Font1.ttf]])
LSM:Register('font', "Comic Sans MS", [[Interface\Addons\]] .. addonName .. [[\Media\Font3.ttf]])

BINDING_HEADER_RAID_MOUSEOVER = "Raid Targeting (Mouseover)"
