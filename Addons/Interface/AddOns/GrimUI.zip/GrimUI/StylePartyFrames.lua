local addonName, addon = ...

addon:RegisterDefaultSetting("stylePartyFrames", 1)

--[[-----------------------------------------------------------------------------
ClearAllPoints on party frame and it's components
-------------------------------------------------------------------------------]]
local function clearAllPoints(frame)
	frame.PedestalFrame:ClearAllPoints()
	frame.HealthBorder:ClearAllPoints()
	frame.HealthBar:ClearAllPoints()
	frame.ManaBorder:ClearAllPoints()
	frame.ManaBar:ClearAllPoints()
	frame.InfoTextFrame:ClearAllPoints()
	frame.LetterFrame:ClearAllPoints()
	frame.HealthNumTxtFrame:ClearAllPoints()
	frame.ManaNumTxtFrame:ClearAllPoints()
	frame.LeaderFrame:ClearAllPoints()
	frame.pvpIconFrame:ClearAllPoints()
	frame.offDeadGhostTxtFrame:ClearAllPoints()
	frame.targetOfFrame:ClearAllPoints()

	-- Textblocks
	frame.HealthBorder.percentHText:ClearAllPoints()
	frame.ManaBorder.percentMText:ClearAllPoints()
	frame.InfoTextFrame.NameText:ClearAllPoints()
	frame.LetterFrame.LetterHText:ClearAllPoints()
	frame.LetterFrame.LetterMText:ClearAllPoints()
	frame.HealthNumTxtFrame.chnumtxt:ClearAllPoints()
	frame.HealthNumTxtFrame.mhnumtxt:ClearAllPoints()
	frame.ManaNumTxtFrame.CMNumTxt:ClearAllPoints()
	frame.ManaNumTxtFrame.MMNumTxt:ClearAllPoints()
	frame.InfoTextFrame.LvlClassText:ClearAllPoints()
	frame.DeadOfflineTxt:ClearAllPoints()
	frame.targetOfFrame.text:ClearAllPoints()
end

--[[-----------------------------------------------------------------------------
Layout Style 1
-------------------------------------------------------------------------------]]
local function layoutStyle1(id)
	local frame = _G[addonName .. "PartyFrame" .. id]
	clearAllPoints(frame)

	-- Main frame set height/width
	frame:SetWidth(223)
	frame:SetHeight(135)

	-- Pedestal
	frame.PedestalFrame:SetPoint('BOTTOM', frame, 'BOTTOM', -62, 0)
	frame.PedestalFrame:SetHeight(15)
	frame.PedestalFrame:SetWidth(49)
	frame.PedestalFrame.texture:SetTexture([[Interface\AddOns\]] .. addonName .. [[\Media\Pedestal]])
	frame.PedestalFrame:SetFrameStrata('LOW')
	frame.PedestalFrame:SetFrameLevel(2)

	-- Hhealth bar
	frame.HealthBorder:SetHeight(100)
	frame.HealthBorder:SetWidth(31)
	frame.HealthBorder:SetPoint('BOTTOMLEFT', frame, 'BOTTOMLEFT', 0, 0)
	frame.HealthBorder:SetBackdrop({ edgeFile = [[Interface\DialogFrame\UI-DialogBox-Border]], edgeSize = 5 })
	frame.HealthBorder:SetBackdropBorderColor(0, 0, 0, 1)
	frame.HealthBorder:SetFrameStrata('HIGH')
	frame.HealthBorder:SetFrameLevel(2)

	frame.HealthBar:SetWidth(29)
	frame.HealthBar:SetHeight(98)
	frame.HealthBar:SetPoint('CENTER', frame.HealthBorder, 'CENTER', 0, 0)
	frame.HealthBar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\VBarTexture]])
	frame.HealthBar:SetStatusBarColor(0.231, 0.682, 0.419, 1)
	frame.HealthBar:SetOrientation('VERTICAL')
	frame.HealthBar:SetFrameStrata('BACKGROUND')
	frame.HealthBar:SetFrameLevel(2)

	frame.HealthBorder.percentHText:SetPoint('TOP', frame.HealthBorder, 'TOP', 0, -1)
	frame.HealthBorder.percentHText:SetTextColor(1, 1, 1, 1)
	frame.HealthBorder.percentHText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 10)

	-- Mana bar
	frame.ManaBorder:SetHeight(100)
	frame.ManaBorder:SetWidth(31)
	frame.ManaBorder:SetPoint('BOTTOM', frame, 'BOTTOM', -29, 0)
	frame.ManaBorder:SetBackdrop({ edgeFile = [[Interface\DialogFrame\UI-DialogBox-Border]], edgeSize = 5 })
	frame.ManaBorder:SetBackdropBorderColor(0, 0, 0, 1)
	frame.ManaBorder:SetFrameStrata('HIGH')
	frame.ManaBorder:SetFrameLevel(2)

	frame.ManaBar:SetWidth(29)
	frame.ManaBar:SetHeight(98)
	frame.ManaBar:SetPoint('CENTER', frame.ManaBorder, 'CENTER', 0, 0)
	frame.ManaBar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\VBarTexture]])
	frame.ManaBar:SetOrientation('VERTICAL')
	frame.ManaBar:SetFrameStrata('BACKGROUND')
	frame.ManaBar:SetFrameLevel(2)

	frame.ManaBorder.percentMText:SetPoint('TOP', frame.ManaBorder, 'TOP', 0, -1)
	frame.ManaBorder.percentMText:SetTextColor(1, 1, 1, 1)
	frame.ManaBorder.percentMText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 10)

	-- TextInfo
	frame.InfoTextFrame:SetPoint('RIGHT', frame, 'RIGHT', 0, -7)
	frame.InfoTextFrame:SetWidth(125)
	frame.InfoTextFrame:SetHeight(79)
	frame.InfoTextFrame:SetFrameStrata('HIGH')
	frame.InfoTextFrame:SetFrameLevel(5)

	-- Name text
	frame.InfoTextFrame.NameText:SetPoint('TOPLEFT', frame.InfoTextFrame, 'TOPLEFT', -1, 0)
	frame.InfoTextFrame.NameText:SetPoint('RIGHT', frame.InfoTextFrame, 'RIGHT', 0, 0)
	frame.InfoTextFrame.NameText:SetJustifyH('LEFT')
	frame.InfoTextFrame.NameText:SetTextColor(1, 1, 1, 1)
	frame.InfoTextFrame.NameText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font3.ttf]], 17, 'OUTLINE')

	frame.LetterFrame:SetPoint('LEFT', frame.InfoTextFrame, 'LEFT', 0, -20)
	frame.LetterFrame:SetWidth(1)
	frame.LetterFrame:SetHeight(1)

	frame.LetterFrame.LetterHText:SetPoint('LEFT', frame.LetterFrame, 'LEFT', 2, 0)
	frame.LetterFrame.LetterHText:SetTextColor(0.937, 1, 0.345, 1)
	frame.LetterFrame.LetterHText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 12, 'OUTLINE')

	frame.LetterFrame.LetterMText:SetPoint('LEFT', frame.LetterFrame, 'LEFT', 60, 0)
	frame.LetterFrame.LetterMText:SetTextColor(0.937, 1, 0.345, 1)
	frame.LetterFrame.LetterMText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 12, 'OUTLINE')

	frame.LetterFrame.LetterHText:SetText("H:")
	frame.LetterFrame.LetterMText:SetText("M:")

	frame.LetterFrame.LetterHText:Show()
	frame.LetterFrame.LetterMText:Show()

	-- health numbered text start
	frame.HealthNumTxtFrame:SetPoint('LEFT', frame.InfoTextFrame, 'LEFT', 0, -16)
	frame.HealthNumTxtFrame:SetWidth(1)
	frame.HealthNumTxtFrame:SetHeight(1)
	
	frame.HealthNumTxtFrame.chnumtxt:Show()
	frame.HealthNumTxtFrame.chnumtxt:SetPoint('LEFT', frame.HealthNumTxtFrame , 'LEFT', 16, 0)
	frame.HealthNumTxtFrame.chnumtxt:SetTextColor(1, 1, 1, 1)
	frame.HealthNumTxtFrame.chnumtxt:SetJustifyH('RIGHT')
	frame.HealthNumTxtFrame.chnumtxt:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 12, 'OUTLINE')

	frame.HealthNumTxtFrame.mhnumtxt:Show()
	frame.HealthNumTxtFrame.mhnumtxt:SetPoint('TOP', frame.HealthNumTxtFrame.chnumtxt , 'BOTTOM', 0, 0)
	frame.HealthNumTxtFrame.mhnumtxt:SetTextColor(1, 1, 1, 1)
	frame.HealthNumTxtFrame.mhnumtxt:SetJustifyH('RIGHT')
	frame.HealthNumTxtFrame.mhnumtxt:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 12, 'OUTLINE')

	-- Mana numbered text start
	frame.ManaNumTxtFrame:SetPoint('RIGHT', frame.InfoTextFrame, 'RIGHT', -8, -16)
	frame.ManaNumTxtFrame:SetWidth(1)
	frame.ManaNumTxtFrame:SetHeight(1)

	frame.ManaNumTxtFrame.CMNumTxt:Show()
	frame.ManaNumTxtFrame.CMNumTxt:SetPoint('RIGHT', frame.ManaNumTxtFrame, 'RIGHT', 0, 0)
	frame.ManaNumTxtFrame.CMNumTxt:SetTextColor(1, 1, 1, 1)
	frame.ManaNumTxtFrame.CMNumTxt:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 12, 'OUTLINE')

	frame.ManaNumTxtFrame.MMNumTxt:Show()
	frame.ManaNumTxtFrame.MMNumTxt:SetPoint('TOP', frame.ManaNumTxtFrame.CMNumTxt, 'BOTTOM', 0, 0)
	frame.ManaNumTxtFrame.MMNumTxt:SetTextColor(1, 1, 1, 1)
	frame.ManaNumTxtFrame.MMNumTxt:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 12, 'OUTLINE')

	frame.InfoTextFrame.LvlClassText:SetPoint('TOP', frame.InfoTextFrame, 'TOP', 0, -34)
	frame.InfoTextFrame.LvlClassText:SetPoint('LEFT', frame.InfoTextFrame, 'LEFT', 2, 0)
	frame.InfoTextFrame.LvlClassText:SetPoint('RIGHT', frame.InfoTextFrame, 'RIGHT', 0, 0)
	frame.InfoTextFrame.LvlClassText:SetJustifyH('LEFT')
	frame.InfoTextFrame.LvlClassText:SetTextColor(0.937, 1, 0.345, 1)
	frame.InfoTextFrame.LvlClassText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 12, 'OUTLINE')

	-- Leader icon
	frame.LeaderFrame:SetPoint('TOPLEFT', frame.InfoTextFrame, 'TOPLEFT', 3, -17)
	frame.LeaderFrame:SetHeight(20)
	frame.LeaderFrame:SetWidth(20)
	frame.LeaderFrame.texture:SetTexture([[Interface\GroupFrame\UI-Group-LeaderIcon]])

	-- PVP icon
	frame.pvpIconFrame:SetPoint('TOPLEFT', frame.InfoTextFrame, 'TOPLEFT', 22, -17)
	frame.pvpIconFrame:SetHeight(21)
	frame.pvpIconFrame:SetWidth(21)

	-- Offline/Dead overlay
	frame.offDeadGhostTxtFrame:SetPoint('LEFT', frame, 'LEFT', 15, 0)
	frame.offDeadGhostTxtFrame:SetWidth(68)
	frame.offDeadGhostTxtFrame:SetHeight(15)
	frame.DeadOfflineTxt:SetPoint('CENTER', frame.offDeadGhostTxtFrame , 'CENTER', 0, 0)
	frame.DeadOfflineTxt:SetTextColor(0.85, 0.10, 0.10, 1)
	frame.DeadOfflineTxt:SetJustifyH('CENTER')
	frame.DeadOfflineTxt:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 18, 'OUTLINE')

	-- Target of target
	frame.targetOfFrame:SetPoint('BOTTOMRIGHT', frame, 'BOTTOMRIGHT', -2, 1)
	frame.targetOfFrame:SetWidth(122)
	frame.targetOfFrame:SetHeight(19)
	frame.targetOfFrame:SetFrameStrata('HIGH')
	frame.targetOfFrame:SetFrameLevel(5)
	frame.targetOfFrame.text:SetPoint('TOPLEFT', frame.targetOfFrame, 'TOPLEFT', 0, 0)
	frame.targetOfFrame.text:SetPoint('BOTTOMRIGHT', frame.targetOfFrame, 'BOTTOMRIGHT', 0, 0)
	frame.targetOfFrame.text:SetTextColor(1, 1, 1, 1)
	frame.targetOfFrame.text:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font3.ttf]], 11, 'OUTLINE')
end

--[[-----------------------------------------------------------------------------
Layout Style 2
-------------------------------------------------------------------------------]]
local function layoutStyle2(id)  
    local frame = _G[addonName .. "PartyFrame" .. id]

end

--[[-----------------------------------------------------------------------------
StylePartyFrames
-------------------------------------------------------------------------------]]
function addon:StylePartyFrames()
	if addon.settings.stylePartyFrames == 2 then
		for id = 1, 4 do
			layoutStyle2(id)
		end
	else	-- Default to 1
		for id = 1, 4 do
			layoutStyle1(id)
		end
	end
end
