local addonName, addon = ...

local GrimTargetFrame = CreateFrame("Frame", addonName .. "TargetFrame", UIParent, "SecureUnitButtonTemplate")

GrimTargetFrame:SetFrameStrata("BACKGROUND") 
GrimTargetFrame:SetFrameLevel(4) 
GrimTargetFrame:SetWidth(230) 
GrimTargetFrame:SetHeight(180) 
GrimTargetFrame:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 138)
GrimTargetFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
GrimTargetFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
GrimTargetFrame:RegisterEvent("PARTY_MEMBERS_CHANGED")

GrimTargetFrame:SetAttribute('unit', 'target')
RegisterUnitWatch(GrimTargetFrame)


local GrimTargetSounds = CreateFrame("Frame", nil, UIParent)
GrimTargetSounds:RegisterEvent("PLAYER_TARGET_CHANGED")

GrimTargetSounds:SetScript("OnEvent", function(self)
	local unitexists = UnitExists("target")
	
	if unitexists == 1 then
		PlaySound("igCreatureNeutralSelect");
	elseif unitexists == nil then
		PlaySound("INTERFACESOUND_LOSTTARGETUNIT");
	end
end)

local eliteRareEvent = CreateFrame("Frame", nil, UIParent)
eliteRareEvent:RegisterEvent("PLAYER_TARGET_CHANGED")

GrimUI.eliteRareEvent = eliteRareEvent

local eliteRareFrame = CreateFrame("Frame", "eliteRareFrame", nil)


eliteRareFrame.textureL = eliteRareFrame:CreateTexture(left)
eliteRareFrame.textureL:SetPoint("BOTTOMLEFT", GrimTargetFrame, "TOPLEFT", 9, -26)
eliteRareFrame.textureL:SetHeight(32)
eliteRareFrame.textureL:SetWidth(30)

eliteRareFrame.textureR = eliteRareFrame:CreateTexture(right)
eliteRareFrame.textureR:SetPoint("BOTTOMRIGHT", GrimTargetFrame, "TOPRIGHT", -9, -26)
eliteRareFrame.textureR:SetHeight(32)
eliteRareFrame.textureR:SetWidth(30)


eliteRareFrame:SetFrameStrata("HIGH") 
eliteRareFrame:SetFrameLevel(5) 





eliteRareEvent:SetScript("OnEvent", function(self) 

	local classification = UnitClassification("target")
	
	if classification == "elite" or classification == "worldboss" then
	eliteRareFrame.textureR:SetTexture([[Interface\AddOns\]] .. addonName .. [[\Media\Elite]])
	
	eliteRareFrame.textureR:SetTexCoord(1, 0, 0, 1)
	
	eliteRareFrame.textureL:SetTexture([[Interface\AddOns\]] .. addonName .. [[\Media\Elite]])
	
	
	elseif classification == "rare" then
	eliteRareFrame.textureR:SetTexture([[Interface\AddOns\]] .. addonName .. [[\Media\Rare]])
	
	eliteRareFrame.textureR:SetTexCoord(1, 0, 0, 1)
	
	eliteRareFrame.textureL:SetTexture([[Interface\AddOns\]] .. addonName .. [[\Media\Rare]])
	
	
	elseif classification == "rareelite" then
	eliteRareFrame.textureR:SetTexture([[Interface\AddOns\]] .. addonName .. [[\Media\Rare]])
	
	eliteRareFrame.textureR:SetTexCoord(1, 0, 0, 1)
	
	eliteRareFrame.textureL:SetTexture([[Interface\AddOns\]] .. addonName .. [[\Media\Elite]])

	else
	eliteRareFrame.textureR:SetTexture(nil)
	eliteRareFrame.textureL:SetTexture(nil)
	end
end)

-- PVP Icon Start
local targPvpIconEvent = CreateFrame("Frame", nil, UIParent)
targPvpIconEvent:RegisterEvent("ADDON_LOADED")
targPvpIconEvent:RegisterEvent("UNIT_FACTION") 
targPvpIconEvent:RegisterEvent("PLAYER_TARGET_CHANGED")

targPvpIconFrame = CreateFrame("Frame", "TargPvpIconFrame", GrimTargetFrame)
targPvpIconFrame:SetPoint("TOPRIGHT", GrimTargetFrame, "TOPRIGHT", -40, -24)
targPvpIconFrame:SetHeight(33)
targPvpIconFrame:SetWidth(33)
targPvpIconFrame.texture = targPvpIconFrame:CreateTexture()
targPvpIconFrame.texture:SetAllPoints(targPvpIconFrame)


targPvpIconEvent:SetScript("OnEvent", function(self) 
    
    local englishFaction, localizedFaction = UnitFactionGroup("target")
    if englishFaction == "Alliance" then    
    targPvpIconFrame.texture:SetTexture("Interface\\GroupFrame\\UI-Group-PVP-Alliance.blp")
    elseif englishFaction == "Horde" then
    targPvpIconFrame.texture:SetTexture("Interface\\GroupFrame\\UI-Group-PVP-Horde.blp")
    end
    
    local ispvp = UnitIsPVP("target")
   
    if ispvp == 1 then
    targPvpIconFrame:Show()
    else
    targPvpIconFrame:Hide()
    end
end)
-- PVP Icon End





-- health bar start
local TargetHealthEvents = CreateFrame("Frame", nil, UIParent)
TargetHealthEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
TargetHealthEvents:RegisterEvent("UNIT_HEALTH")
TargetHealthEvents:RegisterEvent("PLAYER_LEVEL_UP")
TargetHealthEvents:RegisterEvent("UNIT_AURA", "target")
TargetHealthEvents:RegisterEvent("UNIT_MAXHEALTH")
TargetHealthEvents:RegisterEvent("PLAYER_TARGET_CHANGED")

GrimUI.TargetHealthEvents = TargetHealthEvents


local GUI_TargetHealth = CreateFrame('Button', "GUI_TargetHealth", GrimTargetFrame, "SecureActionButtonTemplate")
GUI_TargetHealth:SetHeight(110)
GUI_TargetHealth:SetWidth(36)
GUI_TargetHealth:SetPoint("TOPLEFT", GrimTargetFrame, "TOPLEFT", -2, -34)

GUI_TargetHealth:SetBackdrop{ 
		bgFile = nil, 
		edgeFile = [[Interface\DialogFrame\UI-DialogBox-Border]], tile = false, tileSize = 0, edgeSize = 5, 
		insets = { left = 0, right = 0, top = 0, bottom = 0 } 
	} 
GUI_TargetHealth:SetBackdropBorderColor(0, 0, 0, 1)


GUI_TargetHealth:SetFrameStrata("BACKGROUND")
GUI_TargetHealth:SetFrameLevel("3")

GUI_TargetHealth:RegisterForClicks("AnyUp")
GUI_TargetHealth:SetAttribute("unit", "target")
GUI_TargetHealth:SetAttribute("*type1", "target")

local showmenu = function() 
	ToggleDropDownMenu(1, nil, TargetFrameDropDown, "cursor", 0, 0) 
end
GUI_TargetHealth.showmenu = showmenu
GUI_TargetHealth.unit = "target"
GUI_TargetHealth:SetAttribute("*type2", "showmenu")
GUI_TargetHealth:SetScript("OnEnter", UnitFrame_OnEnter)
GUI_TargetHealth:SetScript("OnLeave", UnitFrame_OnLeave)

local healthBar = CreateFrame("StatusBar", nil, GUI_TargetHealth, "TextStatusBar")
healthBar:SetWidth(34)
healthBar:SetHeight(109)
healthBar:SetPoint("CENTER", GUI_TargetHealth, "CENTER", 0, 0)
healthBar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\VBarTexture]])
healthBar:SetStatusBarColor(.231, .682, .419, 1)
healthBar:SetOrientation("VERTICAL")
healthBar:SetFrameStrata("BACKGROUND")
healthBar:SetFrameLevel("2")

GrimUI.healthBar = healthBar

local percentHText = GUI_TargetHealth:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
percentHText:SetPoint("TOP", GUI_TargetHealth, "TOP", 0, -1)
percentHText:SetTextColor(1, 1, 1, 1)
percentHText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 11)

GrimUI.percentHText = percentHText





--local takenDMGbar = CreateFrame("StatusBar", nil, TargetHealthEvents, "TextStatusBar")
--takenDMGbar:SetWidth(175)
--takenDMGbar:SetHeight(25)
--takenDMGbar:SetPoint("CENTER", GUI_TargetHealth, "CENTER", 0, 0)
--takenDMGbar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\BarTexture]])
--takenDMGbar:SetStatusBarColor(.721, .047, .890, 1)
--takenDMGbar:SetFrameLevel("2")

--GrimUI.takenDMGbar = takenDMGbar




-- health bar end


-- Mana Bar Start
local TargetManaEvents = CreateFrame("Frame", nil, UIParent)
TargetManaEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
TargetManaEvents:RegisterEvent("UNIT_HEALTH")
TargetManaEvents:RegisterEvent("PLAYER_LEVEL_UP")
TargetManaEvents:RegisterEvent("UNIT_MANA")
TargetManaEvents:RegisterEvent("UNIT_AURA")
TargetManaEvents:RegisterEvent("UNIT_DISPLAYPOWER")
TargetManaEvents:RegisterEvent("UNIT_ENERGY")
TargetManaEvents:RegisterEvent("UNIT_MAXENERGY")
TargetManaEvents:RegisterEvent("UNIT_MAXMANA")
TargetManaEvents:RegisterEvent("UNIT_MAXRUNICPOWER")
TargetManaEvents:RegisterEvent("UNIT_RUNIC_POWER")
TargetManaEvents:RegisterEvent("UNIT_RAGE")
TargetManaEvents:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
TargetManaEvents:RegisterEvent("PLAYER_TARGET_CHANGED")

GrimUI.TargetManaEvents = TargetManaEvents

local GUI_TargetMana = CreateFrame('Button', "GUI_TargetMana", GrimTargetFrame, "SecureActionButtonTemplate")
GUI_TargetMana:SetHeight(110)
GUI_TargetMana:SetWidth(36)
GUI_TargetMana:SetPoint("TOPRIGHT", GrimTargetFrame, "TOPRIGHT", 2, -34)

GUI_TargetMana:SetBackdrop{ 
		bgFile = nil, 
		edgeFile = "Interface/DialogFrame/UI-DialogBox-Border", tile = false, tileSize = 0, edgeSize = 5, 
		insets = { left = 0, right = 0, top = 0, bottom = 0 } 
	} 
GUI_TargetMana:SetBackdropBorderColor(0, 0, 0, 1)


GUI_TargetMana:SetFrameStrata("BACKGROUND")
GUI_TargetMana:SetFrameLevel("3")


GUI_TargetMana:RegisterForClicks("AnyUp")
GUI_TargetMana:SetAttribute("unit", "target")
GUI_TargetMana:SetAttribute("*type1", "target")

local showmenu = function() 
	ToggleDropDownMenu(1, nil, TargetFrameDropDown, "cursor", 0, 0) 
end
GUI_TargetMana.showmenu = showmenu
GUI_TargetMana.unit = "target"
GUI_TargetMana:SetAttribute("*type2", "showmenu")
GUI_TargetMana:SetScript("OnEnter", UnitFrame_OnEnter)
GUI_TargetMana:SetScript("OnLeave", UnitFrame_OnLeave)

GrimUI.GUI_TargetMana = GUI_TargetMana

local manaBar = CreateFrame("StatusBar", nil, GUI_TargetMana, "TextStatusBar")
manaBar:SetWidth(34)
manaBar:SetHeight(109)
manaBar:SetPoint("CENTER", GUI_TargetMana, "CENTER", 0, 0)
manaBar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\VBarTexture]])
manaBar:SetOrientation("VERTICAL")
manaBar:SetFrameStrata("BACKGROUND")
manaBar:SetFrameLevel("2")


GrimUI.manaBar = manaBar



--local powerUsed = CreateFrame("StatusBar", nil, manaBarEventFrame, "TextStatusBar")
--powerUsed:SetWidth(175)
--powerUsed:SetHeight(25)
--powerUsed:SetPoint("CENTER", GUI_TargetMana, "CENTER", 0, 0)
--powerUsed:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\BarTexture]])
--powerUsed:SetStatusBarColor(.721, .047, .890, 1)
--powerUsed:SetFrameLevel("2")
--manaBarEventFrame.powerUsed = powerUsed

local percentMText = GUI_TargetHealth:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
percentMText:SetPoint("TOP", GUI_TargetMana, "TOP", 0, -1)
percentMText:SetTextColor(1, 1, 1, 1)
percentMText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 11)

GrimUI.percentMText = percentMText





-- Mana Bar End


-- Health/Mana text display frame
local healthManaTxtDisplay = CreateFrame("frame", nil, GrimTargetFrame)
healthManaTxtDisplay:SetWidth(125)
healthManaTxtDisplay:SetHeight(50)
healthManaTxtDisplay:SetPoint("CENTER", GrimTargetFrame, "CENTER", 0, 60)
healthManaTxtDisplay:SetFrameStrata("HIGH")
healthManaTxtDisplay:SetFrameLevel("5")
healthManaTxtDisplay:RegisterEvent("PLAYER_TARGET_CHANGED")

GrimUI.healthManaTxtDisplay = healthManaTxtDisplay

local healthText = healthManaTxtDisplay:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
healthText:SetPoint("TOP", healthManaTxtDisplay, "TOP", 0, -8)
healthText:SetTextColor(1, 1, 1, 1)
healthText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 12, "OUTLINE")

GrimUI.healthText = healthText

local manaText = healthManaTxtDisplay:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
manaText:SetPoint("TOP", healthText, "BOTTOM", 0, 0)
manaText:SetTextColor(1, 1, 1, 1)
manaText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 11, "OUTLINE")
GrimUI.manaText = manaText

local targetLvlText = healthManaTxtDisplay:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
targetLvlText:SetPoint("BOTTOMRIGHT", healthManaTxtDisplay, "TOPLEFT", 2, -13)
targetLvlText:SetTextColor(1, 1, 1, 1)
targetLvlText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 13, "OUTLINE")
GrimUI.targetLvlText = targetLvlText

local targetClassText = healthManaTxtDisplay:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
targetClassText:SetPoint("BOTTOM", healthText, "TOP", 0, 0)
targetClassText:SetJustifyH("RIGHT")
targetClassText:SetPoint("RIGHT", healthManaTxtDisplay, "RIGHT", -1, 0)
targetClassText:SetTextColor(1, 1, 1, 1)
targetClassText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 13, "OUTLINE")
GrimUI.targetClassText = targetClassText

local targetRaceText = healthManaTxtDisplay:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
targetRaceText:SetPoint("BOTTOM", healthText, "TOP", 0, 0)
targetRaceText:SetPoint("RIGHT", targetClassText, "RIGHT", 0, 0)
targetRaceText:SetPoint("LEFT", healthManaTxtDisplay, "LEFT", 2, 0)
targetRaceText:SetJustifyH("LEFT")
targetRaceText:SetTextColor(1, 1, 1, 1)
targetRaceText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 13, "OUTLINE")




TargetHealthEvents:SetScript("OnEvent", function(self) 
    local currHealth, maxHealth = UnitHealth("Target"), UnitHealthMax("Target") 
    local percentHealth = floor(currHealth / maxHealth * 100)
	
    local str = ("%s/%s"):format(currHealth, maxHealth)
    local perstr = ("%s%%"):format(percentHealth)   
    
	healthText:SetText(str) 
    healthBar:SetMinMaxValues(min(0, currHealth), maxHealth) 
    healthBar:SetValue(currHealth) 
	percentHText:SetText(perstr)
    --takenDMGbar:SetMinMaxValues(min(0, currHealth), maxHealth) 
    --takenDMGbar:SetValue(currHealth) 
end)

TargetManaEvents:SetScript("OnEvent", function(self) 
    local currMana, maxMana = UnitMana("target"), UnitManaMax("target") 
    local powerType = UnitPowerType("target")
    local currPower = UnitPower("target")
    local maxPower = UnitPowerMax("target")
    local currShape = GetShapeshiftForm()
    local percentMana = floor(currMana / maxMana * 100)
	
	
    if maxMana >= 1 then
		local perMstr = ("%s%%"):format(percentMana)
		percentMText:SetText(perMstr)
	end
	
	if maxMana == 0 then
		local perMstr = ("0%")
		percentMText:SetText(perMstr)
	end
	
    
	
	
	if powerType == 0 then
        local manaSTR = ("%s/%s"):format(currMana, maxMana)
        manaText:SetText(manaSTR) 
        manaBar:SetMinMaxValues(min(0, currMana), maxMana) 
        manaBar:SetValue(currMana) 
        manaBar:SetStatusBarColor(.556, .556, .921, 1)
        --powerUsed:SetMinMaxValues(min(0, currMana), maxMana) 
        --powerUsed:SetValue(currMana) 
    elseif powerType == 1 or 3 or 6 then
    local manaSTR = ("%s/%s"):format(currPower, maxPower)
        manaText:SetText(manaSTR) 
        manaBar:SetMinMaxValues(min(0, currPower), maxPower) 
        manaBar:SetValue(currPower) 
        manaBar:SetStatusBarColor(.656, .456, .456, 1)
        --powerUsed:SetMinMaxValues(min(0, currPower), maxPower) 
        --powerUsed:SetValue(currPower)
    end
	
	
	end)

local BossTexture = CreateFrame("frame", BossTexture, nil )	

BossTexture.texture = BossTexture:CreateTexture(BossTexture)
BossTexture.texture:SetPoint("TOPLEFT", GrimTargetFrame, "TOPLEFT", 19, 0)
BossTexture.texture:SetHeight(12)
BossTexture.texture:SetWidth(13)
BossTexture:SetFrameStrata("HIGH")
BossTexture:SetFrameLevel("9")



healthManaTxtDisplay:SetScript("OnEvent", function(self) 
	
	local targetlvl = UnitLevel("target")
	local targclass = UnitClass("target")
	local targetrace = UnitRace("target")
	local targetname = UnitName("target")
	local unitexists = UnitExists("target")
	
	
	if targetrace == nil and unitexists == 1 then 
		local targClasStr = ("%s"):format(targclass)
		targetClassText:SetText(targClasStr)
	
		targetRaceText:SetText("")
		targetClassText:SetPoint("LEFT", healthManaTxtDisplay, "LEFT", 0, 0)
	end
	
	if targetrace ~= nil and unitexists == 1 then
				
		local targRaceStr = ("%s"):format(targetrace)
		targetRaceText:SetText(targRaceStr)
			
		local targClasStr = ("%s"):format(targclass)
		targetClassText:SetText(targClasStr)
	
		targetClassText:SetPoint("LEFT", healthManaTxtDisplay, "CENTER", 0, 0)
	end
	
	
	if targetlvl >= 0 then
	local targLvlStr = ("%s"):format(targetlvl)
	targetLvlText:SetText(targLvlStr)
	BossTexture.texture:SetTexture(nil)
	
	
	elseif targetlvl == -1 then
	targetLvlText:SetText("")
	BossTexture.texture:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull.blp")
	end
	
	
end)

--[[######################  
	       Target Name / Guild Frame START 
	   ########################]] 
	   
	   
local targetNameGuildFrame = CreateFrame("frame", nil, GrimTargetFrame)
targetNameGuildFrame:SetWidth(226)
targetNameGuildFrame:SetHeight(12)
targetNameGuildFrame:SetPoint("BOTTOM", GrimTargetFrame, "BOTTOM", 0, 16)
targetNameGuildFrame:SetFrameStrata("HIGH")
targetNameGuildFrame:SetFrameLevel("5")
targetNameGuildFrame:RegisterEvent("PLAYER_TARGET_CHANGED")

GrimUI.targetNameGuildFrame = targetNameGuildFrame

local targetNameText = targetNameGuildFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
targetNameText:SetPoint("TOP", targetNameGuildFrame, "TOP", 0, 0)
targetNameText:SetPoint("LEFT", targetNameGuildFrame, "LEFT", 0, 0)
targetNameText:SetPoint("RIGHT", targetNameGuildFrame, "RIGHT", 0, 0)
targetNameText:SetTextColor(1, 1, 1, 1)
targetNameText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font3.ttf]], 12, "OUTLINE")

GrimUI.targetNameText = targetNameText

targetNameGuildFrame:SetScript("OnEvent", function(self) 
    local targetName = UnitName("Target")
    local targetGuildName = GetGuildInfo("target")
	local unitexists = UnitExists("target")
	
	if targetGuildName == nil and unitexists == 1 then
		local namegstr = ("%s"):format(targetName)
		targetNameText:SetText(namegstr)
	end
	if targetGuildName ~= nil and unitexists == 1 then
		local namegstr = ("%s - %s"):format(targetName, targetGuildName)
		targetNameText:SetText(namegstr)
	end
	
    
end)
  
	   
--[[######################  
	       Target Name / Guild Frame END 
	   ########################]] 

--[[######################  
	       Target targettarget Frame START 
	   ########################]] 
	   
	   
local targetOfTargetFrame = CreateFrame("frame", nil, GrimTargetFrame)
targetOfTargetFrame:SetWidth(226)
targetOfTargetFrame:SetHeight(12)
targetOfTargetFrame:SetPoint("BOTTOM", GrimTargetFrame, "BOTTOM", 0, 3)
targetOfTargetFrame:SetFrameStrata("HIGH")
targetOfTargetFrame:SetFrameLevel("5")
targetOfTargetFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
targetOfTargetFrame:RegisterEvent("UNIT_TARGET", "target")
GrimUI.targetOfTargetFrame = targetOfTargetFrame

local targetOfTargetText = targetOfTargetFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
targetOfTargetText:SetPoint("TOP", targetOfTargetFrame, "TOP", 0, 0)
targetOfTargetText:SetPoint("LEFT", targetOfTargetFrame, "LEFT", 0, 0)
targetOfTargetText:SetPoint("RIGHT", targetOfTargetFrame, "RIGHT", 0, 0)
targetOfTargetText:SetTextColor(1, 1, 1, 1)
targetOfTargetText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font3.ttf]], 12, "OUTLINE")

GrimUI.targetOfTargetText = targetOfTargetText

targetOfTargetFrame:SetScript("OnEvent", function(self) 
    local targetTargetName = UnitName("Targettarget")
    local targetExists = UnitExists("targettarget")
	local targetMe = UnitName("player")
	
	if  targetExists == 1 and targetTargetName == targetMe then
		targetOfTargetText:SetText("Targeting - ** YOU **")
	end
	if  targetExists == 1 and targetTargetName ~= targetMe then
		local nametstr = ("Targeting - %s"):format(targetTargetName)
		targetOfTargetText:SetText(nametstr)
	end
	if targetExists == nil then
	targetOfTargetText:SetText("-No Target-")
	end
    
end)
  
	   
--[[######################  
	       Target targettargetFrame END 
	   ########################]]

	   
	   
	   



 
 
 --[[######################  
	       The Target-Buttons START 
	   ########################]] 
	 
	    -- Let's create only one tooltip-function for all buttons  
	    -- and get the text and anchor from their variables (see below)  
	    local function button_OnEnter(self) 
	        GameTooltip:SetOwner(self, self.Anchor) 
	        GameTooltip:AddLine(self.TipText) 
	        GameTooltip:Show() 
	    end 
	    -- And the hiding ...  
	    local function button_OnLeave(self) 
	        GameTooltip:Hide() 
	    end 
	 
	 
	    -- Same procedure as above, commonly used settings in a function  
	    -- we need a name which is also used for the backdrop file name  
	    -- and anchor and tooltipText (you remember, the tooltip above!)  
	    local function createTargetButton(name, anchor, tooltipText) 
	        local button = CreateFrame("Button", "GrimUIcore"..name.."Button", GrimTargetFrame) 
	        button:SetFrameStrata("HIGH") 
	        button:Hide() 
	        button:SetWidth(15) 
	        button:SetHeight(15) 
	        button.Anchor = anchor -- Lets store the anchor-variable in the button  
	        button.TipText = tooltipText -- and the tooltipText, too  
	        button:SetNormalTexture([[Interface\AddOns\]] .. addonName .. [[\Media\]] .. name .. "Icon") 
			button:SetHighlightTexture([[Interface\AddOns\]] .. addonName .. [[\Media\]] .. name .. "Icon")
	        -- Assign our tooltip-functions from above  
	        button:SetScript("OnEnter", button_OnEnter) 
	        button:SetScript("OnLeave", button_OnLeave) 
	 
	        button:SetNormalFontObject(GameFontNormal) 
	        button:SetHighlightFontObject(GameFontHighlight) 
	        button:SetDisabledFontObject(GameFontDisable) 
	 
	        return button 
	    end 
	 
	    -- The inspect-button, created with our own function!  
	    local inspect = createTargetButton("Inspect", "ANCHOR_LEFT", "Inspect") 
	    inspect:SetPoint("CENTER", -63, 46) 
	    inspect:SetScript("OnClick", function(self) 
	        InspectUnit("target") 
	    end) 
	 
	    -- and whisper  
	    local whisper = createTargetButton("Whisper", "ANCHOR_LEFT", "Whisper") 
	    whisper:SetPoint("TOP", inspect, "BOTTOM", 0, -4) 
	    whisper:SetScript("OnClick", function(self) 
	        local name, realm = UnitName("target") 
	        if realm then 
	            ChatFrame_SendTell(name.."-"..realm) 
	        else 
	            ChatFrame_SendTell(name) 
	        end 
	    end) 
		
		-- and follow  
	    local follow = createTargetButton("Follow", "ANCHOR_LEFT", "Follow") 
	    follow:SetPoint("TOP", whisper, "BOTTOM", 0, -4) 
	    follow:SetScript("OnClick", function(self) 
	        FollowUnit("target") 
	    end) 
	 
		
		-- Same goes for trade  
	    local trade = createTargetButton("Trade", "ANCHOR_LEFT", "Trade") 
	    trade:SetPoint("TOP", follow, "BOTTOM", 0, -5) 
	    trade:SetScript("OnClick", function(self) 
	        InitiateTrade("target") 
	    end) 
	 
	 
	    -- even invite gets one  
	    local invite = createTargetButton("Invite", "ANCHOR_RIGHT", "Invite") 
	    invite:SetPoint("CENTER", -43, 39) 
	    invite:SetScript("OnClick", function(self) 
	        local name = UnitName("target") 
	        InviteUnit(name) 
	    end) 
	 
	    -- and gtip  
	    local gtip = createTargetButton("Notes", "ANCHOR_RIGHT", "Add Note") 
	    
		gtip:SetWidth(14) 
		gtip:SetHeight(14) 
		gtip:SetPoint("TOPRIGHT", -35, -7) 
	    gtip:SetScript("OnClick", function(self) 
	        GrimUI:RunSlashCmd("/gtipnotes") 
	    end) 

GrimTargetFrame:SetScript("OnEvent", function(self) 
    
	local isPlayer = UnitIsPlayer("target") 
	 
		if isPlayer and UnitIsFriend("target","player") and not UnitIsUnit("target", "player") then 
	                trade:Show() 
	                follow:Show() 
	                whisper:Show() 
	                if not UnitInParty("target") then 
	                    invite:Show() 
	                else 
	                    invite:Hide() 
	                end 
	            else 
	                trade:Hide() 
	                follow:Hide() 
	                whisper:Hide() 
	                invite:Hide() 
	            end 
	            if isPlayer then 
	                inspect:Show() 
	                else 
	                inspect:Hide() 
				end
				if(UnitExists("target")) then
					gtip:Show()
				else
					gtip:Hide()
		end
end)
--[[####################################################  
	       The Target-Buttons  END
    ####################################################]]


-------------------------
-- Clique inclusion start
-------------------------
ClickCastFrames = ClickCastFrames or {}
ClickCastFrames[GUI_TargetHealth] = true
ClickCastFrames[GUI_TargetMana] = true
-------------------------
-- Clique inclusion end
-------------------------