local addonName, addon = ...

--[[-----------------------------------------------------------------------------
Minimap
-------------------------------------------------------------------------------]]
/* Minimap:ClearAllPoints()
Minimap:SetPoint('BOTTOM', UIParent, 0, 11)
Minimap:SetHeight(132)
Minimap:SetParent(UIParent)
Minimap:SetFrameStrata('BACKGROUND')
Minimap:SetFrameLevel(1)
Minimap:SetBackdropBorderColor(nil, nil, nil, nil)
Minimap:SetMaskTexture([[Interface\BUTTONS\WHITE8X8]])
Minimap:SetScale(0.95)
Minimap:Show()

Minimap.SetHeight = addon.DoNothing
Minimap.SetWidth = addon.DoNothing
Minimap.SetParent = addon.DoNothing
Minimap.SetFrameStrata = addon.DoNothing
Minimap.SetFrameLevel = addon.DoNothing
Minimap.ClearAllPoints = addon.DoNothing
Minimap.Hide = addon.DoNothing
Minimap.SetBackdropBorderColor = addon.DoNothing
Minimap.SetMaskTexture = addon.DoNothing
Minimap.SetPoint = addon.DoNothing

addon:HideFrame(MinimapCluster)

Minimap:SetScript('OnMouseWheel', function(self, direction)
	self:SetZoom(max(min(self:GetZoom() + direction, self:GetZoomLevels()), 0))
end)
Minimap:EnableMouseWheel(true)

Minimap:SetScript('OnMouseUp', function(self, button)
	if button == 'RightButton' then
		if WorldMapFrame:IsVisible() then
			HideUIPanel(WorldMapFrame)
		else
			ShowUIPanel(WorldMapFrame)
		end
	elseif button == 'LeftButton' then
		if IsControlKeyDown() then
			ToggleDropDownMenu(1, nil, MiniMapTrackingDropDown, self)
		else
			Minimap_OnClick(Minimap)
		end
	end
end)

--[[-----------------------------------------------------------------------------
Minimap LFG Buttons
-------------------------------------------------------------------------------]]
MiniMapLFGFrame:ClearAllPoints()
MiniMapLFGFrame:SetPoint('BOTTOMLEFT', addon.skin, 'TOPLEFT', 1, 1)
MiniMapLFGFrame:SetParent(UIParent)
MiniMapLFGFrameBorder:SetAlpha(0)

MiniMapInstanceDifficulty:ClearAllPoints()
MiniMapInstanceDifficulty:SetPoint('RIGHT', UIParent, -1, -150)
MiniMapInstanceDifficulty:SetFrameStrata('HIGH')

--[[-----------------------------------------------------------------------------
Coords Frame
-------------------------------------------------------------------------------]]
local coordsFrame = CreateFrame('Frame', nil, UIParent)
coordsFrame:SetPoint('BOTTOM')
coordsFrame:SetHeight(11)
coordsFrame:SetWidth(80)

local coordsBG = coordsFrame:CreateTexture(nil, 'BACKGROUND')
coordsBG:SetTexture(0, 0, 0, 1)
coordsBG:SetAllPoints()

local coords = coordsFrame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
coords:SetPoint('CENTER', coordsFrame, 'CENTER', 0, 1)
coords:SetTextColor(1, 1, 1, 1)
coords:SetFont([[Fonts\FRIZQT__.TTF]], 10, 'NORMAL')
coords:SetJustifyH('CENTER')

local timer, oldX, oldY = 0
coordsFrame:SetScript('OnUpdate', function(self, elapsed)
	timer = timer + elapsed
	if timer < 0.1 then return end
	timer = 0
	local x, y = GetPlayerMapPosition('player')
	if x ~= oldX or y ~= oldY then
		coords:SetFormattedText("%.2f  %.2f", x * 100, y * 100)
		oldX, oldY = x, y
	end
end)

--[[-----------------------------------------------------------------------------
Watch frame set default position and improve behavior with MoveFrames
-------------------------------------------------------------------------------]]
WatchFrame:ClearAllPoints()
WatchFrame:SetPoint('TOPLEFT', UIParent, 28, 0)
addon:LockFrame(WatchFrame)

local processing
function addon:AdjustWatchFrameHeight()
	if processing then return end
	processing = true
	WatchFrame:SetHeight(min(WatchFrame:GetTop(), UIParent:GetHeight() / 2))
	processing = nil
end

local function AdjustHeight()
	addon:SafeCall("AdjustWatchFrameHeight")
end

WatchFrame:HookScript('OnMouseUp', AdjustHeight)
WatchFrameHeader:HookScript('OnMouseUp', AdjustHeight)
WatchFrame:HookScript('OnSizeChanged', AdjustHeight)

hooksecurefunc('WatchFrame_Collapse', function()
	WatchFrame:EnableMouse(false)
end)

hooksecurefunc('WatchFrame_Expand', function()
	WatchFrame:EnableMouse(true)
end)

--[[-----------------------------------------------------------------------------
WorldMapBlobFrame and combat taint on WorldMap toggle fix
-------------------------------------------------------------------------------]]
local currentTrackState

local function WorldMapFix(frame, event)
	if event == 'PLAYER_REGEN_DISABLED' then
		currentTrackState = WorldMapQuestShowObjectives:GetChecked()
		HideUIPanel(WorldMapFrame)
		WorldMap_ToggleSizeDown()
		WatchFrame.showObjectives = nil
		WorldMapQuestShowObjectives:SetChecked(false)
		addon:HideFrame(WorldMapBlobFrame)
		addon:HideFrame(WorldMapFrameSizeUpButton)
		addon:HideFrame(WorldMapPOIFrame)
		addon:HideFrame(WorldMapQuestShowObjectives)
		addon:HideFrame(WorldMapTitleButton)
		addon:HideFrame(WorldMapTrackQuest)
		WatchFrame_Update()
	elseif event == 'PLAYER_REGEN_ENABLED' then
		addon:ShowFrame(WorldMapBlobFrame)
		addon:ShowFrame(WorldMapFrameSizeUpButton)
		addon:ShowFrame(WorldMapPOIFrame)
		addon:ShowFrame(WorldMapQuestShowObjectives)
		addon:ShowFrame(WorldMapTitleButton)
		addon:ShowFrame(WorldMapTrackQuest)
		if currentTrackState then
			WatchFrame.showObjectives = true
			WorldMapQuestShowObjectives:SetChecked(true)
			WatchFrame_Update()
		else
			WatchFrame.showObjectives = nil
			WorldMapQuestShowObjectives:SetChecked(false)
		end
	else
		ShowUIPanel(WorldMapFrame)
		HideUIPanel(WorldMapFrame)
	end
end

addon.RegisterEvents("WorldMapFix", WorldMapFix, 'PLAYER_ENTERING_WORLD', 'PLAYER_REGEN_DISABLED', 'PLAYER_REGEN_ENABLED')
*/ 