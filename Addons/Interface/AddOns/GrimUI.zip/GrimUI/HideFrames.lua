local addonName, addon = ...

local frames = {
	'TargetFrame',

	'ExhaustionTick',
	'MainMenuBarLeftEndCap',
	'MainMenuBarRightEndCap',
	'MainMenuExpBar',

	'ReputationWatchBar',

	'GameTimeFrame',
	'CastingBarFrameBorder',
	'TimeManagerClockButton',
	
	'MainMenuXPBarTexture0',
	'MainMenuXPBarTexture1',
	'MainMenuXPBarTexture2',
	'MainMenuXPBarTexture3',

	'MainMenuBarTexture0',
	'MainMenuBarTexture1',
	'MainMenuBarTexture2',
	'MainMenuBarTexture3',

	'MainMenuMaxLevelBar0',
	'MainMenuMaxLevelBar1',
	'MainMenuMaxLevelBar2',
	'MainMenuMaxLevelBar3',

	'MiniMapMailBorder',
	'MiniMapMailFrame',
	'MinimapZoomIn',
	'MinimapZoomOut',
	'MinimapBackdrop',
	'MinimapZoneTextButton',
	'MinimapToggleButton',
	'MiniMapWorldMapButton',

	'SmartBuff_MiniMapButton',
	'CritlineMinimapFrame',
	'TrinketMenu_IconFrame',
	'ItemRackMiniMapFrame',
	'MI3_MinimapButton',
	'FishingBuddyMinimapFrame',
	'AltoholicMinimapButton',
	'MacaroonMinimapButton',
	'Gatherer_MinimapOptionsButton',
	'DBMMinimapButton',
	'LibDBIcon10_EasyDND',
	'LibDBIcon10_sRaidFrames',
	'WIM3MinimapButton',
	'LibDBIcon10_oRA2',
	'LibDBIcon10_AutoBar',
	'LibDBIcon10_Broker_Auditor',
--	'LibDBIcon10_BugSack',
	'DHUDMinimapButton',
}

addon.RegisterEvent("HideFrames-Monitor", 'ADDON_LOADED', function(self, event)
	for _, name in pairs(frames) do
		local frame = _G[name]
		if frame then
			addon:HideFrame(frame)
			frames[name] = nil
		end
	end
	if next(frames) then return end
	addon.UnregisterEvent(self, event)
end)
