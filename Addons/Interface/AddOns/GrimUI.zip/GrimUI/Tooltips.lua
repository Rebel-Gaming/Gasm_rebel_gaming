local addonName, addon = ...

addon:RegisterDefaultSetting("tooltipIconSize", 20)

--[[-----------------------------------------------------------------------------
Reskin and anchor tooltips
-------------------------------------------------------------------------------]]
GUITTAnchor = CreateFrame('Frame', nil, UIParent, 'SecureHandlerStateTemplate')
GUITTAnchor:SetPoint('LEFT', UIParent, 'LEFT', 35, -130)

local function SkinTooltip(tooltip)
	tooltip:SetBackdrop{
		bgFile = [[Interface\AddOns\]] .. addonName .. [[\Media\MainBG]],
		edgeFile = [[Interface\AddOns\]] .. addonName .. [[\Media\HordeBorder]], edgeSize = 15,
	}
	tooltip:SetBackdropColor(0.09, 0.09, 0.19, 1)
end
hooksecurefunc('GameTooltip_OnLoad', SkinTooltip)

for _, tooltip in ipairs({ GameTooltip, ItemRefTooltip, ShoppingTooltip1, ShoppingTooltip2, ShoppingTooltip3, WorldMapTooltip }) do
	SkinTooltip(tooltip)
end

hooksecurefunc('GameTooltip_SetDefaultAnchor', function (tooltip, parent)
	tooltip:SetOwner(parent, 'ANCHOR_NONE')
	tooltip:ClearAllPoints()
	tooltip:SetPoint('BOTTOMLEFT', GUITTAnchor)
end)


--[[-----------------------------------------------------------------------------
Add icons to tooltips
-------------------------------------------------------------------------------]] 
local function AddIcon(self, icon)
	if icon then
		local title = _G[self:GetName() .. 'TextLeft1']
		local text = title:GetText()
		if text and not text:find('|T' .. icon) then
			title:SetFormattedText("|T%s:%s|t %s", icon, addon.settings.tooltipIconSize, text)
		end
	end
end

local function OnTooltipSetItem(self)
	local _, link = self:GetItem()
	if link then
		AddIcon(self, GetItemIcon(link))
	end
end
_G['GameTooltip']:HookScript('OnTooltipSetItem', OnTooltipSetItem)
_G['ItemRefTooltip']:HookScript('OnTooltipSetItem', OnTooltipSetItem)

local function OnTooltipSetSpell(self)
	local _, _, icon = GetSpellInfo(self:GetSpell())
	AddIcon(self, icon)
end
_G['GameTooltip']:HookScript('OnTooltipSetSpell', OnTooltipSetSpell)
_G['ItemRefTooltip']:HookScript('OnTooltipSetSpell', OnTooltipSetSpell)
