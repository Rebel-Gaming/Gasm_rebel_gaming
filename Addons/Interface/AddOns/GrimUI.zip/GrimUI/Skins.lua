local addonName, addon = ...

--[[-----------------------------------------------------------------------------
Skin frame and textures for each portion
-------------------------------------------------------------------------------]]
local skin = CreateFrame('Frame', nil, UIParent)
skin:SetFrameStrata('BACKGROUND')
skin:SetFrameLevel(1)
skin:SetPoint('BOTTOMLEFT')
skin:SetPoint('BOTTOMRIGHT')
skin:SetHeight(238)
addon.skin = skin

skin[1] = skin:CreateTexture(nil, 'BACKGROUND')												-- Left
skin[1]:SetPoint('TOPLEFT')
skin[1]:SetPoint('BOTTOMLEFT', -1, 0)
skin[1]:SetWidth(468)
_G["GrimUIcoreArtB1"] = skin[1]

skin[2] = skin:CreateTexture(nil, 'BACKGROUND')												-- Mid-left
skin[2]:SetPoint('TOPLEFT', skin[1], 'TOPRIGHT')
skin[2]:SetPoint('BOTTOMLEFT', skin[1], 'BOTTOMRIGHT')
skin[2]:SetPoint('RIGHT', UIParent, 'CENTER')
_G["GrimUIcoreArtB2"] = skin[2]

skin[3] = skin:CreateTexture(nil, 'OVERLAY')													-- Minimap
skin[3]:SetWidth(158)
skin[3]:SetHeight(127)
skin[3]:SetPoint('CENTER', Minimap)
_G["GrimUIcoreArtMM"] = skin[5]

skin[4] = skin:CreateTexture(nil, 'BACKGROUND')													-- Target
skin[4]:SetWidth(248)
skin[4]:SetHeight(251)
skin[4]:SetParent("GrimUITargetFrame")
skin[4]:SetPoint('BOTTOM', GrimUITargetFrame, 'BOTTOM', 0, 4)
_G["GrimUItargetArt"] = skin[6]

skin[-1] = skin:CreateTexture(nil, 'BACKGROUND')											-- Right
skin[-1]:SetPoint('TOPRIGHT')
skin[-1]:SetPoint('BOTTOMRIGHT')
skin[-1]:SetWidth(472)
skin[-1]:SetTexCoord(1, 0, 0, 1)
_G["GrimUIcoreArtB4"] = skin[-1]

skin[-2] = skin:CreateTexture(nil, 'BACKGROUND')											-- Mid-right
skin[-2]:SetPoint('TOPRIGHT', skin[-1], 'TOPLEFT')
skin[-2]:SetPoint('BOTTOMRIGHT', skin[-1], 'BOTTOMLEFT')
skin[-2]:SetPoint('LEFT', UIParent, 'CENTER')
skin[-2]:SetTexCoord(1, 0, 0, 1)
_G["GrimUIcoreArtB3"] = skin[-2]

--[[-----------------------------------------------------------------------------
UpdateSkin - Call this when the uiSkin setting changes
-------------------------------------------------------------------------------]]
function addon:ConfigureSkin()
	local path = addon.settings.uiSkin .. "-"
	for i = 1, #skin do
		skin[i]:SetTexture(path .. i)
		if skin[-i] then
			skin[-i]:SetTexture(path .. i)
		end
	end
end

--[[-----------------------------------------------------------------------------
Initialize
-------------------------------------------------------------------------------]]
addon.RegisterEvent("InitializeSkins", 'PLAYER_ENTERING_WORLD', function(self, event)
	addon.UnregisterEvent(self, event)

	addon:RegisterDefaultSetting("uiSkin", [[Interface\AddOns\]] .. addonName .. [[\Skins\]] .. UnitFactionGroup('player'))
	addon:ConfigureSkin()
end)

--[[-----------------------------------------------------------------------------
Combat Indicator
-------------------------------------------------------------------------------]]
local function CreateAggroTexture(...)
	local texture = skin:CreateTexture(nil, 'BORDER')
	texture:SetTexture([[Interface\AddOns\]] .. addonName .. [[\Skins\Aggro]])
	texture:SetPoint(...)
	texture:SetHeight(250)
	texture:SetWidth(340)
	texture:Hide()
	return texture
end

local aggroL = CreateAggroTexture('BOTTOMLEFT', skin[1])
local aggroR = CreateAggroTexture('BOTTOMRIGHT', skin[-1])
aggroR:SetTexCoord(1, 0, 0, 1)

skin:SetScript('OnEvent', function(self, event)
	if event == 'PLAYER_REGEN_ENABLED' then
		aggroL:Hide()
		aggroR:Hide()
	else
		aggroL:Show()
		aggroR:Show()
	end
end)
skin:RegisterEvent('PLAYER_REGEN_ENABLED')
skin:RegisterEvent('PLAYER_REGEN_DISABLED')

--[[-----------------------------------------------------------------------------
WorldFrame / Viewport
-------------------------------------------------------------------------------]]
WorldFrame:ClearAllPoints()
WorldFrame:SetPoint('TOPLEFT')
WorldFrame:SetPoint('RIGHT')
WorldFrame:SetPoint('BOTTOM', Minimap, 'TOP')
