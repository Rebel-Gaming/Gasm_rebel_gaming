local addonName, addon = ...

addon:RegisterDefaultSetting("hideBlizPartyFrames", true)
addon:RegisterDefaultSetting("showPartyFrames", true)

--[[-----------------------------------------------------------------------------
Header
-------------------------------------------------------------------------------]]
local partyHeader = CreateFrame('Frame', nil, UIParent, 'SecureHandlerStateTemplate')

partyHeader:SetAttribute('_onstate-group', [[
	self[newstate](self, true)
]])
 
--[[-----------------------------------------------------------------------------
Party Frames
-------------------------------------------------------------------------------]]
local function showPartyMenu(self)
	ToggleDropDownMenu(1, nil, _G['PartyMemberFrame' .. self.id .. 'DropDown'], "cursor", 0, 0)
end

local function showPartyTargetMenu(self)
	ToggleDropDownMenu(1, nil, TargetFrameDropDown, "cursor", 0, 0)
end
 
local function CreateUnitButton(name, parent, unit, menufunc)
	local frame = CreateFrame('Button', name, parent, 'SecureUnitButtonTemplate')
	SecureUnitButton_OnLoad(frame, unit, menufunc)
	frame:RegisterForClicks('AnyUp')
	frame:SetScript('OnEnter', UnitFrame_OnEnter)
	frame:SetScript('OnLeave', UnitFrame_OnLeave)

	partyHeader:WrapScript(frame, 'OnAttributeChanged', [[
		if name ~= 'state-exists' then return end
		self[value](self, true)
	]])
	RegisterStateDriver(frame, 'exists', ("[@%s, exists] Show; Hide"):format(unit))

	frame.unit = unit
	return frame
end
 
for id = 1, 4 do
	local unit = 'party' .. id
	local frame = CreateUnitButton(addonName .. "PartyFrame" .. id, partyHeader, unit, showPartyMenu)
	frame.id = id

	-- Pedestal Frame
	frame.PedestalFrame = CreateFrame('Frame', nil, frame)

	-- Health Bar
	frame.HealthBorder = CreateFrame('Button', nil, frame)
	frame.HealthBar = CreateFrame('StatusBar', nil, frame)
	frame.HealthNumTxtFrame = CreateFrame('Frame', nil, frame)

	-- Mana Bar
	frame.ManaBorder = CreateFrame('Button', nil, frame)
	frame.ManaBar = CreateFrame('StatusBar', nil, frame)
	frame.ManaNumTxtFrame = CreateFrame('Frame', nil, frame)

	-- Misc Frames
	frame.InfoTextFrame = CreateFrame('Button', nil, frame)
	frame.LetterFrame = CreateFrame('Frame', nil, frame)
	frame.LeaderFrame = CreateFrame('Frame', nil, frame)
	frame.pvpIconFrame = CreateFrame('Frame', nil, frame)
	frame.offDeadGhostTxtFrame = CreateFrame('Frame', nil, frame)

	-- Target Bar
	frame.targetOfFrame = CreateUnitButton(frame:GetName() .. "TargetFrame", frame, unit .. 'target', showPartyTargetMenu)
	frame.targetOfFrame.unitOf = unit

	-- texture creation
	frame.PedestalFrame.texture = frame.PedestalFrame:CreateTexture()
	frame.LeaderFrame.texture = frame.LeaderFrame:CreateTexture()
	frame.pvpIconFrame.texture = frame.pvpIconFrame:CreateTexture()
	frame.targetOfFrame.texture = frame:CreateTexture(nil, 'BACKGROUND')

	-- texture SetAllPoints that remain the same for both party styles
	frame.PedestalFrame.texture:SetAllPoints()
	frame.targetOfFrame.texture:SetAllPoints(frame.targetOfFrame)
	frame.LeaderFrame.texture:SetAllPoints()
	frame.pvpIconFrame.texture:SetAllPoints()

	-- font creation
	frame.HealthBorder.percentHText = frame.HealthBorder:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.ManaBorder.percentMText = frame.ManaBorder:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.InfoTextFrame.NameText = frame.InfoTextFrame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.LetterFrame.LetterHText = frame.LetterFrame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.LetterFrame.LetterMText = frame.LetterFrame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.HealthNumTxtFrame.chnumtxt = frame.HealthNumTxtFrame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.HealthNumTxtFrame.mhnumtxt = frame.HealthNumTxtFrame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.ManaNumTxtFrame.CMNumTxt = frame.ManaNumTxtFrame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.ManaNumTxtFrame.MMNumTxt = frame.ManaNumTxtFrame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.InfoTextFrame.LvlClassText = frame.InfoTextFrame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.DeadOfflineTxt = frame.offDeadGhostTxtFrame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
	frame.targetOfFrame.text = frame:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
end

--[[-----------------------------------------------------------------------------
ResetPartyFrames
-------------------------------------------------------------------------------]]
function addon:ResetPartyFrames()
	for id = 1, 4 do
		_G[addonName .. "PartyFrame" .. id]:ClearAllPoints()
	end
	_G[addonName .. "PartyFrame1"]:SetPoint('BOTTOMRIGHT', addonName .. "PartyFrame2", 'BOTTOMLEFT')
	_G[addonName .. "PartyFrame2"]:SetPoint('BOTTOMRIGHT', addonName .. "TargetFrame", 'BOTTOMLEFT', -8, 10)
	_G[addonName .. "PartyFrame3"]:SetPoint('BOTTOMLEFT', addonName .. "TargetFrame", 'BOTTOMRIGHT', 8, 10)
	_G[addonName .. "PartyFrame4"]:SetPoint('BOTTOMLEFT', addonName .. "PartyFrame3", 'BOTTOMRIGHT')
end
addon:ResetPartyFrames()

--[[-----------------------------------------------------------------------------
Event Handlers
-------------------------------------------------------------------------------]]
local match = string.match

local function UpdateDeadOffline(self, event, unit)
	if match(event, '^UNIT_') then
		if self.unit ~= unit then return end
	else
		unit = self.unit
	end
	if not UnitIsConnected(unit) then
		if UnitIsGhost(unit) then
			self.DeadOfflineTxt:SetText("Ghost\n Offline")
		elseif UnitIsDead(unit) then
			self.DeadOfflineTxt:SetText("Dead\n Offline")
		else
			self.DeadOfflineTxt:SetText("Offline")
		end
	elseif UnitIsGhost(unit) then
		self.DeadOfflineTxt:SetText("Ghost")
	elseif UnitIsDead(unit) then
		self.DeadOfflineTxt:SetText("Dead")
	else
		self.DeadOfflineTxt:SetText("")
	end
end

local function UpdateHealth(self, event, unit)
	if match(event, '^UNIT_') then
		if self.unit ~= unit then return end
	else
		unit = self.unit
	end
	local curHealth, maxHealth = UnitHealth(unit), UnitHealthMax(unit)
	if curHealth and maxHealth and UnitIsConnected(unit) then
		self.HealthBorder.percentHText:SetFormattedText("%s%%", floor(curHealth / maxHealth * 100))
		self.HealthBar:SetMinMaxValues(min(0, curHealth), maxHealth)
		self.HealthBar:SetValue(curHealth) 
		if addon.settings.stylePartyFrames == 2 then 
			self.HealthNumTxtFrame.chnumtxt:SetFormattedText("%s/%s", curHealth, maxHealth)
		else
			self.HealthNumTxtFrame.chnumtxt:SetText(curHealth) 
			self.HealthNumTxtFrame.mhnumtxt:SetText(maxHealth)
		end
	else
		self.HealthBorder.percentHText:SetText("0%")
	end
end

local function UpdateLeader(self)
	if UnitIsPartyLeader(self.unit) then
		self.LeaderFrame:Show()
	else
		self.LeaderFrame:Hide()
	end
end

local function UpdateLevelClass(self, event, unit)
	local class = UnitClass(self.unit)
	if class then
		self.InfoTextFrame.LvlClassText:SetFormattedText("%s %s", UnitLevel(self.unit), class)
	else
		self.InfoTextFrame.LvlClassText:SetText("")
	end
end

local function UpdateName(self, event, unit)
	if match(event, '^UNIT_') then
		if self.unit ~= unit then return end
	else
		unit = self.unit
	end
	local name = UnitName(unit)
	if name then
		self = self.InfoTextFrame.NameText
		self:SetText(name)
		if UnitThreatSituation(unit) or UnitAffectingCombat(unit) then
			self:SetTextColor(1, 0, 0, 1)
		else
			self:SetTextColor(1, 1, 1, 1)
		end
	end
end

local function UpdatePower(self, event, unit)
	if match(event, '^UNIT_') then
		if self.unit ~= unit then return end
	else
		unit = self.unit
	end
	local powerType, curPower, maxPower = UnitPowerType(unit)
	if powerType == 0 then
		curPower, maxPower = UnitMana(unit), UnitManaMax(unit)
		self.ManaBar:SetStatusBarColor(0.556, 0.556, 0.921, 1)
	elseif powerType == 1 or powerType == 3 or powerType == 6 then
		curPower, maxPower = UnitPower(unit), UnitPowerMax(unit)
		self.ManaBar:SetStatusBarColor(0.656, 0.456, 0.456, 1)
	else
		return
	end

	self.ManaBar:SetMinMaxValues(min(0, curPower), maxPower)
	self.ManaBar:SetValue(curPower)
	if maxPower > 0 then
		self.ManaBorder.percentMText:SetFormattedText("%s%%", floor(curPower / maxPower * 100))
	else
		self.ManaBorder.percentMText:SetText("0%")
	end

	if addon.settings.stylePartyFrames == 2 then 
		self.ManaNumTxtFrame.CMNumTxt:SetFormattedText("%s/%s", curPower, maxPower) 
	else
		self.ManaNumTxtFrame.CMNumTxt:SetText(curPower)
		self.ManaNumTxtFrame.MMNumTxt:SetText(maxPower)
	end
end

local function UpdatePvp(self, event, unit)
	if match(event, '^UNIT_') and self.unit ~= unit then return end
	if UnitIsPVP(self.unit) then
		self.pvpIconFrame:Show()
	else
		self.pvpIconFrame:Hide()
	end
end

local function UpdateTarget(self, event, unit)
	if match(event, '^UNIT_') and self.unitOf ~= unit then return end
	unit = self.unit
	if UnitIsUnit(unit, 'player') then
		self.text:SetText("** YOU **")
	elseif UnitIsUnit(unit, 'target') then
		self.text:SetText("** YOUR TARGET **")
	else
		self.text:SetText(UnitName(unit))
	end
	if UnitIsFriend(unit, 'player') then
		self.texture:SetTexture(0.10, 0.40, 0.10, 1)
	else
		self.texture:SetTexture(0.40, 0.10, 0.10, 1)
	end
end

local function UpdateUnit(self, event, unit)
	if match(event, '^UNIT_') then
		if self.unit ~= unit then return end
	else
		unit = self.unit
	end
	if event == 'UNIT_AURA' then
		UpdateHealth(self, "", unit)
		UpdatePower(self, "", unit)
	elseif event == 'UNIT_HEALTH' then
		UpdateDeadOffline(self, "", unit)
		UpdateHealth(self, "", unit)
	elseif event == 'UNIT_LEVEL' then
		UpdateHealth(self, "", unit)
		UpdateLevelClass(self, "", unit)
		UpdatePower(self, "", unit)
	else
		UpdateDeadOffline(self, "", unit)
		UpdateHealth(self, "", unit)
		UpdateLeader(self, "", unit)
		UpdateLevelClass(self, "", unit)
		UpdateName(self, "", unit)
		UpdatePower(self, "", unit)
		UpdatePvp(self, "", unit)
	end
end

--[[-----------------------------------------------------------------------------
Register/Unregister events on Show/Hide
-------------------------------------------------------------------------------]]
local function OnShow(self)
	local register = addon.RegisterEvents
	register(self, UpdateDeadOffline, 'PARTY_MEMBER_DISABLE', 'PARTY_MEMBER_ENABLE')
	register(self, UpdateLeader, 'PARTY_LEADER_CHANGED', 'ZONE_CHANGED_NEW_AREA')
	register(self, UpdateName, 'UNIT_COMBAT', 'UNIT_FLAGS', 'UNIT_NAME_UPDATE', 'UNIT_THREAT_LIST_UPDATE', 'UNIT_THREAT_SITUATION_UPDATE')
	register(self, UpdatePower, 'UNIT_DISPLAYPOWER', 'UNIT_ENERGY', 'UNIT_MANA', 'UNIT_MAXENERGY', 'UNIT_MAXMANA', 'UNIT_MAXRUNICPOWER', 'UNIT_RAGE', 'UNIT_RUNIC_POWER')
	register(self, UpdatePvp, 'UNIT_DYNAMIC_FLAGS', 'UNIT_FACTION')
	register(self, UpdateUnit, 'PLAYER_ENTERING_WORLD', 'PARTY_MEMBERS_CHANGED', 'UNIT_AURA', 'UNIT_HEALTH', 'UNIT_LEVEL')
	addon.RegisterEvent(self, 'UNIT_MAXHEALTH', UpdateHealth)
	UpdateUnit(self, "")
end

local function OnHideTarget(self)
	addon.UnregisterAllEvents(self)
	self.text:SetText("-No Target-")
	self.texture:SetTexture(0, 0, 0, 1)
end

local function OnShowTarget(self)
	addon.RegisterEvents(self, UpdateTarget, 'PLAYER_ENTERING_WORLD', 'PARTY_MEMBERS_CHANGED', 'UNIT_TARGET')
	UpdateTarget(self, "")
end

for id = 1, 4 do
	local frame = _G[addonName .. "PartyFrame" .. id]
	frame:SetScript('OnHide', addon.UnregisterAllEvents)
	frame:SetScript('OnShow', OnShow)
	frame.targetOfFrame:SetScript('OnHide', OnHideTarget)
	frame.targetOfFrame:SetScript('OnShow', OnShowTarget)
	OnHideTarget(frame.targetOfFrame)
end

--[[-----------------------------------------------------------------------------
ConfigureBlizPartyFrames
-------------------------------------------------------------------------------]]
function addon:ConfigureBlizPartyFrames()
	if addon.settings.hideBlizPartyFrames then
		for id = 1, MAX_PARTY_MEMBERS do
			local frame = _G['PartyMemberFrame' .. id]
			frame:UnregisterAllEvents()
			addon:HideFrame(frame)
		end
	else
		for id = 1, MAX_PARTY_MEMBERS do
			local frame = _G['PartyMemberFrame' .. id]
			frame:RegisterEvent('IGNORELIST_UPDATE')
			frame:RegisterEvent('MUTELIST_UPDATE')
			frame:RegisterEvent('PARTY_LEADER_CHANGED')
			frame:RegisterEvent('PARTY_LOOT_METHOD_CHANGED')
			frame:RegisterEvent('PARTY_MEMBER_DISABLE')
			frame:RegisterEvent('PARTY_MEMBER_ENABLE')
			frame:RegisterEvent('PARTY_MEMBERS_CHANGED')
			frame:RegisterEvent('READY_CHECK')
			frame:RegisterEvent('READY_CHECK_CONFIRM')
			frame:RegisterEvent('READY_CHECK_FINISHED')
			frame:RegisterEvent('UNIT_AURA')
			frame:RegisterEvent('UNIT_DISPLAYPOWER')
			frame:RegisterEvent('UNIT_ENTERED_VEHICLE')
			frame:RegisterEvent('UNIT_EXITED_VEHICLE')
			frame:RegisterEvent('UNIT_NAME_UPDATE')
			frame:RegisterEvent('UNIT_PET')
			frame:RegisterEvent('UNIT_PORTRAIT_UPDATE')
			frame:RegisterEvent('UNIT_PVP_UPDATE')
			frame:RegisterEvent('VARIABLES_LOADED')
			frame:RegisterEvent('VOICE_START')
			frame:RegisterEvent('VOICE_STATUS_UPDATE')
			frame:RegisterEvent('VOICE_STOP')
			frame.Show = nil
			if UnitExists('party' .. id) then
				frame:Show()
				UnitFrame_OnEvent(frame, 'PARTY_MEMBERS_CHANGED')
			end
		end
	end
end

--[[-----------------------------------------------------------------------------
ConfigurePartyFrames
-------------------------------------------------------------------------------]]
function addon:ConfigurePartyFrames()
	if addon.settings.showPartyFrames then
		local _, instanceType = IsInInstance()
		if not GetCVarBool('hidePartyInRaid') or instanceType == 'arena' then
			RegisterStateDriver(partyHeader, 'group', "[group] Show; Hide")
		else
			RegisterStateDriver(partyHeader, 'group', "[group:raid] Hide; [group:party] Show; Hide")
		end
	else
		RegisterStateDriver(partyHeader, 'group', "Hide")
	end
end

--[[-----------------------------------------------------------------------------
Initialize
-------------------------------------------------------------------------------]]
addon.RegisterEvent("PartyFrames-Initialize", 'PLAYER_ENTERING_WORLD', function(self, event)
	addon.UnregisterEvent(self, event)

	local pvpTexture = [[Interface\GroupFrame\]UI-Group-PVP-]] .. UnitFactionGroup('player')
	for id = 1, 4 do
		_G[addonName .. "PartyFrame" .. id].pvpIconFrame.texture:SetTexture(pvpTexture)
	end

	addon:ConfigureBlizPartyFrames()
	addon:ConfigurePartyFrames()
	addon:StylePartyFrames()
end)

--[[-----------------------------------------------------------------------------
Monitor for cvar changes and arena matches
-------------------------------------------------------------------------------]]
local function monitorCVar(self, event, cvar, value)
	if event == 'CVAR_UPDATE' and cvar ~= 'hidePartyInRaid' then return end
	addon:SafeCall("ConfigurePartyFrames")
end
addon.RegisterEvents("PartyFrames-MonitorCVar", monitorCVar, 'CVAR_UPDATE', 'PLAYER_ENTERING_WORLD')

--[[-----------------------------------------------------------------------------
Clique support
-------------------------------------------------------------------------------]]
--ClickCastFrames = ClickCastFrames or {}
--ClickCastFrames[healthborder] = true
--ClickCastFrames[GrimPlayerManaborder] = true
--ClickCastFrames[playerModelClickFrame] = true
