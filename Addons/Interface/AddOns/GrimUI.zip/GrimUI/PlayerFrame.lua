local addonName, addon = ...

addon:RegisterDefaultSetting("hideBlizPlayerFrame", true)
addon:RegisterDefaultSetting("showPlayerFrame", true)
addon:RegisterDefaultSetting("playerFrameScale", 1)

local GrimPlayerFrame = CreateFrame('Frame', addonName .. "PlayerFrame", UIParent)


--[[-----------------------------------------------------------------------------
ConfigureBlizPlayerFrame
-------------------------------------------------------------------------------]]
function addon:ConfigureBlizPlayerFrame()
	if addon.settings.hideBlizPlayerFrame then
		addon:HideFrame('PlayerFrame')
	else
		addon:ShowFrame('PlayerFrame')
	end
end

--[[-----------------------------------------------------------------------------
ConfigurePlayerFrame
-------------------------------------------------------------------------------]]
function addon:ConfigurePlayerFrame()
	if addon.settings.showPlayerFrame then
		addon:ShowFrame(addonName .. "PlayerFrame")
	else
		addon:HideFrame(addonName .. "PlayerFrame")
	end
end

--[[-----------------------------------------------------------------------------
ResetPlayerFrame
-------------------------------------------------------------------------------]]
function addon:ResetPlayerFrame()
	_G[addonName .. "PlayerFrame"]:ClearAllPoints()
	_G[addonName .. "PlayerFrame"]:SetPoint('BOTTOMLEFT', 'UIParent', -10, 245)
end
addon:ResetPlayerFrame()

function addon:PlayerFrameSetScale()
    GrimPlayerFrame:SetScale(addon.settings.playerFrameScale)
end

--[[-----------------------------------------------------------------------------
Initialize
-------------------------------------------------------------------------------]]
addon.RegisterEvent("PlayerFrame-Initialize", 'PLAYER_ENTERING_WORLD', function(self, event)
	addon.UnregisterEvent(self, event)

	addon:ConfigureBlizPlayerFrame()
	addon:ConfigurePlayerFrame()
    addon:PlayerFrameSetScale()
end)



-- Main Frame Start

GrimPlayerFrame:SetWidth(272)
GrimPlayerFrame:SetHeight(180)
GrimPlayerFrame:SetFrameStrata("BACKGROUND")
GrimPlayerFrame:SetFrameLevel("1")


-- Main Frame End

-- pedistal
local pedestalFrame = CreateFrame('Frame', "pedestalFrame", GrimPlayerFrame)
pedestalFrame:SetPoint("BOTTOMLEFT", GrimPlayerFrame, "BOTTOMLEFT", 24, 49)
pedestalFrame:SetHeight(20)
pedestalFrame:SetWidth(72)
pedestalFrame.texture = pedestalFrame:CreateTexture()
pedestalFrame.texture:SetAllPoints(pedestalFrame)
pedestalFrame.texture:SetTexture([[Interface\AddOns\]] .. addonName .. [[\Media\Pedestal]])
pedestalFrame:SetFrameStrata("LOW")
pedestalFrame:SetFrameLevel("2")


-- 3D model click frame


local GUI_Player3DModel = CreateFrame('Button', "GUI_Player3DModel", GrimPlayerFrame, "SecureUnitButtonTemplate")
GUI_Player3DModel:SetPoint("BOTTOMLEFT", GrimPlayerFrame, "BOTTOMLEFT", 15, 49)
GUI_Player3DModel:SetHeight(130)
GUI_Player3DModel:SetWidth(81)
GUI_Player3DModel:SetFrameStrata("HIGH")
GUI_Player3DModel:SetFrameLevel("4")

GUI_Player3DModel:RegisterForClicks("AnyUp")
GUI_Player3DModel:SetAttribute("unit", "player")
GUI_Player3DModel:SetAttribute("*type1", "target")

local showmenu = function() 
	playerInVehicle = UnitInVehicle("player")
    if playerInVehicle == nil then
    ToggleDropDownMenu(1, nil, PlayerFrameDropDown, "cursor", 0, 0) 
    
    elseif playerInVehicle == 1 then
    ToggleDropDownMenu(1, nil, PetFrameDropDown, "cursor", 0, 0)
    end 
end
GUI_Player3DModel.showmenu = showmenu
GUI_Player3DModel.unit = "player"
GUI_Player3DModel:SetAttribute("*type2", "showmenu")
GUI_Player3DModel:SetScript("OnEnter", UnitFrame_OnEnter)
GUI_Player3DModel:SetScript("OnLeave", UnitFrame_OnLeave)


--[[ 3D model frame

local playerModelFrame = CreateFrame('PlayerModel', "playerModelFrame", UIParent)
playerModelFrame:RegisterEvent("VARIABLES_LOADED")
playerModelFrame:RegisterEvent("UNIT_MODEL_CHANGED", "player")
playerModelFrame:RegisterEvent("PLAYER_LEAVE_COMBAT")
playerModelFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
playerModelFrame:RegisterEvent("LOOT_OPEN")
playerModelFrame:RegisterEvent("LOOT_CLOSED")
playerModelFrame:SetHeight(220)
playerModelFrame:SetWidth(200)
playerModelFrame:SetPoint("BOTTOM", pedestalFrame, "BOTTOM", 0, 0)
playerModelFrame:SetFrameStrata("HIGH")
playerModelFrame:SetFrameLevel("5")
playerModelFrame:SetUnit("player")
playerModelFrame:SetCamera(2)

--local function OnUpdate ( self )
    
  --  playerModelFrame:SetScript( "OnUpdateModel", nil );
    --end

--local function OnUpdateModel ( self )
  --              -- Mesh is loaded; Wait one more frame
    --        playerModelFrame:SetScript( "OnUpdate", OnUpdate );
--end


playerModelFrame:SetScript("OnUpdate", function(self)
    
    playerModelFrame:SetModelScale( .7 );
    playerModelFrame:SetPosition( 0, 0, 0 );
    playerModelFrame:SetFacing( 0 );
end)




playerModelFrame:SetScript("OnEvent", function(self)
    playerModelFrame:RefreshUnit()
    playerModelFrame:SetModelScale( .7 );
    
end)
GrimUI.playerModelFrame = playerModelFrame
 

      
      --function me.Model:Reset ( KeepFacing )
         --       self:ClearModel();
           --    self:SetModelScale( 1 );
             --  self:SetPosition( 0, 0, 0 );
               -- if ( not KeepFacing ) then
                 --       self:SetFacing( 0 );
               --end

                -- Wait a frame after model changes, or else the current model scale will
                --   display as 100% with later calls scaling relative to it.
                --self:SetScript( "OnUpdate", nil );
                --self:SetScript( "OnUpdateModel", OnUpdateModel );
        --end



local pmfbg = playerModelFrame:CreateTexture(nil, "BACKGROUND")
pmfbg:SetTexture(0, 0, 0, .7)
pmfbg:SetAllPoints(playerModelFrame)


-- 3D model frame end]]




-- health bar start
local PlayerHealthEvents = CreateFrame("Frame", nil, UIParent)
PlayerHealthEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
PlayerHealthEvents:RegisterEvent("UNIT_HEALTH")
PlayerHealthEvents:RegisterEvent("PLAYER_LEVEL_UP")
PlayerHealthEvents:RegisterEvent("UNIT_AURA", "Player")
PlayerHealthEvents:RegisterEvent("UNIT_MAXHEALTH")





local GUI_PlayerHealth = CreateFrame('Button', "GUI_PlayerHealth", GrimPlayerFrame, "SecureActionButtonTemplate")
GUI_PlayerHealth:SetHeight(25)
GUI_PlayerHealth:SetWidth(175)
GUI_PlayerHealth:SetPoint("TOPRIGHT", GrimPlayerFrame, "TOPRIGHT", 0, -80)
GUI_PlayerHealth:SetFrameStrata("HIGH")
GUI_PlayerHealth:SetFrameLevel("4")

GUI_PlayerHealth:RegisterForClicks("AnyUp")
GUI_PlayerHealth:SetAttribute("unit", "player")
GUI_PlayerHealth:SetAttribute("*type1", "target")

local showmenu = function() 
	playerInVehicle = UnitInVehicle("player")
    if playerInVehicle == nil then
    ToggleDropDownMenu(1, nil, PlayerFrameDropDown, "cursor", 0, 0) 
    
    elseif playerInVehicle == 1 then
    ToggleDropDownMenu(1, nil, PetFrameDropDown, "cursor", 0, 0)
    end 
end
GUI_PlayerHealth.showmenu = showmenu
GUI_PlayerHealth.unit = "player"
GUI_PlayerHealth:SetAttribute("*type2", "showmenu")
GUI_PlayerHealth:SetScript("OnEnter", UnitFrame_OnEnter)
GUI_PlayerHealth:SetScript("OnLeave", UnitFrame_OnLeave)

local healthBar = CreateFrame("StatusBar", nil, GrimPlayerFrame, "TextStatusBar")
healthBar:SetWidth(175)
healthBar:SetHeight(25)
healthBar:SetPoint("CENTER", GUI_PlayerHealth, "CENTER", 0, 0)
healthBar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\BarTexture]])
healthBar:SetStatusBarColor(.231, .682, .419, 1)
healthBar:SetFrameLevel("3")



local healthText = healthBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
healthText:SetPoint("RIGHT", GUI_PlayerHealth, "RIGHT", -5, -1)
healthText:SetTextColor(1, 1, 1, 1)
healthText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 16, "OUTLINE")


local takenDMGbar = CreateFrame("StatusBar", nil, GrimPlayerFrame, "TextStatusBar")
takenDMGbar:SetWidth(175)
takenDMGbar:SetHeight(25)
takenDMGbar:SetPoint("CENTER", GUI_PlayerHealth, "CENTER", 0, 0)
takenDMGbar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\BarTexture]])
takenDMGbar:SetStatusBarColor(.721, .047, .890, 1)
takenDMGbar:SetFrameLevel("2")


PlayerHealthEvents:SetScript("OnEvent", function(self) 
    local currHealth, maxHealth = UnitHealth("Player"), UnitHealthMax("Player") 
    
    local str = ("%s/%s"):format(currHealth, maxHealth)
        
    healthText:SetText(str) 
    healthBar:SetMinMaxValues(min(0, currHealth), maxHealth) 
    healthBar:SetValue(currHealth) 

    takenDMGbar:SetMinMaxValues(min(0, currHealth), maxHealth) 
    takenDMGbar:SetValue(currHealth) 
end)
-- health bar end

-- Mana Bar Start
local manaBarEventFrame = CreateFrame("Frame", "manaBarEventFrame", UIParent)
manaBarEventFrame:RegisterEvent('PLAYER_ENTERING_WORLD')
manaBarEventFrame:RegisterEvent('UNIT_HEALTH')
manaBarEventFrame:RegisterEvent('PLAYER_LEVEL_UP')
manaBarEventFrame:RegisterEvent('UNIT_MANA')
manaBarEventFrame:RegisterEvent('UNIT_AURA')
manaBarEventFrame:RegisterEvent('UNIT_DISPLAYPOWER')
manaBarEventFrame:RegisterEvent('UNIT_ENERGY')
manaBarEventFrame:RegisterEvent('UNIT_MAXENERGY')
manaBarEventFrame:RegisterEvent('UNIT_MAXMANA')
manaBarEventFrame:RegisterEvent('UNIT_MAXRUNICPOWER')
manaBarEventFrame:RegisterEvent('UNIT_RUNIC_POWER')
manaBarEventFrame:RegisterEvent('UNIT_RAGE')
manaBarEventFrame:RegisterEvent('UPDATE_SHAPESHIFT_FORM')

local GUI_PlayerMana = CreateFrame('Button', "GUI_PlayerMana", GrimPlayerFrame, "SecureActionButtonTemplate")
GUI_PlayerMana:SetHeight(25)
GUI_PlayerMana:SetWidth(175)
GUI_PlayerMana:SetPoint("TOPRIGHT", GUI_PlayerHealth, "BOTTOMRIGHT", 0, 0)
GUI_PlayerMana:SetFrameStrata("HIGH")
GUI_PlayerMana:SetFrameLevel("4")

GUI_PlayerMana:RegisterForClicks("AnyUp")
GUI_PlayerMana:SetAttribute("unit", "player")
GUI_PlayerMana:SetAttribute("*type1", "target")

local showmenu = function() 
	playerInVehicle = UnitInVehicle("player")
    if playerInVehicle == nil then
    ToggleDropDownMenu(1, nil, PlayerFrameDropDown, "cursor", 0, 0) 
    
    elseif playerInVehicle == 1 then
    ToggleDropDownMenu(1, nil, PetFrameDropDown, "cursor", 0, 0)
    end 
end


GUI_PlayerMana.unit = "player"
GUI_PlayerMana:SetAttribute("*type2", "showmenu")
GUI_PlayerMana:SetScript("OnEnter", UnitFrame_OnEnter)
GUI_PlayerMana:SetScript("OnLeave", UnitFrame_OnLeave)



local manaBar = CreateFrame("StatusBar", nil, GrimPlayerFrame, "TextStatusBar")
manaBar:SetWidth(175)
manaBar:SetHeight(25)
manaBar:SetPoint("CENTER", GUI_PlayerMana, "CENTER", 0, 0)
manaBar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\BarTexture]])
manaBar:SetFrameLevel("3")



local manaText = manaBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
manaText:SetPoint("RIGHT", GUI_PlayerMana, "RIGHT", -4, -1)
manaText:SetTextColor(1, 1, 1, 1)
manaText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 16, "OUTLINE")


local powerUsed = CreateFrame("StatusBar", nil, GrimPlayerFrame, "TextStatusBar")
powerUsed:SetWidth(175)
powerUsed:SetHeight(25)
powerUsed:SetPoint("CENTER", GUI_PlayerMana, "CENTER", 0, 0)
powerUsed:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\BarTexture]])
powerUsed:SetStatusBarColor(.721, .047, .890, 1)
powerUsed:SetFrameLevel("2")


manaBarEventFrame:SetScript("OnEvent", function(self) 
    local currMana, maxMana = UnitMana("Player"), UnitManaMax("Player") 
    local powerType = UnitPowerType("Player")
    local currPower = UnitPower("Player")
    local maxPower = UnitPowerMax("Player")
    local currShape = GetShapeshiftForm()
    
    
    if powerType == 0 then
        local manaSTR = ("%s/%s"):format(currMana, maxMana)
        manaText:SetText(manaSTR) 
        manaBar:SetMinMaxValues(min(0, currMana), maxMana) 
        manaBar:SetValue(currMana) 
        manaBar:SetStatusBarColor(.556, .556, .921, 1)
        powerUsed:SetMinMaxValues(min(0, currMana), maxMana) 
        powerUsed:SetValue(currMana) 
    elseif powerType == 1 or 3 or 6 then
    local manaSTR = ("%s/%s"):format(currPower, maxPower)
        manaText:SetText(manaSTR) 
        manaBar:SetMinMaxValues(min(0, currPower), maxPower) 
        manaBar:SetValue(currPower) 
        manaBar:SetStatusBarColor(.656, .456, .456, 1)
        powerUsed:SetMinMaxValues(min(0, currPower), maxPower) 
        powerUsed:SetValue(currPower)
    end
end)
-- Mana Bar End


-- Player Info Text 


local nameEventFrame = CreateFrame("Frame", nil, UIParent)
nameEventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
nameEventFrame:RegisterEvent("PLAYER_REGEN_ENABLED") 
nameEventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
nameEventFrame:RegisterEvent("PLAYER_UPDATE_RESTING")



local InfoEventDisplayFrame = CreateFrame('Button', "InfoEventDisplayFrame", GrimPlayerFrame, "SecureActionButtonTemplate")
InfoEventDisplayFrame:SetHeight(15)
InfoEventDisplayFrame:SetWidth(177)
InfoEventDisplayFrame:SetPoint("BOTTOM", GUI_PlayerHealth, "TOP", 0, 0)
InfoEventDisplayFrame:SetFrameStrata("HIGH")
InfoEventDisplayFrame:SetFrameLevel("4")



local nameText = InfoEventDisplayFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
nameText:SetPoint("BOTTOMLEFT", GUI_PlayerHealth, "TOPLEFT", -4, -4)
nameText:SetTextColor(1, 1, 1, 1)
nameText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font3.ttf]], 20, "OUTLINE")

local function nameTextColor(self, event) 
    local resting = IsResting()
    if event == "PLAYER_ENTERING_WORLD" and resting == 1 then
        nameText:SetTextColor(0, 1, 0, 1)
        else 
        nameText:SetTextColor(1, 1, 1, 1)
    end
    if event == "PLAYER_REGEN_ENABLED" then 
        nameText:SetTextColor(1, 1, 1, 1)
    elseif event == "PLAYER_REGEN_DISABLED" then
        nameText:SetTextColor(1, 0, 0, 1)
    elseif event == "PLAYER_UPDATE_RESTING" and resting == 1 then
        nameText:SetTextColor(0, 1, 0, 1)
    elseif event == "PLAYER_UPDATE_RESTING" and resting == nil then
        nameText:SetTextColor(1, 1, 1, 1)
    end 
end 
nameEventFrame:SetScript("OnEvent", nameTextColor) 


local playerInfoText = InfoEventDisplayFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
playerInfoText:SetPoint("BOTTOMRIGHT", InfoEventDisplayFrame, "BOTTOMRIGHT", 0, -3)
playerInfoText:SetTextColor(0.937, 1, 0.345, 1)
playerInfoText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 11, "OUTLINE")
playerInfoText:SetPoint("LEFT", nameText, "RIGHT", -4, 0)
playerInfoText:SetJustifyH("RIGHT")



local InfoEventFrame = CreateFrame("Frame", nil, GrimPlayerFrame) -- this creates a frame table for it.  remember all addons are basically tables 
InfoEventFrame:SetScript("OnEvent", function(self, event, ...)  -- self = myAddon 
    if InfoEventFrame[event] then -- do you have a function set for the event in your table? 
        return InfoEventFrame[event](self, event, ...) -- if so, send the data 
    end 
end) 
InfoEventFrame:RegisterEvent("PLAYER_LEVEL_UP")  -- register events as usual 
InfoEventFrame:RegisterEvent("UNIT_LEVEL", "player")

InfoEventFrame:Show()  -- make sure the frame is "shown" or it will not receive scripts 
	 
function InfoEventFrame:PLAYER_LEVEL_UP(event, ...) -- hey lookie!  your event function! 
    local newLvl, manaGain, STSTIN, STSTIN, STSTIN, STSTIN, RTN0onWar, rtnsOonWar = ...;  -- extract your data from "...", which is shorthand for all args passed.  you can also simply do "newLvl = ...", skipping the rest that you don't need  
     -- since you have the data you want at this point, continue to use as needed 
    local playerClass = UnitClass("Player") 
    local playerName = UnitName("Player") 
    nameText:SetText(("%s"):format(playerName)) -- you can eliminate the excess "nameStr" declaration if you're just gonna use it here.  just plug the format in instead  
    playerInfoText:SetText(("%s %s"):format(newLvl, playerClass))  -- same as before 
end  


-- Player Info Text

local InfoInitiateFrame = CreateFrame("Frame", nil, GrimPlayerFrame)
InfoInitiateFrame:RegisterEvent("PLAYER_ENTERING_WORLD")

--InfoInitiateFrame:RegisterEvent("PLAYER_LEVEL_UP")
--InfoInitiateFrame:RegisterEvent("UNIT_MAXHEALTH")

InfoInitiateFrame:SetScript("OnEvent", function(self) 
      
    local playerLVL = UnitLevel("Player")
    local playerClass = UnitClass("Player")
    local playerName = UnitName("Player")
    local nameSTR = ("%s"):format(playerName)
    local playerInfoSTR = ("%s %s"):format(playerLVL, playerClass)
    nameText:SetText(nameSTR) 
    playerInfoText:SetText(playerInfoSTR)
end)


-- party leader icon
local partyLeaderEvent = CreateFrame("Frame", nil, UIParent)
partyLeaderEvent:RegisterEvent("ADDON_LOADED")
partyLeaderEvent:RegisterEvent("PARTY_LEADER_CHANGED") 
partyLeaderEvent:RegisterEvent("PARTY_MEMBERS_CHANGED")

partyLeaderFrame = CreateFrame("Frame", "partyLeaderFrame", GrimPlayerFrame)
partyLeaderFrame:SetPoint("BOTTOM", InfoEventDisplayFrame, "TOP", 52, -9)
partyLeaderFrame:SetHeight(22)
partyLeaderFrame:SetWidth(22)
partyLeaderFrame.texture = partyLeaderFrame:CreateTexture()
partyLeaderFrame.texture:SetAllPoints(partyLeaderFrame)
partyLeaderFrame.texture:SetTexture("Interface\\GroupFrame\\UI-Group-LeaderIcon.blp")

partyLeaderEvent:SetScript("OnEvent", function(self) 
      
    local isPartyLead = IsPartyLeader()
    
    if isPartyLead == 1 then
    partyLeaderFrame:Show()
    else
    partyLeaderFrame:Hide()
    end
end)

-- PVP icon
local pvpIconEvent = CreateFrame("Frame", nil, GrimPlayerFrame)
pvpIconEvent:RegisterEvent("ADDON_LOADED")
pvpIconEvent:RegisterEvent("UNIT_FACTION") 
pvpIconEvent:RegisterEvent("PARTY_MEMBERS_CHANGED")

pvpIconFrame = CreateFrame("Frame", "partyLeaderFrame", GrimPlayerFrame)
pvpIconFrame:SetPoint("BOTTOM", InfoEventDisplayFrame, "TOP", 77, -11)
pvpIconFrame:SetHeight(25)
pvpIconFrame:SetWidth(25)
pvpIconFrame.texture = pvpIconFrame:CreateTexture()
pvpIconFrame.texture:SetAllPoints(pvpIconFrame)


pvpIconEvent:SetScript("OnEvent", function(self) 
    
    local englishFaction, localizedFaction = UnitFactionGroup("player")
    if englishFaction == "Alliance" then    
    pvpIconFrame.texture:SetTexture("Interface\\GroupFrame\\UI-Group-PVP-Alliance.blp")
    elseif englishFaction == "Horde" then
    pvpIconFrame.texture:SetTexture("Interface\\GroupFrame\\UI-Group-PVP-Horde.blp")
    end
    
    local ispvp = UnitIsPVP("player")
   
    if ispvp == 1 then
    pvpIconFrame:Show()
    else
    pvpIconFrame:Hide()
    end
end)

---------------------------------------
-- Player Pet Frame
--------------------------------------------------------------------------------

local GrimPlayerPetFrame = CreateFrame("Frame", "GrimPlayerPetFrame", GrimPlayerFrame, "SecureUnitButtonTemplate")
GrimPlayerPetFrame:SetFrameStrata("BACKGROUND") 
GrimPlayerPetFrame:SetFrameLevel(4) 
GrimPlayerPetFrame:SetWidth(108) 
GrimPlayerPetFrame:SetHeight(180) 
GrimPlayerPetFrame:SetPoint("LEFT", GrimPlayerFrame, "RIGHT", 0, 2)

GrimPlayerPetFrame:SetAttribute('unit', 'pet')
RegisterUnitWatch(GrimPlayerPetFrame)

--  Pet pedistal
local PetPedestalFrame = CreateFrame('Frame', "pedestalFrame", GrimPlayerPetFrame)
PetPedestalFrame:SetPoint("CENTER", GrimPlayerPetFrame, "CENTER", 0, -58)
PetPedestalFrame:SetHeight(15)
PetPedestalFrame:SetWidth(54)
PetPedestalFrame.texture = PetPedestalFrame:CreateTexture()
PetPedestalFrame.texture:SetAllPoints(PetPedestalFrame)
PetPedestalFrame.texture:SetTexture([[Interface\AddOns\]] .. addonName .. [[\Media\Pedestal]])
PetPedestalFrame:SetFrameStrata("LOW")
PetPedestalFrame:SetFrameLevel("2")

-- health bar start
local PlayerPetHealthEvents = CreateFrame("Frame", nil, UIParent)
PlayerPetHealthEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
PlayerPetHealthEvents:RegisterEvent("UNIT_HEALTH", "pet")
PlayerPetHealthEvents:RegisterEvent("UNIT_LEVEL", "pet")
PlayerPetHealthEvents:RegisterEvent("UNIT_AURA", "pet")
PlayerPetHealthEvents:RegisterEvent("UNIT_MAXHEALTH", "pet")
PlayerPetHealthEvents:RegisterEvent("PLAYER_PET_CHANGED")
PlayerPetHealthEvents:RegisterEvent("UNIT_PET", "player")
PlayerPetHealthEvents:RegisterEvent("LOCALPLAYER_PET_RENAMED")

local GUI_PlayerPetHealth = CreateFrame('Button', "GUI_PlayerPetHealth", GrimPlayerPetFrame, "SecureActionButtonTemplate")
GUI_PlayerPetHealth:SetHeight(98)
GUI_PlayerPetHealth:SetWidth(32)
GUI_PlayerPetHealth:SetPoint("LEFT", GrimPlayerPetFrame, "LEFT", 0, -15)

GUI_PlayerPetHealth:SetBackdrop{ 
		bgFile = nil, 
		edgeFile = "Interface/DialogFrame/UI-DialogBox-Border", tile = false, tileSize = 0, edgeSize = 5, 
		insets = { left = 0, right = 0, top = 0, bottom = 0 } 
	} 
GUI_PlayerPetHealth:SetBackdropBorderColor(0, 0, 0, 1)


GUI_PlayerPetHealth:SetFrameStrata("BACKGROUND")
GUI_PlayerPetHealth:SetFrameLevel("3")

GUI_PlayerPetHealth:RegisterForClicks("AnyUp")
GUI_PlayerPetHealth:SetAttribute("unit", "pet")
GUI_PlayerPetHealth:SetAttribute("*type1", "target")

local showpetmenu = function() 
	playerInVehicle = UnitInVehicle("player")
    if playerInVehicle ~= 1 then
    ToggleDropDownMenu(1, nil, PetFrameDropDown, "cursor", 0, 0) 
    end
    if playerInVehicle == 1 then
    ToggleDropDownMenu(1, nil, PlayerFrameDropDown, "cursor", 0, 0)
    end
    
end
GUI_PlayerPetHealth.showpetmenu = showpetmenu
GUI_PlayerPetHealth.unit = "pet"
GUI_PlayerPetHealth:SetAttribute("*type2", "showpetmenu")
GUI_PlayerPetHealth:SetScript("OnEnter", UnitFrame_OnEnter)
GUI_PlayerPetHealth:SetScript("OnLeave", UnitFrame_OnLeave)
GUI_PlayerPetHealth:SetFrameStrata("BACKGROUND")
GUI_PlayerPetHealth:SetFrameLevel("2")


local playerPetHealthBar = CreateFrame("StatusBar", nil, GUI_PlayerPetHealth, "TextStatusBar")
playerPetHealthBar:SetWidth(30)
playerPetHealthBar:SetHeight(96)
playerPetHealthBar:SetPoint("CENTER", GUI_PlayerPetHealth, "CENTER", 0, 0)
playerPetHealthBar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\VBarTexture]])
playerPetHealthBar:SetStatusBarColor(.231, .682, .419, 1)
playerPetHealthBar:SetOrientation("VERTICAL")
playerPetHealthBar:SetFrameStrata("BACKGROUND")
playerPetHealthBar:SetFrameLevel("2")



local percentPHText = GUI_PlayerPetHealth:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
percentPHText:SetPoint("TOP", GUI_PlayerPetHealth, "TOP", 0, -1)
percentPHText:SetTextColor(1, 1, 1, 1)
percentPHText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 10)




PlayerPetHealthEvents:SetScript("OnEvent", function(self) 
    local currPHealth, maxPHealth = UnitHealth("pet"), UnitHealthMax("pet") 
    
    
    local percentPHealth = floor(currPHealth / maxPHealth * 100)   
    local petHstr = ("%s%%"):format(percentPHealth)
    
    
    
    playerPetHealthBar:SetMinMaxValues(min(0, currPHealth), maxPHealth) 
    playerPetHealthBar:SetValue(currPHealth) 
    percentPHText:SetText(petHstr)
    --takenDMGbar:SetMinMaxValues(min(0, currHealth), maxHealth) 
    --takenDMGbar:SetValue(currHealth) 
end)


--local takenDMGbar = CreateFrame("StatusBar", nil, TargetHealthEvents, "TextStatusBar")
--takenDMGbar:SetWidth(175)
--takenDMGbar:SetHeight(25)
--takenDMGbar:SetPoint("CENTER", GUI_PlayerHealth, "CENTER", 0, 0)
--takenDMGbar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\BarTexture]])
--takenDMGbar:SetStatusBarColor(.721, .047, .890, 1)
--takenDMGbar:SetFrameLevel("2")

--GrimUI.takenDMGbar = takenDMGbar




-- health bar end

----------------------------------
-- Mana Bar Start
-----------------------
-- Mana Bar Start
local PlayerPetManaEvents = CreateFrame("Frame", nil, UIParent)
PlayerPetManaEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
PlayerPetManaEvents:RegisterEvent("UNIT_HEALTH", "pet")
PlayerPetManaEvents:RegisterEvent("UNIT_LEVEL", "pet")
PlayerPetManaEvents:RegisterEvent("UNIT_MANA", "pet")
PlayerPetManaEvents:RegisterEvent("UNIT_AURA", "pet")
PlayerPetManaEvents:RegisterEvent("UNIT_DISPLAYPOWER", "pet")
PlayerPetManaEvents:RegisterEvent("UNIT_ENERGY", "pet")
PlayerPetManaEvents:RegisterEvent("UNIT_MAXENERGY", "pet")
PlayerPetManaEvents:RegisterEvent("UNIT_MAXMANA", "pet")
PlayerPetManaEvents:RegisterEvent("UNIT_MAXRUNICPOWER", "pet")
PlayerPetManaEvents:RegisterEvent("UNIT_RUNIC_POWER", "pet")
PlayerPetManaEvents:RegisterEvent("UNIT_RAGE", "pet")



local GUI_PlayerPetMana = CreateFrame('Button', "GUI_PlayerPetMana", GrimPlayerPetFrame, "SecureActionButtonTemplate")
GUI_PlayerPetMana:SetHeight(98)
GUI_PlayerPetMana:SetWidth(32)
GUI_PlayerPetMana:SetPoint("RIGHT", GrimPlayerPetFrame, "RIGHT", 0, -15)

GUI_PlayerPetMana:SetBackdrop{ 
		bgFile = nil, 
		edgeFile = "Interface/DialogFrame/UI-DialogBox-Border", tile = false, tileSize = 0, edgeSize = 5, 
		insets = { left = 0, right = 0, top = 0, bottom = 0 } 
	} 
GUI_PlayerPetMana:SetBackdropBorderColor(0, 0, 0, 1)


GUI_PlayerPetMana:SetFrameStrata("BACKGROUND")
GUI_PlayerPetMana:SetFrameLevel("3")


GUI_PlayerPetMana:RegisterForClicks("AnyUp")
GUI_PlayerPetMana:SetAttribute("unit", "pet")
GUI_PlayerPetMana:SetAttribute("*type1", "target")

local showpetmenu = function() 
	local playerInVehicle = UnitInVehicle("player")
    if playerInVehicle == nil then
    ToggleDropDownMenu(1, nil, PetFrameDropDown, "cursor", 0, 0) 
    
    elseif playerInVehicle == 1 then
    ToggleDropDownMenu(1, nil, PlayerFrameDropDown, "cursor", 0, 0)
    end
    
end
GUI_PlayerPetMana.showpetmenu = showpetmenu
GUI_PlayerPetMana.unit = "pet"
GUI_PlayerPetMana:SetAttribute("*type2", "showpetmenu")
GUI_PlayerPetMana:SetScript("OnEnter", UnitFrame_OnEnter)
GUI_PlayerPetMana:SetScript("OnLeave", UnitFrame_OnLeave)
GUI_PlayerPetMana:SetFrameStrata("BACKGROUND")
GUI_PlayerPetMana:SetFrameLevel("2")




local playerPetManaBar = CreateFrame("StatusBar", nil, GUI_PlayerPetMana, "TextStatusBar")
playerPetManaBar:SetWidth(30)
playerPetManaBar:SetHeight(96)
playerPetManaBar:SetPoint("CENTER", GUI_PlayerPetMana, "CENTER", 0, 0)
playerPetManaBar:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\VBarTexture]])
playerPetManaBar:SetOrientation("VERTICAL")
playerPetManaBar:SetFrameStrata("BACKGROUND")
playerPetManaBar:SetFrameLevel("2")



--local powerUsed = CreateFrame("StatusBar", nil, manaBarEventFrame, "TextStatusBar")
--powerUsed:SetWidth(175)
--powerUsed:SetHeight(25)
--powerUsed:SetPoint("CENTER", manaborder, "CENTER", 0, 0)
--powerUsed:SetStatusBarTexture([[Interface\AddOns\]] .. addonName .. [[\Media\BarTexture]])
--powerUsed:SetStatusBarColor(.721, .047, .890, 1)
--powerUsed:SetFrameLevel("2")
--manaBarEventFrame.powerUsed = powerUsed

local percentPMText = GUI_PlayerPetMana:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
percentPMText:SetPoint("TOP", GUI_PlayerPetMana, "TOP", 0, -1)
percentPMText:SetTextColor(1, 1, 1, 1)
percentPMText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 10)



PlayerPetManaEvents:SetScript("OnEvent", function(self) 
    local currMana, maxMana = UnitMana("pet"), UnitManaMax("pet") 
    local powerType = UnitPowerType("pet")
    local currPower = UnitPower("pet")
    local maxPower = UnitPowerMax("pet")
    local percentMana = floor(currMana / maxMana * 100)
	
	
    if maxMana >= 1 then
		local perMstr = ("%s%%"):format(percentMana)
		percentPMText:SetText(perMstr)
	end
	
	if maxMana == 0 then
		local perMstr = ("0%")
		percentPMText:SetText(perMstr)
	end
	
    
	
	
	if powerType == 0 then
       
        playerPetManaBar:SetMinMaxValues(min(0, currMana), maxMana) 
        playerPetManaBar:SetValue(currMana) 
        playerPetManaBar:SetStatusBarColor(.556, .556, .921, 1)
        --powerUsed:SetMinMaxValues(min(0, currMana), maxMana) 
        --powerUsed:SetValue(currMana) 
    elseif powerType == 1 or 3 or 6 then
    
        playerPetManaBar:SetMinMaxValues(min(0, currPower), maxPower) 
        playerPetManaBar:SetValue(currPower) 
        playerPetManaBar:SetStatusBarColor(.656, .456, .456, 1)
        --powerUsed:SetMinMaxValues(min(0, currPower), maxPower) 
        --powerUsed:SetValue(currPower)
    end
	
	
	end)


--------------
-- Pet Mana Bar End
-----------------


--[[######################  
	       PET Name  Frame START 
	   ########################]] 
	   
	   
local playerPetNameFrame = CreateFrame("frame", nil, GrimPlayerPetFrame)
playerPetNameFrame:SetWidth(106)
playerPetNameFrame:SetHeight(23)
playerPetNameFrame:SetPoint("BOTTOM", GrimPlayerPetFrame, "BOTTOM", 0, 3)
playerPetNameFrame:SetFrameStrata("HIGH")
playerPetNameFrame:SetFrameLevel("5")
playerPetNameFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
playerPetNameFrame:RegisterEvent("PLAYER_PET_CHANGED")
playerPetNameFrame:RegisterEvent("UNIT_NAME_UPDATE", "pet")
playerPetNameFrame:RegisterEvent("UNIT_NAME_UPDATE", "vehicle")
playerPetNameFrame:RegisterEvent("PET_ATTACK_START")
playerPetNameFrame:RegisterEvent("PET_ATTACK_STOP")
playerPetNameFrame:RegisterEvent("UNIT_ENTERED_VEHICLE", "player")

local ppnfbg = playerPetNameFrame:CreateTexture(nil, "BACKGROUND")
ppnfbg:SetTexture(0, 0, 0, 0)
ppnfbg:SetAllPoints(playerPetNameFrame)




local playerPetNameText = playerPetNameFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
playerPetNameText:SetPoint("TOP", playerPetNameFrame, "TOP", 0, 0)
playerPetNameText:SetPoint("LEFT", playerPetNameFrame, "LEFT", 0, 0)
playerPetNameText:SetPoint("RIGHT", playerPetNameFrame, "RIGHT", 0, 0)
playerPetNameText:SetTextColor(1, 1, 1, 1)
playerPetNameText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font3.ttf]], 13)



local playerPetLvlRaceText = playerPetNameFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
playerPetLvlRaceText:SetPoint("BOTTOM", playerPetNameFrame, "BOTTOM", 0, 0)
playerPetLvlRaceText:SetPoint("LEFT", playerPetNameFrame, "LEFT", 0, 0)
playerPetLvlRaceText:SetPoint("RIGHT", playerPetNameFrame, "RIGHT", 0, 0)
playerPetLvlRaceText:SetTextColor(1, 1, 1, 1)
playerPetLvlRaceText:SetFont([[Interface\AddOns\]] .. addonName .. [[\Media\Font1.ttf]], 11)


playerPetNameFrame:SetScript("OnEvent", function(self) 
    local petName = UnitName("pet")
    
    local vehicname = UnitName("vehicle")
    local vehiclvl = UnitLevel("vehicle")
    local vehictype = UnitCreatureType("vehicle")
    
    
    local petlvl = UnitLevel("pet")
	local petclass = UnitClass("pet")
	local petrace = UnitRace("pet")
	local unitpetexists = UnitExists("pet")
	local pettype = UnitCreatureType("pet")
    local petfamily = UnitCreatureFamily("pet")
    local playerInVehicle = UnitInVehicle("player")
    if event == "PET_ATTACK_START" then 
        playerPetNameText:SetTextColor(1, 0, 0, 1)
    elseif event == "PET_ATTACK_STOP" then
        playerPetNameText:SetTextColor(1, 1, 1, 1)
    else
        playerPetNameText:SetTextColor(1, 1, 1, 1)
    end 
        
   
	if unitpetexists == 1 and playerInVehicle == nil then
        
        local petnamestr = ("%s"):format(petName)
		playerPetNameText:SetText(petnamestr)
        
        if pettype ~= nil and petfamily ~= nil then
            local petlvlracestr = ("%s %s %s"):format(petlvl, pettype, petfamily)
            playerPetLvlRaceText:SetText(petlvlracestr)
        else
            playerPetLvlRaceText:SetText("Unknown")
        end
    elseif unitpetexists == 1 and playerInVehicle == 1 then
        if vehicname ~= nil and vehiclvl ~= nil and vehictype ~= nil then
        local vehicnamestr = ("%s"):format(vehicname)
		playerPetNameText:SetText(vehicnamestr)
        
        local vehiclvlracestr = ("%s %s"):format(vehiclvl, vehictype)
        playerPetLvlRaceText:SetText(vehiclvlracestr)
        end
        if vehicname == nil and vehiclvl == nil and vehictype == nil then
        playerPetNameText:SetText("Unkown")
        playerPetLvlRaceText:SetText("Unknown")
        end
    
    end
    
end)
  
   
--######################  
--       PET Name Frame END 
--########################

-------------------------
-- Clique inclusion start
-------------------------
ClickCastFrames = ClickCastFrames or {}
ClickCastFrames[GUI_PlayerHealth] = true
ClickCastFrames[GUI_PlayerMana] = true
ClickCastFrames[GUI_Player3DModel] = true
ClickCastFrames[GUI_PlayerPetHealth] = true
ClickCastFrames[GUI_PlayerPetMana] = true
-------------------------
-- Clique inclusion end
-------------------------

