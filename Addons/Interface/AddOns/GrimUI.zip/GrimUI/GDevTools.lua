
local addonName, addon = ...

addon:RegisterDefaultSetting("toggleTaintLog", false)
addon:RegisterDefaultSetting("showDevBar", false)


local GDevBar = CreateFrame('Frame', "GDevBar", UIParent)
GDevBar:SetHeight(122)
GDevBar:SetWidth(140)
GDevBar:SetBackdrop{
		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
		edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
		tile = true,
		tileSize = 32,
		edgeSize = 32,
		insets = {
			left = 11,
			right = 12,
			top = 12,
			bottom = 11
		}
	}

function addon:GrimUIMemUse()
	UpdateAddOnMemoryUsage()
	local GUIMemUse = GetAddOnMemoryUsage("GrimUI")
	print("|cff33ff99" .. addonName .. "|r: Current memory usage = ", GUIMemUse)
end

local button = CreateFrame("Button", nil, GDevBar, "UIPanelButtonTemplate")
	button:SetHeight(25)
	button:SetWidth(105)
	button:SetPoint("CENTER", 0, -30)
	button:SetText("Reload")
	button:RegisterForClicks("AnyUp")
	button:SetScript("OnClick", ReloadUI)

local button2 = CreateFrame("Button", nil, GDevBar, "UIPanelButtonTemplate")
	button2:SetHeight(25)
	button2:SetWidth(105)
	button2:SetPoint("CENTER", 0, 0)
	button2:SetText("Memory Use")
	button2:RegisterForClicks("AnyUp")
	button2:SetScript("OnClick", function() addon:GrimUIMemUse() end)

local button3 = CreateFrame("Button", nil, GDevBar, "UIPanelButtonTemplate")
	button3:SetHeight(25)
	button3:SetWidth(105)
	button3:SetPoint("CENTER", 0, 30)
	button3:SetText("Frame Stack")
	button3:RegisterForClicks("AnyUp")
	button3:SetScript("OnClick", function() GrimUI:RunSlashCmd("/framestack") end)
	
	
	
function addon:ResetDevBar()
	GDevBar:ClearAllPoints()
	GDevBar:SetPoint("RIGHT", UIParent, "RIGHT", 0, 0)
end

addon:ResetDevBar()

function addon:ShowDevBar()
	if addon.settings.showDevBar then
		addon:ShowFrame('GDevBar')
	else
		addon:HideFrame('GDevBar')
	end
end


function addon:BlizBuildInfo()
	local version, build, bdate, toc = GetBuildInfo()

	print(string.format("version = %s, build = %s, builddate = '%s', tocversion = %s.", version, build, bdate, toc))

end


function addon:ToggleTaintLog()
	if addon.settings.toggleTaintLog == true then
		addon:RunSlashCmd("/console taintLog 1")
	elseif addon.settings.toggleTaintLog == false then
		addon:RunSlashCmd("/console taintLog 0")
	end
end

addon.RegisterEvent("GDevBar-Initialize", 'PLAYER_ENTERING_WORLD', function(self, event)
	addon.UnregisterEvent(self, event)
	
	if not addon.settings.toggleTaintLog then
	addon:RunSlashCmd("/console taintLog 0")
	end
	
	addon:ShowDevBar()
end)