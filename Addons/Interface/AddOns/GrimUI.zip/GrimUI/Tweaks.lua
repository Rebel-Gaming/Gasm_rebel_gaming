local addonName, addon = ...

--[[-----------------------------------------------------------------------------
Relocate the CastingBarFrame and keep open bags a fixed size
-------------------------------------------------------------------------------]]
addon.RegisterEvent("Feature-Initialize", 'PLAYER_ENTERING_WORLD', function(self, event)
	addon.UnregisterEvent(self, event)

	CastingBarFrame:ClearAllPoints()
	CastingBarFrame:SetPoint('BOTTOM', UIParent, 'BOTTOM', 0, 350)
	addon:LockFrame(CastingBarFrame)

	for id = 1, NUM_CONTAINER_FRAMES do
		local frame = _G['ContainerFrame' .. id]
		frame:SetScale(0.9)
		frame.SetScale = addon.DoNothing
	end
end)

--[[-----------------------------------------------------------------------------
PVP Battleground
-------------------------------------------------------------------------------]]
if PVPBattlegroundFrame then
	if PVPBattlegroundFrameFrameLabel then		-- Display fix for 3.1+
		PVPBattlegroundFrameFrameLabel:ClearAllPoints()
		PVPBattlegroundFrameFrameLabel:SetPoint('TOP', PVPBattlegroundFrame, 'TOP', 0, -17)
	end
	if PVPBattlegroundFrameNameHeader then		-- Display fix for 3.2+
		PVPBattlegroundFrameNameHeader:ClearAllPoints()
		PVPBattlegroundFrameNameHeader:SetPoint('TOPLEFT', PVPBattlegroundFrame, 'TOPLEFT', 70, -55)
	end
end
