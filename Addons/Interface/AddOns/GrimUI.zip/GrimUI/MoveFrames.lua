local addonName, addon = ...

addon:RegisterDefaultSetting("lockFrames", false)

--[[-----------------------------------------------------------------------------
Frames to allow moving and saving
-------------------------------------------------------------------------------]]
local frames = {
--	["FrameName"] =	false  - move the frame
--							true   - move the frame's parent instead
--							string - move the named frame instead

	-- Blizzard Frames
	['RuneFrame'] = false,
	['SpellBookFrame'] = false,			-- May cause taint
	['QuestLogFrame'] = false,
	['FriendsFrame'] = false,
	['LFGParentFrame'] = false,
	['KnowledgeBaseFrame'] = true,
	['HelpFrame'] = false,
	['GossipFrame'] = false,
	['MerchantFrame'] = false,
	['MailFrame'] = false,
	['GuildRegistrarFrame'] = false,
	['DressUpFrame'] = false,
	['TabardFrame'] = false,
	['TaxiFrame'] = false,
	['QuestFrame'] = false,
	['TradeFrame'] = false,
	['LootFrame'] = false,					-- May cause taint
	['PetStableFrame'] = false,
	['StackSplitFrame'] = false,
	['PetitionFrame'] = false,
	['WorldStateScoreFrame'] = false,
	['BattlefieldFrame'] = false,
	['ArenaFrame'] = false,
	['ItemTextFrame'] = false,
	['GameMenuFrame'] = false,
	['InterfaceOptionsFrame'] = false,
	['MacOptionsFrame'] = false,
	['PetPaperDollFrame'] = false,		-- ???
	['PaperDollFrame'] = true,
	['CharacterModelFrame'] = true,
	['ReputationFrame'] = true,
	['SkillFrame'] = true,
	['PVPFrame'] = true,
	['PVPBattlegroundFrame'] = false,
	['SendMailFrame'] = true,
	['TokenFrame'] = true,
	['WatchFrameHeader'] = true,
	['InterfaceOptionsFrame'] = false,
	['VideoOptionsFrame'] = false,
	['AudioOptionsFrame'] = false,
	['BankFrame'] = false,
	['TimeManagerFrame'] = false,
	['LFDParentFrame'] = false,
--	['MultiBarBottomLeft'] = false,		-- DON'T MOVE THIS, TAINTS FRAME MANAGEMENT
--	['MultiBarLeft'] = false,				-- DON'T MOVE THIS, TAINTS FRAME MANAGEMENT
--	['MultiBarBottomRight'] = false,		-- DON'T MOVE THIS, TAINTS FRAME MANAGEMENT
--	['MultiBarRight'] = false,				-- DON'T MOVE THIS, TAINTS FRAME MANAGEMENT
--	['ShapeshiftBarFrame'] = false,		-- DON'T MOVE THIS, TAINTS FRAME MANAGEMENT
--	['BonusActionBarFrame'] = false,		-- DON'T MOVE THIS, TAINTS FRAME MANAGEMENT
--	['VehicleMenuBar'] = false,			-- DON'T MOVE THIS, TAINTS FRAME MANAGEMENT

	-- Blizzard LOD frames
	['AuctionFrame'] = false,
	['KeyBindingFrame'] = false,
	['CraftFrame'] = false,
	['GMSurveyFrame'] = false,
	['InspectFrame'] = false,
	['InspectPVPFrame'] = true,
	['InspectTalentFrame'] = true,
	['ItemSocketingFrame'] = false,
	['MacroFrame'] = false,
	['PlayerTalentFrame'] = false,
	['TradeSkillFrame'] = false,
	['ClassTrainerFrame'] = false,
	['GuildBankFrame'] = false,
	['GuildBankEmblemFrame'] = true,
	['TimeManagerFrame'] = false,
	['AchievementFrame'] = false,
	['AchievementFrameHeader'] = true,
	['AchievementFrameCategoriesContainer'] = 'AchievementFrame',
	['TokenFrame'] = true,
	['ItemSocketingFrame'] = false,
	['GlyphFrame'] = 'PlayerTalentFrame',
	['BarberShopFrame'] = false,
	['CalendarFrame'] = false,
	['CalendarCreateEventFrame'] = true,

	-- Our frames
	[addonName .. "PlayerFrame"] = false,
	[addonName .. "PartyFrame1"] = false,
	[addonName .. "PartyFrame2"] = false,
	[addonName .. "PartyFrame3"] = false,
	[addonName .. "PartyFrame4"] = false,

	-- AddOns
	["LudwigFrame"] = false,
}

for id = 1, NUM_CONTAINER_FRAMES do																-- Add the bag/keyring containers
	frames['ContainerFrame' .. id] = false
end

--[[-----------------------------------------------------------------------------
Frame hooking
-------------------------------------------------------------------------------]]
local hookedFrame, parentFrame, movedFrames, oldPoint, oldX, oldY = { }, { }

local function GetRelativePosition(frame)
	local _, _, uiWidth, uiHeight = UIParent:GetRect()
	local left, bottom, width, height = frame:GetRect()
	if bottom + height / 2 >= uiHeight / 2 then
		if left + width / 2 >= uiWidth / 2 then
			return 'TOPRIGHT', left + width - uiWidth - 1, bottom + height - uiHeight - 1
		else
			return 'TOPLEFT', left, bottom + height - uiHeight - 1
		end
	elseif left + width / 2 >= uiWidth / 2 then
		return 'BOTTOMRIGHT', left + width - uiWidth - 1, bottom
	end
	return 'BOTTOMLEFT', left, bottom
end

local function OnShow(self)
	local frame = parentFrame[self] or self
	local position = movedFrames[frame:GetName()]
	if position then
		addon:UnlockFrame(frame)
		frame:ClearAllPoints()
		frame:SetPoint(unpack(position))
		addon:LockFrame(frame)
	end
end

local function OnMouseDown(self, button)
	if button ~= 'LeftButton' or addon.settings.lockFrames then return end
	local frame = parentFrame[self] or self
	oldPoint, oldX, oldY = GetRelativePosition(frame)
	addon:UnlockFrame(frame)
	frame:StartMoving()
end

local function OnMouseUp(self, button)
	if button ~= 'LeftButton' or not oldPoint then return end
	local frame = parentFrame[self] or self
	frame:StopMovingOrSizing()
	addon:LockFrame(frame)
	local point, x, y = GetRelativePosition(frame)
	if point ~= oldPoint or x ~= oldX or y ~= oldY then
		movedFrames[frame:GetName()] = { point, 'UIParent', x, y }
	end
	oldPoint, oldX, oldY = nil, nil, nil
end

local HookFrame
function HookFrame(name, parent)
	if hookedFrame[name] then return true end
	local frame = _G[name]
	if not frame then return end
	if parent then
		if type(parent) == 'string' then
			parent = _G[parent]
		else
			parent = frame:GetParent()
		end
		if not parent then return end
		HookFrame(parent:GetName())
		while(parentFrame[parent]) do
			parent = parentFrame[parent]
		end
		parentFrame[frame] = parent
	elseif not name:match("^" .. addonName) then
		frame:HookScript('OnShow', OnShow)
	end
	frame:EnableMouse(true)
	frame:SetMovable(true)
	frame:SetClampedToScreen(false)
	frame:HookScript('OnMouseDown', OnMouseDown)
	frame:HookScript('OnMouseUp', OnMouseUp)
	hookedFrame[name] = true
	if movedFrames[name] and frame:IsShown() then
		OnShow(frame)
	end
	return true
end

--[[-----------------------------------------------------------------------------
Initialize
-------------------------------------------------------------------------------]]
addon.RegisterEvent("MoveFrames-Initialize", 'PLAYER_LOGIN', function(self, event)
	addon.UnregisterEvent(self, event)

	movedFrames = addon.settings.movedFrames
	if type(movedFrames) ~= 'table' then
		movedFrames = { }
		addon.settings.movedFrames = movedFrames
	end
	addon:RegisterDefaultSetting("movedFrames", true)										-- Prevent it from being removed on PLAYER_LOGOUT

	local function HookFrames(self, event)
		for name, parent in pairs(frames) do
			if HookFrame(name, parent) then
				frames[name] = nil
			end
		end
		if next(frames) then return end
		addon.UnregisterEvent(self, event)
	end

	addon.RegisterEvent("MoveFrames-Hook", 'ADDON_LOADED', HookFrames)
	HookFrames("MoveFrames-Hook", 'ADDON_LOADED')
end)
