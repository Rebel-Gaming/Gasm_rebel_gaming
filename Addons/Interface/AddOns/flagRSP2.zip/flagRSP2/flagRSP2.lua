--[[
flagRSP2 - Alexia E. Smith - http://www.nonamestudios.com/flagRSP2.php
German Localization: Niclas
Chinese Localization: Bo Yuan
Idea contributions by ClemSnide and Vastare(Feathermoon).
Thanks for the Rabbit for help with his LibDBIcon library.

With some code from:
flagRSP 0.5.6 - Florian Kruse - http://flokru.org/flagrsp/
AF_Tooltip Mini -  AquaFlare7 and devFreak - http://afstudios.net/
TinyTip - Thrae of Maelstrom (aka "Matthew Carras")
]]--

flagRSP2 = LibStub("AceAddon-3.0"):NewAddon("flagRSP2", "AceEvent-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("flagRSP2", false)
flagRSP2.title = "flagRSP2"

--Variable Declaration
local name = "FlagRSP2";
local textsendupdate = 0;
local descupdate = 0;
local dpcooldown = 0;
local rName = GetRealmName();
local pName = UnitName("player");
local cttip = "";
local nttip = "";
local rspcombat = 0;
local difftime = 0;
local polledtime = 0;
local lasttime = 0;
local buffersize = 0;
local bufferpos = 0;
local cid = nil;
local channame = nil;
local chanwarned = 0;
local textonefont = nil;
local texttwofont = nil;
local timeatloading = time();
local dpthrottle = {};
local comm_channel = "xtensionxtooltip2"
local self = flagRSP2;
local unittype = {normal = "", elite = "|cffFFCC00(Elite)", worldboss = "|cffFF0000(Boss)", rare = "|cffFF66FF(Rare)", rareelite = "|cffFFAAFF(Rare Elite)", trivial = "|cff999999(Trivial)"}

--Create Frames
--Default frame for updates.
local flagRSP2_Frame = CreateFrame("Frame", nil, UIParent);
flagRSP2_Frame:SetScript("OnUpdate", function() flagRSP2:UpdateSendBuffer(); if (FRSP_RESIZING == true) then flagRSP2InfoDesc:SetWidth(flagRSP2Info_Frame:GetWidth() - 40); end end)

GameTooltip:HookScript("OnShow", function() if (flagRSP2.db.char.flagRSP2TooltipLightModeCheck == false) then r, g, b, a = GameTooltip:GetBackdropColor(); GameTooltip:SetBackdropColor(r, g, b, 0.7); end end)

--Clear View Frame
local flagRSP2ClearViewClose = CreateFrame("Frame", nil, WorldFrame);
flagRSP2ClearViewClose:SetPoint("TOPRIGHT", WorldFrame, "TOPRIGHT", 0, 0)
flagRSP2ClearViewClose:SetWidth(32)
flagRSP2ClearViewClose:SetHeight(32)
--Clear View Frame Button
local flagRSP2ClearViewCloseButton = CreateFrame("Button", nil, flagRSP2ClearViewClose, "UIPanelCloseButton");
flagRSP2ClearViewCloseButton:SetPoint("TOPRIGHT", flagRSP2ClearViewClose, "TOPRIGHT", 0, 0)
flagRSP2ClearViewCloseButton:SetWidth(32)
flagRSP2ClearViewCloseButton:SetHeight(32)
flagRSP2ClearViewCloseButton:SetScript("OnClick", function() flagRSP2SetClearView() end)
flagRSP2ClearViewClose:Hide()
--Character Profile Button
flagRSP2CharacterAnchor = CreateFrame("Frame", nil, PaperDollFrame);
flagRSP2CharacterAnchor:SetPoint("CENTER", PaperDollFrame, "CENTER", 0, 0)
local flagRSP2CharacterAnchorButton = CreateFrame("Button", nil, flagRSP2CharacterAnchor, "OptionsButtonTemplate");
flagRSP2CharacterAnchorButton:SetPoint("CENTER", PaperDollFrame, "LEFT", 165, -140)
flagRSP2CharacterAnchorButton:SetWidth(135)
flagRSP2CharacterAnchorButton:SetHeight(20)
flagRSP2CharacterAnchorButton:SetText(L["FLAGRSP2_PAPERDOLL_BUTTON"])
flagRSP2CharacterAnchorButton:SetScript("OnEnter", function() GameTooltip:SetOwner(flagRSP2CharacterAnchorButton, "ANCHOR_RIGHT"); GameTooltip:SetText(MicroButtonTooltipText("Edit character sheet via FlagRSP2.", "Character Profile"), 1.0,1.0,1.0 ); end)
flagRSP2CharacterAnchorButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
flagRSP2CharacterAnchorButton:SetScript("OnClick", function() InterfaceOptionsFrame_OpenToCategory("flagRSP2") end)

local ldb = LibStub:GetLibrary("LibDataBroker-1.1"):NewDataObject("flagRSP2", {
    type = "launcher",
    icon = "Interface\\AddOns\\flagRSP2\\icon",
    OnClick = function(clickedframe, button)
        if (IsShiftKeyDown() and button == "LeftButton") then
			flagRSP2SetClearView()
		elseif (IsControlKeyDown() and button == "LeftButton") then
			name = UnitName("target");
			if (FlagList[rName][name] ~= nil) then
				if (FlagList[rName][name]["HideDesc"] == nil) then
					FlagList[rName][name]["HideDesc"] = 1;
					DEFAULT_CHAT_FRAME:AddMessage("|cffB100DD" .. name .. L["FLAGRSP2_LUA_DESCSHOW"]);
				elseif (FlagList[rName][name]["HideDesc"] == 1) then
					FlagList[rName][name]["HideDesc"] = 0;
					DEFAULT_CHAT_FRAME:AddMessage("|cffB100DD" .. name .. L["FLAGRSP2_LUA_DESCSHOW"]);
				else
					FlagList[rName][name]["HideDesc"] = 1;
					DEFAULT_CHAT_FRAME:AddMessage("|cffB100DD" .. name .. L["FLAGRSP2_LUA_DESCHIDE"]);
				end
			end
		elseif (button == "RightButton") then
			if (flagRSP2Viewer_Frame:IsVisible()) then
				flagRSP2Viewer_Frame:Hide();
			else
				flagRSP2Viewer_Frame:Show();
			end
		elseif (button == "LeftButton") then
			InterfaceOptionsFrame_OpenToCategory("flagRSP2")
		end
    end,
	OnEnter = function(self)
	    GameTooltip:SetOwner(self, "ANCHOR_NONE")
	    GameTooltip:SetPoint("TOPLEFT", self, "BOTTOMLEFT")
	    GameTooltip:ClearLines()
		GameTooltip:AddLine("flagRSP2 "..frspversion)
		GameTooltip:AddLine(L["FLAGRSP2_MM_TOOLTIP"])
	    GameTooltip:Show()
	end,
	OnLeave = function(self)
	    GameTooltip:Hide()
	end,
})

local icon = LibStub("LibDBIcon-1.0")
--icon:Register("flagRSP2", ldb, flagRSP2LDBI)

--Functions
function flagRSP2:OnUpdateFuBarTooltip()
	GameTooltip:AddLine("flagRSP2 v" .. GetAddOnMetadata("flagRSP2", "Version"));
	GameTooltip:AddLine(L["FLAGRSP2_MM_TOOLTIP"]);
	fontfile, fontsize, fontflags = GameTooltipTextLeft1:GetFont();
	GameTooltipTextLeft1:SetFont(fontfile, 15, "OUTLINE");
	fontfile, fontsize, fontflags = GameTooltipTextLeft2:GetFont();
	GameTooltipTextLeft2:SetFont(fontfile, 13, "OUTLINE");
	GameTooltipTextLeft2:SetTextColor(1, 1, 1);
end

function flagRSP2:OnInitialize()
	FRSPLOADED = 0;
    currenttime = time();

	flagRSP2_Frame:Show();
	flagRSP2.db = LibStub("AceDB-3.0"):New("flagRSP2DB", flagRSP2.defaults)
	LibStub("AceConfig-3.0"):RegisterOptionsTable("flagRSP2", flagRSP2.options, "rsp")
	local ACD3 = LibStub("AceConfigDialog-3.0")
	LibStub("AceConfigDialog-3.0"):AddToBlizOptions("flagRSP2", nil, nil, "frsp2options")
	if (flagRSP2.db.char.flagRSP2DescAutoDBCleanCheck) then
		flagRSP2PurgeOldDB()
	end
	flagRSP2Options_Initialize()
	icon:Register("flagRSP2", ldb, flagRSP2.db.char.minimap)
	_G.SLASH_FRSP1 = "/rsp" 
    _G.SlashCmdList["FRSP"] = flagRSP2SlashCommandHandler
	tinsert(UISpecialFrames, "flagRSP2Player_Frame")
	tinsert(UISpecialFrames, "flagRSP2Viewer_Frame")
	--tinsert(UISpecialFrames, "flagRSP2Info_Frame")
	
	if flagRSP2.db.char.flagRSP2OptionsShowCharacterButton then
		flagRSP2CharacterAnchor:Show()
	else
		flagRSP2CharacterAnchor:Hide()
	end
	
	flagRSP2Info:SetBackdrop({bgFile = [=[Interface\ChatFrame\ChatFrameBackground]=], edgeFile = [=[Interface\Addons\flagRSP2\images\edgefile.tga]=], level = '0', edgeSize = 6, insets = {top = 4, left = 4, bottom = 4, right = 4}})
	flagRSP2Info:SetBackdropColor(0, 0, 0, 0.5)
	flagRSP2Info:SetBackdropBorderColor(0, 0, 0, 1)
	flagRSP2Info_Frame:SetMinResize(220,125);

	--flagRSP2Info_FrameResizeBottomRight:SetBackdrop({edgeFile = [=[Interface\ChatFrame\ChatFrameBorder]=], level = '0', insets = {top = -2, left = -2, bottom = -2, right = -2}})

	--I really do not like this here.  Ultimately I would love to build the frames from Lua like I have done with CleanMinimap.
	flagRSP2Viewer_SearchText:SetText(L["FLAGRSP2_SEARCH_TEXT"])
end

function flagRSP2:OnEnable()
	flagRSP2HookOnTooltipSetUnit(GameTooltip, flagRSP2UnitMouseOver, 1);
    flagRSP2:RegisterEvent("UPDATE_MOUSEOVER_UNIT");
	flagRSP2:RegisterEvent("CHAT_MSG_CHANNEL");
	flagRSP2:RegisterEvent("PLAYER_TARGET_CHANGED");
	flagRSP2:RegisterEvent("PLAYER_REGEN_DISABLED");
	flagRSP2:RegisterEvent("PLAYER_REGEN_ENABLED");
end

function flagRSP2:OnDisable()
	DEFAULT_CHAT_FRAME:AddMessage("|cffB100DD" .. L["FLAGRSP2_LUA_DISABLE_ERROR"]);
	flagRSP2UnhookOnTooltipSetUnit(GameTooltip, flagRSP2UnitMouseOver, 1);
	LeaveChannelByName(comm_channel);
	flagRSP2:UnregisterAllEvents();
end

function flagRSP2:JoinCommChan()
	if (time() - timeatloading > 60) then
		if (chanwarned == 0) then
			JoinChannelByName(comm_channel, "", -1);
		end
		cid, channame = GetChannelName(comm_channel);
		if (cid == 0 or cid == nil) and (chanwarned == 0) then
			DEFAULT_CHAT_FRAME:AddMessage("|cffB100DD" .. L["FLAGRSP2_LUA_CHANNEL_ERROR"]);
			chanwarned = 1;
		end
	end
end

function flagRSP2:CHAT_MSG_CHANNEL(event, ...)
	local message, sender, language, channelString, target, flags, arg7, channelNumber, channelName, arg9 = ...;
	if string.lower(channelName) == string.lower(comm_channel) then
		--The DRUNK ...hic! code.
		sober = string.gsub(message, " ...hic!", "");
		flaggedChanHandle(sober, sender);
	end
	cid, channame = GetChannelName(comm_channel);
	if (cid == 0 or cid == nil) then
		flagRSP2:JoinCommChan();			
	end
end

function flagRSP2:PLAYER_TARGET_CHANGED()
	cName = UnitName("target");
	if (cName == nil and flagRSP2.db.char.flagRSP2OptionsStickyDescCheck == false) then
		flagRSP2Info_Frame:Hide();
	end
	if (FlagList[rName][cName] ~= nil and UnitIsPlayer("target")) then
		if (flagRSP2.db.char.flagRSP2OptionsTargetDescCheck == true) then
			flagRSP2ShowDesc(cName);
		end
	else
		if (flagRSP2.db.char.flagRSP2OptionsStickyDescCheck == false) then
			flagRSP2Info_Frame:Hide();
		end
	end
end

function flagRSP2:PLAYER_REGEN_DISABLED()
	if (FRSPLOADED == 1) then
		if (flagRSP2.db.char.flagRSP2OptionsHideCombatCheck == true) then
			rspcombat = 1;
			flagRSP2Info_Frame:Hide();
		else
			rspcombat = 0;
		end
	end
end

function flagRSP2:PLAYER_REGEN_ENABLED()
	if (FRSPLOADED == 1) then
		if (flagRSP2.db.char.flagRSP2OptionsHideCombatCheck == true) then
			rspcombat = 0;
		else
			rspcombat = 0;
		end
	end
end

function flagRSP2:UPDATE_MOUSEOVER_UNIT()
	newtime = time();
	temptime = currenttime + 300;
	if (newtime >= temptime) then
		currenttime = newtime;
		flagRSP2CharUpdate("timedupdate");
		dpcooldown = 0;
	end
	cid, channame = GetChannelName(comm_channel);
	if (cid == 0 or cid == nil) then
		flagRSP2:JoinCommChan();
	end
	if (flagRSP2.db.char.flagRSPUpgradeNote == true) then
		DEFAULT_CHAT_FRAME:AddMessage("New FlagRSP2 2.4 Features: The |cffe6e900Character Profile|r and |cffe6e900Viewer|r can now be accessed through the character screen.(By default, press C on your keyboard.)  Click the |cffe6e900Character Profile|r |cff9c6700button|r at the bottom of the character's paper doll.  Access the FlagRSP2 options by pressing Escape to open the game menu and clicking |cff9c6700Interface|r|cffe6e900->|r|cff9c6700AddOns tab|r|cffe6e900->|r|cff9c6700FlagRSP2|r.  This message will only be shown once.")
		flagRSP2.db.char.flagRSPUpgradeNote = false
	end
end

function flagRSP2:GetMessage()
    return flagRSP2.message
end

function flagRSP2:SetMessage(newValue)
    flagRSP2.message = newValue
end

function flagRSP2SlashCommandHandler(cmd)
	if (cmd == "" or cmd == nil or cmd == "options") then
		InterfaceOptionsFrame_OpenToCategory("flagRSP2")
	end
	if (cmd == "cv") then
		flagRSP2SetClearView();
	end
	if (cmd == "character") then
		if (flagRSP2Player_Frame:IsVisible() or flagRSP2Viewer_Frame:IsVisible()) then
			if not (flagRSP2Player_Frame:IsVisible()) then
				frameTop = (GetScreenHeight() - getglobal(currentwindow):GetTop()) * -1;
				flagRSP2Player_Frame:SetPoint("TOPLEFT", UIParent, "TOPLEFT", getglobal(currentwindow):GetLeft(), frameTop);
			end
			flagRSP2Player_Frame:Hide();
			flagRSP2Viewer_Frame:Hide();
		else
			flagRSP2Player_Frame:Show();
		end
	end
end

function flagRSP2UnitMouseOver(unit, name, realm)
--CODING MINE FIELD - Clean up in progress!
	local fontfile, fontsize, fontflags = GameTooltipHeaderText:GetFont();
	GameTooltipTextLeft1:SetFont(fontfile, fontsize, fontflags);
	local fontfile, fontsize, fontflags = GameTooltipText:GetFont();
	GameTooltipTextLeft2:SetFont(fontfile, fontsize, fontflags);
	cName = UnitName(unit);
	--Use the enhanced colorful tooltip or the default one?
	if (flagRSP2.db.char.flagRSP2TooltipLightModeCheck == false) then
		local tooltip_info = flagRSP2FormatTooltip(unit)
		--I love if then.

		local levelLine, matched;
		if (GameTooltipTextLeft2:GetText() == nil) then
			GameTooltip:Hide();
		else
			levelLine, matched = string.gsub(GameTooltipTextLeft2:GetText(), (L["FLAGRSP2_LUA_LEVELFINDER"]..".*"), "");
			if (matched == 1) then
				levelLine = 2;
			else
				if (GameTooltipTextLeft3:GetText()) then
					levelLine, matched = string.gsub(GameTooltipTextLeft3:GetText(), (L["FLAGRSP2_LUA_LEVELFINDER"]..".*"), "");
					if (matched == 1) then
						levelLine = 3;
					else
						levelLine = nil;
					end
				else
					levelLine = nil;
				end
			end
		end
		
		if (UnitIsPlayer(unit)) then
			nametext = flagRSP2GenerateName(cName);
		else
			nametext = cName;
		end
		leveltext = (tooltip_info['level'] or "") .. " |r" .. "|cffFFFFFF" .. (tooltip_info['race'] or "") .. " |r" .. (tooltip_info['class'] or "") .. " |r" .. (tooltip_info['elite'] or "") .. "|r" .. "|cff888888" .. (tooltip_info['corpse'] or "") .. "|r"
		if (levelLine) then
			--At this point, they MAY not a player.  It does not matter since the tool tip will be recleared for players any way since there is no extra information to grab.
			--NPC with description.
			if (levelLine == 3 and UnitIsPlayer(unit) == nil) then
				NPCDESC = GameTooltipTextLeft2:GetText();
				GameTooltipTextLeft1:SetText(tooltip_info['c_name'] .. nametext .. "|r");
				GameTooltipTextLeft2:SetText(tooltip_info['c_description'] .. NPCDESC .. "|r");
				GameTooltipTextLeft3:SetText(leveltext);
			end
			--NPC, but no NPC description.
			if (levelLine == 2 and UnitIsPlayer(unit) == nil) then
				GameTooltipTextLeft1:SetText(tooltip_info['c_name'] .. nametext .. "|r");
				GameTooltipTextLeft2:SetText(leveltext);
			end
		end

		--Playing with the GameTooltip is a very messy process.  This is around the third or fourth revision of the code to modify the tooltip.
		--Handles both users of FlagRSP2 and non-users.
		if (UnitIsPlayer(unit)) then
			GTTNL = 0;
			GTTTable = {};
			--Display description frame on targeting the player if the character has a profile.
			if (FlagList[rName][cName] ~= nil and flagRSP2.db.char.flagRSP2OptionsTargetDescCheck == false) then
				flagRSP2ShowDesc(cName);
			end
			GameTooltipTextLeft1:SetText(tooltip_info['c_name'] .. nametext .. "|r");
			--Character Name
			GTTNL = 1;
			GTTTable[GTTNL] = tooltip_info['c_name'] .. nametext .. "|r";
			--Title with cheesy check.
			if (FlagList[rName][cName] ~= nil and flagRSP2.db.char.flagRSP2TooltipShowTitleCheck == true) then
				titletext = flagRSP2GenerateTitle(cName);
				if (titletext) then
					GTTNL = GTTNL + 1;
					GTTTable[GTTNL] = titletext;
				end
			end
			--Character Level
			GTTNL = GTTNL + 1;
			GTTTable[GTTNL] = leveltext;
			--Guild Information
			if (GetGuildInfo(unit) and flagRSP2.db.char.flagRSP2TooltipShowGuildCheck) then
				--Show at Bottom
				GTTNL = GTTNL + 1;
				GTTTable[GTTNL] = "|cffFFFFFF" .. GetGuildInfo(unit) .. "|r";
			end
			--Status Information(Role Players)
			if (flagRSP2.db.char.flagRSP2TooltipShowStatusCheck == true and FlagList[rName][cName] ~= nil) then
				if ((FlagList[rName][cName]["RPFlag"] ~= nil and FlagList[rName][cName]["RPFlag"] ~= "") or (FlagList[rName][cName]["CSTATUS"] ~= nil and FlagList[rName][cName]["CSTATUS"] ~= ""  and FlagList[rName][cName]["CSTATUS"] ~= 0)) then
					flagRSP2GenerateStatusLine(unit, cName);
					if (finalline ~= "false") then
							GTTNL = GTTNL + 1;
							GTTTable[GTTNL] = finalline;
					end
				end
			end
			--Role Player with hidden description?
			if (FlagList[rName][cName] ~= nil and FlagList[rName][cName]["HideDesc"] == 1) then
				GTTNL = GTTNL + 1;
				GTTTable[GTTNL] = "|cffFEF1B5" .. "(Description Hidden)";
			end
			if (UnitIsPVP(unit) and flagRSP2.db.char.flagRSP2TooltipShowPvPCheck == true) then
				GTTNL = GTTNL + 1;
				GTTTable[GTTNL] = "|cffFFFFFF" .. "PvP";
			end
			if (levelLine == 2 and UnitInParty(unit) and GameTooltip:NumLines() > 2) then
				GTTNL = GTTNL + 1;
				GTTTable[GTTNL] = "|cffFFFFFF" .. GameTooltipTextLeft3:GetText();
			end
			--Add Developer or Donator status.
			dName = {"Jenine", "Azxiana", "Trela", "Mihau"};
			for i,v in pairs(dName) do
				if (rName == "Feathermoon" and cName == v) then
					GTTNL = GTTNL + 1;
					GTTTable[GTTNL] = "|cffff00c6" .. " FlagRSP2 Developer"
				end
			end
			if (rName == "Moon Guard" and cName == "Kíssy") then
				GTTNL = GTTNL + 1;
				GTTTable[GTTNL] = "|cffff00c6" .. " FlagRSP2 Developer"
			end
			--Remove unused GameTooltipTextLefts.
			if (GTTNL < GameTooltip:NumLines()) then
				for i = GTTNL + 1, GameTooltip:NumLines() do
					getglobal("GameTooltipTextLeft" ..  i):Hide();
				end
			end
			--Add more GameTooltipTextLefts.
			if (GTTNL > GameTooltip:NumLines()) then
				for i = 1, GTTNL - GameTooltip:NumLines() do
					GameTooltip:AddLine(" ");
				end
			end
			--Take each line from GTTTable and assign it to the proper GameTooltipTextLeft.
			for i = 1, GTTNL do
				getglobal("GameTooltipTextLeft" .. i):SetText(GTTTable[i]);
			end
			--Hide the description frame if sticky and target descriptions are turned off.
			if (FlagList[rName][cName] == nil and flagRSP2.db.char.flagRSP2OptionsStickyDescCheck == false and flagRSP2.db.char.flagRSP2OptionsTargetDescCheck == false) then
				flagRSP2Info_Frame:Hide();
			end
		else
			--Hide the description frame if sticky and target descriptions are turned off.
			if (flagRSP2.db.char.flagRSP2OptionsStickyDescCheck == false and flagRSP2.db.char.flagRSP2OptionsTargetDescCheck == false) then
				flagRSP2Info_Frame:Hide();
			end
		end
		--GameTooltip:Show();
	--Default tooltip with extra information.
	elseif (FlagList[rName][cName] ~= nil and UnitIsPlayer(unit)) then
		--Show GameTooltip first to allow all of its new properties to populate such as its points.
		--GameTooltip:Show();
		nametext = flagRSP2GenerateName(cName);
		GameTooltipTextLeft1:SetText(nametext);
		GameTooltip:AddLine()
		if (flagRSP2.db.char.flagRSP2TooltipShowTitleCheck == true) then
			titletext = flagRSP2GenerateTitle(cName);
			if (titletext) then
				GameTooltip:AddLine(titletext);
			end
		end
		if (flagRSP2.db.char.flagRSP2TooltipShowStatusCheck == true) then
			if ((FlagList[rName][cName]["RPFlag"] ~= nil and FlagList[rName][cName]["RPFlag"] ~= "") or (FlagList[rName][cName]["CSTATUS"] ~= nil and FlagList[rName][cName]["CSTATUS"] ~= ""  and FlagList[rName][cName]["CSTATUS"] ~= 0)) then
				flagRSP2GenerateStatusLine(unit, cName);
				if (finalline ~= "false") then
					GameTooltip:AddLine(finalline);
				end
			end
		end
		if (FlagList[rName][cName] ~= nil and flagRSP2.db.char.flagRSP2OptionsTargetDescCheck == false) then
			flagRSP2ShowDesc(cName);
		end
	else
		if (flagRSP2.db.char.flagRSP2OptionsStickyDescCheck == false and flagRSP2.db.char.flagRSP2OptionsTargetDescCheck == false) then
			flagRSP2Info_Frame:Hide();
		end
	end
end

function flagRSP2GenerateName(cName)
	if (flagRSP2.db.char.flagRSP2TooltipShowAddNameCheck == true and FlagList[rName][cName] ~= nil) then
		if (FlagList[rName][cName]["AN1"] ~= nil and FlagList[rName][cName]["AN1"] ~= "") then
			if (FlagList[rName][cName]["AN3"] ~= nil and FlagList[rName][cName]["AN3"] ~= "") then
				return FlagList[rName][cName]["AN1"] .. " " .. cName .. " " .. FlagList[rName][cName]["AN3"]
			else
				return FlagList[rName][cName]["AN1"] .. " " .. cName
			end
		else
			if (FlagList[rName][cName]["AN3"] ~= nil and FlagList[rName][cName]["AN3"] ~= "") then
				return cName .. " " .. FlagList[rName][cName]["AN3"]
			else
				return cName
			end
		end
	else
		return cName
	end
end

function flagRSP2GenerateTitle(cName)
	if (FlagList[rName][cName] ~= nil) then
		if (FlagList[rName][cName]["Title"] ~= nil and FlagList[rName][cName]["Title"] ~= "") then
			local titletext = FlagList[rName][cName]["Title"];
			if (flagRSP2.db.char.flagRSP2OptionsWordLimitCheck == true) then
				local words = 0;
				local strstart = 0;
				local strend = 0;
				for i = 1, string.len(FlagList[rName][cName]["Title"]) do
					if (string.find(FlagList[rName][cName]["Title"], " ", strstart) ~= nil) then
						strstart = string.find(FlagList[rName][cName]["Title"], " ", strstart) + 1
						words = words + 1;
					end
					if (words == 8) then
						strend = strstart - 1;
					end
				end
				if (words > 8) then
					titletext = string.sub(FlagList[rName][cName]["Title"], 1, strend - 1) .. "...";
				end
			end
			return "|cffFFFFFF" .. "\"" .. "|cffFEF1B5" .. titletext .. "|r" .. "|cffFFFFFF" .. "\"";
		end
	end
end

function flagRSP2GenerateStatusLine(unit, cName)
	local norpstatus = 0;
	local nocsstatus = 0;
	local rpline = "";
	local rpt = {L["FLAGRSP2_LUA_RP"],L["FLAGRSP2_LUA_CRP"],L["FLAGRSP2_LUA_FRP"],L["FLAGRSP2_LUA_BRP"],L["FLAGRSP2_LUA_MRP"],}
	local cst = {L["FLAGRSP2_LUA_OOC"], L["FLAGRSP2_LUA_IC"], L["FLAGRSP2_LUA_LFC"], L["FLAGRSP2_LUA_ST"],}
	if (rpt[FlagList[rName][cName]["RPFlag"]] ~= nil and cst[FlagList[rName][cName]["CSTATUS"]] ~= nil) then
		finalline = "|cffFEF1B5".."<"..rpt[FlagList[rName][cName]["RPFlag"]].. ", " ..cst[FlagList[rName][cName]["CSTATUS"]]..">"
	--RP Only
	elseif (rpt[FlagList[rName][cName]["RPFlag"]] ~= nil and cst[FlagList[rName][cName]["CSTATUS"]] == nil) then
		finalline = "|cffFEF1B5".."<"..rpt[FlagList[rName][cName]["RPFlag"]]..">"
	--CS Only
	elseif (rpt[FlagList[rName][cName]["RPFlag"]] == nil and cst[FlagList[rName][cName]["CSTATUS"]] ~= nil) then
		finalline = "|cffFEF1B5".."<"..cst[FlagList[rName][cName]["CSTATUS"]]..">"
	else
		finalline = "false"
	end
	return finalline;
end

function flagRSP2ShowDesc(cName)
	if (cName == "" or cName == nil) then
		return
	end
	if (FlagList[rName][cName]["HideDesc"] == nil) then
		FlagList[rName][cName]["HideDesc"] = 0;
	end
	if (rspcombat == 0 and FlagList[rName][cName]["HideDesc"] == 0) then
		dsnametext = "|cff00AAFF"..flagRSP2GenerateName(cName)
		if (FlagList[rName][cName]["Desc"] ~= nil and flagRSP2.db.char.flagRSP2OptionsShowDescCheck == true) then
			fontfile, fontsize, fontflags = flagRSP2InfoDesc:GetFont();
			flagRSP2InfoDesc:SetFont(fontfile, "12", fontflags);
			local i = 1;
			local desctext = "";
			while FlagList[rName][cName]["Desc"]["A"][i] ~= nil do
				desctext = desctext .. FlagList[rName][cName]["Desc"]["A"][i];
				i = i + 1;
			end
			blanktext = string.gsub(desctext, "\n", "");
			blanktext = string.gsub(blanktext, "\\l", "");
			if (blanktext ~= "") then
				largestwidth = 0;
				--flagRSP2Info:SetBackdropColor(0.0, 0.0, 0.0, 0.5);
				fontfile, fontsize, fontflags = flagRSP2InfoName:GetFont();
				
				--Name Line
				flagRSP2InfoName:SetFont(fontfile, "20", fontflags);
				flagRSP2InfoName:SetText(dsnametext);
				largestwidth = flagRSP2InfoName:GetWidth();
				
				--Title Line
				if (flagRSP2.db.char.flagRSP2DescShowTitleCheck == true) then
					if (FlagList[rName][cName]["Title"] ~= nil or FlagList[rName][cName]["Title"] ~= "") then
						flagRSP2InfoTitle:SetText(FlagList[rName][cName]["Title"]);
					else
						flagRSP2InfoTitle:SetText("");
					end
				else
					flagRSP2InfoTitle:SetText("");
				end
				flagRSP2InfoTitle:SetWidth(flagRSP2InfoTitle:GetStringWidth() + 2);
				if (flagRSP2InfoTitle:GetWidth() > 300) then
					flagRSP2InfoTitle:SetWidth(300);
				end
				if (flagRSP2InfoTitle:GetWidth() > largestwidth) then
					largestwidth = flagRSP2InfoTitle:GetWidth();
				end
				
				--Status Line
				if (flagRSP2.db.char.flagRSP2DescShowStatusCheck == true) then
				flagRSP2GenerateStatusLine(unit, cName);
					if (finalline ~= "false") then
						flagRSP2InfoStatus:SetText(finalline);
					else
						flagRSP2InfoStatus:SetText("");
					end
					if (flagRSP2InfoStatus:GetWidth() > largestwidth) then
						largestwidth = flagRSP2InfoStatus:GetWidth();
					end
				else
					flagRSP2InfoStatus:SetText("");
				end
			
				if (largestwidth > 185) then
					flagRSP2Info_Frame:SetWidth(largestwidth + 40);
				else
					flagRSP2Info_Frame:SetWidth(220);
				end
				
				--Description Line
				desctext = string.gsub(desctext, "\\l", "\n");
				flagRSP2InfoDesc:SetText(desctext);
				flagRSP2InfoDesc:SetWidth(flagRSP2Info_Frame:GetWidth() - 40);
				flagRSP2InfoDescSizer:SetText(desctext);
				flagRSP2InfoDescSizer:SetWidth(flagRSP2Info_Frame:GetWidth() - 40);
				flagRSP2InfoDescScrollFrame:SetWidth(flagRSP2InfoDesc:GetWidth());
				if (flagRSP2InfoDescSizer:GetHeight() < 275) then
					flagRSP2InfoDescScrollFrame:SetHeight(flagRSP2InfoDescSizer:GetHeight());
				else
					flagRSP2InfoDescScrollFrame:SetHeight(275);
				end
				if (flagRSP2InfoName:GetHeight() + flagRSP2InfoDescScrollFrame:GetHeight() + flagRSP2InfoTitle:GetHeight() + flagRSP2InfoStatus:GetHeight() + 20 > 125) then
					height = flagRSP2InfoName:GetHeight() + flagRSP2InfoDescScrollFrame:GetHeight() + flagRSP2InfoTitle:GetHeight() + flagRSP2InfoStatus:GetHeight() + 20
				else
					height = 125
				end
				flagRSP2Info_Frame:SetHeight(height);
				if (not flagRSP2Info_Frame:IsShown()) then
					if (UIParent:IsVisible()) then
						flagRSP2Info_Frame:SetParent(UIParent);
						flagRSP2Info_Frame:Show();
					else
						flagRSP2Info_Frame:SetParent(WorldFrame);
						flagRSP2Info_Frame:Show();
					end
					flagRSP2Info_Frame:SetClampedToScreen();
				end
			else
				if (flagRSP2.db.char.flagRSP2OptionsStickyDescCheck == false) then
					flagRSP2Info_Frame:Hide();
				end
			end
		else
			if (flagRSP2.db.char.flagRSP2OptionsStickyDescCheck == false and flagRSP2.db.char.flagRSP2OptionsTargetDescCheck == false) then
				flagRSP2Info_Frame:Hide();
			end
		end
	end
end

function flagRSP2FormatTooltip(unit)
	local race_f, class_f, elite_f, level_f, corpse
	local color_name, color_description, color_level

	if (UnitRace(unit) and UnitIsPlayer(unit)) then
		--race, it is a player
		race_f = UnitRace(unit);
	elseif (UnitPlayerControlled(unit)) then
		--creature family, its is a pet
		race_f = UnitCreatureFamily(unit);
	else
		--creature type, it is a mob
		if (UnitCreatureType(unit) == "Not specified") then
			race_f = ""
		else
			race_f = UnitCreatureType(unit);
		end
	end

	if (UnitClassBase(unit) and UnitIsPlayer(unit)) then
		local class, classFileName = UnitClassBase(unit)
		local classTextColor = RAID_CLASS_COLORS[classFileName]
		if (classTextColor and UnitHealth(unit) > 0) then
			class_f = "|cff" .. format("%02X%02X%02X", 255 * classTextColor.r, 255 * classTextColor.g, 255 * classTextColor.b) .. class
		elseif (UnitHealth(unit) > 0) then
			class_f = "|cffFFFFFF" .. class
		else
			class_f = "|cff888888" .. class
		end
	end

	if (UnitHealth(unit) > 0) then
		elite_f = unittype[UnitClassification(unit)]
	end

	if (UnitPlayerControlled(unit)) then
		if (UnitCanAttack(unit, "player") and UnitCanAttack("player", unit)) then
			--red, hostile, both can attack
				GameTooltip:SetBackdropColor(0.5, 0, 0, 0.5);
				color_name = "|cffFF0000";
				color_description = "|cffDD0000";
		elseif (not UnitCanAttack(unit, "player") and UnitCanAttack("player", unit)) then
			--yellow, neutral, only I can attack
				GameTooltip:SetBackdropColor(0.5, 0.5, 0, 0.5);
				color_name = "|cffFFFF00";
				color_description = "|cffCCCC00";
		elseif (UnitCanAttack(unit, "player") and not UnitCanAttack("player", unit)) then
			--purple, caution, only they can attack
				GameTooltip:SetBackdropColor(0.5, 0, 0.5, 0.5);
				color_name = "|cffFF66FF";
				color_description = "|cffBB55BB";
		elseif (not UnitCanAttack(unit, "player") and not UnitCanAttack("player", unit)) then
			if (UnitIsPVP(unit)) then
				--green, friendly pvp, neither can attack
					GameTooltip:SetBackdropColor(0, 0, 0.5, 0.5);
					color_name = "|cff00FF00";
					color_description = "|cff00AA00";
			else
				--blue, friendly, neither can attack
					GameTooltip:SetBackdropColor(0, 0, 0.5, 0.5);
					color_name = "|cff00AAFF";
					color_description = "|cff0088FF";
			end
		end
	elseif (UnitReaction(unit, "player") and UnitReaction(unit, "player") <= 3) then
		--red, they are hostile
			GameTooltip:SetBackdropColor(0, 0, 0, 0.5);
			color_name = "|cffFF0000";
			color_description = "|cffDD0000";
	elseif (UnitReaction(unit, "player") and UnitReaction(unit, "player") == 4) then
		--yellow, they are neutral
			GameTooltip:SetBackdropColor(0, 0, 0, 0.5);
			color_name = "|cffFFFF00";
			color_description = "|cffCCCC00";
	else
		if (UnitIsPVP(unit)) then
			--green, pvp enabled friend
			GameTooltip:SetBackdropColor(0, 0, 0, 0.5);
			color_name = "|cff00FF00";
			color_description = "|cff00AA00";
		else
			--blue, they are friendly
			GameTooltip:SetBackdropColor(0, 0, 0, 0.5);
			color_name = "|cff00AAFF";
			color_description = "|cff0088FF";
		end
	end

	if (UnitIsTapped(unit)and (not UnitIsTappedByPlayer(unit))) then
		color_name = "|cff888888";
		color_description = "|cff888888";
	elseif (UnitIsTappedByPlayer(unit)) then
		GameTooltip:SetBackdropColor(0, 0, 0, 0.5);
		color_name = "|cffFF0000";
		color_description = "|cffDD0000";
	end

	if (UnitLevel(unit) and UnitLevel(unit) >= 1) then
		text_level = L["FLAGRSP2_LUA_LEVELFINDER"].." "..UnitLevel(unit);
	else
		text_level = L["FLAGRSP2_LUA_LEVELFINDER"].." ??";
	end

	local levelDiff = UnitLevel(unit) - UnitLevel("player");
	if (UnitFactionGroup(unit) ~= UnitFactionGroup("player")) then
		if ( levelDiff >= 5 or UnitLevel(unit) == -1) then
			color_level = "|cffFF0000";
		elseif ( levelDiff >= 3 ) then
			color_level = "|cffFF6600";
		elseif ( levelDiff >= -2 ) then
			color_level = "|cffFFFF00";
		elseif ( -levelDiff <= GetQuestGreenRange() ) then
			color_level = "|cff00FF00";
		else
			color_level = "|cff888888";
		end
	else
		color_level = "|cffFFCC00";
	end

	if (UnitHealth(unit) == 0) then
		corpse = "Corpse";
		race_f = "|cff888888"..(race_f or "");
		elite_f = "|cff888888"..(elite_f or "");
		color_name = "|cff888888";
		color_description = "|cff888888";
		color_level = "|cff888888";
	else
		corpse = "";
	end

	level_f = color_level .. text_level	

	return {race = race_f, class = class_f, elite = elite_f, level = level_f, c_name = color_name, c_description = color_description, c_level = color_level, corpse = corpse}
end

--Logging function that logs how many characters are parsed over a given time period.
local totalchar = 0
local charstart = 0
local charstop = 0
local calculating = false
function frspcalcband(enable)
	if enable == "start" then
		totalchar = 0
		calculating = true
		charstart = time()
	elseif enable == "stop" then
		charstop = time()
		print("Parsed: "..totalchar.." characters.  Started: "..charstart..".  Stopped: "..charstop)
	end
end

function flaggedChanHandle(arg1, arg2)
	if string.find(arg1,"<") == nil then 
		return;
	end
	if calculating == true then
		totalchar = totalchar + strlen(arg1)
	end
	--IF BLOCK 1 START
	if string.find(string.sub(arg1,2,string.len(arg1)),"<") ~= nil then 
	--More than one option in the string.
      
      
		firstBrack = string.find(string.sub(arg1,2,string.len(arg1)),"<");

		firstComm = string.sub(arg1,1,firstBrack);
		rest = string.sub(arg1,firstBrack+1, string.len(arg1));

      
		flaggedChanHandle(firstComm, arg2);
		flaggedChanHandle(rest, arg2);
	
	--IF BLOCK 1 ELSEIF 1 START
	elseif string.find(string.sub(arg1,2,string.len(arg1)),"<") == nil then 
		--Only one command remaining, parse as normal.


		--Substitute encoded brackets for old compatibility. - Not needed any more?  I have not seen these used in forever.  Alexia.
		arg1 = string.gsub(arg1, "\\%(", "<");
		arg1 = string.gsub(arg1, "\\%)", ">");
			
		--IF BLOCK 2 START
 		--Character Title
		if string.sub(arg1, 1, 3) == "<T>" then
			RPaddFlag("Title", string.sub(arg1, 4, string.len(arg1)), arg2);

		--Roleplay Status
		elseif string.sub(arg1,1,3) == "<RP" and string.sub(arg1,4,4) ~= "T"  then
			local RPStyle = string.sub(arg1,4,4);
			if (tonumber(RPStyle) ~= nil) then
				RPaddFlag("RPFlag", tonumber(RPStyle), arg2)
			end

		--Character Status
		elseif string.sub(arg1, 1, 3) == "<CS" then
			local cStatus = string.sub(arg1,4,4);
			if (tonumber(cStatus) ~= nil) then
				RPaddFlag("CSTATUS", tonumber(cStatus), arg2)
			end

		--Additional Name
		elseif string.sub(arg1, 1, 3) == "<AN" then
			local cAN = string.sub(arg1,4,4);
			if (tonumber(cAN) ~= nil) then
				RPaddFlag("AN", tonumber(cAN), arg2, string.sub(arg1, 6, string.len(arg1)));
			end

		--Description Version/Revision
		elseif (string.sub(arg1, 1, 4) == "<DV>") then
			local n = tonumber(string.sub(arg1, 5, string.len(arg1)));
			if (n ~= nil) then
				RPaddFlag("DV", n, arg2);
			end

	 	--Description Pull
		elseif (arg1 == ("<DP>" .. UnitName("player")) or arg1 == ("<DPULL>" .. UnitName("player"))) then
			local saveddesc = string.gsub(flagRSP2.db.char.flagRSP2OptionsPhysDesc, "\n", "\\l") .. "\\eod";
			if (dpcooldown == 0) then
				if (strlen(saveddesc) > 245) then
					local nummess = strlen(saveddesc) / 245;
					if (mod(strlen(saveddesc), 245) > 0) then
						nummess = ceil(nummess)
					end
					for i=1, nummess do
						dpmessage = string.format("<D%02.f>%s", i, string.sub(saveddesc, (245 * i) - 244, 245 * i))
						flagRSP2:AddToBuffer(dpmessage);
					end
					dpcooldown = 1;
				else
					dpmessage = "<D01>" .. string.sub(saveddesc, 1, 245)
					flagRSP2:AddToBuffer(dpmessage);
					dpcooldown = 1;
				end
			end
		--Description Pull Throttler Add
		elseif (string.sub(arg1, 1, 4) == "<DP>") then
			local matchfound = false
			for index, value in pairs(dpthrottle) do
				if (value == string.sub(arg1, 5, string.len(arg1))) then
					matchfound = true
				end
			end
			if (not matchfound) then
				dpbuffersize = getn(dpthrottle);
				dpbuffersize = dpbuffersize + 1;
				dpthrottle[dpbuffersize] = string.sub(arg1, 5, string.len(arg1));
			end
			matchfound = false

		elseif (string.sub(arg1, 1, 2) == "<D" and tonumber(string.sub(arg1, 3, 4)) ~= nil and flagRSP2.db.char.flagRSP2OptionsSaveDescCheck == true) then
			RPaddDesc(tonumber(string.sub(arg1,3,4)), string.sub(arg1, 6, string.len(arg1)), arg2);
 
		elseif (string.sub(arg1, 1, 2) == "<P" and tonumber(string.sub(arg1, 3, 4)) ~= nil and flagRSP2.db.char.flagRSP2OptionsSaveDescCheck == true) then
			RPaddDesc(tonumber(string.sub(arg1, 3, 4)), string.sub(arg1, 6, string.len(arg1)), arg2, true);
		end
	end
end

function flagRSP2:AddToBuffer(message)
	buffersize = getn(rspsendbuffer);
	buffersize = buffersize + 1;
	rspsendbuffer[buffersize] = message;
end

function flagRSP2:UpdateSendBuffer()
	polledtime = time();
	if (getn(rspsendbuffer) == 0) then
		buffersize = 0;
		bufferpos = 0;
	end
	if (polledtime >= (lasttime + 5)) then
		cid, channame = GetChannelName(comm_channel);
		if (rspsendbuffer[bufferpos] ~= nil) then
			local foundinbuffer = false
			for index, value in pairs(dpthrottle) do
				if (value == string.sub(rspsendbuffer[bufferpos], 5, string.len(rspsendbuffer[bufferpos]))) then
					foundinbuffer = true
					table.remove(dpthrottle, index)
				end
			end
			if (not foundinbuffer) then
				if (flagRSP2.db.char.flagRSP2OptionsAFKCheck) then
					if (UnitIsAFK("player") ~= 1) then
						SendChatMessage(rspsendbuffer[bufferpos], "CHANNEL", GetDefaultLanguage("player"), cid);
					end
				else
					SendChatMessage(rspsendbuffer[bufferpos], "CHANNEL", GetDefaultLanguage("player"), cid);
				end
			end
			foundinbuffer = false
		end
		lasttime = time();
		if (getn(rspsendbuffer) == bufferpos) then
			buffersize = 0;
			bufferpos = 0;
			rspsendbuffer = {};
		end
		bufferpos = bufferpos + 1;
	end
end

function RPaddFlag(flag, value, name, valuetwo)
	if flag == nil then 
		return;
	end
	if (FlagList[rName][name] == nil) then
		FlagList[rName][name] = {};
		FlagList[rName][name].timeStamp = time();
		FlagList[rName][name].faction = UnitFactionGroup("player");
	end
	if (flag == "RPFlag" or flag =="Title" or flag =="CSTATUS") then
		if FlagList[rName][name] == nil then
			FlagList[rName][name] = {};
		end
		FlagList[rName][name][flag] = value;
		FlagList[rName][name].timeStamp = time();
		FlagList[rName][name].faction = UnitFactionGroup("player");
	end 
	if (flag == "AN") then
		if FlagList[rName][name] == nil then
			FlagList[rName][name] = {};
		end
		if (value == 1 and valuetwo ~= nil) then
			FlagList[rName][name]["AN1"] = valuetwo;
		elseif (value == 3 and valuetwo ~= nil) then
			FlagList[rName][name]["AN3"] = valuetwo;
		end
		FlagList[rName][name].timeStamp = time();
		FlagList[rName][name].faction = UnitFactionGroup("player");
	end
	if (flag == "DV") then
		if (FlagList[rName][name][flag]) then
			if (value > -1 and FlagList[rName][name][flag] < value) then
				csm = "<DP>" .. name;
				flagRSP2:AddToBuffer(csm);
			end
		else
			if (value > -1) then
				csm = "<DP>" .. name;
				flagRSP2:AddToBuffer(csm);
			end
		end
		if (value == -1 and FlagList[rName][name]["Desc"] ~= nil) then
			FlagList[rName][name]["Desc"]["A"] = {};
		end
		FlagList[rName][name][flag] = value;
		FlagList[rName][name].timeStamp = time();
		FlagList[rName][name].faction = UnitFactionGroup("player");
	end
end

function RPaddDesc(num, text, name, rev, partial)
	if partial == nil then
		partial = false;
	end

	--flag = "Desc";
	desc = "A";

	if FlagList[rName][name] == nil then
		FlagList[rName][name] = {};
	end

	if FlagList[rName][name]["Desc"] == nil then
		FlagList[rName][name]["Desc"] = {};
	else
		--message("Description " .. name);
	end
	if FlagList[rName][name]["Desc"][desc] == nil then
		FlagList[rName][name]["Desc"][desc] = {};
		FlagList[rName][name]["Desc"][desc].complete = false;
	elseif (num == 1 and FlagList[rName][name]["Desc"][desc] ~= nil) then
		FlagList[rName][name]["Desc"][desc] = {};
		FlagList[rName][name]["Desc"][desc].complete = false;
	end

	FlagList[rName][name]["Desc"][desc][num] = text;

	FlagList[rName][name]["Desc"][desc].revision = rev;
   
	if not partial then
		FlagList[rName][name]["Desc"][desc].complete = true;
	end

	local i = 1;
	local lastPart;
	while FlagList[rName][name]["Desc"][desc][i] ~= nil do
		lastPart = string.sub(FlagList[rName][name]["Desc"][desc][i], string.len(FlagList[rName][name]["Desc"][desc][i])-3);

		if lastPart == "\\eod" then
			FlagList[rName][name]["Desc"][desc].complete = true;
			FlagList[rName][name]["Desc"][desc][i] = string.gsub(FlagList[rName][name]["Desc"][desc][i], "\\eod", "");
		end
      
		i = i + 1;
	end

	FlagList[rName][name].timeStamp = time();
	FlagList[rName][name].faction = UnitFactionGroup("player");
end

function flagRSP2PurgeOldDB()
	for key, value in next, FlagList[rName] do
		--I could just multiply by 86,400 seconds, but I separated it for easier code editing.
		if (value.timeStamp <= time() - (30 * 24 * 60 * 60)) then
			FlagList[rName][key] = nil;
		end
	end
end

function flagRSP2PurgeAllDB()
	FlagList[rName] = nil;
	ReloadUI();
end

function flagRSP2WindowChange(newwindow, oldwindow)
	--I hacked this code together with separate frames because the tab implementation in the WoW UI is annoying to implement.
	currentwindow = newwindow
	frameTop = (GetScreenHeight() - getglobal(oldwindow):GetTop()) * -1;
	getglobal(newwindow):SetPoint("TOPLEFT", UIParent, "TOPLEFT", getglobal(oldwindow):GetLeft(), frameTop);
	getglobal(oldwindow):Hide();
	getglobal(newwindow):Show();
	getglobal(oldwindow):SetWidth(472);
	getglobal(newwindow):SetWidth(472);
end

function flagRSP2SetClearView()
	if (UIParent:IsVisible()) then
		CloseAllWindows();
		for i = 1, FCF_GetNumActiveChatFrames() do
			getglobal("ChatFrame" .. i):SetParent(WorldFrame);
			getglobal("ChatFrame" .. i):SetScale(UIParent:GetScale());
			ChatFrameEditBox:SetParent(WorldFrame);
			ChatFrameEditBox:SetScale(UIParent:GetScale());
		end
		for index, value in pairs(DOCKED_CHAT_FRAMES) do
			chatTab = getglobal(value:GetName() .. "Tab");
			chatTab:SetParent(WorldFrame);
			chatTab:SetScale(UIParent:GetScale());
			chatTab:Show();
		end
		ChatFrameMenuButton:SetParent(WorldFrame);
		ChatFrameMenuButton:SetScale(UIParent:GetScale());
		GameTooltip:SetParent(WorldFrame);
		GameTooltip:SetScale(UIParent:GetScale());
		GameTooltip:SetFrameStrata("TOOLTIP");
		flagRSP2Info_Frame:SetParent(WorldFrame);
		flagRSP2Info_Frame:SetScale(UIParent:GetScale());
		flagRSP2ClearViewClose:Show();
		UIParent:Hide();
		FCF_OnUpdate(1);
	else
		for i = 1, FCF_GetNumActiveChatFrames() do
			getglobal("ChatFrame" .. i):SetParent(UIParent);
			getglobal("ChatFrame" .. i):SetScale(WorldFrame:GetScale());
			ChatFrameEditBox:SetParent(UIParent);
			ChatFrameEditBox:SetScale(WorldFrame:GetScale());
		end
		for index, value in pairs(DOCKED_CHAT_FRAMES) do
			chatTab = getglobal(value:GetName() .. "Tab");
			chatTab:SetParent(UIParent);
			chatTab:SetScale(WorldFrame:GetScale());
			chatTab:Show();
		end
		ChatFrameMenuButton:SetParent(UIParent);
		ChatFrameMenuButton:SetScale(WorldFrame:GetScale());
		GameTooltip:SetParent(UIParent);
		GameTooltip:SetScale(WorldFrame:GetScale());
		GameTooltip:SetFrameStrata("TOOLTIP");
		flagRSP2Info_Frame:SetParent(UIParent);
		flagRSP2Info_Frame:SetScale(WorldFrame:GetScale());
		flagRSP2ClearViewClose:Hide();
		UIParent:Show();
		FCF_OnUpdate(1);
	end
end

function flagRSP2CloneDatabase()
	--Coded by Xiaclo.
	FlagList.temp = {}
	for key, value in next, FlagList[rName] do
		FlagList.temp[#FlagList.temp + 1] = {(value.AN1 or ""), key, (value.AN3 or "")}
	end
end

function flagRSP2ViewerOnShow()
	--Coded by Xiaclo.
	local index = 1
	local index, offset, search = 1, math.floor(flagRSP2ViewerSlider:GetValue() + 0.5), string.lower(flagRSP2ViewerSearch:GetText())
	local globals = getfenv()
	if search == "" then search = nil end
	for i = 1, #FlagList.temp do
		if not search or string.find(string.lower(FlagList.temp[i][1] .. FlagList.temp[i][2] .. FlagList.temp[i][3]), search) then
			if index > offset and index - 20 <= offset then
				local name1, name2, name3 = FlagList.temp[i][1], FlagList.temp[i][2], FlagList.temp[i][3]
				if name1 and name1 ~= "" then name1 = name1 .. " " else name1 = "" end
				if name3 and name3 ~= "" then name3 = " " .. name3 else name3 = "" end
				globals["flagRSP2ViewerTextLine" .. index - offset].name = FlagList.temp[i][2]
				globals["flagRSP2ViewerTextLine" .. index - offset .. "LeftText"]:SetText(string.gsub(name1 .. name2 .. name3, "^[ ]+", ""))
			end
			index = index + 1
		end
	end
	if index <= 20 then
		for i = index, 20 do
			globals["flagRSP2ViewerTextLine" .. i].name = nil
			globals["flagRSP2ViewerTextLine" .. i .. "LeftText"]:SetText("")
		end
		flagRSP2ViewerSlider:SetMinMaxValues(0, 0)
		if offset ~= flagRSP2ViewerSlider:GetValue() then
			flagRSP2ViewerSlider:SetValue(offset)
		end
		flagRSP2ViewerSliderUpButton:Disable()
		flagRSP2ViewerSliderDownButton:Disable()
	else
		flagRSP2ViewerSlider:SetMinMaxValues(0, index - 20)
		if offset ~= flagRSP2ViewerSlider:GetValue() then
			flagRSP2ViewerSlider:SetValue(offset)
		end
		if offset == 0 then
			flagRSP2ViewerSliderUpButton:Disable()
			flagRSP2ViewerSliderDownButton:Enable()
		elseif offset == index - 20 then
			flagRSP2ViewerSliderUpButton:Enable()
			flagRSP2ViewerSliderDownButton:Disable()
		else
			flagRSP2ViewerSliderUpButton:Enable()
			flagRSP2ViewerSliderDownButton:Enable()
		end
	end
end

--TinyTip Code
--Name: TinyTip
--Author: Thrae of Maelstrom (aka "Matthew Carras")
local function handlerOnTooltipSetUnit(origfunc,handlers,self,...)
    if not handlers then
        if origfunc then
            return origfunc(self,...)
        end
    else
        origfunc(self,...)
    end

    local _, unit = self:GetUnit()
    if unit and UnitExists(unit) and GameTooltipTextLeft1:IsShown() then
        for i = 1,#handlers do
            handlers[i](unit)
        end

        self:Show()
    end
end

local function handler(origfunc,handlers,...)
    if not handlers then
        if origfunc then
            return origfunc(...)
        end
    else
        origfunc(...)
    end

    for i = 1,#handlers do
        handlers[i](...)
    end
end

local function isHooked(handlers, handler)
    if not handlers then return true end
    for _,v in ipairs(handlers) do
        if v == handler then
            return true
        end
    end
end

local function hook(object, func, mainhandler, handler, isscript, priority)
    if not origfuncs then origfuncs = {} end
    if not origfuncs[object] then origfuncs[object] = {} end
    if not hooks then hooks = {} end
    if not hooks[object] then hooks[object] = { [func] = {} } end

    if not isHooked(hooks[object][func], handler) then
        if priority then
            table.insert(hooks[object][func], priority, handler)
        else
            table.insert(hooks[object][func], handler)
        end
    end

    if origfuncs[object][func] == nil then
        if isscript then
            origfuncs[object][func] = object:GetScript(func) or false
            object:SetScript(func, function(...) mainhandler(origfuncs[object][func], hooks[object][func], ...) end)
        else
            origfuncs[object][func] = object[func] or false
            object[func] = function(...) mainhandler(origfuncs[object][func], hooks[object][func], ...) end
        end
    end
end

local function unhook(object, func, handler)
    if not hooks or not hooks[object] or not hooks[object][func] then return end
    local handlers = hooks[object][func]
    for i = 1, #handlers do
        if handlers[i] == handler then
            table.remove(handlers, i)
            return true
        end
    end
end

function flagRSP2HookOnTooltipSetUnit(tooltip, handler, priority)
    hook(tooltip, "OnTooltipSetUnit", handlerOnTooltipSetUnit, handler, true, priority)
end

function flagRSP2StartResize(frame)
    FRSP_RESIZING = true
	frame:GetParent():StartSizing()
end

function flagRSP2StopResize(frame)
	FRSP_RESIZING = false
	frame:GetParent():StopMovingOrSizing()
end