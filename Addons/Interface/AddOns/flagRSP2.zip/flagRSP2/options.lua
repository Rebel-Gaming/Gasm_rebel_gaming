local rName = GetRealmName();
local pName = UnitName("player");
local ooprocessed = 0;
local tooltips = {GameTooltip, ShoppingTooltip1, ShoppingTooltip2, ShoppingTooltip3}
local GAMETOOLTIP_DEFAULT_BACKDROP = GameTooltip:GetBackdrop()
local GAMETOOLTIP_DEFAULT_BACKCOLOR = GameTooltip:SetBackdropColor()
local GAMETOOLTIP_DEFAULT_BORDERCOLOR = GameTooltip:SetBackdropBorderColor()
frspversion = GetAddOnMetadata("flagRSP2", "Version");
rspsendbuffer = {};

local L = LibStub("AceLocale-3.0"):GetLocale("flagRSP2", false)

flagRSP2.defaults = {
    char = {
		flagRSP2DBConverted = false,
	
		flagRSP2OptionsCharPrefix = "",
		flagRSP2OptionsCharSuffix = "",
		flagRSP2OptionsCharTitle = "",
		flagRSP2OptionsPhysDesc = "",
		flagRSP2OptionsPhysDescVer = 0,
		flagRSP2OptionsCharStatus = 2,
		flagRSP2OptionsRPExp = 1,

		flagRSP2OptionsSaveDescCheck = true,
		flagRSP2OptionsShowDescCheck = true,
		flagRSP2OptionsTargetDescCheck = false,
		flagRSP2OptionsStickyDescCheck = false,
		flagRSP2OptionsHideCombatCheck = true,
		flagRSP2OptionsWordLimitCheck = true,
		flagRSP2OptionsAFKCheck = true,
		flagRSP2OptionsShowCharacterButton = true,

		flagRSP2TooltipLightModeCheck = false,
		flagRSP2TooltipFRSP2TTCheck = true,
		flagRSP2TooltipShowAddNameCheck = true,
		flagRSP2TooltipShowTitleCheck = true,
		flagRSP2TooltipShowGuildCheck = true,
		flagRSP2TooltipShowStatusCheck = true,
		flagRSP2TooltipShowPvPCheck = false,
		flagRSP2TooltipShowPvPTitleCheck = false,
		flagRSP2DescShowTitleCheck = true,
		flagRSP2DescShowStatusCheck = true,
		
		flagRSPUpgradeNote = true,
		
		flagRSP2DescAutoDBCleanCheck = false,
		flagRSP2MMIconCheck = true,
		minimap = {
			hide = false,
		},
    },
}

----Profile Options
--Char Prefix
function flagRSP2:GetflagRSP2OptionsCharPrefix()
	return flagRSP2.db.char.flagRSP2OptionsCharPrefix
end
function flagRSP2:SetflagRSP2OptionsCharPrefix(info, value)
	if (flagRSP2.db.char.flagRSP2OptionsCharPrefix ~= value) then
		flagRSP2.db.char.flagRSP2OptionsCharPrefix = value
		flagRSP2CharUpdate("textsendupdate")
	end
end
--Char Suffix
function flagRSP2:GetflagRSP2OptionsCharSuffix()
	return flagRSP2.db.char.flagRSP2OptionsCharSuffix
end
function flagRSP2:SetflagRSP2OptionsCharSuffix(info, value)
	if (flagRSP2.db.char.flagRSP2OptionsCharSuffix ~= value) then
		flagRSP2.db.char.flagRSP2OptionsCharSuffix = value
		flagRSP2CharUpdate("textsendupdate")
	end
end
--Char Title
function flagRSP2:GetflagRSP2OptionsCharTitle()
	return flagRSP2.db.char.flagRSP2OptionsCharTitle
end
function flagRSP2:SetflagRSP2OptionsCharTitle(info, value)
	if (flagRSP2.db.char.flagRSP2OptionsCharTitle ~= value) then
		flagRSP2.db.char.flagRSP2OptionsCharTitle = value
		flagRSP2CharUpdate("textsendupdate")
	end
end
--Phys Desc
function flagRSP2:GetflagRSP2OptionsPhysDesc()
	return flagRSP2.db.char.flagRSP2OptionsPhysDesc
end
function flagRSP2:SetflagRSP2OptionsPhysDesc(info, value)
	if (flagRSP2.db.char.flagRSP2OptionsPhysDesc ~= value) then
		flagRSP2CharUpdate("descupdate")
		flagRSP2.db.char.flagRSP2OptionsPhysDescVer = flagRSP2.db.char.flagRSP2OptionsPhysDescVer + 1
	end
	flagRSP2.db.char.flagRSP2OptionsPhysDesc = value
end
--Status
function flagRSP2:GetflagRSP2OptionsCharStatus()
	return flagRSP2.db.char.flagRSP2OptionsCharStatus
end
function flagRSP2:SetflagRSP2OptionsCharStatus(info, value)
	if (flagRSP2.db.char.flagRSP2OptionsCharStatus ~= value) then
		flagRSP2.db.char.flagRSP2OptionsCharStatus = value
		flagRSP2CharUpdate("textsendupdate")
	end
end
--RP EXP
function flagRSP2:GetflagRSP2OptionsRPExp()
	return flagRSP2.db.char.flagRSP2OptionsRPExp
end
function flagRSP2:SetflagRSP2OptionsRPExp(info, value)
	if (flagRSP2.db.char.flagRSP2OptionsRPExp ~= value) then
		flagRSP2.db.char.flagRSP2OptionsRPExp = value
		flagRSP2CharUpdate("textsendupdate")
	end
end

--General Options
function flagRSP2:GetflagRSP2OptionsSaveDescCheck()
	return flagRSP2.db.char.flagRSP2OptionsSaveDescCheck
end
function flagRSP2:SetflagRSP2OptionsSaveDescCheck()
	flagRSP2.db.char.flagRSP2OptionsSaveDescCheck = not flagRSP2.db.char.flagRSP2OptionsSaveDescCheck
end
function flagRSP2:GetflagRSP2OptionsShowDescCheck()
	return flagRSP2.db.char.flagRSP2OptionsShowDescCheck
end
function flagRSP2:SetflagRSP2OptionsShowDescCheck()
	flagRSP2.db.char.flagRSP2OptionsShowDescCheck = not flagRSP2.db.char.flagRSP2OptionsShowDescCheck
end
function flagRSP2:GetflagRSP2OptionsTargetDescCheck()
	return flagRSP2.db.char.flagRSP2OptionsTargetDescCheck
end
function flagRSP2:SetflagRSP2OptionsTargetDescCheck()
	flagRSP2.db.char.flagRSP2OptionsTargetDescCheck = not flagRSP2.db.char.flagRSP2OptionsTargetDescCheck
end
function flagRSP2:GetflagRSP2OptionsStickyDescCheck()
	return flagRSP2.db.char.flagRSP2OptionsStickyDescCheck
end
function flagRSP2:SetflagRSP2OptionsStickyDescCheck()
	flagRSP2.db.char.flagRSP2OptionsStickyDescCheck = not flagRSP2.db.char.flagRSP2OptionsStickyDescCheck
end
function flagRSP2:GetflagRSP2OptionsHideCombatCheck()
	return flagRSP2.db.char.flagRSP2OptionsHideCombatCheck
end
function flagRSP2:SetflagRSP2OptionsHideCombatCheck()
	flagRSP2.db.char.flagRSP2OptionsHideCombatCheck = not flagRSP2.db.char.flagRSP2OptionsHideCombatCheck
end
function flagRSP2:GetflagRSP2OptionsWordLimitCheck()
	return flagRSP2.db.char.flagRSP2OptionsWordLimitCheck
end
function flagRSP2:SetflagRSP2OptionsWordLimitCheck()
	flagRSP2.db.char.flagRSP2OptionsWordLimitCheck = not flagRSP2.db.char.flagRSP2OptionsWordLimitCheck
end
function flagRSP2:GetflagRSP2OptionsAFKCheck()
	return flagRSP2.db.char.flagRSP2OptionsAFKCheck
end
function flagRSP2:SetflagRSP2OptionsAFKCheck()
	flagRSP2.db.char.flagRSP2OptionsAFKCheck = not flagRSP2.db.char.flagRSP2OptionsAFKCheck
end
function flagRSP2:GetflagRSP2OptionsShowCharacterButton()
	return flagRSP2.db.char.flagRSP2OptionsShowCharacterButton
end
function flagRSP2:SetflagRSP2OptionsShowCharacterButton()
	flagRSP2.db.char.flagRSP2OptionsShowCharacterButton = not flagRSP2.db.char.flagRSP2OptionsShowCharacterButton
	if flagRSP2.db.char.flagRSP2OptionsShowCharacterButton then
		flagRSP2CharacterAnchor:Show()
	else
		flagRSP2CharacterAnchor:Hide()
	end
end

--Tooltip/Description Pop Up Options
function flagRSP2:GetflagRSP2TooltipLightModeCheck()
	return flagRSP2.db.char.flagRSP2TooltipLightModeCheck
end
function flagRSP2:SetflagRSP2TooltipLightModeCheck()
	flagRSP2.db.char.flagRSP2TooltipLightModeCheck = not flagRSP2.db.char.flagRSP2TooltipLightModeCheck
	if (flagRSP2.db.char.flagRSP2TooltipLightModeCheck == false) then
		for _,v in ipairs(tooltips) do
			TOOLTIP_DEFAULT_COLOR = { r = 0, g = 0, b = 0 };
			TOOLTIP_DEFAULT_BACKGROUND_COLOR = { r = 0, g = 0, b = 0 };
			v:SetBackdrop({bgFile = [=[Interface\ChatFrame\ChatFrameBackground]=], edgeFile = [=[Interface\Addons\flagRSP2\images\edgefile.tga]=], level = '0', edgeSize = 6, insets = {top = 4, left = 4, bottom = 4, right = 4}})
			v:SetBackdropColor(0, 0, 0, 0.5)
			v:SetBackdropBorderColor(0, 0, 0, 1)
	    end
	end
	if (flagRSP2.db.char.flagRSP2TooltipLightModeCheck == true) then
		for _,v in ipairs(tooltips) do
			TOOLTIP_DEFAULT_COLOR = { r = 1, g = 1, b = 1 };
			TOOLTIP_DEFAULT_BACKGROUND_COLOR = { r = 0.09, g = 0.09, b = 0.19 };
			v:SetBackdrop(GAMETOOLTIP_DEFAULT_BACKDROP)
			v:SetBackdropColor(TOOLTIP_DEFAULT_BACKGROUND_COLOR)
			v:SetBackdropBorderColor(TOOLTIP_DEFAULT_COLOR)
	    end
	end
end
function flagRSP2:GetflagRSP2TooltipFRSP2TTCheck()
	return flagRSP2.db.char.flagRSP2TooltipFRSP2TTCheck
end
function flagRSP2:SetflagRSP2TooltipFRSP2TTCheck()
	flagRSP2.db.char.flagRSP2TooltipFRSP2TTCheck = not flagRSP2.db.char.flagRSP2TooltipFRSP2TTCheck
end
function flagRSP2:GetflagRSP2TooltipShowAddNameCheck()
	return flagRSP2.db.char.flagRSP2TooltipShowAddNameCheck
end
function flagRSP2:SetflagRSP2TooltipShowAddNameCheck()
	flagRSP2.db.char.flagRSP2TooltipShowAddNameCheck = not flagRSP2.db.char.flagRSP2TooltipShowAddNameCheck
end
function flagRSP2:GetflagRSP2TooltipShowTitleCheck()
	return flagRSP2.db.char.flagRSP2TooltipShowTitleCheck
end
function flagRSP2:SetflagRSP2TooltipShowTitleCheck()
	flagRSP2.db.char.flagRSP2TooltipShowTitleCheck = not flagRSP2.db.char.flagRSP2TooltipShowTitleCheck
end
function flagRSP2:GetflagRSP2TooltipShowGuildCheck()
	return flagRSP2.db.char.flagRSP2TooltipShowGuildCheck
end
function flagRSP2:SetflagRSP2TooltipShowGuildCheck()
	flagRSP2.db.char.flagRSP2TooltipShowGuildCheck = not flagRSP2.db.char.flagRSP2TooltipShowGuildCheck
end
function flagRSP2:GetflagRSP2TooltipShowStatusCheck()
	return flagRSP2.db.char.flagRSP2TooltipShowStatusCheck
end
function flagRSP2:SetflagRSP2TooltipShowStatusCheck()
	flagRSP2.db.char.flagRSP2TooltipShowStatusCheck = not flagRSP2.db.char.flagRSP2TooltipShowStatusCheck
end
function flagRSP2:GetflagRSP2TooltipShowPvPCheck()
	return flagRSP2.db.char.flagRSP2TooltipShowPvPCheck
end
function flagRSP2:SetflagRSP2TooltipShowPvPCheck()
	flagRSP2.db.char.flagRSP2TooltipShowPvPCheck = not flagRSP2.db.char.flagRSP2TooltipShowPvPCheck
end
function flagRSP2:GetflagRSP2TooltipShowPvPTitleCheck()
	return flagRSP2.db.char.flagRSP2TooltipShowPvPTitleCheck
end
function flagRSP2:SetflagRSP2TooltipShowPvPTitleCheck()
	flagRSP2.db.char.flagRSP2TooltipShowPvPTitleCheck = not flagRSP2.db.char.flagRSP2TooltipShowPvPTitleCheck
end
function flagRSP2:GetflagRSP2DescShowTitleCheck()
	return flagRSP2.db.char.flagRSP2DescShowTitleCheck
end
function flagRSP2:SetflagRSP2DescShowTitleCheck()
	flagRSP2.db.char.flagRSP2DescShowTitleCheck = not flagRSP2.db.char.flagRSP2DescShowTitleCheck
end
function flagRSP2:GetflagRSP2DescShowStatusCheck()
	return flagRSP2.db.char.flagRSP2DescShowStatusCheck
end
function flagRSP2:SetflagRSP2DescShowStatusCheck()
	flagRSP2.db.char.flagRSP2DescShowStatusCheck = not flagRSP2.db.char.flagRSP2DescShowStatusCheck
end

--Database Options
function flagRSP2:GetflagRSP2DescAutoDBCleanCheck()
	return flagRSP2.db.char.flagRSP2DescAutoDBCleanCheck
end
function flagRSP2:SetflagRSP2DescAutoDBCleanCheck()
	flagRSP2.db.char.flagRSP2DescAutoDBCleanCheck = not flagRSP2.db.char.flagRSP2DescAutoDBCleanCheck
end

--LibDBIcon Options
function flagRSP2:GetflagRSP2MMIconCheck()
	return flagRSP2.db.char.flagRSP2MMIconCheck
end
local icon = LibStub("LibDBIcon-1.0")
function flagRSP2:SetflagRSP2MMIconCheck()
	flagRSP2.db.char.flagRSP2MMIconCheck = not flagRSP2.db.char.flagRSP2MMIconCheck
	if (flagRSP2.db.char.flagRSP2MMIconCheck == true) then
		flagRSP2.db.char.minimap.hide = nil
		icon:Show("flagRSP2")
	else
		flagRSP2.db.char.minimap.hide = true
		icon:Hide("flagRSP2")
	end
end

local optionsvname = "flagRSP2 " .. frspversion

--NEVER CHANGE THE ORDER OF THESE!
local char_status = {
	[1] = L["FLAGRSP2_LUA_OOC"],
	[2] = L["FLAGRSP2_LUA_IC"],
	[3] = L["FLAGRSP2_LUA_LFC"],
	[4] = L["FLAGRSP2_LUA_ST"]
}
--NEVER CHANGE THE ORDER OF THESE!
local rp_exp = {
	[1] = L["FLAGRSP2_LUA_RP"],
	[2] = L["FLAGRSP2_LUA_CRP"],
	[3] = L["FLAGRSP2_LUA_FRP"],
	[4] = L["FLAGRSP2_LUA_BRP"],
	[5] = L["FLAGRSP2_LUA_MRP"]
}

flagRSP2.options = {
	name = "flagRSP2 " .. GetAddOnMetadata("flagRSP2", "Version"),
	handler = flagRSP2,
	type = 'group',
	args = {
		frsp2options = {
			name = "flagRSP2",
			desc = '',
			order = 1,
			type = 'group',
			args = {
				Profile = {
					name = "Character Profile",
					type = 'group',
					order = 1,
					guiInline = true,
					args = {
						flagRSP2OptionsCharPrefix = {
							type = "input",
							name = L["FLAGRSP2_PREFIX_TEXT"],
							desc = L["FLAGRSP2_PREFIX_TEXT"],
							get = "GetflagRSP2OptionsCharPrefix",
							set = "SetflagRSP2OptionsCharPrefix",
							multiline = false,
							order = 2
						},
						flagRSP2OptionsCharSuffix = {
							type = "input",
							name = L["FLAGRSP2_SUFFIX_TEXT"],
							desc = L["FLAGRSP2_SUFFIX_TEXT"],
							get = "GetflagRSP2OptionsCharSuffix",
							set = "SetflagRSP2OptionsCharSuffix",
							multiline = false,
							order = 3
						},
						flagRSP2OptionsCharTitle = {
							type = "input",
							name = L["FLAGRSP2_TITLE_TEXT"],
							desc = L["FLAGRSP2_TITLE_TEXT"],
							get = "GetflagRSP2OptionsCharTitle",
							set = "SetflagRSP2OptionsCharTitle",
							multiline = false,
							width = 'full',
							order = 4
						},
						flagRSP2OptionsPhysDesc = {
							type = "input",
							name = L["FLAGRSP2_DESC_TEXT"],
							desc = L["FLAGRSP2_DESC_TEXT"],
							get = "GetflagRSP2OptionsPhysDesc",
							set = "SetflagRSP2OptionsPhysDesc",
							multiline = 16,
							width = 'full',
							order = 5
						},
						flagRSP2OptionsCharStatus = {
							type = "select",
							name = L["FLAGRSP2_LUA_CHARSTATUS"],
							desc = L["FLAGRSP2_LUA_CHARSTATUS_DESC"],
							get = "GetflagRSP2OptionsCharStatus",
							set = "SetflagRSP2OptionsCharStatus",
							values = char_status,
							order = 6
						},
						flagRSP2OptionsRPExp = {
							type = "select",
							name = L["FLAGRSP2_LUA_RPEXP"],
							desc = L["FLAGRSP2_LUA_RPEXP_DESC"],
							get = "GetflagRSP2OptionsRPExp",
							set = "SetflagRSP2OptionsRPExp",
							values = rp_exp,
							order = 7
						},
					},
				},
				General = {
					name = "flagRSP2 " .. GetAddOnMetadata("flagRSP2", "Version") .. " General Options",
					type = 'group',
					order = 2,
					guiInline = true,
					args = {
						flagRSP2OptionsSaveDescCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_SAVE_DESCRIPTIONS"],
							desc = L["FLAGRSP2_SAVE_DESCRIPTIONS_DESC"],
							get = "GetflagRSP2OptionsSaveDescCheck",
							set = "SetflagRSP2OptionsSaveDescCheck",
							width = 'full',
							order = 3,
						},
						flagRSP2OptionsShowDescCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_SHOW_TARGET_CHARACTER_DESCRIPTION"],
							desc = L["FLAGRSP2_SHOW_DESCRIPTION_ONLY_WHEN_TARGETTING_PLAYER_DESC"],
							get = "GetflagRSP2OptionsShowDescCheck",
							set = "SetflagRSP2OptionsShowDescCheck",
							width = 'full',
							order = 3,
						},
						flagRSP2OptionsTargetDescCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_SHOW_DESCRIPTION_ONLY_WHEN_TARGETTING_PLAYER"],
							desc = L["FLAGRSP2_SHOW_DESCRIPTION_ONLY_WHEN_TARGETTING_PLAYER_DESC"],
							get = "GetflagRSP2OptionsTargetDescCheck",
							set = "SetflagRSP2OptionsTargetDescCheck",
							width = 'full',
							order = 4,
						},
						flagRSP2OptionsStickyDescCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_STICKY_DESCRIPTION"],
							desc = L["FLAGRSP2_STICKY_DESCRIPTION_DESC"],
							get = "GetflagRSP2OptionsStickyDescCheck",
							set = "SetflagRSP2OptionsStickyDescCheck",
							width = 'full',
							order = 5,
						},
						flagRSP2OptionsHideCombatCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_HIDE_DESCRIPTIONS_DURING_AND_ENTERING_COMBAT"],
							desc = L["FLAGRSP2_HIDE_DESCRIPTIONS_DURING_AND_ENTERING_COMBAT_DESC"],
							get = "GetflagRSP2OptionsHideCombatCheck",
							set = "SetflagRSP2OptionsHideCombatCheck",
							width = 'full',
							order = 6,
						},
						flagRSP2OptionsWordLimitCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_CUT_OFF_TITLES"],
							desc = L["FLAGRSP2_CUT_OFF_TITLES_DESC"],
							get = "GetflagRSP2OptionsWordLimitCheck",
							set = "SetflagRSP2OptionsWordLimitCheck",
							width = 'full',
							order = 7,
						},
						flagRSP2OptionsAFKCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_AFK"],
							desc = L["FLAGRSP2_AFK_DESC"],
							get = "GetflagRSP2OptionsAFKCheck",
							set = "SetflagRSP2OptionsAFKCheck",
							width = 'full',
							order = 8,
						},
						flagRSP2OptionsShowCharacterButton = {
							type = 'toggle',
							name = L["FLAGRSP2_CB"],
							desc = L["FLAGRSP2_CB_DESC"],
							get = "GetflagRSP2OptionsShowCharacterButton",
							set = "SetflagRSP2OptionsShowCharacterButton",
							width = 'full',
							order = 8,
						},
					},
				},
				gametooltip = {
					name = 'Enhanced GameTooltip',
					type = 'group',
					order = 9,
					guiInline = true,
					args = {
						flagRSP2TooltipLightModeCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_LIGHT_MODE_TOOLTIP"],
							desc = L["FLAGRSP2_LIGHT_MODE_TOOLTIP_DESC"],
							get = "GetflagRSP2TooltipLightModeCheck",
							set = "SetflagRSP2TooltipLightModeCheck",
							width = 'full',
							order = 9,
						},
						flagRSP2TooltipShowAddNameCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_ENHANCED_ADDITIONAL_NAME"],
							desc = "",
							get = "GetflagRSP2TooltipShowAddNameCheck",
							set = "SetflagRSP2TooltipShowAddNameCheck",
							width = 'full',
							order = 10,
						},
						flagRSP2TooltipShowTitleCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_ENHANCED_TITLE"],
							desc = "",
							get = "GetflagRSP2TooltipShowTitleCheck",
							set = "SetflagRSP2TooltipShowTitleCheck",
							width = 'full',
							order = 11,
						},
						flagRSP2TooltipShowGuildCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_ENHANCED_GUILD"],
							desc = "",
							get = "GetflagRSP2TooltipShowGuildCheck",
							set = "SetflagRSP2TooltipShowGuildCheck",
							width = 'full',
							order = 12,
						},
						flagRSP2TooltipShowStatusCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_ENHANCED_STATUS"],
							desc = "",
							get = "GetflagRSP2TooltipShowStatusCheck",
							set = "SetflagRSP2TooltipShowStatusCheck",
							width = 'full',
							order = 13,
						},
						flagRSP2TooltipShowPvPCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_ENHANCED_PVP"],
							desc = "",
							get = "GetflagRSP2TooltipShowPvPCheck",
							set = "SetflagRSP2TooltipShowPvPCheck",
							width = 'full',
							order = 14,
						},
						flagRSP2TooltipShowPvPTitleCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_ENHANCED_PVP_TITLE"],
							desc = "",
							get = "GetflagRSP2TooltipShowPvPTitleCheck",
							set = "SetflagRSP2TooltipShowPvPTitleCheck",
							width = 'full',
							order = 15,
						},
					},
				},

				descpopup = {
					name = L["FLAGRSP2_DESC_OPT"],
					type = 'description',
					type = 'group',
					order = 16,
					guiInline = true,
					args = {
						flagRSP2DescShowTitleCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_DESC_TITLE"],
							desc = "",
							get = "GetflagRSP2DescShowTitleCheck",
							set = "SetflagRSP2DescShowTitleCheck",
							width = 'full',
							order = 17,
						},
						flagRSP2DescShowStatusCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_DESC_STATUS"],
							desc = "",
							get = "GetflagRSP2DescShowStatusCheck",
							set = "SetflagRSP2DescShowStatusCheck",
							width = 'full',
							order = 18,
						},
					},
				},
				minimap = {
					name = 'Minimap Icon Options',
					type = 'description',
					type = 'group',
					order = 20,
					guiInline = true,
					args = {
						flagRSP2MMIconHide = {
							type = 'toggle',
							name = L["FLAGRSP2_FUBAR_MINIMAP"],
							desc = L["FLAGRSP2_FUBAR_MINIMAP_DESC"],
							get = "GetflagRSP2MMIconCheck",
							set = "SetflagRSP2MMIconCheck",
							width = 'full',
							order = 21,
						},
					},
				},
				dbcleanup = {
					name = L["FLAGRSP2_DB_CLEAN_UP"],
					type = 'description',
					type = 'group',
					order = 23,
					guiInline = true,
					args = {
						purgeselectivedb = {
							type = 'execute',
							name = L["FLAGRSP2_DB_PURGE_OLD"],
							desc = L["FLAGRSP2_DB_PURGE_ALL_DESC"],
							func = function() flagRSP2PurgeOldDB() end,
							order = 24,
						},
						purgealldb = {
							type = 'execute',
							name = L["FLAGRSP2_DB_PURGE_ALL"],
							desc = L["FLAGRSP2_DB_PURGE_ALL_DESC"],
							func = function() flagRSP2PurgeAllDB() end,
							order = 25,
						},
						flagRSP2DescAutoDBCleanCheck = {
							type = 'toggle',
							name = L["FLAGRSP2_DB_AUTO_PURGE"],
							desc = L["FLAGRSP2_DB_AUTO_PURGE_DESC"],
							get = "GetflagRSP2DescAutoDBCleanCheck",
							set = "SetflagRSP2DescAutoDBCleanCheck",
							width = 'full',
							order = 26,
						},
					},
				},
			},
		},
	},
}

function flagRSP2Options_Initialize()
	if (FlagList == nil) then
		FlagList = {};
	end
	if (FlagList[rName] == nil) then
		FlagList[rName] = {};
	end

	--Only wipe this on the second load because of paranoia.
	if (flagRSP2.db.char.flagRSP2DBConverted == true) then
		PlayerFlags[rName][pName] = {}
	end
	--Convert old PlayerFlags to new AceDB format.
	if (flagRSP2.db.char.flagRSP2DBConverted == false and PlayerFlags) then
		flagRSP2.db.char.flagRSP2OptionsCharPrefix = PlayerFlags[rName][pName]["FName"]
		flagRSP2.db.char.flagRSP2OptionsCharSuffix = PlayerFlags[rName][pName]["LName"]
		flagRSP2.db.char.flagRSP2OptionsCharTitle = PlayerFlags[rName][pName]["Title"]
		flagRSP2.db.char.flagRSP2OptionsRPExp = PlayerFlags[rName][pName]["RP"]
		flagRSP2.db.char.flagRSP2OptionsCharStatus = PlayerFlags[rName][pName]["CS"]
		flagRSP2.db.char.flagRSP2OptionsPhysDescVer = PlayerFlags[rName][pName]["DV"]
		flagRSP2.db.char.flagRSP2OptionsPhysDesc = PlayerFlags[rName][pName]["Desc"]["A"]
		flagRSP2.db.char.flagRSP2DBConverted = true
	end

	FRSPLOADED = 1;
end

function flagRSP2CharUpdate(option)
	statusupdate = 0;
	if (option == "timedupdate" or option == "textsendupdate") then
		statusupdate = 1;
	end

	--Time to compose simple update messages.  Everything except for description will be sent in this step.  CSM stands for composed simple message.
	if (statusupdate == 1) then
		csm = "";
		csm = "<CS" .. flagRSP2.db.char.flagRSP2OptionsCharStatus .. ">";
		csm = csm .. "<RP" .. flagRSP2.db.char.flagRSP2OptionsRPExp .. ">";
		csm = csm .. "<DV>" .. flagRSP2.db.char.flagRSP2OptionsPhysDescVer .. "<AN1>" .. flagRSP2.db.char.flagRSP2OptionsCharPrefix .. "<AN3>" .. flagRSP2.db.char.flagRSP2OptionsCharSuffix;
		flagRSP2:AddToBuffer(csm);
		csmt = "<T>" .. string.sub(flagRSP2.db.char.flagRSP2OptionsCharTitle, 1, 252);
		flagRSP2:AddToBuffer(csmt);
		--Clear DP Throttle Buffer.  May cause accidental spam over the communication channel, but this is better than allowing the buffer to slowly grow during the player's session.
		dpthrottle = {};
		statusupdate = 0;
	end
end