-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

function MazzleOptions:AddOptions_Automation()

    local addItem, tempItem = {}, {}
    addItem.name = "Automation"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "AutoAcceptInvite",
        requiredAddOn = "AutoAcceptInvite",
        addonDescription = "This Ace2 add-on made by our very own Tigerheart allows your character to automatically accept invites from people on an 'accept list' and automatically reject invites from those on your 'reject' list.  You can also tell it to automatically accept invites from all friends or guild memebers.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  AutoAcceptInvite is under the 'Raid' category.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Free Refills",
        requiredAddOn = "FreeRefills",
        addonDescription = "FreeRefills is an add-on that will automatically stock any items you want in your bags. When ever you visit a merchant, it will check to see if that merchant sells an item on your shopping list, and will pick up however many you need.  This is perfect for classes that need to always keep certain reagents on hand.\n",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 3,
        text = "For the following three commands, click the button then shift-click on the item you want to add or remove.",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Add Item",
        label = "Click to add an item to be automatically kept in stock",
        setProc = function() MazzleUI:StartEditCommand("/freerefills add "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 3,
        notetype = "example", 
        text = "/freerefills add [Rune of Portals] 8",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Add Stack",
        label = "Click to add a stack of an item to be automatically kept in stock",
        setProc = function() MazzleUI:StartEditCommand("/freerefills addstack "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 3,
        notetype = "example", 
        text = "/freerefills addstack [Crystal Vial] 1",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Delete",
        label = "Click to delete an item or stack from your shopping list",
        setProc = function() MazzleUI:StartEditCommand("/freerefills del "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 3,
        notetype = "example", 
        text = "/freerefills del [Rune of Portals]",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Print List",
        label = "Click to print your shopping list",
        setProc = function() MazzleUI:Execute("/freerefills list"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Clear",
        label = "Click to clear your shopping list",
        setProc = function() MazzleUI:Execute("/freerefills clear"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "When buying stacks, is it ok to overstock to meet your refill amount?",
        readProc = function() return (FreeRefills.db.profile.overstock); end,
        setProc = function() MazzleUI:Execute("/freerefills overstock"); end,
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Automatically buy items when visiting merchants?",
        readProc = function() return (FreeRefills.db.profile.merchant); end,
        setProc = function() MazzleUI:Execute("/freerefills merchant"); end,
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Automatically grab items from your bank if they are on your shopping list?",
        readProc = function() return (FreeRefills.db.profile.bank); end,
        setProc = function() MazzleUI:Execute("/freerefills bank"); end,
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "GoGoMount",
			["requiredAddOn"] = "GoGoMount",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on allows you to access any of your mounts with a single key binding.  By default, it will randomly choose between your fastest mounts. When in the confines of Ahn'Qiraj, this add-on will automatically substitute your bug mount.  You can also tell this add-on which mount you prefer by accessing the options.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Automatically dismount you when you click on an herb/mining node or cast an offensive spell?",
        parameter = "GoGo_AutoCheck",
        setProc = function(a,b) if (GoGoFrame) then
        		if GoGo_AutoCheck then GoGoFrame:RegisterEvent("UI_ERROR_MESSAGE")
        		else GoGoFrame:UnregisterEvent("UI_ERROR_MESSAGE")
        		end; end; end,
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Include spell-based mounts in GoGoMount's random mount selection?",
        parameter = "GoGo_SpellCheck"}
    table.insert(addItem, tempItem)


    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Include flying mounts in GoGoMount's random mount selection? (Must be level 70)",
        parameter = "GoGo_FlyingCheck"}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", notetype = "none", yadjust = 5,
        text = "The following two options allow you to set preferred mounts in a particular zone.  You can set multiple preferred mounts.  To do so, click the button below and then shift-click on the preferred mount or spell from your inventory or spellbook.",
    }
    table.insert(addItem, tempItem)
    
    tempItem = {
        type = "Button", yadjust = 5,
        name = "Add Mount Item",
        label = "Click to add a preferred mount |CFFFF8000item|r for this zone.",
        setProc = function() MazzleUI:StartEditCommand("/gogo ItemLink "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Add Mount Spell",
        label = "Click to add a preferred mount |CFFFF8000spell|r for this zone.",
        setProc = function() MazzleUI:StartEditCommand("/gogo SpellName "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Clear",
        label = "Click to clear preferred mounts for this zone.",
        setProc = function() MazzleUI:StartEditCommand("/gogo SpellName "); end}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Bags()

    local addItem, tempItem = {}, {}
    addItem.name = "Bags"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Baggins",
        requiredAddOn = "Baggins",
        addonDescription = "Baggins is an Ace2 add-on that provides a fully customizable set of virtual bags. Each bag can have many sections with different categories of items contained in them. There is an interface for defining your own categories based on rules. Currently in alpha, it will be in a constant state of change and probably contain bugs, however it should be usable as it is.\n\n|CFFFF0000Features|r:\n\n|CFFFF8000Create Rules based on|r:\n    ItemType (Armor, Weapon, Consumable etc) \n    Equip Location \n    Item Quality \n    Periodic Table Set \n    Bag or Bag Type \n    Soulbound, Unbound, BoE, BoP, BoU \n\n|CFFFF0000Fully customizable bag layout|r:\n    Create any number of bags with any number of sections \n    Can be setup to be one sorted bag for everything, a bag for each category, or anything in between.\n",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to open the Baggins options window",
        setProc = function() MazzleUI:Execute("/baggins waterfall"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Movable Bags",
        requiredAddOn = "MovableBags",
        addonDescription = "This add-on makes all of your bags movable.  This has been modified from the original to initially place your bags in a location more compatible with the MazzleUI layout.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 10,
        name = "Reset",
        label = "Click to put your bags back to the default MazzleUI positions.",
        setProc = function() MazzleUI:Execute("/movable bags reset"); end}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_UnitFrames()

    local addItem, tempItem = {}, {}
    addItem.name = "Unit Frames"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Discord Unit Frames",
        requiredAddOn = "DiscordUnitFrames",
        addonDescription = "This add-on displays the unit frames for yourself, your target, your pets, your party members and their pets.  It does not handle raid frames.  It is a complex add-on that most users will not need to modify.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 0,
        name = "Discord Unit Frames",
        label = "Click to open options window for Discord Unit Frames.",
        setProc = function() MazzleUI:Execute("/duf"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "MobHealth 3",
        requiredAddOn = "MobHealth",
        addonDescription = "This add-on allows you to display actual health values for your targetted mob.  It can both maintain a database of these values as well as calculate the values on the fly.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  MobHealth is under the 'Combat' category.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 5,
        text = "When configuring the settings remember that estimation precision is a measure of how the add-on balances accuracy vs quick display of a health estimate.  MobHealth3 uses a number between 1 and 99 to determine the trade-off. This number is how many percent a mob's health needs to to change before we will trust the estimated maximum health and display it. The lower this value is, the quicker you'll see a value and the less accurate it will be. Raiding players may want to turn this down a bit. If you don't care about accuracy and want info ASAP, set this to 1.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 10,
        text = "When turned on, the max HP only updates once your target changes. If data for the target is unknown, MH3 will update once during the battle when the precision percentage is reached.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_ErrorFrame()

    local addItem, tempItem = {}, {}
    addItem.name = "Error Window"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "BugGrabber",
        requiredAddOn = "!BugGrabber",
        addonDescription = "This add-on intercepts all error messages and stores them for your later perusal.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "BugSack",
        requiredAddOn = "BugSack",
        addonDescription = "This add-on lets you view the errors that BugGrabber catches.  It has a variety of options to let you better interface with BugGrabber.  You can access the options for this add-on by right-clicking on the green bag icon in your FuBar.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Display()

    local addItem, tempItem = {}, {}
    addItem.name = "Display"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "ClearFont 2d",
        requiredAddOn = "ClearFont2d",
        addonDescription = "Clearfont replaces most of the fonts in the UI with a much more legible font.  The version included in MazzleUI is a stripped-down, streamlined version made by Tuller, author of Bongos.  If you seek a  version of ClearFont2 with more fonts and options, you can download the full version from WoWInterface.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = -5,
        name = "List Fonts",
        label = "Click to list the fonts available",
        setProc = function() MazzleUI:Execute("/clearfont2d fonts"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = -5,
        name = "Font",
        label = "Click to change the font used",
        setProc = function() MazzleUI:StartEditCommand("/clearfont2d font "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = -5,
        name = "Scale",
        label = "Click to change the font scale",
        setProc = function() MazzleUI:StartEditCommand("/clearfont2d scale "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 5,
        text = "1 = 100% scaling in the above command.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = -5,
        name = "Add-Ons",
        label = "Click to toggle whether add-ons use the ClearFont2d font",
        setProc = function() MazzleUI:Execute("/clearfont2d apply"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "GFX Toggle 2",
        requiredAddOn = "gfxToggle2",
        addonDescription = "GFX Toggle allows you to quickly switch between various video settings.  It is used by the various MazzleUI efficiency modes to tone down or improve the graphics as per the MazzleUI performance settings.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button",
        name = "Save Low",
        label = "Click to save the CURRENT video settings as the Low setting.",
        setProc = function() MazzleUI:Execute("/gfxt save low");  end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button",
        name = "Save Medium",
        label = "Click to save the CURRENT video settings as the Medium setting.",
        setProc = function() MazzleUI:Execute("/gfxt save medium");  end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button",
        name = "Save High",
        label = "Click to save the CURRENT video settings as the High setting.",
        setProc = function() MazzleUI:Execute("/gfxt save high"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button",
        name = "Toggle",
        label = "Click to switch between the current setting low and high.",
        setProc = function() MazzleUI:Execute("/gfxt toggle"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 5,
        text = "MazzleUI efficiency modes use the low and high gfxt settings to change graphics.  It does not use the medium settings",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 10,
        text = "GFX Toggle also has options to automatically switch settings based on the zone you're in.  Type /gfxt to access more options.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "MoveFrames",
        requiredAddOn = "moveFrames",
        addonDescription = "MoveFrames allows you to move the basic Blizzard frames anywhere you would like. No more frames locked to the left and center of the screen.  To move a frame, simply drag by the 'title bar' to the location you want the frame placed. The next time you re-open the frame, it will open in it's newly placed position and no longer adhere to the 'frame push' behavior when opened or closed like the default. Frames that have not been moved using moveFrames retain the default blizzard behavior, opening on the left and pushing currently open ones to the middle.\n\n|CFF0000FFDrag|r: Moves a frame wherever you want.  Pretty straight forward.\n\n|CFF0000FFRight-Click|r: Locks the selected frame into position.  To un-lock the frame, just right-click it again.\n\n|CFF0000FFShift-Right-Click|r: Resets the frame. Do this if there is one frame that needs to be reset without losing every frames positional data.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button",
        name = "Reset All",
        label = "Click to reset all windows to their default position.",
        setProc = function() MazzleUI:Execute("/mf reset"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button",
        name = "Lock All",
        label = "Click to lock the position of all windows moved by MoveFrames.",
        setProc = function() MazzleUI:Execute("/mf lock"); end}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Buffing()

    local addItem, tempItem = {}, {}
    addItem.name = "Buffing and Debuffing"

    tempItem = {
			["addonDescription"] = "SmartBuff is an addon to cast buffs ease and quickly. All classes are supported. Bind a key, scrollwheel or use the action button and it checks if you, a party/raid member, also hunter and warlock pets, needs your buff and cast it. Use the options menu to configure it as you like it , as example: buffs, raid subgroups, pets, etc.  Run the mod when ever you wish, if nothing is buffed, there is no penalty or cool down.\n\n|CFF00FF00Features|r:\n- Supports all classes.\n- Checks buffs and rebuff you, raid/party members, raid/party pets\n- Setup your own buff templates (Solo, Party, Raid, Battleground, MC, Ony, BWL, AQ, ZG, Custom 1-5) and auto switch templates\n- Individual setup for each buff\n- Supports group buffs, class buffs, self buffs, weapon buffs (individual for main and off hand), character level based buffs and even tracking abilities\n- Reminder if a buff is missing via a splash message, chatframe message and sound.\n- Re-buff timers and warnings\n\n|CFFFF8000Note|r: When in the options window, right-clicking on buff checkbox opens the buff setup frame where you can customize the settings for a particular buff.\n",
			["type"] = "AddOnHeader",
			["addonName"] = "SmartBuff",
			["requiredAddOn"] = "SmartBuff",
		}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to open the SmartBuff options window",
        setProc = function() MazzleUI:Execute("/sb menu"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "On/Off",
        label = "Click here to toggle SmartBuff on or off",
        setProc = function() MazzleUI:Execute("/sb toggle"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Reset Timers",
        label = "Click here to reset buff timers",
        setProc = function() MazzleUI:Execute("/sb rbt"); end}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonDescription"] = "Decursive is a cleaning mod. Its job is to help you remove afflictions with ease in every condition (playing solo, in small groups or in big\nraids).  \n\n|CFF00FF00Features|r:\n- Support all cleansing spells in all localizations.\n- Minimal memory and CPU usage in all conditions.\n- Users can choose the types of affliction they want to cure and prioritize them.\n-   Mages can sheep mind-controlled units.\n-   Two solutions available to cleans afflictions: Micro-Unit Frames (MUFs), little squares on your screen that changes appearance according to the unit status, and a special mouse-over macro.\n- Cleansing macro auto-configuration: Assign a key to the macro and you can cure people by mousing over them and hitting the key.\n- User customisable debuff filtering system.\n- Easy configurable player priority and skip list.\n\nMUFs have several colors.  Here are a few of the key ones:\n\n|CFFFF8000Full red|r: The unit is in range and affected by something you can cure by left-clicking on the MUF.\n|CFFFF8000Transparent red|r: The unit is out of range and affected by something you could cure by left-clicking on the MUF.\n|CFFFF8000Full blue|r: Same as red but with right-clicking instead of left-clicking.\n|CFFFF8000Full orange|r: Same as blue or red but with ctrl-left-clicking.\n",
			["type"] = "AddOnHeader",
			["addonName"] = "Decursive",
			["requiredAddOn"] = "Decursive",
		}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", 
        text = "To access the various windows of Decursive, mouse-over the hidden Decursive anchor which is just above the first micro unit frame.  It becomes visible when your mouse pointer is over it.  You can access the options for Decursive via the Niagara menu in your Fubar.  It is under the category 'Combat'.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Buttons()

    local addItem, tempItem = {}, {}
    addItem.name = "Buttons and Clicking"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "AutoBar",
        requiredAddOn = "AutoBar",
        addonDescription = "This add-on provides a bar of buttons that auto-load with items that can replenish you in some way.  For example, one item is for mana consumables which will automatically be stacked with mana gems, mana pots, etc. that change dynamically based on a priority list and what is on cooldown.  You can create up to 18 categories and order the items in any way you please.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to open the Autobar options window",
        setProc = function() MazzleUI:Execute("/autobar"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Bongos Action Bars",
        requiredAddOn = "Bongos",
        addonDescription = "This add-on manages all of your button bars, as well as the main menu, key and bag bars.  It is highly suggested you spend some time to learn this add-on well so you can personalize and configure your buttons.  See the MazzleUI FAQ for detailed information about Bongos.  You can access several common Bongos options from the MazzleUI FuBar entry on the far right side of your FuBar.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Configure Buttons",
        label = "Click to open the Bongos options window.",
        setProc = function() MazzleUI:Execute("/bongos"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Clique",
        requiredAddOn = "Clique",
        addonDescription = "This add-on allows you to click on unit and raid frames to cast any spells on the unit or yourself.  This can be used for both offensive and defensive spells.  This add-on also works on the unit frames of certain other add-ons like NeedyList.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", 
        text = "Configuring click-casting is very simple.  First, open up the default blizzard spellbook (left-click on the MazzleUI text on the left side of the screen and click on the spellbook.)  Then click on the Clique tab, which is the bottom tab past your other spell schools.  You can follow the directions presented by Clique at that point.",
}
    table.insert(addItem, tempItem)


    tempItem = {
        type = "Notebox", 
        text = "If you bind right-clicking to a spell, you can still access the party menu by right-clicking on the little tab at the corner of the unit frame.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "cyCircled",
        requiredAddOn = "cyCircled",
        addonDescription = "This add-on modifies the shape of your buttons.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  cyCircled is under the 'Action Bars' category.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Gello's ItemRack",
        requiredAddOn = "ItemRack",
        addonDescription = "This extremely powerful add-on makes swapping equipment easier. One thing it does is provides a bar with one button for each item slot.  Mouseover the bar to access a menu of all items in your bags that can go in that slot. In addition, it provides extremely powerful set management.  Create an arbitrary number of sets or partial sets of equipment and swap them in with one click on the the ItemRack Fubar module (right side of Fubar.)  You can also automatically swap in equipment sets when certain events happen such as being mounted, startin evocation, etc.  This is an extremely powerful and polished add-on.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Item Rack",
        label = "Click here to configure your ItemRack sets, events and options",
        setProc = function() ItemRack_Sets_Toggle(); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Fubar ItemRackFu",
        requiredAddOn = "ItemRackFu",
        addonDescription = "This add-on provides a Fubar menu for the extremely powerful add-on, ItemRack, which makes swapping equipment easier. If you create sets of equipment, you can click on this Fubar entry to access a menu of those sets that you then put on in one click.  Right-clck to access to ItemRack options window to create and modify sets.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Gello's TrinketMenu",
        requiredAddOn = "TrinketMenu",
        addonDescription = "This is a mod to make swapping trinkets easier. It will display your two equipped trinkets in a bar. Mouseover on either trinket will display a menu of up to 30 trinkets in your bags to swap.  In addition, uou can also create a priority list of trinkets to automatically swap in as their cooldowns become available.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Show/Hide",
        label = "Click here to toggle your trinket menu visibility",
        setProc = function() MazzleUI:Execute("/trinketmenu"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 0,
        name = "Options",
        label = "Click here to configure your options and trinket priority list",
        setProc = function() MazzleUI:Execute("/trinketmenu opt"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Omni Cooldown Count",
        requiredAddOn = "OmniCC",
        addonDescription = "Omni Cooldown Count is a universal cooldown count plugin that provides cooldown counts for nearly every button in your UI.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", yadjust = -10,
        name = "Font Size:",
        minValue = 7,
        stepValue = 1,
        maxValue = 42,
        units = " pts",
        readFunc = function() return MazzleUI:GetValue("OmniCC.sets.fontSize") or 20; end,
        setProc = function(a,b) OmniCC:SetFontSize(tonumber(b)); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = -5,
        name = "Font",
        label = "Click to change the font used",
        setProc = function() MazzleUI:StartEditCommand("/omnicc font "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        notetype = "example", 
        text = "/omnicc font Fonts\\FRIZQT__.TTF",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Short Color",
        label = "Click to change the color used for less than 5.5 seconds",
        setProc = function() MazzleUI:StartEditCommand("/omnicc color short "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Medium Color",
        label = "Click to change the color used for less than 1 minute",
        setProc = function() MazzleUI:StartEditCommand("/omnicc color med "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Long Color",
        label = "Click to change the color used for less than one hour",
        setProc = function() MazzleUI:StartEditCommand("/omnicc color long "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Very Long Color",
        label = "Click to change the color used for longer durations",
        setProc = function() MazzleUI:StartEditCommand("/omnicc color vlong "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "You can specify a color with 3 numbers for <red value> <green value> <blue value>.  For example, '1 0 1' would be a purple color.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", yadjust = -10,
        name = "Scale size for less than 5.5 seconds =",
        minValue = 0.1,
        stepValue = .1,
        maxValue = 2,
        units = " x original size",
        readFunc = function() return MazzleUI:GetValue("OmniCC.sets.short.s") or 1; end,
        setProc = function(a,b) OmniCC:SetFontFormat("short", nil, nil, nil, tonumber(b)); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", yadjust = -10,
        name = "Scale size for less than 1 minute =",
        minValue = 0.1,
        stepValue = .1,
        maxValue = 2,
        units = " x original size",
        readFunc = function() return MazzleUI:GetValue("OmniCC.sets.med.s") or 1; end,
        setProc = function(a,b) OmniCC:SetFontFormat("med", nil, nil, nil, tonumber(b)); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", yadjust = -10,
        name = "Scale size for less than one hour =",
        minValue = 0.1,
        stepValue = .1,
        maxValue = 2,
        units = " x original size",
        readFunc = function() return MazzleUI:GetValue("OmniCC.sets.long.s") or 1; end,
        setProc = function(a,b) OmniCC:SetFontFormat("long", nil, nil, nil, tonumber(b)); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", yadjust = -10,
        name = "Scale size for for longer durations =",
        minValue = 0.1,
        stepValue = .1,
        maxValue = 2,
        units = " x original size",
        readFunc = function() return MazzleUI:GetValue("OmniCC.sets.vlong.s") or 1; end,
        setProc = function(a,b) OmniCC:SetFontFormat("vlong", nil, nil, nil, tonumber(b)); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "Scale allows you to change the size of the cooldown based on how much time is left.  For example, you can make it grow larger as it gets closer to finishing.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", yadjust = -10,
        name = "Only show on buttons with cooldowns greater than",
        minValue = 0,
        stepValue = .5,
        maxValue = 60,
        units = " seconds",
        parameter = "OmniCC.sets.minDur",}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -20,
        name = "Hide Blizzard 'clock' effect?",
        parameter = "OmniCC.sets.hideModel",}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton",
        name = "Flash a pulse when a skill goes off cooldown?",
        parameter = "OmniCC.sets.pulse",}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = -10,
        name = "Reset",
        label = "Click here to reset all OmniCC settings to default",
        setProc = function() MazzleUI:Execute("/omnicc reset"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Simple Action Sets",
        requiredAddOn = "SimpleActionSets",
        addonDescription = "Simple Action Sets is an add-on that allows you to save and restore which spells and actions are placed in which buttons.  You can use this to save your button placement if you want to try out another button layout and don't want to lose your old settings.",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 10,
        name = "Launch",
        label = "Click to open Simple Action Sets",
        setProc = function() MazzleUI:Execute("/sas"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "This add-on is not routinely used and is, by default, disabled.  Moreover, MazzleUI will automatically disable it after you're done using it.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Inspect()

    local addItem, tempItem = {}, {}
    addItem.name = "Inspecting"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Examiner",
        requiredAddOn = "Examiner",
        addonDescription = "Examiner is an advanced inspection mod which you can use to check other players gear, talents, honor and arena team details.\n\nWhen you inspect someone, it will show a stat summery of all their equipped gear combined.  Please note that these values are from gear alone, and will not include bonuses from buffs, talents or normal base stats.\n\nEach player you inspect, will be cached so you can look them up later, even when they are no where near you.  This option can be disabled if you prefer not to cache the people you inspect. To cache honor and arena details, you must enable the option to do so under the config page. Talents are not cached.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Talents()

    local addItem, tempItem = {}, {}
    addItem.name = "Talent Window"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Talented",
        requiredAddOn = "Talented",
        addonDescription = "This add-on provides an improved talent frame window in which you can see all three talent trees at once. In addition, you can use it in 'planning mode' as a talent calculator to play with potential specs.  You can access this by hitting the standard talent window keybinding of 'n'.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Quests()

    local addItem, tempItem = {}, {}
    addItem.name = "Quests"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "nQuestLog",
        requiredAddOn = "nQuestLog",
        addonDescription = "This add-on displays a powerful quest minion in a nice frame that is more powerful and customizable than Blizzard's.  It can dynamically change the contents of your quest list, play sounds when you finish quests and several other advanced features.  By default, you can access the nQuestLog minion by hitting L or clicking on the MazzleUI quest hotspot.  To further customize your quest minion, click on the nQuestLog entry in your Fubar.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "LightHeaded",
        requiredAddOn = "LightHeaded",
        addonDescription = "This add-on provides in-game access to all quest comments submitted to the web site WoWHead.  These comments often gives you coordinates and strategies to help you complete the quest.  Simply alt-click on a quest in your MonkeyQuest window to show these comments.  You can also click on a hyperlink inside a set of comments to create a tooltip that will stay on the screen after you close your quest window.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Title",
        label = "Click to search by quest title",
        setProc = function() MazzleUI:StartEditCommand("/qfind title "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Start",
        label = "Click to search by start item or NPC",
        setProc = function() MazzleUI:StartEditCommand("/qfind start "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "End",
        label = "Click to search by end item or NPC",
        setProc = function() MazzleUI:StartEditCommand("/qfind end "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 3,
        text = "The above search commands also accept LUA patterns to perform more complex searches.",
    }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Who()

    local addItem, tempItem = {}, {}
    addItem.name = "Who Window"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Who Favorites",
        requiredAddOn = "WhoFavorites",
        addonDescription = "This add-on allows you to save a list of frequently-used /who queries and recall them at will.  Click on the button next to the entry field in the Who window to add or remove searches from that list.  There are no options for this add-on.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Character()

    local addItem, tempItem = {}, {}
    addItem.name = "Character Window"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Sanity 2",
        requiredAddOn = "Sanity2",
        addonDescription = "This add-on allows you to view all of your character and bank inventories for *any* of your characters at any time.  It presents this valuable information in a list that is searchable.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_KeyBindings()

    local addItem, tempItem = {}, {}
    addItem.name = "Key Bindings"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "MyBindings 2",
        requiredAddOn = "myBindings2",
        addonDescription = "This add-on makes the key bindings interface much more user-friendly.  Rather than scrolling through a huge list of bindings, you can click on a key binding category and see only the bindings for that item.  There are no commonly-used options for this add-on.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "SpellBinder",
        requiredAddOn = "SpellBinder",
        addonDescription = "Nymbia's SpellBinder is an add-on that allows you to bind stuff to keys without taking up an actionbar slot.  Some of the 'hidden' bindings that the Mazzifier creates can be changed here.\n\n|CFFFF8000Usage:|r\n\n |CFF0000FF(1)|r:Click on a type of spell or action from the buttons on the left.\n\n |CFF0000FF(2)|r:Click on the 'Click to Set' button, then enter a key combination.\n\n |CFF0000FF(3)|r:Check that the spell, item or macro name is correct, check that the key combination is correct, then click 'Set Key'. That's it!\n ",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Launch",
        label = "Click here to open SpellBinder",
        setProc = function() MazzleUI:Execute("/spellbind"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Mail()

    local addItem, tempItem = {}, {}
    addItem.name = "Mail"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Postal",
        requiredAddOn = "Postal",
        addonDescription = "This add-on by Grennon of Argent Dawn adds several enhancements to your mail window: a popup list of favorite recipients, auto-remembering of last recipient used,  mail forwarding, mail content summary, subject auto-filling and the ability to perform operations on multiple messages at once.  It also allows for several keyboard shortcuts: shift-click to take item/money from mail, ctrl-click to return mail, alt-click to add an item to be sent in the current piece of mail.  A future version promises to restore the mass mailing feature.  There are no options for this add-on.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Loot()

    local addItem, tempItem = {}, {}
    addItem.name = "Loot Related"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "ItemSync",
        requiredAddOn = "ItemSync",
        addonDescription = "ItemSync is an item collection and manipulation mod that will gather items from many different sources.  ItemSync will always maintain an updated list of items and names. It�s all automatic and you don�t have to do a thing. Just let ItemSync work its magic. ItemSync will gather items from almost every possible location. This includes locations such as the Auction House, Bank, Inventory, Inspect Window, Chat Window, and more. ItemSync also stores the prices of items when you visit a Vendor.\n\n|CFFFF8000Other features:|r\n\n|CFF00FF00- Favorites Window:|r This feature allows you to store a list those items you come across and have always wanted. No more writing down items and then forgetting what they were called or what stats they had.\n\n|CFF00FF00- QuickBags:|r This feature provides a portable inventory bag, which displays prices of items in a simple to read format. No more having to hover items in your bags to view what each item is worth. Selling items to a vendor has never been easier!\n\n|CFF00FF00- Search Window:|r ItemSync comes with a very power search capability. You can search by items by location, rarity, level, and even resistance.\n\n|CFF00FF00- ItemID:|r ItemID is a nifty tool which allows you to manually input items by their item id to your database. This is a great way to add items you haven�t come across yet.\n\n|CFF00FF00- Filtering:|r ItemSync can store items based upon your filtering settings. Want ItemSync to only collect blue items and above? It�s easy with the Filter window. You can even purge the database by a specific rarity.\n\n|CFF00FF00- Fetch Links:|r This is a handy feature that allows you to quickly and easily link items in chat by using partial names. For example typing [*ore*] in the chat window would replace it with the actual link for [Copper Ore]. Fetch Links is a very powerful tool and has many applications.\n\nAll of the options for this add-on can be accessed via the ItemSync window.  To open it, Left-click on the bottom-right hotspot of MazzleUI.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "XLoot",
        addonName = "XLoot",
        addonDescription = "XLoot completely replaces the blizzard loot frame. XLoot is draggable, scaleable, colorable and configurable.  It also supports various plug-ins, two of which are used in MazzleUI.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  XLoot is under the 'Inventory' category",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "XLootGroup",
        addonName = "XLoot Group",
        addonDescription = "This add-on is a compact, efficient replacement for the blizzard loot roll frames.",
}

    table.insert(addItem, tempItem)
    tempItem = {
        type = "AddOnHeader", requiredAddOn = "XLootMaster",
        addonName = "XLoot Master",
        addonDescription = "XLoot Master is a replacement for the built-in master looting dropdown menu.  It allows you to distribute loot in a variety of ways.  A priority menu system allows you to create a custom menu with only certain people included and ordered as you wish, to ease distribution of common items. A random distribution system will choose randomly between all people who are in range, online and eligible for loot. And, finally a rolling system allows you to announce a roll and listen for X (default 30) seconds.  XLootMaster will capture all rolls in that time and display whichever ones match the range you define. All captured rolls can be clicked directly to distribute the item to that person.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Chat()

    local addItem, tempItem = {}, {}
    addItem.name = "Chat Windows"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "HitsMode",
        requiredAddOn = "HitsMode",
        addonDescription = "This important add-on formats your windows with cleaned-up, colored and easier-to-read combat log information.  It also filters out information that you don't want in a particular chat frame.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Left/Right Combat Logs",
        label = "Click here to configure combat messages ",
        setProc = function(a,b) MazzleUI:Execute("/hm"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", 
        text = "The settings for the left chat window, the thin one, are configured to succinctly display damage and healing done.  The right one, on the other hand, is intended to show a more verbose combat log which includes damage and healing taken to you , as well as all miscellaneous messages.",
}
    table.insert(addItem, tempItem)    
    
    tempItem = {
        type = "AddOnHeader", 
        addonName = "Prat",
        requiredAddOn = "Prat",
        addonDescription = "This add-on modifies the behavior and display of your chat window. Among the things it provides are:\n\n  |cFFFF0000(1)|r Abbreviated channel names\n  |cFFFF0000(2)|r Colored player names (by class)\n  |cFFFF0000(3)|r Access to chat history without holding down Alt\n  |cFFFF0000(4)|r Increased chat history length\n  |cFFFF0000(5)|r Edit box to the top of the chat window\n  |cFFFF0000(6)|r Chat links in any channel (other users must run Prat or ChatManager)\n  |cFFFF0000(7)|r Mouse wheel scrolling\n  |cFFFF0000(8)|r Removal of unnecessary chat buttons to save space\n  |cFFFF0000(9)|r Tab completion of names\n  |cFFFF0000(10)|r Incread number of chat channels that are sticky\n  |cFFFF0000(11)|r Time stamps\n",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to open Prat's options window",
        setProc = function() MazzleUI:Execute("/prat waterfall"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Crafting()

    local addItem, tempItem = {}, {}
    addItem.name = "Crafting"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Advanced Trade Skill Window",
        requiredAddOn = "AdvancedTradeSkillWindow",
        addonDescription = "ATSW is a complete replacement for Blizzards tradeskill window with an impressive set of features.  It:\n\n|CFFFF0000(1)|r Provides a larger window so you can see more\n\n|CFFFF0000(2)|r Allows sorting based on a variety of different criteria (alphabetical, by slot, by attribute, even custom categories)\n\n|CFFFF0000(3)|r Allows you to set filters that you can use to search for a recipe or only show certain recipes\n\n(4) Has a production list so you can quickly queue up multiple items.  It automatically adda all necessary sub-items that you must craft to make whatever it is you just added. It even lets you automatically compose a shopping list based on your production queue that you can later use at the auction house or at vendors!\n\nYou can access the options for this via when you open up any of your trade skill windows.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)

end

function MazzleOptions:AddOptions_Accessories()

    local addItem, tempItem = {}, {}
    addItem.name = "Accessories"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Answering Machine Plus",
        requiredAddOn = "AMP",
        addonDescription = "This add-on records messages that come to you in the whisper channel while you are away from your keyboard.  It will present the missed whispers when you exit afk or dnd state.  You can access most of the options for the Answer Machine Fubar menu.  The following are a few you can't sccess from that menu.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Change Message",
        label = "Click to change default message displayed when afk",
        setProc = function() MazzleUI:StartEditCommand("/amp msg "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Print Message",
        label = "Click to print current stored messages",
        setProc = function() MazzleUI:Execute("/amp play"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Add Ignore",
        label = "Click to add an ignore word (associated messages with word won't be recorded when afk)",
        setProc = function() MazzleUI:StartEditCommand("/amp ignore add "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Remove Ignore",
        label = "Click to remove a word from ignore list",
        setProc = function() MazzleUI:StartEditCommand("/amp ignore remove "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Ignore List",
        label = "Click to show all ignore words",
        setProc = function() MazzleUI:Execute("/amp ignore list"); end}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Answering Machine Fu",
			["requiredAddOn"] = "AMPFu",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on provides you with a Fubar menu item that allows you to change Answering Machine's settings and quickly see your messages.  You can access this from your Fubar.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Status Windows",
        requiredAddOn = "StatusWindow",
        addonDescription = "This add-on  allows you to build up to 10 StatusWindows. A StatusWindow holds up to 10 panes, each of which displays a piece of information, like clock, latency meter, FPS meter, durability monitor, health regen monitor, mana regen monitor, and more.  MazzleUI uses several of these on the right-hand side of the MazzleUI panel.  The durability display below the character frame is also a Status Window.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to configure Status Windows",
        setProc = function() MazzleUI:Execute("/statuswindow"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Omnibus",
        requiredAddOn = "Omnibus",
        addonDescription = "This add-on provides you with a virtual notebook to jot down little pieces of information that you may want to keep track of as you adventure.  You can create as many pages as you'd like, change the font size and even execute LUA code from it!",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Open Omnibus",
        label = "",
        setProc = function() MazzleUI:Execute("/omnibus toggle"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", 
        text = "You can always click on the HotSpot over the middle left corner of the MazzleUI panel to show or hide your TinyPad quickly.  The default keybinding for this add-on is 'J'.",
}
    table.insert(addItem, tempItem)
    tempItem = {
        type = "AddOnHeader", 
        addonName = "XCalc",
        requiredAddOn = "xcalc",
        addonDescription = "This add-on adds provides an in-game calculator.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 4,
        name = "Open",
        label = "Click here to launch XCalc",
        setProc = function() MazzleUI:ToggleBottomRightHotSpot("RightButton"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", 
        text = "This add-on can be quickly launched by right-clicking in the bottom right HotSpot of the MazzleUI panel.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_ClassHunter()

    local addItem, tempItem = {}, {}
    addItem.name = "Hunter"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "AntiDaze",
        requiredAddOn = "AntiDaze",
        addonDescription = "This add-on automatically cancels Aspect of the Cheetah or Pack when you or one of your party members get dazed.  It also provides a keybinding for manual cancellations.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = -5,
        name = "Options",
        label = "Click to configure Anti-Daze",
        setProc = function() MazzleUI:Execute("/antidaze options"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)


    tempItem = {
        type = "AddOnHeader", 
        addonName = "KingOfTheJungle",
        requiredAddOn = "KingOfTheJungle",
        addonDescription = "This add-on provides a feeding button for your pet whenever his happiness falls below a certain level.  Clicking on this button or using a keybindings will tell the add-on to choose an appropriate food and feed your pet.  King of the Jungle uses an intelligent food-choosing algorithm that utilizes a priority list based on information from the Periodic Table add-on.  You can modify this priority list in the add-ons options window",
}
    table.insert(addItem, tempItem)
    tempItem = {
        type = "Button", yadjust = -5,
        name = "Options",
        label = "Click to configure King Of The Jungle",
        setProc = function() MazzleUI:Execute("/kotj menu"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "FizzWidget's Hunter's Helper",
        requiredAddOn = "GFW_HuntersHelper",
        addonDescription = "When you mouse over a beast in the world with this add-on enabled, the tooltip will show which abilities a Hunter could learn after taming it. The abilities will be colored according to whether you�ve already learned them.  You can also use this add-on to get a list of all animals that can teach you a skill.",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = -5,
        name = "Find Animal",
        label = "Click to search for animals with a given skill",
        setProc = function() MazzleUI:StartEditCommand("/huntershelper find "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        notetype = "example", 
        text = "/huntershelper find Bite 6 to get a list of beasts known to have Bite (Rank 6). Results are sorted by zone.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)

end

function MazzleOptions:AddOptions_ClassMelee()

    local addItem, tempItem = {}, {}
    addItem.name = "Rogue"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Color Combo Points",
        requiredAddOn = "ColorComboPoints",
        addonDescription = "This add-on provides individually movable colored combo points for rogues and druids.  MazzleUI places them above the hud.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = -5,
        name = "Show",
        label = "Click to show your combo points so you can move them",
        setProc = function() MazzleUI:Execute("/ccp"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)
    
    tempItem = {
        type = "AddOnHeader", 
        addonName = "Poisoner",
        requiredAddOn = "Poisoner",
        addonDescription = "This add-on provides a little button from which you can apply all of your poisons.  Hover over the button and a menu of poison buttons will appear.  Left-click a poison to apply to your left weapon.  Right-click to apply to your right one.  There are no options for this add-on.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)

end

function MazzleOptions:AddOptions_ClassWarlock()

    local addItem, tempItem = {}, {}
    addItem.name = "Warlock"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "ShardAce", 
        addonDescription = "ShardAce provides a warlock with a series of buttons to quickly access their many overpowered skills.  Each of these buttons has different functionality depending on on the type of click you make:\n\n|CFFFF0000Shardcount Button|r\n |CFFFF8000- Left click|r:sorts your soul shards into a selected bag\n |CFFFF8000- Right click|r: opens a menu allowing access to the following spells (from right to left, top to bottom): Fel Domination, Enslave Demon, Demonic Sacrifice, Summon Imp, Summon Voidwalker, Summon Succubus, Summon Felhunter, Inferno, Ritual of Doom, Detect Invisibility, Unending Breath, Sense Demons, Demon Skin/Armor, Summon Felsteed/Dreadsteed, Ritual of Summoning, Eye of Kilrogg, Banish\n\n|CFFFF0000Soulstone button|r\n |CFFFF8000- Left click|r: Uses a Soulstone on your current target\n |CFFFF8000- Right click|r: Casts the highest rank Create Soulstone spell\n\n|CFFFF0000Spellstone button|r (displays a green glow if spellstone is equipped\n |CFFFF8000- Left click|r: Equips a Spellstone if one exists\n |CFFFF8000- Right click|r: Casts the highest rank Create Spellstone spell\n\n|CFFFF0000Firestone button|r (displays a green glow if firestone is equipped\n |CFFFF8000- Left click|r: Equips a Firestone if one exists\n |CFFFF8000- Right click|r: Casts the highest rank Create Firestone spell\n\n|CFFFF0000Healthstone button|r\n |CFFFF8000- Left click|r: Uses a healthstone if one exists\n |CFFFF8000- Right click|r: Casts the highest rank Create Healthstone spell\n |CFFFF8000- Middle click/Shift Right click|r: Puts a healthstone in the first slot of an open trade window, or initiates a trade with your current target\n\nYou can access the options for this add-on via the Niagra configuration utility in FuBar.  ShardAce is under the 'Warlock' category.",
        requiredAddOn = "ShardAce",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)

end

function MazzleOptions:AddOptions_ClassDruid()

    local addItem, tempItem = {}, {}
    addItem.name = "Druid"


    tempItem = {
        type = "AddOnHeader", 
        addonName = "Simple Druid Bar", 
        addonDescription = "This addon creates a mobile bar which displays the Druid's mana while in forms which would normally be unable to view it (bear and cat). This is only an estimate, since the real value is not available to the API, but it is an extremely accurate estimate. Currently accounted for are spirit, mana/5sec gear (but not buffs), Innervate, Stormage 3-piece set bonus, and the Rune of Metamorphosis. You can hold Shift to drag the bar around.",
        requiredAddOn = "SimpleDruidBar",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)

end

function MazzleOptions:AddOptions_AH()

    local addItem, tempItem = {}, {}
    addItem.name = "Auction House"

    tempItem = {
        type = "AddOnHeader",
        addonName ="Auction House Search",
        requiredAddOn = "AHsearch",
        addonDescription = "This add-on allows you to save commonly-used auction house searches for one-click future access.  Simply type in the search and then click on the menubutton next to the entry box.  There are no other options for this add-on.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader",
        addonName ="Auction House Show Bid",
        requiredAddOn = "AH_ShowBid",
        addonDescription = "This small add-on will annotate auctions that have bids placed on them with the words (bid).  There are no other options for this add-on.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader",
        addonName ="Fence",
        requiredAddOn = "Fence",
        addonDescription = "Fence is a modular and lightweight Ace2 tool for the daily auction house business.  Some of its key features are as follows:\n\n|CFFFF0000Auto Fill|r: Remembers the prices and durations of items you put into the auction house.\n\n|CFFFF0000Auto-buyout|r: Can set a customizable markup to fills the buyout when no price informations are available. So if the start price of an item is 1g and the markup is 1.5 the buyout would be 1.5g. \n\n|CFFFF0000Bid Watch|r: Simple module to protect you against scam. You can set a fixed amount (in copper) when Bid Watch should warn you. It will ask you with a popup dialog. Eg. you set 10000 copper (1 gold). If you click a bid for 2 gold the popup dialog will show and ask if you're really sure to bid for this item. \n\n|CFFFF0000Clicks|r: A powerful tool of Fence to shorten time-consuming and repeating processes by adding short-cuts for various actions.\n   |CFF0000FF- Alt-Left-click on an item in your inventory|r:  When at the auction house, this will automatically auction the selected item for either known or standard auction house price. When you're not in the auction house and a trade window is open, it will put the selected item into the trade window.\n   |CFF0000FF- Alt-Shift-Left-click|r: Sells the item immediately.\n   |CFF0000FF- Alt-Right-click|r: Splits a stack into one piece each time you click.\n   |CFF0000FF- Shift=Right-click|r: Splits a stack into its half.\n   |CFF0000FF- Ctrl-Right-click|r: Searches for that item. \n\n|CFFFF0000Sort|r: Adds another sort option to the auction house, 'Name'. \n\nYou can access the options for this add-on via the Niagra configuration utility in FuBar.  Fence is under the 'Interface Enhancements' category",
}
    table.insert(addItem, tempItem)
    
	tempItem = {
			["addonName"] = "qAHImproved",
			["requiredAddOn"] = "qAHImproved",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on provides the following AH Improvements: (1) adds a column to the Browse view, showing the price each for both buyout and bid prices, (2) adds a button to sort the Browse view by either Bid or Buyout price, (3) remembers the prices of items you've auctioned before, (4) remembers the duration of the last auction you set, (5) Makes the AH frame movable and (6) adds a column showing price per unit.",
		}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Tooltip()

    local addItem, tempItem = {}, {}
    addItem.name = "Tooltips"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "TinyTip",
        requiredAddOn = "TinyTip",
        addonDescription = "This add-on provides you with highly enhanced Tooltips for units.  Not only can you get increased information, but you can format the tooltip however you please.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Tiny Tip",
        label = "Click here to open the TipBuddy configuration window",
        setProc = function() MazzleUI:Execute("/tinytip"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Book of Crafts",
        requiredAddOn = "BookOfCrafts",
        addonDescription = "This add-on provide you with information regarding your other characters crafts. Whenever you display a recipe tooltips, it will list which character know this recipe already, which character may learn it now and which character will be able to learn it later.  There are no other options for this add-on.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "BOC Options",
        label = "",
        setProc = function() MazzleUI:Execute("/boc"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "tekKompare",
        requiredAddOn = "tekKompare",
        addonDescription = "This add-on allows you to get a comparison tooltip showing the 'currently equipped' item(s) so that you may compare it to an item you are looking at. This AddOn adds such a feature everywhere in the game where you can hover over items, such as in your bags, in the loot window or on the reward page of a quest. You also receive comparison tooltips when clicking an item link in the chat box.",
}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "FizzWidget's Disenchant Predictor",
			["requiredAddOn"] = "GFW_DisenchantPredictor",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on adds information to item tooltips listing what they are likely to be disenchanted to.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Show disenchant information in tooltips? (overrides other settings)",
        parameter = "FDP_Config.Tooltip"}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Show what level of items you'd need to disenchant in tooltips of enchant materials?",
        parameter = "FDP_Config.Reagents"}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Show what an item will likely disenchant to in tooltip of items?",
        parameter = "FDP_Config.Items"}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Add extra disenchanting instructions to tooltips?",
        parameter = "FDP_Config.Verbose"}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Automatically loot materials when disenchanting?",
        parameter = "FDP_Config.AutoLoot"}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = -5,
        name = "Predict",
        label = "Click to see what an item or items of a certain level disenchant to",
        setProc = function() MazzleUI:StartEditCommand("/enchant "); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 15,
        text = "Simply link an item or enter the item level after pressing the button.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "IDCard",
        requiredAddOn = "IDCard",
        addonDescription = "IDCard is a very small add-on that displays an item's icon next to the tooltip descriptions.  This can be helpful, especially with items that have almost no description.  You can also ctrl-click or shift-click on the IDCard picture to try on or link the item long after the link is gone from your chat window.  There are no options for this add-on.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Mendeleev",
        requiredAddOn = "Mendeleev",
        addonDescription = "This database adds some very useful information into an item's tooltip.  Depending on the item in question, it adds are where the items drops, what classes the items are useful for, and what recipes an item is used for.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  Mendeleev is under the 'Inventory' category.",
}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "RatingBuster",
			["requiredAddOn"] = "RatingBuster",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on translates the new combat rating bonuses in your tooltips into more easily understood percentage values.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  RatingBuster is under the 'Interface Enhancements' category.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Dr. Damage",
			["requiredAddOn"] = "DrDamage",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on will add a wealth of information to your tooltips about the effects of your spells with +dmg/healing gear equipped. Some of the information includes crit %, spell damage and damage coefficients, averages (w/ or w/o Crits/DoTs), DPS, DPSC (damage per seconds cast), Damage until OOM and more.  It will do similar calculations for healing classes.  Dr. Damage is also capable of actively scanning buffs on you / debuffs on target that affect damage/healing. In addition to these already powerful abilities, you can also manually enter hypotherical stats, like +dmg or +crit, to see how your spells will be affected by different gear!  You can access the options for this add-on via the Niagra configuration utility in FuBar.  Dr. Damage is under the 'Interface Enhancements' category.",
        }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end


function MazzleOptions:AddOptions_Libraries()

    local addItem, tempItem = {}, {}
    addItem.name = "Libraries"

    tempItem = {
			["addonName"] = "AbacusLib",
			["requiredAddOn"] = "AbacusLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library to provide tools for formatting money and time.",
        }
    table.insert(addItem, tempItem)

     tempItem = {
			["addonName"] = "Ace2",
			["requiredAddOn"] = "Ace2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is provides the core Ace 2 library.",
        }
    table.insert(addItem, tempItem)
    
     tempItem = {
			["addonName"] = "Ace3",
			["requiredAddOn"] = "Ace3",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is provides the core Ace 3 library.",
        }
    table.insert(addItem, tempItem)    
    
    tempItem = {
			["addonName"] = "AnchorsAway",
			["requiredAddOn"] = "AnchorsAway",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides a framework for setting anchors for frames.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Autobar Config ",
        requiredAddOn = "AutoBarConfig",
        addonDescription = "This add-on provides an options window for Autobar, the add-on that provides a category-based item bar on the right side of the MazzleUI panel.  This add-on only loads when you open the corresponding options window.",
}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-2.2",
			["requiredAddOn"] = "Babble-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Boss-2.2",
			["requiredAddOn"] = "Babble-Boss-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Class-2.2",
			["requiredAddOn"] = "Babble-Class-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Faction-2.2",
			["requiredAddOn"] = "Babble-Faction-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Fish-2.2",
			["requiredAddOn"] = "Babble-Fish-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Gas-2.2",
			["requiredAddOn"] = "Babble-Gas-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Herbs-2.2",
			["requiredAddOn"] = "Babble-Herbs-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Inventory-2.2",
			["requiredAddOn"] = "Babble-Inventory-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Mount-2.2",
			["requiredAddOn"] = "Babble-Mount-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Ore-2.2",
			["requiredAddOn"] = "Babble-Ore-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Quest-2.2",
			["requiredAddOn"] = "Babble-Quest-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Race-2.2",
			["requiredAddOn"] = "Babble-Race-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-SpellTree-2.2",
			["requiredAddOn"] = "Babble-SpellTree-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Spell-2.2",
			["requiredAddOn"] = "Babble-Spell-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Tradeskill-2.2",
			["requiredAddOn"] = "Babble-Tradeskill-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Trainer-2.2",
			["requiredAddOn"] = "Babble-Trainer-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Vendor-2.2",
			["requiredAddOn"] = "Babble-Vendor-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Babble-Zone-2.2",
			["requiredAddOn"] = "Babble-Zone-2.2",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides localization functions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "BigWigs_BlackTemple",
			["addonDescription"] = "This add-on is a library that provides Black Temple encounter information to BigWigs.",
			["type"] = "AddOnHeader",
			["requiredAddOn"] = "BigWigs_BlackTemple",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "BigWigs_Extras",
			["addonDescription"] = "This add-on is a library for BigWigs boss mods.",
			["type"] = "AddOnHeader",
			["requiredAddOn"] = "BigWigs_Extras",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "BigWigs_Hyjal",
			["addonDescription"] = "This add-on is a library that provides Hyjal encounter information to BigWigs.",
			["type"] = "AddOnHeader",
			["requiredAddOn"] = "BigWigs_Hyjal",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "BigWigs_Karazhan",
			["addonDescription"] = "This add-on is a library that provides Karazhan encounter information to BigWigs.",
			["type"] = "AddOnHeader",
			["requiredAddOn"] = "BigWigs_Karazhan",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "BigWigs_Outland",
			["addonDescription"] = "This add-on is a library that provides outdoor outland boss encounter information to BigWigs.",
			["type"] = "AddOnHeader",
			["requiredAddOn"] = "BigWigs_Outland",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a library that provides plug-in functionality for BigWigs.",
			["addonName"] = "BigWigs_Plugins",
			["requiredAddOn"] = "BigWigs_Plugins",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "BigWigs_SC",
			["addonDescription"] = "This add-on is a library that provides Serpentshrine Cavern encounter information to BigWigs.",
			["type"] = "AddOnHeader",
			["requiredAddOn"] = "BigWigs_SC",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "BigWigs_Sunwell",
			["addonDescription"] = "This add-on is a library that provides the Sunwell encounter information to BigWigs.",
			["type"] = "AddOnHeader",
			["requiredAddOn"] = "BigWigs_Sunwell",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "BigWigs_TheEye",
			["addonDescription"] = "This add-on is a library that provides Tempest Keep: The Eye encounter information to BigWigs.",
			["type"] = "AddOnHeader",
			["requiredAddOn"] = "BigWigs_TheEye",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Bongos_ActionBar",
			["requiredAddOn"] = "Bongos_ActionBar",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a library that Bongos uses to displays its actionbars.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Bongos_Options",
			["requiredAddOn"] = "Bongos_Options",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a library that Bongos uses to displays its options window.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "CandyBar",
			["requiredAddOn"] = "CandyBar",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library to draw timer bars.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_Battlegrounds",
			["requiredAddOn"] = "Cartographer_Battlegrounds",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to add specialized information when in a battleground.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_Coordinates",
			["requiredAddOn"] = "Cartographer_Coordinates",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module for displaying coordinates.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_Foglight",
			["requiredAddOn"] = "Cartographer_Foglight",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to show unexplored areas on the map.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_GroupColors",
			["requiredAddOn"] = "Cartographer_GroupColors",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to show colored icons for your party and raid members on the map.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_GuildPositions",
			["requiredAddOn"] = "Cartographer_GuildPositions",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to show your guildmates on your map even if they are not in your party.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_InstanceLoot",
			["requiredAddOn"] = "Cartographer_InstanceLoot",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module that lists what loot drops off what bosses in instances.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_InstanceMaps",
			["requiredAddOn"] = "Cartographer_InstanceMaps",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to show instance maps.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_InstanceNotes",
			["requiredAddOn"] = "Cartographer_InstanceNotes",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to show special points of interest, for example bosses, in instance maps.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_LookNFeel",
			["requiredAddOn"] = "Cartographer_LookNFeel",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to customize the look of your Cartographer maps.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_Notes",
			["requiredAddOn"] = "Cartographer_Notes",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to allow notes to be placed on your map.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_POI",
			["requiredAddOn"] = "Cartographer_POI",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to manage points of interest.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_Professions",
			["requiredAddOn"] = "Cartographer_Professions",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to track profession-based nodes like herbalism and mining spots.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_Waypoints",
			["requiredAddOn"] = "Cartographer_Waypoints",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module to allow yout to set POI's as waypoints.  These waypoints will have an arrow drawn for them, pointing you in their direction.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Cartographer_ZoneInfo",
			["requiredAddOn"] = "Cartographer_ZoneInfo",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Cartographer module which provides information while hovering over a zone.  It will show the levels of the zone, the instances in the zone, their levels, and the number of men the instance is made for (e.g. 5-man, 40-man).",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "CrayonLib",
			["requiredAddOn"] = "CrayonLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library for color selection.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Deadly Boss Mods: Battlegrounds",
			["requiredAddOn"] = "DBM_Battlegrounds",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is plug-in for Deadly Boss Mods that provides warning and timers for PvP battlegrounds.  You can access the options for these boss mods through the main Deadly Boss Mod options window.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Deadly Boss Mods: BlackTemple",
			["requiredAddOn"] = "DBM_BlackTemple",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is plug-in for Deadly Boss Mods that provides warning and timers for the Black Temple.  You can access the options for these boss mods through the main Deadly Boss Mod options window.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Deadly Boss Mods: GUI",
			["requiredAddOn"] = "DBM_GUI",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is plug-in for Deadly Boss Mods that provides the graphical components that display the options and various widgets.  You can access the options for these boss mods through the main Deadly Boss Mod options window.",
        }
    table.insert(addItem, tempItem)
    
    tempItem = {
			["addonName"] = "Deadly Boss Mods: Hyjal",
			["requiredAddOn"] = "DBM_Hyjal",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is plug-in for Deadly Boss Mods that provides warning and timers for Mount Hyjal.  You can access the options for these boss mods through the main Deadly Boss Mod options window.",
        }
    table.insert(addItem, tempItem)    

    tempItem = {
			["addonName"] = "Deadly Boss Mods: Karazhan",
			["requiredAddOn"] = "DBM_Karazhan",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is plug-in for Deadly Boss Mods that provides warning and timers for the Karazhan 10-man instance.  You can access the options for these boss mods through the main Deadly Boss Mod options window.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Deadly Boss Mods: Serpentshrine Caverns",
			["requiredAddOn"] = "DBM_Serpentshrine",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is plug-in for Deadly Boss Mods that provides warning and timers for the 25-man Serpentshrine Caverns instance in Coilfang Reservoir.  You can access the options for these boss mods through the main Deadly Boss Mod options window.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Deadly Boss Mods: The Eye",
			["requiredAddOn"] = "DBM_TheEye",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is plug-in for Deadly Boss Mods that provides warning and timers for the 25-man Tempest Keep instance.  You can access the options for these boss mods through the main Deadly Boss Mod options window.",
        }
    table.insert(addItem, tempItem)
    
    tempItem = {
			["addonName"] = "Deadly Boss Mods: ZulAman",
			["requiredAddOn"] = "DBM_ZulAman",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is plug-in for Deadly Boss Mods that provides warning and timers for Zul'Aman.  You can access the options for these boss mods through the main Deadly Boss Mod options window.",
        }
    table.insert(addItem, tempItem)    

    tempItem = {
			["addonName"] = "Deadly Boss Mods: Other Encounters",
			["requiredAddOn"] = "DBM_Other",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is plug-in for Deadly Boss Mods that provides warning and timers for smaller instances and encounters, namely Doomwalker, Gruul, Kazzak, Magtheridon and Maulgar.  You can access the options for these boss mods through the main Deadly Boss Mod options window.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Deformat",
			["requiredAddOn"] = "Deformat",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "DewdropLib",
			["requiredAddOn"] = "DewdropLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library for creating dropdown menus.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Discord Library",
        requiredAddOn = "DiscordLibrary",
        addonDescription = "This add-on provides support functions for all of the Discord add-ons.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Discord Unit Frames Options",
        requiredAddOn = "DiscordUnitFramesOptions",
        addonDescription = "This add-on provides an options window for Discord Unit Frames, the add-on that displays unit frames for you and your party's characters.  This add-on only loads when you open the corresponding options window.",
}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "FuBarPlugin-2.0",
			["requiredAddOn"] = "FuBarPlugin-2.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides a framework for add-ons to make FuBar menu plugins.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "GloryLib",
			["requiredAddOn"] = "GloryLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that manages battleground related information.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "GratuityLib",
			["requiredAddOn"] = "GratuityLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "LightHeaded_Data_A",
			["requiredAddOn"] = "LightHeaded_Data_A",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This is a load-on-demand module that allows Lightheaded, the add-on that provides WoWHead comments in-game, to save memory by only loading a subset of quest data when needed.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "LightHeaded_Data_B",
			["requiredAddOn"] = "LightHeaded_Data_B",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This is a load-on-demand module that allows Lightheaded, the add-on that provides WoWHead comments in-game, to save memory by only loading a subset of quest data when needed.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "LightHeaded_Data_C",
			["requiredAddOn"] = "LightHeaded_Data_C",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This is a load-on-demand module that allows Lightheaded, the add-on that provides WoWHead comments in-game, to save memory by only loading a subset of quest data when needed.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "LightHeaded_Data_D",
			["requiredAddOn"] = "LightHeaded_Data_D",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This is a load-on-demand module that allows Lightheaded, the add-on that provides WoWHead comments in-game, to save memory by only loading a subset of quest data when needed.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "LightHeaded_Data_E",
			["requiredAddOn"] = "LightHeaded_Data_E",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This is a load-on-demand module that allows Lightheaded, the add-on that provides WoWHead comments in-game, to save memory by only loading a subset of quest data when needed.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["type"] = "AddOnHeader",
			["addonName"] = "LittleWigs_Auchindoun",
			["requiredAddOn"] = "LittleWigs_Auchindoun",
			["addonDescription"] = "This add-on is a library that provides Auchindoun encounter information to Little Wigs.",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["type"] = "AddOnHeader",
			["addonName"] = "LittleWigs_Coilfang",
			["requiredAddOn"] = "LittleWigs_Coilfang",
			["addonDescription"] = "This add-on is a library that provides Coilfang Reservoir encounter information to Little Wigs.",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["type"] = "AddOnHeader",
			["addonName"] = "LittleWigs_CoT",
			["requiredAddOn"] = "LittleWigs_CoT",
			["addonDescription"] = "This add-on is a library that provides Caverns of Time encounter information to Little Wigs.",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["type"] = "AddOnHeader",
			["addonName"] = "LittleWigs_HellfireCitadel",
			["requiredAddOn"] = "LittleWigs_HellfireCitadel",
			["addonDescription"] = "This add-on is a library that provides Hellfire Citadel encounter information to Little Wigs.",
		}
    table.insert(addItem, tempItem)
    
    tempItem = {
			["type"] = "AddOnHeader",
			["addonName"] = "LittleWigs_MagistersTerrace",
			["requiredAddOn"] = "LittleWigs_MagistersTerrace",
			["addonDescription"] = "This add-on is a library that provides Magister's Terrace encounter information to Little Wigs.",
		}
    table.insert(addItem, tempItem)    

    tempItem = {
			["type"] = "AddOnHeader",
			["addonName"] = "LittleWigs_TempestKeep",
			["requiredAddOn"] = "LittleWigs_TempestKeep",
			["addonDescription"] = "This add-on is a library that provides Tempest Keep encounter information to Little Wigs.",
		}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleOptions",
			["requiredAddOn"] = "MazzleOptions",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This is the MazzleUI add-on that provides the window you are looking at!",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI Preloader",
			["requiredAddOn"] = "!!MazzleUI_Preloader",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on allows MazzleUI to perform tweaks on other add-ons as soon as they load.  In this way, we can perform modifications without altering the other add-on's code.  In some cases, this will allow us to update the add-on without having to re-do the changes every time.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI_Default_Skin",
			["requiredAddOn"] = "MazzleUI_Default_Skin",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for the default MazzleUI skin.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI_Skin_Minyaen_Dungeon",
			["requiredAddOn"] = "MazzleUI_Skin_Minyaen_Dungeon",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for Minyaen's Dungeon skin.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI_Skin_Kappatre_Slate",
			["requiredAddOn"] = "MazzleUI_Skin_Kappatre_Slate",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for Kappatre's Slate skin.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI_Skin_Dreadlorde_Discord",
			["requiredAddOn"] = "MazzleUI_Skin_Dreadlorde_Discord",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for Dreadlorde's Discord skin.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI_Skin_Noob123_BlackMetal",
			["requiredAddOn"] = "MazzleUI_Skin_Noob123_BlackMetal",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for Noob123's Black Metal skin.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI_Skin_Noob123_EQ",
			["requiredAddOn"] = "MazzleUI_Skin_Noob123_EQ",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for Noob123's Everquest skin.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI_Skin_Noob123_NE",
			["requiredAddOn"] = "MazzleUI_Skin_Noob123_NE",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for Noob123's Night Elf skin.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI_Skin_Noob123_Undead",
			["requiredAddOn"] = "MazzleUI_Skin_Noob123_Undead",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for Noob123's Undead skin.",
        }
    table.insert(addItem, tempItem)
    
    tempItem = {
    			["addonName"] = "MazzleUI_Skin_Lichking",
    			["requiredAddOn"] = "MazzleUI_Skin_Lichking",
    			["type"] = "AddOnHeader",
    			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for geeskins LichKing Skin.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI_Skin_Elcarath_Orc",
			["requiredAddOn"] = "MazzleUI_Skin_Elcarath_Orc",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for Elcarath's Orc skin.",
        }
    table.insert(addItem, tempItem)    
    
    tempItem = {
			["addonName"] = "MazzleUI_Skin_Elcarath_Draenei",
			["requiredAddOn"] = "MazzleUI_Skin_Elcarath_Draenei",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for Elcarath's Draenei skin.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "MazzleUI_Skin_Keinara_BloodElf",
			["requiredAddOn"] = "MazzleUI_Skin_Keinara_BloodElf",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for Keinara's Blood Elf skin.",
        }
    table.insert(addItem, tempItem)
    
    tempItem = {
			["addonName"] = "MazzleUI_Skin_Diablo",
			["requiredAddOn"] = "MazzleUI_Skin_Diablo",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for geeskins Diablo Skin.",
        }
    table.insert(addItem, tempItem)
    
    tempItem = {
			["addonName"] = "MazzleUI_Skin_War",
			["requiredAddOn"] = "MazzleUI_Skin_War",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This load-on-demand add-on provides artwork and layout information for geeskins Warhammer Skin.",
        }
    table.insert(addItem, tempItem)    

    tempItem = {
			["addonName"] = "Metrognome",
			["requiredAddOn"] = "Metrognome",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that allows add-ons to set up OnUpdate-like processing using any arbitrary timer interval.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "oRA2_Leader",
			["requiredAddOn"] = "oRA2_Leader",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module of oRA2.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "oRA2_Optional",
			["requiredAddOn"] = "oRA2_Optional",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module of oRA2.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "oRA2_Participant",
			["requiredAddOn"] = "oRA2_Participant",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module of oRA2.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "PaintChipsLib",
			["requiredAddOn"] = "PaintChipsLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library for color selection management.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Parser-3.0",
			["requiredAddOn"] = "Parser-3.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library for general string parsing.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "ParserLib",
			["requiredAddOn"] = "ParserLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library for combat log parsing.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Periodic Table 3.0",
			["requiredAddOn"] = "PeriodicTable-3.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides many useful databases that add-ons can query for information.  The 3.0 version compresses its data to save memory, unlike the previous versions of Periodic Table, which are included because some older add-ons still use them. There are no commonly used options for this add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "PeriodicTable-3.0-Consumable",
			["requiredAddOn"] = "PeriodicTable-3.0-Consumable",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides some of Periodic Table's databases.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "PeriodicTable-3.0-Gear",
			["requiredAddOn"] = "PeriodicTable-3.0-Gear",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides some of Periodic Table's databases.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "PeriodicTable-3.0-GearSet",
			["requiredAddOn"] = "PeriodicTable-3.0-GearSet",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides some of Periodic Table's databases.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "PeriodicTable-3.0-InstanceLoot",
			["requiredAddOn"] = "PeriodicTable-3.0-InstanceLoot",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides some of Periodic Table's databases.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "PeriodicTable-3.0-InstanceLootHeroic",
			["requiredAddOn"] = "PeriodicTable-3.0-InstanceLootHeroic",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides some of Periodic Table's databases.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "PeriodicTable-3.0-Misc",
			["requiredAddOn"] = "PeriodicTable-3.0-Misc",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides some of Periodic Table's databases.",
        }
    table.insert(addItem, tempItem)    
    
    tempItem = {
			["addonName"] = "PeriodicTable-3.0-Reputation",
			["requiredAddOn"] = "PeriodicTable-3.0-Reputation",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides some of Periodic Table's databases.",
        }
    table.insert(addItem, tempItem)
    
    tempItem = {
			["addonName"] = "PeriodicTable-3.0-Tradeskill",
			["requiredAddOn"] = "PeriodicTable-3.0-Tradeskill",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides some of Periodic Table's databases.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "PeriodicTable-3.0-TradeskillResultMats",
			["requiredAddOn"] = "PeriodicTable-3.0-TradeskillResultMats",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides some of Periodic Table's databases.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Prat_AutoLoD",
			["requiredAddOn"] = "Prat_AutoLoD",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Prat module.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Prat_Modules_AutoLoD",
			["requiredAddOn"] = "Prat_Modules_AutoLoD",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Prat module.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Prat_Modules",
			["requiredAddOn"] = "Prat_Modules",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a Prat module.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Buff",
			["requiredAddOn"] = "Quartz_Buff",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Flight",
			["requiredAddOn"] = "Quartz_Flight",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Focus",
			["requiredAddOn"] = "Quartz_Focus",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_GCD",
			["requiredAddOn"] = "Quartz_GCD",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Interrupt",
			["requiredAddOn"] = "Quartz_Interrupt",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Latency",
			["requiredAddOn"] = "Quartz_Latency",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Mirror",
			["requiredAddOn"] = "Quartz_Mirror",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Pet",
			["requiredAddOn"] = "Quartz_Pet",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Player",
			["requiredAddOn"] = "Quartz_Player",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Range",
			["requiredAddOn"] = "Quartz_Range",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Swing",
			["requiredAddOn"] = "Quartz_Swing",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Target",
			["requiredAddOn"] = "Quartz_Target",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Timer",
			["requiredAddOn"] = "Quartz_Timer",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz_Tradeskill",
			["requiredAddOn"] = "Quartz_Tradeskill",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for Quarts, a full-featured castbar add-on.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quixote",
			["requiredAddOn"] = "Quixote",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides quest-related functions for other add-ons to use.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "RosterLib",
			["requiredAddOn"] = "RosterLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Sanity Item Cache",
			["requiredAddOn"] = "SanityItemCache",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is library used by Sanity 2, the add-on that gives you a searchable database of bag and bank inventories for all your characters.  This library provides a central repository for all the items that Sanity 2 keeps tracks.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "SCT Options",
        requiredAddOn = "sct_options",
        addonDescription = "This add-on provides an options window for Scrolling Combat Text, the add-on that displays combat information in the middle of your screen.  This add-on only loads when you open the corresponding options window.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "SCTD Options",
        requiredAddOn = "sctd_options",
        addonDescription = "This add-on provides an options window for the damage module of Scrolling Combat Text, the add-on that displays outgoing damage information in the middle of your screen.  This add-on only loads when you open the corresponding options window.",
}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SharedMediaLib",
			["requiredAddOn"] = "SharedMediaLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides a common set of textures, graphics and sounds that all Ace add-ons can use.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SpecialEventsEmbed",
			["requiredAddOn"] = "SpecialEventsEmbed",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides improved and streamlined events to other add-ons.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SpecialEvents-Aura-2.0",
			["requiredAddOn"] = "SpecialEvents-Aura-2.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for SpecialEvents that handles a subset of events.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SpecialEvents-Bags-2.0",
			["requiredAddOn"] = "SpecialEvents-Bags-2.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for SpecialEvents that handles a subset of events.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SpecialEvents-Equipped-2.0",
			["requiredAddOn"] = "SpecialEvents-Equipped-2.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for SpecialEvents that handles a subset of events.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SpecialEvents-LearnSpell-2.0",
			["requiredAddOn"] = "SpecialEvents-LearnSpell-2.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for SpecialEvents that handles a subset of events.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SpecialEvents-Loot-1.0",
			["requiredAddOn"] = "SpecialEvents-Loot-1.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for SpecialEvents that handles a subset of events.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SpecialEvents-Mail-2.0",
			["requiredAddOn"] = "SpecialEvents-Mail-2.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for SpecialEvents that handles a subset of events.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SpecialEvents-Mount-2.0",
			["requiredAddOn"] = "SpecialEvents-Mount-2.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for SpecialEvents that handles a subset of events.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SpecialEvents-Movement-2.0",
			["requiredAddOn"] = "SpecialEvents-Movement-2.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a module for SpecialEvents that handles a subset of events.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SpellEventsLib",
			["requiredAddOn"] = "SpellEventsLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides improved and streamlined spell-related events to other add-ons.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "StatLogicLib",
			["requiredAddOn"] = "StatLogicLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides functions to calculate statistics based on WoW's game mechanics.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "SW UniLog",
			["requiredAddOn"] = "SW_UniLog",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is library used by SWStats.",
        }
    table.insert(addItem, tempItem)
    
    tempItem = {
			["addonName"] = "SWStats Profiles",
			["requiredAddOn"] = "SW_Stats_Profiles",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is library used by SWStats to allow saving and loading of profiles between characters.",
        }
    table.insert(addItem, tempItem)    

    tempItem = {
			["addonName"] = "TabletLib",
			["requiredAddOn"] = "TabletLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library for making both normal and detachable tooltips.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "TableTopLib",
			["requiredAddOn"] = "TableTopLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library to handle the creation and management of graphical tables with resizable and sortable columns.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "TagCompiler-1.0",
			["requiredAddOn"] = "TagCompiler-1.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a library for generating the special tags that Aloft nameplate uses.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Talismonger 3.0",
			["requiredAddOn"] = "Talismonger-3.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides events and information about interactable nodes, loot and profession mats.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Talented_Data",
			["requiredAddOn"] = "Talented_Data",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a library used by Talented to store tooltip descriptions for different talent allocations.  This allows Talented to show you exactly what benefits you get when you're playing with hypothetical talent distributions.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Talented_DrDamage",
			["requiredAddOn"] = "Talented_DrDamage",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a library used by Talented to store tooltip descriptions for different talent allocations.  This allows Talented to show you exactly what benefits you get when you're playing with hypothetical talent distributions.",
        }
    table.insert(addItem, tempItem)
    
    tempItem = {
			["addonName"] = "Talented_Loader",
			["requiredAddOn"] = "Talented_Loader",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is a library used by Talented to store tooltip descriptions for different talent allocations.  This allows Talented to show you exactly what benefits you get when you're playing with hypothetical talent distributions.",
        }
    table.insert(addItem, tempItem)    

    tempItem = {
        type = "AddOnHeader", 
        addonName = "TinyTip Extras",
        requiredAddOn = "TinyTipExtras",
        addonDescription = "This is a library used by Tiny Tip for added functionality to the standard tooltips.  There are no options for this add-on.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "TinyTip Options",
        requiredAddOn = "TinyTipOptions",
        addonDescription = "This add-on provides an options window for TinyTip, the add-on that displays and formats your tooltips.  This add-on only loads when you open the corresponding options window.",
}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "TipHookerLib",
			["requiredAddOn"] = "TipHookerLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that allows add-ons to modify tooltips in a consistent way that will play well with other add-ons.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "TipLib",
			["requiredAddOn"] = "TipLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library of common functions for tooltips.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "TouristLib",
			["requiredAddOn"] = "TouristLib",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides zone information.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Waterfall",
			["requiredAddOn"] = "Waterfall-1.0",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on is an Ace 2 library that provides Ace 2 add-ons with an easy way to make graphical option systems.",
        }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Battlegrounds()

    local addItem, tempItem = {}, {}
    addItem.name = "Battlegrounds and PvP"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "ArenaPointer",
        requiredAddOn = "ArenaPointer",
        addonDescription = "This simple add-on adds a little bit of information to the arena portion of the PvP information pane.  Right next to your arena team's current score, it will show how many points you would earn if you end the arena week at that score.  There are no options for this add-on.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "ArenaUnitFrames",
        requiredAddOn = "ArenaUnitFrames",
        addonDescription = "This powerful add-on provides unit frames for your arena opponents.  These unit frames will show your enemies' health, mana, debuffs, target of target and castbars.  Arena opponents that are crowd-controlled will have their class icon changed so you can quickly see what kind of CC is applied to them, for example sheep, fear, seduce, etc.\n\n- Left click the frame to target the unit. Right click to target + focus the unit. If no unit is currently focused, then left clicking will also focus. It is advisable to focus a target you do not intend to kill first.\n\n- The little class icons to the right of the unit's target indicate your allies are targeting that unit. You can click on these icons to target that unit, even if that unit frame was not created prior to combat.\n",
}
    table.insert(addItem, tempItem)
    
    tempItem = {
        type = "Button", yadjust = -5,
        name = "Show",
        label = "Click to show the Arena Unit Frames",
        setProc = function() MazzleUI:Execute("/auf"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", notetype = "warning",
        text= "Due to the nature of Blizzard's UI interface, this add-on has some limitations it can't get around:\n\n- You or somebody else in your group with this addon must mouseover or target your opponents before a unit frame is created for them.\n\n- You or somebody else in your group with this addon must mouseover/target your opponents prior to entering combat for the unit frames to be clickable.  If you fail to do so, then the ability to target when clicking on the frame will be set the instant you leave combat. Frames without click-to-target functionality will display a reddish hue icon.\n\n- You, your focus, your pet, or someone else on your team must have the opponent/unit targeted (or be the target of this target) in order for his/her frame to display up-to-date health and mana, debuffs, ToT, and cast bars. If nobody has that person targeted, then somebody with the addon installed can mouseover or focus said target to update that player's hitpoints and mana for your team. Frames that are semi-transparent indicate a unit that is not targeted (by you other other teammates) or focused, and that the hp and mana of this player may be inaccurate, and do not show debuffs or casting bars.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Capping",
        requiredAddOn = "Capping",
        addonDescription = "This add-on provides a set of timers for the various objectives in Alterac Valley, Arathi Basic, Eye of the Storm and Warsong Gulch.  Clicking on bars allows you to announce information related to the timer to your teammates.  Ctrl-click to send that information to the /bg channgel.",
}
    table.insert(addItem, tempItem)
    
    tempItem = {
        type = "Button", yadjust = -5,
        name = "Options",
        label = "Click to configure Capping",
        setProc = function() MazzleUI:Execute("/capping"); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_BattlegroundFu",
        addonName = "FuBar BattlegroundFu",
        addonDescription = "This add-on provides a multitude of Battleground related functions:  Queue timer display for all battlegrounds queues, change/join/leave commands, tooltip displays with detailed timers that can be detached to work as an on-screen frame, in-game scoreboard summary for your character in shorthand format on the bar, detachable in-game tooltip with full scoreboard summary for your character, team sizes, team scores (AB/WSG), number of bases held (AB), objective Status report w/ timers (AB/AV), flag carriers (click to target in WSG) and real-time scoreboard.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_HonorFu",
        addonName = "FuBar HonorFu",
        addonDescription = "This add-on keeps track of honor and PvP statistics. It keeps track of: current honor (accurately), battlegrounds wins/losses, honorable kills/deaths and PVP Cooldown.  The add-on will also tell you when the next battleground weekend occurs and what your rating/rank limit for your level is.  It also does a few active things like auto-releasing on bg death, automatically showing bg map, keeping track of enemy flag carrier (allowing you to target them) and printing reputation gain for honor-related factions.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Fubar()

    local addItem, tempItem = {}, {}
    addItem.name = "FuBar Add-Ons"

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar",
        addonName = "Fubar",
        addonDescription = "This add-on and its modules creates a power toolbar at the top of your screen.  You can access option for the different Fubar modules by right-clicking on their display in the top bar.  You can access general Fubar options by right-clicking on an empty portion of the top bar.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 15,
        text = "This MazzleOptions category only contains the FuBar plug-ins that did not clearly fit in another category.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "Niagara",
        addonName = "Niagara",
        addonDescription = "This add-on gives you a graphical interface from which you can change the settings of most Ace 2 add-ons without having to learn their slash commands.  Since so many of MazzleUI's add-ons are Ace2, this is a very important plug-in.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", yadjust = 15,
        text = "In addition to simply opening up Niagara and searching for the add-on you're interested in, you can find the add-on here in MazzleOptions and click the 'Open Niagara Options' button.  Users may find it easier to find an add-on in MazzleOptions since it contains both an alphabetical listing of add-ons and a more intuitive category scheme.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_AmmoFu",
        addonName = "FuBar AmmoFu",
        addonDescription = "This add-on shows how much ammo you have left.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "Fubar_Auto_LootFu",
        addonName = "FuBar AutoLoot Fu",
        addonDescription = "This add-on allows you to quickly turn on/off WoW's auto-looting feature.  It also allows you to automatically switch off auto-looting in parties and raids.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "FuBar AnkhTimerFu",
        requiredAddOn = "FuBar_AnkhTimerFu",
        addonDescription = "This shaman-specific add-on displays both how many Ankhs you have and their related cooldowns.  You can change options for this add-on by right-clicking its entry in your FuBar.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_CombatInfoFu",
        addonName = "FuBar CombatInfoFu",
        addonDescription = "This add-on provides a variety of summary combat skill information like Block/Crit/Dodge/Parry/Armor as well as Mainhand, Offhand, and Ranged Attack numbers.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_DurabilityFu",
        addonName = "FuBar DurabilityFu",
        addonDescription = "This add-on shows you a detailed breakdown of your armor and weapon durability including the cost to repair.  When you visit a vendor, it will automatically present you with an option repair damaged items.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_ExperienceFu",
        addonName = "FuBar ExperienceFu",
        addonDescription = "This add-on shows you detailed tracking of your character's experience points.  It shows current, rest, and pet XP in percent, absolute value, points to next level or xp/time.  It can also show time to level based on either the session or the past level played.  Finally, it shows total time played by session, level or overall.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_FactionsFu",
        addonName = "FuBar FactionsFu",
        addonDescription = "This add-on shows you your current reputation with all factions.  Click on a faction to monitor it.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_FarmerFu",
        addonName = "FuBar FuBar_FarmerFu",
        addonDescription = "This add-on allows you to track how many items you have of something you're presumably farming.  It takes into account both your current inventory and bank.  Right-click on the Fubar to edit the list of what it tracks.  By default, the Mazzifier sets it up to track primals and motes.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_FriendsFu",
        addonName = "FuBar FriendsFu",
        addonDescription = "This add-on shows your online friends.  You can sort the list of players by different values and you can set some filters (eg. specific classes, level ranges or zones). It will also show an indicator if you're grouped with that player.  Click a player to whisper him, shift-click a player to paste its name to chat, alt-click a player to send an invite.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_GarbageFu",
        addonName = "FuBar GarbageFu",
        addonDescription = "GarbageFu is a plugin to FuBar 2.0 that helps you clean your bags of Garbage by letting you drop the least valuable item/s. Or if you are at a merchant you can simply select to sell all your Garbage to him by pressing a button.\n\n|CFFFF0000Features|r:\n Drop least valuable item.\n- Shows all items that can be dropped along with there total value in a tooltip.\n- Sell all that are shown in the tooltip or all grey items to a vendor with the press of a button.\n- Select what to drop and what to keep by Sets, Type, Items and Quality threshold.\n- Supports several addons for retrieval of price information, including it's own.\n- Select sets of items to use auction price for instead of vendor price.\n- Select item quality threshold for when to use auction price instead of vendor price.\n- Supports Autioneer, KC_Items and WoWEcon for Auction prices.\n- Display total/free/used bag slots on the toolbar.\n- Toggle bags display with a quick click.\n\nYou can configure this add-on via its entry in your FuBar.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_GuildFu",
        addonName = "FuBar GuildFu",
        addonDescription = "This add-on shows your online guildmates.  You can sort the list of players by different values and you can set some filters (eg. specific classes, level ranges or zones). It will also show an indicator if you're grouped with that player.  Click a player to whisper him, shift-click a player to paste its name to chat, alt-click a player to send an invite.",
}
    table.insert(addItem, tempItem)


    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_MailFu",
        addonName = "FuBar MailFu",
        addonDescription = "This add-on provides notifications of new mail on your FuBar.",
}
    table.insert(addItem, tempItem)
 
    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_MoneyFu",
        addonName = "FuBar MoneyFu",
        addonDescription = "This add-on tracks information about the money you earn and spend.  It does this for all of your characters.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_ReagentFu",
        addonName = "FuBar ReagentFu",
        addonDescription = "This add-on provides a quick way to see how many reagents you have left.  It automatically configures itself based on your class.  Right-click to add or remove items.",
}
    table.insert(addItem, tempItem)
  
    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_SkillsPlusFu",
        addonName = "FuBar SkillsPlusFu Light",
        addonDescription = "This add-on provides a tooltip which contains most of the information from the skills and professions panel, as well as timers for you various character's transmutes.  You can also choose a skill to watch on the bar. Left-click on the icon to display the skills panel.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_TopScoreFu",
        addonName = "FuBar TopScoreFu",
        addonDescription = "This add-on keeps track of your top damage/heals and alerts you with a large message and sound when you get a new record.  It distinguishes between normal and critical hits, as well as between PvP and PvE damage.  Shift-clicking to put information in the chat box.  Can also be set to take a screenshot when record occurs.",
}
    table.insert(addItem, tempItem)
  
    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_VolumeFu",
        addonName = "FuBar VolumeFu",
        addonDescription = "This add-on gives you a quick way to change the various volume levels as well as disable them entirely.  Mousing over this add-on will also reset your volume, allowing you to quickly recover from that annoying bug that sometimes maximizes your volume when you tab out of WoW.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end


function MazzleOptions:AddOptions_SCTAddOns()

    local addItem, tempItem = {}, {}
    addItem.name = "Scrolling/Floating Combat Text"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Scrolling Combat Text",
        requiredAddOn = "sct",
        addonDescription = "This add-on adds damage, heals, and events (dodge, parry, windfury, etc...) as scrolling text above you character model, much like what already happens above your target. This makes it so you do not have to watch (or use) your regular combat chat window and can see important information quickly.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to configure SCT",
        setProc = function() MazzleUI:Execute("/sct menu"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Scrolling Combat Text Damage",
        requiredAddOn = "sctd",
        addonDescription = "This add-on is a plugin for SCT that lets it also handle the damage done to your target.  It has far more options that the default Blizzard damage display.  Settings for this add-on can be changed via the main SCT options window.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "WitchHunt",
        requiredAddOn = "WitchHunt",
        addonDescription = "This add-on provides large banner messages when enemies near you cast spells or perform emotes.  This lets you more quickly react to important actions your enemy performs do without needing to examing the combat or chat windows.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  Witchhunt is under the 'Interface Enhancements' category.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_DamageMeter()

    local addItem, tempItem = {}, {}
    addItem.name = "Damage/Threat Meters"


    tempItem = {
        type = "AddOnHeader", 
        addonName = "KLH ThreatMeter",
        requiredAddOn = "KLHThreatMeter",
        addonDescription = "This add-on monitors and records your threat, and will list your threat in a table with other members of your party or raid group who are using the mod. Most class talents, abilities, and items that cause or modify threat are taken into account. There is a table for your personal threat contribution, broken into specific categories such as white damage, healing, mana gain, etc, and specific abilities such as Sunder Armor and Taunt.\n\nYou can set options for this add-on by clicking on the options icon in the title bar of the KLH Threatmeter.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "This add-on is expensive and can cause some framerate loss.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "FuBar KTMFu",
        requiredAddOn = "FuBar_KTMFu",
        addonDescription = "This add-on provides a FuBar menu for quick access to commonly-used KTM functions.  You can left-click on the menu to quickly show or hide KTM.  You can right-click to access various options.  Finally, you can set FuBar KTMFu to display quick threat summary or statistic information right in your Fubar.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "KTM CPU Manager",
        requiredAddOn = "KTMCPUManager",
        addonDescription = "This add-on automatically turns off KTM when not in combat.  It will turn KTM back on when you or someone in your raid or party targets a hostile creature.  Since KTM uses expensive polling of all party members to determine threat, this can save a lot of CPU resources.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", notetype = "warning", 
        text = "One unfortunate side-effect of this add-on is that KTM's auto-hiding and showing feature will not always work properly.  To ameliorate some of this, there is an option in MazzleUI's General Options area that will allow you to automatically hide KTM when logging in.",
}
    table.insert(addItem, tempItem)
    
    tempItem = {
        type = "AddOnHeader", 
        addonName = "Omen",
        requiredAddOn = "Omen",
        addonDescription = "Omen is a WoW addon that measures threat generated by each member in the party or raid and displays a side-by-side comparison. The addon attempts to provide a reasonable estimates of your threat level relative to the tank on individual enemies so you can see when you are in danger of pulling aggro.",
}
    table.insert(addItem, tempItem)    

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Recap",
        requiredAddOn = "Recap",
        addonDescription = "This add-on will track and summarize the damage dealt and received by every participant in a fight around the user.  It also does healing and keeps track of a variety of information about which abilities the combatants use.  This version syncs with other users and utilizes Rophy's ParserLib for efficient combat log parsing.  Moreover, it only syncs with other users after combat, so it causes less framerate loss than other damage meters.  Finally, it offers a very intuitive interface where you can see multiple statistics in one, coherent sortable table.\n\nYou can set options for this add-on by clicking on the options icon in the title bar of the Recap window.  You can show/hide by left-clicking on the Recap icon on the right-side of the MazzleUI panel.  You can also right-click on that same icon to quickly turn combat monitoring on or off.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to configure Recap combat tracking",
        setProc = function() RecapOptFrame:Show(); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Recount",
        requiredAddOn = "Recount",
        addonDescription = "Recount is a WoW addon that calculates damage and healing done by characters in the party or raid group. The addon serves as an analysis tool in order to gauge player's performance. It supports detailed information the form of pie charts, line graphs and real-time reports.\n\nThe addon breaks down the total damage and healing done into damage and healing done by each ability's name and percentage. The graphs will show which ability performs the damage or healing.",
}
    table.insert(addItem, tempItem)
    
    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to configure Recount",
        setProc = function() MazzleUI:Execute("/recount config"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)    

    tempItem = {
        type = "AddOnHeader", 
        addonName = "SWStats",
        requiredAddOn = "SW_Stats",
        addonDescription = "This add-on is a customizable, syncing damage/heal meter.  SWStats provides two main advantages over Recap.  First, it is updated in real-time during combat.  Second, it tracks some special-purposes statistics that Recap does not.  There are two main disadvantages.  First real-time, synced damage tracking involves a lot of communication that can cause framerate losses.  Second, many users find the GUI very unintuitive.  Nonetheless, if the rest of your raid group is using it or you are interested in one of its advantages, it may be worth using.  .\n\nYou can access the options of SWStats by right-clicking on it's icon, near the game clock.  To hide or show SWStats, simply click on that same icon.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to configure SWStats",
        setProc = function() MazzleUI:Execute("/sws gs"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_SWStats2Fu",
        addonName = "FuBar SWStats2Fu",
        addonDescription = "This add-on provides a quick way to show and hide SWStats and to access its options from your FuBar.  Left-click to toggle the visibility of SWStats and right-click to access options.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_TimerBars()

    local addItem, tempItem = {}, {}
    addItem.name = "Timer Bars"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Antagonist",
        requiredAddOn = "Antagonist",
        addonDescription = "This add-on display cooldown, effect and timer bars for other people around you who may be casting spells or have spells on cooldown.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  Antagonist is under the 'Combat' category.  You can also use the MazzleUI efficiency modes to automatically turn off this add-on in certain contexts.",
}
    table.insert(addItem, tempItem)
    
    tempItem = {
			["addonName"] = "Chronometer",
			["requiredAddOn"] = "Chronometer",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on displays timers for your spell effects such as HoTs, DoTs, vulnerabilities, crowd control durations, stuns etc.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  Chronometer is under the 'Combat' category.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Hourglass",
			["requiredAddOn"] = "Hourglass",
			["type"] = "AddOnHeader",
			["addonDescription"] = "This add-on displays timers for your spell cooldowns.  It also displays a message in SCT when a cooldown is complete.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to configure Hourglass",
        setProc = function() MazzleUI:Execute("/hourglass"); end}
    table.insert(addItem, tempItem)

    tempItem = {
			["addonName"] = "Quartz",
			["requiredAddOn"] = "Quartz",
			["type"] = "AddOnHeader",
			["addonDescription"] = "Quartz is a modular casting bar addon with configurable size, text and icon positioning, and colors with many powerful, novel features:\n\n |CFFFF8000Target/Focus Cast Bars|r: Implementation of target and focus casting bars in similar fashion to the player cast bar.\n\n |CFFFF8000Buff/Debuff Timers|r: Display of target and focus' buffs and debuffs as timer bars.  It uses the API introduced in patch 2.1.  In other words, it does no expensive combat log parsing.\n\n |CFFFF8000Flight Duration Timers|r: Hooks into FlightMap, FuBar_ToFu, or InFlight to display the current flight progress on your casting bar.\n\n |CFFFF8000Global Cooldown Bar; Displays a tiny spark-bar to show your Global Cooldown near the cast bar. Helpful for those who'd rather not squint at their action bars to see when they can cast again.\n\n |CFFFF8000Interrupt Notification|r: Changes the color and text of your casting bar to help show that your cast has been interrupted (and show who interrupted it).\n\n |CFFFF8000Latency Display|r: Shows the amount of time spent between cast send and start events, in the form of a bar at the end of your casting bar, with optional text that displays the actual duration of the lag. This helps in canceling casts when they will not actually be interrupted, especially for users with consistently high pings.\n\n |CFFFF8000Mirror Bars|r: Shows the 'basic' timers such as breath and feign death, as well as some 'odd' ones such as party invite time, resurrect timeout, and arena game start..\n\n |CFFFF8000Range Indication|r: Recolors the casting bar when your cast target moves out of range mid-cast.\n\n |CFFFF8000Swing Timer|r: Displays a swing timer for your melee weapon as well as hunter autoshot.\n\n |CFFFF8000Custom Timers|r: Allows for creating custom timers displayed on the mirror bars.\n\n |CFFFF8000Tradeskill Merge|r: Merges multiple casts of the same tradeskill item into one big cast bar.",
        }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to configure Quartz",
        setProc = function() MazzleUI:Execute("/quartz"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_MapAddons()

    local addItem, tempItem = {}, {}
    addItem.name = "Maps and Navigation"

	tempItem = {
			["addonName"] = "Cartographer",
			["requiredAddOn"] = "Cartographer",
			["type"] = "AddOnHeader",
			["addonDescription"] = "Cartographer is a modular, lightweight, and efficient framework for manipulation of the world map.  It has a variety of modules built in:\n\n|CFFFF0000(1)|r |CFFFF8000Battlegrounds|r: Allows viewing of battlegrounds outside of the zone.\n \n|CFFFF0000(2)|r |CFFFF8000Coordinates|r: Adds coordinates to the bottom of the world map of the player and the cursor.\n \n|CFFFF0000(3)|r |CFFFF8000Foglight|r: Shows unexplored areas on the map. replacement for MozzFullWorldMap or Unexplorer. Much more efficient, though.\n \n|CFFFF0000(4)|r |CFFFF8000Group Colors|r: Turns all your party's and your raid's POIs into circles colored based on class, and shows a number on them based on their raid group.\n \n|CFFFF0000(5)|r |CFFFF8000Instance Maps|r: Shows maps of instances.\n \n|CFFFF0000(6)|r |CFFFF8000Instance Notes|r: Adds boss notes and such to instance maps.\n \n|CFFFF0000(7)|r |CFFFF8000Instance Loot|r: Shows loot tables when you click a boss note.\n \n|CFFFF0000(8)|r |CFFFF8000Look 'n' Feel|r: Allows you to change the transparency, position, and scale of the world map.\n \n|CFFFF0000(9)|r |CFFFF8000Notes|r: Lets you put notes on the map, similar to MapNotes.\n \n|CFFFF0000(10)|r |CFFFF8000POI|r: Stores notes whenever a guard gives you directions.\n \n|CFFFF0000(11)|r |CFFFF8000Professions|r: Tracks herbs and minerals, similar to Gatherer.\n \n|CFFFF0000(12)|r |CFFFF8000Waypoints|r: Lets you set a note as a waypoint and then draws an arrow pointing you in the direction of that waypoint.\n \n|CFFFF0000(13)|r |CFFFF8000Zone Info|r: on hovering over a zone, it will show the levels of the zone, the instances in the zone, their levels, and the number of men the instance is made for (e.g. 5-man, 40-man).\n\nYou can access the options for Cartographer by pulling up the map with 'M' and clicking the Cartographer button.",
		}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Cartographer Fishing",
        requiredAddOn = "Cartographer_Fishing",
        addonDescription = "This add-on is a cartographer plug-in that records where you find different kinds of fish.  You can access the options for this add-on within the main Cartographer options.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Cartographer Herbalism",
        requiredAddOn = "Cartographer_Herbalism",
        addonDescription = "This add-on is a cartographer plug-in for herbalists. It's main purpose is to track the closest plantson you minimap.  Unlike the normal tracking ability does, this add-on 'remembers' where you have found various items in the past and, whenever the item comes into range, will pop up an icon on your minimap.  While computationally expensive, this add-on can be extremely useful to herbalists and miners.  You can access the options for this add-on within the main Cartographer options.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Cartographer Quests",
        requiredAddOn = "Cartographer_Quests",
        addonDescription = "This add-on is a cartographer plug-in that creates map notes for quest givers.  These can get quite numerous, so remember that you can delete them when you are done with quests in that area.  You can access the options for this add-on within the main Cartographer options.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Cartographer Mining",
        requiredAddOn = "Cartographer_Mining",
        addonDescription = "This add-on is a cartographer plug-in for miners. It does the same thing described for Cartographer Herbalism, except for mining nodes.  You can access the options for this add-on within the main Cartographer options.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Cartographer Noteshare",
        requiredAddOn = "Cartographer_Noteshare",
        addonDescription = "This add-on is a cartographer plug-in that allows you to share herbalism, mining, quest, etc. nodes that you collect.  You can access the options for this add-on within the main Cartographer options.  You can also go there to manually share your node database with another player.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Cartographer Trainers",
        requiredAddOn = "Cartographer_Trainers",
        addonDescription = "This add-on is a cartographer plug-in that records where you find trainers.  You can access the options for this add-on within the main Cartographer options.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Cartographer Treasure",
        requiredAddOn = "Cartographer_Treasure",
        addonDescription = "This add-on is a cartographer plug-in that will record various miscellaneous 'treasure' resources you find such as chest, figurines, lockboxes, Un'Goro crystals, Blood of Heroes, Felwood plants, etc..  You can access the options for this add-on within the main Cartographer options.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Cartographer Vendors",
        requiredAddOn = "Cartographer_Vendors",
        addonDescription = "This add-on is a cartographer plug-in that records where you find various NPCs who sell items.  You can access the options for this add-on within the main Cartographer options.",
}
    table.insert(addItem, tempItem)

	tempItem = {
        type = "AddOnHeader", 
        addonName = "FuBar ToFu",
        requiredAddOn = "FuBar_ToFu",
        addonDescription = "This add-on adds flight information to the flight path gossip window and a duration timer during flights.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  FuBar ToFu is under the 'Interface Enhancements' category.",
}
    table.insert(addItem, tempItem)

	tempItem = {
        type = "AddOnHeader", 
        addonName = "PingDir",
        requiredAddOn = "PingDir",
        addonDescription = "This nifty add-on will draw a large arrow on the screen whenever you or someone in your party/raid pings the map.  The arrow will point in the relative direction of the ping's location. There are no significant options for this add-on.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end
    
function MazzleOptions:AddOptions_Nameplates()

    local addItem, tempItem = {}, {}
    addItem.name = "Nametags and Nameplates"

    tempItem = {
        type = "AddOnHeader", requiredAddOn = "Aloft",
        addonName = "Aloft",
        addonDescription = "This add-on provides provides much more powerful and customizable nameplates.  It allows you to change the size, shape, anchors, font, font options, textures and colors of (1) name text, (2) level text, (3) health bar, (4) cast bar, (5) spell icon, (6) boss icon, (7) raid icon, (8) mouseover highlight.  In addition, it provides the following novel and powerful additions to your nameplates:\n\n- |CFFFF8000Custom health text|r: you can display health percentage, health, or health deficit right on the nameplate.\n\n- |CFFFF8000Spell casting timer|r: Your targets castbar will displays the actual remaining casting time.\n\n- |CFFFF8000Combo points|r: Displayed on target's nameplates for rogues and druids.\n\n- |CFFFF8000Recently Damaged icon|r: Displays an icon next to any unit that has recently taken damage, which can be very helpful to healers.\n\n- |CFFFF8000Finer control of which units display nameplates|r: Gives you specific control over which nameplates are shown.  For example, you can hide friendly pets, out of guild players, etc.\n\n- |CFFFF8000Guild Text|r: Shows guild information right on the nameplate. It can even show abbreviated guild names to save space.  For example, the guild 'Slaves of Mazzle' would get abbreviated to SOM.\n\n- |CFFFF8000Comments|r: Shows 'Banker', 'Flight Master' and other automatically gathered comments, or your own custom ones right on the nameplate.\n\n- |CFFFF8000Mana Bar/Text|r: Can show mana, energy, rage bars.  This only works for party members.\n\n- |CFFFF8000Combat Text|r: Can display all damage and healing done to group members or targets right on the plate.\n\n- |CFFFF8000Pets Owner's Names\n\n- |CFFFF8000Polymorph and undead shackle timer bars!\n\nThis add-on can be configured via its entry in your FuBar.",
}
    table.insert(addItem, tempItem)
 
    tempItem = {
        type = "AddOnHeader", requiredAddOn = "FuBar_NameToggleFu",
        addonName = "FuBar NameToggleFu",
        addonDescription = "This add-on provides adds an icon to toggle player names.  Left-click to toggle names over players.  Right-click to fine-tune the settings including those for name plates.",
}
    table.insert(addItem, tempItem)
 
    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Raiding()

    local addItem, tempItem = {}, {}
    addItem.name = "Raiding Tools"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "BigWigs",
        requiredAddOn = "BigWigs",
        addonDescription = "BigWigs is an Ace2-based boss timer and warning mod that attempts to show info in the most relevant way possible, and give the user control over their mods, not the raid leader.  It is considered one of the more efficient and complete boss timer mods available and is updated frequently.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", 
        text = "You can access the options for BigWigs by right-clicking on its button your Fubar.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "LittleWigs",
        requiredAddOn = "LittleWigs",
        addonDescription = "LittleWigs is an Ace2-based boss timer and warning mod that works in conjunction with BigWigs to provide encounter information for Burning Crusade five-man instances!  These warning can be extremely useful, especially in the more difficult heroic mode encounters.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Deadly Boss Mods",
        requiredAddOn = "DBM_API",
        addonDescription = "Deadly Boss Mods is a timer and warning mod.\n\nThere's a few other things that distinguish Deadly Boss Mods from that other boss mods:\n\n |CFFFF8000(1)|r Boss mods for all raid bosses.  These modules do more than just provide timers.  They also give you prominent warnings with flashy visual effects when certain important events happen to you.\n\n |CFFFF8000(2)|r Some boss mods have very advanced features like the Loatheb healer monitor which allows you to setup a heal rotation and see the cooldowns of all healers.\n\n |CFFFF8000(3)|r Synchronization system for dependable timers.\n\n |CFFFF8000(4)|r Modular design - all boss mods are plugins and can be exchanged, removed or updated separately\n\n |CFFFF8000(5)|r Special effects like the screen flash and the screen shake effect will draw your attention to critical events\n\n |CFFFF8000(6)|r Bars can change their color over time and flash before they expire\n\n |CFFFF8000(7)|r Highly-customizable options\n\n |CFFFF8000(8)|r Option to create custom timers\n\n |CFFFF8000(9)|r Powerful object-oriented API - you can use it to write your own boss mods!\n",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Options",
        label = "Click here to configure Deadly Boss Mods",
        setProc = function() MazzleUI:Execute("/dbm"); MazzleOptions:Hide(); end}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", 
        text = "You can also access the options for Deadly Boss Mods from the MazzleUI menu in your FuBar.",
}
    table.insert(addItem, tempItem)
    
    tempItem = {
        type = "AddOnHeader", 
        addonName = "Incubator",
        addonDescription = "Incubator provides respawn timers for trash in some instances. Currently it supports: Karazhan, Gruul's Lair, Magtheridon's Lair.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  Incubator is under the 'Raid' category",
        requiredAddOn = "Incubator",
}
    table.insert(addItem, tempItem)
    
    tempItem = {
        type = "AddOnHeader", 
        addonName = "oRA2",
        addonDescription = "This add-on provides a low-cost alternative to CT RaidAssist.  With this option you can use only the modules that you need.  All of the commands and options of this add-on can be accessed via the oRA2 menu in Fubar.",
        requiredAddOn = "oRA2",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "sRaidFrames",
        requiredAddOn = "sRaidFrames",
        addonDescription = "sRaidFrames is a low-cost add-on that show Raid frames.  It has been modified to better work within the MazzleUI layout.  It's a more efficient alternative to either Blizzard or CT Raid's raid frames.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  sRaidFrames is under the 'Raid' category.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "XRaid Status",
        requiredAddOn = "XRS",
        addonDescription = "This add-on provides an informative window that lets you monitor overall raid status, such as number of deaths, total tank health, total healer mana, etc.  This add-on is highly configurable.  You can access the options for this add-on via the Niagra configuration utility in FuBar.  XRS is under the 'Raid' category.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", 
        text = "To add more stats to monitor or change display options, simply right-click on the XRaidStatus window, which, by default, is at the top right of the screen.",
}
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

