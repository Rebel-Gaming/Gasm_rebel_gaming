-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

function MazzleOptions:Build_Options()
    MazzleOptions_SettingsInfo = {} 
    MazzleOptions_SettingsInfo.Contents = {} 
    
    local sections = { 
                       "AddOptions_Directory",
                       " MazzleUI ",
                       "AddOptions_AddOnManagement",
                       "AddOptions_Mazz3D",
                       "AddOptions_MazzleHUD",
                       "AddOptions_General",
                       "AddOptions_MazzleButtons",
                       "AddOptions_Notifications",
                       "AddOptions_EfficiencyMode",
                       "AddOptions_UnitFramesManagement",
                       "AddOptions_Special",
                       " Main Categories ",
                       "AddOptions_Accessories",
                       "AddOptions_AH",
                       "AddOptions_Automation",
                       "AddOptions_Bags",
                       "AddOptions_Battlegrounds",
                       "AddOptions_Buffing",
                       "AddOptions_Buttons",
                       "AddOptions_Character",
                       "AddOptions_Chat",
                       "AddOptions_Crafting",
                       "AddOptions_DamageMeter",
                       "AddOptions_ErrorFrame",
                       "AddOptions_Fubar",
                       "AddOptions_Inspect",
                       "AddOptions_KeyBindings",
                       "AddOptions_Loot",
                       "AddOptions_Mail",
                       "AddOptions_MapAddons",
                       "AddOptions_Nameplates",
                       "AddOptions_Quests",
                       "AddOptions_Raiding",
                       "AddOptions_SCTAddOns",
                       "AddOptions_Talents",
                       "AddOptions_TimerBars",
                       "AddOptions_Tooltip",
                       "AddOptions_UnitFrames",
                       "AddOptions_Who",
                       " Class-Specific ",
                       "AddOptions_ClassDruid",
                       "AddOptions_ClassHunter",
                       "AddOptions_ClassMelee",
                       "AddOptions_ClassWarlock",
                       " Under The Hood ",
                       "AddOptions_Display",
                       "AddOptions_Libraries",
                       }
    local setupProc
    
    for _,theSection in pairs(sections) do
        setupProc = MazzleOptions[theSection]
        if (setupProc) then setupProc() else self:Create_Category(theSection) end
    end

    MazzleOptions_SettingsInfo.NumTopics = table.getn(MazzleOptions_SettingsInfo.Contents)

end

function MazzleOptions:Create_Category(sectionName)
    local addItem, tempItem = {}, {}

    addItem.name = sectionName
    addItem.num = 0
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:Build_AddOn_Directory()
    local addItem, addItem2, tempItem = {}, {}, {}
    local addOnCount, currentTooltip
    addItem.name = "Add-On Directory"
    addItem.tooltipText = "This category contains an alphabetical list of every add-on in MazzleUI.\nYou can click any add-on in the list to take you to its options."

    tempItem = {
        type = "Notebox", notetype = "none",
        text = "You are here.",
        label = "_",
    }
    table.insert(addItem, tempItem)

    for i=1, MazzleOptions_SettingsInfo.NumTopics, 1 do
        addOnCount = 0; currentTooltip = "This category contains the following add-ons:|CFFFFFFFF";
        for _,addonInfo in pairs(MazzleOptions_SettingsInfo.Contents[i]) do
            if ((type(addonInfo)=="table") and (addonInfo.type == "AddOnHeader")) then
                addOnCount = addOnCount + 1
                currentTooltip = currentTooltip.."\n   "..addOnCount.." - "..addonInfo.addonName
                tempItem = {
                    type = "TitleButton", yadjust = 5,
                    label = "|CFFFF8000"..addonInfo.addonName.."|r  ("..MazzleOptions_SettingsInfo.Contents[i].name..")",
                    topicID = i,
                    setProc = function(a,b) MazzleOptions:TopicButton_OnClick(MazzleOptions.Actives[this:GetID()].info.topicID); end}
                if (MazzleOptions_SettingsInfo.Contents[i].name == "Libraries") then
                    table.insert(addItem2, tempItem)
                else
                    table.insert(addItem, tempItem)
                end
            end
        end;
        if ((addOnCount > 0) and (not MazzleOptions_SettingsInfo.Contents[i].tooltipText)) then
            MazzleOptions_SettingsInfo.Contents[i].name = MazzleOptions_SettingsInfo.Contents[i].name.." ("..addOnCount..")"
            MazzleOptions_SettingsInfo.Contents[i].tooltipText = currentTooltip
        end
    end;
    
    table.sort(addItem, function(a,b) if (string.lower(a.label) < string.lower(b.label)) then return true; else return false; end; end)
    
    tempItem = {
        type = "Textbox", 
        text = "Libraries",
        label = "",
    }
    table.insert(addItem, tempItem)

    table.sort(addItem2, function(a,b) if (string.lower(a.label) < string.lower(b.label)) then return true; else return false; end; end)
    for _, newItem in pairs(addItem2) do table.insert(addItem, newItem) end;
    
    MazzleOptions_SettingsInfo.Contents[1] = addItem
end

function MazzleOptions:AddOptions_Directory()

    local addItem, tempItem = {}, {}
    addItem.name = "Add-On Directory"


    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_AddOnManagement()

    local addItem, tempItem = {}, {}
    addItem.name = "Add-On Management"

    tempItem = {
        type = "AddOnHeader", 
        addonName = "MCP",
        requiredAddOn = "MCP",
        addonDescription = "This extremely useful add-on provides you with an in-game interface to change which add-ons are loaded for a particular character.  In addition to being able to turn add-ons on and off without going to the character screen, you can create add-on 'sets'.  For example, you could create a profile that contains only raiding add-ons.  You can even create multiple sets so that you can combine them to enable exactly add-ons you want.  You can access this add-on by hitting escape, going to the game menu and hitting the AddOn button.",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "Try using this in conjunction with the Mazzifier to save various sets of add-ons based on different answers to the Mazzifier's questions.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Mazzifier",
        requiredAddOn = "Mazzifier",
        addonDescription = "This add-on is the automatic configuration utility that sets up MazzleUI for you.  In addition to initial installation, it will automatically launch whenever you install a MazzleUI upgrade.",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button",
        name = "Launch",
        label = "Open the MazzleUI configuration Utility",
        setProc = function() MazzleUI:Execute("/mazzify") end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "You can use the Mazzifier to reset option settings to their original 'mazzified' settings, change button layouts, change chat window text size, reset your layout or reconfigure which add-ons are enabled.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button",
        name = "Force Current",
        label = "Force Mazzifier think that all version information is current",
        setProc = function() MazzleUI:Execute("/mazzify forcecurrent") end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "You can use this to make sure that the current version of the Mazzifier will not ask you to update anything in your UI.  This is not recommended unless you have a very specific reason.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "The force current option is not yet implemented.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "AddOnHeader", 
        addonName = "Warm-Up",
        requiredAddOn = "!!Warmup",
        addonDescription = "Warm-Up is an add-on that displays loading time and INITIAL memory use of all of your add-ons.  It is by default disabled.  Enable this add-on to show startup times for the next restart.",
}
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button", yadjust = 5,
        name = "Hide",
        label = "Click here to hide the Warm-Up window",
        setProc = function() MazzleUI:Execute("/warmup"); MazzleOptions:Hide(); end
    }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_EfficiencyMode()
    
    local addItem, tempItem = {}, {}
    addItem.name = "|cFF006699MazzleUI|r Efficiency Modes"
    addItem.tooltipText = "This category lets you set how MazzleUI will scale back\nfunctionality to improve performance in certain situations."

    tempItem = {
        type = "Textbox", 
        text= "MazzleUI offers multiple efficiency modes that can scale back the resources that WoW uses during demanding situations.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3, 
        name = "Enable Party Efficiency Mode",
        parameter = "MazzleUI_Settings.Performance_Enabled.party",
        setProc = function() MazzleUI:InstantiateEfficiencyMode(true); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", 
        name = "Enable Raid Efficiency Mode",
        parameter = "MazzleUI_Settings.Performance_Enabled.raid",
        setProc = function() MazzleUI:InstantiateEfficiencyMode(true); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton",
        name = "Enable Combat Efficiency Mode",
        parameter = "MazzleUI_Settings.Performance_Enabled.combat",
        setProc = function() MazzleUI:InstantiateEfficiencyMode(true); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton",
        name = "Enable PvP Efficiency Mode",
        parameter = "MazzleUI_Settings.Performance_Enabled.pvp",
        setProc = function(a,b) MazzleUI:UpdateEventForSetting("PVPMode"); end,
        setProc = function() MazzleUI:InstantiateEfficiencyMode(true); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text= "Solo, PvP, party, raid and combat efficiency models will automatically be initiated when you're in that context.  There is also a manually-initiated mode you enter when you click on the MazzleUI efficiency mode button.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Textbox",
        text= "Fine-tune Settings:",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", yadjust = -15, xadjust = -20, justification ="right",
        name = "Full graphics settings",
        header = "Solo    Combat    Party       Raid         PvP     Manual",
        parameter = "MazzleUI_Settings.Performance_Gfx",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "3D model animation",
        parameter = "MazzleUI_Settings.Performance_Models",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "BigWigs",
        parameter = "MazzleUI_Settings.Performance_BigWigs",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "HUD Range Checking",
        parameter = "MazzleUI_Settings.Performance_HUDRange",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "Recap",
        parameter = "MazzleUI_Settings.Performance_Recap",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "SWStats",
        parameter = "MazzleUI_Settings.Performance_SWS",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "Scrolling Combat Text",
        parameter = "MazzleUI_Settings.Performance_SCT",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "Scrolling Combat Text Damage",
        parameter = "MazzleUI_Settings.Performance_SCTD",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "Scrolling Combat Text Cooldowns",
        parameter = "MazzleUI_Settings.Performance_SCTC",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "Smart Debuff",
        parameter = "MazzleUI_Settings.Performance_SmartDebuff",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "Spell Effects",
        parameter = "MazzleUI_Settings.Performance_SpellEffects",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "Timer Bars",
        parameter = "MazzleUI_Settings.Performance_CECB",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "WitchHunt Spell Alerts",
        parameter = "MazzleUI_Settings.Performance_SpellAlert",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "PerformanceEntry", justification ="right",
        name = "Normal update rate for Discord add-ons",
        parameter = "MazzleUI_Settings.Performance_Discord",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", xadjust = -250,
        text= "Manual mode trumps PvP mode.  PvP mode trumps raid mode.  Raid mode trumps party mode.  Party mode trumps combat mode.  Combat mode trumps solo mode.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", notetype = "warning",
        text= "Do not turn on extra modes or options unless you're absolutely certain you need to get the increased performance, since you will lose some functionality.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Textbox", 
        text = "Discord Update Rate",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", xadjust = 5,
        name = "Max update frequency for Discord Unit Frames:",
        minValue = 1,
        maxValue = 30,
        stepValue = 1,
        units = " upd/sec",
        parameter = "MazzleUI_Settings.DiscordUpdate",
        setProc = function() MazzleUI:InstantiateEfficiencyMode(true); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider",
        name = "Reduced update frequency for Discord Unit Frames:",
        minValue = 1,
        maxValue = 30,
        stepValue = 1,
        units = " upd/sec",
        parameter = "MazzleUI_Settings.Performance_DiscordUpdate",
        setProc = function() MazzleUI:InstantiateEfficiencyMode(true); end,
    }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Special()

    local addItem, tempItem = {}, {}
    addItem.name = "|cFF006699MazzleUI|r Special Settings"
    addItem.tooltipText = "This category contains a few special purpose options such as bug\nworkarounds and tools for submitting button layouts to Mazzlefizz."


    tempItem = {
        type = "Textbox", 
        text = "Quick Bug Workarounds",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Button",
        name = "Restore Chat Windows",
        label = "",
        setProc = function() MazzleOptions:RestoreChatFrames() end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "Due to a Blizzard bug, detached chat windows, in this case the MazzleUI combat log windows, can disappear for some people.  If this happens to you, click this button to restore them.  If ALL of your chat windows disappear, try typing '/dfm'.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Textbox", 
        text = "Submitting Your Button Layouts",
    }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Mazz3D()

    local addItem, tempItem = {}, {}
    addItem.name = "|cFF006699Mazz3D|r Characters"
    addItem.tooltipText = "This category lets you configure MazzleUI's animated 3d models."

    tempItem = {
        type = "Textbox", 
        text = "Mazzlefizz's Mazz3D Characters Settings",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to be able to click cast on the 3D characters?",
        parameter = "MazzleUI_Settings.Mazz3D.clickCast",
        setProc = function () MazzleUI:SetModelClickCasting(); end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want the 3D characters to do a random emote animation every now and then?",
        parameter = "MazzleUI_Settings.Mazz3D.randomAnims",
        setProc = function () if (MazzleUI_Settings.Mazz3D.randomAnims) then MazzleUI:StartRandomAnims() else MazzleUI:StopRandomAnims(); end; end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want the 3d characters to do event-based animation?",
        parameter = "MazzleUI_Settings.Mazz3D.eventAnims",
        setProc = function () if (MazzleUI_Settings.Mazz3D.eventAnims) then MazzleUI:RegisterAnimEvents(); else MazzleUI:UnregisterAnimEvents(); end; end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "Event-based animations include flinching when hit, roaring when resurrected and falling when dead.  Emote animations are the ones that occur when you do things like /rude.  You can also initiate emote animations by right-clicking on the middle of the 3D model.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to be able to rotate and adjust 3d characters?",
        parameter = "MazzleUI_Settings.Mazz3D.adjustModels",
        setProc = function () if (MazzleUI_Settings.Mazz3D.adjustModels) then MazzleUI:RegisterAdjustEvents(); else MazzleUI:UnregisterAdjustEvents(); end; end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Textbox",
        text = "Debug Options",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Enable Debug messages?",
        parameter = "MazzleUI_Settings.Mazz3D.debugCamera",
    }
    table.insert(addItem, tempItem)


    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_Notifications()

    local addItem, tempItem = {}, {}
    addItem.name = "|cFF006699MazzleUI|r Notifications"
    addItem.tooltipText = "This category lets you configure how MazzleUI will notify you about certain important events."

    tempItem = {
        type = "Textbox", 
        text = "Alerts",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want the bottom panel to strobe red when you have aggro?",
        parameter = "MazzleUI_Settings.AggroStrobe",
        setProc = function(a,b) MazzleUI:UpdateEventForSetting("AggroStrobe1"); MazzleUI:UpdateEventForSetting("AggroStrobe2"); end,
    }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_MazzleButtons()

    local addItem, tempItem = {}, {}
    addItem.name = "|cFF006699MazzleUI|r Button Settings"
    addItem.tooltipText = "This category contains action button related settings."

    tempItem = {
        type = "Textbox", 
        text = "Snap To Layout",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want MazzleUI to try to maintain the relative placement of bars?",
        parameter = "MazzleUI_Settings.SnapToLayout",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "The snap to layout capability included in the MazzleUI version of Bongos is extremely useful if you are |cFFFF8000only|r making common changes to your layouts, such as adding/removing buttons or pages, changing the size/scale/spacing of buttons, etc.  It will allow you to make those changes without having to do a single thing to compensate for them.  For example, other bars will move over if you add a button to a bar.  \n\nIf you decided to change the |cFFFF8000relative position of bars|r, it is recommended that you turn this feature off.  Otherwise, your bars may snap back to the original relative positions, some of which may no longer be applicable.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_General()

    local addItem, tempItem = {}, {}
    addItem.name = "|cFF006699MazzleUI|r General Settings"
    addItem.tooltipText = "This category contains general MazzleUI settings."

    tempItem = {
        type = "Textbox", 
        text = "Automation",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to automatically accept resurrections?",
        parameter = "MazzleUI_Settings.AutoRes",
        setProc = function(a,b) MazzleUI:UpdateEventForSetting("AutoRes"); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to automatically accept summons from Warlocks?",
        parameter = "MazzleUI_Settings.AutoSummon",
        setProc = function(a,b) MazzleUI:UpdateEventForSetting("AutoSummon"); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to automatically unmount when you speak to Flightmaster?",
        parameter = "MazzleUI_Settings.AutoDismount",
        setProc = function(a,b) MazzleUI:UpdateEventForSetting("AutoDismount"); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to hide nQuestLog when you first log in?",
        parameter = "MazzleUI_Settings.HideQuestLog",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to hide KLH Threatmeter when you first log in?",
        parameter = "MazzleUI_Settings.HideKTM",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Textbox", 
        text = "Bags",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to open all bags when trading or at a merchant/bank/mailbox?",
        parameter = "MazzleUI_Settings.AutoOpenBags",
        setProc = function(a,b) MazzleUI:UpdateEventForSetting("AutoOpenBags"); MazzleUI:UpdateEventForSetting("AutoCloseBags"); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to use alt-click to put items in the trade or AH windows?",
        parameter = "MazzleUI_Settings.AutoOpenBags",
        setProc = function(a,b) MazzleUI:HookContainerClicking(MazzleUI_Settings.AutoOpenBags) end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Textbox", 
        text = "Context Menu", 
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to hide the context menu when you first log in?",
        parameter = "MazzleUI_Settings.HideContext",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to hide the context menu when you use an item in it?",
        parameter = "MazzleUI_Settings.HideContextOnClick",
        setProc = function() MazzleUI.ContextMenu:SetCloseOnClick(MazzleUI_Settings.HideContextOnClick); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to move the context menu to your mouse when opened?",
        parameter = "MazzleUI_Settings.MoveContext",
        setProc = function() MazzleUI.ContextMenu:SetMoveToMouse(MazzleUI_Settings.MoveContext); end,
    }
    table.insert(addItem, tempItem)

   tempItem = {
        type = "Textbox", 
        text = "Raid Icon Buttons",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want easy-access raid icon buttons when you are group leader?",
        parameter = "MazzleUI_Settings.ShowCharmIcons",
        setProc = function () MazzleUI:Handle_LeaderChange(); end
    }
    table.insert(addItem, tempItem)

   tempItem = {
        type = "Textbox", 
        text = "Hotspot Shortcuts",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Enable Chat Text Copy Hotspot (bottom left corner)",
        parameter = "MazzleUI_Settings.HotSpots.KCI",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", 
        name = "Enable nQuestLog Hotspot (top left corner)",
        parameter = "MazzleUI_Settings.HotSpots.Quest",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", 
        name = "Enable Omnibus Notebook Hotspot (middle left)",
        parameter = "MazzleUI_Settings.HotSpots.Notebook",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", 
        name = "Enable Context Menu Hotspot (middle right)",
        parameter = "MazzleUI_Settings.HotSpots.NeedyList",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", 
        name = "Enable ItemRack Hotspot (top right corner)",
        parameter = "MazzleUI_Settings.HotSpots.ItemRack",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", 
        name = "Enable ItemSync/Smart Debuff Hotspot (bottom right)",
        parameter = "MazzleUI_Settings.HotSpots.xCalc",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", 
        name = "Enable Map Hotspot (minimap coordinates)",
        parameter = "MazzleUI_Settings.HotSpots.Compass",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", 
        name = "Enable Target of Target Hotspot (under target box)",
        parameter = "MazzleUI_Settings.HotSpots.ToT",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox",
        text = "Hotspots are hidden areas in the bottom MazzleUI panel that you can click to open up commonly used add-ons.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Textbox", 
        text = "Raid Utility Auto-Hiding",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to auto-hide oRA's resurrection monitor when not on a healer?",
        parameter = "MazzleUI_Settings.AutohideRezMonitor",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to auto-show oRA's resurrection monitor when you're dead?",
        parameter = "MazzleUI_Settings.AutoshowRezMonitor",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Never show resurrection monitor or XRaidStatus when pvp-flagged?",
        parameter = "MazzleUI_Settings.HotSpots.hideResurrectionXRSPvP",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Notebox", xadjust = 15,
        text = "The three options above are not yet implemented.",
        width = "full",
    }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_MazzleHUD()
    local addItem = {}
    addItem.name = "|cFF006699MazzleHUD|r Settings"
    addItem.tooltipText = "This category lets you configure MazzleUI's heads-up display."

    tempItem = {
        type = "Textbox", 
        text = "MazzleHUD",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "YesNo", yadjust = -10,
        question = "Do you want to use the HUD?",
        parameter = "MazzleUI_Settings.HUD.UseHUD",
        setProc = function() MazzleUI:InstantiateHUDSettings() end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Textbox", 
        text = "Size and Location:",
    }

    tempItem = {
        type = "Slider",
        name = "Scale:",
        minValue = 0.5,
        stepValue = 0.1,
        maxValue = 2,
        units = " percent",
        parameter = "MazzleUI_Settings.HUD.Scale",
        setProc = function() MazzleUI:CreateHUD(true); end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", yadjust = -10,
        name = "Separation:",
        minValue = 100,
        stepValue = 10,
        maxValue = 300,
        units = " pixels",
        parameter = "MazzleUI_Settings.HUD.separation",
        setProc = function() MazzleUI:CreateHUD(true); end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", yadjust = -10,
        name = "Vertical Adjustment:",
        minValue = -200,
        stepValue = 10,
        maxValue = 200,
        units = " pixels",
        parameter = "MazzleUI_Settings.HUD.YAdjust",
        setProc = function() MazzleUI:CreateHUD(true); end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -20,
        name = "Show your stats as actual values instead of percentage?",
        parameter = "MazzleUI_Settings.HUD.SelfFormat",
        setProc = function() MazzleUI:HUD_PlayerHealthEvent(); MazzleUI:HUD_PlayerManaEvent(); end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Show target's stats as actual values instead of percentage?",
        parameter = "MazzleUI_Settings.HUD.TargetFormat",
        setProc = function() MazzleUI:HUD_TargetHealthEvent(); MazzleUI:HUD_TargetManaEvent(); end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -5,
        name = "Show distance to target?",
        parameter = "MazzleUI_Settings.HUD.ShowRange",
        setProc = function()
            if (MazzleUI_Settings.HUD.ShowRange) then 
                MazzleUI:Handle_TargetChange();
            else
            	if (not MazzleUI.TargetButtons) then MazzleUI:StopMetro("MazzleUITargetUpdate");  end;
            	MazzleUI.HUD.target.rangeText.textString:SetText("");
            end
        end
    }
    table.insert(addItem, tempItem)
    tempItem = {
        type = "Textbox", 
        text = "Transparency:",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider",
        name = "Hud Transparency in Combat:",
        minValue = 0,
        stepValue = .01,
        maxValue = 0.6,
        units = " visibility",
        parameter = "MazzleUI_Settings.HUD.Transparency_IC",
        setProc = function() MazzleOptions:HudTransparency() end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", yadjust = -10,
        name = "Hud Transparency Out of Combat:",
        minValue = 0,
        stepValue = .01,
        maxValue = 0.6,
        units = " visibility",
        parameter = "MazzleUI_Settings.HUD.Transparency_OOC",
        setProc = function() MazzleOptions:HudTransparency() end
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Slider", yadjust = -10,
        name = "Target of Target Transparency:",
        minValue = 0,
        stepValue = .01,
        maxValue = 1,
        units = " visibility",
        parameter = "MazzleUI_Settings.HUD.Transparency_ToT",
        setProc = function() MazzleOptions:HudTransparency() end
    }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end

function MazzleOptions:AddOptions_UnitFramesManagement()
    local addItem = {}
    addItem.name = "|cFF006699MazzleUI|r Unit Frame Settings"
    addItem.tooltipText = "This category lets you configure how\nyour party and raid frames are laid out."

    tempItem = {
        type = "Textbox", 
        text = "Unit Frame Display",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3, 
        name = "HIDE your party members' pets?",
        setProc = function(a,b) MazzleUI:Set_DUFPartyPets(b); MazzleUI:Set_RefreshRaidView(); end,
        readOnlyParameter = function() MazzleOptions:Get_DUFPartyPets(); end,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Textbox", 
        text = "MazzleUI Hot-Swappable Layouts",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Allow MazzleUI to move your raid frames?",
        parameter = "MazzleUI_Settings.manageRaidFrames",
        setProc = MazzleUI.Set_RefreshRaidView,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Allow MazzleUI to move your MT windows?",
        parameter = "MazzleUI_Settings.manageMTFrames",
        setProc = MazzleUI.Set_RefreshRaidView,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3,
        name = "Enable Right-Clicking on MazzleUI logo to cycle through layouts?",
        parameter = "MazzleUI_Settings.HotSpots.RaidCycle",
    }
    table.insert(addItem, tempItem)



    tempItem = {
        type = "Textbox",
        text = "Favorite View",
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "Menu",
        width = 90,
        name = "Raid Frame Position", xadjust = -15,
        parameter = "MazzleUI_Settings.FaveRaidPosition",
        menuItems = {"Bottom",
                     "Top",
                     "None",},
        setProc = MazzleUI.Set_RefreshRaidView,
    }
    table.insert(addItem, tempItem)

--    tempItem = {
--        type = "Menu",
--        width = 310,
--        name = "MT Window Position",
--        menuItems = {"Side with MT and MT's target",
--                     "Top with MT and MT's target",
--                     "Top with MT and MT's target and MT's ToT (wide)"},
--        parameter = "MazzleUI_Settings.FaveMTPosition",
--        setProc = MazzleUI.Set_RefreshRaidView,
--    }
    tempItem = {
        type = "Menu",
        width = 90,
        name = "MT Window Position",
        menuItems = {"Side",
                     "Top",},
        parameter = "MazzleUI_Settings.FaveMTPosition",
        setProc = MazzleUI.Set_RefreshRaidView,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3, xadjust = 15, 
        name = "Adjust raid frame layout to be better distributed when in a 20-man raid?",
        parameter = "MazzleUI_Settings.AutoSwapRaid20",
        setProc = MazzleUI.Set_RefreshRaidView,
    }
    table.insert(addItem, tempItem)

    tempItem = {
        type = "CheckButton", yadjust = -3, 
        name = "SHOW your party members when in a raid and there's room for them?",
        parameter = "MazzleUI_Settings.ShowRaidParty",
        setProc = MazzleUI.Set_RefreshRaidView,
    }
    table.insert(addItem, tempItem)

    addItem.num = table.getn(addItem)
    table.insert(MazzleOptions_SettingsInfo.Contents, addItem)
end
