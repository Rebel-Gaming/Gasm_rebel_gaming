-- Copyright � 2006 Mazin Assanie
-- All Rights Reserved.
-- 
-- Permission to use, copy, modify, and distribute this software in any way
-- is not granted without expressed written agreement.  In the case that it
-- is granted, the above copyright notice and this paragraph must appear in
-- all copies, modifications, and distributions.  This copyright applies
-- to the all of the code, data and artwork in the add-ons MazzleUI,
-- Mazzifier, MazzleOptions, the MazzleUI Preloader and all artwork found in
-- the custom textures folders of Discord Art and Discord Unit Frames.
--
-- To contact the author of this work, use mazzlefizz@gmail.com 
-- For more information on copyright, visit http://copyright.gov/ or http://whatiscopyright.org/
--

function MazzleOptions:HudTransparency()
    if (MazzleUI_Settings.HUD.Transparency_IC == 0) then
        MazzleUI_Settings.HUD.Transparency_FG_IC = 0
    else
        MazzleUI_Settings.HUD.Transparency_FG_IC = MazzleUI_Settings.HUD.Transparency_IC + 0.4
    end
    if (MazzleUI_Settings.HUD.Transparency_OOC == 0) then
        MazzleUI_Settings.HUD.Transparency_FG_OOC = 0
    else
        MazzleUI_Settings.HUD.Transparency_FG_OOC = MazzleUI_Settings.HUD.Transparency_OOC + 0.4
    end
    if (MazzleUI_Settings.HUD.Transparency_FG_IC >= 1) then
        MazzleUI_Settings.HUD.Transparency_FG_IC = 0.99
    end
    if (MazzleUI_Settings.HUD.Transparency_FG_OOC >= 1) then
        MazzleUI_Settings.HUD.Transparency_FG_OOC = 0.99
    end
    
    MazzleUI:InstantiateHUDSettings()
end

function MazzleOptions:CBRead_Rev_1_nil(varValue)
    if (varValue) then return nil else return 1 end
end

function MazzleOptions:CBSet_Rev_1_nil(widgetID, widgetValue)
    --self:Print("Checkbutton write: ", " = ", widgetValue)
    if (widgetValue) then
        MazzleUI:SetValue(MazzleOptions.Actives[widgetID].info.readOnlyParameter, nil)
    else
        MazzleUI:SetValue(MazzleOptions.Actives[widgetID].info.readOnlyParameter, 1)
    end
end

function MazzleOptions:OpenSCLMenu( widgetID, widgetValue, whichMenu)
    SimpleCombatLog:LoadSettingMenu_Mazzle(whichMenu, MazzleOptions.Actives[widgetID].widget.frame)
end
    
function MazzleOptions:Get_sRaid(varType)
    if (varType == "health") then
        local varValue = MazzleUI:GetValue("sRaidFramesDB.profiles.default.healthDisplayType")
        if (varValue == "percent") then return 1;
        elseif (varValue == "deficit") then return 2;
        elseif (varValue == "current") then return 3; end
    elseif (varType == "texture") then
        local varValue = MazzleUI:GetValue("sRaidFramesDB.profiles.default.texture")
        if (varValue == "Blizzard") then return 1;
        elseif (varValue == "Default") then return 2;
        elseif (varValue == "Smooth") then return 3;
        elseif (varValue == "Striped") then return 4; end
    elseif (varType == "sort") then
        local varValue = MazzleUI:GetValue("sRaidFramesDB.profiles.default.SortBy")
        if (varValue == "class") then return 1;
        elseif (varValue == "group") then return 2; end
    elseif (varType == "bufftype") then
        local varValue = MazzleUI:GetValue("sRaidFramesDB.profiles.default.BuffType")
        if (varValue == "buffs") then return 1;
        elseif (varValue == "debuffs") then return 2; end
    elseif (varType == "layout") then
        if (MazzleUI_LastAspect == "1") then return 5; else return 4; end
    end
end

function MazzleOptions:Set_sRaid(varType, varValue)
    if (varType == "health") then
        if (varValue == 1) then MazzleUI:Execute("/sRaidFrames health percent");
        elseif (varValue == 2) then MazzleUI:Execute("/sRaidFrames health deficit");
        elseif (varValue == 3) then MazzleUI:Execute("/sRaidFrames health current"); end
    elseif (varType == "texture") then
        if (varValue == 1) then MazzleUI:Execute("/sRaidFrames texture Blizzard");
        elseif (varValue == 2) then MazzleUI:Execute("/sRaidFrames texture Default");
        elseif (varValue == 3) then MazzleUI:Execute("/sRaidFrames texture Smooth");
        elseif (varValue == 4) then MazzleUI:Execute("/sRaidFrames texture Striped"); end
    elseif (varType == "sort") then
        if (varValue == 1) then MazzleUI:Execute("/sRaidFrames sort class");
        elseif (varValue == 2) then MazzleUI:Execute("/sRaidFrames sort group"); end
    elseif (varType == "bufftype") then
        if (varValue == 1) then MazzleUI:Execute("/sRaidFrames bufftype buffs");
        elseif (varValue == 2) then MazzleUI:Execute("/sRaidFrames bufftype debuffs"); end
    elseif (varType == "layout") then
        if (varValue == 1) then MazzleUI:Execute("/sRaidFrames layout vertical");
        elseif (varValue == 2) then MazzleUI:Execute("/sRaidFrames layout horizontal");
        elseif (varValue == 3) then MazzleUI:Execute("/sRaidFrames layout ctra");
        elseif (varValue == 4) then MazzleUI:Execute("/sRaidFrames layout mazzle");
        elseif (varValue == 5) then MazzleUI:Execute("/sRaidFrames layout mazzle125"); end
    end
end

function MazzleOptions:Get_oRA_MTF(varType)
    if (varType == "style") then
        local varValue = MazzleUI:GetValue("oRAMainTankFrames.profiles.default.style")
        if (varValue == "ctra") then return 1;
        elseif (varValue == "dire") then return 2;
        elseif (varValue == "praid") then return 3;
        elseif (varValue == "elysium") then return 4; end
    elseif (varType == "texture") then
        local varValue = MazzleUI:GetValue("oRAMainTankFrames.profiles.default.bartexture")
        if (varValue == "default") then return 1;
        elseif (varValue == "otravi") then return 2;
        elseif (varValue == "perl") then return 3;
        elseif (varValue == "smooth") then return 4;
        elseif (varValue == "striped") then return 5; end
    end
end

function MazzleOptions:Set_oRA_MTF(varType, varValue)
    if (varType == "style") then
        if (varValue == 1) then MazzleUI:Execute("/ora maintankframes style ctra");
        elseif (varValue == 2) then MazzleUI:Execute("/ora maintankframes style dire");
        elseif (varValue == 3) then MazzleUI:Execute("/ora maintankframes style praid");
        elseif (varValue == 4) then MazzleUI:Execute("/ora maintankframes style elysium"); end
    elseif (varType == "texture") then
        if (varValue == 1) then MazzleUI:Execute("/ora maintankframes bartexture default");
        elseif (varValue == 2) then MazzleUI:Execute("/ora maintankframes bartexture otravi");
        elseif (varValue == 3) then MazzleUI:Execute("/ora maintankframes bartexture perl");
        elseif (varValue == 4) then MazzleUI:Execute("/ora maintankframes bartexture smooth");
        elseif (varValue == 5) then MazzleUI:Execute("/ora maintankframes bartexture striped"); end
    end
end

function MazzleOptions:Get_oRA_RS(varType)
    if (varType == "fontsize") then
        local varValue = MazzleUI:GetValue("oRARaidSay.profiles.default.FontSize")
        if (varValue == "small") then return 1;
        elseif (varValue == "normal") then return 2;
        elseif (varValue == "large") then return 3;
        else return 4; end
    end
end

function MazzleOptions:Set_oRA_RS(varType, varValue)
    if (varType == "fontsize") then
        if (varValue == 1) then MazzleUI:Execute("/ora rs fontsize small");
        elseif (varValue == 2) then MazzleUI:Execute("/ora rs fontsize normal");
        elseif (varValue == 3) then MazzleUI:Execute("/ora rs fontsize large");
        elseif (varValue == 4) then MazzleUI:Execute("/ora rs fontsize huge"); end
    end
end

function MazzleOptions:RestoreChatFrames()
    ChatFrame6:Show()
    ChatFrame7:Show()
end

function MazzleOptions:Get_PartySpotter(varType)
    if (varType == "groups") then
        local varValue = MazzleUI:GetValue("PartySpotterSettings.showGroups")
        if (varValue == "Icons") then return 1;
        elseif (varValue == "Numbers") then return 2;
        elseif (varValue == "Nil") then return 3; end
    elseif (varType == "highlight") then
        local varValue = MazzleUI:GetValue("PartySpotterSettings.showFriends")
        if (varValue == "1") then return 1; end
        varValue = MazzleUI:GetValue("PartySpotterSettings.showGuild")
        if (varValue == "1") then return 2; end
        return 3;
    end
end

function MazzleOptions:Set_PartySpotter(varType, varValue)
    if (varType == "groups") then
        if (varValue == 1) then MazzleUI:Execute("/pspot showgroups icons");
        elseif (varValue == 2) then MazzleUI:Execute("/pspot showgroups numbers");
        elseif (varValue == 3) then MazzleUI:Execute("/pspot showgroups off"); end
    elseif (varType == "highlight") then
        MazzleUI:SetValue("PartySpotterSettings.showFriends", nil)
        MazzleUI:SetValue("PartySpotterSettings.showGuild", nil)
        MazzleUI:SetValue("PartySpotterSettings.showIgnores", nil)
        if (varValue == 1) then MazzleUI:SetValue("PartySpotterSettings.showFriends", "1")
        elseif (varValue == 2) then MazzleUI:SetValue("PartySpotterSettings.showGuild", "1");
        elseif (varValue == 3) then MazzleUI:SetValue("PartySpotterSettings.showIgnores", "1"); end
        PartySpotter_ConfigChange();
    end
end

