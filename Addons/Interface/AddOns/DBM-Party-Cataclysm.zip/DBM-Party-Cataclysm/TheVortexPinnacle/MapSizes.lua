DBM:RegisterMapSize("Skywall", 
	1, 2018.72503662109, 1345.81802368164
)
