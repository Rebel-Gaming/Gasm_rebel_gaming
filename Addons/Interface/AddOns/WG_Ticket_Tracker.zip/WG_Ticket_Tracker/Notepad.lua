-- SavedVariables
NotepadPages = { "" } -- numerically-indexed table of pages
NotepadSettings = {} -- Lock, Font

Notepad = {

	-- tooltip info for controls
	controls = {
		{"NotepadNew","New Page","Create a new page at end of book.  Hold Shift to insert after current page."},
		{"NotepadDelete","Delete Page","Permanently remove this page.  Hold Shift to delete without confirmation."},
		{"NotepadRun","Run Page","Run this page as a script."},
		{"NotepadStart","First Page","Go to first page"},
		{"NotepadLeft","Flip Back","Go back one page."},
		{"NotepadRight","Flip Forward","Go forward one page."},
		{"NotepadEnd","Last Page","Go to the last page."},
		{"NotepadClose","Close Notepad","Close the book."},
		{"NotepadLock","Lock","Lock or Unlock window."},
		{"NotepadFont","Font","Cycle through different fonts."},
		{"NotepadSearch","Options","Search pages for text, change fonts or lock window."},
		{"NotepadSearchNext","Find Next","Find next page with this text"},
		{"NotepadSearchEditBox","Search Criterea","Enter the text to search for here."},
		{"NotepadUndo","Undo","Revert page to last saved text."},
	},

	-- list of fonts to cycle through
	fonts = {
		{"Fonts\\FRIZQT__.TTF",10},
		{"Fonts\\FRIZQT__.TTF",12}, -- default
		{"Fonts\\FRIZQT__.TTF",16},
		{"Fonts\\ARIALN.TTF",12},
		{"Fonts\\ARIALN.TTF",16},
		{"Fonts\\ARIALN.TTF",20},
		{"Fonts\\MORPHEUS.ttf",16,"OUTLINE"},
		{"Fonts\\MORPHEUS.ttf",24,"OUTLINE"}
		-- add fonts here
	},

	current_page = 1, -- page currently viewed
	first_use = 1 -- whether this was used this session
}

BINDING_HEADER_Notepad = "Notepad"
StaticPopupDialogs["NotepadCONFIRM"] = { text = "Delete this page?", button1 = "Yes", button2 = "No", timeout = 0, whileDead = 1, OnAccept = function() Notepad.DeletePage() end}

function Notepad.OnLoad()
	this:SetMinResize(236,96)
	table.insert(UISpecialFrames,"NotepadFrame")
	table.insert(UISpecialFrames,"NotepadSearchFrame")

	this:RegisterEvent("PLAYER_LOGIN")
end

function Notepad.OnEvent()
	NotepadSettings.Font = NotepadSettings.Font or 2
	Notepad.UpdateFont()
	Notepad.UpdateLock()
end

-- /pad # will go to a page, /pad run # will run a page, /pad alone toggles window
function Notepad.SlashHandler(msg)
	local _,_,page = string.find(msg or "","(%d+)")
	if page then
		page = tonumber(page)
		if NotepadPages[page] then
			if string.find(string.lower(msg),"run") then
				RunScript(NotepadPages[page])
			else
				Notepad.current_page = page
				Notepad.ShowPage()
			end
		else
			DEFAULT_CHAT_FRAME:AddMessage("Notepad: Page "..page.." doesn't exist.")
		end
	else
		Notepad.Toggle()
	end
end

-- for use in macros, Notepad.Run(#) to run a page
function Notepad.Run(page)
	if page and tonumber(page) then
		Notepad.SlashHandler("run "..page)
	end
end

-- toggles window on/off screen
function Notepad.Toggle(msg)
	if NotepadFrame:IsVisible() then
		NotepadFrame:Hide()
	else
		NotepadFrame:Show()
	end
end

-- window movement
function Notepad.StartMoving()
	if arg1=="LeftButton" and not NotepadSettings.Lock then
		NotepadFrame:StartMoving()
	end
end

function Notepad.StopMoving()
	if arg1=="LeftButton" then
		NotepadFrame:StopMovingOrSizing()
	end
end

function Notepad.Tooltip()
	local which = this:GetName()
	for i in pairs(Notepad.controls) do
		if Notepad.controls[i][1]==which then
			GameTooltip_SetDefaultAnchor(GameTooltip,UIParent)
			GameTooltip:AddLine(Notepad.controls[i][2])
			GameTooltip:AddLine(Notepad.controls[i][3],.85,.85,.85,1)
			GameTooltip:Show()
			break
		end
	end
end

-- Titlebar button clicks
function Notepad.OnClick()

	local which = this:GetName()
	local new_page
	local book = NotepadPages

	if which=="NotepadUndo" then
		NotepadEditBox:SetText(NotepadPages[Notepad.current_page])
	end

	if which=="NotepadNew" then
		if not IsShiftKeyDown() then
			table.insert(book,"")
			new_page = table.getn(book)
		else
			table.insert(book,Notepad.current_page+1,"")
			new_page = Notepad.current_page + 1
		end
	elseif which=="NotepadDelete" then
		if not IsShiftKeyDown() and string.len(book[Notepad.current_page])>0 then
			StaticPopup_Show("NotepadCONFIRM")
		else
			Notepad.DeletePage() -- delete empty pages without confirmation
		end
	elseif which=="NotepadRun" then
		NotepadPages[Notepad.current_page] = NotepadEditBox:GetText()
		NotepadUndo:Disable()
		RunScript(book[Notepad.current_page])
	elseif which=="NotepadStart" then
		new_page = 1
	elseif which=="NotepadLeft" then
		new_page = math.max(Notepad.current_page-1,1)
	elseif which=="NotepadRight" then
		new_page = math.min(Notepad.current_page+1,table.getn(book))
	elseif which=="NotepadEnd" then
		new_page = table.getn(book)
	elseif which=="NotepadClose" then
		NotepadFrame:Hide()
	elseif which=="NotepadLock" then
		NotepadSettings.Lock = not NotepadSettings.Lock
		Notepad.UpdateLock()
	elseif which=="NotepadFont" then
		NotepadSettings.Font = NotepadSettings.Font+1
		Notepad.UpdateFont()
	elseif which=="NotepadSearch" then
		if NotepadSearchFrame:IsVisible() then
			NotepadSearchFrame:Hide()
		else
			NotepadSearchFrame:Show()
		end
	elseif which=="NotepadSearchNext" then
		Notepad.DoSearch()
	end

	if new_page then
		NotepadPages[Notepad.current_page] = NotepadEditBox:GetText()
		Notepad.current_page = new_page
		Notepad.ShowPage()
	end
end

-- removes the current page
function Notepad.DeletePage()

	local book = NotepadPages

	table.remove(book,Notepad.current_page)
	if table.getn(book)==0 then
		table.insert(book,"")
	end
	Notepad.current_page = math.min(Notepad.current_page,table.getn(book))
	Notepad.ShowPage()
end

-- disables/enables page movement buttons depending on page
function Notepad.ValidateButtons()

	-- nil for disabled, 1 for enabled
	local function set_state(button,enabled)
		if enabled then
			button:SetAlpha(1)
			button:Enable()
		else
			button:SetAlpha(.5)
			button:Disable()
		end
	end

	set_state(NotepadStart,1)
	set_state(NotepadLeft,1)
	set_state(NotepadRight,1)
	set_state(NotepadEnd,1)

	if Notepad.current_page==1 then
		set_state(NotepadStart)
		set_state(NotepadLeft)
	end
	if Notepad.current_page==table.getn(NotepadPages) then
		set_state(NotepadRight)
		set_state(NotepadEnd)
	end
end

-- shows/updates the current page
function Notepad.ShowPage()
	if not NotepadFrame:IsVisible() then
		NotepadFrame:Show()
	end
	if NotepadPages[Notepad.current_page] then
		NotepadPageNum:SetText(Notepad.current_page)
		NotepadEditBox:SetText(NotepadPages[Notepad.current_page])
		Notepad.ValidateButtons()
	end
end

-- refreshes window when shown
function Notepad.OnShow()
	if Notepad.first_use then
		-- only when the pad is first shown show last page
		Notepad.current_page = table.getn(NotepadPages)
		Notepad.first_use = nil
	end
	Notepad.ShowPage()
	NotepadEditBox:SetWidth(NotepadFrame:GetWidth()-50)
end

-- saves page when window hides
function Notepad.OnHide()
	NotepadPages[Notepad.current_page] = NotepadEditBox:GetText()
	NotepadUndo:Disable()
	NotepadEditBox:ClearFocus()
end

-- changes border and resize grip depending on lock status
function Notepad.UpdateLock()
	if NotepadSettings.Lock then
		NotepadFrame:SetBackdropBorderColor(0,0,0,1)
		NotepadSearchFrame:SetBackdropBorderColor(0,0,0,1)
		NotepadResizeGrip:Hide()
	else
		NotepadFrame:SetBackdropBorderColor(1,1,1,1)
		NotepadSearchFrame:SetBackdropBorderColor(1,1,1,1)
		NotepadResizeGrip:Show()
	end
	Notepad.MakeESCable("NotepadFrame",NotepadSettings.Lock)
end

-- updates EditBox font to current settings
function Notepad.UpdateFont()
	if NotepadSettings.Font > table.getn(Notepad.fonts) then
		NotepadSettings.Font = 1
	end
	local font = NotepadSettings.Font
	NotepadEditBox:SetFont(Notepad.fonts[font][1],Notepad.fonts[font][2],Notepad.fonts[font][3])
end

-- adds frame to UISpecialFrames, removes frame if disable true
function Notepad.MakeESCable(frame,disable)
	local idx
	for i=1,table.getn(UISpecialFrames) do
		if UISpecialFrames[i]==frame then
			idx = i
			break
		end
	end
	if idx and disable then
		table.remove(UISpecialFrames,idx)
	elseif not idx and not disable then
		table.insert(UISpecialFrames,1,frame)
	end
end
	
-- when search summoned, remove ESCability of main window (only search cleared with ESC)
function Notepad.SearchOnShow()
	Notepad.MakeESCable("NotepadFrame","disable")
end

-- when search dismissed, restore ESCability to main window and reset search elements
function Notepad.SearchOnHide()
	if not NotepadSettings.Lock then
		Notepad.MakeESCable("NotepadFrame")
	end
	NotepadSearchResults:SetText("Search:")
	NotepadSearchEditBox:ClearFocus()
end

-- does a count
function Notepad.SearchEditBoxOnChange()
	local search = string.lower(NotepadSearchEditBox:GetText() or "")
	if string.len(search)<1 then
		NotepadSearchResults:SetText("Search:")
	else
		local count = 0
		for i=1,table.getn(NotepadPages) do
			count = count + (string.find(string.lower(NotepadPages[i]),search,1,1) and 1 or 0)
		end
		NotepadSearchResults:SetText(count.." found")
	end
end

-- performs a search for the text in the search box
function Notepad.DoSearch()
	local search = string.lower(NotepadSearchEditBox:GetText() or "")
	if string.len(search)<1 then
		return
	end
	local page = Notepad.current_page
	for i=1,table.getn(NotepadPages) do
		page = page + 1
		if page > table.getn(NotepadPages) then
			page = 1
		end
		if string.find(string.lower(NotepadPages[page]),search,1,1) then
			NotepadPages[Notepad.current_page] = NotepadEditBox:GetText()
			Notepad.current_page = page
			Notepad.ShowPage()
			return
		end
	end
end

function Notepad.OnTextChanged()
	local scrollBar = getglobal(this:GetParent():GetName().."ScrollBar")
	this:GetParent():UpdateScrollChildRect()
	local min, max = scrollBar:GetMinMaxValues()
	if ( max > 0 and (this.max ~= max) ) then
		this.max = max
		scrollBar:SetValue(max)
	end
	if this:GetText()~=NotepadPages[Notepad.current_page] then
		NotepadUndo:Enable()
	else
		NotepadUndo:Disable()
	end
end

