﻿function MiniMap_Button()
	if WG_Main_Small:IsVisible() then WG_Main_Small:Hide();
	else
	WG_Main_Small:Show();
	end
end
---- Say Functions ----
function say(text)
	SendChatMessage(text, "SAY", nil,nil);
end
---- Local Functions ----
local gmName = UnitName("player");
---- Announcements
function TicketEnterBug()
	set=".a Tickets : Please do NOT use [Enter] when making your ticket.  If you use [Enter] in your ticket we will not be able to read it.  Thank you!";
	say(set);
end
function DonationAnn()
	set=".a Donation Tickets need the following information: Email Address, Name, Donation Date, and Items donated for.  Please do NOT use the [Enter] key when making your ticket as we will NOT be able to read it.";
	say(set);
	set=".a Thank you for your continued Support of WoWGasm!";
	say(set);
end

function GRAnn()
	set=".a The following is the new guideline for all guild recruitment in any public channel.  Anyone violating this will be muted for a first offense, banned for a second, with bans getting longer on third and fourth offenses.";
	say(set);
	set=".a <GuildName> is now recruiting levels ## and higher.  Horde/Alliance/Both H&A";
	say(set);
end

function StancesAnn()
	set=".a Hunter Pet, Druid Bear Form (Both start in your level 5 town),  Warrior Stance, and Warlock Minions quests are working.  Use wowhead.com or your fellow players in getting assistance with these quests.";
	say(set);
end

function VotingAnn()
	set=".a http://www.wowgasm.org/tools/voter.php - Please vote for us to receive your voter token.  Voters tokens can be traded in for reputation and gear.";
	say(set);
end

function LFGRulesAnn()
	set=".a Just a reminder, We do NOT allow foul language, hateful or harassing comments, or donor bashing on this server.  Anyone violating these rules will be kicked, muted, and/or banned!";
	say(set);
end

---- Casters Set ----
function CasterSet()
	set=".character additemset 800";
	say(set);
	set=".character learnsk 136 450 450"
	say(set);
end
---- GM1 Rules ----
function GM1Rules()
	set="The rules for GM1 are: 1) Do not teleport to or summon anyone without their permission. 2) Do not use your powers for PVP. 3) Do not teleport to ANY GM designated areas. 4) Do not go to the opposite factions SC or Non-PVP Leveling areas.";
	say(set);
	set="The commands for GM1 are: .recall list - to see a list of places to teleport to - .recall port <Place> to teleport - .summon <PlayerName> to summon a player to you - .appear <PlayerName> to appear to a player.";
	say(set);
end
---- Nexus Armors ----
---- FrostHeart T7 ----
function DeathKnightFT7()
    set=".character additem 165018";
    say(set);
    set=".character additem 165019";
    say(set);
    set=".character additem 165020";
    say(set);
    set=".character additem 165021";
    say(set);
    set=".character additem 165022";
    say(set);
    set=".character additem 165023";
    say(set);
    set=".character additem 165024";
    say(set);
end

function DeathKnightST6()
    set=".character additem 164011";
    say(set);
    set=".character additem 164012";
    say(set);
    set=".character additem 164013";
    say(set);
    set=".character additem 164014";
    say(set);
    set=".character additem 164015";
    say(set);
    set=".character additem 164016";
    say(set);
    set=".character additem 164017";
    say(set);
end

function DruidFT7()
    set=".character additem 165075";
    say(set);
    set=".character additem 165076";
    say(set);
    set=".character additem 165077";
    say(set);
    set=".character additem 165078";
    say(set);
    set=".character additem 165079";
    say(set);
    set=".character additem 165080";
    say(set);
    set=".character additem 165081";
    say(set);
end
    
function HunterFT7()
    set=".character additem 165068";
    say(set);
    set=".character additem 165069";
    say(set);
    set=".character additem 165070";
    say(set);
    set=".character additem 165071";
    say(set);
    set=".character additem 165072";
    say(set);
    set=".character additem 165073";
    say(set);
    set=".character additem 165074";
    say(set);
end

function MageFT7()
    set=".character additem 165061";
    say(set);
    set=".character additem 165062";
    say(set);
    set=".character additem 165063";
    say(set);
    set=".character additem 165064";
    say(set);
    set=".character additem 165065";
    say(set);
    set=".character additem 165066";
    say(set);
    set=".character additem 165067";
    say(set);
end

function PaladinFT7()
    set=".character additem 165040";
    say(set);
    set=".character additem 165041";
    say(set);
    set=".character additem 165042";
    say(set);
    set=".character additem 165043";
    say(set);
    set=".character additem 165044";
    say(set);
    set=".character additem 165045";
    say(set);
    set=".character additem 165046";
    say(set);
end

function PriestFT7()
    set=".character additem 165025";
    say(set);
    set=".character additem 165026";
    say(set);
    set=".character additem 165027";
    say(set);
    set=".character additem 165028";
    say(set);
    set=".character additem 165029";
    say(set);
    set=".character additem 165030";
    say(set);
    set=".character additem 165031";
    say(set);
end

function RogueFT7()
    set=".character additem 164004";
    say(set);
    set=".character additem 164005";
    say(set);
    set=".character additem 164006";
    say(set);
    set=".character additem 164007";
    say(set);
    set=".character additem 164008";
    say(set);
    set=".character additem 164009";
    say(set);
    set=".character additem 164010";
    say(set);
end

function ShamanFT7()
    set=".character additem 165054";
    say(set);
    set=".character additem 165055";
    say(set);
    set=".character additem 165056";
    say(set);
    set=".character additem 165057";
    say(set);
    set=".character additem 165058";
    say(set);
    set=".character additem 165059";
    say(set);
    set=".character additem 165060";
    say(set);
end

function WarlockFT7()
    set=".character additem 165032";
    say(set);
    set=".character additem 165033";
    say(set);
    set=".character additem 165034";
    say(set);
    set=".character additem 165035";
    say(set);
    set=".character additem 165037";
    say(set);
    set=".character additem 165038";
    say(set);
    set=".character additem 165039";
    say(set);
end

function WarriorFT7()
    set=".character additem 165047";
    say(set);
    set=".character additem 165048";
    say(set);
    set=".character additem 165049";
    say(set);
    set=".character additem 165050";
    say(set);
    set=".character additem 165051";
    say(set);
    set=".character additem 165052";
    say(set);
    set=".character additem 165053";
    say(set);
end
---- Warrior Nexus----
function WarriorST6()
    set=".character additemset 672";
    say(set);
end

function WarriorFT5()
set=".character additemset 753";
say(set);
end

function WarriorMT5()
set=".character additemset 1656";
say(set);
end
---- Druid Nexus ----
function DruidST6()
set=".character additemset 6145";
say(set);
end

function DruidFT5()
set=".character additemset 773";
say(set);
end

function DruidMT5()
set=".character additemset 1772";
say(set);
end
---- Warlock Nexus ----
function WarlockST6()
set=".character additemset 6012";
say(set);
end

function WarlockFT5()
set=".character additemset 757";
say(set);
end

function WarlockMT5()
set=".character additemset 1751";
say(set);
end
---- Priest Nexus ----
function PriestST6()
set=".character additemset 6081";
say(set);
end

function PriestFT5()
set=".character additemset 758";
say(set);
end

function PriestMT5()
set=".character additemset 1665";
say(set);
end
---- Mage Nexus ----
function MageST6()
set=".character additemset 6028";
say(set);
end

function MageFT5()
set=".character additemset 754";
say(set);
end

function MageMT5()
set=".character additem 7337488";
say(set);
set=".character additem 7337489";
say(set);
set=".character additem 7337490";
say(set);
set=".character additem 7337491";
say(set);
set=".character additem 7337492";
say(set);
set=".character additem 7337493";
say(set);
set=".character additem 7337494";
say(set);
set=".character additem 7337495";
say(set);
end
---- Paladin Nexus ----
function PaladinST6()
set=".character additemset 6230";
say(set);
end

function PaladinFT5()
set=".character additemset 755";
say(set);
end

function PaladinMT5()
set=".character additem 7337412";
say(set); 
set=".character additem 7337413";
say(set);
set=".character additem 7337414";
say(set);
set=".character additem 7337415";
say(set);
set=".character additem 7337416";
say(set);
end
---- Hunter Nexus ----
function HunterST6()
set=".character additemset 5991";
say(set);
end

function HunterFT5()
set=".character additemset 760";
say(set);
end

function HunterMT5()
set=".character additemset 1750";
say(set);
end
---- Shaman Nexus ----
function ShamanST6()
set=".character additemset 6289";
say(set);
end

function ShamanFT5()
set=".character additemset 770";
say(set);
end

function ShamanMT5()
set=".character additemset 1771";
say(set);
end
---- Rogue Nexus ----
function RogueST6()
set=".character additemset 5976";
say(set);
end

function RogueFT5()
set=".character additemset 756";
say(set);
end

function RogueMT5()
set=".character additemset 1752";
say(set);
end

---- Nexus Weapons ----

function NWarglaive()
set=".character additem 32837";
say(set);
set=".character additem 32838";
say(set);
set=".character learn 674"
say(set);
set=".character learnskill 43 350 350"
say(set);
set=".character learn 201";
say(set);
end

function NAxe()
set=".character additem 10000927";
say(set);
set=".character learn 196";
say(set);
end

function NDagger()
set=".character additem 10000928";
say(set);
set=".character learn 1180";
say(set);
end

function NBlade()
set=".character additem 10002000";
say(set);
set=".character learn 201";
say(set);
end

function NShield()
set=".character additem 10002100";
say(set);
set=".character learn 9116";
say(set);
set=".character learn 107";
say(set);
end

function NAzure()
set=".character additem 10010082";
say(set);
set=".character learn 197";
say(set);
end

function NDark()
set=".character additem 10010080";
say(set);
set=".character learn 199";
say(set);
end

function NEstryfe()
    set=".character additem 10010083";
    say(set);
end

---- Nexus Misc ----

function SNDrake()
set=".character additem 30609";
say(set);
set=".char learn 54197";
say(set);
set=".char learn 34091";
say(set);
set=".character learnsk 762 300 300"
say(set);
end

function Peep()
set=".character additem 32458";
say(set);
set=".char learn 54197";
say(set);
set=".char learn 34091";
say(set);
set=".character learnsk 762 300 300"
say(set);
end

function Frostwyrm()
set=".char learn 51960";
say(set);
set=".char learn 54197";
say(set);
set=".char learn 34091";
say(set);
set=".character learnsk 762 300 300"
say(set);
end

function gold3()
set=".character additem 8117003";
say(set);
end

function gold2()
set=".character additem 8117002";
say(set);
end

function gold1()
set=".character additem 8117001";
say(set);
end

---- BT Armor ----
---- Tier 1 ----

function BTWarriorT1()
set=".character additemset 209";
say(set);
end

function BTDruidT1()
set=".character additemset 205";
say(set);
end

function BTWarlockT1()
set=".character additemset 203";
say(set);
end

function BTPriestT1()
set=".character additemset 202";
say(set);
end

function BTMageT1()
set=".character additemset 201";
say(set);
end

function BTPaladinT1()
set=".character additemset 208";
say(set);
end

function BTHunterT1()
set=".character additemset 206";
say(set);
end

function BTShamanT1()
set=".character additemset 207";
say(set);
end

function BTRogueT1()
set=".character additemset 204";
say(set);
end
---- Tier 2 ----
function BTWarriorT2()
set=".character additemset 218";
say(set);
end

function BTDruidT2()
set=".character additemset 214";
say(set);
end

function BTWarlockT2()
set=".character additemset 212";
say(set);
end

function BTPriestT2()
set=".character additemset 211";
say(set);
end

function BTMageT2()
set=".character additemset 210";
say(set);
end

function BTPaladinT2()
set=".character additemset 217";
say(set);
end

function BTHunterT2()
set=".character additemset 215";
say(set);
end

function BTShamanT2()
set=".character additemset 216";
say(set);
end

function BTRogueT2()
set=".character additemset 213";
say(set);
end
---- Tier 3 ----
function BTWarriorT3()
set=".character additemset 523";
say(set);
end

function BTDruidT3()
set=".character additemset 521";
say(set);
end

function BTWarlockT3()
set=".character additemset 529";
say(set);
end

function BTPriestT3()
set=".character additemset 525";
say(set);
end

function BTMageT3()
set=".character additemset 526";
say(set);
end

function BTPaladinT3()
set=".character additemset 528";
say(set);
end

function BTHunterT3()
set=".character additemset 530";
say(set);
end

function BTShamanT3()
set=".character additemset 527";
say(set);
end

function BTRogueT3()
set=".character additemset 524";
say(set);
end
---- Tier 4 ----
function BTWarriorT4Defense()
set=".character additemset 654";
say(set);
end

function BTWarriorT4DPS()
set=".character additemset 655";
say(set);
end

function BTDruidT4Feral()
set=".character additemset 640";
say(set);
end

function BTDruidT4Healing()
set=".character additemset 638";
say(set);
end

function BTDruidT4SpellDPS()
set=".character additemset 639";
say(set);
end

function BTWarlockT4()
set=".character additemset 645";
say(set);
end

function BTPriestT4()
set=".character additemset 664";
say(set);
end
function BTPriestT4Holy()
set".char additemset 663"
say(set);
end

function BTMageT4()
set=".character additemset 648";
say(set);
end

function BTPaladinT4Defense()
set=".character additemset 625";
say(set);
end

function BTPaladinT4Ret()
set=".character additemset 626";
say(set);
end

function BTPaladinT4Healing()
set=".character additemset 624";
say(set);
end

function BTHunterT4()
set=".character additemset 651";
say(set);
end

function BTShamanT4Melee()
set=".character additemset 633";
say(set);
end

function BTShamanT4Healing()
set=".character additemset 631";
say(set);
end

function BTShamanT4Spell()
set=".character additemset 632";
say(set);
end

function BTRogueT4()
set=".character additemset 621";
say(set);
end
------------------------T5----------------------------
function BTWarriorT5Defense()
set=".character additemset 656";
say(set);
end

function BTWarriorT5DPS()
set=".character additemset 657";
say(set);
end

function BTDruidT5Feral()
set=".character additemset 641";
say(set);
end

function BTDruidT5Healing()
set=".character additemset 642";
say(set);
end

function BTDruidT5SpellDPS()
set=".character additemset 643";
say(set);
end

function BTWarlockT5()
set=".character additemset 646";
say(set);
end

function BTPriestT5Healing()
set=".character additemset 665";
say(set);
end

function BTPriestT5Shadow()
set=".character additemset 666";
say(set);
end

function BTMageT5()
set=".character additemset 649";
say(set);
end

function BTPaladinT5Defense()
set=".character additemset 628";
say(set);
end

function BTPaladinT5Ret()
set=".character additemset 629";
say(set);
end

function BTPaladinT5Holy()
set=".character additemset 627";
say(set);
end

function BTHunterT5()
set=".character additemset 652";
say(set);
end

function BTShamanT5Melee()
set=".character additemset 636";
say(set);
end

function BTShamanT5Healing()
set=".character additemset 634";
say(set);
end

function BTShamanT5Spell()
set=".character additemset 635";
say(set);
end

function BTRogueT5()
set=".character additemset 622";
say(set);
end
-----------T6-------------------------
function BTWarriorT6Defense()
set=".character additemset 673";
say(set);
end

function BTWarriorT6DPS()
set=".character additemset 672";
say(set);
end

function BTDruidT6Feral()
set=".character additemset 676";
say(set);
end

function BTDruidT6Healing()
set=".character additemset 678";
say(set);
end

function BTDruidT6SpellDPS()
set=".character additemset 677";
say(set);
end

function BTWarlockT6()
set=".character additemset 670";
say(set);
end

function BTPriestT6Healing()
set=".character additemset 675";
say(set);
end

function BTPriestT6Shadow()
set=".character additemset 674";
say(set);
end

function BTMageT6()
set=".character additemset 671";
say(set);
end

function BTPaladinT6Defense()
set=".character additemset 679";
say(set);
end

function BTPaladinT6Healing()
set=".character additemset 681";
say(set);
end

function BTPaladinT6Ret()
set=".character additemset 680";
say(set);
end

function BTHunterT6()
set=".character additemset 669";
say(set);
end

function BTShamanT6Melee()
set=".character additemset 682";
say(set);
end

function BTShamanT6Healing()
set=".character additemset 683";
say(set);
end

function BTShamanT6Spell()
set=".character additemset 684";
say(set);
end

function BTRogueT6()
set=".character additemset 668";
say(set);
end
------3.2+ Gear-----
function BTWarriorDPST7()
set=".char additem 40525"
say(set);
set=".char additem 40527"
say(set);
set=".char additem 40528"
say(set);
set=".char additem 40529"
say(set);
set=".char additem 40530"
say(set);
end
function BTWarriorProtT7()
set=".char additem 40544"
say(set);
set=".char additem 40545"
say(set);
set=".char additem 40546"
say(set);
set=".char additem 40547"
say(set);
set=".char additem 40548"
say(set);
end
function BTPriestHolyT7()
set=".char additem 40445"
say(set);
set=".char additem 40447"
say(set);
set=".char additem 40448"
say(set);
set=".char additem 40449"
say(set);
set=".char additem 40450"
say(set);
end
function BTPriestDPST7()
set=".char additem 40454"
say(set);
set=".char additem 40456"
say(set);
set=".char additem 40457"
say(set);
set=".char additem 40458"
say(set);
set=".char additem 40459"
say(set);
end
function BTShamanRestoT7()
set=".char additem 40508"
say(set);
set=".char additem 40509"
say(set);
set=".char additem 40510"
say(set);
set=".char additem 40512"
say(set);
set=".char additem 40513"
say(set);
end

function BTShamanEleT7()
set=".char additem 40514"
say(set);
set=".char additem 40515"
say(set);
set=".char additem 40516"
say(set);
set=".char additem 40517"
say(set);
set=".char additem 40518"
say(set);
end

function BTShamanEnhT7()
set=".char additem 45020"
say(set);
set=".char additem 45021"
say(set);
set=".char additem 45022"
say(set);
set=".char additem 45023"
say(set);
set=".char additem 45024"
say(set);
end

function BTPaladinRetT7()
set=".char additem 40574" 
say(set);
set=".char additem 40575"
say(set);
set=".char additem 40576"
say(set);
set=".char additem 40577"
say(set);
set=".char additem 40578"
say(set);
end

function BTPaladinProtT7()
set=".char additem 40579"
say(set);
set=".char additem 40580"
say(set);
set=".char additem 40581"
say(set);
set=".char additem 40583"
say(set);
set=".char additem 40584"
say(set);
end

function BTPaladinHolyT7()
set=".char additem 40569"
say(set);
set=".char additem 40570"
say(set);
set=".char additem 40571"
say(set);
set=".char additem 40572"
say(set);
set=".char additem 40573"
say(set);
end



------T8-----
function BTWarriorDPST8()
set=".char additem 46146"
say(set);
set=".char additem 46148"
say(set);
set=".char additem 46149"
say(set);
set=".char additem 46150"
say(set);
set=".char additem 46151"
say(set);
end
function BTWarriorProtT8()
set=".char additem 46162"
say(set);
set=".char additem 46164"
say(set);
set=".char additem 46166"
say(set);
set=".char additem 46167"
say(set);
set=".char additem 46169"
say(set);
end

function BTPriestHolyT8()
set=".char additem 46188"
say(set);
set=".char additem 46190"
say(set);
set=".char additem 46193"
say(set);
set=".char additem 46195"
say(set);
set=".char additem 46197"
say(set);
end

function BTPriestDPST8()
set=".char additem 46163"
say(set);
set=".char additem 46165"
say(set);
set=".char additem 46168"
say(set);
set=".char additem 46170"
say(set);
set=".char additem 46172"
say(set);
end

function BTShamanRestoT8()
set=".char additem 46198"
say(set);
set=".char additem 46199"
say(set);
set=".char additem 46201"
say(set);
set=".char additem 46202"
say(set);
set=".char additem 46204"
say(set);
end

function BTShamanEnhT8()
set=".char additem 46200"
say(set);
set=".char additem 46203"
say(set);
set=".char additem 46205"
say(set);
set=".char additem 46208"
say(set);
set=".char additem 46212"
say(set);
end
function BTShamanEleT8()
set=".char additem 46206"
say(set);
set=".char additem 46207"
say(set);
set=".char additem 46209"
say(set);
set=".char additem 46210"
say(set);
set=".char additem 46211"
say(set);
end
--DK*

function dkt825damage()
   set=".char additem 46111";
   say(set);
   set=".char additem 46113";
   say(set);
   set=".char additem 46115";
   say(set);
   set=".char additem 46116";
   say(set);
   set=".char additem 46117";
   say(set);
end


function dkt825tank()
   set=".char additem 46118";
   say(set);
   set=".char additem 46119";
   say(set);
   set=".char additem 46120";
   say(set);
   set=".char additem 46121";
   say(set);
   set=".char additem 46122";
   say(set);
end

--DRUID*

function druidt825feral()
   set=".char additem 46157";
   say(set);
   set=".char additem 46158";
   say(set);
   set=".char additem 46159";
   say(set);
   set=".char additem 46160";
   say(set);
   set=".char additem 46161";
   say(set);
end


function druidt825balance()
   set=".char additem 46189";
   say(set);
   set=".char additem 46191";
   say(set);
   set=".char additem 46192";
   say(set);
   set=".char additem 46194";
   say(set);
   set=".char additem 46196";
   say(set);
end

function druidt825restore()
   set=".char additem 46183";
   say(set);
   set=".char additem 46184";
   say(set);
   set=".char additem 46185";
   say(set);
   set=".char additem 46186";
   say(set);
   set=".char additem 46187";
   say(set);
end

function BTPaladinRetT8()

set=".char additem 46152"
say(set);
set=".char additem 46153"
say(set);
set=".char additem 46154"
say(set);
set=".char additem 46155"
say(set);
set=".char additem 46156"
say(set);
end


function BTPaladinProtT8()

set=".char additem 46173"
say(set);
set=".char additem 46174"
say(set);
set=".char additem 46175"
say(set);
set=".char additem 46176"
say(set);
set=".char additem 46177"
say(set);
end



function BTPaladinHolyT8()
set=".char additem 46178"
say(set);
set=".char additem 46179"
say(set);
set=".char additem 46180"
say(set);
set=".char additem 46181"
say(set);
set=".char additem 46182"
say(set);
end

function BTMageT8()
set=".char additem 46129"
say(set);
set=".char additem 46130"
say(set);
set=".char additem 46132"
say(set);
set=".char additem 46133"
say(set);
set=".char additem 46134"
say(set);
end

function BTHunterT8()
set=".char additem 46141"
say(set);
set=".char additem 46142"
say(set);
set=".char additem 46143"
say(set);
set=".char additem 46144"
say(set);
set=".char additem 46145"
say(set);
end


function BTRogueT8()
set=".char additem 46123"
say(set);
set=".char additem 46124"
say(set);
set=".char additem 46125"
say(set);
set=".char additem 46126"
say(set);
set=".char additem 46127"
say(set);
end

function BTWarlockT8()
set=".char additem 46135"
say(set);
set=".char additem 46136"
say(set);
set=".char additem 46137"
say(set);
set=".char additem 46139"
say(set);
set=".char additem 46140"
say(set);
end

-----T9 Ally-----
function AWarriorDPST9()
set=".char additem 48383"
say(set);
set=".char additem 48381"
say(set);
set=".char additem 48385"
say(set);
set=".char additem 48384"
say(set);
set=".char additem 48382"
say(set);
end
function AWarriorProtT9()
set=".char additem 48433"
say(set);
set=".char additem 48455"
say(set);
set=".char additem 48451"
say(set);
set=".char additem 48453"
say(set);
set=".char additem 48447"
say(set);
end 

function APriestDPST9()
set=".char additem 48085"
say(set);
set=".char additem 48082"
say(set);
set=".char additem 48083"
say(set);
set=".char additem 48086"
say(set);
set=".char additem 48084"
say(set);
end

function ApriestHolyT9()
set=".char additem 48035"
say(set);
set=".char additem 48029"
say(set);
set=".char additem 48031"
say(set);
set=".char additem 48037"
say(set);
set=".char additem 48033"
say(set);
end

function ADruidBalanceT9()
set=".char additem 48171"
say(set);
set=".char additem 48168"
say(set);
set=".char additem 48169"
say(set);
set=".char additem 48172"
say(set);
set=".char additem 48170"
say(set);
end

function ADruidFeralT9()
set=".char additem 48204"
say(set);
set=".char additem 48207"
say(set);
set=".char additem 48206"
say(set);
set=".char additem 48203"
say(set);
set=".char additem 48205"
say(set);
end
function ADruidRestoT9()
set=".char additem 48141"
say(set);
set=".char additem 48138"
say(set);
set=".char additem 48139"
say(set);
set=".char additem 48142"
say(set);
set=".char additem 48140"
say(set);
end

function AShamanRestoT9()
set=".char additem 48292"
say(set);
set=".char additem 48290"
say(set);
set=".char additem 48294"
say(set);
set=".char additem 48293"
say(set);
set=".char additem 48291"
say(set);
end 

function AShamanEnhT9()
set=".char additem 48353"
say(set);
set=".char additem 48351"
say(set);
set=".char additem 48355"
say(set);
set=".char additem 48354"
say(set);
set=".char additem 48352"
say(set);
end

function AShamanEleT9()
set=".char additem 48323"
say(set);
set=".char additem 48321"
say(set);
set=".char additem 48325"
say(set);
set=".char additem 48324"
say(set);
set=".char additem 48322"
say(set);
end

function ADKDPST9()

set=".char additem 48488"
say(set);
set=".char additem 48486"
say(set);
set=".char additem 48490"
say(set);
set=".char additem 48489"
say(set);
set=".char additem 48487"
say(set);
end

function ADKTankT9()

set=".char additem 48545"
say(set);
set=".char additem 48543"
say(set);
set=".char additem 48547"
say(set);
set=".char additem 48546"
say(set);
set=".char additem 48544"
say(set);
end

function AHunterT9()

set=".char additem 48262"
say(set);
set=".char additem 48260"
say(set);
set=".char additem 48264"
say(set);
set=".char additem 48263"
say(set);
set=".char additem 48261"
say(set);
end

function AMageT9()

set=".char additem 47761"
say(set);
set=".char additem 47758"
say(set);
set=".char additem 47759"
say(set);
set=".char additem 47762"
say(set);
set=".char additem 47760"
say(set);
end

function APaladinProtT9()
set=".char additem 48644"
say(set);
set=".char additem 48646"
say(set);
set=".char additem 48642"
say(set);
set=".char additem 48643"
say(set);
set=".char additem 48645"
say(set);
end

function APaladinHolyT9()
set=".char additem 48582"
say(set);
set=".char additem 48580"
say(set);
set=".char additem 48584"
say(set);
set=".char additem 48583"
say(set);
set=".char additem 48581"
say(set);
end

function APaladinRetT9()
set=".char additem 48614"
say(set);
set=".char additem 48612"
say(set);
set=".char additem 48616"
say(set);
set=".char additem 48615"
say(set);
set=".char additem 48613"
say(set);
end


function ARogueT9()
set=".char additem 48230"
say(set);
set=".char additem 48228"
say(set);
set=".char additem 48232"
say(set);
set=".char additem 48231"
say(set);
set=".char additem 48229"
say(set);
end

function AWarlockT9()
set=".char additem 47789"
say(set);
set=".char additem 47792"
say(set);
set=".char additem 47791"
say(set);
set=".char additem 47788"
say(set);
set=".char additem 47790"
say(set);
end
------T9 Horde------
function HWarriorDPST9()
set=".char additem 48398"
say(set);
set=".char additem 48400"
say(set);
set=".char additem 48396"
say(set);
set=".char additem 48397"
say(set);
set=".char additem 48399"
say(set);
end
function HWarriorProtT9()
set=".char additem 48468"
say(set);
set=".char additem 48470"
say(set);
set=".char additem 48466"
say(set);
set=".char additem 48467"
say(set);
set=".char additem 48469"
say(set);
end
function HPriestDPST9()
set=".char additem 48088"
say(set);
set=".char additem 48091"
say(set);
set=".char additem 48090"
say(set);
set=".char additem 48087"
say(set);
set=".char additem 48089"
say(set);
end

function HPriestHolyT9()
set=".char additem 48058"
say(set);
set=".char additem 48061"
say(set);
set=".char additem 48060"
say(set);
set=".char additem 48057"
say(set);
set=".char additem 48059"
say(set);
end

function HDruidFeralT9()
set=".char additem 48201"
say(set);
set=".char additem 48198"
say(set);
set=".char additem 48199"
say(set);
set=".char additem 48202"
say(set);
set=".char additem 48200"
say(set);
end

function HDruidRestoT9()
set=".char additem 48144"
say(set);
set=".char additem 48147"
say(set);
set=".char additem 48146"
say(set);
set=".char additem 48143"
say(set);
set=".char additem 48145"
end

function HDruidBalanceT9()
set=".char additem 48174"
say(set);
set=".char additem 48177"
say(set);
set=".char additem 48176"
say(set);
set=".char additem 48173"
say(set);
set=".char additem 48175"
say(set);
end
function HShamanRestoT9()
set=".char additem 48307"
say(set);
set=".char additem 48309"
say(set);
set=".char additem 48305"
say(set);
set=".char additem 48306"
say(set);
set=".char additem 48308"
say(set);
end

function HShamanEleT9()
set=".char additem 48328"
say(set);
set=".char additem 48330"
say(set);
set=".char additem 48326"
say(set);
set=".char additem 48327"
say(set);
set=".char additem 48329"
say(set);
end

function HShamanEnhT9()
set=".char additem 48358"
say(set);
set=".char additem 48360"
say(set);
set=".char additem 48356"
say(set);
set=".char additem 48357"
say(set);
set=".char additem 48359"
say(set);
end

function HHunterT9()
set=".char additem 48267"
say(set);
set=".char additem 48269"
say(set);
set=".char additem 48265"
say(set);
set=".char additem 48266"
say(set);
set=".char additem 48268"
say(set);
end
function HWarlockT9()
set=".char additem 47796"
say(set);
set=".char additem 48330"
say(set);
set=".char additem 47794"
say(set);
set=".char additem 47797"
say(set);
set=".char additem 47795"
say(set);
end

function HRogueT9()
set=".char additem 48235"
say(set);
set=".char additem 48237"
say(set);
set=".char additem 48233"
say(set);
set=".char additem 48234"
say(set);
set=".char additem 48236"
say(set);
end

function HMageT9()
set=".char additem 47764"
say(set);
set=".char additem 47767"
say(set);
set=".char additem 47766"
say(set);
set=".char additem 47763"
say(set);
set=".char additem 47765"
say(set);
end

function HPaladinRetT9()
set=".char additem 48619"
say(set);
set=".char additem 48621"
say(set);
set=".char additem 48617"
say(set);
set=".char additem 48618"
say(set);
set=".char additem 48620"
say(set);
end

function HPaladinProtT9()
set=".char additem 48649"
say(set);
set=".char additem 48647"
say(set);
set=".char additem 48651"
say(set);
set=".char additem 48650"
say(set);
set=".char additem 48648"
say(set);
end

function HPaladinHolyT9()
set=".char additem 48587"
say(set);
set=".char additem 48585"
say(set);
set=".char additem 48589"
say(set);
set=".char additem 48588"
say(set);
set=".char additem 48586"
say(set);
end
function HDKTankT9()
set=".char additem 48550"
say(set);
set=".char additem 48552"
say(set);
set=".char additem 48548"
say(set);
set=".char additem 48549"
say(set);
set=".char additem 48551"
say(set);
end

function HDKDPST9()
set=".char additem 48493"  
say(set);
set=".char additem 48495"
say(set);
set=".char additem 48491"
say(set);
set=".char additem 48492"
say(set);
set=".char additem 48494"
say(set);
end

---- Weapon Skills ----
function All_w_skills()
    set=".character learnskill 433 450 450";
    say(set);
    set=".character learnskill 9116 450 450";
    say(set);
    set=".character learnskill 473 450 450";
    say(set);
    set=".character learnskill 160 450 450";
    say(set);
    set=".character learnskill 45 450 450";
    say(set);
    set=".character learnskill 229 450 450";
    say(set);
    set=".character learnskill 46 450 450";
    say(set);
    set=".character learnskill 176 450 450";
    say(set);
    set=".character learnskill 44 450 450";
    say(set);
    set=".character learnskill 118 450 450";
    say(set);
    set=".character learnskill 172 450 450";
    say(set);
    set=".character learnskill 173 450 450";
    say(set);
    set=".character learnskill 226 450 450";
    say(set);
    set=".character learnskill 228 450 450";
    say(set);
    set=".character learnskill 43 450 450";
    say(set);
    set=".character learnskill 55 450 450";
    say(set);
    set=".character learnskill 54 450 450";
    say(set);
    set=".character learnskill 162 450 450";
    say(set);
    set=".character learnskill 136 450 450";
    say(set);
    set=".character learn 107";
    say(set);
    set=".character learn 264";
    say(set);
    set=".character learn 5011";
    say(set);
    set=".character learn 1180";
    say(set);
    set=".character learn 674";
    say(set);
    set=".character learn 15509";
    say(set);
    set=".character learn 266";
    say(set);
    set=".character learn 196";
    say(set);
    set=".character learn 198";
    say(set);
    set=".character learn 201";
    say(set);
    set=".character learn 3127";
    say(set);
    set=".character learn 200";
    say(set);
    set=".character learn 3018";
    say(set);
    set=".character learn 5019";
    say(set);
    set=".character learn 227";
    say(set);
    set=".character learn 2764";
    say(set);
    set=".character learn 2567";
    say(set);
    set=".character learn 197";
    say(set);
    set=".character learn 199";
    say(set);
    set=".character learn 202";
    say(set);
    set=".character learn 203";
    say(set);
    set=".character learn 5009";
    say(set);
end
---- Arena S4 Gear ----
function S4_Barrier()
	set=".char additem 34986";
	say(set);
end

function S4_Redoubt()
	set=".char additem 35073";
	say(set);
end

function S4_ShieldWall()
	set=".char additem 35094";
	say(set);
end
---- Season 4 Arena (Black Temple)----
function warriors4()
	set=".character additem 35066";
	say(set);
	set=".character additem 35067";
	say(set);
	set=".character additem 35068";
	say(set);
	set=".character additem 35069";
	say(set);
	set=".character additem 35070";
	say(set);
end

function warlocks4critgear()
set=".character additem 35009";
say(set);
set=".character additem 35010";
say(set);
set=".character additem 35011";
say(set);
set=".character additem 35012";
say(set);
set=".character additem 35013";
say(set);
end

function warlocks4affliction()
set=".character additem 35003";
say(set);
set=".character additem 35004";
say(set);
set=".character additem 35005";
say(set);
set=".character additem 35006";
say(set);
set=".character additem 35007";
say(set);
end

function shamans4resto()
set=".character additem 35077";
say(set);
set=".character additem 35078";
say(set);
set=".character additem 35079";
say(set);
set=".character additem 35080";
say(set);
set=".character additem 35081";
say(set);
end

function shamans4ele()
set=".character additem 35048";
say(set);
set=".character additem 35049";
say(set);
set=".character additem 35050";
say(set);
set=".character additem 35051";
say(set);
set=".character additem 35052";
say(set);
end

function shamans4enh()
set=".character additem 35042";
say(set);
set=".character additem 35043";
say(set);
set=".character additem 35044";
say(set);
set=".character additem 35045";
say(set);
set=".character additem 35046";
say(set);
end

function rogues4()
set=".character additem 35032";
say(set);
set=".character additem 35033";
say(set);
set=".character additem 35034";
say(set);
set=".character additem 35035";
say(set);
set=".character additem 35036";
say(set);
end

function priests4shadow()
set=".character additem 35083";
say(set);
set=".character additem 35084";
say(set);
set=".character additem 35085";
say(set);
set=".character additem 35086";
say(set);
set=".character additem 35087";
say(set);
end

function priests4holy()
set=".character additem 35053";
say(set);
set=".character additem 35054";
say(set);
set=".character additem 35055";
say(set);
set=".character additem 35056";
say(set);
set=".character additem 35057";
say(set);
end

function paladins4ret()
set=".character additem 35088";
say(set);
set=".character additem 35089";
say(set);
set=".character additem 35090";
say(set);
set=".character additem 35091";
say(set);
set=".character additem 35092";
say(set);
end

function paladins4holy()
set=".character additem 35059";
say(set);
set=".character additem 35060";
say(set);
set=".character additem 35061";
say(set);
set=".character additem 35062";
say(set);
set=".character additem 35063";
say(set);
end

function paladins4spelldps()
set=".character additem 35027";
say(set);
set=".character additem 35028";
say(set);
set=".character additem 35029";
say(set);
set=".character additem 35030";
say(set);
set=".character additem 35031";
say(set);
end

function mages4()
set=".character additem 35096";
say(set);
set=".character additem 35097";
say(set);
set=".character additem 35098";
say(set);
set=".character additem 35099";
say(set);
set=".character additem 35100";
say(set);
end

function hunters4()
set=".character additem 34990";
say(set);
set=".character additem 34991";
say(set);
set=".character additem 34992";
say(set);
set=".character additem 34993";
say(set);
set=".character additem 34994";
say(set);
end

function druids4balance()
set=".character additem 35111";
say(set);
set=".character additem 35112";
say(set);
set=".character additem 35113";
say(set);
set=".character additem 35114";
say(set);
set=".character additem 35115";
say(set);
end

function druids4feral()
set=".character additem 34998";
say(set);
set=".character additem 34999";
say(set);
set=".character additem 35000";
say(set);
set=".character additem 35001";
say(set);
set=".character additem 35002";
say(set);
end

function druids4resto()
set=".character additem 35022";
say(set);
set=".character additem 35023";
say(set);
set=".character additem 35024";
say(set);
set=".character additem 35025";
say(set);
set=".character additem 35026";
say(set);
end
---- S4 Weapons -----
---- Wand ----
function bgbatonoflight()
set=".character additem 34985";
say(set);
end

function bgpiercingtouch()
set=".character additem 35065";
say(set);
end

function bgtouchofdefeat()
set=".character additem 35107";
say(set);
end
---- 2h Sword ----
function bggreatsword()
set=".character additem 35015";
say(set);
end
---- 2h Mace ----
function bgbonegrinder()
set=".character additem 34989";
say(set);
end
---- 2h Axe ----
function bgdecapitator()
set=".character additem 34997";
say(set);
end
---- Thrown ----
function bgwaredge()
set=".character additem 35108";
say(set);
end
---- Staff ----
function bgbattlestaff()
set=".character additem 34987";
say(set);
end

function bgstaff()
set=".character additem 35103";
say(set);
end

function bgwarstaff()
set=".character additem 35109";
say(set);
end
---- 1h Sword ----
function bgquickblade()
set=".character additem 35072";
say(set);
end

function bgslicer()
set=".character additem 35101";
say(set);
end
---- Polearm ----
function bgpainsaw()
set=".character additem 35064";
say(set);
end
---- 1h Mace ----
function bgbonecracker()
set=".character additem 34988";
say(set);
end

function bggavel()
set=".character additem 35014";
say(set);
end

function bgpummeler()
set=".character additem 35071";
say(set);
end

function bgsalvation()
set=".character additem 35082";
say(set);
end

function bgswiftjudgement()
set=".character additem 37740";
say(set);
end
---- 1h Axe ----
function bgchopper()
set=".character additem 34995";
say(set);
end

function bgcleaver()
set=".character additem 34996";
say(set);
end

function bghacker()
set=".character additem 35017";
say(set);
end

function bghatchet()
set=".character additem 36737";
say(set);
end

function bgwaraxe()
set=".character additem 35110";
say(set);
end
---- Gun ----
function bgrifle()
set=".character additem 35075";
say(set);
end
---- Fist ----
function bgleftrender()
set=".character additem 35037";
say(set);
end

function bgleftripper()
set=".character additem 35038";
say(set);
end

function bgrightripper()
set=".character additem 35076";
say(set);
end
---- Dagger ----
function bgbladeofalacrity()
set=".character additem 37739";
say(set);
end

function bgmutilator()
set=".character additem 35058";
say(set);
end

function bgshanker()
set=".character additem 35093";
say(set);
end

function bgshiv()
set=".character additem 35095";
say(set);
end

function bgspellblade()
set=".character additem 35102";
say(set);
end
---- Crossbow ----
function bgheavycrossbow()
set=".character additem 35018";
say(set);
end
---- Bow ----
function bglongbow()
set=".character additem 35047";
say(set);
end
---- BT Legendary ----
function Andonisus()
set=".character additem 22736";
say(set);
end

function Ashbringer()
set=".character additem 13262";
say(set);
end

function CosmicInfuser()
set=".character additem 30317";
say(set);
end

function Devastation()
set=".character additem 30316";
say(set);
end

function InfinityBlade()
set=".character additem 30312";
say(set);
end

function Netherstrand()
set=".character additem 30318";
say(set);
end

function StaffOfD()
set=".character additem 30313";
say(set);
end

function Thoridal()
set=".character additem 34334";
say(set);
end

function Thunderfury()
set=".character additem 19019";
say(set);
end

function WarglaiveMH()
set=".character additem 32837";
say(set);
end

function WarglaiveOH()
set=".character additem 32838";
say(set);
end

function WarpSlicer()
set=".character additem 30311";
say(set);
end

function Phaseshift()
set=".character additem 30314";
say(set);
end

function Qiraji()
set=".character additem 21176";
say(set);
end
---- Heirloom Items ----
function BoneBow()
set=".character additem 42946";
say(set);
end

function Sunderseer()
set=".character additem 44107";
say(set);
end

function Dreadmist()
set=".character additem 42985";
say(set);
end

function Heartseeker()
set=".character additem 42944";
say(set);
end

function ScarletKris()
set=".character additem 44091";
say(set);
end

function HandCannon()
set=".character additem 44093";
say(set);
end

function Stormshroud()
set=".character additem 44103";
say(set);
end

function Feralheart()
set=".character additem 44105";
say(set);
end

function Ironfeather()
set=".character additem 42984";
say(set);
end

function Shadowcraft()
set=".character additem 42952";
say(set);
end

function FiveThunders()
set=".character additem 44102";
say(set);
end

function Herod()
set=".character additem 42950";
say(set);
end

function Elements()
set=".character additem 42951";
say(set);
end

function Beastmaster()
set=".character additem 44101";
say(set);
end

function Aurastone()
set=".character additem 42948";
say(set);
end

function HOfGrace()
set=".character additem 44094";
say(set);
end

function Thrash()
set=".character additem 44096";
say(set);
end

function SacredCharge()
set=".character additem 42945";
say(set);
end

function Valor()
set=".character additem 42949";
say(set);
end

function Lightforge()
set=".character additem 44100";
say(set);
end

function Stockade()
set=".character additem 44099";
say(set);
end

function Headmaster()
set=".character additem 42947";
say(set);
end

function Jordan()
set=".character additem 44095";
say(set);
end

function EyeOfBeast()
set=".character additem 42992";
say(set);
end

function InsAlly()
set=".character additem 44098";
say(set);
end

function InsHorde()
set=".character additem 44097";
say(set);
end

function HOJustice()
set=".character additem 42991";
say(set);
end

function Arcanite()
set=".character additem 42943";
say(set);
end

function Truesilver()
set=".character additem 44092";
say(set);
end

---- DK Starter ----

function Auto_Skills()
playerFaction = UnitFactionGroup("target")
playerClass = UnitClass("target")
playerLevel = UnitLevel("target")
	if playerFaction == "Horde" and playerClass == "Druid" then HordeDruid()
	end
	if playerFaction == "Horde" and playerClass == "Mage" then HordeMage()
	end
	if playerFaction == "Horde" and playerClass == "Hunter" then HordeHunter()
	end
	if playerFaction == "Horde" and playerClass == "Paladin" then HordePaladin()
	end
	if playerFaction == "Horde" and playerClass == "Priest" then HordePriest()
	end
	if playerFaction == "Horde" and playerClass == "Rogue" then HordeRogue()
	end
	if playerFaction == "Horde" and playerClass == "Shaman" then HordeShaman()
	end
	if playerFaction == "Horde" and playerClass == "Warlock" then HordeWarlock()
	end
	if playerFaction == "Horde" and playerClass == "Warrior" then HordeWarrior()
	end
	if playerFaction == "Alliance" and playerClass == "Druid" then AllyDruid()
	end
	if playerFaction == "Alliance" and playerClass == "Mage" then AllyMage()
	end
	if playerFaction == "Alliance" and playerClass == "Hunter" then AllyHunter()
	end
	if playerFaction == "Alliance" and playerClass == "Paladin" then AllyPaladin()
	end
	if playerFaction == "Alliance" and playerClass == "Priest" then AllyPriest()
	end
	if playerFaction == "Alliance" and playerClass == "Rogue" then AllyRogue()
	end
	if playerFaction == "Alliance" and playerClass == "Shaman" then AllyShaman()
	end
	if playerFaction == "Alliance" and playerClass == "Warlock" then AllyWarlock()
	end
	if playerFaction == "Alliance" and playerClass == "Warrior" then AllyWarrior()
	end
end
function HumanRacial()
set=".char learn 59752";
say(set);
end

function HordeDruid()
playerLevel = UnitLevel("target");
	if playerLevel >= 10 then
		set=".character learn 18960"; -- Moonglade, 10 --
		say(set);
		set=".character learn 6795"; -- Growl , 10 --
		say(set);
		set=".character learn 6807"; -- Maul, 10 --
		say(set);
		set=".character learn 5487"; -- Bear Form, 10 --
		say(set);
	end
	if playerLevel >= 67 then
		set=".character learn 26996"; -- Maul 8, 67 --
		say(set);
	end
	if playerLevel >= 70 then 
		set=".character learn 27047"; -- Growl 8, 70 --
		say(set);
	end
	if playerLevel >= 16 then --Druid Travel Form-
		set=".char learn 783";
		say(set);
	end 
	if playerLevel >= 40 then
		set=".character learn 9634"; -- Dire Bear, 40 --
		say(set);
	end
	if playerLevel >= 18 then 
		set=".character learn 6808"; -- Maul 2, 18 --
		say(set);
	end
	if playerLevel >= 26 then 
		set=".character learn 6809"; -- Maul 3, 26 --
		say(set);
	end
	if playerLevel >= 34 then 
		set=".character learn 8972"; -- Maul 4, 34 --
		say(set);
	end
	if playerLevel >= 42 then 
		set=".character learn 9745"; -- Maul 5, 42 --
		say(set);
	end
	if playerLevel >= 50 then 
		set=".character learn 9880"; -- Maul 6, 50 --
		say(set);
	end
	if playerLevel >= 58 then 
		set=".character learn 9881"; -- Maul 7, 58 --
		say(set);
	end
	if playerLevel >= 16 then 
		set=".character learn 1066"; -- Aquatic Form, 16 --
		say(set);
	end
	if playerLevel >= 60 then 
		set=".character learn 40120"; -- Swift Flight Form, 60 --
		say(set);
	end
end

function HordeHunter()
playerLevel = UnitLevel("target");
	if playerLevel >= 10 then
		set=".character learn 1515";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 5149";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 6991";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 2641";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 883";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 982";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 23355";
		say(set);
	end
end

function HordeMage()
playerLevel = UnitLevel("target");
	if playerLevel >= 20 then
		set=".character learn 3567";
		say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 35715";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 32272";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 3566";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 3563";
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 11417";
		say(set);
	end
	if playerLevel >= 65 then
		set=".character learn 35717";
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 32267";
		say(set);
	end
	if playerLevel >= 50 then
		set=".character learn 11420";
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 11418";
		say(set);
	end
	if playerLevel >= 70 then
		set=".character learn 38704";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 45438";
		say(set);
	end
	if playerLevel >= 70 then
		set=".character learn 43987";
		say(set);
	end
	--Portals--
if playerLevel >= 35 then
set=".char learn 49361"; --Stonard--
say(set);
end
if playerLevel >= 40 then
set=".char learn 11418"; --UC--
say(set);
end
if playerLevel >= 40 then
set=".char learn 32267"; --Silvermoon--
say(set);
end
if playerLevel >= 40 then
set=".char learn 11417"; --Orgrimmar--
say(set);
end
if playerLevel >= 50 then
set=".char learn 11420"; --Darnassus-
say(set);
end
if playerLevel >= 65 then
set=".char learn 35717"; --Shattrath--
say(set);
end
if playerLevel >= 74 then
set=".char learn 53142"; --Dalaran--
say(set);
end
--Teleports--
if playerLevel >= 20 then
set=".char learn 3567"; --Org--
say(set);
end 
if playerLevel >= 20 then
set=".char learn 32272"; --Silvermoon--
say(set);
end

if playerLevel >= 20 then
set=".char learn 3563"; --Undercity--
say(set);
end
if playerLevel >= 30 then
set=".char learn 3566"; --TB--
say(set);
end
if playerLevel >= 35 then
set=".char learn 49358"; --Stonard--
say(set);
end
if playerLevel >= 60 then
set=".char learn 33690"; --Shattrath--
say(set);
end
if playerLearn >= 71 then
set=".char learn 53140"; --Dalaran--
say(set);
end 
end

function HordePaladin()
playerLevel = UnitLevel("target");
	if playerLevel >= 12 then
		set=".character learn 7328";
		say(set);
	end
	if playerLevel >= 24 then
		set=".character learn 10322";
		say(set);
	end
	if playerLevel >= 36 then
		set=".character learn 10324";
		say(set);
	end
	if playerLevel >= 48 then
		set=".character learn 20772";
		say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 20773";
		say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 34767";
		say(set);
	end
	if playerLevel >= 20 then
	set=".char learn 34769";
	say(set);
	end
		if playerLevel >= 1 then --Seal of Martyr--
	set=".char unlearn 53720";
	say(set);
	end
	if playerLevel >= 1 then --Seal of Blood--
	set=".char unlearn 31892";
	say(set);
	end
	
	end

function HordePriest()
playerLevel = UnitLevel("target");
 if playerLevel >= 30 then
 set=".char learn 14752";
say(set);
end
end

function HordeRogue()
playerLevel = UnitLevel("target");
	if playerLevel >= 16 then
		set=".character learn 1804";
		say(set);
		set=".character learnskill 633 450 450";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 2842";
		say(set);
		set=".character learnskill 40 450 450";
		say(set);
	end
	if playerLevel >= 22 then
	set=".char learn 1856";
	say(set);
	end
	
	
end

function HordeShaman()
playerLevel = UnitLevel("target");
	if playerLevel >= 10 then
		set=".character learn 3599";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 6363";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 6364";
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 6365";
		say(set);
	end
	if playerLevel >= 50 then
		set=".character learn 10437";
		say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 10438";
		say(set);
	end
	if playerLevel >= 69 then
		set=".character learn 25533";
		say(set);
	end
	if playerLevel >= 4 then
		set=".character learn 8071";
		say(set);
	end
	if playerLevel >= 14 then
		set=".character learn 8154";
		say(set);
	end
	if playerLevel >= 24 then
		set=".character learn 8155";
		say(set);
	end
	if playerLevel >= 34 then
		set=".character learn 10406";
		say(set);
	end
	if playerLevel >= 44 then
		set=".character learn 10407";
		say(set);
	end
	if playerLevel >= 54 then
		set=".character learn 10408";
		say(set);
	end
	if playerLevel >= 63 then
		set=".character learn 25508";
		say(set);
	end
	if playerLevel >= 70 then
		set=".character learn 25509";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 5394";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 6375";
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 6377";
		say(set);
	end
	if playerLevel >= 50 then
		set=".character learn 10462";
		say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 10463";
		say(set);
	end
	if playerLevel >= 69 then
		set=".character learn 25567";
		say(set);
	end
	if playerLevel >= 70 then
		set=".character learn 2825";
		say(set);
	end
if playerLevel >= 16 then --Wolf form--
		set=".char learn 2645";
		say(set);
		end
	end 

function HordeWarlock()
playerLevel = UnitLevel("target");
	if playerLevel >= 1 then
		set=".character learn 688";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 697";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 712";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 691";
		say(set);
	end
	if playerLevel >= 20 then
	set=".char learn 5784"
	say(set);
	end
		if playerLevel >= 60 then
		set=".character learn 23161";
		say(set);
		set=".character learn 18540";
		say(set);
	end
end

function HordeWarrior()
playerLevel = UnitLevel("target");
	if playerLevel >= 10 then
		set=".character learn 71";
		say(set);
		set=".character learn 7386";
		say(set);
		set=".character learn 355";
		say(set);
	end
	if playerLevel >= 22 then
		set=".character learn 7405";
		say(set);
	end
	if playerLevel >= 22 then
		set=".character learn 8380";
		say(set);
	end
	if playerLevel >= 46 then
		set=".character learn 11596";
		say(set);
	end
	if playerLevel >= 58 then
		set=".character learn 11597";
		say(set);
	end
	if playerLevel >= 67 then
		set=".character learn 25225";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 2458";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 20252";
		say(set);
	end
	if playerLevel >= 42 then
		set=".character learn 20616";
		say(set);
	end
	if playerLevel >= 52 then
		set=".character learn 20617";
		say(set);
	end
	if playerLevel >= 61 then
		set=".character learn 25272";
		say(set);
	end
	if playerLevel >= 69 then
		set=".character learn 25275";
		say(set);
	end
end

function AllyDruid()
playerLevel = UnitLevel("target");
	if playerLevel >= 10 then
		set=".character learn 18960"; -- Moonglade, 10 --
		say(set);
		set=".character learn 6795"; -- Growl , 10 --
		say(set);
		set=".character learn 6807"; -- Maul, 10 --
		say(set);
		set=".character learn 5487"; -- Bear Form, 10 --
		say(set);
	end
	if playerLevel >= 67 then
		set=".character learn 26996"; -- Maul 8, 67 --
		say(set);
	end
	if playerLevel >= 70 then 
		set=".character learn 27047"; -- Growl 8, 70 --
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 9634"; -- Dire Bear, 40 --
		say(set);
	end
	if playerLevel >= 18 then 
		set=".character learn 6808"; -- Maul 2, 18 --
		say(set);
	end
	if playerLevel >= 16 then --Druid Travel Form-
		set=".char learn 783";
		say(set);
	end 
	if playerLevel >= 26 then 
		set=".character learn 6809"; -- Maul 3, 26 --
		say(set);
	end
	if playerLevel >= 34 then 
		set=".character learn 8972"; -- Maul 4, 34 --
		say(set);
	end
	if playerLevel >= 42 then 
		set=".character learn 9745"; -- Maul 5, 42 --
		say(set);
	end
	if playerLevel >= 50 then 
		set=".character learn 9880"; -- Maul 6, 50 --
		say(set);
	end
	if playerLevel >= 58 then 
		set=".character learn 9881"; -- Maul 7, 58 --
		say(set);
	end
	if playerLevel >= 16 then 
		set=".character learn 1066"; -- Aquatic Form, 16 --
		say(set);
	end
	if playerLevel >= 70 then 
		set=".character learn 40120"; -- Swift Flight Form, 70 --
		say(set);
	end
end

function AllyHunter()
playerLevel = UnitLevel("target");
	if playerLevel >= 10 then
		set=".character learn 1515";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 5149";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 6991";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 2641";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 883";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 982";
		say(set);
	end
	if playerLevel >= 81 then
		set=".character learn 23355";
		say(set);
	end
end

function AllyMage()
playerLevel = UnitLevel("target");
	if playerLevel >= 30 then
		set=".character learn 3565";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 32271";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 3562";
		say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 33690";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 3561";
		say(set);
	end
	if playerLevel >= 50 then
		set=".character learn 11419";
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 32266";
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 11416";
		say(set);
	end
	if playerLevel >= 65 then
		set=".character learn 33691";
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 10059";
		say(set);
	end
	if playerLevel >= 70 then
		set=".character learn 38704";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 45438";
		say(set);
	end
	if playerLevel >= 70 then
		set=".character learn 43987";
		say(set);
	end
--Portals--
if playerLevel >= 35 then
set=".char learn 49360"; --Theramore--
say(set);
end
if playerLevel >= 40 then
set=".char learn 10059"; --Stormwind--
say(set);
end
if playerLevel >= 40 then
set=".char learn 11416"; --Ironforge--
say(set);
end
if playerLevel >= 40 then
set=".char learn 32266"; --Exodar--
say(set);
end
if playerLevel >= 50 then
set=".char learn 11419"; --Darnassus-
say(set);
end
if playerLevel >= 65 then
set=".char learn 33691"; --Shattrath--
say(set);
end
if playerLevel >= 74 then
set=".char learn 53142"; --Dalaran--
say(set);
end
--Teleports--
if playerLevel >= 20 then
set=".char learn 32271"; --Exodar--
say(set);
end 
if playerLevel >= 20 then
set=".char learn 3562"; --Ironforge--
say(set);
end

if playerLevel >= 20 then
set=".char learn 3561"; --Stormwind--
say(set);
end
if playerLevel >= 30 then
set=".char learn 3565"; --Darnassus--
say(set);
end
if playerLevel >= 35 then
set=".char learn 49359"; --Theramore--
say(set);
end
if playerLevel >= 60 then
set=".char learn 33690"; --Shattrath--
say(set);
end
if playerLearn >= 71 then
set=".char learn 53140"; --Dalaran--
say(set);
end 
	end

function AllyPaladin()
playerLevel = UnitLevel("target");
	if playerLevel >= 12 then
		set=".character learn 7328";
		say(set);
	end
	if playerLevel >= 24 then
		set=".character learn 10322";
		say(set);
	end
	if playerLevel >= 36 then
		set=".character learn 10324";
		say(set);
	end
	if playerLevel >= 48 then
		set=".character learn 20772";
		say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 20773";
		say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 23214";
		say(set);
	end
	if playerLevel >= 64 then
		set=".character learn 31801";
		say(set);
	end
	if playerLevel >= 20 then
	set=".char learn 13819";
	say(set);
	end
	
	if playerLevel >= 1 then
	set=".char unlearn 53720";
	say(set);
	end
	if playerLevel >= 1 then
	set=".char unlearn 31892";
	say(set);
	end
end

function AllyPriest()
playerLevel = UnitLevel("target");
 if playerLevel >= 30 then
 set=".char learn 14752";
say(set);
end
end

function AllyRogue()
playerLevel = UnitLevel("target");
	if playerLevel >= 16 then
		set=".character learn 1804";
		say(set);
		set=".character learnskill 633 450 450";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 2842";
		say(set);
		set=".character learnskill 40 450 450";
		say(set);
	end
	
	if playerLevel >= 22 then
	set=".char learn 1856";
	say(set);
	end

end

function AllyShaman()
playerLevel = UnitLevel("target");
	if playerLevel >= 10 then
		set=".character learn 3599";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 6363";
		say(set);
	end
	if playerLevel >= 16 then --Wolf form--
		set=".char learn 2645";
		say(set);
		end
	if playerLevel >= 30 then
		set=".character learn 6364";
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 6365";
		say(set);
	end
	if playerLevel >= 50 then
		set=".character learn 10437";
		say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 10438";
		say(set);
	end
	if playerLevel >= 69 then
		set=".character learn 25533";
		say(set);
	end
	if playerLevel >= 4 then
		set=".character learn 8071";
		say(set);
	end
	if playerLevel >= 14 then
		set=".character learn 8154";
		say(set);
	end
	if playerLevel >= 24 then
		set=".character learn 8155";
		say(set);
	end
	if playerLevel >= 34 then
		set=".character learn 10406";
		say(set);
	end
	if playerLevel >= 44 then
		set=".character learn 10407";
		say(set);
	end
	if playerLevel >= 54 then
		set=".character learn 10408";
		say(set);
	end
	if playerLevel >= 63 then
		set=".character learn 25508";
		say(set);
	end
	if playerLevel >= 70 then
		set=".character learn 25509";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 5394";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 6375";
		say(set);
	end
	if playerLevel >= 40 then
		set=".character learn 6377";
		say(set);
	end
	if playerLevel >= 50 then
		set=".character learn 10462";
		say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 10463";
		say(set);
	end
	if playerLevel >= 69 then
		set=".character learn 25567";
		say(set);
	end
	if playerLevel >= 70 then
		set=".character learn 32182";
		say(set);
	end
end

function AllyWarlock()
	playerLevel = UnitLevel("target");
	if playerLevel >= 1 then
		set=".character learn 688";
		say(set);
	end
	if playerLevel >= 10 then
		set=".character learn 697";
		say(set);
	end
	if playerLevel >= 20 then
		set=".character learn 712";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 691";
		say(set);
	end
	if playerLevel >= 20 then
	set=".char learn 5784"
	say(set);
	end
	if playerLevel >= 60 then
		set=".character learn 23161";
		say(set);
		set=".character learn 18540";
		say(set);
	end
end

function AllyWarrior()
playerLevel = UnitLevel("target");
	if playerLevel >= 10 then
		set=".character learn 71";
		say(set);
		set=".character learn 7386";
		say(set);
		set=".character learn 355";
		say(set);
	end
	if playerLevel >= 22 then
		set=".character learn 7405";
		say(set);
	end
	if playerLevel >= 22 then
		set=".character learn 8380";
		say(set);
	end
	if playerLevel >= 46 then
		set=".character learn 11596";
		say(set);
	end
	if playerLevel >= 58 then
		set=".character learn 11597";
		say(set);
	end
	if playerLevel >= 67 then
		set=".character learn 25225";
		say(set);
	end
	if playerLevel >= 30 then
		set=".character learn 2458";
		say(set);
		set=".character learn 20252";
		say(set);
	end
	if playerLevel >= 42 then
		set=".character learn 20616";
		say(set);
	end
	if playerLevel >= 52 then
		set=".character learn 20617";
		say(set);
	end
	if playerLevel >= 61 then
		set=".character learn 25272";
		say(set);
	end
	if playerLevel >= 69 then
		set=".character learn 25275";
		say(set);
	end
	if playerLevel >= 80 then
	set=".char learn 55918";
	say(set);
	end 
end

function shamantotems()
	set=".character additem 5175";
	say(set);
	set=".character additem 5178";
	say(set);
	set=".character additem 5176";
	say(set);
	set=".character additem 5177";
	say(set);
end

function GM_Start()
gmStartName = UnitName("target")
	if gmStartName ~= gmName then UIErrorsFrame:AddMessage("You MUST target yourself for this to work! Please target yourself now and re-click GM Startup Button!", 1.0, 0.0, 0.0, 53, 2);
	end
	if gmStartName == gmName then 
		set=".cheat trigger";
		say(set);
		set=".cheat god";
		say(set);
		set=".cheat cast";
		say(set);
		set=".cheat cooldown";
		say(set);
		set=".inv";
		say(set);
		set=".mod speed 30";
		say(set);
		set=".cheat flyspeed 60";
		say(set);
		set=".mod faction 35";
		say(set);
		set=".cheat power";
		say(set);
		set=".mod mana 500000 500000";
		say(set);
		set=".mod energy 500000 500000";
		say(set);
		set=".mod runicpower 500000 500000";
		say(set);
        set=".gm list";
        say(set);
	end
end

function GM_Spell_Setup()
gmStartName = UnitName("target")
	if gmStartName ~= gmName then 
		UIErrorsFrame:AddMessage("You MUST target yourself for this to work! Please target yourself now and re-click GM Spell button!", 1.0, 0.0, 0.0, 53, 2);
	else
		set=".char learn 38505";
		say(set);
		set=".char learn 39258";
		say(set);
		set=".char learn 22856";
		say(set);
		set=".char learn 11027";
		say(set);
		set=".char learn 30839";
		say(set);
		set=".char learn 26666";
		say(set);
		set=".char learn 37940";
		say(set);
		set=".char learn 28337";
		say(set);
	end
end
-- Professions --
function profRiding()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 762 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	
	end
end

function profFish()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 356 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 7620";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profAid()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 129 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 3273";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profCook()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 185 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 2550";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profTailor()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 197 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 3908";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profSkin()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 393 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 8613";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profMining()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 186 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 2575";
	say(set);
	set=".character learn 2656";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profLeather()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 165 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 2108";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profJewel()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 755 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 25229";
	say(set);
	set=".character learn 31252";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profInscrip()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 773 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 45357";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profHerb()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 182 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 2366";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profEngin()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 202 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 4036";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profEnch()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 333 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 7411";
	say(set);
	set=".character learn 13262";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profBlack()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!", 1.0, 0.0, 0.0, 53, 2);
	else
	set=".character learnsk 164 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 2018";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

function profAlch()
	if profMin:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Minimum Skill Level please!");
	elseif profMax:GetText() == "" then
	UIErrorsFrame:AddMessage("Specify a Maximum Skill Level please!");
	else
	set=".character learnsk 171 "..profMin:GetText().." "..profMax:GetText();
	say(set);
	set=".character learn 2259";
	say(set);
	profMin:SetText("");
	profMax:SetText("");
	end
end

-- NEW ENTRIES TICKET TRACKER 3/2009 --

-- Retail T7 --

function DK_T7_Tank()
    set=".char additem 40559";
    say(set);
    set=".char additem 40563";
    say(set);
    set=".char additem 40565";
    say(set);
    set=".char additem 40567";
    say(set);
    set=".char additem 40568";
    say(set);
end

function DK_T7_DPS()
    set=".char additem 40550";
    say(set);
    set=".char additem 40552";
    say(set);
    set=".char additem 40554";
    say(set);
    set=".char additem 40556";
    say(set);
    set=".char additem 40557";
    say(set);
end

function BTHunterT7()
    set=".char additem 40503";
    say(set);
    set=".char additem 40504";
    say(set);
    set=".char additem 40505";
    say(set);
    set=".char additem 40506";
    say(set);
    set=".char additem 40507";
    say(set);
end

function BTMageT7()
    set=".char additem 40415";
    say(set);
    set=".char additem 40416";
    say(set);
    set=".char additem 40417";
    say(set);
    set=".char additem 40418";
    say(set);
    set=".char additem 40419";
    say(set);
end

function BTDruidT7Feral()
    set=".char additem 40471";
    say(set);
    set=".char additem 40472";
    say(set);
    set=".char additem 40473";
    say(set);
    set=".char additem 40493";
    say(set);
    set=".char additem 40494";
    say(set);
end

function BTDruidT7Healing()
    set=".char additem 40460";
    say(set);
    set=".char additem 40461";
    say(set);
    set=".char additem 40462";
    say(set);
    set=".char additem 40463";
    say(set);
    set=".char additem 40465";
    say(set);
end

function BTDruidT7SpellDPS()
    set=".char additem 40466";
    say(set);
    set=".char additem 40467";
    say(set);
    set=".char additem 40468";
    say(set);
    set=".char additem 40469";
    say(set);
    set=".char additem 40470";
    say(set);
end

function DeathKnightFT8()
	set=".char additem 10002022";
	say(set);
	set=".char additem 10002023";
	say(set);
	set=".char additem 10002024";
	say(set);
	set=".char additem 10002025";
	say(set);
	set=".char additem 10002026";
	say(set);
	set=".char additem 10002027";
	say(set);
	set=".char additem 10002028";
	say(set);
	set=".char additem 10002029";
	say(set);
end

function HunterFT8()
	set=".char additem 10002013";
	say(set);
	set=".char additem 10002014";
	say(set);
	set=".char additem 10002015";
	say(set);
	set=".char additem 10002016";
	say(set);
	set=".char additem 10002017";
	say(set);
	set=".char additem 10002018";
	say(set);
	set=".char additem 10002019";
	say(set);
	set=".char additem 10002020";
	say(set);
end

function PaladinFT8()
	set=".char additem 10002005";
	say(set);
	set=".char additem 10002006";
	say(set);
	set=".char additem 10002007";
	say(set);
	set=".char additem 10002008";
	say(set);
	set=".char additem 10002009";
	say(set);
	set=".char additem 10002010";
	say(set);
	set=".char additem 10002011";
	say(set);
	set=".char additem 10002012";
	say(set);
	end
	
function RogueFT8()
	set=".char additem 10002030";
	say(set);
	set=".char additem 10002031";
	say(set);
	set=".char additem 10002032";
	say(set);
	set=".char additem 10002033";
	say(set);
	set=".char additem 10002034";
	say(set);
	set=".char additem 10002035";
	say(set);
	set=".char additem 10002036";
	say(set);
	set=".char additem 10002037";
	say(set);
end

function WarriorFT8()
	set=".char additem 10002039";
	say(set);
	set=".char additem 10002040";
	say(set);
	set=".char additem 10002041";
	say(set);
	set=".char additem 10002042";
	say(set);
	set=".char additem 10002043";
	say(set);
	set=".char additem 10002044";
	say(set);
	set=".char additem 10002045";
	say(set);
	set=".char additem 10002046";
	say(set);
end

function MeleeSet()
	set=".char additem 10010200";
	say(set);
	set=".char additem 10010201";
	say(set);
	set=".char additem 10010202";
	say(set);
	set=".char additem 10010203";
	say(set);
	set=".char additem 10010204";
	say(set);
	set=".char additem 10010205";
	say(set);
	set=".char additem 10010206";
	say(set);
	set=".char additem 10010207";
	say(set);
end

function NexusMachineGun()
	set=".char additem 10002038";
	say(set);
end

function StolenTimeMH()
	set=".char additem 10042010";
	say(set);
	set=".character learn 674"
	say(set);
	set=".character learnskill 43 350 350"
	say(set);
	set=".character learn 201";
	say(set);
end

function StolenTimeOH()
	set=".char additem 10042011";
	say(set);
	set=".character learn 674"
	say(set);
	set=".character learnskill 43 350 350"
	say(set);
	set=".character learn 201";
	say(set);
end

function TheFrostmourne()
	set=".char additem 117137";
	say(set);
end

--DK*


function dkt825damage()
   set=".char additem 46111";
   say(set);
   set=".char additem 46113";
   say(set);
   set=".char additem 46115";
   say(set);
   set=".char additem 46116";
   say(set);
   set=".char additem 46117";
   say(set);
end


function dkt825tank()
   set=".char additem 46118";
   say(set);
   set=".char additem 46119";
   say(set);
   set=".char additem 46120";
   say(set);
   set=".char additem 46121";
   say(set);
   set=".char additem 46122";
   say(set);
end

--DRUID*

function druidt825feral()
   set=".char additem 46157";
   say(set);
   set=".char additem 46158";
   say(set);
   set=".char additem 46159";
   say(set);
   set=".char additem 46160";
   say(set);
   set=".char additem 46161";
   say(set);
end


function druidt825balance()
   set=".char additem 46189";
   say(set);
   set=".char additem 46191";
   say(set);
   set=".char additem 46192";
   say(set);
   set=".char additem 46194";
   say(set);
   set=".char additem 46196";
   say(set);
end

function druidt825restore()
   set=".char additem 46183";
   say(set);
   set=".char additem 46184";
   say(set);
   set=".char additem 46185";
   say(set);
   set=".char additem 46186";
   say(set);
   set=".char additem 46187";
   say(set);
end

function HellfireMace()
	set=".char additem 10002021";
	say(set);
end

function FragmentDagger()
	set=".char additem 10042012";
	say(set);
end

function DruidFT8()
	set=".char additem 100021";
	say(set);
	set=".char additem 100022";
	say(set);
	set=".char additem 100023";
	say(set);
	set=".char additem 100024";
	say(set);
	set=".char additem 100025";
	say(set);
	set=".char additem 100026";
	say(set);
	set=".char additem 100027";
	say(set);
	set=".char additem 100132";
	say(set);
end

function WarlockFT8()
	set=".char additem 100028";
	say(set);
	set=".char additem 100029";
	say(set);
	set=".char additem 100030";
	say(set);
	set=".char additem 100031";
	say(set);
	set=".char additem 100032";
	say(set);
	set=".char additem 100033";
	say(set);
	set=".char additem 100034";
	say(set);
	set=".char additem 100133";
	say(set);
end

function PriestFT8()
	set=".char additem 100035";
	say(set);
	set=".char additem 100036";
	say(set);
	set=".char additem 100037";
	say(set);
	set=".char additem 100038";
	say(set);
	set=".char additem 100039";
	say(set);
	set=".char additem 100040";
	say(set);
	set=".char additem 100041";
	say(set);
	set=".char additem 100131";
	say(set);
end

function ShamanFT8()
	set=".char additem 100042";
	say(set);
	set=".char additem 100043";
	say(set);
	set=".char additem 100044";
	say(set);
	set=".char additem 100045";
	say(set);
	set=".char additem 100046";
	say(set);
	set=".char additem 100047";
	say(set);
	set=".char additem 100048";
	say(set);
	set=".char additem 100130";
	say(set);
end

function MageFT8()
	set=".char additem 100049";
	say(set);
	set=".char additem 100050";
	say(set);
	set=".char additem 100051";
	say(set);
	set=".char additem 100052";
	say(set);
	set=".char additem 100053";
	say(set);
	set=".char additem 100054";
	say(set);
	set=".char additem 100055";
	say(set);
	set=".char additem 100134";
	say(set);
end

function PaladinFT9()
	set=".char additem 100060";
	say(set);
	set=".char additem 100061";
	say(set);
	set=".char additem 100062";
	say(set);
	set=".char additem 100063";
	say(set);
	set=".char additem 100064";
	say(set);
	set=".char additem 100065";
	say(set);
	set=".char additem 100066";
	say(set);
	set=".char additem 100140";
	say(set);
end

function PriestFT9()
	set=".char additem 100116";
	say(set);
	set=".char additem 100117";
	say(set);
	set=".char additem 100118";
	say(set);
	set=".char additem 100119";
	say(set);
	set=".char additem 100120";
	say(set);
	set=".char additem 100121";
	say(set);
	set=".char additem 100122";
	say(set);
	set=".char additem 100136";
	say(set);
end

function ShamanFT9()
	set=".char additem 100123";
	say(set);
	set=".char additem 100124";
	say(set);
	set=".char additem 100125";
	say(set);
	set=".char additem 100126";
	say(set);
	set=".char additem 100127";
	say(set);
	set=".char additem 100128";
	say(set);
	set=".char additem 100129";
	say(set);
	set=".char additem 100135";
	say(set);
end
	
function DeathKnightFT9()
	set=".char additem 100081";
	say(set);
	set=".char additem 100082";
	say(set);
	set=".char additem 100083";
	say(set);
	set=".char additem 100084";
	say(set);
	set=".char additem 100085";
	say(set);
	set=".char additem 100086";
	say(set);
	set=".char additem 100087";
	say(set);
	set=".char additem 100142";
	say(set);
end

function MageFT9()
	set=".char additem 100109";
	say(set);
	set=".char additem 100110";
	say(set);
	set=".char additem 100111";
	say(set);
	set=".char additem 100112";
	say(set);
	set=".char additem 100113";
	say(set);
	set=".char additem 100114";
	say(set);
	set=".char additem 100115";
	say(set);
	set=".char additem 100139";
	say(set);
end

function DruidFT9()
	set=".char additem 100095";
	say(set);
	set=".char additem 100096";
	say(set);
	set=".char additem 100097";
	say(set);
	set=".char additem 100098";
	say(set);
	set=".char additem 100099";
	say(set);
	set=".char additem 100100";
	say(set);
	set=".char additem 100101";
	say(set);
	set=".char additem 100137";
	say(set);
end

function WarlockFT9()
	set=".char additem 100102";
	say(set);
	set=".char additem 100103";
	say(set);
	set=".char additem 100104";
	say(set);
	set=".char additem 100105";
	say(set);
	set=".char additem 100106";
	say(set);
	set=".char additem 100107";
	say(set);
	set=".char additem 100108";
	say(set);
	set=".char additem 100138";
	say(set);
end

function HunterFT9()
	set=".char additem 100088";
	say(set);
	set=".char additem 100089";
	say(set);
	set=".char additem 100090";
	say(set);
	set=".char additem 100091";
	say(set);
	set=".char additem 100092";
	say(set);
	set=".char additem 100093";
	say(set);
	set=".char additem 100094";
	say(set);
	set=".char additem 100144";
	say(set);
end

function RogueFT9()
	set=".char additem 100074";
	say(set);
	set=".char additem 100075";
	say(set);
	set=".char additem 100076";
	say(set);
	set=".char additem 100077";
	say(set);
	set=".char additem 100078";
	say(set);
	set=".char additem 100079";
	say(set);
	set=".char additem 100080";
	say(set);
	set=".char additem 100143";
	say(set);
end

function WarriorFT9()
	set=".char additem 100067";
	say(set);
	set=".char additem 100068";
	say(set);
	set=".char additem 100069";
	say(set);
	set=".char additem 100070";
	say(set);
	set=".char additem 100071";
	say(set);
	set=".char additem 100072";
	say(set);
	set=".char additem 100073";
	say(set);
	set=".char additem 100141";
	say(set);
end

---December 4 2009--- Coding By Panzertoter
---wotlk neutral factions----

function EbonBlade()
    set=".Char SetStanding 1098 32999";
    say(set);
    end
function KirinTor()
    set=".char setstanding 1090 32999";
    say(set);
    end
function Oracles()
    set=".char setstanding 1105 32999";
    say(set);
    end
function frenzyheart()
    set=".char setstanding 1104 32999";
    say(set);
    end
function ArgentCrusade()
    set=".char setstanding 1106 32999";
    say(set);
    end
function WyrmrestAccord()
    set=".char setstanding 1091 32999";
    say(set);
    end
function Kaluak()
    set=".char setstanding 1073 32999";
    say(set);
    end
function SonsofHodir()
    set=".char setstanding 1119 32999";
    say(set);
    end
    
-----woltk alliance factions----
function AllianceVanguard()
    set=".char setstanding 1037 32999";
    say(set);
end
 
function ExplorersLeague()
    set=".char setstanding 1068 32999";
    say(set);
end
 
function Frostborn()
    set=".char setstanding 1126 32999";
    say(set);
end
 
function SilverCovenant()
    set=".char setstanding 1094 32999";
    say(set);
end
 
function ValianceExpedition()
    set=".char setstanding 1050 32999";
    say(set);
end  
 

---Events---

----This spells may change from time to time----

--Shock n' Run--

function ShockandRun()
gmStartName = UnitName("target")
	if gmStartName ~= gmName then UIErrorsFrame:AddMessage("You MUST target yourself for this to work! Please target yourself now and try again.", 1.0, 0.0, 0.0, 53, 2);
	end
	if gmStartName == gmName then 

set=".char learn 49271";
say(set);
set=".char learn 39580";
say(set);
set=".cheat stack";
say(set);
set=".cheat power";
say(set);
set=".char learn 47893";
say(set);
set=".cheat cast";
say(set);
set=".invisible";
say(set);
end
end

function dodgeball()
gmStartName = UnitName("target")
	if gmStartName ~= gmName then UIErrorsFrame:AddMessage("You MUST target yourself for this to work! Please target yourself now and try again.", 1.0, 0.0, 0.0, 53, 2);
	end
	if gmStartName == gmName then 
set=".invisible";
say(set);
set=".char learn 24340";
say(set);
end

end
function paintball()
set=".char learn 36246"
say(set);
set=".mod hp 10000 10000"
say(set);
set=".mod displayid 29348"
say(set);
set=".cheat cast"
say(set);
set=".cheat power"
say(set);
set=".cheat cooldown"
end
function PvP()
set=".a A PvP event is about to start! It might be from FFA to 3v3!" 
say(set);
set=".a Depending on how many people we get, get your teams ready just in case";
say(set);
end
----Event Rules---

function R_Shock()
set="In shock and run you'll have to run and avoid the lightning clouds!, last man standing wins the round";
say(set);
set="Rules are:";
say(set);
set="No PvP, no mounts, no speed buffs, no buffs, no spells, no healing, no flaming/bashing during and after the event";
say(set);
set="Have fun and good luck!";
say(set);
end

function R_PvP()
set="Rules are:";
say(set);
set="No PvP, no mounts, no speed buffs, no external buffs,no flaming/bashing during and after the event, NO PVP OUTSIDE OF THE ARENA";
say(set);
set="If you don't follow the rules, it will result in a 2h - 2d ban";
say(set);
set="Have fun and goodluck everyone!";
say(set);
end
function R_Dodgeball()
set="In Dodgeball you'll have to dodge huge meteors falling from the sky, last man standing wins the round!";
say(set);
set="No PvP, no mounts, no speed buffs, no buffs, no spells, no healing, no flaming/bashing during and after the event";
say(set);
end

function R_Paint()
set="In Paintball you'll have to kill each other with the spells we just gave you, last man standing wins the round";
say(set);
set="No Bashing, no flaming, no healing, no buffs"
say(set);
set="Have fun and goodluck everyone!"
say(set);
end
function R_Hide()
set="In hide and seek one of the GM's is going to hide and you'll have to find them! The person that finds them wins the first prize.";
say(set);
set="No PvP, no mounts, no speed buffs, no buffs, no spells, no healing, no flaming/bashing during and after the event";
say(set);
end

-----------Season 7---------
function BTPriestHolyS7()
set=".char additem 41855"
say(set);
set=".char additem 41870"
say(set);
set=".char additem 41860"
say(set);
set=".char additem 41875"
say(set);
set=".char additem 41865"
say(set);
end

function BTPriestShadowS7()
set=".char additem 41916"
say(set);
set=".char additem 41935"
say(set);
set=".char additem 41922"
say(set);
set=".char additem 41941"
say(set);
set=".char additem 41928"
say(set);
end
function BTPaladinHolyS7()

set=".char additem 40934"
say(set);
set=".char additem 40964"
say(set);
set=".char additem 40910"
say(set);
set=".char additem 40928"
say(set);
set=".char additem 40940"
say(set);
end

function BTPaladinRetS7()
set=".char additem 40831"
say(set);
set=".char additem 40872"
say(set);
set=".char additem 40792"
say(set);
set=".char additem 40812"
say(set);
set=".char additem 40852"
say(set);
end
function BTWarriorS7()

set=".char additem 40829"
say(set);
set=".char additem 40870"
say(set);
set=".char additem 40790"
say(set);
set=".char additem 40810"
say(set);
set=".char additem 40850"
say(set);
end

function BTWarlockS7()

set=".char additem 41994"
say(set);
set=".char additem 42012"
say(set);
set=".char additem 41999"
say(set);
set=".char additem 42018"
say(set);
set=".char additem 42006"
end

function BTHunterS7()
set=".char additem 41158"
say(set);
set=".char additem 41218"
say(set);
set=".char additem 41088"
say(set);
set=".char additem 41144"
say(set);
set=".char additem 41206"
say(set);
end

function BTRoguesS7()
set=".char additem 41673"
say(set);
set=".char additem 41684"
say(set);
set=".char additem 41651"
say(set);
set=".char additem 41768"
say(set);
set=".char additem 41656"
say(set);
end

function BTMageS7()
set=".char additem 41947"
say(set);
set=".char additem 41966"
say(set);
set=".char additem 41947"
say(set);
set=".char additem 41972"
say(set);
set=".char additem 41960"
say(set);
end
function BTDKS7()

set=".char additem 40830"
say(set);
set=".char additem 40871"
say(set);
set=".char additem 40791"
say(set);
set=".char additem 40811"
say(set);
set=".char additem 40851"
say(set);
end

function BTShamanRestoS7()
set=".char additem 41014"
say(set);
set=".char additem 41039"
say(set);
set=".char additem 41045"
say(set);
set=".char additem 41002"
say(set);
set=".char additem 41028"
say(set);
end
function BTShamanEnhS7()

set=".char additem 41152"
say(set);
set=".char additem 41212"
say(set);
set=".char additem 41082"
say(set);
set=".char additem 41138"
say(set);
set=".char additem 41200"
say(set);
end
function BTShamanEleS7()
set=".char additem 41020"
say(set);
set=".char additem 41039"
say(set);
set=".char additem 40995"
say(set);
set=".char additem 41008"
say(set);
set=".char additem 41034"
say(set);
end

function BTDruidRestoS7()
set=".char additem 41322"
say(set);
set=".char additem 41276"
say(set);
set=".char additem 41311"
say(set);
set=".char additem 41288"
say(set);
set=".char additem 41299"
say(set);
end

function BTDruidBalanS7()
set=".char additem 41328"
say(set);
set=".char additem 41282"
say(set);
set=".char additem 41317"
say(set);
set=".char additem 41294"
say(set);
set=".char additem 41305"
say(set);
end

function BTDruidFeralS7()
set=".char additem 41679" 
say(set);
set=".char additem 41716"
say(set);
set=".char additem 41662"
say(set);
set=".char additem 41774"
say(set);
set=".char additem 41668"
say(set);
end

--Nexus Caster Boosters--
function CasterPower()
set=".chara additem 161414 2" --(Caster power booster)
say(set);
end
function MagePower()
set=".chara additem 161413 2" --(Mage power booster)
say(set);
end 

--T10--

function DK_T10_Tank()
set=".char additem 51305"
say(set);
set=".char additem 51306"
say(set);
set=".char additem 51307"
say(set);
set=".char additem 51308"
say(set);
set=".char additem 51309"
say(set);
end

function DK_T10_DPS()
set=".char additem 51310"
say(set);
set=".char additem 51311"
say(set);
set=".char additem 51312"
say(set);
set=".char additem 51313"
say(set);
set=".char additem 51314"
say(set);
end

function BTPaladinHolyT10()
set=".char additem 51270"
say(set);
set=".char additem 51271"
say(set);
set=".char additem 51272"
say(set);
set=".char additem 51273"
say(set);
set=".char additem 51274"
say(set);
end

function BTPaladinRetT10()
set=".char additem 51275"
say(set);
set=".char additem 51276"
say(set);
set=".char additem 51277"
say(set);
set=".char additem 51278"
say(set);
set=".char additem 51279"
say(set);
end

function BTPaladinProtT10()
set=".char additem 51265"
say(set);
set=".char additem 51266"
say(set);
set=".char additem 51267"
say(set);
set=".char additem 51268"
say(set);
set=".char additem 51269"
say(set);
end

function Druid_Feral_T10()
set=".char additem 51295"
say(set);
set=".char additem 51296"
say(set);
set=".char additem 51297"
say(set);
set=".char additem 51298"
say(set);
set=".char additem 51299"
say(set);
end

function Druid_Resto_T10()
set=".char additem 51300"
say(set);
set=".char additem 51301"
say(set);
set=".char additem 51302"
say(set);
set=".char additem 51303"
say(set);
set=".char additem 51304"
say(set);
end

function Druid_DPS_T10()
set=".char additem 51290"
say(set);
set=".char additem 51291"
say(set);
set=".char additem 51292"
say(set);
set=".char additem 51293"
say(set);
set=".char additem 51294"
say(set);
end

function BT_Hunter_T10()
set=".char additem 51285"
say(set);
set=".char additem 51286"
say(set);
set=".char additem 51287"
say(set);
set=".char additem 51288"
say(set);
set=".char additem 51289"
say(set);
end

function BT_Mage_T10()
set=".char additem 51280"
say(set);
set=".char additem 51281"
say(set);
set=".char additem 51282"
say(set);
set=".char additem 51283"
say(set);
set=".char additem 51284"
say(set);
end

function BT_Priest_Holy_T10()
set=".char additem 51260"
say(set);
set=".char additem 51261"
say(set);
set=".char additem 51262"
say(set);
set=".char additem 51263"
say(set);
set=".char additem 51264"
say(set);
end

function BT_Priest_DPS_T10()
set=".char additem 51255"
say(set);
set=".char additem 51256"
say(set);
set=".char additem 51257"
say(set);
set=".char additem 51258"
say(set);
set=".char additem 51259"
say(set);
end

function RogueT10()
set=".char additem 51250"
say(set);
set=".char additem 51251"
say(set);
set=".char additem 51252"
say(set);
set=".char additem 51253"
say(set);
set=".char additem 51254"
say(set);
end



function Shaman_Ele_T10()
set=".char additem 51235"
say(set);
set=".char additem 51236"
say(set);
set=".char additem 51237"
say(set);
set=".char additem 51238"
say(set);
set=".char additem 51239"
say(set);
end

function Shaman_Resto_T10()
set=".char additem 51245"
say(set);
set=".char additem 51246"
say(set);
set=".char additem 51247"
say(set);
set=".char additem 51248"
say(set);
set=".char additem 51249"
say(set);
end

function Shaman_Enh_T10()
set=".char additem 51240"
say(set);
set=".char additem 51241"
say(set);
set=".char additem 51242"
say(set);
set=".char additem 51243"
say(set);
set=".char additem 51244"
say(set);
end

function BT_Warlock_T10()
set=".char additem 51230"
say(set);
set=".char additem 51231"
say(set);
set=".char additem 51232"
say(set);
set=".char additem 51233"
say(set);
set=".char additem 51234"
say(set);
end

function BT_Warrior_DPS_T10()
set=".char additem 51225"
say(set);
set=".char additem 51226"
say(set);
set=".char additem 51227"
say(set);
set=".char additem 51228"
say(set);
set=".char additem 51229"
say(set);
end

function BT_Warrior_Prot_T10()
set=".char additem 51220"
say(set);
set=".char additem 51221"
say(set);
set=".char additem 51222"
say(set);
set=".char additem 51223"
say(set);
set=".char additem 51224"
say(set);
end