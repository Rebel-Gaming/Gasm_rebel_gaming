if GetLocale() ~= "deDE" then
	return
end

local L = BUYEMALL_LOCALS

-- Thanks to JokerGermany
-- L.MAX 		= "Max"
-- L.STACK 		= "Stack"
L.CONFIRM = "Bist du sicher das du\n %d � %s kaufen willst?"
-- L.STACK_PURCH	= "Stack Purchase"
L.STACK_SIZE = "Stack gr��e"
-- L.PARTIAL 	= "Partial stack"
L.MAX_PURCH = "Gr��t m�glcher Einkauf"
L.FIT = "Du hast Platz f�r"
L.AFFORD = "Du kannst dir leisten"
L.AVAILABLE = "Der Verk�ufer hat"
