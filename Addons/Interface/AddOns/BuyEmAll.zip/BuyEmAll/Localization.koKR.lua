if GetLocale() ~= "koKR" then
	return
end

local L = BUYEMALL_LOCALS

-- Thanks to sayclub
L.MAX 			= "최대"
L.STACK 		= "세트"
L.CONFIRM 		= "정말로 당신은 다음과 같이 구매를 희망하십니까?\n[%d 개 × %s 아이템]"
L.STACK_PURCH	= "세트 구입"
L.STACK_SIZE 	= "세트 수량"
L.PARTIAL 		= "부분 세트 구입"
L.MAX_PURCH		= "최고 구입"
L.FIT			= "구입 가능 수량"
L.AFFORD		= "현재 자산으로 구입 가능 수량"
L.AVAILABLE		= "최대 판매 수량"
