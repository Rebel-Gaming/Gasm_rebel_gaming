Elo = { }
ElDat = { }
ElZones = ElZones or {
		["Orgrimmar"] = { "[oO]rgrimmar", "City", },
		["Ironforge"] = { "[iI]ronforge", "City", },
		["Undercity"] = { "[uU]ndercity", "City", },
		["Thunder Bluff"] = { "[tT]hunder[%s%p]*[bB]luff", "City", },
		["Darnassus"] = { "[dD]arnassus", "City", },
		["Stormwind City"] = { "[sS]tormwind[%s%p]*City", "City", },
		["Shattrath City"] = { "[sS]hattrath[%s%p]*City", "City", },
		["Stormwind"] = { "[sS]torm[%s%p]*[wW]ind", "City", },
		["Shattrath"] = { "[sS]hattrath", "City", },
		["Dalaran"] = { "[dD]alaran", "City", },
		["Silvermoon City"] = { "[sS]ilvermoon[%s%p]*City", "City", },




	}
Elo.List = {
	["Friends"] = { },
	["Guild"] = { },
	}
Elo.Race = { }
Elo.Srv = GetRealmName()
local trim = string.trim
local concat = strconcat

local c
function Elo.gsub(msg,before,after,limit,level)
	msg,c = gsub(msg,before,after,limit)
	if EloOutputFrame and (EloConfig.FeedbackMode == 1 or EloOutputFrame:IsShown()) then
		local tmsg = trim(msg)
		local speaker = arg2
		if tmsg ~= Elo.LastDebMessage then
			Elo.LastDebMessage = tmsg
			if speaker and speaker ~= Elo.LastDebugSpeaker then
--				if speaker == "" then speaker = Elo.Event end
				tmsg = concat(Elo.Hue.green,Elo.Event,"|r\n",speaker,"|r: ",Elo.Hue.yellow,tmsg)
			else
				if level then level = concat("|r (",Elo.Hue.green,level,"|r)")
				else level = ""
				end
				tmsg = concat(Elo.Hue.grey,before,level,"|r\n",tmsg)
			end
			tmsg = gsub(tmsg,"%f[%d](%d%d?)(@%a+)",Elo.Hue.orange.."%1|r%2")
			EloChatFrame:AddMessage(tmsg)
		end
		if speaker then Elo.LastDebugSpeaker = speaker end
	end
	return msg,c
end
---------------------------------------------------------------------
-- Identifying Info
---------------------------------------------------------------------
Elo.Info	=	{
	name			=	"Eloquence",
	description	=	"Imbue chat with clarity and personality using a selection of filters.",
	version		=	" 3",
	releaseDate	=	"June 23, 2007",
	author		=	"Marr",
	category		=	MYADDONS_CATEGORY_CHAT,
	optionsframe	=	"EloOptions"
};
---------------------------------------------------------------------
-- Help Text
---------------------------------------------------------------------
local e = "\n|c00ffffff/elo|cffffff00 "
Elo.Help	=	{
[1]	=	e.." - Summon Eloquence's |cffff6d00options window.\n"..
		"|c00ffffff/elo|cffffff00 on/off/toggle|c00ffffff - Turn on/off/toggle master switch.\n"..

		"|c00ffffff/elo|cff0070dd misc|c00ffffff - View miscellaneous slash-only commands.",

[2]	=	
		"|c00ffffffCustom Filters:|cffffff00\n"..
		e.."add (before) = (after)|r - Add a new custom filter set."..
		e.."del (before)|r - Delete the custom set starting with (before)."..
		e.."list|r - View the list of custom filter sets.\n"..
		"\n|c00ffffffSuppress Annoying Players/NPCs:|cffffff00\n"..
		e.."suppress (X)|r - Suppress all chat and emotes from X."..
		e.."suppress clear|r - Clear the suppression list."..
		e.."suppress|r - View the list of suppressed characters.\n"..
		"\n|c00ffffffSkip Filtering Certain Channels:|cffffff00\n"..
		e.."channel (Y)|r - Stop filtering the custom channel Y."..
		e.."channel clear|r - Clear the channel list."..
		e.."channel|r - View the list of skipped channels.\n"..
		"\n|c00ffffffSkip Filtering Certain Players:|cffffff00\n"..
		e.."comrades add | remove|r - Add/remove all of your\nguildmates and friends to/from the skipped players list."..
		e.."skip (Z)|r - Stop filtering any chat from player Z."..
		e.."skip clear|r - Clear the skipped players list."..
		e.."skip|r - View the list of skipped players.\n"..
		e.."skipword (W)|r - Stop filtering any message that contains (W).",

--[
[3]	=	"|c00ffffff/elo|cffffff00 colors|c00ffffff - Cycle styles for colorization of known player names based on class.\n"..
		"|c00ffffff/elo|cffffff00 random|c00ffffff - Toggle random colors for players whose classes are unknown.\n"..
		"|c00ffffff/elo|cffffff00 header|c00ffffff - Cycle display modes of channel headers.\n"..
		"|c00ffffff/elo|cffffff00 link|c00ffffff - Cycle through three link styles. Messages that contain item links cannot be linked.\n"..
		"|c00ffffff/elo|cffffff00 max|c00ffffff - Enter the maximum no. of characters per line before it is trimmed.\n"..
		"|c00ffffff/elo|cffffff00 spam|c00ffffff - Toggle suppression of repeat messages by others.\n"..
		"|c00ffffff/elo|cffffff00 duel|c00ffffff - Toggle suppression of duel spam.\n"..
		"|c00ffffff/elo|cffffff00 coin|c00ffffff - Toggle suppression of party coin spam.\n"..
		"|c00ffffff/elo|cffffff00 join|c00ffffff - Toggle suppression of channel leave/join messages.\n"..
		"|c00ffffff/elo|cffffff00 ranks|c00ffffff - Toggle suppression of PvP ranks in Defense channels.\n"..
		"|c00ffffff/elo|cffffff00 chuck|c00ffffff - Toggle suppression of chat that mentions action heroes.\n"..
		"|c00ffffff/elo|cffffff00 bracket|c00ffffff - Toggle display of brackets around channels, players, items, etc.\n"..
		"|c00ffffff/elo|cffffff00 splash|c00ffffff - Toggle Eloquence's splash message.",
--]
};

BINDING_HEADER_Eloquence = "Eloquence";
BINDING_NAME_EloquenceOptions = "Toggle Eloquence Options";

function Elo.ChatFrameSetup()
	if (not EloChatFrame:GetScript("OnMouseWheel")) then
		EloChatFrame:SetScript("OnMouseWheel", 
			function ()
				if (arg1 > 0) then
					if (IsShiftKeyDown()) then this:ScrollToTop();
					elseif (IsControlKeyDown()) then this:PageUp();
					else this:ScrollUp() this:ScrollUp() this:ScrollUp() this:ScrollUp() end
				elseif (arg1 < 0) then
					if (IsShiftKeyDown()) then this:ScrollToBottom();
					elseif (IsControlKeyDown()) then this:PageDown();
					else this:ScrollDown() this:ScrollDown() this:ScrollDown() this:ScrollDown() end
				end
			end
		);
		
		EloChatFrame:EnableMouseWheel(1);
	end
end
function Elo.MoveOrResize(this)

	local cx, cy = GetCursorPosition();
	local scale = this:GetEffectiveScale();
	local left = this:GetLeft() * scale;
	local right = this:GetRight() * scale;
	local phi = math.floor((right-left)/5); 

	--Elo.DebugMessage("CX: "..cx.." SC: "..scale.." L: "..left.." R: "..right.." PHI: "..phi)

	if cx < (left+phi) then
		this:StartSizing("LEFT");
	elseif cx > (right+phi) then
         this:StartSizing("RIGHT");
	else
         this:StartMoving()
	end
end


Elo.Hue = {
	["yellow"]	=	"|cffffff00",
	["gold"]		=	"|cffcfb52b",
	["white"]	=	"|c00ffffff",
	["grey"]		=	"|cffcccccc",
	["red"]		=	"|cffff0000",
	["green"]	=	"|cff00ff00",
	["blue"]		=	"|cff0000ff",
	["neonblue"]	=	"|cff0070dd",
	["lightblue"]	=	"|c00c0ffff",
	["purple"]	=	"|cffa335ee",
	["orange"]	=	"|cffff6d00",
}

Elo.PreviewKeyList = {
	[0] = {"Shift",IsShiftKeyDown},
	[1] = {"Ctrl",IsControlKeyDown},
	[2] = {"Alt",IsAltKeyDown},
}

Elo.StyleGuide = {
	[0] = " |cff808080OFF|r ",
	[1] = " |cff00ff00Lv. 1|r ",
	[2] = " |cff4d4dffLv. 2|r ",
	[3] = " |cffa335eeLv. 3|r ",
	[4] = " |cffff6d00Lv. 4|r ",
}

Elo.ZoneFilter = {
	["hillsbrad foothills"] = {
		["search"] = "hillsbrad foothills",
		["in"] = {
			[1] = {
				["(%A)[sS][sS](%A)"] = "%1Southshore%2",
			},
		},
	},
	["the barrens"] = {
		["search"] = "the barrens",
		["in"] = {
			[1] = {
				["(%A)[cC]amp%A?[tT](%A)"] = "%1Camp Taurajo%2",
				["(%A)[cC][tT](%A)"] = "%1Camp Taurajo%2",
				["(%A)[rR][fF](%A)"] = "%1Razorfen%2",
			},
		},
	},
	["arathi basin"] = {
		["search"] = "arathi basin",
		["in"] = {
			[1] = {
				["(%A)[bB][sS](%A)"] = "%1the blacksmith%2",
				["([^%d%a:])[sS][tT]([^%d%a.])"]	=	"%1the stables%2",
				["(%A)[sS]h?tabs*(%A)"] = "%1the stables%2",
				["(%A)[gG][mM](%A)"] = "%1the gold mine%2",
				["(%A)[lL][mM](%A)"] = "%1the lumber mill%2",
			},
			[2] = {
				["(%A[cC]ame%s)([oOdD][%d%s.?,!])"]	=	"%1#%2",
				["(%A[cC]om[eding]+%s)([oOdD][%d%s.?,!])"]	=	"%1#%2",
				["(%A[gG]o[eing]*%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[wW]ent%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[sS]tay%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[mM]ore%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[lL]ess%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[oO]n%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["^%s([oOdD]%s%a+%A+%a)"] = " #%1",
			},
			[3] = {
				["(%s)#[oO]([%d%s.?,!])"]		=	"%1 offense%2",
				["(%s)#[dD]([%d%s.?,!])"]		=	"%1 defense%2",
            },
		},
	},
	["eye of the storm"] = {
		["search"] = "eye of the storm",
		["in"] = {

			[2] = {
				["(%s)[dD]([%s.!?])"] = "%1defense%2",
				["(%A)[fF][rR](%A)"] = "%1flag room%2",
				["(%A)[fF][cC](%A)"] = "%1flag carrier%2",
				["(%A)[eE][fF][cC](%A)"] = "%1enemy flag carrier%2",
				["(%A[cC]ame%s)([oOdD][%d%s.?,!])"]	=	"%1#%2",
				["(%A[cC]om[eding]+%s)([oOdD][%d%s.?,!])"]	=	"%1#%2",
				["(%A[gG]o[eing]*%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[wW]ent%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[sS]tay%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[mM]ore%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[lL]ess%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[oO]n%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["^%s([oOdD]%s%a+%A+%a)"] = " #%1",
			},
			[3] = {
				["(%s)#[oO]([%d%s.?,!])"]		=	"%1 offense%2",
				["(%s)#[dD]([%d%s.?,!])"]		=	"%1 defense%2",
            },
		},
	},
	["deadmines area"] = {
		["search"] = "westfall the deadmines duskwood",
		["in"] = {
			[1] = {
				["%s[lL]%s?[fFrR4](.-)[%s%p]+[dD][mM]+(%A)"] = " LF%1 Deadmines %2",
			},
			[2] = {
				["(%A)[dD][mM](%A)"] = "nil",
				["(%A)[dD][mM]%s([^nNeEwW])"] = "%1Deadmines%2",
				["(%A)[dD][mM](%A*)$"] = "%1Deadmines%2",
			},
		},
		["out"] = {
			[1] = {
				["%s[lL]%s?[fFrR4](.-)[%s%p]+[dD][mM]+(%A)"] = " LF%1 Dire Maul %2",
			},
			[2] = {
				["(%A)[dD][mM](%A)"] = "%1Dire Maul%2",
			},
		},			
	},	
	["outlands"] = {
		["search"] = "hellfire peninsula zangarmarsh coilfang reservoir",
		["in"] = {
			[2] = {
				["(%A)[sS][pP]([%s!?.,])"] = "%1Slave Pens%2",
			},
		},
	},


	["stranglethorn vale"] = {
		["search"] = "stranglethorn vale",
		["in"] = {
			[2] = {
				["(%A)[gG]rom+([%s!?.,])"] = "%1Grom'gol%2",
				["(%A)[gG][gG](%A)"] = "%1Grom'gol%2",
				["(%s)[sS][tT]([^%d%a])"]	=	"%1Stranglethorn%2",
				["(%A)[lL]ake%s?[nN]%a*(%A)"]		=	"%1Lake Nazferiti%2",
				["(%A)[nN]es['%a]*([%s?!,.])"] = "%1Nesingwary%2",
			},
		},
		["out"] = {
			[2] = {
				["(%A)[gG]rom+([%s!?.,])"] = "nil",
				["(%A)[gG][gG](%A)"] = "%1good game%2",
				["(%s)[sS][tT]([^%d%a])"]	=	"%1Sunken Temple%2",
				["(%A)[lL]ake%s?[nN]%a*(%A)"]		=	"nil",
				["(%A)[nN]es['%a]*([%s?!,.])"] = "nil",
			},
		},			
	},	
	["alterac valley"] = {
		["search"] = "alterac valley",
		["in"] = {
			[1] = {
				["(%A)[hH]i[gh]*%s?[rR][oa]*d+(%A)"] = "%1high road%2",
				["(%A)[lL]ok+z?p?q?(%A)"] = "%1Lokholar%2",
				["(%A)[eEaAuU]?[bB][eau]?l+indah?(%A)"] = "%1Balinda%2",
				["(%A)[bB][ea]l(%A)"] = "%1Balinda%2",
				["(%A)[wW][cC]([sS]*%A)"]			=	"%1Wing Commander%2",
				["(%A)[vV]a[nh]+(%A)"] = "%1Vanndar%2",
				["(%A)[dD]rek([^%a'])"] = "%1Drek'thar%2",
				["(%A)[gG]alvz?p?q?([^%a'])"] = "%1Galvangar%2",
			},
			[2] = {
				["(%A)[sS][fF](%A)"] = "%1Snowfall%2",
				["([^%a'])[sS][hH]([^%a!])"] = "%1Stonehearth%2",
				["(%A[lL])[tT](s?%A)"] = "%1ieutenant%2",
				["(%A)[tT][pP](%A)"] = "%1Tower Point%2",
				["(%A)[iI][bB](%A)"] = "%1Iceblood%2",
				["(%A)[iI][wW][bB](%A)"] = "%1Icewing Bunker%2",
				["(%A)[iI][wW](%A)"] = "%1Icewing%2",
				["(%A)[sS][fF](%A)"] = "%1Snowfall%2",
				["(%A)[fF][wW](%A)"] = "%1Frostwolf%2",
				["([^%a(])[sS][pP]([^%a)])"] = "%1Stormpike%2",
				["(%A)[sS]hgy*(%A)"] = "%1the Stonehearth Graveyard%2",
				["(%A)[iI]bgy*(%A)"] = "%1the Iceblood Graveyard%2",
				["(%A)[sS]fgy*(%A)"] = "%1the Snowfall Graveyard%2",
				["(%A)[fF]wgy*(%A)"] = "%1the Frostwolf Graveyard%2",
				["(%A)[sS]pgy*(%A)"] = "%1the Stormpike Graveyard%2",
				["(%A)[fF]o[sS](%A)"] = "%1the Field of Strife%2",
				["(%A)[fF]a?s(%A)"] = "%1the First Aid Station%2",
				["(%A)[sS]as(%A)"] = "%1the Stormpike Aid Station%2",
				["(%A)[rR][sShH](%A)"] = "%1the Relief Hut%2",
				["(%A)Let your essence congeal with Lokholar!(%A)"]	=	"%1%2",
				["(%A)Throw these villains from Alterac Valley!(%A)"]	=	"%1%2",
				["(%A)Drive%sthese%sheathens%sfrom%sour%slands!(%A)"]	=	"%1%2",
				["^%s?T?h?e?%s(.-)%sis%sunder%sattack!%sIf%sleft%sunchecked,%sthe%s(%a+).*$"]	=	" The %2 contests the %1! ",
				["^%s?T?h?e?%s(.-)%swas%s(%a+)%sby%sthe%s(%a+)!%s$"]	=	" The %3 has %2 the %1! ",
				["(under%sattack!%sI%srequire%said!)%sCome!.*$"]	=	"%1",

				["(%A[cC]ame%s)([oOdD][%d%s.?,!])"]	=	"%1#%2",
				["(%A[cC]om[eding]+%s)([oOdD][%d%s.?,!])"]	=	"%1#%2",
				["(%A[gG]o[eing]*%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[wW]ent%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[sS]tay%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[mM]ore%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[lL]ess%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[oO]n%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["^%s([oOdD]%s%a+%A+%a)"] = " #%1",
			},
			[3] = {
				["(%s)#[oO]([%d%s.?,!])"]		=	"%1offense%2",
				["(%s)#[dD]([%d%s.?,!])"]		=	"%1defense%2",


			},
		},
	},	
	["blackwing lair"] = {
		["search"] = "blackwing lair",
		["in"] = {
			[2] = {
				["(%A)[bB][aA](%A)"] = "%1Burning Adrenaline%2",
				["(%A)[sS][fF](%A)"] = "%1Shadowflame%2",
			},
		},
	},	
	["tanaris"] = {
		["search"] = "tanaris",
		["in"] = {
			[2] = {
				["(%A)[sS][wW][pP](%A)"] = "%1Steamwheedle Port%2",
			},
		},
	},	
	["warsong gulch"] = {
		["search"] = "warsong gulch",
		["in"] = {
			[2] = {
				["(%s)[dD]([%s.!?])"] = "%1defense%2",
				["(%A)[tT]un+(%A)"] = "%1tunnel%2",
				["(%A)[fF][rR](%A)"] = "%1flag room%2",
				["(%A)[fF][cC](%A)"] = "%1flag carrier%2",
				["(%A)[eE][fF][cC](%A)"] = "%1enemy flag carrier%2",
				["(%A[cC]ame%s)([oOdD][%d%s.?,!])"]	=	"%1#%2",
				["(%A[cC]om[eding]+%s)([oOdD][%d%s.?,!])"]	=	"%1#%2",
				["(%A[gG]o[eing]*%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[wW]ent%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[sS]tay%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[mM]ore%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[lL]ess%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["(%A[oO]n%s)([oOdD][%d%s.?,!])"]			=	"%1#%2",
				["^%s([oOdD]%s%a+%A+%a)"] = " #%1",
--				["The%s(.-)%sFlag%swas%s(.-)%sby%s(.-)!"]	=	"%3 has %2 the %1 Flag!",
--	The Alliance Flag was picked up by Mastwulfgar!
			},
			[3] = {
				["(%s)#[oO]([%d%s.?,!])"]		=	"%1 offense%2",
				["(%s)#[dD]([%d%s.?,!])"]		=	"%1 defense%2",

				["(%A)[gG]o%s[tT]unnel(%A)"]			=	"%1take the tunnel%2",
				["(%A)[gG]oing%s[tT]unnel(%A)"]			=	"%1taking the tunnel%2",
				["(%A)[cC]ome%s[tT]unnel(%A)"]			=	"%1come to the tunnel%2",
				["([%s%pn])[cC]oming%s[tT]unnel(%A)"]			=	"%1coming through the tunnel%2",

				["(%A)[gG]o%s[rR]amp(%A)"]			=	"%1take the ramp%2",
				["(%A)[gG]oing%s[rR]amp(%A)"]			=	"%1taking the ramp%2",
				["(%A)[cC]ome%s[rR]amp(%A)"]			=	"%1take the ramp%2",
				["([%s%pn])[cC]oming%s[rR]amp(%A)"]			=	"%1coming down the ramp%2",

			},
		},
	},	
	["molten core"] = {
		["search"] = "molten core",
		["in"] = {
			[2] = {
				["(%A)[lL]uci(%A)"] = "%1Lucifron%2",
				["(%A)[mM]ag(%A)"] = "%1Magmadar%2",
				["(%A)[gG]e?hen(%A)"] = "%1Gehennas%2",
				["(%A)[bB]aron(%A[^gG])"] = "%1Baron Geddon%2",
				["(%A)[gG]ole?(%A)"] = "%1Golemagg%2",
				["(%A)[rR]ag(%A)"] = "%1Ragnaros%2",
				["(%A)[dD]omo(%A)"] = "%1Majordomo%2",
				["(%A)[sS]ulf(%A)"] = "%1Sulfuron%2",
			},
		},
	},	
};

--[[

Elo.DungeonVals = {
	["Ragefire Chasm"]	= {
		[1] = 15,
		[2] = {"rfc","rcf","rage?%A*fire%A*ch?a[sm]",},
		},
	["Deadmines"]			=	{
		[1] = 21,
		[2] = {"dead%A*mines","vc","van%A*cleef",},
		},
	["Wailing Caverns"]	=	{
		[1] = 20,
		[2] = {"wc","wailing%A*caverns?",},
		},
	["Stockades"]			=	{
		[1] = 28,
		[2] = {"stockades?","stocks",},
		},
	["Shadowfang Keep"]	=	{
		[1] = 26,
		[2] = {"sfk","skf","shadow%A*fang%A*ke+p+",},
		},
	["Blackfathom Deeps"]	=	{
		[1] = 28,
		[2] = {"bfd","blackfathom%A*deeps",},
		},
	["Gnomeregan"]		=	{
		[1] = 33,
		[2] = {"gnomer","gnome?r[eaoui]g[oa]n",},
		},
	["Razorfen Kraul"]	=	{
		[1] = 27,
		[2] = {"rfk","rkf","raz[eo]*r%A*fen+%A*kr[aeu][wu]l+",},
		},
	["Razorfen Downs"]	=	{
		[1] = 36,
		[2] = {"rfd","rdf","raz[eo]*r%A*fen+%A*downs?",},
		},
	["Scarlet Monastery"]	=	{
		[1] = 39,
		[2] = {"sm","scarlet%A*m[oa]n+[ae]st[ae]ry",},
		},
	["Uldaman"]			=	{
		[1] = 41,
		[2] = {"ulda","uldaman+",},
		},
	["Zul'Farrak"]		=	{
		[1] = 49,
		[2] = {"zf","zul+%A*far+a+k+",},
		},
	["Sunken Temple"]		=	{
		[1] = 50,
		[2] = {"st","sunken","temple"},
		},
	["Maraudon"]			=	{
		[1] = 50,
		[2] = {"ma+ra+","m[ea]r+[auo]+d[oae]+n",},
		},
	["Blackrock Depths"]	=	{
		[1] = 56,
		[2] = {"brd","blackrock%A*dep+[th]*s",},
		},
	["Blackrock Spire"]	=	{
		[1] = 59,
		[2] = {"brs","[ul]bsr","[ul]brs","blackrock%A*spi[ry][ae]h?",
			},
		},
	["Stratholme"]		=	{
		[1] = 59,
		[2] = {"strath?","stra[th]+hol?me?"},
		},
	["Dire Maul"]			=	{
		[1] = 57,
		[2] = {"dire%A*maul","dm%A*north","dm%A*west","dm%A*east",},
		},
	["Scholomance"]		=	{
		[1] = 58,
		[2] = {"s[chk]+o+l+o+","s[kch]+ol+omance",},
		},
	["Ahn'Qiraj"]		=	{
		[1] = 58,
		[2] = {"aq","ah?n%A*qiraj",},
		},
	["Naxxramas"]		=	{
		[1] = 60,
		[2] = {"nax+","nax+r+am+as+",},
		},
	["Zul'Gurub"]		=	{
		[1] = 60,
		[2] = {"zg","zul+%A*gu*r+ub+",},
		},
	["Jintha'Alor"]		=	{
		[1] = 47,
		[2] = {"ji[mn]tha?%A*al+or","ji[mn]tha"},
		},
	["Stromgarde"]		=	{
		[1] = 37,
		[2] = {"[st[or]+mg[au]+de?","strom"},
		},
	["Baron"]		=	{
		[1] = 59,
		[2] = {"[bB]a+r+on+"},
		},
	["Test of Skulls"]		=	{
		[1] = 58,
		[2] = {"tos","test%A*[oa]f?%A*skul+[zs]*"},
		},
	["Warlord's Command"]		=	{
		[1] = 57,
		[2] = {"warlord[s%A]*command","rend"},
		},
}
--]]

---------------------------------------------------------------------
-- If not EN version then include FR and DE in the class values
---------------------------------------------------------------------
Elo.ClassTable = {
	  ["Druid"]	= 1,
	  ["Druide"]	= 1,
	  ["Hunter"]	= 2,
	  ["Huntah"]	= 2,
	  ["untah"]	= 2,
	  ["Chasseur"]	= 2,
	  ["J\195\164ger"]	= 2,
	  ["Mage"]	= 3,
	  ["Magier"]	= 3,
	  ["Paladin"]	= 4,
	  ["Priest"]	= 5,
	  ["Pr\195\170tre"]	= 5,
	  ["Priester"]	= 5,
	  ["Rogue"]	= 6,
	  ["Voleur"]	= 6,
	  ["Schurke"]	= 6,
	  ["Shaman"]	= 7,
	  ["Chaman"]	= 7,
	  ["Schamane"]	= 7,
	  ["Warlock"]	= 8,
	  ["D\195\169moniste"]	= 8,
	  ["Hexenmeister"]	= 8,
	  ["Warrior"]	= 9,
	  ["Guerrier"]	= 9,
	  ["Krieger"]	= 9,
	  ["Death Knight"]   = 10,
	  ["Chevalier de la Mort"]   = 10,
	  ["Todesritter"]   = 10,
	  };

---------------------------------------------------------------------
-- French
---------------------------------------------------------------------
if( GetLocale() == "frFR" ) then

Elo.RacialTable = {
	  ["Orc"]	= 1,
	  ["Tauren"]	= 2,
	  ["Troll"]	= 3,
	  ["Undead"]	= 4,
	  ["Mort-vivant"]	= 4,
	  ["BloodElf"]	= 5,
	  ["Blood Elf"]	= 5,
	  ["Human"]	= 1,
	  ["Humain"]	= 1,
	  ["NightElf"]	= 2,
	  ["Night Elf"]	= 2,
	  ["Elfe de la nuit"] = 2,
	  ["Dwarf"]	= 3,
	  ["Nain"] = 3,
	  ["Gnome"]	= 4,
	  ["Draenei"]	= 5,
	  };


Elo.FactionTable = {
	  ["Orc"]	= "Horde",
	  ["Tauren"]	= "Horde",
	  ["Troll"]	= "Horde",
	  ["Undead"]	= "Horde",
	  ["Mort-vivant"]	= "Horde",
	  ["BloodElf"]	= "Horde",
	  ["Blood Elf"]	= "Horde",
	  ["Human"]	= "Alliance",
	  ["Humain"]	= "Alliance",
	  ["NightElf"]	= "Alliance",
	  ["Night Elf"]	= "Alliance",
	  ["Elfe de la nuit"] = "Alliance",
	  ["Dwarf"]	= "Alliance",
	  ["Nain"] = "Alliance",
	  ["Gnome"]	= "Alliance",
	  ["Draenei"]	= "Alliance",
};

local frenchlocs = {
	["hillsbrad foothills"] = "contreforts d'hillsbrad",
	["the barrens"] = "les tarides",
	["arathi basin"] = "bassin d'arathi",
	["deadmines area"] = "for\195\170t d'elwynn marche de l'ouest les mortemines bois de la p\195\169nombre",
	["stranglethorn vale"] = "vall\195\169e de strangleronce",
	["alterac valley"] = "vall\195\169e d'alterac",
	["blackwing lair"] = "repaire de l'aile noire",
	["tanaris"] = "tanaris",
	["warsong gulch"] = "goulet des warsong",
	["molten core"] = "c\197\147ur du magma",
}

for k in Elo.ZoneFilter do
	Elo.ZoneFilter[k]["search"] = frenchlocs[k]
end

frenchlocs = nil

Elo.DefaultChannels = {
	["G\195\169n\195\169ral"]		=	true,
	["D\195\69fenseLocale"]	=	true,
	["D\195\69fenseUniverselle"]	=	true,
	["Commerce"]			=	true,
	["RechercheGroupe"]	=	true,
	["RecrutementGuilde"]	=	true,
}
Elo.RankedChan = "(D\195\69fense[LU]%a+%]%s|Hplayer:.-|h%[).-([^%s%]]+%])"

Elo.LOCLOOKINGFORGROUP = "RechercheGroupe"
Elo.LOCTRADE = "Commerce"

Elo.THE = "[lL]e"

Elo.HeaderSettings = {
[0] = {
	},
[1] = {
	[1] = {
		["%[%d.%sD\195\69fenseLocale%]%s:%s"]		=	"",
		["%[%d.%sD\195\69fenseUniverselle%]%s:%s"]		=	"",
	},
	[2]={
		["%[[%d%s%w.]+%]%s:?%s?"]	=	"",
	},
	},
[2] = {
	[1] = {
		["%[%d.%sD\195\69fenseLocale%]%s:%s"]		=	"[DL.] ",
		["%[%d.%sD\195\69fenseUniverselle%]%s:%s"]		=	"[DU.] ",
	},
	[2]={
		["%[%d%.%s(%a)%a*%]"]		=	"[%1.]",
		["%[Guilde%]%s?(|H)"]		=	"[Gu.] %1",
		["%[Groupe%]%s?(|H)"]		=	"[Gr.] %1",
		["%[Officier%]%s?(|H)"]	=	"[O.] %1",
		["%[Raid%]%s?(|H)"]		=	"[R.] %1",
		["%[Chef de raid%]%s"]		=	"[CR.]",
		["%[Champ de bataille%]%s"]		=	"[CB.]",

	},
	},
[3] = {
	[1] = {
		["%[(%d).%sD\195\69fenseLocale%]%s:%s"]		=	"[%1.] ",
		["%[(%d).%sD\195\69fenseUniverselle%]%s:%s"]		=	"[%1.] ",
	},
	[2]={
		["%[(%d)%.%s%w+%]%s?(|H)"]		=	"[%1.] %1",
		["%[Guilde%]%s?(|H)"]		=	"[Gu.] %1",
		["%[Groupe%]%s?(|H)"]		=	"[Gr.] %1",
		["%[Officier%]%s?(|H)"]	=	"[O.] %1",
		["%[Raid%]%s?(|H)"]		=	"[R.] %1",
		["%[Chef de raid%]%s"]		=	"[CR.]",
		["%[Champ de bataille%]%s"]		=	"[CB.]",

	},
	},
[4] = {
	[1] = {
		["%[%d%.%s(%a+)%][:%s]*(|H%a)"]		=	"[%1]: %2",
	},
	},
};

---------------------------------------------------------------------
-- German
---------------------------------------------------------------------
elseif ( GetLocale() == "deDE" ) then

Elo.RacialTable = {
	  ["Orc"]	= 1,
	  ["Tauren"]	= 2,
	  ["Troll"]	= 3,
	  ["Undead"]	= 4,
	  ["Untoter"]	= 4,
	  ["BloodElf"]	= 5,
	  ["Blood Elf"]	= 5,
	  ["Human"]	= 1,
	  ["Mensch"]	= 1,
	  ["NightElf"]	= 2,
	  ["Night Elf"]	= 2,
	  ["Nachtelf"]	= 2,
	  ["Dwarf"]	= 3,
	  ["Zwerg"]	= 3,
	  ["Gnome"]	= 4,
	  ["Gnom"]	= 4,
	  ["Draenei"]	= 5,
	  };


Elo.FactionTable = {
	  ["Orc"]	= "Horde",
	  ["Tauren"]	= "Horde",
	  ["Troll"]	= "Horde",
	  ["Undead"]	= "Horde",
	  ["Untoter"]	= "Horde",
	  ["BloodElf"]	= "Horde",
	  ["Blood Elf"]	= "Horde",
	  ["Human"]	= "Alliance",
	  ["Mensch"]	= "Alliance",
	  ["NightElf"]	= "Alliance",
	  ["Night Elf"]	= "Alliance",
	  ["Nachtelf"]	= "Alliance",
	  ["Dwarf"]	= "Alliance",
	  ["Zwerg"]	= "Alliance",
	  ["Gnom"]	= "Alliance",
	  ["Gnome"]	= "Alliance",
	  ["Draenei"]	= "Alliance",
};

Elo.DefaultChannels = {
	["Allgemein"]		=	true,
	["LokaleVerteidigung"]	=	true,
	["WeltVerteidigung"]	=	true,
	["Handel"]			=	true,
	["SuchenachGruppe"]	=	true,
	["GildenRekrutierung"]	=	true,
}

Elo.LOCLOOKINGFORGROUP = "SuchenachGruppe"
Elo.LOCTRADE = "Handel"

Elo.THE = "[dD]er"

Elo.RankedChan = "([WL].-Verteidigung%]%s|Hplayer:.-|h%[).-([^%s%]]+%])"

local deutschlocs = {
	["hillsbrad foothills"] = "die vorgebirge von hillsbrad",
	["the barrens"] = "das brachland",
	["arathi basin"] = "arathibecken",
	["deadmines area"] = "der wald von elwynn westfall die todesminen duskwood",
	["stranglethorn vale"] = "stranglethorn",
	["alterac valley"] = "alteractal",
	["blackwing lair"] = "pechschwingenhort",
	["tanaris"] = "tanaris",
	["warsong gulch"] = "warsongschlucht",
	["molten core"] = "geschmolzener kern",
}


for k in Elo.ZoneFilter do
	Elo.ZoneFilter[k]["search"] = deutschlocs[k]
end

deutschlocs = nil


Elo.HeaderSettings = {
[1] = {
	[1] = {
		["%[.-WeltVerteidigung%]%s:%s"]		=	"",
		["%[.-LokaleVerteidigung%]%s:%s"]		=	"",


	},
	[2]={
		["%[[%d%s%w.]+%]%s:?%s?"]	=	"",
	},
	},
[2] = {
	[1] = {
		["%[.-WeltVerteidigung%]%s:%s"]		=	"[W.]:",
		["%[.-LokaleVerteidigung%]%s:%s"]		=	"[L.]:",
	},
	[2]={
		["%[%d%.%s(%a)%a*%]"]		=	"[%1.]",
		["%[Gilde%]%s?(|H)"]		=	"[Gi.] %1",
		["%[Gruppe%]%s?(|H)"]		=	"[Gr.] %1",
		["%[Offizier%]%s?(|H)"]	=	"[O.] %1",
		["%[Schlachtzug%]%s?(|H)"]		=	"[S.] %1",
		["%[Schlachtzugsleiter%]%s"]		=	"[SL.]",
		["%[Schlachtfeld%]%s"]		=	"[SF.]",
	},
	},
[3] = {
	[1] = {
		["%[(%d).-WeltVerteidigung%]%s:%s"]		=	"[%1.]:",
		["%[(%d).-LokaleVerteidigung%]%s:%s"]		=	"[%1.]:",
	},
	[2]={
		["%[(%d)%.%s%w+%]"]		=	"[%1.]",
		["%[Gilde%]%s?(|H)"]		=	"[G.] %1",
		["%[Gruppe%]%s?(|H)"]		=	"[G.] %1",
		["%[Offizier%]%s?(|H)"]	=	"[O.] %1",
		["%[Schlachtzug%]%s?(|H)"]		=	"[S.] %1",
		["%[Schlachtzugsleiter%]%s"]		=	"[SL.]",
		["%[Schlachtfeld%]%s"]		=	"[SF.]",

	},
	},
[4] = {
	[1] = {
		["%[%d%.%s(%a+)%][:%s]*(|H%a)"]		=	"[%1]: %2",
	},
	},
};
---------------------------------------------------------------------
-- Everywhere else
---------------------------------------------------------------------
else

Elo.RacialTable = {
	  ["Orc"]	= 1,
	  ["Tauren"]	= 2,
	  ["Troll"]	= 3,
	  ["Undead"]	= 4,
	  ["BloodElf"]	= 5,
	  ["Blood Elf"]	= 5,
	  ["Human"]	= 1,
	  ["NightElf"]	= 2,
	  ["Night Elf"]	= 2,
	  ["Dwarf"]	= 3,
	  ["Gnome"]	= 4,
	  ["Draenei"]	= 5,
	  };
Elo.FactionTable = {
	  ["Orc"]	= "Horde",
	  ["Tauren"]	= "Horde",
	  ["Troll"]	= "Horde",
	  ["Undead"]	= "Horde",
	  ["BloodElf"]	= "Horde",
	  ["Blood Elf"]	= "Horde",
	  ["Human"]	= "Alliance",
	  ["NightElf"]	= "Alliance",
	  ["Night Elf"]	= "Alliance",
	  ["Dwarf"]	= "Alliance",
	  ["Gnome"]	= "Alliance",
	  ["Draenei"]	= "Alliance",
};

Elo.HeaderSettings = {
-- Capture: [4. WorldDefense] : |cffffff00Tirisfal Glades is under attack!|r

[0] = {
	[1] = {},
	},

[1] = {
	[1] = {
		["%[.-WorldDefense%]%s:%s"]		=	"",
		["%[.-LocalDefense%]%s:%s"]		=	"",
	},
	[2]={
		["%[[%d%s%w.]+%]%s:?%s?"]	=	"",
	},
	},
[2] = {
	[1] = {
		["%[.-WorldDefense%]%s:"]		=	"[WD.]",
		["%[.-LocalDefense%]%s:"]		=	"[LD.]",
	},
	[2]={
		["%[%d%.%s(%a)%a*%]"]		=	"[%1.]",
		["%[Guild%]%s?(|H)"]		=	"[G.] %1",
		["%[Party%]%s?(|H)"]		=	"[P.] %1",
		["%[Officer%]%s?(|H)"]	=	"[O.] %1",
		["%[Raid%]%s?(|H)"]		=	"[R.] %1",
		["%[Raid%sLeader%]"]		=	"[RL.]",
		["%[Battleground%]%s(|H)"]		=	"[BG.] %1",
		["%[Battleground%sLeader%]%s(|H)"]		=	"[BL.] %1",
	},
	},
[3] = {
	[1] = {
		["%[(%d).-WorldDefense%]%s:"]		=	"[1.]",
		["%[(%d).-LocalDefense%]%s:"]		=	"[1.]",

	},
	[2]={
		["%[(%d)%.%s%w+%]"]		=	"[%1.]",
		["%[Guild%]%s?(|H)"]		=	"[G.] %1",

		["%[Party%]%s?(|H)"]		=	"[P.] %1",
		["%[Officer%]%s?(|H)"]	=	"[O.] %1",
		["%[Raid%]%s?(|H)"]		=	"[R.] %1",
		["%[Raid%sLeader%]"]		=	"[RL.]",
		["%[Battleground%]%s(|H)"]		=	"[BG.] %1",
		["%[Battleground%sLeader%]%s(|H)"]		=	"[BL.] %1",

	},
	},
[4] = {
	[1] = {
		["%[%d%.%s(%a+)%][:%s]*(|H%a)"]		=	"[%1]: %2",

	},
	},
};

Elo.ClassTable = {
	  ["Druid"]	= 1,
	  ["Hunter"]	= 2,
	  ["Untah"]	= 2,
	  ["untah"]	= 2,
	  ["'untah"]	= 2,
	  ["Mage"]	= 3,
	  ["Paladin"]	= 4,
	  ["Priest"]	= 5,
	  ["Rogue"]	= 6,
	  ["Shaman"]	= 7,
	  ["Warlock"]	= 8,
	  ["Warrior"]	= 9,
	  ["Death Knight"]  = 10,
};

Elo.DefaultChannels = {
	["General"]		=	true,
	["LocalDefense"]	=	true,
	["WorldDefense"]	=	true,
	["Trade"]			=	true,
	["LookingForGroup"]	=	true,
	["GuildRecruitment"]	=	true,
}

Elo.LOCLOOKINGFORGROUP = "LookingForGroup"
Elo.LOCTRADE = "Trade"

Elo.THE = "[tT]he"

Elo.RankedChan = "(%u%l%l%l%lDefense%]%s|Hplayer:.-|h%[).-([^%s%]]+%])"


end
