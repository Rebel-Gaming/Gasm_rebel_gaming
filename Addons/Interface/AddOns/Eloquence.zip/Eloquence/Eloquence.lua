Elo.Event = ""
local gsub = string.gsub
local sub = string.sub
local gmatch = string.gmatch
local fmod = math.fmod
local find = string.find
local len = string.len
local insert = table.insert
local elogsub = Elo.gsub
local upper = string.upper
local trim = string.trim
local lower = string.lower
local byte = string.byte
local format = string.format
local concat = strconcat
local player = (UnitName("player"))
local p = pairs
local speaker = ""

local escapeTable = { }
local itemTable = { }
local spamlist = { }
local capstring = false
local checkme = false
local flagged = ""
local systemspam = { }
local urlTable = { }
local lastEvent = {
	["Party"] = 1,
	["Raid"] = 1,
	["Guild"] = 1,
	["Friend"] = 1,
	["Who"] = {
		["Time"] = 1,
		["Zone"] = "",
		["Query"] = "",
	},
}
local caplist = { }
local langlist = { }
local playertag = "zpq"
local customtag = "zmq"

local function print(msg)
	DEFAULT_CHAT_FRAME:AddMessage(msg)
end
---------------------------------------------------------------------
-- Print Debug Messages to the Feedback Console
---------------------------------------------------------------------
local function debug(...)
	if EloConfig and (EloConfig.FeedbackMode == 1 or EloOutputFrame:IsShown()) and ... then
		local a = {...}
		local t = ""
		for k,v in p(a) do
			t = strjoin(" ",t,v)
		end
		t = trim(t)
		if t ~= Elo.LastDebMessage then
			EloChatFrame:AddMessage(Elo.Hue.green..t)
			Elo.LastDebMessage = t
		end
	end
end

local function islangknown(lingo)
	if not lingo or lingo == "" or langlist[lingo] then
		return true
	else
		return false
	end
end
local tildetypes = {
	{["(%l)~+(%u)"]	=	"%1 %2"},
	{["~?(%a%a%a+)~"]	=	"%1"},
	{["(%a)~(%a)"]	=	"%1%2"},
	{["~[*~]+"]	=	""},
	{["~%?%?~"]	=	"%?%?"},
}

local hexValues = { [0] = "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" }
local webFilter = {
	"%a+://%S+%s?",
	"www%.[_%w%-]+%.%S+%s?",
	"[_%w.-]+@[_%w.-]+%.+[_%w.-]+%s?",
	"%d%d?%d?%.%d%d?%d?%.%d%d?%d?%.%d%d?%d?:%d%d?%d?%d?%d?%s?",
	"%d%d?%d?%.%d%d?%d?%.%d%d?%d?%.%d%d?%d?%s?",
	"[%w_-]+%.?[%w_-]+%.[%w_-]+:%d%d%d?%d?%d?",
	"%w%w[%w.]-%w%w%.%a%a%a%s?"
}

local eventtable = {
	["CHAT_MSG_SAY"] = "Say",
	["CHAT_MSG_EMOTE"] = "Say",
	["CHAT_MSG_ACHIEVEMENT"] = "Say",
	["CHAT_MSG_YELL"] = "Yell",
	["CHAT_MSG_CHANNEL"] = "Default",
	["CHAT_MSG_CUSTOM"] = "Custom",
	["CHAT_MSG_PARTY"] = "Party",
	["CHAT_MSG_PARTY_LEADER"] = "Party",
	["CHAT_MSG_RAID"] = "Raid",
	["CHAT_MSG_RAID_LEADER"] = "Raid",
	["CHAT_MSG_RAID_WARNING"] = "Raid",
	["CHAT_MSG_BATTLEGROUND"] = "Battleground",
	["CHAT_MSG_BATTLEGROUND_LEADER"] = "Battleground",
	["CHAT_MSG_GUILD"] = "Guild",
	["GUILD_MOTD"] = "Guild",
	["CHAT_MSG_GUILD_ACHIEVEMENT"] = "Guild",
	["CHAT_MSG_OFFICER"] = "Officer",
	["CHAT_MSG_WHISPER"] = "Whisper",
	["CHAT_MSG_WHISPER_INFORM"] = "Whisper",
	["CHAT_MSG_TEXT_EMOTE"] = "Say",
	["CHAT_MSG_MONSTER_EMOTE"] = "Say",
	["CHAT_MSG_MONSTER_SAY"] = "Say",
	["CHAT_MSG_MONSTER_WHISPER"] = "Whisper",
	["CHAT_MSG_MONSTER_YELL"] = "Yell",
	["CHAT_MSG_RAID_BOSS_EMOTE"] = "Say",

	["CHAT_MSG_BG_SYSTEM_ALLIANCE"] = "Battleground",
	["CHAT_MSG_BG_SYSTEM_HORDE"] = "Battleground",

	["CHAT_MSG_SYSTEM"] = "Dummy",



	["SAY"] = "Say",
	["EMOTE"] = "Say",
	["ACHIEVEMENT"] = "Say",
	["YELL"] = "Yell",
	["CHANNEL"] = "Default",
	["CUSTOM"] = "Custom",
	["PARTY"] = "Party",
	["RAID"] = "Raid",
	["GUILD"] = "Guild",
	["OFFICER"] = "Officer",
	["WHISPER"] = "Whisper",
	["RAID_WARNING"] = "Raid",
--	["RAID_LEADER"] = "Raid",
	["BATTLEGROUND"] = "Battleground",
--	["BATTLEGROUND_WARNING"] = "Battleground",
--	["BATTLEGROUND_LEADER"] = "Battleground",

}

local emoteevents = {
	["CHAT_MSG_MONSTER_EMOTE"] = true,
	["CHAT_MSG_TEXT_EMOTE"] = true,
	["CHAT_MSG_RAID_BOSS_EMOTE"] = true,
}
local monsterevents = {
	["CHAT_MSG_MONSTER_EMOTE"] = true,
	["CHAT_MSG_TEXT_EMOTE"] = true,
	["CHAT_MSG_RAID_BOSS_EMOTE"] = true,
	["CHAT_MSG_MONSTER_EMOTE"] = true,
	["CHAT_MSG_MONSTER_SAY"] = true,
	["CHAT_MSG_MONSTER_WHISPER"] = true,
	["CHAT_MSG_MONSTER_YELL"] = true,
	["CHAT_MSG_BG_SYSTEM_ALLIANCE"] = true,
	["CHAT_MSG_BG_SYSTEM_HORDE"] = true,
}


---------------------------------------------------------------------
-- Colors!
---
------------------------------------------------------------------
local classcolor = {
	[0] = {
		[1] = "|c00ff7d0a",
		[2] = "|c00abd473",
		[3] = "|c0069ccf0",
		[4] = "|c00f58cba",
		[5] = "|c00ffffff",
		[6] = "|c00fff569",
		[7] = "|c002459ff",
		[8] = "|c009482c9",
		[9] = "|c00c79c6e",
		[10] = "|c00c41f3b",
	},
	[1] = {
		[1] = "|c00FF7C0A",
		[2] = "|c00AAD372",
		[3] = "|c0068CCEF",
		[4] = "|c00F48CBA",
		[5] = "|c00FFFEFE",
		[6] = "|c00FFF468",
		[7] = "|c00F48CBA",
		[8] = "|c009382c9",
		[9] = "|c00C69B6D",
		[10] = "|c00D32E2A",
	}
}



local bracketFilter={
[1]={
	["|r%s*|c"]	=	"|r, |c",
	["(%d)|c"]	=	"%1 |c",
	["(%w%w)|c"]	=	"%1 |c",
	["([?!:])|c(%x)"]	=	"%1 |c%2",
	["%]%["]	=	"], [",
},
[2]={


	["|h%[(.-)%]|h([^%s|:])"]	=	"|h%1|h %2",


	["%[(%d+%+?)%]"]	=	"%(%1%)",
	["%s*%[%s*%]%s?"]	=	"",
	["|h%]:%s%[(.-)%]%s"]		=	"|h in %1: ",
	["%ssays:%s%[(.-)%]%s"]		=	" says in %1: ",
	["%syells:%s%[(.-)%]%s"]		=	" yells in %1: ",
},
[3]={
	["|r(%w%w)"]	=	"|r %1",
	["^%[(.-)%.%]:"]	=	"%1.",
},
[4]={
	["%]"]	=	"",
	["%["]	=	"",
	["%s%s"]	=	" ",
},
};
local magicchars = "([-?*+%%^$\"()%[%].])"

local function safecapture(msg)
	return gsub(msg,"%%?"..magicchars,"%%%1")
end
local function unsafecapture(msg)
	return gsub(msg,"%%"..magicchars,"%1")
end
local function titlecap(txt)
	if txt then return gsub(lower(txt), "^[^|'%a]*%l", upper) end
end
local function locUnitRace(u)
	local _, race = UnitRace(u)
	if (race == "Scourge") then
		return "Undead"
	end
	return race
end


local function reducerep(msg)
	if msg and speaker ~= player then
--		Reduce repeating item links of an identical item.
		for i=1,5 do
			msg = gsub(msg,"(|.-|H[%w:]+|h.-|h|r)%s*%1","%1")
		end
--		Reduce improbably long numerals
		msg = gsub(msg,"(%d%d%d%d%d%d%d%d%d%d)%d+","%1")

--		Reduce S p a c i n g and H-y-p-h-e-n-a-t-i-n-g
		local initials = ""
		for word,thing in gmatch(msg,"(%a+)([%s%p])") do
			if len(word) == 1 and find(msg,safecapture(initials..word..thing)) then
				initials = initials..word..thing
			end
		end
		if len(initials) > 4 then
			local after = gsub(initials,"[%s%p]+(.)","%1")
			msg = gsub(msg,safecapture(initials),after)
		end
		for a,b in gmatch(msg,"(([^f%d.])%2)%1") do
			b = safecapture(b)
			msg = gsub(msg,b..b..b.."+",a)
		end
--		Reduce blah blah blah blah
		if not find(msg,"|[cH]") then
			for x in gmatch(msg,"%f[%a][^%d%sgah][%a%p]+%f[%A]") do
				local s = safecapture(x)
				msg = gsub(msg,s.."%A*"..s.."%A*"..s,x)
			end
		end
	end
	return msg
end
local function isinbound()
	if Elo.Event and find(Elo.Event,"_") and Elo.Event ~= "RAID_WARNING" then
		return true
	end
end

local function formatclass(msg)
	if EloConfig.ColorInChat > 0 then
		for w,s in gmatch(msg,"'?(%a%a%a%a%a-)('?[sz]*)%f[%A]") do
			local gotcha = titlecap(w)
			if Elo.ClassTable[gotcha] then
				local tillfound = gsub(msg,"^(.-)"..w..s..".*$","%1",1)
				local checklink = find(tillfound,"|[cH]")
				--debug("Tillfound = ",tillfound)

				if not checklink or find(tillfound,"|r") then


					msg = gsub(msg,"%f[%a]("..w..s..")%f[%A]",classcolor[EloConfig.CTRaidColors][Elo.ClassTable[gotcha]].."%1|r",1)
				end
			end
		end
	end
	return msg
end
local function checkchannels(msg,chan,eventname)
	if find(eventname,"CUSTOM") or
	find(eventname,"WHISPER") then
		if (chan and EloConfig.AddonChannels[lower(chan)]) or
		find(msg,"^<.->") then
			return nil
		end
	end
	return true
end
local function addguildchannels()
	local guildchan = GetGuildInfo("player")
	if guildchan and len(guildchan) > 1 then
		local safechan = gsub(lower(guildchan),"[^%w]+","")
		EloConfig.AddonChannels[safechan] = true
		EloConfig.AddonChannels["ct"..safechan] = true
		addguildchannels = nil
	end
end
local function nukewts(line,chan)
	local suppress
	if line and chan and find(chan,Elo.LOCTRADE) and EloConfig.PriceCheck == 1 then
		local msg = " "..lower(line).." "
		for x in gmatch(msg,"(%d+%.?%d?)%s?g") do
			x = tonumber(x)
			if x and GetMoney() > x * 750 then
				return nil
			elseif not find(msg,"free") then
				suppress = true
			end
		end
	end
	return suppress
end



local function alphabetize(a,b)
	if (strlower(a) < strlower(b)) then
		return true
	elseif (strlower(a) == strlower(b) and a < b) then
		return true
	end
end
local function top(msg)
	return gsub(msg,"%f[%a](%a)",function(a)
			return "["..lower(a)..upper(a).."]"
			end
			)
end

Elo.Top = top
local function makefrontier(key,value)
	local ktest,vtest,kc,vc

	if type(value) == "string" then
		ktest,kc = gsub(key,"^%(%%A%)(%[?%a.-%a%]?[*+-?]?)%(%%A%)$","%%f%[%%a%]%1%%f%[%%A%]",1)
		if kc == 1 then
			vtest,vc = gsub(value,"^%%1(.-)%%2$","%1",1)
		else
			ktest,kc = gsub(key,"^%(%%A(%[%a[%a+%[%]]%])%)(%[?%a.-%a%]?[*+-?]?)%(%%A%)$","%%f%[%%a%]%(%1%)%2%%f%[%%A%]",1)
			if kc == 1 then
				vtest,vc = gsub(value,"^%%1(.-)%%2$","%%1%1",1)
			else
				ktest,kc = gsub(key,"^%(%%A%)(%[?%a.-%a%]?[*+-?]?%(%[sz%]%*)%%A%)$","%%f%[%%a%]%1%)%%f%[%%A%]",1)
				if kc == 1 then
					vtest,vc = gsub(value,"^%%1(.-)%%2$","%1%%1",1)
				end
			end
		end
	end
	if kc == 1 and vc == 1 and value ~= "nil" then
		key = ktest
		value = vtest
	end
	return key,value
end
local codex = { }
local function compilefilters(filtername,position)
	for x,y in p(filtername) do
		if not codex[x] then
			codex[x] = { }
		end
		for key,value in p(y) do
			local k,v = makefrontier(key,value)
			if codex[x][k] then
				if v == "nil" then
					codex[x][k] = nil
				else
					codex[x][k][position] = v
				end
			else
				if v == "nil" then
					codex[x][k] = nil
				else
					codex[x][k] = { [position] = v }
				end
			end
		end
	end
end
--[[
function Elo.TestCompilation()
	EloForSave = { }
	for a,b in p(codex) do
		for k,v in p(b) do
			for i = 1,19 do
				if codex[i] and i ~= a then	
					if type(codex[i][k]) == "string" then
						if EloConfig["Saveme"][k] then
							insert(EloConfig["Saveme"][k],i)
						else
							EloConfig["Saveme"][k] = {a,i}
						end
					end
				end
			end
		end
	end
end
--]]
local function createcompilation()
	local rf = Elo.RaceFilter
	local max = Elo.Max
	for c,d in p(rf) do
		for x,y in p(d) do
			if not codex[x] then
				codex[x] = { }
			end
			for key,value in p(y) do
				local k,v = makefrontier(key,value)
				if codex[x][k] then
					if codex[x][k][max] then
						codex[x][k][max][c] = v
					else
						codex[x][k][max] = { [c] = v }
					end
				else
					codex[x][k] = { [max] = { [c] = v }, }
				end
			end
		end
	end
	compilefilters(Elo.ActingCoach,5)
	compilefilters(Elo.Sanitizer,4)
	compilefilters(Elo.Emotes,3)
	compilefilters(Elo.Abbreviations,2)
	compilefilters(Elo.Typos,1)
	createcompilation = nil
end

---------------------------------------------------------------------
-- Run Supplied Text through the Supplied Filter and Return it.
---------------------------------------------------------------------
function Elo.FilterMessage(msg,filter,times)
	for a,b in p(filter) do
		for k,v in p(b) do
			msg = gsub(msg,k,v,times)
		end
	end
	return msg
end

---------------------------------------------------------------------
-- Run Supplied Text through the Custom Filter and Return it.
---------------------------------------------------------------------
local backslash = "\\"
local function customfiltermessage(msg)
	msg = Elo.AddSpaces(msg)
	for k,v in p(EloConfig.Custom) do
		for a in gmatch(v,"[%S]+") do
			v = gsub(v,a,backslash..a,1)
		end
		msg = elogsub(msg,"%f[%S]"..k.."%f[%s]",v)
	end
	for esc in gmatch(msg,"%f[%S]"..backslash.."([%S]+)") do
		escapeTable[#(escapeTable)+1] = esc
		msg = elogsub(msg,backslash..esc,customtag..#(escapeTable),1)
	end
	return msg,c
end

---------------------------------------------------------------------
-- Determine Which Filter
---------------------------------------------------------------------

local nonenglish = "\195\160\195\161\195\162\195\163\195\164\195\166\195\167\195\168\195\169\195\170\195\171\195\172\195\173\195\174\195\175\195\177\195\178\195\179\195\180\195\181\195\182\195\184\195\185\195\186\195\188\195\132\195\150\195\156\195\159\197\147"
local eurochars = concat(nonenglish,upper(nonenglish))
nonenglish = nil
local function isenglishonly(msg)
	if msg and EloConfig.SkipNonEnglish == 1 then
		if find(msg,"["..eurochars.."]") then
			return false
		end
	end
	return true
end
local function selfothers()
	if speaker == player then
		return "Self"
	else
		return "Others"
	end
end
local function oktofilter(msg)
	local m = lower(msg)
	for k,v in p(EloConfig.SkipWordList) do
		if find(m,"%f[%a%d]"..lower(k).."[^%a%d]") then return false end
	end
	local t = concat("SkipOOC",selfothers())
	if EloConfig[t] == 1 then
		if find(m,"^[%s%p]*o[oc][c][%s%p]+[%a%d]") then
			return false
		end
	end
	return true
end


local function pickfilter(msg)
	local c = selfothers()
	local e = Elo.Event
	local matrix = { }
	local mf = Elo.Max
	if find(e,"EMOTE") then
		if not emoteevents[e] then
			matrix[1] = EloConfig[c][eventtable[e]][1]
			matrix[2] = EloConfig[c][eventtable[e]][2]
		end
	else
		matrix = EloConfig[c][eventtable[e]]
	end
	if matrix ~= { } and arg2 ~= "" and isenglishonly(msg) then
		local race
		local list = ElDat[Elo.Srv][Elo.Faction]
		if type(EloOthersOverride) == "number" and speaker ~= player then
			race = EloOthersOverride
		elseif type(EloSelfOverride) == "number" and speaker == player then
			race = EloSelfOverride
		elseif list[speaker] then
			race = list[speaker][1]
		else
			race = nil
		end
		for a,b in p(codex) do
			for k,v in p(b) do
				if v[mf] and matrix[mf] and v[mf][race] then
					if v[mf][race] ~= "nil" then
						msg = elogsub(msg,k,v[mf][race],nil,a)
					end
				else
					for i=(mf - 1),1,-1 do
						if matrix[i] and v[i] then
							msg = elogsub(msg,k,v[i],nil,a)
							break
						end
					end
				end
			end
		end
	end
	return msg

end


---------------------------------------------------------------------
-- Handle Caps and Colors
---------------------------------------------------------------------
local twoletterwords = {
["AH"] = true, ["AM"] = true, ["AN"] = true, ["AS"] = true, ["AT"] = true, ["AW"] = true, ["AX"] = true, ["BE"] = true, ["BY"] = true, ["DO"] = true, ["EH"] = true, ["EL"] = true, ["EM"] = true, ["GO"] = true, ["HA"] = true, ["HE"] = true, ["HI"] = true, ["HO"] = true, ["ID"] = true, ["IF"] = true, ["IN"] = true, ["IS"] = true, ["IT"] = true, ["JO"] = true, ["MA"] = true, ["ME"] = true, ["MI"] = true, ["MY"] = true, ["NE"] = true, ["NO"] = true, ["OF"] = true, ["OH"] = true, ["ON"] = true, ["OR"] = true, ["OW"] = true, ["OX"] = true, ["OY"] = true, ["PA"] = true, ["SO"] = true, ["TO"] = true, ["UH"] = true, ["UM"] = true, ["UN"] = true, ["UP"] = true, ["US"] = true, ["WE"] = true, ["YA"] = true, ["YE"] = true, ["YO"] = true,
}
local function capcolorname(txt,color)
	if txt and color and (#(urlTable) == 0) and (color > 0) then
		for i,j in p(caplist) do
			txt = gsub(txt, "[%a%d\\]+", function(a)
					if len(a) > len(i) / 2 or len(a) >= 4 then
						if find(lower(i),"^"..a) or find(i,"^"..a) then
							if find(txt,"|[cH]") then
								return titlecap(a)..playertag
							else
								return j[1]..titlecap(a)..playertag.."|r"
							end
						end
					end
					return a
				end
				)
		end
	end
	return txt
end

local function shallweformat()
	local c = selfothers()
	local t = EloConfig[c][eventtable[Elo.Event]]
	if t and t[1] then
		return true
	end
end

local function preformat(msg,color)
	escapeTable,itemTable,urlTable = { },{ },{ }

	if shallweformat() then

		for num,name in gmatch(msg,"(|H.-|h)%[?(.-)%]?|h|r") do
			insert(itemTable,{num, name})
		end
		local i = 1
		for k,v in p(webFilter) do
			for x in gmatch(msg,v) do
				insert(urlTable,lower(x))
				msg = gsub(msg,safecapture(x),"dummyurl"..i,1)
				i = i + 1
			end
		end
--  Preserve changes made by custom filters
		msg = customfiltermessage(msg)

--  Don't filter word if escape tag is present
		if not isinbound() then
			local tag = safecapture(EloConfig.EscapeTag)
			for esc in gmatch(msg,"%f[%S]"..tag.."(%a+)") do
				escapeTable[#(escapeTable)+1] = esc
				msg = gsub(msg,esc,customtag..#(escapeTable),1)
			end
		end
--	Add space to beginning and end of line to prepare for tokens/acronyms in next step.
		msg = gsub(msg,"^%s*(.-)%s*$"," %1 ")


--	Reduce repetition for everyone but the player
		msg = reducerep(msg)


--	Separate things like Big SwordLarge ShieldFire Helm
		msg = gsub(msg, "(%l%l)(%u%l%l%l)","%1 %2")
--	Separate things like EnchanterLFwork
		msg = gsub(msg, "(%l%l)(%u%u+)(%l%l)","%1 %2 %3")
--	Separate things like mageLFG
		msg = gsub(msg, "(%l%l%l)(%u%u+)","%1 %2")


--	If there's a mix of upp/lower in a word, lower it
		msg = gsub(msg, "%u*[^ch%u%s%d%p]%u%a+",lower)
		msg = gsub(msg, "%l%l%u",lower)



--	Lowercase aggressively if the line is alphabetical, and all caps
		if find(msg,"%a[AEIOU]") and not find(msg,"%l") then
			if speaker == player then
				Elo.SelfAllCap = len(msg)
			end
			msg = gsub(msg,"%a%a%a+",lower)
			Elo.AddExclamation = true
--	Otherwise be selective and make all-caps into Title Caps
		else
			local captest = gsub(msg, "%u%u+%l",titlecap)
--  If only 1 whole word is uppercase, remember it for future recapping.
			msg,Elo.Hit = gsub(captest,"%u%u%u+",titlecap)
			if Elo.Hit == 1 then
				capstring = gsub(captest,"^.-(.?%A?)(%u%u+)(%A?.?).*$",function(a,b,c)
						local result = concat(a,b,c)
						checkme = top(trim(lower(safecapture(result))))
						if len(a) == 0 then
							checkme = concat("^",top(trim(lower(safecapture(result)))))
							result = b
						elseif len(c) == 0 then
							checkme = concat(checkme,"%f[%A]")
						end
						return result
					end
				)
			end
		end
		for i,j in p(twoletterwords) do
			msg = gsub(msg,"[%s%p]"..i.."[%s%p]",lower)
		end

--	Add commas to really long numerals > 9999.
		msg = gsub(msg,"[^:f%d]%d%d%d%d%d+%f[^%d|]",function (a)
					if type(a) == "number" and not find(msg,"|h|r") then 
						a = gsub(a,"(%d)(%d%d%d)$","%1,%2",1)
						for x,y in gmatch(a,"(%d)(%d%d%d,)") do
							a = gsub(a,x..y,x..","..y)
						end
					end
				return a
				end
			)
--	Uppercase Roman Numerals
		msg = gsub(msg, "%sIi+",upper)

--	Space out item links
		msg = gsub(msg, "([%d%a,!.?:])%s*(|c.-|H.-|h|r)%s*([%d%a])","%1 %2 %3")
	end

--	Cap/color recent speakers
	msg = capcolorname(msg,color)

	return msg
end
local function tohex(n)
	if n > 245 then n = 245 end
	return hexValues[math.floor(n / 16)]..hexValues[fmod(n, 16)]
end
local function newcolor(guy)
	guy = gsub(guy,"%A","")
	local nombre = len(guy)
	local a = 17
	for i = 1, nombre do
		a = a * 37 * byte(guy, i)
	end
	local rgb =	{ math.floor(fmod(a, 255)),
				math.floor(fmod(a * 3, 255)),
				math.floor(fmod(a / 17, 255)) }
-- Recalculate color if it's a dark color or deep blue
	if rgb[1] + rgb[2] + rgb[3] < 500 then
		while rgb[1] + rgb[2] < 250 do
			rgb[1] = rgb[1] + nombre + 13
			rgb[2] = rgb[2] + nombre + 11
		end
	end
	local playercolor = format("|cff%s%s%s", tohex(rgb[1]), tohex(rgb[2]), tohex(rgb[3]))
	for k,v in p(caplist) do
		if playercolor == v[1] or classcolor[EloConfig.CTRaidColors][v[1]] then
			playercolor = format("|cff%s%s%s", tohex(rgb[1]), tohex(rgb[2]), tohex(rgb[3]))
		end
	end
	return playercolor
end
local function addplayer()
	if EloConfig.RandomColors > 0 then
		local bloke = gsub(arg2, ".-(%S+)$", "%1")
		local entry = ElDat[Elo.Srv][Elo.Faction][bloke]
		if caplist[bloke] then
			if entry and
			classcolor[EloConfig.CTRaidColors][entry[2]] then
				caplist[bloke] = { classcolor[EloConfig.CTRaidColors][entry[2]], time() }
			end
			return
		end
		if entry then
			caplist[bloke] = { classcolor[EloConfig.CTRaidColors][entry[2]], time() }
		elseif EloConfig.Colors + EloConfig.RandomColors > 0 then
			caplist[arg2] = { newcolor(arg2), time() }
		end
	end
	for k,v in p(caplist) do
		if k ~= player and v[2] < (time() - (len(gsub(k,"^(.-)%-.+","%1")) * 25)) then
			caplist[k] = nil
		end
	end
end
local citylist = {
	["Orgrimmar"] = true,
	["Thunder Bluff"] = true,
	["Undercity"] = true,
	["Shattrath City"] = true,
	["Stormwind City"] = true,
	["Ironforge"] = true,
	["Darnassus"] = true,
	["Dalaran"] = true,
	["Silvermoon City"] = true,
}

local function addplacename(place,zone)
	if place and place ~= "" then
		local gotcha = 0
		place,gotcha = gsub(place,"^"..Elo.THE.."%s(.*)$","%1",1)
		if (gotcha == 0 and len(place) > 6) then
--		find(place,"%A") or
--		not find(place,"s$") then
			local newkey = lower(place)
			newkey = top(place)
			newkey = gsub(newkey,"[%s:',]+","[%%s%%p]*")
			local kind = "Place"
			if not zone then 
				kind = "Subzone"
			elseif citylist[titlecap(place)] then
				kind = "City"
			elseif zone and IsInInstance() then
				kind = "Instance"
			end
			ElZones[place] = ElZones[place] or {newkey,kind}
		end
	end
end
local function addzoneandsubzone()
	if EloConfig.PlaceNames == 1 then
		local zone = GetRealZoneText()
		local sub = GetSubZoneText()
		addplacename(zone,1)
		addplacename(sub)
	end
end
local chuckfilter = {
	"chu[ck]+[%s%p]",
	"[%s%p]chu[ck]+$",
	"nor+is+",
	"vin%A*d[eia]+s+[eai]l",
	"y?o?u'?re?%A*m[aou]m",
	"y[ao]%A*m[aou]m",
	"s%A*m[aou]m",
	"jet+%A*l[ei]+",
	"bru+ce%A*lee+",
	"jackie%A*chan+",
	"r[ou]+nd%A*h[ou]+se",
	"back%A*fist",
	"^%A*d+a+g+e+r+%A*$",
	"ham+er%stime%A*$",
	"pew%A*pew",
	"kirby",
	"mike%A*j[oi]*nes",
	"%D%d%d%d%-%d%d%d%d%D",
	"[lL]%s[oO]%s[lL]%s[uU]%s[mM]%s[aA]%s[dD]",
	"[lL][oO][lL][uU][mM][aA][dD]",
	"[lL]_[lL]_[mM]_[dD]?",
	"[aA][nN][aA][lL]",
	"[aA]%s[nN]%s[aA]%s[lL]",
	"lol[u%a*]",

}
local function chuckfound(msg,guy,event,channel)
	if EloConfig.DefeatChuck == 1 and guy and channel and (Elo.DefaultChannels[gsub(channel,"^(%a+).*$","%1")] or event == "CHAT_MSG_YELL") and guy ~= player then
		for k,v in p(chuckfilter) do
			if find(lower(msg),v) then
				return true
			end
		end
	end
	return nil
end

local filtermessage = Elo.FilterMessage

local function postformat(msg)
	if shallweformat() then
		msg = gsub(msg,"[.?!]%s%l[%s%l]",titlecap)
		if not find(Elo.Event,"EMOTE") then
			msg = gsub(msg,"^[^!|/%a%d]+%l['%l%s]",titlecap)
			msg = gsub(msg,"^%l['%l%s]",titlecap)
		end
		if capstring and find(msg,"%S%s%S") then
			checkme,gotcha = gsub(checkme,"([nN])([tT])","%1%('?%)%2",1)
			if gotcha == 1 then
				capstring = gsub(capstring,"([nN])([tT])","%1%%1%2",1)
			end
			

			--debug(concat("Checkme: ",checkme," Capstring: ",capstring))


			msg = gsub(msg,checkme,capstring,1)
		end
		capstring = nil
		checkme = nil
		for k,v in p(urlTable) do
			msg = gsub(msg,"%f[%a][dD]ummyurl%s*"..k.."%.?",v,1)
		end
		if Elo.SelfAllCap and Elo.SelfAllCap >= len(msg) - 5 then
			msg = upper(msg)
		end
		Elo.SelfAllCap = nil
		if Elo.AddExclamation then
			msg = gsub(msg,"(%a%a%??)[.,/]+$","%1!" )
		end
		Elo.AddExclamation = nil
		for k,v in p(escapeTable) do
			msg = gsub(msg,"[zZ]mq%s*"..k,v,1)
		end

	end

	msg = filtermessage(msg,tildetypes)

	for k,v in p(itemTable) do
		msg = gsub(msg,	safecapture(v[1])..".-|h|r",
							v[1].."["..v[2].."]|h|r")
	end



--	Re-filter for compatability with other mods like Autofollow, Chatlink, etc.
	msg = gsub(msg,"^!%s*[fF]ollow%p*$","!follow")
	msg = gsub(msg,"{%s?[cC]link%s?:%s?","{CLINK:")

	return elogsub(msg,playertag,"")
end


---------------------------------------------------------------------
-- Initialize Settings on Variables Loaded
---------------------------------------------------------------------
local function defaultracetable()
	ElDat = {
		[Elo.Srv] = {
			["Suppress"] = { },
			["Alliance"] = { },
			["Horde"] = { },
			},
		}
end
local defaults = {
		["Custom"] = {

		},
		["Master"] = 1,
		["SelfOutgoing"] = 0,
		["PreviewKey"] = 0,
		["Self"] = { },
		["Others"] = { },
		["Monster"] = 0,
		["MonsterLink"] = 0,
		["BracketNuker"] = 0,
		["HideSplash"] = 0,
		["Header"] = 3,
		["QuellDuel"] = 0,
		["SquelchLoot"] = 0,
		["DefeatChuck"] = 0,
		["StopJoin"] = 0,
		["NoBarrage"] = 0,
		["ColorInChat"] = 0,
		["CTRaidColors"] = 0,
		["SkipNonEnglish"] = 0,
		["Colors"] = 0,
		["RandomColors"] = 0,
		["FeedbackMode"] = 0,
		["ZoneGather"] = 0,
		["NPCGather"] = 0,
		["NoRaidSpam"] = 0,
		["ChopServers"] = 0,
		["PlaceNames"] = 0,
		["PriceCheck"] = 0,
		["NoEnemyTaunt"] = 0,
		["AntiSpam"] = 0,
		["ChopRanks"] = 0,
		["ExpireLimit"] = 14,
		["Links"] = 2,
		["MaxLength"] = 200,
		["SumDisplay"] = 110,
		["SumTag"] = " and so on.",
		["EscapeTag"] = "=",
		["SafeTag"] = "-",
		["SumRGB"] = {1,1,1},
		["SumColor"] = Elo.Hue.white,
		["PlaceColor"] = Elo.Hue.white,
		["PlaceRGB"] = {1,1,1},
		["CityColor"] = Elo.Hue.yellow,
		["CityRGB"] = {1,1,0},
		["InstanceColor"] = Elo.Hue.green,
		["InstanceRGB"] = {0.6,1,0},
		["SubzoneColor"] = Elo.Hue.grey,
		["SubzoneRGB"] = {0.5,0.5,0.5},
		["SkipOOCSelf"] = 1,
		["SkipOOCOthers"] = 1,
		["SkipList"] = { },
		["SkipWordList"] = { },
		["AddonChannels"] = {
			["gem"] = true,
			["gemchanneldefault"] = true,
			["loremessaging"] = true,
			["loreskyisthelimit"] = true,
			["ctachannel"] = true,
			["xtensionxtooltip2"] = true,
			["guildadsglobal"] = true,
			["myroleplay"] = true,
	},
}
function Elo.RestoreDefaults()
	PlaySound("igSpellBookClose")
	for k,v in p(defaults) do
		if k ~= "AddonChannels" and k~= "Custom" then
			EloConfig[k]=v
		end
	end
	for k,v in p(Elo.RadioButtons) do
		EloConfig.Others[v[1]] = {true}
	end
end
local commonwhosearches = {
"orgrim","bluff","undercity","shattrath","storm","forge","forest","wood","black","valley","sili","vale","gulch","barren","hell","dal",
}
local function elosendwho(kind)
	if EloConfig[kind.."Gather"] == 1 then

		local place = GetRealZoneText()
--		debug(Elo.Hue.white..place)
		if len(place) > 3 then
			lastEvent.Who.Zone = place
		end
		if lastEvent.Who.Query == place then
			place = commonwhosearches[math.random(1,#(commonwhosearches))]
		else
			place = lastEvent.Who.Zone
		end

		if not WhoFrame:IsShown()
		and not FriendsFrame:IsVisible()
		and GetTime() > lastEvent.Who.Time + 10 then
--			debug("Last Place = ",lastEvent.Who.Zone,"Place = ",place,"Event = ",event)
			FriendsFrame:IsVisible()
			Elo.Suppress = true
			SendWho("z-\""..place.."\"")
			SetWhoToUI(1)
			debug("Sending who query for "..Elo.Hue.orange..place)
			lastEvent.Who.Time = GetTime()
			lastEvent.Who.Query = place

		end
	end
end
function Elo.OnEvent(event)
	if event ~= "UPDATE_MOUSEOVER_UNIT" then
		debug(event)
	end
	if event == "ADDON_LOADED" and arg1 == "Eloquence" then
		Elo.OnLoad()
	end
	if (event == "PLAYER_ENTERING_WORLD") then
		Elo.EnterWorld()
	end
	if EloConfig.Master == 1 then
		if (event == "FRIENDLIST_UPDATE") then
			Elo.ScanFriends()
		elseif event == "GUILD_ROSTER_UPDATE" then
			Elo.ScanGuild()
		elseif find(event,"ZONE_CHANGED") then
			Elo.ZoneChanged()
			elosendwho("Zone")
		elseif Elo.DialectsOn or EloConfig.Colors > 0 then
			if (event == "UPDATE_MOUSEOVER_UNIT") then
				if (UnitIsPlayer("mouseover") and UnitIsFriend("player","mouseover")) then
					Elo.AddUnitRaceData("mouseover")
				end
			elseif (event == "RAID_ROSTER_UPDATE") then
				Elo.ScanRaid()
			elseif (event == "PARTY_MEMBERS_CHANGED") then
				Elo.ScanParty()
			elseif (event == "WHO_LIST_UPDATE") then
				Elo.ScanWhoList()
			elseif (event == "PLAYER_LEVEL_UP") then
				playerLevelUp()
			else
				elosendwho("NPC")
			end
		end
	end
end

local function grabplayercolor(player)
	local val = ElDat[Elo.Srv][Elo.Faction][player]
	if val and val[2] and classcolor[EloConfig.CTRaidColors][val[2]] then
		return classcolor[EloConfig.CTRaidColors][val[2]]..player
	else
		local c = caplist[player] do
			if c then
				return c[1]..player
			end
		end
	end
	return Elo.Hue.grey..player
end



Elo.Faction = Elo.FactionTable[locUnitRace("player")]
local n = Elo.Info.name
local g = Elo.Hue.green
local regtable = {
	["Suppress"] = {
		[1] = n.." is suppressing these characters on "..Elo.Srv..":",
		[2] = n.."'s suppression list has been cleared.",
		[3] = n.." will no longer suppress "..g,
		[4] = n.." will now suppress "..g
	},
	["Skip"] = {
		[1] = n.." will skip filtering chat from the following players:",
		[2] = n.."'s skip list has been cleared.",
		[3] = n.." will no longer skip filtering "..g,
		[4] = n.." will now skip filtering "..g
	},
	["Skipword"] = {
		[1] = n.." will skip filtering messages that contain the following words:",
		[2] = n.."'s skipped word list has been cleared.",
		[3] = n.." will no longer skip messages containing "..g,
		[4] = n.." will now skip messages containing "..g
	},
	["Channel"] = {
		[1] = n.." will skip filtering the following channels:",
		[2] = n.."'s list of skipped channels has been cleared.",
		[3] = n.." will no longer skip "..g,
		[4] = n.." will now skip "..g
	},
};

function Elo.EnterWorld()
	Elo.CheckDialects()
	for i=1, GetNumLanguages() do
		langlist[(GetLanguageByIndex(i))] = true
	end
	Elo.AddUnitRaceData("player")
	if (Elo.UpdateOptions) then
		Elo.UpdateOptions()
	end
	if GetNumGuildMembers() > 0 then
		GuildRoster()
	end
	Elo.ClearOldEntries()
	Elo.ZoneChanged(1)
	this:UnregisterEvent("PLAYER_ENTERING_WORLD");
	Elo.UpdateFilters()
	Elo.EnterWorld = nil
end
---------------------------------------------------------------------
-- Belch Help Messages
---------------------------------------------------------------------
function Elo.ShowHelp(txt,lvl)
	print(Elo.Hue.green..Elo.Info.name..Elo.Info.version..txt)
	for line in gmatch(Elo.Help[lvl], "[^\n]+") do
		print(line)
	end
end
---------------------------------------------------------------------
-- Cycle or Toggle Variables
---------------------------------------------------------------------
function Elo.Cycle(val,max)
	if (EloConfig[val] == max) or (EloConfig[val] == nil) then EloConfig[val] = 0
	else EloConfig[val] = EloConfig[val]+1
	end
end
---------------------------------------------------------------------
-- Print Things to the Chat Frame
---------------------------------------------------------------------
function Elo.AddMsg(msg)
	print(Elo.Hue.yellow..Elo.Info.name..msg)
end
---------------------------------------------------------------------
-- Make Strings that Display On/Off Status
---------------------------------------------------------------------
local function bool(val)
	if (EloConfig[val] == 1) then
		s = "|cff00ff00 ON |r"
	else
		s = "|cff808080 OFF |r"
	end
	return s
end
---------------------------------------------------------------------
-- Slash Command Handler
---------------------------------------------------------------------
function Elo.SlashCmd(msg)
	local input = { };
	Elo.Temp = msg
	if ((not msg) or (strlen(msg) <= 0)) then
		if (Elo.UpdateOptions) then
			Elo.ToggleOptions() return
		else
			Elo.AddMsg("'s option window files not found.")
		end
	end
	if find(msg,"^%s?add%s") and find(msg,"=") then
		local before = gsub(msg,"^%s?add%s(.-)%s*=.*$","%1",1)
		local after = gsub(msg,"^.-=%s*(.*)$","%1",1)
		Elo.AddCustom(before,after)
	elseif find(msg,"^%s?del%s") then
		Elo.DeleteCustom(gsub(msg,"^%s?del%s(.*)$","%1"))
	else
		gsub(msg, "(%S+)", function (w) insert(input, w) end)
		if (input[1] == "on") then
			EloConfig.Master = 1;
			Elo.MainStatus()
		elseif (input[1] == "off") then
			EloConfig.Master = 0;
			Elo.MainStatus()
		elseif (input[1] == "toggle") then
			Elo.Cycle("Master",1)
			Elo.MainStatus()
		elseif (input[1] == "sendon") then
			EloConfig.SelfOutgoing = 1;
			Elo.MainStatus()
		elseif (input[1] == "sendoff") then
			EloConfig.SelfOutgoing = 0;
			Elo.MainStatus()
		elseif (input[1] == "send") then
			Elo.Cycle("SelfOutgoing",1)
			Elo.MainStatus()
		elseif (input[1] == "comrades") then
			Elo.Comrades(input[2])
		elseif (input[1] == "test") then
			EloOutputFrame:Show()
			if (input[2]) then
				local txt= ""
				table.remove(input,1)
				for k,v in p(input) do
					txt = txt.." "..v
				end
				Elo.Test(txt)
			end
		elseif (input[1] == "size") then
			Elo.Size()
		elseif (input[1] == "clear") then
			ElDat[Elo.Srv][Elo.Faction] = { }
			caplist[player] = { classcolor[EloConfig.CTRaidColors][Elo.ClassTable[UnitClass("player")]],}
			Elo.Size()
			local rd,ul,cd = Elo.RacialTable[locUnitRace("player")],UnitLevel("player"),Elo.ClassTable[UnitClass("player")]
			ElDat[Elo.Srv][Elo.Faction][player] = {[1] = rd, [2] = cd, [3] = ul, [4] = time()}
		elseif (input[1] == "help") then Elo.ShowHelp(" Basic Help",1)
		elseif (input[1] == "misc") then Elo.ShowHelp(" Misc Help",2)
		elseif (input[1] == "status") then
				Elo.MainStatus()
				Elo.DisplayStatus()
				Elo.MiscStatus()
		elseif (input[1] == "suppress") then Elo.Register(input,regtable["Suppress"],ElDat[Elo.Srv]["Suppress"])
		elseif (input[1] == "skip") then Elo.Register(input,regtable["Skip"],EloConfig.SkipList)
		elseif (input[1] == "skipword") then Elo.Register(input,regtable["Skipword"],EloConfig.SkipWordList)
		elseif (input[1] == "channel") then Elo.Register(input,regtable["Channel"],EloConfig.AddonChannels)
		elseif (input[1] == "list") then Elo.ListCustom()
		else Elo.ShowHelp(" Basic Help",1)
		end
	end
end
---------------------------------------------------------------------
-- Functions for Custom Filters
---------------------------------------------------------------------
function Elo.CheckCustom()
	for k,v in p(EloConfig.Custom) do
		if len(k) == 0 or len(v) == 0 then
			Elo.AddMsg(" has removed the custom filter \""..k.."\" = \""..v.."\".")
			EloConfig.Custom[k] = nil
		end
	end
end
function Elo.AddCustom(before,after)
	if len(before) > 0 and len(after) > 0 then
		Elo.AddMsg(" will now filter \""..before.."\" into \""..after.."\".")
		EloConfig.Custom[safecapture(before)] = after
	else
		Elo.AddMsg(" cannot process this request.")
	end
end
function Elo.ListCustom()
	local list = { }
	Elo.AddMsg(" is applying the following custom filters:")
	for k,v in p(EloConfig.Custom) do
		insert(list,k)
	end
	table.sort(list,alphabetize)
	for k,v in p(list) do
		print(g..unsafecapture(v).." = "..EloConfig.Custom[list[k]])
	end
end
function Elo.DeleteCustom(msg)
	if EloConfig.Custom[safecapture(msg)] then
		Elo.AddMsg(" will no longer apply a custom filter to \""..unsafecapture(msg).."\"")
		EloConfig.Custom[safecapture(msg)] = nil
	else
		Elo.AddMsg(" has no custom entry for \""..unsafecapture(msg).."\"")
	end
end
---------------------------------------------------------------------
-- Report the Number of Player Entries
---------------------------------------------------------------------
function Elo.Size(flag)
	local c,t = 1,0
	if not flag then Elo.AddMsg(" has gathered entries for") end
	for x,y in p(ElDat) do
		c = 0
		for k,v in p(y["Alliance"]) do
			c = c + 1
		end
		for k,v in p(y["Horde"]) do
			c = c + 1
		end
		if c > 0 then
			if not flag then print(Elo.Hue.grey..c.."|r on "..s..".") end
		end
		t = t + c
	end
	if not flag then print(Elo.Hue.yellow..t.." players total.") end
	return t
end
---------------------------------------------------------------------
-- Register/delete players, channels, etc from their lists
---------------------------------------------------------------------

function Elo.Register(input,msgtable,datatable)
	if not input or not input[2] then
			print(Elo.Hue.yellow..msgtable[1])
		local tab = { }
		for k,v in p(datatable) do
			insert(tab,k)
		end
		table.sort(tab,alphabetize)
		for k,v in p(tab) do
			print(k..". "..v)
		end
	elseif (input[2] == "clear") then
		for i,j in p(datatable) do 
			datatable[i] = nil
		end
		print(Elo.Hue.yellow..msgtable[2])
	else
		local dude = input[2]
		if msgtable == regtable["Skipword"] then
			dude = lower(dude)
		elseif (input[1] == "suppress" or input[1] == "skip") and UnitName(input[2]) then
			dude = UnitName(input[2])
		else
			dude = titlecap(dude)
		end
		if input[3] then dude = dude.." "..titlecap(input[3]) end
		if (datatable[dude]) then
			datatable[dude] = nil
			print(Elo.Hue.yellow..msgtable[3]..dude..".")
		else
			datatable[dude] = true
			print(Elo.Hue.yellow..msgtable[4]..dude..".")
		end
	end
end
function Elo.Comrades(flag)
	local c,t = 0,""
	for a in Elo.List do
		for x in Elo.List[a] do
			c = c + 1
			if flag == "add" then
				EloConfig.SkipList[x] = true
				t = "added"
			else
				EloConfig.SkipList[x] = nil
				t = "removed"
			end
		end
	end
	Elo.AddMsg(": "..c.." friends/guildmates "..t..".")
end
---------------------------------------------------------------------
-- Run a Thorough Test and See the Results in the Feedback Console
---------------------------------------------------------------------
function Elo.Test(msg)
--	EloOutputFrame:Show()
	EloChatFrame:AddMessage(Elo.Hue.yellow.."Text: "..msg)
	msg = preformat(msg,EloConfig.Colors)
	EloChatFrame:AddMessage(Elo.Hue.grey.."Preformat: "..msg)
	if capstring then
		--debug(Elo.Hue.grey.."Cap String: "..capstring)
	end
	Elo.Event = "CHAT_MSG_WHISPER"
	msg = pickfilter(msg)

	msg = postformat(msg)
	msg = gsub(msg,"^[^!|%a%d]*%l['%l%s]",titlecap)

	if capstring and find(msg,lower(capstring)) then
		msg = gsub(msg,lower(capstring),upper,1)
		msg = gsub(msg,"%u%u%l+",upper)
		capstring = nil
	end
	EloChatFrame:AddMessage(Elo.Hue.yellow..msg)
end
---------------------------------------------------------------------
-- Display the Status of the Addon
---------------------------------------------------------------------
function Elo.MainStatus()
	print(Elo.Hue.yellow..Elo.Info.name..Elo.Info.version.."|r is"..bool("Master"))
end

function Elo.DisplayStatus()
	if (EloConfig.Master == 0) then
		local status	= bool("Master")
		print(Elo.Hue.yellow..Elo.Info.name..Elo.Info.version.."|r is"..status)
		return
	end
	print(Elo.Hue.yellow..Elo.Info.name.." Display Options:")
	print(
				"Color by Class:"		..bool("Colors")..
				"Random if Unknown:"	..bool("RandomColors")..
				"Color inside Chat:"	..bool("ColorInChat")..
				"Thwart Chat Spam:"	..bool("AntiSpam")..
				"Quell Duel Spam:"	..bool("QuellDuel")..
				"Squelch Coin Spam:"	..bool("SquelchLoot")..
				"Defeat Chuck Norris:"..bool("DefeatChuck")..
				"No PvP Ranks:"		..bool("ChopRanks")..
				"Eradicate Brackets:"	..bool("BracketNuker")..
				"Hide Splash Message:"..bool("HideSplash")
				)
end	
local headerstyle = {
	[0] = "|cffffff00 Default |r",
	[1] = "|cff808080 OFF |r",
	[2] = "|cffffff00 First letter |r",
	[3] = "|cffffff00 Numerical |r",
	[4] = "|cffffff00 No Numbers |r",
}
local linkstyle = {
	[0] = "|cff808080 OFF |r",
	[1] = "|cffffff00 Classic |r",
	[2] = "|cffffff00 Debug |r",
}
function Elo.MiscStatus()
	if (EloConfig.Master == 0) then
		print(Elo.Hue.yellow..Elo.Info.name..Elo.Info.version.."|r is"..bool("Master"))
		return
	end
	local msg = "Channel headers:"..headerstyle[EloConfig.Header].."Links:"..linkstyle[EloConfig.Links]
	if EloConfig.Links > 0 then
		msg = msg.."(Lines over |cffffff00"..EloConfig.MaxLength.."|r characters trimmed to |cffffff00"..EloConfig.SumDisplay.."|r and tagged with \"|cffffff00"..EloConfig.SumTag.."|r\")"
	end
	print(Elo.Hue.yellow..Elo.Info.name.." Misc Status:")
	print(msg)
end
---------------------------------------------------------------------
-- Collect Players' Race Info
---------------------------------------------------------------------
function Elo.AddUnitRaceData(obj)
	local un, us = UnitName(obj)
	if us then un = un.."-"..us end
	Elo.AddRaceData(un,UnitLevel(obj),locUnitRace(obj),UnitClass(obj))
end


function Elo.AddRaceData(un,ul,ur,uc)
	if un and ul and uc and Elo.ClassTable[uc] then

		local racenum = Elo.RacialTable[ur]

		ul = tonumber(ul)
		if ul > 0 and ul < 81 then
			if racenum or not ElDat[Elo.Srv][Elo.Faction][un] then
				ElDat[Elo.Srv][Elo.Faction][un] = {
					[1] = racenum,
					[2] = Elo.ClassTable[uc],
					[3] = ul,
					[4] = time(),
				}
			else
				ElDat[Elo.Srv][Elo.Faction][un][2] = Elo.ClassTable[uc]
				ElDat[Elo.Srv][Elo.Faction][un][3] = ul
				ElDat[Elo.Srv][Elo.Faction][un][4] = time()
			end
			Elo.FormatDataScrollFrame()
			return true
		end
	end
end

function Elo.WhoHandler(msg,...)
	if Elo.Suppress == true then
		if msg and msg == "" then
			msg = WhoFrame_GetDefaultWhoCommand();
			ShowWhoPanel();
		end
		SendWho(msg,...);
	else
		Elo.OldWhoHandler(msg,...);
	end
end



function Elo.ClearOldEntries()
	local tally = 0
	for x,y in p(ElDat) do
		for f,g in p(y) do
			for n,m in p(g) do
				if find(n,"%-") then
					ElDat[x][f][n] = nil
					tally = tally + 1
				elseif type(m) == "table" then
					if m[4] == nil then
						ElDat[x][f][n][4] = time()
					elseif type(m[4]) == "number"
					and (m[4] + (3600 * 24 * EloConfig.ExpireLimit) < time()) and
					m ~= player then
						ElDat[x][f][n] = nil
						tally = tally + 1
					end
				end
			end
		end
	end
	if tally > 0 then
		--debug(tally.." entries cleared.")
	end
end
function Elo.ScanFriends()
	if (GetTime() > lastEvent.Friend + 30) and GetNumFriends() > 0 then
		Elo.List.Friends = { }
		for c = 1, GetNumFriends() do
			local un, ul, uc = GetFriendInfo(c)
			if Elo.AddRaceData(un,ul,nil,uc) then
				Elo.List.Friends[un] = true
			end
		end
		lastEvent.Friend = GetTime()
	end
end
function Elo.ScanGuild()
	if (GetTime() > lastEvent.Guild + 1) and GetNumGuildMembers() > 0 then
		--debug("Found "..GetNumGuildMembers().." guild results.")
		Elo.List.Guild = { }
		for c = 1, GetNumGuildMembers() do
			local un, _, _, ul, uc = GetGuildRosterInfo(c)
			if un ~= player then
				if Elo.AddRaceData(un,ul,nil,uc) then
					Elo.List.Guild[un] = true
				end
			end
		end
		lastEvent.Guild = GetTime()
	end
end
function Elo.ScanParty()
	local num = GetNumPartyMembers()
	if (GetTime()  > lastEvent.Party + 1) and
	GetNumRaidMembers() == 0 and
	num > 0 then
	if Elo.DialectsOn or EloConfig.Colors > 0 then
			Elo.ScanEither("party",num)
		end
		lastEvent.Party = GetTime()
	end
end
function Elo.ScanRaid()
	if (Elo.DialectsOn or EloConfig.Colors > 0) and
	GetTime() > lastEvent.Raid + 1 and
	GetNumRaidMembers() > 0 then
		Elo.ScanEither("raid",GetNumRaidMembers())
		lastEvent.Party = GetTime()
	end
end
function Elo.ScanEither(type,num)
	if num and num > 0 then
	--debug("Found "..num.." "..type.." results.")
		local obj = ""
		for c = 1,num do
			obj = type..c
			Elo.AddUnitRaceData(obj)
		end
	end
end
function Elo.ScanWhoList()
	local num = GetNumWhoResults()
	if num and num > 0 then
		for c = 1,num do
			local un, _,ul, ur, uc = GetWhoInfo(c);
			Elo.AddRaceData(un,ul,ur,uc)
		end
		Elo.Suppress = nil
		SetWhoToUI(0)
	end
end
function playerLevelUp()
	Elo.AddRaceData(player,arg1,locUnitRace("player"),UnitClass("player"))
end
---------------------------------------------------------------------
-- Logic for Updating the Filters.
---------------------------------------------------------------------
function Elo.UpdateFilters()
	Elo.ScanFriends()
	Elo.ScanGuild()
	systemspam = { }
	if EloConfig.QuellDuel == 1 then
		systemspam = {"drunk","tipsy","smashed","sobering up","in a duel","from a duel"}
	end
	if EloConfig.SquelchLoot == 1 then
		insert(systemspam,1,"Your share of the loot is")
	end
	if EloConfig.NoRaidSpam == 1 then
--		insert(systemspam,1,"ha[sve]+ %a+ the battle")
		insert(systemspam,1,"ha[sve]+ %a+ the raid")
	end

	if EloConfig.BracketNuker == 1 then
		EloConfig.SumTag = gsub(EloConfig.SumTag,"^%s*(%a)","%1")
	else
		EloConfig.SumTag = gsub(EloConfig.SumTag,"^(%a)"," %1")
	end
	if EloConfig.SafeTag == "" then
		EloConfig.SafeTag = defaults.EscapeTag
	end
	if EloConfig.EscapeTag == "" then
		EloConfig.EscapeTag = defaults.EscapeTag
	end
	if EloConfig.Monster == 1 then
		eventtable["CHAT_MSG_MONSTER_EMOTE"] = "Say"
		eventtable["CHAT_MSG_MONSTER_SAY"] = "Say"
		eventtable["CHAT_MSG_MONSTER_WHISPER"] = "Whisper"
		eventtable["CHAT_MSG_MONSTER_YELL"] = "Yell"
		eventtable["CHAT_MSG_RAID_BOSS_EMOTE"] = "Say"
	elseif EloConfig.MonsterLink == 1 then
		eventtable["CHAT_MSG_MONSTER_EMOTE"] = "dummy"
		eventtable["CHAT_MSG_MONSTER_SAY"] = "dummy"
		eventtable["CHAT_MSG_MONSTER_WHISPER"] = "dummy"
		eventtable["CHAT_MSG_MONSTER_YELL"] = "dummy"
		eventtable["CHAT_MSG_RAID_BOSS_EMOTE"] = "dummy"
	else
		eventtable["CHAT_MSG_MONSTER_EMOTE"] = nil
		eventtable["CHAT_MSG_MONSTER_SAY"] = nil
		eventtable["CHAT_MSG_MONSTER_WHISPER"] = nil
		eventtable["CHAT_MSG_MONSTER_YELL"] = nil
		eventtable["CHAT_MSG_RAID_BOSS_EMOTE"] = nil
	end

	Elo.ZoneChanged()
	if EloConfig.Links > 0 then
		if SCCN_clickinvite == 1 then
			Elo.AddMsg("'s Chat Links: SCCN compatibility for \"click to invite\" enabled.") 
		end
		if SCCN_hyperlinker == 1 then
			Elo.AddMsg("'s Chat Links: SCCN compatibility for hyperlinked URLs enabled.") 
		end
		if ChatBox then
			Elo.AddMsg(": Chat Links disabled for compatibility with ChatBox.")
			EloConfig.Links = 0
		end
	end
	Elo.CheckCustom()
end
---------------------------------------------------------------------
-- Check Current Zone Name and Tweak Filters Accordingly
---------------------------------------------------------------------
local function filterbyzone(zone)
	local gotcha
	for k,v in p(Elo.ZoneFilter) do
		if find(v["search"],lower(zone)) then
			gotcha = v
		else
			if v["out"] then
				compilefilters(v["out"],2)
			else
				for c,d in p(v["in"]) do
					for x,y in p(d) do
						local frontx = makefrontier(x,y)
						codex[c][frontx] = nil
					end
				end
			end
		end
	end
	if gotcha then
		compilefilters(gotcha["in"],2)
		debug("Setting zone filters for "..gotcha["search"])
	end
end
local rawline = ""
function Elo.ZoneChanged(override)
	addzoneandsubzone()
	local zone = GetRealZoneText()
	if zone and zone ~= "" then
		if override or (not UnitOnTaxi("player") and zone ~= Elo.ActiveZone) then
			filterbyzone(zone)
			rawline = ""
			Elo.ActiveZone = zone
		end
	end
end
---------------------------------------------------------------------
-- Filter Outgoing Chat Message
---------------------------------------------------------------------
local function filterownmessage(msg,syst,chan)
	local channame
	speaker = player
	if chan then _, channame = GetChannelName(chan) end
	if syst == "CHANNEL" and channame then
		if not Elo.DefaultChannels[gsub(channame,"^(%a+).*$","%1")] then
			syst = "CUSTOM"
		end
	end
	if EloConfig.Self[eventtable[syst]] and checkchannels(msg,channame,syst) and oktofilter(msg) then
		Elo.Event = syst
		msg = preformat(msg,0,channame)
		msg = pickfilter(msg)
		msg = postformat(msg)
	end
	return msg
end

local function restorebrackets(msg)
	msg = gsub(msg,"(|H%a+:[%d:-]+|h)([^%[])","%1[%2")
	msg = gsub(msg,"(|H.-[^%]])|h|r","%1]|h|r")
	msg = gsub(msg,"%[%l",upper)
	return msg
end

local function ismodifierdown()
	local b = Elo.PreviewKeyList[EloConfig.PreviewKey][2]
	return b()
end

local function elosendchatmessage(msg,sys,lang,chan,...)
	if msg then
		if EloConfig.Master == 1 then
			if addguildchannels then addguildchannels() end
			if EloConfig.SelfOutgoing == 1 then
				local s = safecapture(EloConfig.SafeTag)
				if find(msg,"^"..s) then
					msg = gsub(msg,"^"..s.."(.*)$","%1")
				else
					msg = filterownmessage(msg,sys,chan)
				end
			end
		end
		msg = restorebrackets(msg)
	end
	if not ismodifierdown() then
		Elo.OldSendChatMessage(msg,sys,lang,chan,...)
	end
end
local rawout
local prev
local function zing()
	PlaySoundFile("Sound\\Interface\\MagicClick.wav");
end
local function elochatedit_onescapepressed(editBox,...)
	local msg = editBox:GetText()
	if ismodifierdown() and EloConfig.Master == 1 and not find(msg,"^%s*/") then
		msg = restorebrackets(msg)
		local type = editBox:GetAttribute("chatType")
		local target = editBox:GetAttribute("channelTarget")
		if len(msg) > 0 then
			if rawout then
				if msg == prev then
					PlaySound("UChatScrollButton")
					editBox:SetText(rawout)
					rawout = nil
				else
					rawout = msg
					prev = filterownmessage(msg,type,target)
					editBox:SetText(prev)
					zing()
				end
			else
				rawout = msg
				prev = filterownmessage(msg,type,target)
				editBox:SetText(prev)
				zing()
			end
		end
		return
	else

		rawout = nil
		Elo.OldChatEdit_OnEscapePressed(editBox,...)
	end

end


---------------------------------------------------------------------
-- Handle Incoming Chat Events
---------------------------------------------------------------------
local header,headerfound,doneline
local function incomingmessage(msg,x)
		if arg2 and
		checkchannels(msg,arg9,Elo.Event) then
			if msg == rawline and
			arg2 == speaker then
				msg = doneline
			elseif not find(msg,"|Hxhmsg:") and not find(msg,"^<GEM") then
				speaker = gsub(arg2, "^.-(%S+)$", "%1")

				rawline = msg
				if (EloConfig.Colors > 0) and
				(EloConfig.ColorInChat + EloConfig.RandomColors > 0) then
					addplayer(arg2)
				end
				if speaker == player or
				Elo.Event == "CHAT_MSG_WHISPER_INFORM" then
					if EloConfig.SelfOutgoing == 1 or find(Elo.Event,"EMOTE") then
						msg = capcolorname(msg,EloConfig.ColorInChat)
						msg = gsub(formatclass(msg),playertag,"")
					elseif EloConfig.Self[eventtable[Elo.Event]] and oktofilter(msg) then
						if (EloConfig.SelfOutgoing == 0) then
							msg = pickfilter(preformat(msg,EloConfig.ColorInChat,arg9))
						end
						msg = postformat(msg)
					end
				elseif EloConfig.Others[eventtable[Elo.Event]] and not EloConfig["SkipList"][speaker] and oktofilter(msg) then
					msg = preformat(msg,EloConfig.ColorInChat,arg9)
					if islangknown(arg3) then
						msg = pickfilter(msg)
					end
					msg = postformat(msg)
				end


				if EloConfig.PlaceNames == 1 then
					for k,v in p(ElZones) do
						msg = gsub(msg,"%f[%a]"..v[1].."%f[^%a%d]",EloConfig[v[2].."Color"]..k.."|r")
					end
				end
				if EloConfig.Colors > 0 and EloConfig.Links ~= 1 then
					msg = formatclass(msg)
				end

				if arg2 and
				(emoteevents[Elo.Event] == nil) and
				(not find(Elo.Event,"MONSTER") or EloConfig.MonsterLink ~= 0) and
				(EloConfig.Links > 0 and arg2 ~= "") and
				(SCCN_clickinvite ~= 1 or not find(rawline,"[iI]nv")) and
				(not find(rawline,"<XR>")) and
				(SCCN_hyperlinker ~= 1 or #(urlTable) == 0) then
--						if not find(msg,"|c.-|r") and not find(msg,"|H.-|h") then
					if not find(msg,"|H.-|h") then
						local clickme = gsub(msg,"|+%f[^cr]","/")
						local linkstart = "|Helomsg:"..arg2.."<ELO>"
						local hl = len(header)
						if x == 0 then hl = len(arg2) end
						if len(msg) + hl > EloConfig.MaxLength and
						arg2 ~= player and
						Elo.Event ~= "CHAT_MSG_WHISPER_INFORM" then
							if (EloConfig.Links == 2) then
								msg = gsub(rawline,"|","/")
							end
							local showchat = sub(clickme,1,EloConfig.SumDisplay  - len(arg2))

							showchat = gsub(showchat,"%a+$","")
							showchat = gsub(showchat,"%s?|c[%a%d]+$"," ")
							showchat = gsub(showchat,"([%a%d])[^%a%d]+$","%1 ")

							msg = concat(linkstart,msg,"|h",showchat,EloConfig.SumColor,EloConfig.SumTag,"|h|r")
						else
							if EloConfig.Links == 1 and not find(msg,"|r") then
							msg = concat(linkstart,msg,"|h",gsub(clickme,"^%s*(.-)%s*$","%1"),"|h|r")

							elseif EloConfig.Links == 2 then
							msg = concat(linkstart,gsub(rawline,"|","/"),"|h",gsub(clickme,"^%s*(.-)%s*$","%1"),"|h|r")
							end
						end
					end


				end
				doneline = msg
			end

		end


		return msg
end

local synlist = {
	["says"] = {
		"shares a gem of wisdom",
		"divulges something keen",
		"offers encouragement",
		"cackles maniacally",
		"boasts righteously",
		"waxes eloquent",
		"frames the issue",
		"speaks rhetorically",
		"quotes a passage",
		"babbles ad nauseum",
		"discusses a topic",
		"mutters some gibberish",
		"insists on speaking",
		"curses indignantly",
		"conveys sympathy",
		"offers some advice",
		"rambles on",
		"apologizes",
		"utters a phrase",
		"makes a point",
		"mentions something",
		"talks",
		"says a phrase",
		"says a few words",
		"says something",
		"says some words",
		"asks a question",
		"speaks fluently",
		"shares a thought",
		"makes a request",
		"sighs sullenly",
		"points something out",
		"expresses an opinion",
		"giggles cheerfully",
		"spouts some nonsense",
		"complains relentlessly",
		"begins a lecture",
		"drones monotonously",
		"concedes the point",
		"sums up the situation",
		"speculates whimsically",
		"delivers a quick rebuttal",
		"confesses a secret",
		"appeals to reason",
		"pleads innocence",
		"gives a lame excuse",
		"flies off on a tangent",
		"conveys a profound concept",
	},
	["yells"] = {
		"snarls vulgarly",
		"blurts something out",
		"howls like a beast",
		"barks orders",
		"proclaims something",
		"roars ferociously",
		"shouts with authority",
		"shrieks",
		"gives a shout",
		"screams",
		"shouts some words",
		"shouts",
		"yells",
		"yells something",
		"shouts an order",
		"howls",
		"roars",
		"cries out",
		"roars menacingly",
		"shouts vigorously",
		"shouts defiantly",
		"wails",
		"curses vehemently",
		"announces something",
		"bellows with rage",
		"howls furiously",
		"cries to the heavens",
		"screeches with pain",
	},
}
local function weight(list)
	local a = #(list) / 3
	local z = math.floor(math.random(a) + math.random(a) + math.random(a))
	return list[z]
end
local function makesyn(kind)
	local s = synlist[kind][math.random(#(synlist[kind]))]
end

local lasttime = 0
local lastspeaker = ""
local lastself

local function newaddmessage(self,msg,...)
		if msg and EloConfig.Master == 1 then
--CHECK

--			if type(EloForSave) == "table" and arg1 and event then
--				insert(EloForSave,{msg,arg1,event})
--			end

			if event == "CHAT_MSG_CHANNEL_NOTICE" and EloConfig.StopJoin == 1 then
				return
			elseif event == "CHAT_MSG_SYSTEM" or
			event == "CHAT_MSG_MONEY" then
				if msg == INSTANCE_SAVED then return end
				for racename,num in p(Elo.RacialTable) do
					for name,lvl,race,cls in gmatch(msg,"|Hplayer:([^%s|]+)|h.-|h:%s"..LEVEL.."%s(%d+)%s("..racename..")%s(%a+)") do
						Elo.AddRaceData(name,lvl,race,cls)
					end
				end
				for k,v in p(systemspam) do
					if (find(msg,v)) then
						debug("Elo hid "..msg)
						return
					end
				end
			end



			if event == "CHAT_MSG_CHANNEL" and
			not Elo.DefaultChannels[gsub(arg9,"^(%a+).*$","%1")] then
				Elo.Event = "CHAT_MSG_CUSTOM"
			else
				if arg2 ~= player and not EloConfig.SkipList[arg2] and nukewts(msg,arg9) then
					debug("Suppressing",arg9,": ",msg)
					return
				end
				Elo.Event = event
			end
			if arg2 and eventtable[Elo.Event] and not EloConfig.SkipList[arg2] then
				if ElDat[Elo.Srv]["Suppress"][arg2] then
					debug("Suppressing",arg9,": ",msg)
					return
				elseif (EloConfig.AntiSpam == 1 or EloConfig.NoBarrage == 1) and
				EloConfig.Others[eventtable[Elo.Event]] and
				not monsterevents[Elo.Event] and
				Elo.Event ~= "CHAT_MSG_WHISPER_INFORM" and
				arg2 ~= player and
				not Elo.List.Guild[arg2] and
				not Elo.List.Friends[arg2] then
					for k,v in p(spamlist[self]) do
						if EloConfig.NoBarrage == 1 and k == 2 and v[1] == arg2 and v[3] == time() then
							debug("Elo hid spam: ",msg)
							return
						elseif EloConfig.AntiSpam == 1 and v[1] == arg2 and v[2] == arg1 then
							debug("Elo hid spam: ",msg)
							return
						end
					end
					insert(spamlist[self],1,{arg2,arg1,time()})
					spamlist[self][4] = nil
				end
				if chuckfound(msg,arg2,event,arg9) then
					debug("Suppressed "..arg2..": "..msg)
					return
				end
				local txt = gsub(arg1,"^%s*%%s","")
				header,headerfound = gsub(msg,"^(.-)"..safecapture(txt).."$","%1",1)
				local filtered = incomingmessage(txt,headerfound)
				if not filtered then
					debug("Elo hid ",msg)
					return
				end
				if headerfound == 1 then
					msg = concat(header,filtered)
				end
-- Reduce double percentages. They always pop up twice somewhere after filtration. No idea why.
-- CHECK %
				msg = gsub(msg,"%%+","%%")

				if EloConfig.NoEnemyTaunt == 1 then
					if islangknown(arg3) ~= true then
						if find(msg,"<ELO>") then
							msg = gsub(msg,"^(.-)(%a%a%a-s):.-(|Helomsg:.-|h).-|h|r",function(a,b,c)
								return a..weight(synlist[b])..c.." in "..arg3..".|h|r"
								end
							)

--	[1] = "Samantha Shackleton says: [Gutterspeak] |Helomsg:Shackleton<ELO>shown in box|hClick me|h|r",


						else
							msg = gsub(msg,"^(.-)(%a%a%a-s): %[.*$",function(a,b)
								return a..weight(synlist[b]).." in "..arg3.."."
								end
							)
						end
					end
				end


				if EloConfig.ChopRanks > 0 then
					msg = gsub(msg,Elo.RankedChan,"%1%2")
				end
				if EloConfig.Colors > 0 and
				SCCN_colornicks ~= 1 then
					local guy = ElDat[Elo.Srv][Elo.Faction][arg2]
					local safesearch = safecapture(arg2)
					local ct = EloConfig.CTRaidColors
					if guy then
						if guy[2] and guy[3] then
							if EloConfig.Colors == 3 then
								msg = gsub(msg, "%["..safesearch,"["..classcolor[ct][guy[2]]..speaker.."|r ("..guy[3]..")", 1)
							elseif EloConfig.Colors == 2 then
								msg = gsub(msg, "%["..safesearch,"[("..guy[3]..") "..classcolor[ct][guy[2]]..speaker.."|r", 1)
							elseif EloConfig.Colors == 1 then
								msg = gsub(msg, "%["..safesearch,"["..classcolor[ct][guy[2]]..speaker.."|r", 1)
							end
						end
					elseif EloConfig.RandomColors > 0 then
						local c = caplist[arg2]
						if c then
							if monsterevents[event] then
								msg = gsub(msg, "^"..safecapture(arg2), c[1]..arg2.."|r")
							else
								msg = gsub(msg, "%["..safecapture(speaker), "["..c[1]..speaker.."|r", 1)
							end
						end
					else
						if monsterevents[event] then
							msg = gsub(msg, "^"..safecapture(arg2), Elo.Hue.grey..arg2.."|r")
						else
							msg = gsub(msg, "%["..safecapture(speaker), "["..Elo.Hue.grey..speaker.."|r", 1)
						end
					end
				end
				if EloConfig.ChopServers > 0 and find(arg2,"%-") then
					msg = gsub(msg,"(|Hplayer:.-%S%-%S.-%S)%-%u[%a%s%d'-]+(.-|h)","%1 (*)%2",1)
				end
				msg = filtermessage(msg,Elo.HeaderSettings[EloConfig.Header],1)

				msg = gsub(msg,playertag,"")



--CHECK
--				if type(EloForSave) == "table" and arg1 and event then
--					insert(EloForSave,{msg,arg2,event})
--				end

			end

			if EloConfig.BracketNuker > 0 then
				msg = filtermessage(msg,bracketFilter)
			end
			msg = trim(msg)

		end
		self:EloOldAddMessage(msg,...)
	end





function Elo.RaidWarningFrame_OnEvent(event, msg, ...)
	if EloConfig.Master == 1 and event == "CHAT_MSG_RAID_WARNING" then
		Elo.Event = event
		speaker = arg2
		if arg2 == player then
			if EloConfig.SelfOutgoing == 1 then
				msg = capcolorname(msg,EloConfig.ColorInChat)
				msg = gsub(formatclass(msg),playertag,"")
			elseif EloConfig.Self[eventtable[Elo.Event]] and oktofilter(msg) then
				if (EloConfig.SelfOutgoing == 0) then
					msg = pickfilter(preformat(msg,EloConfig.ColorInChat))
				end
				msg = postformat(msg)
			end
		elseif EloConfig.Others[eventtable[Elo.Event]] and oktofilter(msg) then
			msg = pickfilter(preformat(msg,EloConfig.ColorInChat))
		end
	end
	Elo.OldRaidWarningFrame_OnEvent(event, msg, ...)
end

local function hooksetitemref()
	local prevplayer,prevchat
	local ert = EloRefTooltip
	local ereb = EloRefEditBox
	function SetItemRef(link, text, button, ...)
		for guy, chat in gmatch(link, "elomsg:(.-)<ELO>(.+)$") do
			if (ert:IsVisible() and guy == prevplayer and chat == prevchat) then
				ert:Hide()
				prevplayer,prevchat = "",""
			else
				prevplayer,prevchat = guy,chat
				EloRefPlayer:SetText(guy)
				EloRefChat:SetText(chat)

				local totalpix = EloRefChat:GetStringWidth()
				local ypixel = EloRefChat:GetHeight()
				local playerpix = EloRefPlayer:GetStringWidth()
				EloRefPlayer:SetText("")
				EloRefChat:SetText("")
				local xpixel = 240
				if totalpix < 240 then
					if totalpix < playerpix + 20 then
						xpixel = playerpix + 20
					else
						xpixel = totalpix
					end
				end
				if xpixel > 240 then xpixel = 240 end
				if EloConfig.Colors > 0 then
					guy = grabplayercolor(guy)
				else
					guy = Elo.Hue.yellow..guy
				end
				if (not ert:IsOwned(UIParent)) then
					ert:SetOwner(UIParent, "ANCHOR_PRESERVE")
				end
				ert:ClearLines()
				ert:AddLine(guy..": ", 1, 1, 0)
				ert:Show()
				ert:SetHeight(ypixel + 40);
				ert:SetWidth(xpixel + 25);
				ereb:ClearFocus();
				ereb:SetHeight(ypixel);
				ereb:SetWidth(xpixel);
				ereb:SetText(chat)
				PlaySoundFile("Sound\\Creature\\Rat\\Rat\\FootstepRat3A.wav");
			end
			return;
		end
		previous = nil;
		Elo.OldSetItemRef(link, text, button, ...)
	end
end
---------------------------------------------------------------------
-- Initialize Logic on Addon Load
---------------------------------------------------------------------
function Elo.OnLoad()
	local regtable = {
	"ZONE_CHANGED",
	"ZONE_CHANGED_NEW_AREA",
	"ZONE_CHANGED_INDOORS",
	"MINIMAP_ZONE_CHANGED",
	"PARTY_MEMBERS_CHANGED",
	"PLAYER_LEVEL_UP",
	"RAID_ROSTER_UPDATE",
	"WHO_LIST_UPDATE",
	"UPDATE_MOUSEOVER_UNIT",
	"FRIENDLIST_UPDATE",
	"GUILD_ROSTER_UPDATE",
	"MERCHANT_CLOSED",
	"AUCTION_HOUSE_CLOSED",
	"GOSSIP_CLOSED",
	"QUEST_FINISHED"
	}
	for k,v in p(regtable) do
		this:RegisterEvent(v)
	end
	if Elo.Faction == "Horde" and Elo.HordeDialect then
		Elo.HordeDialect()
	elseif Elo.AllianceDialect then
		Elo.AllianceDialect()
	end

	createcompilation()
	if EloConfig then
		for k,v in p(EloConfig) do
			if not defaults[k] then
				EloConfig[k] = nil
			end
		end
		for k,v in p(defaults) do
			if not EloConfig[k] then
				EloConfig[k] = defaults[k]
			elseif type(EloConfig[k]) == "table" then
				for x,y in p(defaults[k]) do
					if not EloConfig[k][x] then
						EloConfig[k][x] = defaults[k][x]
					end
				end
			end
		end
	else
		debug("No config found; creating default values")
		EloConfig = defaults
		for k,v in p(Elo.RadioButtons) do
			EloConfig.Others[v[1]] = {true}
		end
	end

	Elo.AllianceDialect = nil
	Elo.HordeDialect = nil
	if EloConfig.FeedbackMode ~= 1 then
		Elo.GrammarNazi = nil
		Elo.Typos = nil
		Elo.Abbrevations = nil
		Elo.ActingCoach = nil
		Elo.Race = nil
	end

	local a = Elo.Hue.yellow..Elo.Info.name..Elo.Info.version.."|r "
	local b = ""
	if not ElDat then
		defaultracetable()
	elseif not ElDat[Elo.Srv] then
		ElDat[Elo.Srv] = {
			["Suppress"] = { },
			["Alliance"] = { },
			["Horde"] = { },
		}
		b = a.."Creating new entry for |cffff6d00"..Elo.Srv.."|r.\n"
	else b = a
	end

	Elo.AddUnitRaceData("player")

	if not ElDat[Elo.Srv]["Suppress"] then ElDat[Elo.Srv]["Suppress"] = { } end
	caplist[player] = { classcolor[EloConfig.CTRaidColors][Elo.ClassTable[UnitClass("player")]],}
	SlashCmdList["ELOQUENCESLASH"] = Elo.SlashCmd
		SLASH_ELOQUENCESLASH1 = "/elo"
		SLASH_ELOQUENCESLASH2 = "/eloquence"
	Elo.OldSetItemRef = SetItemRef;
	hooksetitemref()
	hooksetitemref = nil
	if not EloConfig.Custom then EloConfig.Custom = { } end
	if (myAddOnsFrame_Register) then
		myAddOnsFrame_Register(Elo.Info,Elo.Help)
	end

	elochatframe_messageeventhandler = nil

	Elo.OldRaidWarningFrame_OnEvent = RaidWarningFrame_OnEvent
	RaidWarningFrame_OnEvent = Elo.RaidWarningFrame_OnEvent

	Elo.RaidWarningFrame_OnEvent = nil

	Elo.OldWhoHandler = SlashCmdList.WHO
	SlashCmdList.WHO = Elo.WhoHandler;

	Elo.OldFriendsFrame_OnEvent = FriendsFrame_OnEvent;
	function FriendsFrame_OnEvent(...)
		if event ~= "WHO_LIST_UPDATE" or Elo.Suppress == nil then
			SetWhoToUI(0)
			Elo.OldFriendsFrame_OnEvent(...)
		end
	end

	Elo.OldSendChatMessage = SendChatMessage
	SendChatMessage = elosendchatmessage

	elosendchatmessage = nil

	if (EloConfig.HideSplash < 1) then
		print(b.."Type "..Elo.Hue.yellow.."/elo"..Elo.Hue.white.." for options.")
	end

	local hookwindow = {1,2,3,4,5,6,7}
--[[	Only hook chat frames not hooked by HitsMode original or updated versions. (7/03/06)
	if HM_Options or HM_OptionsList then
		for i=1,4 do
			hookwindow[HM_GetValue("window"..i)] = nil
		end
	end
--]]
	for k,v in p(hookwindow) do 
		local cf = getglobal("ChatFrame"..v)
		cf.EloOldAddMessage = cf.AddMessage
		cf.AddMessage = newaddmessage
		spamlist[getglobal("ChatFrame"..v)] = { }
	end
	Elo.OldChatEdit_OnEscapePressed = ChatEdit_OnEscapePressed
	ChatEdit_OnEscapePressed = elochatedit_onescapepressed

	elochatedit_onescapepressed = nil

	Elo.CheckCustom()

	this:RegisterEvent("PLAYER_ENTERING_WORLD")

	this:UnregisterEvent("ADDON_LOADED")
	Elo.OnLoad = nil
end
