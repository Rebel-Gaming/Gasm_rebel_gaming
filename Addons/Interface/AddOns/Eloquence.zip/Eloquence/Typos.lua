function Elo.ChopSpaces(msg)
	msg = string.gsub(msg,"%s%s+"," ")
	return strtrim(msg)
end

Elo.Typos = {
[1]={
--	LFG typos
	["(%A)[bB]a+r+o+n(%A)"]			=	"%1Baron%2",
	["^%s*[fF][lL;][mM]"]	=	" LFM",
	["^%s*[fF][lL;][mM]"]	=	" LFM",
	["^%s*[lL][f4]+[mM]+['s]*"]	=	" LFM",

	["^%s*[fF][lL;][gG]"]	=	" LFG",
	["^%s*[lL][fF][pPtT]%s"]	=	" LFG ",
	["^%s*[lL;:,.<>][fF][gG]"]	=	" LFG",
	["^%s*[gG][lL;][fF]"]	=	" Our group is LF ",
	["^%s*[lL;][gG][fF]"]	=	" LFG",
	["^%s*[wW][tT][hH]%s?(%d%d%d[%s%a])"]	=	" LF %1",
	["^%s*[lL;][gGfF][mMkK]%s"]	=	" LFM ",
	["^%s*[lL;][fF][nN](%A)"]	=	" LFM%1",
	["^%s*[lL;][mM][fF]([^aA])"]	=	" LFM%1",
	["^%s*[lL;][fF]%s?[iI]%s?[mM]%s"]	=	" LF1M",

	["(%A)[lL]+[fF4]+([gGdDpPhHmMsS])"]	=	"%1LF%2",



--	Fix 'hav esome' typos
	["(%A[hHgGwWsS])av%se(%a%a)"]		=	"%1ave %2",

	["(%A)[aA@][sz%$][sz%$](%A)"]	=	"%1ass%2",

	["(%A)[fF][ao]h?%s?[sS]hoh?(%A)"]	=	"%1for sure%2",
	["(%A[cC])an([%a'%s]+)%s[pP]aly(%A)"]	=	"%1an%2play%3",

	["(%A)[lL]o+k+[ei]?n[g']?(%A)"]	=	"%1looking%2",
	["(%A)[hH]a?ea?r?l+[ei]?n'?(%A)"]	=	"%1healing%2",
	["(%A)[sS]h?ay[ei]?n'?(%A)"]	=	"%1saying%2",
	["(%A)[qQ]u*it+[ei?]n['g]?(%A)"]	=	"%1quitting%2",
	["(%A)[dD][yei][yei]+n'?(%A)"]	=	"%1dying%2",
	["(%A)[aA]sk[ei]?n'?(%A)"]	=	"%1asking%2",
	["(%A)[tT]ry[ei]?n'?(%A)"]	=	"%1trying%2",
	["(%A)[rR]un+[ei]n'?(%A)"]	=	"%1running%2",
	["(%A)[tT]a[lk][lk][ei]?n'?(%A)"]	=	"%1talking%2",
	["(%A[dDgG])oin'?(%A)"]	=	"%1oing%2",
	["(%A)[bB]ein'?(%A)"]	=	"%1being%2",
	["(%A)[cC]heck[ei]?n'?(%A)"]	=	"%1checking%2",




	["^[%s~hHmM]*([,!?]+)[%s~]*$"]	=	"Hmm%1",

--	["%l%u+"]	=	string.lower,
	["%a[\"/'`;][LSRDZVTM]+%s"]	=	string.lower,

	["(%a%a%a)[\"/'`;]([lLsSdDmM][el]?%s)"]	=	"%1'%2",

--	Add 'for' before prices.
	["^([wW]%s?[tT]%s?[sSbB])(......-)=?%s?(%d[%d.,]*)%s?([gG])"]	=	"%1 %2 for %3 %4",
	["(%A[yY])o%s[yY]o(%A)"]	=	"%1o%2",

	["([%s%p])1,?337([sSzZ]*[%s%p])"]	=	"%1leet%2",

	["(%A[cC])ool[%s%p]+[dD]own(%A)"]		=	"%1ooldown%2",

	["(%A)[aA]tlea?st(%A)"]	=	"%1at least%2",
	["(%A)[eE]n+y(%A)"]	=	"%1any%2",
	["([%s,!?./])'?[lL]o+(%A)"]	=	"%1hello%2",
--	Bracket typo after typing 'p' like p[st
	["([pP])%[(%a[^%]]*)$"]	=	"%1%2",
--	Bracket typo before typing 'p' like [pst
	["%[([pP]%a[^%]]*)$"]	=	"%1",

	["(%A[fF])[ei]*r[ei]*nd([sz]*%A)"]		=	"%1riend%2",

--	Catch 'cnat' 'dnot' etc.
	["(%A[cCwWdD])n([ao])t(%A)"]		=	"%1%2nt%3",

--	Catch 'wuz' 'wuznt' etc.
	["(%A[wW])uz([n%s%p])"]		=	"%1as%2",

--	Replace waht, wha, waaat, wut, whut, wot, and woht
	["(%A)[wW]a+h?t([sz]*%A)"]	=	"%1what%2",
	["(%A)[wW]h?u+h?t([sz]*%A)"]	=	"%1what%2",
	["(%A)[wW]oh?t([sz]*%A)"]		=	"%1what%2",
	["(%A)[wW][hH][tT]([sz]*%A)"]		=	"%1What%2",
	["(%A)[wW]h?[au]+h?tm(%A)"]		=	"%1What am%2",

--	Catch 'donw' etc.
	["([cCwWdDlLrRtTpPgGsS])onw(%A)"]		=	"%1own%2",

	["(%A)[kK]?([lL]+)k?e?[vV]+[elL.]*([sz]*%A)"]	=	"%1 %2evel%3",
	["(%A)[kK]?([lL]+)k?e?[vV]+l+['e]?d(%A)"]	=	"%1%2eveled%3",
	["(%A)[kK]?([lL]+)k?e?[vV]+l+in['g]?(%A)"]	=	"%1%2eveling%3",

	["(%A)[jJ]/?[kK](%A)"]			=	"%1just kidding%2",

	["(%A[gG])+od+"]	=	"%1od",
	["(%A[gG])a+w+d+"]	=	"%1od",

--	Standardise spelling for later filters
	["(%A)[sS]+h?[uU]+[cCkK]+e?d(%A)"]		=	"%1sucked%2",
	["(%A)[sS]+h?[uU]+[cCkK]+[ei]n[g'](%A)"]		=	"%1sucking%2",

	["(%A)[sS]+u+x+(%A)"]		=	"%1sucks%2",

	["(%A)[sS]+h?[uU]+[cCkK]+(%A)"]		=	"%1suck%2",
	["(%A)[sS]+u+[ckq]+[xsz]+[ck]*(%A)"]		=	"%1sucks%2",

--	Grab arrows
	["^%s*==+>%s*([%a%d])"]		=	" --> %1",

	["(%A)[sS]ha*t+h?%s*[rR]a*t?h(%A)"]	=	"%1Shattrath%2",


},
[2]={
	["(%A)[sS]h[au][td]+%s?[au]p+(%A)"]	=	"%1shut up, %2",
	["(%A)[dD]%p?l(e?d?%A)"]		=	"%1download%2",
--	["(%A)[cC][uUoO]+s(%A)"]	=	"%1because%2",
	["(%A)'?[cC][uUoO]+z+([%s%p])"]	=	"%1because%2",
	["(%A)[kK][uU]+[sSzZ]+([%s%p])"]	=	"%1because%2",
	["(%A)[bB][eE]?/+[cC]([%s%p])"]	=	"%1because%2",
	["(%A)[bB][cC]([%s%p])"]	=	"%1BC%2",
	["(%A)[tT][bB][cC](%A)"]	=	"%1Burning Crusade%2",

	["(%A)[cC]['oOuU]?[mM]+[hHeE]+[rR][eE]?(%A)"]	=	"%1come here%2",
	["^%s[yY][aA]%s[wW]an+a"]		=	"Do you want to",

	["(%A[tTrRgGbBdDsSyY]h?)nak(%A)"]	=	"%1ank%2",
	["(%A)[rR]l+y(%A)"]	=	"%1really%2",
	["([%s%p])[tT][yY][%AtTyY]*(%A)"]	=	"%1thank you%2",

	["(%A)[oO]%A*[rR]%A*l+%A*y(%A)"]	=	"%1oh, really%2",

	["(%A)[bB]li[sz]+(%A)"]		=	"%1Blizzard%2",


	["(%A)[eE]q+[ui]+p+([ei])"]		=	"%1equipp%2",

	["(%A)[gG]m(s?%A)"]		=	"%1GM%2",
	["(%A)[pP][vV][pP](s?%A)"]		=	"%1PvP%2",
	["(%A)[pP]r?ty?ing(%A)"]		=	"%1partying%2",

	["(%A)[aA]i?ll+[iy]+(%A)"]	=	"%1Alliance%2",

	["(%A[sS])[oO]*[rR]+[yY](%A)"]	=	"%1orry%2",

	["(%A)[gG]nt(%A)"]		=	"%1good night%2",

	["(%A)[gG]'?ni[gh]*te?(%A)"]	=	"%1good night%2",
	["(%A)[gG]'?[lL]uck(%A)"]	=	"%1good luck%2",

	["(%A)[gG]'?[lL]uck(%A)"]	=	"%1good luck%2",

	["(%A)[gG]'?[lL](%A.-)%f[%a][hH][fF](%A)"]	=	"%1good luck%2have fun%3",


	["(%A)[xX][%s%p]*mas+(%A)"]	=	"%1Christmas%2",
	["([%s.,?!:;])[bB]%A*[dD]ay(%A)"]	=	"%1birthday%2",

	["(%A)[tT]h?nx(%A)"]	=	"%1thanks%2",

	["(%A)'?[sS]'?okay(%A)"]		=	"%1it's okay%2",

	["(%A[rR])gr(%A)"]		=	"%1oger%2",
	["(%A[aA])p+rox+(%A)"]		=	"%1pproximately%2",
	["(%A[fF])a+v+e?([sz]*%A)"]		=	"%1avorite%2",

--	Replace 'ez' and 'E Z'
	["(%A)[eE][%s%p]*[zZ](%A)"]	=	"%1easy%2",

	["(%A[sS])rsly(%A)"]		=	"%1eriously%2",
	["(%A[sS])h?e+r[ie]+[ou]+sl+y(%A)"]		=	"%1eriously%2",

	["(%A[nN])e?vr?%s[mM]i?nd(%A)"]	=	"%1ever mind%2",

	["(%A)[wW]arr+(%A)"]	=	"%1Warrior%2",


	["(%A)[cC]yz(%A)"]	=	"%1see you%2",
	["(%A)[yY]r([sz]*%A)"]		=	"%1year%2",
	["(%A)[pP]l+e*[zs]+(%A)"]	=	"%1please%2",

	["(%s)'?[cCsS]ept?%s(%a)"]	=	"%1except %2",

	["(%A)[dD]ose(%s?[nN][o']t%A)"]	=	"%1does%2",

	["(%A%a+)'Re(%A)"]		=	"%1're%2",
--	Uncap lone letters that aren't I
	["[%s!.?,][^iI%s%d%p][%s!.?,;]"]	=	string.lower,
--	Replace 'ahvent' etc.
	["(%A)[aA]hve([%sn])"]		=	"%1have%2",
--	Replace 'ina' 'ona' and 'ifa' with 'in a' and 'on a' etc.
	["(%A[io][fnr])a(%A)"]		=	"%1 a%2",
--	Replace 'int he' and 'ont he' with 'in the' and 'on the' etc.
	["(%A[iIoO][fFnN])[tT]%s?[hH][eE](%A)"]		=	"%1 the%2",
--	Catch backwards 'h' placement like hc, hw etc.
	["(%a%a)[hH]([wcgpg])(%A)"]		=	"%1%2h%3",
	["(%a%ang)ht(%A)"]		=	"%1th%2",
	["%s[hH]([wcstpg])([^%s%d%pmt])"]	=	" %1h%2",
--	Catch erroneous 'gn' placement in thign etc.
	["([hrydkot])ign([sz]*%A)"]		=	"%1ing%2",
--	Catch 'kc' typos.
	["([aeiouwy])kc([aeiouwy%s])"]	=	"%1ck%2",
--	Catch 'lcok' typos.
	["([lLcCnNpPtTfFdDwWsS])c([aeiou])k(%A)"]	=	"%1%2ck%3",
--	Catch 'cechk' typos.
	["(%A[cCsStT])([aeiou])h(ck%A)"]	=	"%1h%2%3",
--	Catch 'kn' typos.
	["([aeiou])kn(%A)"]	=	"%1nk%2",
--	Catch 'vestemnt' typos.
	["(%a%a[^%d%p%se])emnt(%A)"]	=	"%1ment%2",
	["(%a%a[^%d%p%se])emnt(%A)"]	=	"%1ment%2",
--	Catch 'fourthj' typos.
	["(%a%a[knhm])j(%A)"]	=	"%1%2",
--	Catch 'tjhanks' and 'thje' typos.
	["(%A[pPwWcCtT])j?hj?(%a)"]	=	"%1h%2",
--	Catch 'wq' typos.
	["(%a)[wW]q([aeiou])"]	=	"%1w%2",
--	Catch 'cl' typos.
	["([aeiou])cl(%A)"]	=	"%1ck%2",
--	Catch 'aome' typos.
	["(%A[aA])ome(%A)"]	=	"%1some%2",
--	Catch 'tog et' typos.
	["(%A)[tT]o([gsr])%s([uea]%a%A)"]	=	"%1to %2%3",
--	Catch 'ckick' typos.
	["(%A[cCbB])k([oaui]%a)"]	=	"%1l%2",
--	Catch 'yo uwant' typos.
	["(%A[yY])o%su(%a%a)"]	=	"%1ou %2",
--	Catch 'ig ot' typos.
	["(%A)[iI]g%sot(%A)"]	=	"%1I got%2",
--	Catch 'nf' typos.
	["([aeou])nf(%A)"]	=	"%1nd%2",
	["(%a)inf(%A)"]	=	"%1ing%2",
--	Catch 'abou tit' typos.
	["(%A[aA])bu?ou?%st(it%A)"]	=	"%1bout %2",

--	Catch 'go ta' 'go tit' typos.
	["(%A[gG])o%st([ai]t?%A)"]	=	"%1ot %2",

--	Catch 'ge tthat' typos.
	["(%A[gG][oe])%stth(%a)"]	=	"%1t th%2",

--	Catch 'witht hem' typos.
	["(%A[wW])h?itht%s([hH][ieao]%a+)"]	=	"%1ith %2",
	["(%A[wW])hith(%A)"]	=	"%1ith%2",
	["(%A[wW])iht(%A)"]	=	"%1ith%2",
--	Catch 'hj' and 'kj' typos.
	["(%A[hHkK])j([aeiou]%a+)"]	=	"%1%2",
--	Catch 'whilf' typos.
	["([wstprgnmc]h?)ilf(%A)"]	=	"%1ile%2",
--	Catch 'respodn' typos.
	["([aeiou])dn([%s%d!%.?])"]	=	"%1nd%2",
--	Catch 'tranlsate' typos.
	["([aeiou])n([mlpf])s([aeiou])"]	=	"%1ns%2%3",
--	Catch 'trasnlate' typos.
	["([aeiou])sn([mlpf])([aeiou])"]	=	"%1ns%2%3",
--	Catch 'messege' 'cabbege' etc.
	["(%a)([sbptm])(%2)ege(%A)"]		=	"%1%2%3age%4",
--	Catch 'guilg' 'builg' etc.
	["(%a)uilg(%A)"]		=	"%1uild%2",
--	Catch 'oir', 'oin' etc.
	["(%A)[oO]i([nrf]%A)"]		=	"%1o%2",
--	Catch 'chacne' etc.
	["(%a[aeiou])([sc])ne(%A)"]		=	"%1n%2e%3",
--	Catch 'folloe' 'alloe' etc.
	["([ao])l+oe(%A)"]		=	"%1llow%2",
--	Catch 'cotnradiction' 'itnroduction' etc.
	["([aeiou])tnr([aeiou]%A)"]		=	"%1ntr%2",
--	Catch word-ending 'l' typos 
	["([^%a;]%a%a+);(%a[^%a;])"]	=	"%1l%2",
--	Catch 'falg' and 'palce'
	["(%A[fFpP])al([cg][^ho])"]			=	"%1la%2",
--	Catch 'lfag'
	["(%A)[lL]fa([cg][^ho])"]			=	"%1fla%2",
--	Catch typos like 'popualte' 'deleagte' etc.
	["(%A%a-[^qQ%d%s%p][eu])([ai])([lcbrg])te(%a?%A)"]	=	"%1%3%2te%4",
--	Mistaken past tense
	["(%A[sSpPlL])ayed(%A)"]	=	"%1aid%2",
	["(%A[bB])ette?d(%A)"]	=	"%1et%2",
	["(%A[bB])idded(%A)"]	=	"%1id%2",
	["(%A[bBgG]r?)inded(%A)"]	=	"%1ound%2",
	["(%A[gG])ived(%A)"]	=	"%1ave%2",
	["(%A[bB])uye?d(%A)"]	=	"%1ought%2",
	["(%A[cC])at[ch]+e?d(%A)"]	=	"%1aught%2",
	["(%A[cC][ao])ste?d(%A)"]	=	"%1st%2",
	["(%A[fFdD])r[ie]+([vz])e?d(%A)"]	=	"%1ro%2e%3",
	["(%A[sS])eeke?d(%A)"]	=	"%1ought%2",
	["(%A[sS])et+e?d(%A)"]	=	"%1et%2",
	["(%A[sS])hut+e?d(%A)"]	=	"%1hut%2",
	["(%A[sS])hin+ed(%A)"]	=	"%1hone%2",
	["(%A[sS])mite?d(%A)"]	=	"%1mote%2",
	["(%A[sS])wim+e?d(%A)"]	=	"%1wam%2",
	["(%A[lL])ended(%A)"]	=	"%1ent%2",
	["([tT])ake?d(%A)"]	=	"%1ook%2",
	["([wW])ake?d(%A)"]	=	"%1oke%2",
--	Mistaken progressive tense
	["(%a[sbcdfglmpv])eing(%A)"]	=	"%1ing%2",
	["(%a)ieing(%A)"]	=	"%1ying%2",

--	Other common mispellings/typos.
	["(%A)invet(%A)"]	=	"%1invite%2",
	["(%A)[pP]erferably(%A)"]	=	"%1preferably%2",
	["(%A)[gG][uU][dD](%A)"]	=	"%1good%2",
	["(%A)[sS]up+os+[ed]*%s?[tT2o]+(%A)"]	=	"%1supposed to%2",
	["(%A)[iI]nna([^rt%d%p%s]%a+)"]	=	"%1ina%2",
	["[aA]p+rop+r[ie][aeu]t"]	=	"appropriate",
	["(%A)[sS]h?[ur]+p+ri[sze]+(%A)"]	=	"%1surprise%2",

	["(%A)[sS]e[ck]+s[aiey]+(%A)"]	=	"%1sexy%2",
	["(%A)defence(%A)"]	=	"%1defense%2",
	["(%A)[sS][rR][sS](%A)"]	=	"%1serious%2",
	["(%A)[bB][zZ][nN][sS](%A)"]	=	"%1business%2",

	["(%A)[bB]el[ei]+ve(%A)"]	=	"%1believe%2",

	["(%A)[hH]er?or?ic(%A)"]	=	"%1heroic%2",
	["(%a[rtz])ioc(%A)"]	=	"%1oic%2",

	["([aAeE]p+)rici(%a)"]	=	"%1reci%2",
	["ittel"]				=	"ittle",
	["(%A[rR])ecc[ao](%a)"]		=	"%1eco%2",
	["(%A[dD])zn(%A)"]		=	"%1ozen%2",
	["(%A)[lL]i'?l(%A)"]		=	"%1little%2",
	["(%A)[rR][ei]r?[cq][rui]+t"]		=	"%1recruit",
	["(%A)[sS]h?ence(%A)"]		=	"%1sense%2",
	["(%A)[aA]l+r[ae]*y?d+y?(%A)"]		=	"%1already%2",
	["(%A)[aA]ll+([rm]%a)"]		=	"%1al%2",
	["(%A[pP])re*f+e*re*d(%A)"]		=	"%1referred%2",
	["(%a%a)yoen(%A)"]		=	"%1yone%2",
	["[iI]ha?ve?(%A)"]		=	"I have%1",
	["(%A[gG])ee+t([sz]*%A)"]		=	"%1et%2",
	["(%A[oO])pp+[sz](%A)"]		=	"%1ops%2",
--	["(%A)[xX]([apc]%a%a%a+%s)"]		=	"%1ex%2",
	["(%A)[hH]av%s-([^%snei])"]		=	"%1have %2",
	["(%A[nN])e?ve?r+([%A][^mM%s%p%d])"]	=	"%1ever%2",
	["(%A[sScCtThH][ao])em"]		=	"%1me",
	["(%A[sScCtThH])m([ao])e"]		=	"%1%2me",
	["(%A)([rf])o(%A)"]		=	"%1o%2%3",
	["(%A[dgt])won([^%a'])"]		=	"%1own%2",
	["(%A)[aA]+in[\"/;:`]?t'?(%A)"]			=	"%1ain't%2",
	["iegh"]				=	"eigh",
	["(%A[dD])ot'?n'?([%s.!?,])"]	=	"%1on't%2",
	["(%A[dDwW])on[t']*cha([%s.!?,])"]	=	"%1on't you%2",
	["(%A[hH])e*l+e*p+"]	=	"%1elp",
	["(%a%a)ciev(%a)"]		=	"%1ceiv%2",
	["(%a)cheiv(%a)"]		=	"%1chiev%2",
	["(%A)[fF]romt%she(%A)"]	=	"%1from the%2",
	["(%A[nNplt]r?)([cpkldtbf])([iauo])e(%A)"]		=	"%1%3%2e%4",
	["([^mn]?%A)[iI]%s?[nN]o(%A)"]		=	"%1I know%2",
	["(%A)[kK][nN]o%sw(%a)"]		=	"%1know %2",
	["(%A)[kK]?[nN]oe([sz]*%A)"]		=	"%1know%2",
	["(%A)[kK]nw?o([sz]*%A)"]		=	"%1know%2",
	["(%A)[nN]kow([sz]*%A)"]	=	"%1know%2",
	["(%A)de?ul(%A)"]		=	"%1duel%2",
	["(%A)[gG][ua]+r+[ua]+ntee"]	=	"%1guarantee",
	["(%A)[iI][sn]+t[ae]+d(%A)"]	=	"%1instead%2",
	["(%A[tTrR])uff+(%A)"]	=	"%1ough%2",
	["(%A)[pP][eui]*r+t+y(%A)"]			=	"%1pretty%2",
	["(%A)[pP]r+it+y(%A)"]			=	"%1pretty%2",
	["(%A)[eE]v+ry"]		=	"%1every",
	["(%A)[wW]o?rng(%A)"]		=	"%1wrong%2",
	["(%A)[cC]lens([ie]%a*%A)"]		=	"%1clean%2",
	["(%A[wW])hi?sp(%A)"]		=	"%1hisper%2",
	["(%A[wW])i?sp?e?r(%A)"]		=	"%1hisper%2",
	["(%A)[oO]desn'?t(%A)"]	=	"%1doesn't%2",
	["[oO]te?hre?"]		=	"other",
	["(%A)[iI]tlle?(%A)"]			=	"%1it'll%2",
	["(%A[tTwW])ehr%s?e?(%A)"]		=	"%1here%2",
	["(%A[tTwW])he+r(%A)"]		=	"%1here%2",
	["uwh([aeo])"]			=	"you wh%1",
	["(%A)[bB]eyon[hbgs](%A)"]	=	"%1beyond%2",
	["(%A)[nN]e[sc]+[ai]s+[aie]r+e?y(%A)"]	=	"%1necessary%2",
	["[jJ]u+s+y?(%A)"]		=	"just%1",
	["([jJmM])s+ut(%A)"]		=	"%1ust%2",
	["[aA]mke(%A)"]		=	"make%1",
	["(%A)[aA]mking?(%A)"]	=	"%1making%2",
	["(%A)[nN]+ed([sz]*%A)"]	=	"%1need%2",
	["([%s%p])[nN]ad([%s%p])"]		=	"%1and%2",
	["([%s%p])[aA]hd([%s%p])"]		=	"%1had%2",
	["(%A)[Mm]ay+b[ye]+(%A)"]		=	"%1maybe%2",
	["(%A)[Mm]or%s([^eE])"]	=	"%1more %2",
	["(%A)[tT]her%s([^eE])"]	=	"%1there %2",
	["(%A)[tT]her%se(%a)"]	=	"%1there %2",
	["(%A)[lL][eE][mM]+[eE]%s(%a)"]	=	"%1let me %2",
	["%swer%s([^eE])"]		=	" were %1",
	["(%a[vdtbsyk])a+h+([sz]*%A)"]	=	"%1er%2",
	["(%A)[lL]ik%s([^eE])"]		=	"%1like %2",
	["(%A)[lL]ik%se"]			=	"%1like ",
	["(%A[lLtTmMsSrRpP])([cl])([aoiu])k"]		=	"%1%3%2k",
	["(%A)[iI]([^%d%s%pgmnrts]%a%a%a-)ed(%A)"]		=	"%1I %2ed%3",
	["(%A[yY])o%suare(%A)"]		=	"%1ou are%2",
	["[fF]omr"]			=	"form",
	["(%A[dDwW])opnt(%A)"]		=	"%1ont%2",
	["(%A[tT])h([mnts])([aeiu])(%A)"]		=	"%1h%3%2%4",
	["[wW]hne(%A)"]		=	"when%1",
	["[aA]slo(%A)"]		=	"also%1",
	["(%A)els%se?"]		=	"%1else ",
	["(%A)[tT][ao]*m+[oa]*r+o*w+(%A)"]	=	"%1tomorrow%2",
	["(%A)[wW]e+ke?dn?([sz]*%A)"]	=	"%1weekend%2",
	["[dD]if+[ea]?r+[eau]*n+"]	=	"differen",
	["(%A)[dD]if+([sz]*%A)"]		=	"%1difference%2",
	["([eE])ssance([sz]*%A)"]		=	"%1ssence%2",
	["(%A)[aA]g[iae]+n([%As])"]			=	"%1again%2",
	["(%A)[sS]he?i?ld"]		=	"%1shield",
	["(%A[rR]?e?)[mM][em]*be?re?(s?[^d%a])"]	=	"%1member%2",
	["(%A[mM])ent(%A)"]	=	"%1eant%2",
	["(%A[hHlLgG])awt+(%A)"]	=	"%1ot%2",
	["(%A)[pP][eu]h?l+[ae]+se(%A)"]		=	"%1please%2",

	["(%a)a%snd(%A)"]	=	"%1 and%2",
	["([%s%p])[aA][bm]d([%s%p])"]	=	"%1and%2",
	["(%A)[cCsS]+ec?p+e?t[eao]?re?(%A)"]	=	"%1scepter%2",
	["(%A[tT])he%s*[aA]l+t[oe]r(%A)"]	=	"%1he altar%2",
	["[aA]cu?tau?l"]		=	"actual",
	["[hH]onne"]			=	"hone",
	["[dD]is+[iea]+p+e+a?r"]	=	"disappear",
	["[gG]reatful"]		=	"grateful",
	["[fF]in+aly"]			=	"finally",
	["[vV]err+([iy])"]		=	"ver%1",
	["([^%p%d%so])[fF]+[aei]n+[aie]t[ea]?([^i])"]	=	"%1finite%2",
	["[rR]edicul"]			=	"ridicul",
	["(%A)[rR]iad"]		=	"%1raid",
	["[pP]oss[aoue]b"]		=	"possib",
	["(%A[iI])nste([^a])"]	=	"%1nsta%2",
	["[sS]epe?r+[aei]t(%a)"]	=	"separat%1",
	["[pP]repe?r+[aei]t(%a)"]	=	"preparat%1",
	["[dD]esp[aei]r+[eai](%a)"]	=	"despera%1",
	["[sS]trat[ai]g"]			=	"strateg",
	["[bB]eni(%a)"]			=	"bene%1",
	["([mM])sot(%A)"]	=	"%1ost%2",
	["(%A[wW])nat(%A)"]	=	"%1ant%2",
	["(%A)[wW]an+a+n*(%A)"]	=	"%1want to%2",
	["(%A)[gG]er+at(%A)"]	=	"%1great%2",
	["(%A)[gG]r+aet(%A)"]	=	"%1great%2",
	["([rR])[ei][sz]+iste([^%d%s%pd])"]	=	" %1esista%2",
	["(%A[fF])[ie]+rey(%A)"]	=	"%1iery%2",
	["(%A[iI])c[aie]+y(%A)"]	=	"%1cy%2",
	["([pP]r[eo])ffe([^rR])"]	=	"%1rofe%2",
	["[cC]ahn(%a)"]		=	"chan%1",
	["(%A[eE])n?c[hn]*a[hnt]+"]	=	"%1nchant",
	["(%A[eE])n[ch]+n?a[nh]?t"]	=	"%1nchant",
	["[aA]mmou(%a)"]			=	"amou%1",
	["ertian"]			=	"ertain",
	["(%a)el?aly"]			=	"%1eally",
	["(%A%a)ae(%a+A)"]			=	"%1ea%2",
	["(%A)spe?c[ia]+l+y(%A)"]	=	"%1especially%2",
	["(%A[gG])u?eu?s+(%A)"]	=	"%1uess%2",


	["(%A)[aA]gre?d(%A)"]	=	"%1agreed%2",
	["(%A)[rR][ae][ae]+l+y(%A)"]	=	"%1really%2",
	["(%A)[qQ]i?ui?[kc]+([l%A])"]	=	"%1quick%2",
	["(%A)[nN]+o+%A*[wW]+a+i+(%A)"]	=	"%1no way%2",
	["(%A)[yY]+[ea]+s*%A*[wW]+a+i+(%A)"]	=	"%1yes way%2",

	["(%A)[tT]il([%s%p])"]		=	"%1till%2",
	["(%A)[tT]aht([sz]*%A)"]		=	"%1that%2",
	["(%A[tT]?)[hH]si(%A)"]		=	"%1his%2",
	["(%A[tT]?)[iI]hs(%A)"]		=	"%1his%2",
	["(%A[tT]?)[hH]ier([sz]*%A)"]	=	"%1heir%2",

	["(%A)[tT]h([ai])%s([ts])i([ts]%A)"]		=	"%1th%2%3 i%4",

	["(%A)[xX]([tp][re]%a)"]	=	"%1ex%2",

	["(%A)[eE]xpe?ria?nce?"]	=	"%1 experience",
	["(%a%a)sicly(%A)"]		=	"%1sically%2",
	["(%a[^%p%d%se])atly(%A)"]		=	"%1ately%2",
--	["(%A[lL])oo+[sz](%a+)"]	=	"%1os%2",
	["(%A)[pP]roo+v(%a+)"]	=	"%1prov%2",
	["[sS]acr[ae]f"]		=	"sacrif",
	["[bB]all+anc"]		=	"balanc",
	["[gG]au?rau?nt"]		=	"guarant",
	["(%A[iI])n+tr+es+t"]		=	"%1nterest",
	["(%A[rR])el+[aei]t+([ie])"]		=	"%1elat%2",
	["(%A)[aA]t+c?k"]		=	"%1attack",
	["(%A)[aA]tt+(%A)"]		=	"%1attack%2",
	["%s'?[nN]other(%A)"]	=	" another%1",
	["[sS]pec+'?e?d"]		=	"specialized",
	["[sS]pec+%a-(e?[szdg])%sin"]	=	"specializ%1 in",
	["[sS]im+[ua]l+[iea]r"]	=	"similar",
	["(%A)bliz+[aeiou]rd(%A)"]			=	"%1Blizzard%2",

	["(%A)[jJ]e?w+[ae]?l"]		=	"%1jewel",

	["(%A)[qQ][weu]*s[ew]?t"]		=	"%1quest",
	["[tT]hru(%A)"]		=	"through%1",
--	["[tT]hrew(%A)"]		=	"through%1",
	["(%A)[kK]ewlz?(%A)"]	=	"%1cool%2",
	["(%A)[hH]+e+y+(%A)"]	=	"%1hey%2",
	["(%A)[aA]+[yi]+t(%A)"]		=	"%1all right%2",
	["(%A)[aA]+l+ri+g?h?te?(%A)"]		=	"%1all right%2",
	["(%A[iI])tsoka?[yi]?(%A)"]		=	"%1t's all right%2",
	["(%A)[lL]+[aA]+[wW]+[lL]+[sz]*(%A)"]		=	"%1lol%2",
	["(%A)[lL]+[oO09]+[lL][oO0lsz]*([%s%p])"]		=	"%1lol%2",
	["(%A)[rR]+[oO09]+[fF]+[lL]+[%a%d]*(%A)"]		=	"%1rofl%2",
--	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0](%A)"]		=	"%1LMFAO%2",
	["(%A)[mM]id(%s)"]		=	"%1middle%2",
	["(%A)[sS]h?ig(%A)"]		=	"%1signature%2",
	["(%a%a[^%d%s%pfl])er%s?[tT]hen(%A[iI]%A)"]	=	"%1er than%2",
	["(%a%a[^%d%s%pfl])er%s?[tT]hen(%A%a%a)"]	=	"%1er than%2",
	["(%A[mM])o?r%s?e%s?[tT]hen(%A%d)"]	=	"%1ore than%2",
	["(%A)[yY]+e+s+h?(%A)"]			=	"%1yes%2",
	["([%s%p]%d+)%s?[aA]m(%A)"]			=	"%1 AM%2",
	["([%s%p]%d+)%s?[pP]m(%A)"]			=	"%1 PM%2",
	["(%A[sSdD])oo+(%A)"]	=	"%1o%2",
	["(%A)[aA]l+e?[iy]+e?[sz]+(%A)"]	=	"%1Alliance%2",
	["(%A)[aA]l+inc%a*(%A)"]	=	"%1Alliance%2",
	["(%A)[aA]l+ien[cz]e?(%A)"]	=	"%1Alliance%2",
	["(%A)[aA]l+i?ai?n[cz]+e(%A)"]	=	"%1Alliance%2",

	["(%A)[gG]et+a(%A)"]		=	"%1get a%2",
	["(%A[lLnNtT])i+te([sz]*%A)"]	=	"%1ight%2",
	["(%A[lLnNtT])tie([sz]*%A)"]	=	"%1ight%2",
	["(%A)[sS]h?up%s?[sS]up(%A)"]	=	"%1sup%2",
	["(%A[oO])n%s[tT]he%s[lL]o+se(%A)"]	=	"%1n the loose%2",
--	["(.-|.-%A[lL])oose(%A)"]	=	"%1oose%2",
	["(%A)[pP][sS][yY]?[tT]+[yY]?(%A)"]		=	"%1PST%2",
	["(%A)[tT]o+ni+te?(%A)"]	=	"%1tonight%2",
	["(%A[rR])[aei]+nde+a?r(%A)"]	=	"%1eindeer%2",

	["(%A)[tT]h[nk]+s(%A)"]	=	"%1thanks%2",
	["(%A)[tT]hakn?s+(%A)"]		=	"%1thanks%2",

	["(%A)[cC]han+l+e(%A)"]		=	"%1channel%2",
	["(%A[iI])n+k+e*p+e*r+(%A)"]	=	"%1nnkeeper%2",
	["(%A[oO])+k+[ieysz]+%a*(%A)"]	=	"%1kay%2",
	["([%s%p])[oO]?k+([%s%p])"]	=	"%1okay%2",
	["(%A)[aA]gro"]		=	"%1aggro",


	["([%s%p])[aA]+i+[gh]-te?(%A)"]	=	"%1all right%2",
	["([%s%p])[iI]+[gh]+te?(%A)"]	=	"%1all right%2",
	["(%A)[sS]em+([sz]*%A)"]	=	"%1seem%2",
	["(%A)[sS]ed+(%A)"]	=	"%1said%2",
	["(%A)[sS]+ez+(%A)"]	=	"%1says%2",


	["(%A)'?[sS]'?cu+se(%A)"]	=	"%1excuse%2",
	["(%A)[bB]e*[cC]ua?[sz]+e?(%A)"]	=	"%1because%2",

--	Replace 'teh' and 'th' and 'thw'
	["%s[tT][eE]?[hH][eEwW3]?%s"]		=	" the ",
	["%s[tT][eE3][hH]%s"]		=	" the ",

--	Replace 'da' and 'dis' and 'dat'
	["([%s%p])[dD][aA]([%s%p])"]	=	"%1the%2",
	["(%A)[dD]ass(%A)"]	=	"%1that's%2",
	["(%A)[dD]ere?(%A)"]	=	"%1there%2",

	["(%A)[eE]ou[gh][gh](%A)"]	=	"%1enough%2",

	["(%A[pP])[eo][eo]+pe?l+e?(%A)"]		=	"%1eople%2",
	["([vV])i[sz]+[ae]b([il])"]	=	"%1isib%2",
	["(%A)[cC]alss+(%A)"]	=	"%1class%2",

	["(%A)[tT]a?ua?r+[eai]n([sz]*%A)"]		=	"%1Tauren%2",
	["(%A)[pP]al+[iea]+d+[ai]+n([sz]*%A)"]	=	"%1Paladin%2",

	["(%A)mage([sz]*%A)"]		=	"%1Mage%2",
	["(%A)hunter([sz]*%A)"]		=	"%1Hunter%2",
	["(%A)[rR]o[ue]?g[ue]*([sz]*%A)"]	=	"%1Rogue%2",
	["(%A)[dD]r[uo0i]+d([sz]*%A)"]	=	"%1Druid%2",
	["(%A)[dD]ru([sz]*%A)"]	=	"%1Druid%2",
	["(%A)[pP]r[ei]+a?s+[ei]?t([sz]*%A)"]	=	"%1Priest%2",
	["(%A)[pP]i?re+s[ei]*t([sz]*%A)"]	=	"%1Priest%2",
	["(%A)[sS]h?a[mM]+e?[iy]+e?([sz]*%A)"]		=	"%1Shaman%2",
	["(%A)[sS]har?m+[aeiuo]n([sz]*%A)"]	=	"%1Shaman%2",
	["(%A)[wW][ao]r+o?io?[ri]+([sz]*%A)"]	=	"%1Warrior%2",
	["(%A)[wW][oa]r+l+o[ck]+e?([sz]*%A)"]		=	"%1Warlock%2",

	["(%A)[hH]o+ar+de?s?(%A)"]			=	"%1Horde%2",
	["(%A)[hH]a?o+a?r+de?[sz]?(%A)"]			=	"%1Horde%2",

--	Fixes 'groop' 'grup' 'grp' etc.
	["(%A)[gG][ou]*r[ou]*p([sz]*%A)"]	=	"%1group%2",


	["(%A)[wW]ind%A*[fF][uer]+y(%A)"]	=	"%1Wind Fury%2",




	["(%A)[tT]rink([sz]*%A)"]		=	"%1trinket%2",
	["(%A)[qQ]u+e?([dsz]*%A)"]		=	"%1queue%2",
	["(%A[gG])[ea]*n[eauio]*r+[eauio]*l+(%A)"]		=	"%1eneral%2",
	["(%A[sS])[ea]*rg[ae]*n?t(%A)"]		=	"%1ergeant%2",
	["(%A[cC])apt[aei]*n?(%A)"]		=	"%1aptain%2",
	["(%A[lL])[aeiu]+t[aie]*n[aeu]*nt(%A)"]		=	"%1ieutenant%2",

	["(%A[eE])?xh?u?au?lt"]		=	"%1xalt",
	["(%A[aA])rt[ae]+s[ia]+n([sz]*%A)"]		=	"%1rtisan%2",

	["(%A[mM])[iy]th[eiau]?r+[aeiouy]l+(%A)"]	=	"%1ithril%2",
	["(%A[aA])r?a?c[hr][aei]nite(%A)"]	=	"%1rcanite%2",

	["(%A[vV]?)aley(%A)"]	=	"%1alley%2",
	["(%A)[gG]rom+%A*[gG]ol+(%A)"]		=	"%1Grom'gol%2",
	["(%A)bo+t+y%s?bay(%A)$"]		=	"%1Booty Bay%2",
	["(%A)[tT]h?unde?rbluf+(%A)"]	=	"%1Thunder Bluff%2",

	["(%A)[tT][ue]?a[ue]?r+[ae]n%s?[mM]il+s*"]	=	"%1Tarren Mill",

	["(%A)[sS]h?to[ck]+ai?de?s?"]	=	"%1Stockades",

	["(%A)[aA]uch?[aeiou]+n*d+o+[uw]?[nm]+(%A)"]	=	"%1Auchindoun%2",
	["(%A)[dD]a?r?n+r?as+[aeu]s+(%A)"]	=	"%1Darnassus%2",

	["(%A)[sS]h?[ae]+p+ul[ch]+%a+(%A)"]	=	"%1Sepulcher%2",
	["(%A)[mM][au]+r[au]+[aeioudn]*(%A)"]	=	"%1Maraudon%2",
	["(%A)ul+da?ma?n+(%A)"]	=	"%1Uldaman%2",
	["(%A)[zZ]ul+[%s%p]*[fF][aei]r+[ei]k+(%A)"]	=	"%1Zul'Farrak%2",
	["(%A)zul+[%s%p]*[fF][aei]r+[aei]k+(%A)"]	=	"%1Zul'Farrak%2",

	["(%A)[sS]h?[ch]+olo%a*(%A)"]	=	"%1Scholomance%2",


	["[sS]car?lr?e?t%s[mM][ao]n[aeio]s?ts?[aiou]r+y"]	=	"Scarlet Monastery",

	["(%A)[tT]?h?e?%s?un+d?erci?t+y(%A)"]			=	"%1the Undercity%2",
	["(%A)[iI]ron%sford?ge?(%A)"]	=	"%1Ironforge%2",

	["(%A)[iI](['l]*%s?)[vV]end[eoa]?r(%A)"]	=	"%1I%2 sell%3",

--	Correct attribute names.
	["(%A)[aA]gilty?(%A)"]		=	"%1 Agility %2",
	["(%A)[sS]h?te?r?n[gth]+(%A)"]	=	"%1 Strength %2",
	["(%A)[sS]h?tr?n[gth]*(%A)"]	=	"%1 Strength %2",
	["(%A)[sS]h?pi*r+[ri]+t(%A)"]	=	"%1 Spirit %2",
	["(%A[fF])o?r?st"]	=	"%1rost",

	["(%A[eE])l+[ie]+xi?ei?r([sz]*%A)"]	=	"%1lixir%2",
	["(%A[sS])taf+[sz](%A)"]	=	"%1taves%2",
	["(%A[sS])taf(%A)"]	=	"%1taff%2",
	["(%A[cC])h[ea]-e+p"]		=	"%1heap",

	["(%A[pP])a?te?rn([sz]*%A)"]		=	"%1attern%2",

	["(%A)[dD]%A?[cC][e']*d(%A)"]	=	"%1disconnected%2",
	["(%A)[dD]%A?[eE]'d(%A)"]	=	"%1disenchanted%2",


	["(%A[aA])rc[aeiou]*n[eai]*te?(%A)"]	=	"%1rcanite%2",
	["(%A[eE]+)n*g+[ei]+n+[aie]+r+([sz]*%A)"]		=	"%1ngineer%2",

--	Add apostrophes to contractions. If other punctuation is where apostrophe should be,
--	replaces it with an apostrophe (a common typo).
--	Other common contraction typos

	["(%A[iIa])sn[\"/;:`]?t'?(%A)"]			=	"%1sn't%2",
	["(%A)[iI]t[\"/;:`]?d(%A)"]			=	"%1it would%2",
	["(%A)[iI]t[\"/;:`]?ll(%A)"]			=	"%1it will%2",
	["(%A)[kKcC]an[\"/;:`]?t(%A)"]	=	"%1can't%2",
	["(%A)[wW]+on[\"/;:`]?t(%A)"]	=	"%1won't%2",
	["(%A)[dD]+in?dn?[\"/;:`]?t(%A)"]	=	"%1didn't%2",
	["(%A)[dD]+on[\"/;:`]?t'?(%A)"]	=	"%1don't%2",
	["(%A)[dD]+[oe]*se?n[\"/;:`]?t(%A)"]	=	"%1doesn't%2",
	["(%A[tTwW])here?[\"/;:`]?s+(%A)"]		=	"%1here's%2",

	["^(%A[tT])hi?eri?e?[\"/;:`]?s+(%Aa)"]		=	"%1here is%2",

	["(%A)[wW]+hy[\"/;:`]?s+(%A)"]		=	"%1why is%2",
	["(%A[wW]+)ho[\"/;:`]?s+(%A)"]		=	"%1ho's%2",
	["(%A[hH])ow[\"/;:`]?([sd]%A)"]		=	"%1ow'%2",
	["(%A)[wW]+h?at[\"/;:`]?s+(%A)"]		=	"%1what's%2",
	["(%A)[wW]+h?as[\"/;:`]?t(%A)"]		=	"%1what's%2",
	["(%A)[wW]+h?en[\"/;:`]?s+(%A)"]		=	"%1when's%2",
	["(%A)[hH]ere[\"/;:`]?s+(%A)"]		=	"%1here's%2",
	["(%A)[aA]re?n[\"/;:`]?t(%A)"]		=	"%1aren't%2",
	["(%A)[wW]+e+[\"/;:`]re(%A)"]		=	"%1we're%2",
	["(%A)[wW]+ere?n[\"/;:`]?t'?(%A)"]		=	"%1weren't%2",
	["(%A)[wW]+asn[\"/;:`]?t'?(%A)"]			=	"%1wasn't%2",
	["(%A)[wW]+h?at[\"/;:`]?r[\"/;:`]?e?(%A)"]		=	"%1what are%2",
	["(%A)[hH]a[fv]ta(%A)"]		=	"%1have to%2",
	["(%A)([wWcCsS]h?)o?ul?d'?[av]e?(%A)"]		=	"%1%2ould have%3",
	["(%A)([wWcCsS]h?)o?ul?dn[\"/;:`]?t'?(%A)"]	=	"%1%2ouldn't%3",
	["(%A)[hH]+a([dsv]e?)n[\"/;:`]?t'?(%A)"]	=	"%1ha%2n't%3",
	["(%A[tTwW]h[ea][ty])[\"/;:`]?l+(%A)"]	=	"%1 will%2",
	["(%A[yY])o?u[\"/;:`]?l+(%A)"]	=	"%1ou'll%2",
	["(%A)[tT]+hat[\"/;:`]?d(%A)"]			=	"%1that'd%2",
	["(%A)[tT]+hey[\"/;:`]?d(%A)"]			=	"%1they'd%2",
	["(%A)[tT]+hey[\"/;:`]?r[\"/;:`]?e?(%A)"]		=	"%1they're%2",
	["(%A)[tT]+hat[\"/;:`]?r[\"/;:`]?e?(%A)"]		=	"%1that are%2",
	["(%A)[tT]+hey[\"/;:`]?[\"/;:`]?ve(%A)"]			=	"%1they have%2",

--	Need more 60's
	["(%d%d)[\"/;:`']?s([%s.?!,])"]	=	"%1s%2",

	["^%s[tT]here%sa(%A)"]	=	" They are a%1",
	["^%s[tT]here%snot(%A)"]	=	" They are not%1",

	["(%A)[kK]in+d?a(%A)"]	=	"%1kind of%2",
	["(%A)[sS]h?orta(%A)"]	=	"%1sort of%2",
	["(%A)[oO]ut+a(%A)"]	=	"%1out of%2",
	["(%A)[lL]ot+a(%A)"]	=	"%1lot of%2",
	["(%A)[oO]u?ght+a(%A)"]	=	"%1ought to%2",
	["(%A)[mM]i[ght]+a(%A)"]	=	"%1might have%2",
	["(%A)[mM]u[st]+a(%A)"]	=	"%1must have%2",
	["(%A)[lL]otsa(%A)"]	=	"%1lots of%2",
	["(%A)[aA]lot+(%A)"]	=	"%1a lot%2",
	["(%A[bB])uncha(%A)"]	=	"%1unch of%2",

--	Replace wepin, wappin, wpn, etc.
	["(%A[wW])h?[ea]+p+[aeiu]+n+([%s%p%dsz])"]	=	"%1eapon%2",
	["(%A[wW])e[ao]?po?n?([%s%p%dsz])"]			=	"%1eapon%2",

--	"Armor" is a quantity: has no plural.
	["(%A[aA])rm[ou]*r[sz]+(%A)"]			=	"%1rmor pieces%2",

--	Fix common 'should of' errors.
	["(%A[sSwWcC]h?)o?ul?dl?%s?[oO][fF](%A)"]	=	"%1ould have%2",
	["([^e]+)[mM]i[gGhH]+[tT]%s?[oO][fF](%A)"]		=	"%1might have%2",
	["(%A)[mM]ust%s?[oO]f(%A)"]				=	"%1must have%2",

--	Fix 'wud' 'shud' and 'coudl' and 'shuld' typos.
	["(%A[sSwWcC]h?)o?ul?dl?(%A)"]	=	"%1ould%2",
	["(%A[sScC]h?)ool?dl?(%A)"]	=	"%1ould%2",

	["(%a)yig?n'?(%A)"]		=	"%1ying%2",
	["(%a[ai][ln]?)kig?n'?(%A)"]	=	"%1king%2",
	["(%a)ll(y?)ig?n'?(%A)"]	=	"%1ll%2ing%3",
	["(%a)ttig?n'?(%A)"]		=	"%1tting%2",

	["(%ao[ro])ki[gn]'?(%A)"]	=	"%1king%2",
	["(%a)illig?n'?(%A)"]	=	"%1illing%2",
	["(%a)eadig?n'?(%A)"]	=	"%1eading%2",

	["(%A)[gG][aou]+n+a(%A)"]	=	"%1going to%2",

	["(%A)[iI]ve(%a+)"]	=	"%1I've %2",
	["^(%A+)[iI]v%se(%a+)"]	=	"%1I've %2",

	["(%A)[nN][oe30][ow0]+b+([sz]*%A)"]	=	"%1newb%2",
	["(%A)[nN]u+b+([sz]*%A)"]	=	"%1newb%2",
	["(%A)[nN][oe30][ow0]+b+[eiy]+([sz]*%A)"]	=	"%1newbie%2",
	["(%A)[nN][oe30]?[uow0]+b+l[ie]+t([sz]*%A)"]				=	"%1newblet%2",
	["(%A)[nN][oe30]?[uow0]+b+[eiy]+sh(%A)"]		=	"%1newbish%2",
	["(%A)[nN][oe30]?[uow0]+b+[cC]ake(%A)"]		=	"%1newbcake%2",
	["(%A)[nN][oe30]?[uow0]+b+age(%A)"]			=	"%1newbage%2",
	["(%A)[nN][oe30]?[uow0]+b+[zZ][o0O][rR]([sz]*%A)"]			=	"%1newb%2",

	["(%A)[dD][o0e4][o0w]de?([sz]?%A)"]			=	"%1dude%2",



	["(%A[eE]pic+['e]*d%A*)[oO]ut(%A)"]	=	"%1%2",

	["(%A)[cC][uU']*m+e?o+n+(%A)"]	=	"%1come on%2",
	["(%A)[dD][ou]+n+o+(%A)"]	=	"%1don't know%2",

	["(%A)[tT]re?ue?%A*[tTdD]h?at(%A)"]	=	"%1that is true%2",
	["(%A)[gG]im+e+(%A)"]	=	"%1give me%2",


--	Replace ty, TYVM, THX, tnx, and thnx
	["(%A)[tT]ha?n?[zxc]s?(%A)"]	=	"%1thanks%2",


	["(%A)[tT][yY][vV][mM](%A)"]	=	"%1thank you very much%2",

--	Replace yw, YW, and y w
	["(%A)[yY]%s?[wW](%A)"]		=	"%1you're welcome%2",


--	Replace 'ic'
	["(%A)[iI]%s?[cC](%A)"]	=	"%1I see%2",

--	Replace s'alright
	["(%A)[sS]h?'?%s?a+[lw]r+i+g?h?te?(%A)"]		=	"%1it's all right%2",

--	Replace 'sok'
	["(%A)'?[sS]'?[oO][kK](%A)"]	=	"%1it's okay%2",

--	Replace nuff and enuff and 'nuff
	["(%A)[eE']?[nN]uf+(%A)"]	=	"%1enough%2",


--	Replace 'luv' 'luvs' etc
	["(%A)[lL]+u+[vb]+e?([szd]%A)"]	=	"%1love%2",

--	Replace 'u'
	["([%s%p])[uU]([^%d%a_.%^-])"]	=	"%1you%2",

--	Replace 'ull'
	["([%s%p])[uU]ll([%s%p])"]	=	"%1you'll%2",

--	Replace 'j00' etc.
	["(%A)[jJyY][oO0][oO0]+(%A)"]	=	"%1you%2",
--	Replace 'ur' with 'your'.
	["(%A)[yY]*[uU][rR]e?(%A)"]		=	"%1your%2",

--	Replace 'yor' and 'yur' and 'yuor' and 'yer' with 'your'.
	["(%A)[yY][oe]+[r](%A)"]	=	"%1your%2",

--	Replace 'urs' and 'URZ' with 'yours'
	["(%A)[yY]?[uU][rR][sSzZ](%A)"]	=	"%1yours%2",

--	Replace 'urself' and 'URSELF' with 'yourself'
	["(%A)[yY]?[uU]rs[el]+f(%A)"]			=	"%1yourself%2",
	["(%A)[yY]?[uU]rs[el]+[fv][e]?[sz](%A)"]	=	"%1yourselves%2",

--	Replace 'u r' and 'U R' with 'you are'
	["(%A)[uU]%s[rR](%A)"]		=	"%1you are%2",

--	Replace 'ru'
	["(%A)[rR][uU](%A)"]	=	"%1are you%2",

--	Replace 'r'
	["(%s)[rR]([%s?!.,])"]	=	"%1are%2",
--	Replace 'rnt'
	["%s[rR]nt%s"]	=	" aren't ",

--	Replace 'b'
	["([^'%a%d(:/\\])[bB]([^.'%a%d/\\])"]	=	"%1be%2",

--	Replace any1 ny1 ne1 nething with or without spaces
	["(%A)[aA]?[nN]+%s?[yYeE]%s?1([%s%p])"]	=	"%1anyone%2",
	["(%A)[aA]?[nN]+%s?[yYeE]%s?[oOpPiI]n[ew](%A)"]	=	"%1anyone%2",
	["(%A)[nN]ay%s?[oO]n[ew](%A)"]	=	"%1anyone%2",
	["(%A)[nN]ay%s?1([%s%p])"]	=	"%1anyone%2",
	["(%A)[eEsS]n[yei]%s?on[ew](%A)"]	=	"%1anyone%2",
	["(%A)[nN]+[oup][th]+[ei]n['g]?(%A)"]	=	"%1nothing%2",
	["(%A)[nN]+[oup]?th[ei]?n['g]?(%A)"]	=	"%1nothing%2",
	["(%A)[aA]?[nN]+%s?[yea]+%s?thin['g]?(%A)"]	=	"%1anything%2",
	["(%A)[aA]?[nN]+%s?[yea]%s?way([sz]*%A)"]	=	"%1anyway%2",

	["(%A)[eE]v[ery]+one?([sz]*%A)"]	=	"%1everyone%2",


	["(%A)[nN][aey]+body([%s%p])"]	=	"%1anyone%2",
	["(%A[aA])ne([%s%p])"]	=	"%1ny%2",


	["(%A)[nN]%s?1([%s%p])"]	=	"%1anyone%2",

	["(%A)[nN]%s?[eE]%s?sec"]	=	"%1any sec",

--	Add ending 'g' to doin and goin
	["(%A[gGdD])oin'?(%A)"]		=	"%1oing%2",

	["(%A)[oO]toh(%A)"]		=	"%1on the other hand%2",
	["(%A)[iI]irc(%A)"]		=	"%1if I recall correctly%2",
	["(%A)[aA]faik(%A)"]	=	"%1as far as I know%2",
	["(%A)[yY]vm?w(%A)"]			=	"%1you're very welcome%2",
	["(%A)[iI]dc(%A)"]			=	"%1I don't care%2",
	["(%A)[iI]dk(%A)"]			=	"%1I don't know%2",
	["(%A)[iI]mh?o(%A)"]		=	"%1, in my opinion, %2",
	["(%A)[dD]in(%A)"]		=	"%1doing%2",
	["(%A)[iI]i+rc(%A)"]		=	"%1, if I remember correctly, %2",
	["(%A)[bB]bs([%s%p])"]			=	"%1be back soon%2",
	["(%A)[bB]bl([%s%p])"]			=	"%1be back later%2",
	["(%A)[lL]os(%A)"]		=	"%1line of sight%2",

	["(%A)[bB][%se]?4([%s%p])"]		=	"%1before%2",
	["([%s%p])4[eE]v[ea][rh]?(%A)"]	=	"%1forever%2",

	["([%s%p])[eE]va[rh]?(%A)"]	=	"%1ever%2",

	["(%A[lL])o+k+in[g'%s]*4(%A)"]	=	"%1f%2",
	["(%A)[gG]r?8([%s%p])"]			=	"%1great%2",
	["(%A)[hH]8e?(r?[zs]?[%s%p])"]			=	"%1hate%2",
	["(%A)[mM]8([sz]?[%s%p])"]			=	"%1mate%2",
	["(%A)[sS]h?tr8([%s%p])"]			=	"%1straight%2",

	["(%a%a)3r([%s%p])"]			=	"%1er%2",
	["(%a%a)3st([%s%p])"]			=	"%1est%2",

	["(%A)[uU]%s?2([%s%p])"]			=	"%1you too%2",

	["([%s%p])[gG]1([%s%p])"]		=	"%1good one%2",

	["^(%A[iI]%s%a.-%a)%s2%s$"]		=	"%1 too ",
	["(%A)[mM]e2([%s%p])"]		=	"%1me too%2",
	["(%A)[mM]e%s?[tT]o([%s%p]+)$"]		=	"%1me too%2",
	["(%A)[mM]e%s?2(%s%p*)$"]		=	"%1me too%2",
	["(%A)[mM]e2([%s%p])"]		=	"%1me too%2",
	["([%s%p])4%s?g([eo])t([sz*]%A)"]		=	"%1forg%2t%3",
	["(%A)[gG][tT2][gG]([%s%p])"]		=	"%1got to go%2",
	["([%s%p])4%s[mM]e(%A)"]			=	"%1for me%2",
	["(%A)[wW]ant([sz]*)%s?2%s?(%a%a-[^s%p%s%d]%A)"]	=	"%1want%2 to %3",
	["(%A)[wW]here?%s?2%s?(%a)"]		=	"%1where to %2",
	["([%s%p])2[%s%p]*[gG]ether([%s%p])"]		=	"%1together%2",
	["(%A[lL])%s?2%s?(%a%a+[%s%p])"]		=	"%1earn to %2",
	["(%A[lL])rn%s?2%s?(%a%a+[%s%p])"]		=	"%1earn to %2",
	["([%s%p])2[dD][ae]y(%A)"]			=	"%1today%2",
	["([%s%p])2[nN]ight?(%A)"]			=	"%1tonight%2",
	["([%s%p])2m[ao]r+ow?(%A)"]			=	"%1tomorrow%2",
	["([%s%p])2m[ao]r+ow?(%A)"]			=	"%1tomorrow%2",
	["(%s)%$%$+(%s)"]		=	"%1money%2",
	["(%A)/[wW](%A)"]			=	"%1whisper%2",
	["(%A)[wW]%s?/%s?([oO][^u])"]			=	"%1with %2",
	["(%A)[wW]%s?/%s([^oO])"]			=	"%1with %2",
	["(%A)[wW]%s?/%s?[oO]([%s.,?!])"]			=	"%1without%2",
	["(%A)[wW]%s?/%s?[oO]ut([%s.,?!])"]			=	"%1without%2",
	["(%A)[wW]%s?/%s?[eE]([%s.,?!])"]			=	"%1whatever%2",
	["(%a%a)&+(%a%a)"]					=	"%1 and %2",


	["(%A)[tT]bh(%A)"]		=	"%1to be honest%2",
	["(%A)[tT]ba(%A)"]		=	"%1to be announced%2",
	["(%A)[bB][tT][wW](%A)"]		=	"%1by the way%2",

	["(%A[aA])%s?[mM]in(%A)"]	=	"%1 minute%2",
	["(%A)[iI]+[nN]+[cC]+(%A)"]	=	"%1incoming%2",

--	Replace 'sup' and 'ssssuuuuupppp' etc
	["(%A)[sS]+h?u+p+[sz]*(%A)"]	=	"%1what's up%2",


	["(%A)[cC]o%p*ord([sz]*%A)"]	=	"%1coordinate%2",
	["(%A)[rR]eq([sz]*%A)"]	=	"%1requirement%2",
	["(%A)[rR]ep[sz]*(%A)"]	=	"%1reputation%2",
	["(%A)[sS]h?pd([sz]*%A)"]		=	"%1speed%2",
	["(%A)[dD]bl([sz]*%A)"]	=	"%1double%2",
	["(%A)[aA]mt([sz]*%A)"]	=	"%1amount%2",

	["(%A)[pP]ee+p[sz](%A)"]	=	"%1people%2",


	["(%A)[bB]e'?s(%A)"]			=	"%1Blood Elf%2",
	["(%A)[bB]elf(%A)"]			=	"%1Blood Elf%2",
	["(%A)[bB]elfs(%A)"]		=	"%1Blood Elves%2",
	["(%A)[dD]r[aei]+n+[aei]+[sz]*(%A)"]			=	"%1Draenei%2",
	["(%A)[nN]elf(%A)"]			=	"%1Night Elf%2",
	["(%A)[nN]elfs(%A)"]		=	"%1Night Elves%2",
	["(%d%d)%s?[nN]e(%A)"]		=	"%1 Night Elf%2",


	["(%A)[lL]ok+([sz]%A)"]		=	"%1Warlock%2",

	["(%A)[zZ]ep%a-([sz]*%A)"]	=	"%1zeppelin%2",


	["(%A)[mM]y%s?[mM]at+'?[sz](%A)"]		=	"%1my materials%2",
	["(%A)[yY]our%s?[mM]at+'?[sz](%A)"]		=	"%1your materials%2",
	["(%A)[oO]wn%s?[mM]at+'?[sz](%A)"]		=	"%1own materials%2",
	["(%A)[gG]ot%s?[mM]at+'?[sz](%A)"]		=	"%1have the materials%2",
	["(%A)[hH]ave%s?[mM]at+'?[sz](%A)"]		=	"%1have the materials%2",
	["(%A)[mM]at+'?[sz]%s?[pP]rov(.)"]		=	"%1materials prov%2",
	["(%A)[wW]ith?%s?[mM]at+'?[sz](%A)"]		=	"%1with materials%2",
	["(%A)[oO]f%s?[mM]at+'?[sz](%A)"]		=	"%1of materials%2",
	["(%A)[tT]he%s?[mM]at+'?[sz](%A)"]		=	"%1the materials%2",
	["(%A)[bB]r?%A*[yY]%A*[oO]%A*[mM](%A)"]		=	"%1bring your own materials%2",
	["(%A)[oO][%s%p]?[bB][%s%p]?[oO](%A)"]		=	"%1or best offer%2",

	["(%A[pP])rot(%A)"]		=	"%1rotection%2",
	["(%A[pP])lay%s*[dD]e?f*(%A)"]		=	"%1lay defense%2",

--	Change 'pots' to 'potions'
	["(%a)ing%s?[pP]ot(%A)"]	=	"%1ing potion%2",
	["(%A[mM]ana)%s?[pP]ot(%A)"]	=	"%1 potion%2",
	["(%A[hH]ealth)%s?[pP]ot(%A)"]	=	"%1 potion%2",
	["(%A[hHmM][pP])%s?[pP]ot(%A)"]	=	"%1 potion%2",
	["(%A[gG])a?ua?nt[sz](%A)"]	=	"%1auntlets%2",
	["(%A)[xX]%A?[B]ow?(%A)"]	=	"%1crossbow%2",

	["(%A[!1])[%s%-]?[hH]a?n?d?(%A)"]	=	"%1%-handed%2",
	["(%A[@2])[%s%-]?[hH]a?n?d?(%A)"]	=	"%1%-handed%2",

	["(%A)[oO][mM][wW](%A)"]	=	"%1on my way%2",
	["(%A)[oO][tT][wW](%A)"]	=	"%1on the way%2",

	["(%A[wW])[pP][nN]([sz]*%A)"]			=	"%1eapon%2",

--	Replace 'oic'
	["(%A)[oO]%s?[iI][cC](%A)"]	=	"%1oh, I see%2",

	["([%s!?])[nN][tT](%A)"]	=	"%1nice try%2",

-- Replace 'gj' and 'nj'
	["(%A)[gG][jJ](%A)"]		=	"%1good job%2",
	["(%A)[nN][jJ](%A)"]	=	"%1nice job%2",
	["(%A)[gG][wW](%A)"]		=	"%1good work%2",
--	["(%A)[nN][wW](%A)"]	=	"%1nice work%2",

	["([%s%p]%d%d%s?)[uU][dD](%A)"]	=	"%1Undead%2",
	["([i'])ll%s[pP]rob+(%A)"]	=	"%1ll probably%2",

	["(%A[pP])rob+%s+[nN]ot(%A)"]	=	"%1robably not%2",
	["(%A[pP])rob+%s(%a%a-n't%A)"]	=	"%1robably %2",


	["(%A)[cC]an%s[pP]rob+(%A)"]	=	"%1can probably%2",

	["([lL])evel%s*(%d+)%s*[mM]in(%A)"]		=	"%1evel %2 minimum%3",

	["(%A)[fF4]y[ik](%A)"]		=	"%1for your information%2",
	["(%A)[pP][pP][lL][eE]?(%A)"]		=	"%1people%2",
	["(%A)[pP][pP][lL][zZsS](%A)"]	=	"%1people's%2",

	["(%A)[nN]%s?[pP][sz]*(%A)"]	=	"%1no problem%2",

	["([%s%p])[kK]+([%s%p])"]				=	"%1okay%2",
	["([%s%p])[oO]*[kK]+[aA]?[yY]?([%s%p])"]			=	"%1okay%2",
	["([%s%p])[oO]+k+[ieysz]+%a*(%A)"]		=	"%1okay%2",

	["(%A)[wW][tT2][gG](%A)"]	=	"%1way to go%2",

	["(%A)[cC]%s?[yYuU][ao]?u?(%A)"]	=	"%1see you%2",
	["(%A)[cC]%s?[yY]a[sz](%A)"]	=	"%1see you%2",

	["(%A)[nN][vV]?%s?[mM](%A)"]	=	"%1never mind%2",

	["(%A)[lL][oO][mM](%A)"]	=	"%1low on mana%2",

	["(%A)[oO][oO][mM](%A)"]	=	"%1out of mana%2",
	["(%A)[rR]+[dD]+[yY]+(%A)"]	=	"%1ready%2",

	["(%A)[bB][rR][tT](%A)"]	=	"%1be right there%2",
	["(%A)[bB][rR][bB](%A)"]	=	"%1be right back%2",
	["(%A)[aA]sap(%A)"]	=	"%1as soon as possible%2",

	["(%A)[lL]8[eErR]*[sz]*(%A)"]		=	"%1later%2",

--	Replace msg and mssg with message
	["(%A)[mM][sS]+[gG](%A)"]	=	"%1message%2",

--	Replace whassat, wuzzat, etc.
	["(%A)[wW][hH]?[aAuUoO][hH]?[sSzZ]+[aA][tT](%A)"]	=	"%1what is that%2",

--	Replace whassup, wuzzup, what up, etc.
	["(%A)[wW]+[hH]*[aAuUoO]+[hH]*[sSzZ]+[uU]+[pP]+(%A)"]	=	"%1what's up, %2",
	["(%A)[wW]+[hH]*[aAuUoO]+[hH]*[tT]+%s?[uU]+[pP]+(%A)"]	=	"%1what's up, %2",


--	Replace 'prolly' and 'probly' and 'probobly' and 'probublly' etc
	["(%A)[pP]r[aoub]*l+[eiy]+(%A)"]		=	"%1probably%2",

},
[3]={
	["(%A)[rR]un[%sr]?[tT]r?hr?ough(%A)"]		=	"%1run through%2",

	["(%A)[pP]%p?[lL](%A)"]		=	"%1ower level%2",

	["(%A)[aA][tT][mM](%A)"]	=	"%1at the moment%2",

	["(%A)[pP]rob+([sz]*%A)"]	=	"%1problem%2",
	["(%A)[lL]oc([sz]*%A)"]	=	"%1location%2",

	["(%A)[wW]ant([sz]*)%s[tT]o%s[cC](%A)"]	=	"%1want%2 to see%3",


	["([^%a.])[oO]r+g+%.?([^%a])"]		=	"%1 Orgrimmar%2",
	["(%A)[oO]g+(%A)"]		=	"%1 Orgrimmar%2",
	["(%A)[oO][ri]?g+[ri]+m?(%A)"]	=	"%1Orgrimmar%2",
	["(%A)[oO]r%a-g%a-a+r+(%A)"]	=	"%1Orgrimmar%2",
	["(%A)[oO]g+r[ai]m%a*(%A)"]	=	"%1Orgrimmar%2",

	["(%A)[sS]hat+(%A)"]	=	"%1Shattrath%2",

	["(%A)[hH]fc(%A)"]	=	"%1Hellfire Citadel%2",
	["(%A)[bB][fF](%A)"]	=	"%1Blood Furnace%2",
 


--	Replace hes, hed, etc
	["(%A)[hH][eE][\"/;:`]?([sd])(%A)"]		=	"%1he'%2%3",
--	Replace shes, shed, etc
	["(%A)[sS][hH][eE][\"/;:`]?([sd])(%A)"]		=	"%1she'%2%3",
--	Replace thats, thatd, dats, datd, etc
	["(%A)[tTdD]h?at[\"/;:`]?([sd])(%A)"]		=	"%1that'%2%3",
--	Replace ive, im, and id with I've and I'm and I'd
	["(%A)[iI][\"/;:`o]?([mMdD]+%A)"]		=	"%1I'%2",
	["(%A)[iI][\"/;:`o]?([vV]+[eE]%A)"]		=	"%1I'%2",
--	Elongate 'em and em to 'them'
	["(%A)[\"/;:'`]?[eE]m(%A)"]		=	"%1them%2",

	["[lL]+e?ie?k(%A)"]		=	"like%1",

	["(%A[pP])robable(%A)"]	=	"%1ro~bable%2",

	["(%A[aA])ny([^%s%potpwbh])"]	=	"%1ny %2",
	["(%A[aA]ny%s?[oOpPwWbBhH]%w+%s)[nN]ow?(%A)"]	=	"%1 know%2",

	["(%A[sS])[o0u][mn]+e?%s?one([%s%p])"]	=	"%1omeone%2",
	["(%A[sS])[o0u][mn]+eone?([%s%p])"]	=	"%1omeone%2",
	["(%A[sS])[o0u][mn]+oene?([%s%p])"]	=	"%1omeone%2",


	["(%A[sS])[o0u]*[mn]+e?%s?th?i?n[g']?([%s%p])"]	=	"%1omething%2",
	["(%A[sS])[o0u]*[mn]+e?%s?[bB][o0u]d+[eiy]+([%s%p])"]	=	"%1omebody%2",

	["(%A[nN])oone(s?[%s%p])"]	=	"%1o one%2",


	["(%A[tT])hi?e[yi]?re?%s?([yY]?)our"]	=		"%1hey're %2our",
	["(%A[iI])ts%s?([yY]?)our"]	=		"%1t's %2our",

	["(%A)[mM]e%s[iI]'?m%s(%a+)"]		=	"%1me. I'm %2",

	["(%A)[aA]?[cC][oOuU][mM]+[iI][nN]['gG]?(%A)"]	=	"%1coming%2",


--	Replace 'ud'
	["(%A)ud(%A%a%a)"]	=	"%1you'd%2",


	["(%A)[yY]?o?u[\"/;:`]?l+(%A)"]		=	"%1you'll%2",
	["(%A)[yY]?o?u[\"/;:`]?re(%A)"]		=	"%1you're%2",
	["(%A)[yY]?o?u[\"/;:`]?ve?(%A)"]	=	"%1you've%2",

	["(%A)U[dD](%A)"]	=	"%1Undead%2",

	["([mM])in+%s?[lL]e?ve?l([sz]*%A)"]		=	"%1 minimum level%2",


	["(%A)[mM]in+[ui]+te?([sz]*%A)"]		=	"%1minute%2",

	["(%A)[mM]in+([sz]*%A)"]		=	"%1 minute%2",
	["(%A[sS])ec+([sz]*%A)"]	=	"%1econd%2",


	["(%A[nN])o%s?1([%s%p])"]		=	"%1o one%2",
	["(%A[sS])[o0u][mn]+e?%s?1([%s%p])"]	=	"%1omeone%2",
	["(%A[eE])v+e?ry?%s?1([%s%p])"]	=	"%1verybody%2",

--	Change 'a' to 'an' where necessary
	["([%s%p])[aA]%s+([aAeEiIoO]%a)"]	=	"%1an %2",
	["([%s%p])[aA]%s+([hH])our"]	=	"%1an %2our",

	["([%s%p])[aA]n%s+([trsdbpgczwxj]%a)"]	=	"%1a %2",


},

[4] = {
	["^.*$"]	=	Elo.ChopSpaces,
},

[5]={

--	Y at the start of a long sentence is usually "Why"
	["^[yY]%s(%a+%A+%a+%A+%a+)"]	=	"Why %1",



--	Refilter "cheetah"
	["([cC])heeter"]	=	"%1heetah",
--	Refilter "Booyah"
	["([bB])oo+h*yer"]	=	"%1ooyah",


},

[6]={

--	Fix r by itself 
	["^are$"]	=	"Ready",


	["^[iI]nv[ite]*%s(%S+)$"]		=	"Invite %1",

--	GRAMMAR?
--	"Its" is "It's" almost all the time when starting a line
	["^[iI]ts(%A)"]	=	"It's%1",

--	"its" followed by "the" two words later is usually "it's"
	["(%A[iI])ts%s(%a+)%s[tT]he(%A)"]	=	"%1t's %2 the%3",

	["(%d)(%d%d%d,)"]	=	"%1,%2",


},

[7]={

--	Replace sry, soory, soorry, and srry
	["^[sS]h?[oO]*[rR]+[yY]$"]			=	"I'm sorry",

	["^[oO](%p*)$"]			=	"Oh%1",
	["^[oO]h*%s+(%a)"]			=	"Oh, %1",
	["^[oO][oO]+%s*(%p%s%a)"]			=	"Ooh! %1",

--	Capitalise lone 'i' & roman numerals up to III
	["%Ai+%A"]	=	string.upper,
	["%Ai+$"]		=	string.upper,

	["^[bB]out%s"]			=	"It's about ",
	["%s[bB]out%s"]		=	" about ",
	["[iI]%A?m[jJ]ust(%A)"]		=	"I'm just%1",

	["([dD])ammag"]			=	"%1amag",

--	["%s[sS]ec+([sz]*)$"]	=	" second%1",
	["^[sS]h?ec+$"]			=	"Just a moment",






	["^[jJ]ah?(%A*)$"]			=	"Yes%1",
	["^[yY]+([.!]?)$"]			=	"Yes%1",
	["^[yY]+%?$"]					=	"Why%?",
--	GRAMMAR
	["^[yY]%s?[bB]ecause"]				=	"Why? Because",
	["^[yY]%s?[cC]an"]				=	"Why can",
	["^[yY]%s?[nN]ot"]				=	"Why not",
	["^[yY][\"/;:%s]*[iI']s"]		=	"Why is",
--	["^[yY][aA][rR]+(%A)"]				=	"Yes%1",
	["^[yY]%s[aA'][rR]e?"]			=	"Why are",
	["^[yY]%s?[wW]as"]				=	"Why was",
	["^[yY]%s?[tT]he"]				=	"Why the",
	["^[yY]%s?[wW]ere?"]			=	"Why were",
	["^[yY]%s?[dD]id"]				=	"Why did",
	["^[yY]%s?[dD]on'?t"]			=	"Why don't",
	["^[yY]%s(%a%a+)%?"]		=	"Why %1%?",
	["^[yY]s%s?[tTDd]h?at%??"]		=	"Why is that%?",
	["%s[yY]%s(%a)"]				=	" why %1",
	["%s[yY]%?"]				=	" why%?",
	["(%A)[aA]sk%s[yY](%A*)$"]				=	"%1ask why%2",



--	Replace whatcha, wotcha, wutcha, whucha, etc.
	["([wW])[hH]?[aAuUoO][hH]?[tT]?[cC][hH][aA]([^bB])"]	=	"%1hat are you%2",


--	Replace 'ya' with 'yes' or 'you' depending on context.
--	["(%A)[yY][aA](%A)"]	=	"%1you%2",
	["^[yY][aA]+[hH]?(%p)"]		=	"Yes%1",
	["^[yY][aA]%s[yY]ou"]		=	"Yes, you ",
	["^[yY][aA]%s[wW]e"]		=	"Yes, we ",
	["^[yY][aA]%s[tT][hH](%a)"]		=	"Yes, th%1",
	["^[yY][aA]+[hH][%s,]"]		=	"Yes, ",
--	["(%A)[yY][aA]$"]		=	"%1you",
	["^[yY][aA]+[hH]?$"]			=	"Yes",

	["^[yY][aA]+%s[iI]t%s"]			=	"Yes, it ",

	["[sS]ee+%s?[yY]ah?"]		=	"see you",

	["^[nN]+a+[wh]+%s"]		=	"No, ",
	["^[nN]+a+[wh]+(%p)"]	=	"No%1",
	["^[nN]+a+[wh]+$"]		=	"No, no%.",


--	Replace 'n' if not followed by space and 'e' or 'o'
--	experimental
	["([^%a.'])[nN]%s+([^%s%peE])"]	=	"%1and %2",
	["([^%a.'])[nN]$"]			=	"%1and",
	["^[nN](%s[^eE])"]	=	"No%1",

--	Remove superfluous 'at' in place queries.
	["([wW])here(.-)[iI]t'?[sS]%s[aA]t(%p*)$"]		=	"%1here%2it is%3",

	["[nN]e?ve?rmind"]	=	"never mind",

--	Add ? to questions at end of line
	["^[wW]ho%p?$"]			=	"Who%?",
--	["^[wW]hat%s([^?,.]+)[?.]*$"]		=	"What %1%?",
	["^[wW]hat%p?$"]			=	"What%?",


	["^[wW]e?he?re?$"]		=	"Where%?",
	["^[wW]h?eh?n%p?$"]			=	"When%?",
	["^[wW]hy$"]			=	"Why%?",
	["^[hH]ow$"]			=	"How%?",
	["^[hH]ow%A*[mM]uch$"]			=	"How much%?",
	["^[lL]evels%?+$"]			=	"What levels are they%?",
--	["^[wW]h?ih?ch%s([^?,.]+)[?.]*$"]	=	"Which %1%?",
	["^[wW]h?ih?ch$"]		=	"Which%?",

--	Replace 'yoyo' at start of line
	["^[yY][oO][yYoO]*[^%a%d|?]+"]	=	"Yo, ",
	["^[yY][oO][yYoO]*$"]	=	"Yo!",


	["|r%s?[sS]ell$"]	=	"|r for sale!",
	["%sgold%s[sS]ell$"]	=	" gold",
	["%+(%d+)(%a)"]				=	"%+%1 %2",


--	Deteriorated GRAMMAR
	["^[aA]nyone%s[hH]ave%s(.-)[?.]*$"]		=	"anyone have %1%?",
	["^[aA]ny%s(%a+)s%s[aA]ble%s[tT]o%s(.-)%?"]		=	"would any %1s be able to %2%?",
	["^[aA]ny%s(%a+)s%s[cC]an%s(.-)%?"]		=	"can any %1s %2%?",
	["^[sS]omeone%s[cC]an%s(%a+%A+%a.-)%?"]		=	"could someone %1%?",
	["^[aA]ny%s(%a+)s%s[cC]an%s(.-)please"]		=	"can any %1s %2%?",



	["^[iI]s%s[tT]h?ere?%s[aA]ny%s(%a%a-s[%s%a]+)[?.]*"]		=	"are there any %1%?",
	["^([tTwW])h?ere?[%si']*s%s(%a%a%a%a[^%s%d%paeiou]-s%A%a%a+)"]	=	"%1here are %2",

	["^([wW]hat['s]+%s[%a%s]+)$"]	=	"%1%?",


--	Replace 'ill' and 'il' with 'I'll'
	["^[iI][\"/;:`o]?l+([%s,.!?:;])"]		=	"I'll%1",
	["(%A)[iI][\"/;:`o]?l+([%s,.!?:;])"]	=	"%1I'll%2",

},

[8]={

	["([gG]old)%s[pP]er(%A*)$"]	=	"%1 each%2",

--	Remove superfluous 'at' in place queries.
	["([wW])here(.-)%s[aA]t(%p*)$"]		=	"%1here%2%3",

	["([wW])here%s[yY]ou%s[aA]t(%s?[%a%p]*)$"]		=	"%1here are you%2%?",
	["^[wW]h?ere?([%s%a]-)%sat%??$"]	=	"Where%1?",




	["^[aA]re%s[yY]ou([^?,.]+)[?.]+"]		=	"are you%1%?",

	["^[aA]ny%s(%a%a%a-)s%s[wW]ant([^?,.]+)[?.]+"]		=	"would any %1s want%2%?",

	["^[aA]ny%s(%a%a%a-s.-)%s[tT]hat%s[cC]an([^?,.]+)[?.]+"]		=	"are there any %1 who can%2%?",


	["^[aA]ny%s(%a%a%a-)s%s[wW]ho([^?,.]+)[?.]+"]		=	"could any %1s %2%?",

	["([wW]h%a+)%s[yY]ou%s(%a%a%a%a-)ig?n[g']?[?.]*$"]	=	"%1 are you %2ing%?",
	["([wW]h%a+)%s[yY]ou%s(%a%a%a%a-)ig?n[g']?([^%a?,][^?,]-)[?!]+"]	=	"%1 are you %2ing%3%?",

	["([wW]h%a+)%s[wW]e%s(%a%a%a%a-)ig?n[g']?[?.]*$"]	=	"%1 are we %2ing%?",
	["([wW]h%a+)%s[wW]e%s(%a%a%a%a-)ig?n[g']?([^%a?,][^?,]-)[?.]+"]	=	"%1 are we %2ing%3%?",

	["[iI]s%sthere%sany%s(%a%a%a-s%s)([^?,.]+)[?.]*"]		=	"are there any %1%2%?",
	["[iI]sn't%sthere%sany%s(%a%a%a-s%s)([^?,.]+)[?.]*"]		=	"aren't there any %1%2%?",
	["^[aA]ny%s(%.-)%s[aA]vail%s([^?,.]+)[?.]*"]		=	"are any %1 available %2%?",
	["^[yY][oua]+%sbet+er"]			=	"you had better",
--	["^[cC]an%s(%a+%s%a[^%d?,.]+)[?.]*$"]	=	"can %1%?",
	["^[wW]e%s?([dDgG])oing([^?,.]+)%?+"]	=	"Are we %1oing%2%?",
	["^[nN]eed%s([^tT][%a%s]*)%?$"]		=	"Do you need %1%?",
--	["^[nN]eed%s([^tT][^?]+)$"]		=	"I need %1",
--	["^[nN]eed%s[tT]o%s([^?]+)$"]	=	"I need to %1",
	["^[wW]ant%s([^tT][%a%s]*)%?$"]		=	"Do you want %1%?",
--	["^[wW]ant%s[tT]o%s([^?]+)$"]	=	"I want to %1",
	["^[wW]anted%s[tT]o%s([^?]+)$"]	=	"I wanted to %1",

	["^[sS]h?ee%sth(.-)%?$"]		=	"do you see th%1%?",

--	Too much cheer
	["[hH]a+[hH]a+h+[ha]*"]		=	"hahaha",

	["([yY])our%scan"]			=	"%1ou can",
	["([wW])e%swas"]			=	"%1e were",
	["([tT])h?ey%swas"]			=	"%1hey were",


	["([wW])hat%sare%syou%sgot"]	=	"%1hat do you have",
	["(%a%a)%sbecause%s(%a+)%s[tT]o%s(%a%a)"]			=	"%1 cause %2 to %3",
	["([tT][ho]e?)%s?because"]			=	"%1 cause",
	["(%A[aA])%s?because"]			=	"%1 cause",
	["([lL])ost%s?because"]			=	"%1ost cause",
	["([mM])ore%s?4(%D)"]		=	"%1ore for%2",
	["(%A)To(%A)"]		=	"%1to%2",


},

[9]= {
	["^(.+)$"]	=	Elo.AnalyzeGrammar,
},
[10]= {
},
[11]= {
},
[12]= {
	["^(.+)$"]	=	Elo.WipeGrammarTags,
},
[13]= {
},
[14]={

--	testing
	["(%A)[aA][hH][hH]+%s(%a)"]		=	"%1Ahh, %2",


},

[15]={
--	Mistaken plural
	["(%a)x+s(%A)"]	=	"%1xes%2",




--	Correct other contraction / possessive typos (Dave;s Dave"s Dave:s etc. to Dave's)
	["(%a%a)[\"/;:`][eE]?([sdl]+%A)([^%2]+)$"]	=	"%1'%2%3",


--	Refilter "the might of the Horde" etc.
	["([tT])he%s[mM]i([gc])ht%shave%s"]	=	"%1he mi%2ht of ",


--	Separate digits from words of four or more letters (To preserve links and nominals.)
	["%s(%a%a+)(%d+)%s"]	=	" %1 %2 ",
	["([%s%+%-]%d+)(%a%a%a)"]	=	" %1 %2",

	["(%a%a)%s*[xX]%s*(%d+)"]	=	"%1 x%2",

--	Catch 'possib;e' etc.
--	["(%a%a);+([^%p%s%dls]+%A)"]		=	"%1l%2",


},
[16] = {

	["(%A)[cC]an%s[nN]ot(%A)"]	=	"%1cannot%2",
	["([tT])he%s[tT]he%s"]			=	"%1he ",

	["(%w)[%s;,'.]*([!?][!?])[1!?@%s]*"]		=	"%1%2 ",


},

[17] = {
	["^.*$"]	=	Elo.ChopSpaces,
},

[18]={

	["(%a)[%s,]+'s(%A)"]	=	"%1's%2",

--	Reduce sets of three or more hyphens to two
--	["%s*%-%-%-+%s*"]	=	" %-%- ",

	["[%s,]*%.%.+"]	=	"%.%.%.",
	["(%a)%s*[;:][;:]+%s*"]	=	"%1, ",
	["(%a)%s+([,;:?!]%s+%a)"]	=	"%1%2",
	["%s*[;,./]+%s*([?!,;:][%a%s(\"]%a)"]	=	"%1",
	["%s*([?!,;:])%s*[;,./]+([%a%s(\"]%a)"]	=	"%1%2",
	["([;,.]+)%s*[-/]+"]	=	"%1 ",
	["^,+%s*(%a)"]	=	"%1",

--	Adjust spacing at end of item names
	["|r([^%s,.;:!?*)\"'])"]				=	"|r %1",

	["(%a)[,.%s%])]*[/\\]+[,.%s%[(]*([-+%a])"]	=	"%1 / %2",


--	Replace two lone periods with ellipses
	["([^.])%.%.([^.])"]	=	"%1%.%.%.%2",
	["([^.])%.%.$"]	=	"%1%.%.%.",
	["^%.%.([^.])"]	=	"%.%.%.%1",

	["(%d?)%s?@%s"]		=	"%1 at ",

--	Parantheses spacing
	["([%a%d])%s*%(+%s*([^)]-)%s*%)+%s*([%a%d])"]		=	"%1 %(%2%) %3",


	["%s*[!~]%s*[~!]+([^?]%w)"]	=	"!! %1",

	["(%a)%s*([;,])%s*(%w)"]		=	"%1%2 %3",


	["%s*([;,:])[%s!?.}{]+(%w)"]		=	"%1 %2",
	["%s*[;,:]%s*([!?.]+)$"]		=	"%1",

	["%s?[~!?.]%s?[;,]+(%l)"]		=	", %1",

	["(..[%w'\")])%s*[~!?.,;/]%s*[;,/]+%s*([!.?])"]		=	"%1%2",

	["%s+%.(%D)"]		=	".%1",

--	Change exclamation to comma if first word followed by others
	["^(%a[%a']+)!+(%A*%a+%A+%a)"]	=	"%1,%2",

--	Recap XD smiley
	["([%s%p])[xX]d"]	=	"%1XD",


	["([^chHr%s])%s*|+%s*([^chHr%s])"]	=	"%1, %2",

--	Replace common ending punctuation typos
	["^([^!].-[%w|']%w)[%s|,-]*$"]	=	"%1%.",
	["(%w%w[)'])[%s|,-.]*$"]	=	"%1%.",
	["(%w[%w'\")])%s*[?/]+%s*$"]	=	"%1%?",
	["^([^<][^<]-[%w%s]%w)[%s?]*>+[?%s/]*$"]	=	"%1%?",
	["(%w%w)%s*[@!]%s*$"]	=	"%1!",
	["(%w%w)%s*[!~`]%s*$"]	=	"%1!",

	["^([^(:;][^(:;^_]-)%s?[,.]?%s?%)$"]	=	"%1%.",


},
}
