local gsub = string.gsub
local lower = string.lower
local gmatch = string.gmatch
local find = string.find
local elogsub = Elo.gsub
local p = pairs
--	Add grammar to all manner of LFG messages.

local lfglist = {
	["Stratholme"] = {
		{["Stratholme%A+Undead"] = true},
		{["Stratholme%A+Live"] = true},
		{["Stratholme%A+Baron"] = true},
		{["Baron%A+of%A+Stratholme"] = true},
		{["45%-[mM]inute%sBaron"] = true},
--		{["Baron"] = true},
	},
	["Deadmines"] = true,
	["Van Cleef"] = true,
	["Stockades"] = {
		{["[sS]tocks?"] = true},
	},
	["Scholomance"] = true,
	["Dire Maul"] = {
		{["Dire Maul [wW]est"] = true},
		{["Dire Maul [eE]ast"] = true},
		{["Dire Maul [nN]orth"] = true},
		{["Dire Maul [tT]ribute"] = true},
--		{["[tT]ribute"] = true},
	},
	["Scarlet Monastery"] = {
		{["Scarlet Monastery [gG]raveyard"] = true},
		{["Scarlet Monastery [aA]rmory"] = true},
		{["Scarlet Monastery [cC]athedral"] = true},
		{["Scarlet Monastery [lL]ibrary"] = true},
--		{["[aA]rmory"] = true},
--		{["[cC]athedral"] = true},
--		{["[lL]ibrary"] = true},
	},
	["Sunken Temple"] = true,
	["Wailing Caverns"] = true,
	["Shadowfang Keep"] = {
		{["[sS]hadow%A*[fF]ang%A*[kK]eep"] = true},
	},
	["Molten Core"] = {
		{["Attunement"] = true},
	},
	["Zul'Farrak"] = true,
	["Zul'Gurub"] = true,
	["Maraudon"] = true,
	["Uldaman"] = true,
	["Blackrock Depths"] = {
		{["Emperor%A+of Blackrock Depths"] = true},
	},
	["Blackwing Lair"] = {
		{["Onyxia"] = true},
	},
	["Blackrock Spire"] = {
		{["Lower Blackrock Spire"] = true},
		{["Upper Blackrock Spire"] = true},
	},
	["Razorfen"] = {
		{["Razorfen Kraul"] = true},
		{["Razorfen Downs"] = true},
	},
	["Ragefire Chasm"] = true,
	["Gnomeregan"] = true,
	["Blackfathom Deeps"] = true,
	["Ahn'Qiraj"] = {
		{["Ruins%A+of Ahn'Qiraj"] = true},
		{["Temple%A+of Ahn'Qiraj"] = true},
	},
	["Warlord's Command"] = true,
	["Test of Skulls"] = true,
	["Alterac Valley"] = {
		{["organized Alterac Valley"] = true},
		{["premade Alterac Valley"] = true},
		{["Alterac Valley premade"] = true},
	},
	["Arathi Basin"] = {
		{["organized Arathi Basin"] = true},
		{["premade Arathi Basin"] = true},
		{["Arathi Basin premade"] = true},
	},
	["Warsong Gulch"] = {
		{["organized Warsong Gulch"] = true},
		{["premade Warsong Gulch"] = true},
		{["Warsong Gulch premade"] = true},
	},
	["Eye of the Storm"] = {
		{["organized Eye of the Storm"] = true},
		{["premade Eye of the Storm"] = true},
		{["Eye of the Storm premade"] = true},
	},
	["Strand of the Ancients"] = {
		{["organized Strand of the Ancients"] = true},
		{["premade Strand of the Ancients"] = true},
		{["Strand of the Ancients premade"] = true},
	},
	["Durnholde"] = true,
	["Underbog"] = true,
	["Shattered Halls"] = true,
	["Ramparts"] = true,
	["Mana Tombs"] = true,
	["Mechanar"] = true,
	["Botanica"] = true,
	["Gruul's Lair"] = {
		{["[gG]ruul"] = true},
	},
	["Sethekk Halls"] = true,
	["Blood Furnace"] = true,
	["Arcatraz"] = true,
	["Shadow Labyrinth"] = true,
	["Slave Pens"] = {
		{["[sS]lave%A?[pP]ens"] = true},
	},
	["Auchenai Crypts"] = {
		{["[cC]rypts?"] = true}
	},
	["Blood Marsh"] = true,
	["Steamvault"] = true,
	["Magtheridon's Lair"] = true,
	["Magister's Terrace"] = true,
	["Utgarde Keep"] = true,
	["The Nexus"] = true,
	["Azjol-Nerub"] = true,
	["Ahn'Kahet"] = {
		{["[tT]he [oO]ld [kK]ingdom"] = true},
	},

	["Drak'Tharon Keep"] = true,
	["Violet Hold"] = true,
	["Gundrak"] = true,
	["Ulduar"] = {
		{["[hH]alls [oO]f [sS]tone"] = true},
		{["[hH]alls [oO]f [lL]ightning"] = true},
		{["[uU]lduar"] = true},
	},

	["Utgarde Pinnacle"] = true,
	["Oculus"] = true,
	["Naxxramas"] = true,
	["Obsidian Sanctum"] = true,
	["Eye of Eternity"] = true,
	["Vault of Archavon"] = true,
	["Icecrown Citadel"] = true,

	["Caverns of Time"] = {
		{["[cC]averns%A+[oO]f Time"] = true},
		{["[oO]ld Hillsbrad"] = true},
		{["[eE]scape%A+[fF]rom [dD]urnholde? [kK]eep"] = true},
		{["[bB]attle%A+[oO]f [mM]ount [hH]yjal"] = true},
		{["[bB]lack%s[mM]orass"] = true},
		{["[mM]ount [hH]yjal"] = true},
		{["[oO]pening%A+[tT]he [dD]ark [pP]ortal"] = true},
		{["[tT]he [dD]ark [pP]ortal"] = true},
		{["[tT]he [cC]ulling [oO]f [sS]tratholme"] = true},
	},
	["Seth"] = true,
--	[""] = true,

	["Karazhan"] = true,
}


local lfgabbs = {
	{["[lL](%d*)[mM]+"]			=	"LF%1M"},
	{["[gGdDpPtT]"]	=	"7@a group"},
	{["[mM]ore"]			=	"more"},

	{["[gG]uild"]	=	"7@a guild"},

	{["!%s*[mM]+"]			=	"1 M"},
	{["@%s*[mM]+"]			=	"2 M"},
	{["#%s*[mM]+"]			=	"3 M"},
	{["$%s*[mM]+"]			=	"4 M"},


	{["(%d*)[mM]+'s"]			=	"%1M"},
	{["[mM]+(%d+)[mM]*"]			=	"%1 more"},


	{["(%d)%s*[mM]+"]			=	"%1 more"},

	{["[mM]+"]			=	"more"},

	{["[sS]"]	=	"81@someone"},
	{["[^%a%d]*[hH]elp"]		=	"help"},
	{["[gG]uardian"]		=	"7@a guardian"},
	{["[tT]ank"]		=	"7@a tank"},
	{["[hH]ealer"]		=	"7@a healer"},
	{["[tT]anks"]		=	"tanks"},
	{["[hH]ealer[sz]"]		=	"healers"},
	{["[cC][cC]"]		=	"crowd-controller"},
	{["[dD]amage%sper%ssecond"]		=	"7@damage%-dealer"},
	{["[dD][pP][sS]"]		=	"7@damage%-dealer"},
	{["[wW]"]		=	"work"},
	{["[hH]"]		=	"7@a healer"},
	{["[bB][sS]"]			=	"blacksmith"},
	{["[eE]ng"]	=	"engineer"},

--	{[""]		=	""},

}


--	Only expand if we're sure it's an LFG message
local lfgonly = {
	{["[sS]trath?"]	=	"Stratholme"},
	{["[mM][cC]"]	=	"Molten Core"},
	{["[bB][mM]"]	=	"Black Morass"},
	{["[sS][pP]"]	=	"Slave Pens"},
	{["[uU][bB]"]	=	"Underbog"},
	{["[bB][tT]"]	=	"Black Temple"},
	{["[sS][hH]"]	=	"Shattered Halls"},
	{["[sS][lL]"]	=	"Shadow Labyrinth"},
	{["[sS]labs*"]	=	"Shadow Labyrinth"},
	{["[aA][cC]"]	=	"Auchenai Crypts"},
	{["[aA][rR][cC]"]	=	"Arcatraz"},
	{["[bB]ot"]	=	"Botanica"},
	{["[mM]ag"]	=	"Magtheridon's Lair"},
	{["[rR]amp[sz]*]"]	=	"Ramparts"},
	{["[sS][mM][aA]"]	=	"Scarlet Monastery Armory"},
	{["[tT][oO][sS]"]	=	"Test of Skulls"},
	{["[lL]([12356789])[mM]"]	=	"2@looking 5@for %1 more"},
	{["[lL][gG]"]	=	"2@looking 5@for 7@a group"},
	{["[lL][mM]"]	=	"2@looking 5@for more"},
	{["[mM][tT]"]	=	"main tank"},
	{["[rR]eg"]	=	"regular"},
--	{["[lL]ock"]	=	"Warlock"},
	{["[sS]ham"]	=	"Shaman"},
--	{["[hH]"]	=	"heroic"},
	{["[cC][cC]"]	=	"crowd control"},
	{["[cC][oO][tT]"]	=	"Caverns of Time"},
	{["[dD]urn"]	=	"Durnholde"},
	{["[kK]ara"]	=	"Karazhan"},
	{["[bB][sS]"]			=	"blacksmith"},
	{["[eE]ng"]	=	"engineer"},
	{["[cC][oO][sS]"]	=	"Culling of Stratholme"},
	{["[aA][%poO]?[eE][rR]*"]	=	"area%-bombardment"},
	
	{["(%A)[uU][pP](%A)"]	=	"%1Utgarde Pinnacle%2"},
	{["(%A)[oO][kK](%A)"]	=	"%1Old Kingdom%2"},
}

local levelclasscombos = {
	"%s(%d%d)%s+%a*%s*86@(%a+)",
	"86@(%a+)%s+5@of%s+(%d%d)%s%a+",
}

local lfgmodifiers = {
	["Hero"] = true,
	["hero"] = true,
	["Heroic"] = true,
	["Normal"] = true,
	["Regular"] = true,
	["heroic"] = true,
	["normal"] = true,
	["regular"] = true,
	["Heroics"] = true,
	["Normals"] = true,
	["Regulars"] = true,
	["heroics"] = true,
	["normals"] = true,
	["regulars"] = true,
	["non-heroic"] = true,
	["non-heroics"] = true,

}

local lfsyn = {
	"2@looking 5@for",
	"2@looking 5@for",
	"2@looking 5@for",
	"2@looking 5@for",
	"2@looking 5@for",
	"5@in 0@search 5@of",
	"2@searching 5@for",
	"2@searching 5@for",
	"2@seeking",
	"2@seeking",
	"2@seeking",
}

--	["^(%s?[lL][fF].-)[.,!%-><]+%s?[hH]ave([^?]+)$"]	=	"%1; I have %2",
--	["^(%s?[lL][fF].-)[.,!%-><]+%s?[gG]ot([^?]+)$"]	=	"%1; I got %2",
--	["^(%s?[lL][fF].-)[.,!%-><]+%s*[nN]eed([^?]+)$"]	=	"%1; I need%2",
--	["[.,!%-]+%s*[wW]ant%s([^?]+)$"]	=	"; I want %1",
local lf = "([lL]ook%a+%s5@[fF]or"


local function filterwordsonly(msg,filter)
	if msg and filter then
		for a,b in p(filter) do  --a=key, b=value
			for k,v in p(b) do --k=key, v=value
				msg = gsub(msg,"%f[%a]"..k.."%f[^%a%d|[]",v)
			end
		end
	end
	return msg
end


local function processlfg(msg)
	if not IsInInstance() and (find(Elo.Event,"CHANNEL") or find(Elo.Event,"CUSTOM") or find(Elo.Event,"YELL")) then
		msg = gsub(msg,"^%A+[nN]eed%f[%A]"," 2@looking 5@for")
		msg = filterwordsonly(msg,lfgonly)
		local classtotal = 0
		local classnum
		for k,v in p(Elo.ClassTable) do
			msg,classnum = elogsub(msg,"%f[%a]("..k.."['sz]*)%f[%A]","86@%1")
			classtotal = classtotal + classnum
		end
		local total = 0
		local subtotal = 0
		local count = 0
		for k,v in p(lfglist) do

			msg = elogsub(msg,k.."%A+[hH]ave%s%f[%a]",k..". 82@We 0@have ")
			msg = elogsub(msg,k.."%A+[nN]eed%s%f[%a]",k..". 82@We 0@need ")

			subtotal = 0
			count = 0
			if type(v) == "table" then
				for a,b in p(v) do --a=key, b=value
					for x,y in p(b) do --x=key, y=value
						msg,count = gsub(msg,lf..".-)%s?("..x..")%s?[/|~@#*]*","%1 85@%2 ")
						subtotal = subtotal + count
					end
				end
			end
			if subtotal == 0 then
				msg,subtotal = gsub(msg,lf..".-)%s?("..k..")","%1 85@%2")
				msg,subtotal = gsub(msg,lf..".-)%s?("..lower(k)..")","%1 85@"..k)
			end
			total = total + subtotal
		
		
		end
		for k,v in p(lfgabbs) do
			for a,b in p(v) do --a=key, b=value
				msg = elogsub( msg,"2?@?[lL]ook%a*%s5@[fF]or[%s%p]*"..a.."%f[^%d%a]"," looking 5@for "..b )
			end
		end

		msg = gsub(msg,"(%S+)%s(85@)",function(a,b)
					if lfgmodifiers[a] then return b..a.." " end
				end
				)



		msg = elogsub(msg,"[^%a%d)(!%]%[]+(85@%a)"," %1")

		msg = elogsub(msg,"%f[%a][oO]r%s85@","85@",1)
		msg = elogsub(msg,"([%s%p]5@%a+%s)85@","%1",1)

		msg = elogsub(msg,"%s85@"," 5@for ",1)


		if total == 2 then
			msg = elogsub(msg,"%s85@"," or ",1)
		else
			msg = elogsub(msg,"(5@.-)85@(.-85@%a.*)$","%1, %2",total-1)
			msg = elogsub(msg,"%s85@(.-85@%a.*)$",", %1",total-1)
			msg = elogsub(msg,"%s85@",", or ",1)
		end

		msg,abbsfound = elogsub(msg,"2?@?[lL]ook%a+%s5@[fF]or(%A.)",lfsyn[math.random(1,#(lfsyn))].."%1")

--		Add speaker's class/level data if we don't have it already
		if classtotal == 1 and abbsfound > 0 then
			local entry = ElDat[Elo.Srv][Elo.Faction][arg2]
			for k,v in p(levelclasscombos) do
				for first,second in gmatch(msg,v) do
					if tonumber(first) then
						Elo.AddRaceData(arg2,first,nil,second)
					else
						Elo.AddRaceData(arg2,second,nil,first)
					end
				end
			end
		end
	end

	return msg
end


Elo.Abbreviations={

[1]={
--	["^%s*[lL;][fF](%d*)[mM]%s*4(%D)"]	=	" LF%1 for %2",

--	["%s[lL;]%s?[fFrR]([%s%p]*%d+)%s?[mM]+['sS]+%s"]	=	" LF%1 more ",

	["^%s[wW][tT][hH](%a%a-[eo]r%A+%a+%A+%a+)"]	=	"LF %1",

	["([%s%p])[oO]ne([%s%p])"]		=	"%11%2",

	["(%d%A*)[pP]t([sz]*%A)"]	=	"%1 point%2",


--	Standardise numerals for later filters
	["([%s%p])[oO]ne([%s%p])"]		=	"%11%2",
	["([%s%p])[tT]wo([%s%p])"]		=	"%12%2",
	["([%s%p])[tT]hree([%s%p])"]		=	"%13%2",
	["([%s%p])[fF]our([%s%p])"]		=	"%14%2",

--	Prep 'press r' etc so later filters don't make it 'press are'
	["(%A[pP])ress%s([^%s%pa])([%s%p])"]			=	"%1ress '%2'%3",
	["(%A[hH])old%s([^%s%pa])([%s%p])"]			=	"%1old '%2'%3",
	["(%A[hH])it%s([^%s%pa])([%s%p])"]			=	"%1it '%2'%3",
	["(%A[sS])hift%s([^%s%pa])([%s%p])"]			=	"%1hift '%2'%3",
	["(%A[aA])lt%s([^%s%d%pa])([%s%p])"]			=	"%1lt '%2'%3",
	["(%A[cC])o?n?tro?l%s([^%s%d%pa])(%A)"]	=	"%1ontrol '%2'%3",

	["(%A)[tT]he%s[yY](%A)"]	=	"%1the 'Y'%2",
	["(%A)[aA]%s[yY](%A)"]	=	"%1a 'Y'%2",
	["(%A)[hH][pP][sS]?(%A)"]	=	"%1Health%2",
	["(%A)[mM][pP][sS]?([^%a3])"]	=	"%1Mana%2",
	["(%A)[pP][wW]:%s?[sS](%A)"]	=	"%1Power Word: Shield%2",
	["(%A)[pP][wW]:%s?[fF](%A)"]	=	"%1Power Word: Fortitude%2",

	["^%s*[wW][tT][sS]mith%s"]	=	" I'll smith ",

	["(%A)10[mM](%A)"]	=	"%1ten man%2",
	["(%A)25[mM](%A)"]	=	"%1twenty five man%2",
	["(%A)40[mM](%A)"]	=	"%1forty man%2",

	["(%A)[aA]nd%s?[gGrR][tT2][gG](%A)"]		=	"%1and we're good to go%2",
	["(%A)[wW]e%s?[gGrR][tT2][gG](%A)"]		=	"%1we're good to go%2",
	["(%A)[tT]h[ea]n%s?[gGrR][tT2][gG](%A)"]		=	"%1then we're good to go%2",
	["[iI]'?m%s?[gGrR][tT2][gG]"]		=	"I'm good to go",
	["[iI]'?ve?%s?[gG][tT2][gG]"]		=	"I have got to go",
	["(%A)[fF][fF][sS](%A)"]	=	"%1for heaven's sake%2",
	["(%A)[cC][bB][aA](%A)"]	=	"%1can't be bothered%2",

	["(%A)[sS]haz+(%A)"]	=	"%1Shazzrah%2",

	["(%A)[nN]%s?1(%s.-%?)"]	=	"%1anyone%2",

	["%s[nN]eed(s?.-)[wW][aA][rR]+([sz]*)([%s!,.]+%a%a)"]			=	" need%1 Warrior%2 %3",
	["%s[lL]%s?[fFrR4]%s?[pP]r[ei]+st([%s!,.]+%a%a)"]			=	" LF a Priest%1",
	["%s[lL]%s?[fFrR4](.-%A)[sS][hH][aA][mM]%a-([sz]*)(%s+%a%a)"]			=	" LF%1 Shaman%2 %3",
	["^(%d+)%s?[wW][aA][rR]+([sz]*)%s[lL][fF][gG]([%s!,.]+%a%a)"]			=	"%1 Warrior%2 LFG%3",

--	With * to mean "here's what I really meant"
	["^%s*(%w[%w']+)%s?[*&(]+%s*$"]		=	" %1, rather ",
	["^%s*%*+%s*$"]		=	" That's what I wanted to say ",
	["^%s*%*+(%w[%w']+)%s*$"]		=	" Er, I meant \"%1\" ",

	["(%A)[xX]%A*mut([ei])"]			=	"%1transmut%2",



	["(%A[pP])re%s?req+([sz]-%A)"]		=	"%1prerequisite%2",
	["(%A)[mM]in%s?req+([sz]-%A)"]		=	"%1minimum requirement%2",
	["(%A)[tT]he%s?[mM]in(%A)"]		=	"%1the minimum%2",

--	Keep 'PST' if necessary for grammar
	["(%A[cC]an%s.-)[pP][sS][tT]%s?[mM]?e?(%A)"]	=	"%1send word%2",

	["(%A)[pP][sS][tT]%s?[mM]?e?%s([\"'!]%a%a)"]	=	"%1whisper %2",


	["^%s+([gGnN]%a),?%s[aA]ll(%A+)$"]		=	" %1, everyone%2",

	["(%A)[sS]h?%A*[tTdD]%A*[fFhH]%A*[uU]i?(%A)"]	=	"%1shut up%2",

	["(%A)[sS][tT][rRaA][aAhHrRtT]%a*[sS][mM](%A)"]	=	"%1Stratholme Scarlet%2",

	["%sDE'?e?d([%s%p])"]		=	" disenchanted%1",
	["%sDE'?ing([%s%p])"]		=	" disenchanting%1",

},

[2]={
--	Nix superfluous 'plz'
	["(%A)[pP][sS][tT](%s.-%s?)[pP]l[ea]*[zs]e?(%A)"]		=	"%1PST %2%3",

	["(%A[lL][fF].-%s)[lL]+[wW]+(%A)"]		=	"%1leatherworker%2",
	["(%A[lL][fF].-%s)[jJ]+[cC]+(%A)"]		=	"%1jewelcrafter%2",
	["(%A[lL][fF].-%s)[aA]+lch(%A)"]		=	"%1alchemist%2",

	["([%s%p])DE([%s%p])"]		=	"%1disenchant%2",

	["(%A)[lL]+[wW]+(%s.-%f[%a][lL][fF])"]		=	"%1leatherworker%2",
	["(%A)[jJ]+%A*[cC]+(%s.-%f[%a][lL][fF])"]		=	"%1jewelcrafter%2",
	["(%A)[aA]+lch(%s.-%f[%a][lL][fF])"]		=	"%1alchemist%2",

	["^%s*[nN]%s?(%d+%s%a)"]	=	" Need %1",
	["^%s*[nN]%s?(%d+)([mM])"]	=	" Need %1 %2",

	["(%A+)[uUbB][dD]%s*[sS][tT][rRaA][aAhHrRtT]%a*(%A)"]	=	"%1Stratholme Undead%2",
	["(%A+)[uUbB][dD]%s*[sS][tT][rRaA][aAhHrRtT]%a*(%A)"]	=	"%1Stratholme Undead%2",
	["([%s!,.]+)[sS]courge%s*[sS][tT][rRaA][aAhHrRtT]%a*(%A)"]	=	"%1Stratholme Undead%2",
	["([%s!,.]+)[B]aron%s*[sS][tT][rRaA][aAhHrRtT]%a*(%A)"]	=	"%1Baron of Stratholme%2",
	["([%s!,.]+)[sS][tT][rRaA][aAhHrRtT]%a*%s*[B]aron(%A)"]	=	"%1Baron of Stratholme%2",
	["([%s!,.]+)[sS][cC]%A*[sS][tT][rRaA][aAhHrRtT]%a*(%A)"]	=	"%1Stratholme Scarlet%2",
	["(%A)[sS]carlet%s?[sS][tT][rRaA][aAhHrRtT]%a*(%A)"]	=	"%1Stratholme Scarlet%2",
	["(%A)[lL]i[fv]%a*%s?[sS][tT][rRaA][aAhHrRtT]%a*(%A)"]		=	"%1Stratholme Scarlet%2",
	["(%A)[sS][tT][rRaA][aAhHrRtT]%a*[%s!,.]*[dD][ea]+d(%A)"]		=	"%1Stratholme Undead%2",
	["(%A)[sS][tT][rRaA][aAhHrRtT]%a*[%s!,.]*[dD][ea]+dside(%A)"]		=	"%1Stratholme Undead%2",
	["(%A)[sS][tT][rRaA][aAhHrRtT]%a*[%s%p]*[uUbB][dD](%A)"]		=	"%1Stratholme Undead%2",
	["(%A)[sS][tT][rRaA][aAhHrRtT]%a*[%s%p]+[sS]c(%A)"]		=	"%1Stratholme Scarlet%2",
	["(%A)[sS][tT][rRaA][aAhHrRtT]%a*[%s%p]+[lL]i[fv]e(%A)"]		=	"%1Stratholme Scarlet%2",

	["(%A)[bB]aron%s?45(%A)"]	=	"%1Baron of Stratholme%2",

	["(%A)[oO]rg%s[aA][bB](%A)"]	=	"%1organized Alterac Valley%2",
	["(%A)[oO]rg%s[aA][vV](%A)"]	=	"%1organized Arathi Basin%2",
	["(%A)[oO]rg%s[wW]sg(%A)"]	=	"%1organized Warsong Gulch%2",
	["(%A)[oO]rg%s[eE][oO][tT][sS](%A)"]	=	"%1organized Eye of the Storm%2",
	["(%A)[oO]rg%s[bB][gG](%A)"]	=	"%1organized battleground%2",

	["(%A)[gG][gG](%A)"]	=	"%1good game%2",
	["(%A)[vV][gG][gG](%A)"]	=	"%1very good game%2",

	["(%A)[wW][bB](%A)"]	=	"%1welcome back%2",

	["^%s[lL][fF]([^hHsSmMgG%d%s%p])"]	=	" LF %1",
	["^%s[lL][fF]%s?(%d?)%s?([mMgG])%sto%sdo"]	=	" LF %1%2 ",



	["%s([lL]%s?[fFrR4].-)[wW]ar+([sz]*)([%s/|\\!,.]+)"]			=	" %1 Warrior%2 %3",
	["%s[wW]ar+([sz]*)([%s/|\\!,.]+)(.-[lL]%s?[fFrR4])"]			=	" Warrior%1 %2 %3",


	["%s([lL]%s?[fFrR4][%dmMgG].-%A)[lL]o[ck]+([sz]*)([%s/|\\!,.]+)"]			=	" %1 Warlock%2 %3",


--	Replace 'k' with digits
	["([^%d.]%d+)[kK]([%s%p])"]	=	"%1,000%2",
	["(%d+)%.(%d)[kK]([%s%p])"]	=	"%1,%200%3",

	["(%d.-[aA])ll%s?[rR]e[sz]+(%A)"]	=	"%1ll resistances%2",
	["(%A[aA])ll%s?[rR]e[sz]+ist(%A)"]	=	"%1ll resistances%2",

	["(%A[eE])nch(%A)"]	=	"%1nchantments%2",
	["(%A[aA])lchy?(%A)"]	=	"%1lchemy%2",

	["(%A)[rR]ex+[eao]*r(%A)"]		=	"%1Rexxar%2",
	["(%A)[nN]ef(%A)"]		=	"%1Nefarian%2",
	["(%A)[nN]ax+(%A)"]		=	"%1Naxxrammas%2",
	["(%A)[oO]ny(%A)"]		=	"%1Onyxia%2",

	["(%A[fF])fa(%A)"]		=	"%1ree%-for%-all%2",
	["(%A)[aA]fk(%A)"]		=	"%1AFK%2",
--	["(%A)[pP]at([sz]*%A)"]		=	"%1patrol%2",
	["(%A)[pP]rac(%A)"]		=	"%1practice%2",
	["(%A)%s?[hH]r([sz]*%A)"]	=	"%1 hour%2",
	["(%A)[cC]omp([sz]-%A)"]		=	"%1computer%2",
	["(%A[hH])i%-(%a%a)"]		=	"%1igh%-%2",


	["(%A)[cC]?o?n?[gG]ra?[td][sz]+(%A)"]	=	"%1congrats%2",

	["(%A)[aA]n%s[iI]nvi?te?(%A)"]		=	"%1an invitation%2",
	["(%A)[tT]he%s[iI]nvi?te?(%A)"]	=	"%1the invitation%2",
	["(%A)[fF]or%s[iI]nvi?t?e?(%A)"]	=	"%1for the invitation%2",
	["(%A)[iI][nN][vV](%A)"]	=	"%1invitation%2",
	["(%A)[tT]tyl(%A)"]		=	"%1talk to you later%2",
	["(%A)[tT]nl(%A)"]		=	"%1till next level%2",
	["(%A)[fF][pP](%A)"]		=	"%1flight path%2",
	["(%A)[wW][rR](%A)"]		=	"%1wind rider%2",
--	["(%A)[tT]os(%A)"]		=	"%1terms of service%2",
	["(%A)[aA]ccn?t(%A)"]		=	"%1account%2",

	["([%s%p])[nN]%sof(%A)"]		=	"%1north of%2",
	["([%s,?!;:])[sS]%sof(%A)"]		=	"%1south of%2",
	["([%s%p])[eE]%sof(%A)"]		=	"%1east of%2",
	["([%s%p])[wW]%sof(%A)"]		=	"%1west of%2",

	["(%s,?!;:)[nN][eE]%sof(%A)"]		=	"%1northeast of%2",
	["(%s,?!;:)[nN][wW]%sof(%A)"]		=	"%1northwest of%2",
	["(%s,?!;:)[sS][eE]%sof(%A)"]		=	"%1southeast of%2",
	["(%s,?!;:)[sS][wW]%sof(%A)"]		=	"%1southwest of%2",



	["(%A)[eE]ta(%A)"]	=	"%1time of arrival%2",


	["(%A)[tT]he%s?(%a*%s)[rR][lL]([sz]*%A)"]	=	"%1the %2 raid leader%3",
	["(%A)[aA]%s?(%a*%s)[rR][lL]([sz]*%A)"]	=	"%1a %2 raid leader%3",


	["(%A)[dD]ps(%A)"]	=	"%1damage per second%2",
	["([%s%p%dl])[dD]a?ma?g(%A)"]	=	"%1 damage %2",
	["([+%d])%s?[dD]am+(%A)"]	=	"%1 damage %2",
	["(%A)[dD]am+%s?([+%d])"]	=	"%1 damage %2",

	["(%A)[aA][oO][eE](%A)"]	=	"%1area%-effect%2",

	["(%A)[cC]hara?([sz]*%A)"]	=	"%1character%2",

--	Replace 'xp' and 'exp'
	["(%A)[eE]?[xX][pP](%A)"]	=	"%1experience%2",

	["(%A)[fF]rost%s?[rR]e[zs]+(%A)"]				=	"%1frost resistance%2",
	["(%A)[iI]ce%s?[rR]e[zs]+(%A)"]				=	"%1frost resistance%2",
	["(%A)[fF]ire%s?[rR]e[zs]+(%A)"]				=	"%1fire resistance%2",
	["(%A)[sS]hadow%s?[rR]e[zs]+(%A)"]				=	"%1shadow resistance%2",
	["(%A)[nN]ature%s?[rR]e[zs]+(%A)"]				=	"%1nature resistance%2",
	["(%A)[mM]ore%s?[rR]e[zs]+(%A)"]				=	"%1nature resistance%2",
	["(%A)[rR]e[zs]+%A*[gG]ear[sz]*(%A)"]				=	"%1resistance gear%2",
	["(%A)[wW][tT][eE](%A)"]				=	"%1I'd like to enchant%2",

	["(%A)[dD][eE]%s?it(%A)"]				=	"%1disenchant it%2",
	["(%A)[dD][eE]'?e?d%s?it(%A)"]				=	"%1disenchanted it%2",

	["(%A)[pP]al+i[iey]*([sz]*%A)"]	=	"%1Paladin%2",
	["(%A)[pP]al+[iy]+e*([sz]%A)"]	=	"%1Paladin%2",
	["(%A)[pP]al+a([sz]*%A[^dD])"]	=	"%1Paladin%2",
	["(%A)[pP]al+[ie]*y+([sz]*%A)"]	=	"%1Paladin%2",
	["(%A)[pP]l+d+(%A)"]	=	"%1Paladin%2",
	["(%A[hHlL])(l+)(r%A)"]	=	"%1ea%2e%3",

	["(%A[lL][fF].-%A)[sS]ham+([sz]*%A)"]	=	"%1Shaman%2",

	["(%A)[wW][ao]rr([sz]*%A)"]		=	"%1Warrior%2",
	["(%s%d%d%s?)[wW][ao]r+([sz]*%A)"]		=	"%1Warrior%2",
	["(%A[rR])egen(%A)"]	=	"%1egeneration%2",
	["(%A[rR])e?stor?(%A)"]	=	"%1estoration%2",

--	Common ability acronyms. Need more.
	["(%A)[lL]otp(%A)"]				=	"%1Leader of the Pack%2",
	["(%A)[hH]otw(%A)"]				=	"%1Heart of the Wild%2",
	["(%A)[mM]otw(%A)"]				=	"%1Mark of the Wild%2",
	["(%A)[gG]otw(%A)"]				=	"%1Gift of the Wild%2",
	["(%A)[rR][eE][tT](%A)"]			=	"%1Retribution%2",
	["(%A)[dD][iI][sS][cC](%A)"]			=	"%1Discipline%2",
	["(%A)[rR]esil(%A)"]				=	"%1Resilience%2",
	["(%A)[wW]otf(%A)"]				=	"%1Will of the Forsaken%2",
	["(%A)[eE]le(%A)"]				=	"%1Elemental%2",
	["(%A)[aA]otc(%A)"]				=	"%1Aspect of the Cheetah%2",
	["(%A)[aA]otb(%A)"]				=	"%1Aspect of the Beast%2",
	["(%A)[aA]otw(%A)"]				=	"%1Aspect of the Wild%2",
	["(%A)[aA]oth(%A)"]				=	"%1Aspect of the Hawk%2",
	["(%A)[aA]otp(%A)"]				=	"%1Aspect of the Pack%2",
	["(%A)[aA]otm(%A)"]				=	"%1Aspect of the Monkey%2",
	["(%A)[aA]otv(%A)"]				=	"%1Aspect of the Viper%2",

	["(%A)[mM]c['e]d(%A)"]			=	"%1mind%-controlled%2",
	["(%A)[mM]c'?s+(%A)"]				=	"%1mind%-controls%2",
	["(%A)[mM]c'?ing?(%A)"]			=	"%1mind%-controlling%2",

	["(%A)[hH][kK]([sz]*%A)"]	=	"%1honorable kill%2",
	["(%A)[dD][kK]([sz]*%A)"]	=	"%1Death Knight%2",
	["(%A)[cC][pP]([sz]*%A)"]	=	"%1contribution point%2",

--	Locations
	["(%A)[rR]%A*[fF]%A*[kK](%A)"]			=	"%1Razorfen Kraul%2",
	["(%A)[rR]%A*[fFgG]%A*[cC](%A)"]		=	"%1Ragefire Chasm%2",
	["(%A)[wW]/?[cC]([%s,.!?('])"]			=	"%1Wailing Caverns%2",
	["(%A)[wW][lL][cC](%A)"]			=	"%1Warlord's Command%2",
	["(%A)[rR]%A*[fF]%A*[dD](%A)"]			=	"%1Razorfen Downs%2",
	["(%A)[aA]+%A*[qQ](%A)"]			=	"%1Ahn'Qiraj %2",
	["(%A)[rR]aq(%A)"]			=	"%1the Ruins of Ahn'Qiraj%2",
	["(%A)[tT]aq(%A)"]			=	"%1the Temple of Ahn'Qiraj%2",
	["(%A)[bB]fd(%A)"]			=	"%1Blackfathom Deeps%2",
	["(%A)[Bb]rm(%A)"]			=	"%1Blackrock Mountain%2",

	["(%A)[Bb]rs(%A)"]			=	"%1Blackrock Spire%2",
	["(%A)[bB]wl(%A)"]			=	"%1Blackwing Lair%2",

	["(%A)[lL][%s%peE]*[BbrR]+[sS]+(%A)"]		=	"%1Lower Blackrock Spire%2",
	["(%A)[uU][%s%prRnN]*[Bb]+[eErR]*[sS]+(%A)"]	=	"%1Upper Blackrock Spire%2",

	["(%A)[sS]h?tv(%A)"]			=	"%1Stranglethorn Vale%2",
	["(%A)[sS]h?f[klj]+(%A)"]			=	"%1Shadowfang Keep%2",
	["(%A)[sS]h?ith[ai]l[aiu]s+(%A)"]			=	"%1Silithus%2",
	["(%A)[sS]h?il+[ai]th[aiu]s+(%A)"]			=	"%1Silithus%2",
	["(%A)[gG][nop]+me?r([^%a%-])"]		=	"%1Gnomeregan%2",
	["(%A)[gG][nop]+me?r%a-n(%A)"]		=	"%1Gnomeregan%2",
	["(%A)[dD]mf(%A)"]	=	"%1Darkmoon Faire%2",
	["(%A)[eE]l+[wyi]*n+%a*%s?[fF]o?re?st"]	=	"%1Elwynn Forest",
	["(%A)[eE]l+w[yi]n+%a*([^fF])"]	=	"%1Elwynn Forest %2",
	[",?(%A+)[cC]ath(%A)"]			=	"%1Cathedral%2",
	[",?(%A+)[lL]ibr?s?(%A)"]			=	"%1Library%2",
	["onastery(.-),?[^%a%d|]+[aA]rm?[so]*(%A)"]			=	"onastery%1 Armory%2",
	["([lL]f.-),?[^%a%d|][aA]rm[so]*(%A)"]			=	"%1 Armory%2",
	[",?(%A+)[tT]rib(%A)"]			=	"%1Tribute%2",
--	["(%A)[sS]h?tp(%A)"]		=	"%1Splintertree Post%2",
	["(%A)[sS]h?t[ro]+m%A*[gG][au]+rde?(%A)"]		=	"%1Stromgarde%2",
	["(%A)[fF][wW][pP](%A)"]		=	"%1Freewind Post%2",
	["(%A)[lL][hH][cC](%A)"]		=	"%1Light's Hope Chapel%2",
	["(%A)[eE]%s?[pP][lL]?(%A)"]		=	"%1the Eastern Plaguelands%2",
	["(%A)[wW]%s?[pP][lL](%A)"]		=	"%1the Western Plaguelands%2",
	["(%A)[bB][gG]'?([sz]*%A)"]	=	"%1Battleground%2",
	["(%A)[wW][sS][gG](%A)"]	=	"%1Warsong Gulch%2",
	["(%A)[aA][vV](%A)"]	=	"%1Alterac Valley%2",
	["(%A)[eE][oO][tT][sS](%A)"]	=	"%1Eye of the Storm%2",
	["(%A)[zZ][mM](%A)"]	=	"%1Zangarmarsh%2",
	["(%A)[sS][oO][tT][aA](%A)"]	=	"%1Strand of the Ancients%2",
	["(%A)[sS]hadow%A*[lL]ab[sz]*(%A)"]	=	"%1Shadow Labyrinth%2",

	["(%A)[sS][vV](%A)"]	=	"%1Steamvault%2",

	["(%A)[sS]team%A*[vV](%A)"]	=	"%1Steamvault%2",

	["(%A)[gG][yY](s?%A)"]		=	"%1graveyard%2",

	["([%s%p])[aA][bB](%A)"]	=	"%1Arathi Basin%2",
	["([^%a(])[tT][nN]([^%a)])"]	=	"%1Thousand Needles%2",
	["(%A)1,?000%s*[nN]eedle[sz](%A)"]	=	"%1Thousand Needles%2",

	["([%s%p])[bB][bB]([%s%p])"]		=	"%1Booty Bay%2",
	["(%A)[tT][bB](%A)"]	=	"%1Thunder Bluff%2",

	["([^%a(])[tT][mM]([^%a)])"]	=	"%1Tarren Mill%2",

	["(%A)[cC][oO][sS](%A)"]	=	"%1Culling of Stratholme%2",

	["(%A)[oO]r?g+r?i+%p?l+%p?a+(%A)"]	=	"%1Ogri'la%2",
	

	["(%A)[vV][hH](%A)"]	=	"%1Violet Hold%2",
	["(%A)[A][N](%A)"]	=	"%1Azjol-Nerub%2",
	["(%A)[nN]erub(%A)"]	=	"%1Azjol-Nerub%2",

	["(%A)[uU]tgarde[pP]innacle(%A)"]	=	"%1Utgarde Pinnacle%2",
	["(%A)[pP]inn(%A)"]	=	"%1Utgarde Pinnacle%2",
	["(%A)[U][P](%A)"]	=	"%1Utgarde Pinnacle%2",

	["(%A)[uU][kK](%A)"]	=	"%1Utgarde Keep%2",
	["(%A)[nN]ex(%A)"]	=	"%1Nexus%2",
	["(%A)[nN]exus(%A)"]	=	"%1Nexus%2",

	["(%A)[O][K](%A)"]	=	"%1Old Kingdom%2",
	["(%A)[vV][oO][aA](%A)"]	=	"%1Vault of Archavon%2",
	["(%A)[vV]ault(%A)"]	=	"%1Vault of Archavon%2",
	["(%A)[aA]rch(%A)"]	=	"%1Vault of Archavon%2",
	["(%A)[aA][kK](%A)"]	=	"%1Old Kingdom%2",
	["(%A)[kK]ahet(%A)"]	=	"%1Old Kingdom%2",
	["(%A)[aA][kK][oO][kK](%A)"]	=	"%1Old Kingdom%2",
	["(%A)[aA]hn'[kK]ahet(%A)"]	=	"%1Old Kingdom%2",
	["(%A)[dD][tT][kK](%A)"]	=	"%1Drak'Tharon Keep%2",
	["(%A)[tT][fF][aA](%A)"]	=	"%1Threat From Above%2",
	["(%A)[gG]undrak(%A)"]	=	"%1Gundrak%2",
	["(%A)[hH][oO][sS](%A)"]	=	"%1Halls of Stone%2",
	["(%A)[oO]cc(%A)"]	=	"%1Oculus%2",
	["(%A)[oO]cu(%A)"]	=	"%1Oculus%2",
	["(%A)[oO]c(%A)"]	=	"%1Oculus%2",
	["(%A)[hH][oO][lL](%A)"]	=	"%1Halls of Lightning%2",
	["(%A)[oO][sS](%A)"]	=	"%1Obsidian Sanctum%2",
	["(%A)[sS]arth(%A)"]	=	"%1Obsidian Sanctum%2",
	["(%A)[eE][oO][eE](%A)"]	=	"%1Eye of Eternity%2",
	["(%A)[mM]aly(%A)"]	=	"%1Eye of Eternity%2",
	["(%A)[mM]alygos(%A)"]	=	"%1Eye of Eternity%2",
	["(%A)[mM]ally(%A)"]	=	"%1Eye of Eternity%2",
	["(%A)[iI][cC][cC](%A)"]	=	"%1Icecrown Citadel%2",
	["(%A)[dD]al(%A)"]	=	"%1Dalaran%2",
	["(%A)[dD]alaran(%A)"]	=	"%1Dalaran%2",
	["(%A)[wW][gG](%A)"]	=	"%1Wintergrasp%2",
	["(%A)[tT][oO][cC](%A)"]	=	"%1Trial of the Champion%2",
	["(%A)[fF][oO][sS](%A)"]	=	"%1Forge of Souls%2",
	["(%A)[pP][oO][sS](%A)"]	=	"%1Pit of Saron%2",
	["(%A)[hH][oO][rR](%A)"]	=	"%1Halls of Reflection%2",
	["(%A)[iI][cC](%A)"]	=	"%1Icecrown Citadel%2",
--	["(%A)(%A)"]	=	"%1%2",
--	Replace 'sw'. Prepositions included to avoid meaning 'southwest'
	["[iI]n%s+[sS][wW](%A)"]		=	"in Stormwind%1",
	["[sS]ide%s+[sS][wW](%A)"]	=	"side Stormwind%1",
	["(%A)[aA]t%s+[sS][wW](%A)"]	=	"%1in Stormwind%2",
	["(%A)[oO]f%s+[sS][wW](%A)"]	=	"%1of Stormwind%2",
	["(%A)[tT]o%s+[sS][wW](%A)"]	=	"%1to Stormwind%2",

--	Replace 'darn'. Prepositions included to avoid meaning 'darn'
	["[iI]n%s+[dD]arn[a.]?(%A)"]		=	"in Darnassus%1",
	["[sS]ide%s+[dD]arn[a.]?(%A)"]	=	"side Darnassus%1",
	["(%A)[aA]t%s+[dD]arn[a.]?(%A)"]	=	"%1in Darnassus%2",
	["(%A)[oO]f%s+[dD]arn[a.]?(%A)"]	=	"%1of Darnassus%2",
	["(%A)[tT]o%s+[dD]arn[a.]?(%A)"]	=	"%1to Darnassus%2",

--	Replace 'sunken' with "the Sunken Temple"
	["(%A)[tT]?h?e?%s?sunken%s?[tT]?e?m?p?l?e*(%A)"]	=	"%1Sunken Temple%2",
	["(%s)[sS][tT]([^%d%a])"]	=	"%1Sunken Temple%2",


--	Replace 'IF' and 'if'.
	["(%A[tT])o%s+[iI]%s?[fF]([%s%p]*)$"]		=	"%1o Ironforge%2",
	["(%A[iI])n%s+[iI]%s?[fF](%A)"]		=	"%1n Ironforge%2",
	["(%a)[sS]ide%s+[iI]%s?[fF](%A)"]		=	"%1side Ironforge%2",
	["(%A[oO])f%s+[iI]%s?[fF](%A)"]		=	"%1f Ironforge%2",
	["(%A)[aA]t%s+[iI]%s?[fF](%A)"]		=	"%1in Ironforge%2",

	["(%A)[sS]h?[rR][rR](%A)"]	=	"%1Sun Rock Retreat%2",
	["(%A)[sS][mM][cC](%A)"]	=	"%1Silvermoon City%2",

	["(%A)[mM]ara(%A)"]	=	"%1Maraudon%2",
	["(%A)[uU]l+da*(%A)"]	=	"%1Uldaman%2",

	["(%A)[zZ]%s?[fF](%A)"]	=	"%1Zul'Farrak%2",

	["(%A)[gG]%s?[zZ](%A)"]	=	"%1Gadgetzan%2",
	["(%A)[zZ]%s?[gG](%A)"]	=	"%1Zul'Gurub%2",
--	["(%A)[dD]%s?[mM](%A)"]	=	"%1DM%2",
	["(%A)[dD][wW][mM](%A)"]	=	"%1Dustwallow Marsh%2",
	["(%A)[vV][cC](%A)"]	=	"%1Van Cleef%2",
	["(%A)[aA][dD]%s[fF]action"]	=	"%1Argent Dawn faction",

--	Replace 'strat'. Prepositions included to avoid 'strategy' meaning.
	["[iI]n%s[sS]trath?(%A)"]	=	"in Stratholme%1",
	["(%A[tTdD])o%s[sS]trath?(%A)"]	=	"%1o Stratholme%2",
	["[aA]t%s[sS]trath?(%A)"]	=	"at Stratholme%1",
	["[fF]rom%s[sS]trath?(%A)"]	=	"from Stratholme%1",



	["(%A)[sS]h?cholo?(%A)"]	=	"%1Scholomance%2",

--	Replace 'sm' and 'SM'.
	["(%A)[sS]h?[mM](%A)"]	=	"%1Scarlet Monastery%2",

--	Replace 'MC'. Prepositions included to avoid 'mind control' meaning.
	["[iI]n%s[mM]%s?[cC]([)/%s.!?,])"]	=	"in Molten Core%1",
	["[tT]o%s[mM]%s?[cC]([)/%s.!?,])"]	=	"to Molten Core%1",
	["[aA]t%s[mM]%s?[cC]([)/%s.!?,])"]	=	"at Molten Core%1",
	["[fF]rom%s[mM]%s?[cC]([)/%s.!?,])"]	=	"from Molten Core%1",
	["(%A)[mM]%s?[cC]%s[rR]un([sz]?[)/%s.!?,])"]	=	"%1Molten Core run%2",
	["(%A)[mM]%s?[cC]%s?[aA]t+u*n+e?"]	=	"%1Molten Core Attune",


--	Replace 'wf'. Prepositions included to avoid 'wind fury' meaning.
	["[iI]n%s[wW][fF](%A)"]	=	"in Westfall%1",
	["[tT]o%s[wW][fF](%A)"]	=	"to Westfall%1",
	["[aA]t%s[wW][fF](%A)"]	=	"at Westfall%1",
	["[fF]rom%s[wW][fF](%A)"]	=	"from Westfall%1",

	["(%A)[xX]%A?[rR][sS]?(%A)"]	=	"%1the Crossroads%2",
	["(%A)[xX]%A?r[oa]*ds?(%A)"]		=	"%1the Crossroads%2",
	["(%A)[wW][cC](%A)"]		=	"%1Wailing Caverns%2",

	["(%A)[tT]?[hH]?[eE]?%s?[uU][cC](%A)"]	=	"%1the Undercity%2",

--	Correct attribute names.
	["(%A)[aA]g[il]*(%A)"]		=	"%1 Agility %2",
	["(%A)[iI]nt(%A[^h])"]			=	"%1 Intellect %2",
	["(%A)[iI]nt(%A*)$"]			=	"%1 Intellect %2",
	["(%A)[iI]ntell(%A)"]			=	"%1 Intellect %2",
	["(%d%s?)[iI]ntel+(%A)"]			=	"%1 Intellect %2",
	["(%A)[sS]h?tr([%s%p])"]			=	"%1 Strength %2",
	["(%A)[sS]h?t[am]+(%A)"]	=	"%1 Stamina %2",
	["(%A)[sS]h?p[ir][ri]?(%A)"]	=	"%1 Spirit %2",
	["(%A[eE])nchants%s?:"]	=	"%1nchantments: ",

	["(%A)[pP][uU][gG]([sz]*%A)"]	=	"%1pick%-up group%2",

	["(%A)[bB][oO][pP]'?[sz](%A)"]	=	"%1items that bind on pickup%2",
	["(%A)[bB][oO][eE]'?[sz](%A)"]	=	"%1items that bind on equip%2",

	["(%A[tT])rans(%A[^mM])"]	=	"%1ransmutation%2",

	["(%A[aA])r?ca?%A*([tT])ran"]	=	"%1rcanite %2ran",
	["(%A[aA])r?ca?n?[%AxX]*[mM]ute?([sz]*%A)"]	=	"%1rcanite transmutation%2",

	["(%A)[dD]w(%A)"]		=	"%1dual%-wield%2",
	["([%s!?.,])[lL]+p+(%a+%A)"]		=	"%1lockpick%2",
	["([%s!?.,])[lL]+p+%s?(%d+)"]		=	"%1lockpicking %2",
	["([%s!?.,])[lL]+p+%s(%D)"]		=	"%1lockpick %2",
	["(%A)'?[cC]hanter([sz]*%A)"]		=	"%1enchanter%2",


	["(%A)[fF4][tT][wWeE]([^%a%d|?])"]		=	"%1for the win%2",

},

[3]={
	["(%A)OT(%A)"]			=	"%1Off Tank%2",
	["(%A)[cC][dD](%A)"]			=	"%1cool down%2",
	

	["(%A)[bB][oO][pP](%A)"]	=	"%1\"bind on pickup\"%2",
	["(%A)[bB][oO][eE](%A)"]	=	"%1\"bind on equip\"%2",

	["(%D%d%d)%s?[lL]ock(%A)"]	=	"%1 Warlock%2",
	["(%A)[lL]ock%s?(%d%d)(%D)"]	=	"%1%2 Warlock%3",

	["(%A)[lL][4fF]([%a%d])"]	=	"%1looking for %2",
	["(%A)[lL][4fF]([%p%s])"]	=	"%1looking for%2",

	["^(%A*)[sS]t?rt?ath?([%s!,.]+%a)"]	=	"%1Stratholme%2",
	["(%A)[sS]h?trath(%A)"]	=	"%1Stratholme%2",

	["(%A)[jJ]+[cC]+(%A)"]		=	"%1jewelcrafting%2",
	["(%A)[jJ]+[cC]+er(%A)"]		=	"%1jewelcrafter%2",

	["(%A)[lL]+[wW]+(%A)"]		=	"%1leatherworking%2",
	["(%A)[lL]+[wW]+ing?(%A)"]		=	"%1leatherworking%2",
	["(%A)[lL]+[wW]+'?er([sz]*%A)"]		=	"%1leatherworker%2",
	["(%A)[lL]+[wW]+'?(s%A)"]		=	"%1leatherworker%2",

	["(%A)[hH]ave%s?[kK]ey([sz]*%A)"]	=	"%1have the key%2",
	["(%A)[hH]ave%s?[mM]allet([sz]*%A)"]	=	"%1have the mallet%2",
	["(%A)[hH]ave%s?[sS]cepter([sz]*%A)"]	=	"%1have the scepter%2",

--	Replace 'ah' only when referring to the Auction House
	["(%A)[tT]he%s?[aA][hH](%A)"]		=	"%1the Auction House%2",
	["(|r)([IiOo])n%s?[aA][hH](%A)"]		=	"%1 %2n the Auction House%3",
	["(%A[IiOo])n%s?[aA][hH](%A)"]		=	"%1n the Auction House%2",
	["(%A)[tT]o%s?[aA][hH](%A)"]		=	"%1to the Auction House%2",
	["([sS]ide)%s[aA][hH](%A)"]	=	"%1 the Auction House%2",
	["(%A)[oO]f%s?[aA][hH](%A)"]	=	"%1of the Auction House%2",
	["(%A)[aA][hH]%s?[bB]ridge?(%A)"]	=	"%1Auction House Bridge%2",

	["(%A)[iI][fF]%s?[aA][hH](%A)"]	=	"%1Ironforge Auction House%2",
	["(%A)[sS][wW]%s?[aA][hH](%A)"]	=	"%1Stormwind Auction House%2",

	["(%A)[tT]h[ea]?n%s[aA][hH](%A)"]			=	"%1than the Auction House%2",
	["(%A)[aA]t%s[aA][hH](%A)"]			=	"%1at the Auction House%2",
	["@%s?[aA][hH](%A)"]			=	"at the Auction House%1",
	["(%A)[fF]rom%s?[aA][hH](%A)"]			=	"%1from the Auction House%2",
--	["(%A)[aA][hH]%sit(%A)"]		=	"%1auction it%2",
	["(%A)[aA][hH]%s[pP]rice(%A)"]		=	"%1the Auction House's price%2",
--	["(%A)[aA][hH]%sth([ia]%a)"]	=	"%1auction th%2",
	["(%A)[bB]/?[oO](%A)"]		=	"%1buyout%2",

--	["(%a[^yer%s%d%p])%s[bB]ank"]	=	"%1 the Bank",

	["(%A)[eE]pic+['e]*d(%A)"]	=	"%1epic%-equipped%2",

	["[pP][gGsSmM]*[tTwW]%s[pP]lease(%A)"]	=	"PST%1",
	["[pP]lease%s[pP][gGsSmM]*[tTwW](%A)"]	=	"PST%1",
	["(%A)[Bb]rd(%A)"]			=	"%1Blackrock Depths%2",

	["(%A)[yY]ou%s[cC](%A)"]	=	"%1you see%2",

	["(%A)[nN]on%A*[hH]eroic(s?%A)"]			=	"%1non%-heroic%2",

	["(%A)[dD]?[mM][%p%s]*([eEwW][ea])st(%A)"]			=	"%1Dire Maul %2st%3",
	["(%A)[dD]?[mM][%p%s]*([nNsS]o[ur])th(%A)"]			=	"%1Dire Maul %2th%3",

	["(%A)[dD]ire%A*[mM]aul[%p%s]*[eE](%A)"]			=	"%1Dire Maul East%2",
	["(%A)[dD]ire%A*[mM]aul[%p%s]*[wW](%A)"]			=	"%1Dire Maul West%2",
	["(%A)[dD]ire%A*[mM]aul[%p%s]*[nN](%A)"]			=	"%1Dire Maul North%2",


--	Fix 'res'
	["(%A)[rR]+e+[z]+([ei]?[snd]?g?%A)"]	=	"%1resurrect%2",

--	Replace 'level ??'
	["(%A)[lL]evel[%s~]*%?%?[%s~]*(%a%a)"]	=	"%1high%-level %2",
--	["%s%?%?%sto%s(%a%a)"]	=	" too high to %1",
--	Handle ?? for "high level"
	["[%s~]%?%?[%s~]*[aA]lliance"]	=	"high%-level Alliance",
	["[%s~]%?%?[%s~]*[hH]orde"]	=	"high%-level Horde",

	["(%A)[iI]n?%s?[rR][lL](%A)"]	=	"%1in real life%2",
	["([^nmae])(%A)[rR][lL](%A)"]	=	"%1%2real life%3",


	["(%A)[tT]he%s?(%a*%s)[gG][lL]([sz]*%A)"]	=	"%1the %2 guild leader%3",
	["(%A)[aA]%s?(%a*%s)[gG][lL]([sz]*%A)"]	=	"%1a %2 guild leader%3",

	["(%A)[mM]at[sz](%A)"]		=	"%1materials%2",

},

[5]={

},

[6]={


--	Add 'for' before prices.
	["^([wW]%s?[tT]%s?[sSbB].-)[oO]nly%s+for%s+(%d)"]	=	"%1 for only %2",


	["([%a%p%s])1st"]		=	"%1first",
	["([%a%p%s])2nd"]		=	"%1second",
	["([%a%p%s])3rd"]		=	"%1third",

	["^[lL][fF4]?[mM]+['s]*%s*(%d+)[%s-]*[mM]an"]		=	"Calling more for a %1-man ",

	["^[wW][yY][sS]"]		=	"WTS",

	["^[lL][fFeE4]%s?!"]		=	"Seeking 1",
	["^[lL][fFeE4]%s?@"]		=	"Now calling 2",
	["^[lL][fFeE4]%s?#"]		=	"Seeking 3",
	["^[lL][fFeE4]%s?%$"]		=	"I seek 4",
	["^[lL][fFeE4]%s?%%"]		=	"Calling 5",


},
[7]={


	["^g%.?$"]	=	"Good",
	["^G%.?$"]	=	"Excellent",

	["^n%.?$"]	=	"Nice",
	["^N%.?$"]	=	"Very nice",

	["^[gG][lL](%A*)$"]			=	"Good luck",

	["^[mM][tT]$"]			=	"Sorry, mistell",


--	Change WTB and wtb
	["(.%A)[wWuU][tT][bB](%A)"]	=	"%1want to buy%2",
	["^%A*[WUL]t%s?b%s+(%u)"]			=	"I want to purchase %1",
	["^%A*[wul]t%s?b%s+(%l)"]			=	"I'd like to acquire %1",
	["^%A*[wWuUlL]+[tT]+%s?[bB]+%s?[^%a%d|+%[]+"]	=	"I want to buy ",
	["^%A*[wWuUlL]+[tT]+%s?[bB]+%s?%+"]	=	"Looking to buy +",
	["^%A*[wWuUlL]+[tT]+%s?[bB]+%s?|c"]	=	"I'd like to buy |c",
	["(%A)[wWuUlL]tb$"]			=	"%1want to buy",
	["(%A)[wW]ho%s?buy%p*$"]			=	"%1 for sale!",
	["^%A*[wWuUlL]tb$"]				=	"I want to buy",

	["^[iI]%s?[fF]$"]			=	"Ironforge",

	["^[wW]t%s?[tT](%A)"]		=	"Trading%1",
	["(%A)[wW]t%s?[tT](%A)"]		=	"%1trading%2",
	["^[wW]t%s?[cC]raft(%A)"]	=	"Crafting%1",
	["^[wW][tT][cC](%A)"]	=	"Crafting%1",
	["^[wW]t%s?[eE]nchant(%A)"]	=	"Enchanting%1",

	["(%A)[wWuU]+%s?[tT]+%s?s+%s"]		=	"%1selling ",
	["(%A)[wWuU]+%s?[tT]+%s?s+([%p%d])"]	=	"%1Offering %2",
	["^[wWuUlL]%s?t+s+%s*:"]				=	"I'm selling ",
	["^[fF]%s?s+[%s:;]"]			=	"For sale: ",
	["^[wW]+%s?[sS]+[tT]+(%A.*)"]			=	"Who'll buy my %1%?",
	["^[wWuUlL]+%s?[tT]+%s?[sS]+%s[aA]nd%s[aA]t+ach%s?"]	=	"Selling and attaching ",
	["^[wWuUlL]+%s?[tT]+%s?[sS]+%s[aA]nd%s[iI]n?stal+%s?"]	=	"Selling and attaching ",
	["^[wWuUlL]+%s?[tT]+%s?[sS]+[^%a%d|?+]+"]	=	"Selling ",
	["^[wWuUlL]+%s?[tT]+%s?[sS]+|c([^f])"]	=	"Selling |c%1",
	["^[wWuUlL]+%s?[tT]+%s?[sS]+|cff1"]	=	"I'm selling |cff1",
	["^[wWuUlL]+%s?[tT]+%s?[sS]+|cff0"]	=	"For sale: |cff0",
	["^[wWuUlL]+%s?[tT]+%s?[sS]+(%d)"]		=	"Now selling %1",
	["^[wWuUlL]+%s?[tT]%s?[sS](%a)"]		=	"I'd like to sell %1",
	["([%s%pr])[wW]+%s?t+s+$"]				=	"%1 for sale",
	["^[wWuU]+%s?t+s+$"]				=	"Goods for sale!",

--	Replace g with gold if it follows a digit
	["(%d)%s*[gG]p?([^%a|])"]	=	"%1 gold %2",
	["(%d)%s*[gG]p?$"]	=	"%1 gold",
	["(%d)%s*[gG]p?|"]	=	"%1 gold |",
	["([^|]%d+)[gG]old"]	=	"%1 gold ",
	["^(%d+)[gG]old"]	=	"%1 gold ",

--	Replace s with silver if it follows a digit
	["(%a%s%d)%s*[sS]p?(%A)"]			=	"%1 silver%2",
	["(%d)%s*[sS][il]+v?(%A)"]		=	"%1 silver%2",
--	["[fF]or%s*(%d+)[sS]p?(%A)"]			=	"for %1 silver%2",

--	Replace c with copper if it follows a digit
--	["(%A)(%d+)%s*[cC]p?(%A)"]	=	"%1%2 copper%3",
	["^(%d+)%s*[cC]p?(%A)"]		=	"%1 copper%2",
	["([%s%p%dgs])(%d+)%s*[cC]p?$"]		=	"%1%2 copper",
	["^(%d+)%s*[cC]p?$"]		=	"%1 copper",

	["(%d+)%s?[mM]+([%s!?:,./])"]	=	"%1 more%2",
	["(%d+)%s?[mM]+$"]		=	"%1 more",

	["(%d)%s?[vV]s?%s?(%d)"]	=	"%1 vs %2",


--	Refilter if preceded by article, indicating the noun.
	["[aA]%s[rR]es+ur+ect(%A)"]				=	"a resurrection%1",
	["[tT]he%s[rR]es+ur+ect(%A)"]				=	"the resurrection%1",

	["[aA]sk%s+[mM]e+%s+[oO]f+ers?"]	=	"please make me an offer",
	["[aA]sk%s+[mM]e+%s+[pP]rices?"]	=	"please make offers",
	["[aA]sk%s+[mM]e+%s+[wW]ith%s[oO]+fers?"]	=	"now taking offers",
	["|r%s?[oO]ffers?$"]	=	"|r%. Taking offers",

	["^[wWlL][tT][bB]"]				=	"Buying ",
	["^[wWlL][bBpP][tT]"]				=	"I'll buy ",
	["^[wWlL][tT][sS]"]				=	"Selling ",
	["^[wW][tT](%A)"]				=	"I want to %1",

--	Handle other ?? expressions.
	["^~%?%?~%s?(%a%a)"]				=	"High-level %1",
	["([%a'])s%s~%?%?~%s?(%a%a)"]				=	"%1s high-level %2",
	["%sis%s%?%?$"]				=	" is high-level",
},

[9]= {
	["^(.+)$"]	=	Elo.AnalyzeGrammar,
},
[11]={
	["^.*$"]		=	processlfg,
},
[12]={
	["^(.+)$"]	=	Elo.WipeGrammarTags,
},

[14]={
	["%s([tT])o_%s"]		=	" %1o ",

	["([^%d%a.,+-/*])1([%s?!])"]		=	"%1one%2",
	["([^%d%a.,+-/*])2([%s?!])"]		=	"%1two%2",
	["([^%d%a.,+-/*><])3([%s?!])"]		=	"%1three%2",
	["([^%d%a.,+-/*])4([%s?!])"]		=	"%1four%2",
	["([^%d%a.,+-/*])5([%s?!])"]		=	"%1five%2",
	["([^%d%a.,+-/*])6([%s?!])"]		=	"%1six%2",
	["([^%d%a.,+-/*])7([%s?!])"]		=	"%1seven%2",
	["([^%d%a.,+-/*()])8([%s?!])"]		=	"%1eight%2",
	["([^%d%a.,+-/*])9([%s?!])"]		=	"%1nine%2",


},

[15]={
	["(%s)1([^%d%%]*)$"]		=	"%1one%2",
	["(%s)2([^%d%%]*)$"]		=	"%1two%2",
	["(%s)3([^%d%%]*)$"]		=	"%1three%2",
	["(%s)4([^%d%%]*)$"]		=	"%1four%2",

	["(%A)[gG]old%s*(%d+)%s?[sS]p?(%A)"]	=	"%1gold, %2 silver%3",

},
[18]={
	["(%a)%s@%s(%a)"]		=	"%1 at %2",
	["(%a)_"]	=	"%1",

--  Replace certain numbers at start of line only.
	["^0([%s?!;]%D+)$"]	=	"Zero%1",
	["^1([%s?!;]%D+)$"]	=	"One%1",
	["^2([%s?!;]%D+)$"]	=	"Two%1",
	["^3([%s?!;]%D+)$"]	=	"Three%1",
	["^4([%s?!;]%D+)$"]	=	"Four%1",
	["^5([%s?!;]%D+)$"]	=	"Five%1",
	["^6([%s?!;]%D+)$"]	=	"Six%1",
	["^7([%s?!;]%D+)$"]	=	"Seven%1",
	["^8([%s?!;]%D+)$"]	=	"Eight%1",
	["^9([%s?!;]%D+)$"]	=	"Nine%1",
	["^10([%s?!;]%D+)$"]	=	"Ten%1",
	["^11([%s?!;]%D+)$"]	=	"Eleven%1",
	["^12([%s?!;]%D+)$"]	=	"Twelve%1",
	["^20([%s?!;]%D+)$"]	=	"Twenty%1",
	["^30([%s?!;]%D+)$"]	=	"Thirty%1",
	["^40([%s?!;]%D+)$"]	=	"Forty%1",
	["^50([%s?!;]%D+)$"]	=	"Fifty%1",
	["^100([%s?!;]%D+)$"]	=	"A hundred%1",
	["^100[sS]([%s?!;])"]	=	"Hundreds%1",
},


}
