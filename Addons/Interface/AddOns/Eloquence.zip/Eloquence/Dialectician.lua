local elogsub = Elo.gsub
local lower = string.lower
local p = pairs
local function expandeverything(msg)
	msg = Elo.ExpandQuestion(msg)
	msg = Elo.ExpandStatement(msg)
	return msg
end

Elo.RaceFilter = { }
function Elo.HordeDialect()

local function jahswitch(msg)
	return " a"..lower(msg)
end

jahverblist = {
--	Isn't it?
		{[",?%s[13]@be%s8[12]@%a+%s[nN]ot?%??"]	=	", nuh true?"},

--		Negative "Joe doesn't have to do it" -> "Joe no bother haffi do it"
		{["[013]@[dD]o%s[nN]ot%s0@[hH]ave%s5@[tT]o%s([03]@%a+)"]	=	"no bother haffi %1"},
		{["[013]@[dD]o%s[nN]ot%s0@[nN]eed%s5@[tT]o%s([03]@%a+)"]	=	"no bother haffi %1"},

		{["[013]@[dD]o%s[nN]ot%s0@[nN]eed%s5@[tT]o%s([03]@%a+)"]	=	"no bother haffi %1"},

		{["(%A)[wW]hy%s[013]@[dD]o%s[nN]ot(%s.-[0-4]@)"]	=	"%1a what no make%2"},
		{["(%A)[wW]hy%s[013]@[dD]o(%s.-[0-4]@)"]	=	"%1a what make%2"},

--	"has never been as great"
		{["[019]@[hH]ave%s6@[nN]ever%s4@[bB]e%s[aA]s(%A+%a+)"]	=	"never%1 so yet"},
		{["[019]@[hH]ave%s6@[nN]ever%s4@[bB]e(%A+%a+)"]	=	"never%1"},

--		Question grammar - > statement grammar
		{["9%d?@(%a+%s)([^.?!;:0]-%s)([0234]@%a+)"]	=	function(a,b,c) 
														return b.."9@"..lower(a)..c
													end },



		{["[0-4]@be%s[nN]ot?%s(%a+%s)([tT]?[hH]ere%s)"]	=	"no %1no %2"},

		{["[0-4]@be%s[nN]ot?%s(%a+%s)(5@%a+)"]	=	"no %1no %2"},

--	Negative
--		"I told him to not eat that" -> "I told him say not eat that"
		{["[0-4]@%a+[^?!.,]-5@[tT]o%s[nN]ot(%s[03]@%a+)"]	=	"say no%1"},
		{["[0-4]@%a+[^?!.,]-%f[%a][nN]ot%s5@[tT]o(%s[03]@%a+)"]	=	"say no%1"},


--		Remote future intent - negative "I will not be talking"
		{["(%s)0@[wW]ill%s[nN]ot%s0@[bB]e%s(2@%a+)"]	=	"%1no a go deh %2"},

--		State or location marker "I have not been talking"
		{["(%s)[019]@[hH]ave%s[nN]ot%s4@[bB]e%s([25]@%a+)"]	=	"%1no been deh %2"},


--		"Won't he take it?" -> "He no take it?"
		{["[013]@[dD]o%s[nN]ot(%s%a+%s)([03]@%a+)"]	=	"%1no %2"},
		{["0@[wW]ill%s[nN]ot(%s%a+%s)([03]@%a+)"]	=	"%1no %2"},

--		Negative Potential. "They are not able to walk" -> "They no can walk"
		{["3@[bB]e%s[nN]ot%s[aA]ble%s5@[tT]o%s([03]@%a+)"]	=	"no could %1"},
		{["3@[bB]e%s[uU]nable%s5@[tT]o%s([03]@%a+)"]	=	"no could %1"},

		{["s?%s[nN]ot%s[aA]ble%s5@[tT]o%s([03]@%a+)"]	=	" can not %1"},
		{["s?%s[uU]nable%s5@[tT]o%s([03]@%a+)"]	=	" can not %1"},

--		Negative progessive
		{["(%s)[013]@[bB]e%s[nN]ot%s(2@%a+)"]	=	"%1no a %2"},
		{["(%a%a)'s%s[nN]ot%s(2@%a+)"]	=	"%1 no a %2"},

--		Remote past aspect marker - negative
		{["(%s)3@[hH]ave%s[nN]ot%s(3@%a+)"]	=	"%1none %2"},

--		Remote past aspect marker - negative
		{["(%s)0@[hH]ave%s[nN]ot%s4@[bB]e%s(2@%a+)"]	=	"%1none %2"},

--		Perfect aspect marker - negative
		{["(%s)0@[hH]ave%s[nN]ot%s(3@%a+)"]	=	"%1never %2"},


		{["(%s[0-4]@[tT]ry%s)[nN]ot%s5@[tT]o%s"]	=	"%1 no "},

--		"I never eat that" -> "I no eat that"
		{["(%s)6@[nN][eE]ver%s([03]@%a+%A+%a)"]	=	"%1no %2"},
--		"I never ate that" -> "I never eat that"
--		{["(%s)6@[nN]?[eE]ver%s([1-4]@%a+)"]	=	"%1never %2"},

--		Nobody knows anything
--		{["(%s[nN]o%s%a+%s)(.-[013]@%a+)"]	=	"%1no %2"},
		{["(81@[nN]o%s?[tT]hing%s)(.-[013]@%a+)"]	=	"%1no %2"},
		{["(81@[nN]o%s?[oO]ne%s)(.-[013]@%a+)"]	=	"%1no %2"},
		{["(81@[nN]o%s?[bB]ody%s)(.-[013]@%a+)"]	=	"%1no %2"},
		{["(%s[nN]o%s?[wW]here%s)(.-[013]@%a+)"]	=	"%1no %2"},


--		"is not" -> "not"
		{["[013]@be(%s[nN]ot%s%a+)"]	=	"%1"},

--		"do not walk" -> "not walk"
--		{["%s[01]@do(%s[nN]ot%s[03]@%a+)"]	=	"%1"},

--		Double negative
		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[aA]ny%s?[mM]ore%f[%A]"]	=	"%1again"},

		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[aA]nother%s"]	=	"%1no more "},
		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[aA]nother%s"]	=	"%1no more "},
		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[aA]%s"]	=	"%1no "},
		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[aA]%s"]	=	"%1no "},

		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[sS]ome(%A*)$"]	=	"%1none%2"},
		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[sS]ome%s?"]	=	"%1no "},
		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[sS]ome%s?"]	=	"%1no "},

		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[aA]ny(%A*)$"]	=	"%1none%2"},
		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[aA]ny%s?"]	=	"%1no "},
		{["%f[%a]([nN]ot?%sa?%s?[0-4]@%a[^.,?!]-[%s@])[aA]ny%s?"]	=	"%1no "},

		{["(%s[nN]ot%s)[aA]ny%s([0-4]@%a+)"]	=	"%1 %2"},


--		Future aspect marker - negative
		{["(%s)0@[wW]ill%s[nN]ot%s([03]@%a+)"]	=	"%1no a %2"},

--		Negative interrogative
--		{["1@[dD]o%s[nN]ot%s(%a+)"]	=	"dwon't %1"},

--		Negative Past
		{["(%s)3@[dD]o%s[nN]ot%s([03]@%a+)"]	=	"%1never %2"},

--		Negative Imperative
		{["%f[%a][dD]o%s[nN]ot%f[%A]"]	=	"dwon't"},


--		Future intent - negative "I am not going to talk"
		{["(%s)1@[bB]e%s[nN]ot%sa?%s?2@[gG]o%s5@[tT]o%s([03]@%a+)"]	=	"%1no gween %2"},

--		Future intent - negative "I am not talking"
		{["(%s)1@[bB]e%s[nN]ota?%s?%s(2@%a+)"]	=	"%1no gween %2"},

--		"Worry no more" -> "No worry no more"
--		{["^([^%d@]*[03]@%a+%s[nN]ot?%s)"]	=	" no %1"},
		{["^([03]@%a+%s[nN]ot?%s)"]	=	" no %1"},

--		Other negative
--		{["%s[nN]ot%s(3@%a+)"]	=	" no %1"},

--	Positive
--	Indefinite article "one
		{["([0-4]@%a%a%a+%s)7@a%s([^%s%plL])"]	=	"%1 %2"},

--		Future Passive
		{["%f[%a][wW]ill%s0@[bB]e(%s[34]@%a+)"]	=	"go 0@get%1"},

--	Past Passive
		{["3@[bB]e(%s[34]@%a+)"]	=	"done%1"},

--	Passive
		{["[01]@[bB]e(%s[34]@%a+)"]	=	"0@get%1"},

--	Passive Progressive
		{["[0-4]@[bB]e%A+[bB]e(%s[34]@%a+)"]	=	"a%1"},

--	He has been there
		{["(%s)[019]@[hH]ave%s4@[bB]e%s5@%a+"]	=	"%1gone a"},
		{["(%s)[019]@[hH]ave%s4@[bB]e(%s%a+)"]	=	"%1gone%2"},


--	Perfect aspect marker - positive
		{["[019]@[hH]a[vs]e?(%s[34]@%a+)"]	=	"done%1"},
		{["[019]@[hH]a[vs]e?%s([6]@%a+)(%s[34]@%a+)"]	=	"%1 done%2"},

--	Serial verb construction "He came and killed me" -> "He come come kill me"
		{["%s([0134]@)(%a+)(.-)%s[aA]nd%s%1(%a+)"]	=	" %1%2%3 %1%4"},

--	Conveyance. "she told me that ..." -> "she told me say..."
		{["([0-4]@tell%s.-)[tT]hat(%A+%a+%A+%a+)"]	=	"%1say %2"},
		{["([0-4]@hear%s.-)[tT]hat(%A+%a+%A+%a+)"]	=	"%1say %2"},
		{["([0-4]@read%s.-)[tT]hat(%A+%a+%A+%a+)"]	=	"%1say %2"},
		{["([0-4]@say%s.-)[tT]hat(%A+%a+%A+%a+)"]	=	"%1%2"},
		{["([0-4]@mean%s.-)[tT]hat(%A+%a+%A+%a+)"]	=	"%1%2"},
		{["([sS]ure%A+)[tT]hat(%A+%a+%A+%a+)"]			=	"%1say %2"},
		{["([0-4]@believe%s.-)[tT]hat(%A+%a+%A+%a+)"]	=	"%1say %2"},

--	Orders. "he wants me to bring it" -> "he want me fi go bring..."
		{["([0-4]@want%s%a[%a%s]-)5@[tT]o%s([03]@%a+)"]	=	"%1say %2"},
		{["([0-4]@tell%s%a[%a%s]-)5@[tT]o%s([03]@%a+)"]	=	"%1say %2"},
		{["([0-4]@ask%s%a[%a%s]-)5@[tT]o%s([03]@%a+)"]	=	"%1say %2"},

--	Future intent - positive "I am going to talk"
		{["(%s)1@[bB]e%s2@[gG]o%s5@[tT]o%s([03]@%a+)"]	=	"%1gween %2"},

--	He even ate a pie -> He all ate a pite
		{["%f[%a][eE]ven%s([3]@%a+)%s"]	=	"all %1 "},

--	He has been running
		{["(%s)[019]@[hH]ave%s4@[bB]e%s(2@%a+)"]	=	"%1been a %2"},

--	He had been running
		{["(%s)[39]@[hH]ave%s4@[bB]e%s(2@%a+)"]	=	"%1been deh %2"},

--	It has been taken by the Horde
		{["(%s)[019]@[hH]ave%s4@[bB]e%s([34]@%a+)"]	=	"%1gone %2"},


--	"They have got to run" -> "They haffi run"
		{["%s0@have%s3@g[eo]t%s5@[tT]o%s([03]@%a+)"]	=	" haffi %1"},

--	"They got to run" -> "They haffi run"
		{["3@[gG][eo]t%s5@[tT]o%s([03]@%a)"]	=	"haffi %1"},

--	"Joe has to eat" -> "Joe haffi eat"
		{["%f[%d][019]@[hH]ave%s5@[tT]o%s([03]@%a+)"]	=	"haffi %1"},
		{["%f[%d][01]@[nN]eed%s5@[tT]o%s([03]@%a+)"]	=	"haffi %1"},
		{["%s[mM]ust%s([03]@%a+)"]	=	" mussi %1"},

--	"Joe had to eat" -> "Joe haf to eat"
		{["%f[%d]3@[hH]ave%s5@[tT]o%s([03]@%a+)"]	=	"haf to %1"},
		{["%f[%d]3@[nN]eed%s5@[tT]o%s([03]@%a+)"]	=	"haf to %1"},

--	Potential. "They are able to walk" -> "They can walk"
		{["s?%s[012]@be%s[aA]ble%s5@[tT]o%s([03]@%a+)"]	=	" can %1"},
		{["s?%s3@be%s[aA]ble%s5@[tT]o%s([03]@%a+)"]	=	" coulda can %1"},

		{["%f[%a][wW]ould%f[%A]"]	=	"woulda"},

--	Inceptive marker
		{["5@[aA]lmost%s(3@%a+)"]	=	" nearly 0@go 5@for %1"},
		{["[jJ]ust%s5@[aA]bout%s5@[tT]o%s([03]@%a+)"]	=	" just 0@go 5@for %1"},
		{["5@[aA]bout%s5@[tT]o%s([03]@%a+)"]	=	" 0@go 5@for %1"},
		{["%s[3]@be%s2@[gG]o%s5@[tT]o%s([03]@%a+)"]	=	" 0@go 5@for %1"},


--	We were finished eating
		{["%s[0-4]@be%s[fF]inish%a*(%s2@%a+)"]	=	" done%1"},
		{["%s[0-4]@be%s[cC]omplet%a*(%s2@%a+)"]	=	" done%1"},

--	Progressive
		{["[01]@be(%s6?@?%a*%s?2@%a)"]	=	"a%1"},
		{["(%a%a)'s(%s6?@?%a*%s?2@%a)"]	=	"%1 a%2"},

--	Past Progressive
		{["3@be(%s2@%a)"]	=	"been a%1"},

--	"Bob was eating" -> "Bob deh eat"
--		{["(%s)3@be%s(2@%a+)"]	=	"%1deh %2"},

--	Past Habit, "I used to go there"
		{["3@[uU]se%s5@[tT]o%s([03]@%a+)"]	=	"been %1"},

--	I'm going to do this
		{["(%s2@[gG]o%s)5@[tT]o%s([03]@%a+)"]	=	"%1 %2"},

--	I'm trying to go to Brill
		{["(%s[0-4]@[tT]ry%s)5@[tT]o%s([03]@%a+)"]	=	"%1%2"},

--	"Mike must have wanted to eat"
		{["%s0@[hH]ave%s?(%a*%s[34]@%a+)"]	=	" been %1"},

--	When Bob gets here --> Whenever Bob gets here
		{["%d*@?%f[%a][wW]hen(%A+%a+%s+[01]@%a)"]		= "whenever-time%1"},

--	"a" before interrogatives
		{["(%s84@%a+%s[13]@[bB]e%A+%a)"]	=	jahswitch},
		{["(%s84@%a+%s9?[0-4]@%a+%A+%a)"]	=	jahswitch},
		{["^(%s84@%a)"]	=	jahswitch},

		{["(a%s84@[%a%s]+)9?[01]@[dD]o%s"]	=	"%1"},

--	do they make me run fast?
		{["[01]@[dD]o(%s[%s%a]+[01]@%a)"]	=	"%1"},

--	"A" starts I'll
		{["^%s8[13]@[iI]t?'[sl]+(%A+%a+%A+%a+)"]	=	" a%1"},


--	Location: "They are at the gate"
		{["%s[13]@[bB]e%f[%A](.-)5@[aA]t%s"]	=	"%1deh a "},
		{["%s[13]@[bB]e%f[%A](.-)5@[iI]n(%A+%a%a)"]	=	"%1deh 5@a%2"},
		{["%s[13]@[bB]e%f[%A](.-)5@[iI]nside(%A+%a%a)"]	=	"%1deh 5@a%2"},

		{["%s[13]@[bB]e%f[%A](.-)(5@%a%a%a%a)"]	=	"%1deh %2"},

		{["%s[0-4][hH]ave%s4@[bB]e%f[%A](.-)(5@%a%a)"]	=	"%1deh %2"},

		{["^([^@]-%a)%s5@[aA]t(%A+%a%a)"]	=	"%1 deh 5@upon %2"},
		{["^([^@]-%a)%s5@[iI]n(%A+%a%a)"]	=	"%1 deh 5@in %2"},


		{["%s[13]@[bB]e%f[%A](.-)%s[tT]here(%A+%a)"]	=	"%1 deh%1"},
--		{["%s[13]@[bB]e%f[%A](.-)%s[tT]here%?%s$"]	=	"%1, ya? "},


		{["%s([0-5]@%a+)%s[uU]s([%s%p])"]	=	" %1 we%2"},


--	"Bill ran so that we could live" -> "Bill run and make we live"
		{["(%s3@%a+%s.-)[sS]o%s[tT]hat%s(%a.-)[cC]ould(%s[03]@%a+)"]	=	"%1 and make %2%3"},
		{["(%s3@%a+%s.-)[sS]o%s(%a.-)[cC]ould(%s[03]@%a+)"]	=	"%1 and make %2%3"},

--	"We should get some soon" -> "We suppozi get some soon"
		{["%s[sS]hould(%s%a+)%s([03]@%a+)"]	=	" %1 suppozi %2"},
		{["%s[sS]hould(%s[03]@%a+)"]	=	" suppozi%1"},
		{["%s[03]@[sS]uppose%s[tT]o(%s[03]@%a+)"]	=	" suppozi%1"},
		{["(@8%d@%a+%s)[bB]etter(%s[03]@%a+)"]	=	"%1suppozi%2"},

--	"Does anyone think the people are coming" -> "anyone does think the people are coming"
		{["(%s9%d?@%a+)(.-%s8%d@%a)(%s0@@%%a+)"]	=	"%2%1%3"},

--	"Did they say that" -> "Dem say that"
		{["%s9%d?@%a+(%s%a[%a%s]-[03]@%a+)"]	=	" %1"},
--		"Are the people coming" -> "The people coming"
		{["%s9%d?@%a+(%s[%a%d][%a%d@%s']-%f[%d]2@%a+)"]	=	"%1"},


--	Future
		{["(%a)%s0@[wW]ill(%s[03]@%a%a%a)"]	=	"%1 0@go%2"},
		{["(%a)%s0@[wW]ill(%s0[^%d%p%sbB]%a)"]	=	"%1 0@go%2"},


--	That was dumb --> That did dumb
		{["%s(8%d@%a+)%s3@be%s(%a+)"]	=	" %1 did %2"},


--	Polite imperative
		{["%s[pP]lease%s([03]@%a+)"]	=	" please t~o %1"},
--	"Bob wants to go" -> "Bob want for go"
		{["5@[tT]o(%s[03]@%a+)"]	=	"for%1"},

--	That guy wants --> The guy there wants
		{["%f[%a][tT]hat%s(8?%d?2?@%a+%s)([0134]%a+%s[5-7]@%a)"]	=	"the %1there%2"},
		{["%f[%a][tT]his%s(8?%d?2?@%a+%s)([0134]%a+%s[5-7]@%a)"]	=	"the %1here%2"},

		{["%f[%a][tT]hat(%s8%d@%a+%s.-[0-4]@%a)"]	=	"what%1"},
		{["[0-4]@be%s([1-4]@%a)"]	=	"a %1"},
		{["[012349]@do%s([0-4]@%a)"]	=	"%1"},

--	Remove "be"
		{["%d+@[bB]e%s([67]@%a)"]	=	"%1"},
		{["[91234]+@[bB]e%s"]	=	""},

--	Alter "Mi a go bring" --> "Mi a come bring"
		{["%f[%a][gG]o%s(%d@bring)"]	=	"come %1"},
		{["%f[%a][gG]o%s(%d@g[eo]t%s7@%a)"]	=	"come %1"},

--	Change "my" to "the" if the object (after verb or preposition)
--		{["([1-5]@%a+)%s7@[mM]y%s"]	=	"%1 the "},


--	Demonstratives
--		{["([0-5]@%a+%A+[tT]his)(%s%a)"]	=	"%1 yah%2"},
		{["([0-5]@%a+%A+[tT]hem)(%s%a)"]	=	"%1 deh%2"},
		{["([0-5]@%a+%A+)[tT]hese(%s%a)"]	=	"%1this yah%2"},
		{["([0-5]@%a+%A+)[tT]hose(%s%a)"]	=	"%1them deh%2"},


--	Change on to 'pon (before article)
		{["5@on(%s7@%a+)"]	=	"upon%1"},

--	Change "been" to "gone"
		{["%f[%a][dD]one%s4@[bB]e%f[%A]"]	=	"gone"},
		{["%f[%a][dD]one%s4@[gG]o%f[%A]"]	=	"gone"},
		{["4@[bB]e%f[%A]"]	=	"gone"},
		{["4@[gG]o%f[%A]"]	=	"gone"},

--	No elliptical grammar in Jah
		{["(8%d?@%a+%s[01]@[dD]o)(%A+)$"]		= "%1 that%2"},
		{["(8%d?@%a+%s0@)[wW]ill(%A+)$"]		= "%1go do that%2"},

--	Restore "thanks"
		{["(1@[tT]hank)%f[%A]"]	=	"%1s"},
--	Restore "lets"
		{["1@[lL]et(%s[06]@%a%a+)"]	=	"82@we%1"},

--	Remove question grammar except "can"
		{["9%d?@[^%d%p%scC]%a+%s([0-4]@%a)"]	=	"%1"},

--	Object us --> we
		{["([0-5]@%a+%A+)[uU]s%f[%A]"]	=	"%1we"},

		{["9@([^%d%p%scC]%a+%s[^0-4]@?%a)"]	=	"%1"},
--	Passive "get" + verb --> verb only
		{["[0-4]@[gG]et(%s[34]@%a)"]	=	"%1"},
--	Revert "get" (past) back to "got" ...it's too important.
		{["3@[gG]et%f[%A]"]	=	"3@got"},
--	Revert "willing to"
		{["2@[wW]ill%s5@[tT]o%f[%A]"]	=	"2@want to"},

--	Probably --> i think
		{["^%S*%s*(8[1-4]@%a+)%s[pP]robably%f[%A]([^?]+)$"]	=	"83@I 0@think %1"},

--	It died --> It dead
		{["(8%d?@%a+%s)[0134]@[dD]ie%f[%A]"]	=	"%1dead"},

--	I'm next to the bank --> I there about the bank
		{["%f[%a][nN]ext%s5@[tT]o"]	=	"there about"},
		{["%f[%a][cC]lose%s5@[tT]o%s(7@%a)"]	=	"there about %1"},
		{["%f[%a][aA]lmost%s5@[tT]o%s(7@%a)"]	=	"there about %1"},

--	I told you already --> I done tell you
		{["(8%d@%a+%s)([34]@%a+%s)6@[aA]lready%f[%A]"]	=	"%1done %2"},
		{["(8%d@%a+%s)6@[aA]lready%s([34]@%a+)"]	=	"%1done %2"},

--	Begin for run --> begin run
		{["([0-4]@[bB]egin%s)[fF]or%s([03]@%a)"]	=	"%1%2"},
		{["([0-4]@[sS]tart%s)[fF]or%s([03]@%a)"]	=	"%1%2"},

--	I even ran there --> I all run there
		{["(8%d@%a+%s)[eE]ven%s([0-4]@%a)"]	=	"%1all %2"},

--	below the house --> bottomside the house
		{["[bB]elow(%s7@%a)"]	=	"bottomside%1"},
		{["[uU]nder(%s7@%a)"]	=	"bottomside%1"},
		{["[bB]eneath(%s7@%a)"]	=	"bottomside%1"},
		{["[uU]nderneath(%s7@%a)"]	=	"bottomside%1"},

--	who here wants to go --> who this side want fi go
		{["(84@%a+)%s[hH]ere%f[%A]"]	=	"%1 this side"},

--	He only said he'd go
		{["%f[%a][oO]nly%s([0-4]@%a)"]	=	"ongle %1"},

}



local verbs = Elo.Verbs
Elo.Verbs = nil
local function jahgrammar(msg,testflag)
	msg = Elo.AddSpaces(msg)

	msg = expandeverything(msg)

--	Make plural the default if verbs are irregular
	msg = elogsub(msg,"(%A)[wW]ould%s[lL]ike%s[tT]o(%A)","%1want to%2")

	msg = elogsub(msg,"(%A)[aA]m(%A)","%1are%2")
	msg = elogsub(msg,"(%A)[iI]s(%A)","%1are%2")
	msg = elogsub(msg,"(%A)[wW]as(%A)","%1were%2")

	msg = Elo.AnalyzeGrammar(msg,true,true)

	msg = elogsub(msg,"7@[iI]t's(%A)","81@it 1@be%1")

	msg = elogsub(msg,"(%A)[iI]s(%A)","%1be%2")
	msg = elogsub(msg,"(%A)[aA]re(%A)","%1be%2")

	msg = elogsub(msg,"(%A)[dD]oes(%A)","%1do%2")
	msg = elogsub(msg,"(%A)[hH]as(%A)","%1have%2")

	msg = elogsub(msg,"(7@%a%a-%s)2@(%a+)",function(a,b)
			return a..verbs[b][2]
		end
		)
--	msg = elogsub(msg,"%f[%a](%a+)(%s[1-4]@%a+)",function(a,b)
--				return verbs[a][2]..b
--		end
--		)

	for a,b in p(jahverblist) do
		for k,v in p(b) do
--			msg = elogsub(msg,k,v)
			msg = elogsub(msg,k,v,a)
		end
	end
	return msg
--	return elogsub(msg,"%f[%d]%d+@(%a)","%1")
end





Elo.RaceFilter[1]={
[1]={
	["^[%s~hHmM]*([,.!?]+)[%s~]*$"]	=	"Dro'duuk%1",


},
[2]={
	["(%A)[dD]'?o+h+%A"]	=	"%1grr! ",
	["(%A)[dD]'?u+h+%A"]	=	"%1it's obvious! ",
	["(%A)[gG][ae]+h+%A"]		=	"%1grr! ",
	["(%A)[mM]y%s?[gG][ao]+w?d(%A)"]		=	"%1my word! %2",
	["(%A)[tT]hank%s?[gG][ao]+w?d(%A)"]		=	"%1thank Doomhammer%2",
	["(%A)[rR]+a+w+r+(%A)"]		=	"%1lok'tar! %2",


	["(%A)[nN][oe30]?[uow0]+b+([sz]*%A)"]				=	"%1scrub%2",
	["(%A)[lL]ow?b[iey]+([sz]*%A)"]			=	"%1raw recruit%2",
	["(%A)[yY]+a+[yY]+(%A)"]		=	"%1victory!%2",

	["(%A[nN])[ou]pe(%A)"]				=	"%1o%2",
},
[3]={
	["(%A)[wW]t[fh]+%s*[iI]s(%A)"]	=	"%1what in the Twisting Nether is%2",
	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1hoh! My tummy aches!%2",

	["(%A)[lL]ike%s[cC]raz+y+(%A)"]	=	"%1furiously%2",



},
[5]={

	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"For the Horde! I have reached Level %1!",
},
[6]={
	["^[wW]t[fh]+%a*[^%a%d|]+"]	=	"What in Durotan's name! ",
	["(%A)[wW]t[fh]+(%A)"]	=	"%1what under the sky%2",
	["^[wW]t[fh]+%a*$"]		=	"Demons take me!",


	["(%A)[sS]hut%s[uU]p(%A)"]	=	"%1shut your gaping maw%2",
	["^[sS]hut%s[uU]p[^%a%d|?]+"]		=	"Silence, ",
	["^[sS]hut%s[uU]p%s+"]		=	"Silence, ",
	["(%A)[sS]hut%s[uU]p?$"]	=	"%1shut your gaping maw",
	["^[sS]hut%s[uU]p$"]		=	"Silence!",

--	Replace ZOMG, omfg, gawd, jeez, wtf, with various archaic expressions
	["^omg$"]	=	"By the clans!",
	["^omg%a+"]	=	"Upon my honor!",
	["(%a)[%s!,.]+omg%f[%A]"]	=	"%1, by Durotan!",

	["(%a%a)[%s%p]-[>=]+[%-%s*]*%(%s*$"]		=	"%1, and my blood boils!",
	["(%a%a)[%s%p]+[QtT][oO0%._]?[QtT]%s*$"]		=	"%1, as bitter tears flow",
	["(%a%a)[%s%p]-[._]%-[;,]*$"]			=	"%1, dull though that sounds",

	["^[cC]ra+p+$"]		=	"There's some devilry at work here...",


	["^[gG]od%s([^dD])"]		=	"Foul omen! %1",

	["^[gG]od(%p)"]	=	"By Durotan's blade%1",
	["^[gG]od$"]		=	"By Thrall's hammer!",
	["^[gGjJ]e+[szb]+e?u*s*[%s!,.]+(.*)"]	=	"By Doomhammer, %1",
	["^[gG]e+[szb]+e?u*s*$"]	=	"Grom save us!",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"Grom help us!",

	["^[gGnN][jJwW]%s[oO]n%s"]		=	"Well done on ",
	["^[gGnN][jJwW]%s(%a%a%a-)ing%s"]		=	"You did well %1ing ",

	["^[fF][aou]+c?k(%p)"]	=	"Blast it%1",
--	["^[fFmM][aou]+c?k%s([^tT])"]	=	"Curses %1",
	["^[fFmM][aou]+c?k$"]		=	"Oh, blast it all!",

	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"May demons take you!",

	["[fF][aou]+w?c?ke?r"]		=	"demon",

	["(%A)[dD]a+[mn]+%s?[iI]t(%A)"]			=	"%1blast it%2",
	["(%A)[dD]a+[mn]+%s?[iI]t$"]				=	"%1blast it!",
	["^[dD]a+[mn]+%s?[iI]t$"]					=	"What devilry is this!%?",

	["(%w)%s[hH]el+%sof%sa"]		=	"%1 mighty",

},
[7]={
	["^no$"]			=	"Unfortunately not",

	["^[yY]es$"]		=	"Lok'tar",
	["^[yY][ea]+h?$"]	=	"Lok'tar",

	["^[sS]ee%syou$"]				=	"Lok'gredar logar",
	["^[bB]ye[^%d%a?]*$"]		=	"Go forth to victory!",
	["^[tT]ake%s?[cC]are[^%d%a?]*$"]		=	"May your blades never dull",
	["^[lL]ater$"]			=	"Go forth to victory",

	["^[gG][lL](%A*)$"]		=	"Strength!",

--	Replace woot, WOOOOOOT, w00t and WOOHAA
	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1hurray%2",
	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 for victory!",
	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"! For victory!",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]		=	"For Doomhammer%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]			=	"For the Horde! ",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"For the Warchief!",
	["^[bB][o0]+y+a+h*"]				=	"Eat that, swine!",


	["^[yY][oO][yYoO]*[^%a%d|?]+"]	=	"Mok'gra, ",
	["^[yY][oO][yYoO]*$"]	=	"Grom'ka!",

	["^[cCkK][oO0][oO0]+[lL]?[sz]*$"]		=	"This bodes well",

	["^[aA]w+e?some?$"]		=	"This bodes well",

	["[wW]hat's%sup$"]		=	"Blood and thunder!",
	["[wW]hat's%sup%s"]		=	"Throm'ka, ",
	["^[tT][yY][tTyY]*(%A*)$"]	=	"Aka'magosh%1",
	["^[tT]ha?n?[zxc]s?$"]		=	"Glok'tar",
	["[sS]+h?[au]*w+e+t+$"]		=	"This bodes well!",

	["%f[%a][gG]o%s?[gGo][gGo%s%p]+%f[%A]"]	=	"lok'regan ogal!",

	["%s[fF]or%s[tT]he%s[wW]in[^%a%d|?]+"]	=	" will always be honored%. ",

	["^[dD]u+de%A(%a)"]	=	"Why, %1",
	["^[dD]u+de$"]	=	"By Durotan's blade%.%.%.",

	["(%A)[nN]ub([sz]*%A)"]		=	"%1whelp%2",
	["^[nN]ub([sz]*%A)"]		=	"Whelp%1",
	["(%A)[nN]ub([sz])$"]		=	"%1whelp%2",
	["^[nN]ub[sz]*$"]			=	"How craven!",

	["([wW]h%a+)%s[tT]he%s?[hH]el+%s([^?!]+)[?!]*"]	=	"%1 in Orgrim's name %2%?",


	["^[lL][oO0][lLoO0]+%p*$"]	=	"haha!",

	["^[gG]ood%s[gG]ame$"] = "Doomhammer would be proud indeed.",

	["(%A)[dD]a+[mn]+e?d(%A)"]	=	"%1cursed%2",

	["^[sS]h?ure$"]		=	"Dabu",
	["^[pP]r[aoub]*l+y$"]			=	"Zug zug",

	["^[nN]ice%s?[tT]ry$"]			=	"So close to victory...",
	["^[nN]ice%s?[tT]ry%p+$"]			=	"Doomhammer would be proud!",
},
[14] = {
	["(%A)[fF]ucking(%A)"]	=	"%1accursed%2",

	["(%A)[cC]ongratulations%s([oO]n%s)"]		= "%1honor and glory %2",
	["^(%A)[cC]ertainly(%A+%a+%A+%a)"]	=	"%1Zub%2",

	["(%A)[hH]ello(%A)"]				=	"mok'gra",


},
[15]={
	["(%A)[cC]ongratulations(%A)"]		= "%1you do us honor, %2",
	["(%A)[hH]aha?([%s%p])"]			= "%1har%2",
},
}

Elo.RaceFilter[2]={
[1]={

},
[2]={
	["(%A)[dD]'?o+h+%A"]	=	"%1alas! ",

	["(%A)[gG][ae]+h+%A"]		=	"%1alas! ",
	["(%A)[mM]y%s?[gG][ao]+w?d(%A)"]		=	"%1by the Earth Mother! %2",
	["(%A)[tT]hank%s?[gG][ao]+w?d(%A)"]		=	"%1thank the ancestors%2",
	["(%A)[rR]+a+w+r+(%A)"]		=	"%1do not push me or I will impale you on my horns!%2",


	["(%A)[yY]+a+[yY]+(%A)"]		=	"%1praise the Earth Mother!%2",
	["(%A)[lL]ow?b[iey]+([sz]*%A)"]		=	"%1greenhorn%2",
	["(%A)[nN][oe30]?[uow0]+b+([sz]*%A)"]	=	"%1whelp%2",
--	["(%A)[gG]o%s?bac?k(%A)"]		=	"%1return%2",
	["(%A)[hH]ead%s?bac?k(%A[tT]o)"]		=	"%1return%2",


},
[3]={
	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1downright laughable!%2",
	["(%A)[lL]ike%s[cC]raz+y+(%A)"]	=	"%1like thunder%2",



},
[5]={
	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"The winds have guided me to Level %1!",
},
[6]={
	["^[aA]?[bB]out%s?[tT][oa]"]			=	"I soon shall",

--	Replace ZOMG, omfg, gawd, jeez, wtf, with various archaic expressions
	["^omg%a*[^%a%d|?]+"]	=	"Bless my hooves! ",
	["^omg%a*%s"]		=	"Simply amazing! ",
	["^omg$"]	=	"By the ancestors!",
	["(%A)omg%a+"]	=	"%1by the spirits! ",
	["^omg%a+$"]	=	"Upon my word!",
	["(%a)[%s!,.]+omg%f[%A]"]	=	"%1, by the Earth Mother!",
	["(%a)[%s!,.]+omg$"]	=	"%1%. I don't know what to say!",

--	"Its" is "It's" almost all the time when starting a line
	["^[iI]ts(%A)"]	=	"It is%1",

--	"its" followed by "the" two words later is usually "it's"
	["(%A[iI])ts%s(%a+)%s[tT]he(%A)"]	=	"%1t is %2 the%3",

--	Other common "it's" places
	["(%A[iI])ts%s[oO]nly(%A)"]	=	"%1t is only%2",
	["(%A[iI])ts%s[tT]oo(%A)"]	=	"%1t is too%2",
	["(%A[iI])ts%s[jJ]ust(%A)"]	=	"%1t is just%2",
	["(%A[iI])ts%s(%a%a-ing%A)"]	=	"%1t is %2",
	["(%A[iI])ts%s[nN]o([wtob%s])"]	=	"%1t is no%2",

	["(%A[iI])ts%s[tT]he(%A)"]	=	"%1t is the%2",
	["(%A[iI])ts%s[aA](n?%A)"]	=	"%1t is a%2",

	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"May Mother Earth forgive you!",

	["^[gG]od(%p)"]	=	"By the clans%1",
	["^[gG]od$"]		=	"Upon my honor!",
	["^[gGjJ]e+[szb]+e?u*s*[%s!,.]+(.*)"]	=	"By the Earth Mother, %1",
	["^[gG]e+[szb]+e?u*s*$"]	=	"Mother Earth help us!",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"Spirits help us!",

	["^[wW]t[fh]+%a*[^%a%d|]+"]	=	"By my ancenstors' horns, ",
	["(%A)[wW]t[fh]+(%A)"]	=	"%1what under the Sun%2",
	["^[wW]t[fh]+%a*$"]		=	"How is it possible!?",

	["(%A)[sS]hut%s[uU]p(%A)"]	=	"%1give us peace%2",
	["^[sS]hut%s[uU]p[^%a%d|?]+"]		=	"Peace, ",
	["^[sS]hut%s[uU]p%s+"]		=	"Peace, ",
	["(%A)[sS]hut%s[uU]p?$"]	=	"%1be silent",
	["^[sS]hut%s[uU]p$"]		=	"Peace!",

	["^[cC]ra+p+$"]		=	"Will these troubles never cease%.%.%.",
	["[fF][aou]+w?c?ke?r"]		=	"ravager",

	["^[fF][aou]+c?k(%p)"]	=	"Oh%1",
--	["^[fFmM][aou]+c?k%s([^tT])"]	=	"Curses %1",
	["^[fFmM][aou]+c?k$"]		=	"Mother Earth help me",

},
[7]={

	["^[oO]+k+[iey]+%A*[dD]ok%a+"]	=	"Lei ah suse amein%. ",

	["^[gG]ood%s?[wW]ork%p*$"]		=	"For the tribes!",

	["^[gG]ood%s?[jJ]ob%p*$"]		=	"The Earth Mother smiles upon us!",
	["^[gG]ood%s[gG]ame$"] = "And so the battle draws to a close.",

--	Replace woot, WOOOOOOT, w00t and WOOHAA
	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1ancestors be praised!%2",
	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 Ishnu porah!",
	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"! Ishnu porah!",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]		=	"thank the Earth Mother%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]			=	"ancestors be praised! ",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"for the tribes!",
	["^[bB][o0]+y+a+h*"]				=	"for my ancestors!",


	["^[cCkK][oO0][oO0]+[lL]?[sz]*$"]		=	"very good",

	["^[aA]w+e?some?$"]		=	"praise the Earth Mother",

	["^[iI]?[dDfF][ou]+n+o+(%A)"]	=	"I do not know%1",
	["^[iI]?[dDfF][ou]+n+o+$"]	=	"alas, I do not know",


	["^no$"]			=	"I'm afraid not",

	["^[gG][lL](%A*)$"]			=	"Ancestors watch over you%1",



	["^[tT][yY][tTyY]*(%A*)$"]	=	"Thank you, kind spirit%1",

	["^[tT]ha?n?[zxc]s?$"]		=	"Thanks, friend",
	["^[sS]+h?[au]*w+e+t+$"]		=	"Very good",

	["^[lL][oO0][lLoO0]+%p*$"]	=	"Haha!",

	["^[bB]ye[^%d%a?]*$"]		=	"Go in peace",
	["^[tT]ake%s?[cC]are[^%d%a?]*$"]		=	"Walk with the Earth Mother",

	["^[hH]ello+$"]		=	"Greetings, traveler",

	["^[sS]ee%syou$"]		=	"Winds be at your back!",

	["^[lL]ater$"]			=	"We shall meet again",
	["%s[fF]or%s[tT]he%s[wW]in[^%a%d|?]+"]	=	" shall be cherished till the end of our days%. ",

	["%f[%a][gG]o%s?[gGo][gGo%s%p]+%f[%A]"]	=	"hoof it! ",

--	Replace 'fellows' with 'brethren'
	["^[fF]ellows(%p)"]	=	"Brothers%1",
	["^[fF]ellows%s"]		=	"My brethren, ",
	["^[fF]ellows$"]		=	"My brethren...",

},
[8]={
	["^(%a+)'?s%salways%sbeen"]		=	"Ever has %1 been",
	["^(%a%a-)'?ve%salways%sbeen"]		=	"Ever have %1 been",

},
[13] = {
		["^(.+)$"] = expandeverything,

},

[14]={

	["(%A)[hH]ello(%A+)$"]				=	"%1ishne alo porah%2",

	["^(%A)[tT]he%s?[sS]un(%A)"]		= "%1An'she%2",
	["^(%A)[tT]he%s?[mM]oon(%A)"]		= "%1Mu'sha%2",

	["(%A)[iI]%s[rR]eally%s[wW]ant%s[tT]o(%A)"]	=	"%1I should dearly like to%2",
},
[15] = {

	["(%A)[cC]ongratulations(%A)"]			= "%1you make your ancestors proud, %2",

	["(%A)[iI]'m(%A)"]		=	"%1I am%2",
	["(%A%a+)'ve(%A)"]		=	"%1 have%2",
	["(%A%a+)'ll(%A)"]		=	"%1 will%2",
	["(%A%a+)'d(%A)"]		=	"%1 would%2",


},


}
--	Trolls. Basilectic Jamaican Patois, inspired by http://www.geocities.com/yotaino/grama.html
Elo.RaceFilter[3]={
[1]={
	["([^nNoOeErRsS%p%s%d])!+%s*$"]	=	"%1, mon!",

	["(%a%a%a[^rRsSaAeEyYmMnN%p%s%d])([!?]+%s%a%a)"]	=	"%1, mon%2",

	["^%s*%*+(%w[%w']+)%s*$"]		=	" Cho, make that \"%1\"",

},
[2]={
	["(%A)[dD]'?o+h+%A"]	=	"%1cho! ",
	["(%A)[dD]'?u+h+%A"]	=	"%1you don't see%? ",
	["(%A)[gG][ae]+h+%A"]		=	"%1cha! ",
	["(%A)[mM]y%s?[gG][ao]+w?d(%A)"]		=	"%1by the spirits! %2",
	["(%A)[tT]hank%s?[gG][ao]+w?d(%A)"]		=	"%1praise the spirits%2",
	["(%A)[rR]+a+w+r+(%A)"]		=	"%1tas'dingo! %2",

	["(%A)[iI]%s?[dD][ou]+n+o+%s?([wW]%a+)"]	=	"nil",
	["(%A)[cCkK]an'?t%s?[sS]ta+nd(%A)"]	=	"nil",
	["^%s[nN]o+%s?[rR]ush(%A)"]			=	"nil",

	["(%A)[aA]lot+(%A)"]	=	"%1plenty%2",


	["(%A[nN])[ou]pe(%A)"]				=	"%1o%2",

	["(%A)[gG][eui]rl+(%A)"]		=	"%1gyal%2",
	["(%A)[cC]hi[ck]+([sz]*%A)"]		=	"%1dawtah%2",
	["(%A)[tT][ie]+n[se]*y(%A)"]		=	"%1beenie%2",
--	Replace 'ina' 'ona' and 'ifa' with 'in a' and 'on a' etc.
	["(%A)[yY]+a+[yY]+(%A)"]		=	"%1tas'dingo!%2",
	["(%A[dD])own(%A)"]		=	"%1ung%2",
	["(%A)[wW]oman(%A)"]		=	"%1uumon%2",
	["(%A)[wW]omen(%A)"]		=	"%1uumon dem%2",
	["(%A)Stone([sz]*%A)"]		=	"%1Rockstone%2",
	["(%A)stone([sz]*%A)"]		=	"%1rockstone%2",
	["(%A)[lL]otsa(%A)"]		=	"%1whole heap of%2",
	["(%A)[lL]ots%s?of(%A)"]		=	"%1whole heap of%2",
	["(%A)[lL]ot+a(%A)"]	=	"%1plenty%2",
	["(%A)[aA]%s[cC]ouple(%A)"]		=	"%1a little%2",
	["(%A[io][fnr])a(%A)"]		=	"nil",
	["(%Ao[rn])a(%A)"]		=	"%1 a%2",
	["(%A[iI])([fn])%s?a(%A)"]		=	"%1%2%2a%3",
--	["(%A)[tT]hier(%A)"]	=	"%1deh%2",
--	["(%A)[tT]heir(%A)"]	=	"%1deh%2",


	["(%A)[uU]p%s?[fF]or(%A)"]			=	"nil",
	["(%A)[lL][eE3][eE3][tT7](%A)"]	=	"%1massive%2",
	["(%A)[lL][eE30][wW0][tT7][sz]*(%A)"]	=	"%1bling%2",

	["(%A)[lL]ow?b[iey]+([sz]*%A)"]		=	"%1youth%2",

	["(%A)[lL]o+[sz]+er([sz]*%A)"]		=	"%1raggamuffin%2",
	["(%A)[pP]us+[yie]+([sz]*%A)"]		=	"%1bumbo%-hole%2",
	["(%A)[rR]?[e-]?tard([sz]*%A)"]			=	"%1lagga%-head%2",
	["(%A)[rR]etarde?d(%A)"] = "%1lagga%-head%2",

	["(%A)[nN]ig+([sz]*)(%A)"]			=	"%1dutty%-bwoy%2%3",
	["(%A)[nN]ig+[eaui][rh]*([sz]*%A)"]			=	"%1dutty%-bwoy%2",

	["(%A)[fF]u[ck]+tard([sz]*%A)"]			=	"%1lagga%-head%2",
	["(%A)[aA@][sz%$][sz%$]%s?hat([sz]*%A)"]		=	"%1rassclot%2",
	["(%A)[aA@][sz%$][sz%$]%s?load([sz]*%A)"]		=	"%1whole heap%2",

	["(%A)[fF][ou]+%s?c?k%s?load(%A)"]			=	"%1whole heap%2",
	["(%A)[sS]hite?%s?head([sz]*%A)"]	=	"%1zutopeck%2",
	["(%A)[sS]hite?%s?to%s?do(%A)"]	=	"%1tings to do%2",
	["(%A)[dD][ui]m[pb]?%s?shit([sz]*%A)"]	=	"%1zutopong%2",
	["(%A)[dD]ic?k%s?he[a]?d([sz]*%A)"]		=	"%1half%-idiot%2",
	["(%A)[dD]um+b?[fFmM]u[c]?k([sz]*%A)"]	=	"%1half%-idiot%2",
	["(%A)[dD]um+b?[aA@][sz%$][sz%$]e?([sz]*%A)"]		=	"%1buguyaga%2",
	["(%A)[cC]lu[st]+er%s?fu?c?k([sz]*%A)"]	=	"%1mashclot%2",
	["(%A)[dD][ou]+che?%s?bag([sz]*%A)"]		=	"%1dung%-heap%2",

	["(%A)[aA@][sz%$][sz%$]+%s?hole?([sz]*%A)"]		=	"%1rassclot%2",
	["(%A)[aA@][sz%$][sz%$]+%s?wipe?([sz]*%A)"]		=	"%1filty swine%2",
	["(%A)[mM][ou]th[ea]*[hr]*%A*[fF][aou]+w?c?k[ear][rh]?(%A)"]		=	"%1bumboclot%2",
	["(%A)[hH]oly%s?shit[^%a%d|?]+"]		=	"%1rhaatid! ",
	["(%A)[hH]oly%s?[cC]rap[^%a%d|?]+"]		=	"%1by di spirits! ",
	["(%A)[hH]oly%s?[fF]uc?k[^%a%d|?]+"]		=	"%1oh, hex me! ",

	["(%A)[wW]ea[%s%p]*k[%s%p]*[sS][%s%p]*auce?(%A)"] = "%1quattie%2",

--	["(%A)[oO]n%s([^tTdD]%a)"]		=	"%1'pon %2",
--	["(%A)[oO]n(%A)$"]		=	"%1'pon%2",

	["(%A)[gG]h?[ae]+y+(%A)"]		=	"%1batty%2",
	["(%A)[fF]ag+[oieau]?t?([sz]*%A)"]		=	"%1chi%-chi mon%2",
	["(%A)[fF]gt([sz]*%A)"]			=	"%1batty bwoy%2",
	["(%A)[pP]rick([sz]*%A)"]			=	"%1bait%2",
	["(%A)[pP]unk([sz]*%A)"]			=	"%1filty bait%2",
	["(%A)[pP]e+n[ieua]s+(%A)"]		=	"%1buddy%2",
	["(%A)[cC]o*c+k+(%A)"]		=	"%1hood%2",


	["(%A)[pP][sS][tT]%sto(%A)"]	=	"%1talk to%2",
	["(%A)[pP][sS][tT]%swith(%A)"]	=	"%1, just give me%2",

	["(%A)[jJ]ok[ei]%a*(%A)"]		=	"%1jestah%2",

	["(%A[mM])agic[sz]*(%A)"]		=	"%1ojo%2",

--	["(%A)[tT]he%sother%sday(%A)"]		=	"%1wa day%2",

	["(%A)[lL]ast%s(%a%a%a-)day(%A)"]		=	"%1%2day gone%3",

	["(%A)[rR]em[em]*be?re?"]		=	"%1'membah",
	["(%A%a-)nsible(%A)"]		=	"%1nse%2",
	["(%A%a-)nsibility(%A)"]		=	"%1nse%2",

	["(%A)[sS]h?t[eao]le?(%A)"]			=	"%1tief%2",

	["(%A)[gG]impe?d(%A)"]			=	"%1weak%2",
	["(%A)[gG]imp(%A)"]			=	"%1weak%2",

	["(%A)[gG]ank%s?sq[ua]+d([sz]*%A)"]	=	"nil",

	["(%A)[mM]y%s?[gGbB]%A?[fF](%A)"]	=	"nil",
	["(%A)[yY]our%s?[gGbB]%A?[fF](%A)"]	=	"nil",

	["(%A)[gG]f(%A)"]	=	"%1gyalfren%2",
	["(%A)[bB]f(%A)"]	=	"%1bwoyfren%2",


--	["_gncd_"]		=	UnitSex("player"),
--	["(%A)[mM][eE](%A)"]	=	"%1pn_%2",
	["([%s%p])[dD][aA](%A)"]	=	"%1di%2",
	["(%A)[dD]is(%A)"]		=	"nil",
	["(%A)[dD]at(%A)"]		=	"nil",
	["(%A)[dD]ass(%A)"]	=	"nil",
	["(%A)[dD]ere?(%A)"]	=	"nil",

	["(%A)[dD]ude[sz](%A)"]		=	"%1bredren%2",
	["(%A)[dD]ude(%A)"]		=	"%1breddah%2",


--	Replace nuff and enuff and 'nuff
	["(%A)[eE']?[nN]uf+(%A)"]	=	"nil",
	["(%A)[eE]n[ou]+gh(%A)"]	=	"%1'nuff%2",

	["(%A)[vV]er+y%s?[nN]ice(%A)"]	=	"%1wicked%2",
	["(%A)[tT]h([aeio][st]?e?)%s?da[mn]+(%A)"]	=	"%1d%2 magga%-dog%3",


--	Replace 'oic'
	["(%A)[oO]%s?[iI][cC](%A)"]	=	"%1oh, mi zeein%2",

	["(%A)[tT][yY][vV][mM](%A)"]	=	"%1big respect%2",

	["(%A)[hH]ella(%A)"]		=	"%1so%2",
	["(%A)(%a+)%s[aA]s%s?[hH]ell(%A)"]		=	"%1so %2%3",

	["(%A)[nN][oe30][ow0]+b+([sz]*%A)"]	=	"%1bubu%-head%2",
	["(%A)[nN][oe30][ow0]+b+[eiy]+([sz]*%A)"]	=	"%1bubu%2",
	["(%A)[nN][oe30]?[uow0]+b+l[ie]+t([sz]*%A)"]				=	"%1bubu%-head%2",
	["(%A)[nN][oe30]?[uow0]+b+[eiy]+sh(%A)"]		=	"%1bubu%2",
	["(%A)[nN][oe30]?[uow0]+b+[cC]ake(%A)"]		=	"%1bubu%2",
	["(%A)[nN][oe30]?[uow0]+b+age(%A)"]			=	"%1bubu%2",


	["(%A)[bB]ad[%s%-]?[aA@][sS%$][sS%$]([%s!,.]+%a)"]		=	"%1tallowah%2",
	["(%A)[bB]ad[%s%-]?[aA@][sS%$][sS%$]%s$"]		=	"%1tallowah",
	["(%A)[bB]ig+[%s%-]?[aA@][sS%$][sS%$]%s(%a+%A)"]		=	"%1massive %2",
	["(%A)[hH]u+ge[%s%-]?[aA@][sS%$][sS%$]%s(%a+%A)"]	=	"%1massive %2",
	["(%A)[lL]ong[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1tall%2",
	["(%A)[sS]h?low[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1slow%2",
	["(%A)[wW]i[sz]e[%s%-]?[aA@][sz%$][sz%$](%A)"]		=	"%1buttu%2",
	["(%A)[lL]ame[%s%-]?[aA@][sS%$][sS%$](%A)"]			=	"%1pyaa%-pyaa%2",
	["(%A)[wW]eak[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1pyaa%-pyaa%2",
	["(%A)[dD]um+b?[%s%-]?[aA@][sz%$][sz%$]e?([sz]*%A)"]		=	"%1lagga%-head%2",
	["(%A)[sS]h?[tu]+p+id%A*[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"%1lagga%-head%2",

	["(%A)[fF]at[%s%-]?[aA@][sz%$][sz%$]e?([sz]*%A)"]		=	"%1slabba%-slabba%2",

	["(%A)[nN]%s?[pP][sz]*(%A)"]	=	"%1everything is irie%2",

	["(%A)[lL]+a+m+e(%A)"]		=	"%1fengki%-fengki%2",
	["(%A)[lL]amest(%A)"]		=	"%1fengki%-fengki%2",

--	["(%A[yY]+)e+a+h*(%A)"]	=	"%1a%2",
	["(%A)[bB][rR][tT](%A)"]	=	"%1soon come%2",
	["(%A)[bB][rR][bB](%A)"]	=	"%1soon come%2",
	["(%A)[aA]sap(%A)"]	=	"%1big haste%2",

--	Replace 'ic'
	["(%A)[iI]%s?[cC](%A)"]	=	"%1mi zeein%2",

},
[3]={
	["(%A)[aA]%s?[cCkK][eoO0][woO0]+[lL](%A%a+)"]		=	"nil",
	["(%A)[nN]ot%s?[cCkK][eoO0][woO0]+[lL](%A%a+)"]		=	"nil",
	["(%A)[lL]ike%s[cC]raz+y+(%A)"]	=	"%1leggo beast%2",

	["(%A)[wW]t[fh]+%s*[iI]s(%A)"]	=	"%1what is%2",
	["(%A)[wW]t[fh]+%s*[aA]?re?(%A)"]	=	"%1what are%2",
	["(%A)[wW]t[fh]+%s*[wW]a[sd]+(%A)"]	=	"%1what was%2",
	["(%A)[wW]t[fh]+%s*[wW]ere?(%A)"]	=	"%1what was%2",

	["(.)[%p%s]+[pP][gs]*[tw]+%s?[mM]?e?%s?[fF]or(%A)"]	=	"%1%. Just ask me for %2",
	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1that makes me laugh, mon!%2",

--	["(%A[wW]h%a+)%s[dD]oe?s?e?(%A)"]		=	"%1%2",
--	["(%A[hH]ow)%s[dD]oe?s?e?(%A)"]		=	"%1%2",


	["(%A)[yY]ou%A*[bB]i[yao]*t?[cs]he?([sz]*%A)"]	=	"%1you bumboclot%2",

},
[5]={
	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"Come get the voodoo! I have gotten Level %1!",
},
[6]={
--	Translate ideogrammatic expressions before GrammarNazi's punctuation filters mangle them.
	["(%a.-)[.,!%s]+[;:>=x]+[%-%(%s]*[oODdbpPsS|%]%):]+%s*$"]	=	"%1, mon!",
--	["(%a.-)[.,!%s]*[%(;:]*%^[_%.o%s]?[%^][%);:/]*$"]		=	"%1, mon!",
	["(%a%a)[%s%p]-[>=]+[%-%s*]*%(%s*$"]		=	"%1, cha!",
	["(%a%a)[%s%p]-[;:>=8]+[%-%s*]*%(%s*$"]		=	"%1, jesum piece",
	["(%a%a)[%s%p]-[;:>=8]+[%-%s*]*[/\\]%s*$"]		=		"%1, jesum piece",
	["(%a%a)[%s%p]-[;:>=8]+[%-%s*]*%[%s*$"]		=	"%1, cha!",
	["(%a%a)[%s%p]*[tT][oO0%._][tT]%s*$"]		=	"%1, cha!",
	["(%a%a)[%s%p]-[><][_%.%o][><]$"]		=	"%1!",
	["(%a%a)[%s%p]-[._]%-[;,]*$"]			=	"%1%. Cha...",

	["^[._%-%^%s]*[oO0@][._%-%^][oO0@]"]	=	"Dis a big hex! ",
	["([%p%a]%a)[%s%p]*[._%-%^%s]*[oO0@][._%-%^][oO0@]$"]	=	"%1! Cha!",

	["^[tT][oO0%._][tT]%s+"]		=	"Don't make my eyewatah! ",
	["^[;:>%-=*]+%(%s*"]			=	"Cha! ",
	["^[;:>%-=*]+%[%s*"]			=	"Cho! ",

	["^[jJ]/?[kK]$"]			=	"I just jestah 'pon you",
	["^[sS]h?ure%s[tT]h?ing?%p*"]	=	"Mos' deff",

	["^[;:>=xX%-%s]*[%)DdbBpP%s]+$"]		=	"Ya, mon!",
	["^[;:>=xX%-%s]*[%)DdbBpP]+%s(%a%a)"]		=	"Ya, mon! %1",
	["^[;:>=xX%-*%s]+[oO]"]			=	"Cha! ",

--	Replace 'yall'
	["^[yY]'?[aA]'?[lL]+(%A)"]			=	"Unno you%1",
	["(%A)[yY]'?[aA]'?[lL]+(%A)"]			=	"%1unno you%2",
	["(%A)[yY]'?[aA]'?[lL]+$"]	=	"%1unno you",
	["^[yY]'?[aA]'?[lL]+$"]			=	"Unno you",

	["^[nN][oO]%s?shit"]	=	"Nuh true%? ",
	["[Gg][uo]+d%s?shit"]		=	"di lambsbread",
	["(%A)[tT][oO]+%s?[dD][aA][mMnN]+%s(%a)"]		=	"%1too %2",

	["^[bB]i[yao]*t?[cs]h(%A)"]	=	"Dat zutopong%1",
	["^[bB]i[yao]*t?[cs]he?s+(%A)"]	=	"Ginnals%1",
	["^[bB]i[yao]*t?[cs]h$"]		=	"Dat zutopeck!",
	["^[dD]a+[mn]+%s[yY]ou(.*)!?$"]		=	"Hex 'pon you%1!",

	["^[dD]a+[mn]+%s+[iI]%s"]		=	"Cha! I ",
	["^[dD]a+[mn]+$"]	=	"Kiss me neck...",


	["^[wW]t[fh]+%a*$"]		=	"rhaatid!",

	["^[wW]tf+%a*%s+"]	=	"rhaatid! ",
	["^[wW]t[fh]+%a*[^%a%d|]+"]	=	"rhaatid! ",
	["(%p)[wW]t[fh]+$"]		=	"%1 rhaatid!",
	["([%a%d])[%s!,.]+[wW]t[fh]+$"]		=	"%1, rhaatid!",
	["(%A)[wW]t[fh]+(%A)"]	=	"%1a what%2",


	["(%A)[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"nil",
	["^[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"nil",
	["(%A)[aA@][sz%$][sz%$]e?([sz]*)$"]	=	"nil",
	["^[aA@][sz%$][sz%$]e?([sz]*)$"]	=	"nil",

	["(%A)[aA@][sz%$][sz%$](e?[sz]*%A)"]	=	"%1rass%2",
	["^[aA@][sz%$][sz%$](e?[sz]*%A)"]	=	"Rass%1",
	["(%A)[aA@][sz%$][sz%$](e?[sz]*)$"]	=	"%1rass%2",
	["^[aA@][sz%$][sz%$](e?[sz]*)$"]	=	"Rass%1",

	["(%A)[fF]ine$"]	=	"%1irie",
	["^[fF]ine$"]	=	"Irie, mon",


--	Replace ZOMG, omfg, gawd, jeez, wtf, with various expressions
	["^omg%a*[^%a%d|?]+"]	=	"Cooyah! ",
	["^omg%a*%s"]		=	"Cooyah! ",
	["^omg%a+$"]		=	"Cooyah!",
	["^omg$"]	=	"Cooyah!",
	["(%A)omg%a+"]	=	"%1, kiss me neck!",
	["(%a)[%s!,.]+omg%f[%A]"]	=	"%1, kiss me neck!",
	["(%a)[%s!,.]+omg$"]	=	"%1, kiss me neck!",

	["^[gG]od%s([^dD])"]		=	"Cho! %1",
	["^[gG]od(%p)"]	=	"Cho%1",
	["^[gG]od$"]		=	"Cho!",
	["^[gGjJ]e+[szb]+e?u*s*[%s!,.]+(.*)"]	=	"Hopa, %1",

	["^[jJ]e+[szb]+e?u*s*$"]	=	"Hopa!",

	["^[cC]ra+p+(%A)"]	=	"Rhaatid%1",

	["^[gG]rr+%p*$"]	=	"Cha!",

	["(%A)[sS]hut%s[uU]p(%A)"]	=	"%1ease up%2",
	["^[sS]hut%s[uU]p[^%a%d|?]+"]		=	"Cover your mouth! ",
	["^[sS]hut%s[uU]p%s+"]		=	"Cover your mouth ",
	["(%A)[sS]hut%s[uU]p?$"]	=	"%1ease up",
	["^[sS]hut%s[uU]p$"]		=	"Cover you mouth",

	["^shit(%A)"]	=	"Bloodclot%1",
	["^shit$"]		=	"Kiss me neck!",

	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"Hex 'pon you!",

	["^[fF][aou]+c?k(%p)"]	=	"Cha%1",
	["^[fFmM][aou]+c?k$"]		=	"Eh chuta!",


	["[fF][aou]+w?c?ke?r"]		=	"bait",

	["^[gGnN][jJwW]%s[oO]n%s"]		=	"You mash up ",
	["^[gGnN][jJwW]%s(%a%a%a-)ing%s"]		=	"Dat was righteous job %1ing ",

	["^[bB][o0]+y+a+h*%A*[kK]asha+"]		=	"Booyah",

},
[7]={
	["(%A)[fF]u[cke]+d%s?(%a+)%sup"]	=	"%1vexed %2",
	["(%A)[fF]u[ck]+([ed]*)%s?up"]		=	"%1sheg %2 up",
	["(%A)[fF]u[ck]+%A*ups"]		=	"%1sheg%-ups",
	["(%A)[fF]u[cke]+d(%p*)$"]		=	"%1sheg up%2",

	["(%A)[fF]u[ck]+ing?%s?up"]		=	"%1sheggin up",
	["(%A)[sS]hitting%s?up"]		=	"%1sheggin up",

	["^[dD]on't%s[kK]now(%A)"]	=	"I don't know%1",
	["^[dD]on't%s[kK]now$"]	=	"I don't know",


	["^[nN]ice%s?[tT]ry$"]	=	"Righteous effort",
	["^[nN]ice%s?[tT]ry%p+$"]	=	"Respect, mon!",


	["^[nN]+a+[wh]*$"] = "Nuh tink so",
	["^[nN]+a+[wh]*%s"] = "Nuh, mon%. ",

	["^no$"]			=	"Nuh, mon",

	["^[yY][aAeE]+[hH]%s"]		=	"Ya, ",

--	["(%A)[mM][tT]$"]		=	"%1slip a' di tongue",
	["^[mM][tT](%p)"]		=	"Don't worry about that%1",
	["^[mM][tT]$"]			=	"Don't worry about that",

	["^[yY][oO][yYoO]*[^%a%d|?]+"]	=	"Yush, ",
	["^[yY][oO][yYoO]*$"]	=	"Yush!",

--	Replace woot, WOOOOOOT, w00t and WOOHAA
	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1tas'dingo!%2",
	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 Tas'dingo!",
	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"! Tas'dingo!",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]		=	"Tas'dingo%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]			=	"Tas'dingo! ",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"Tas'dingo, mon!",

	["^[gG]ood%s?[jJ]ob%p*$"]		=	"Respect!",
	["^[nN]ice%s?[jJ]ob%p*$"]		=	"You have the mojo!",
	["^[gG]ood%s?[wW]ork%p*$"]		=	"Big respect!",

	["%s[fF]or%s[tT]he%s[wW]in[^%a%d|?]+"]	=	" is massive, mon! ",
	["%s[fF]or%s[tT]he%s[wW]in$"]	=	" always mash up the house! ",

	["^[tT]ha?n?[zxc]s?(%A)"]		=	"Respect%1",
	["^[tT][yY][tTyY]*(%A*)$"]	=	"Respect%1",
	["^[tT]ha?n?[zxc]s?$"]		=	"Tanks",
	["^[tT][hn]+a[hnks]+$"]		=	"Respect",

	["^[gG]ood%s[gG]ame$"]		=	"Good game, mon.",
	["^[gG]ood%s[gG]ame(%A)"]	=	"nil",
--	["^[nNgG][fF]"]	=	"You mash up ",
--	["(%A)[nN][fF]$"]	=	"%1bashy fight",
	["^[bB][o0]+y+a+h*"]		=	"Booyah-kasha! ",

	["^[oO]+k+[iey]+%A*[dD]ok%a+"]	=	"Okee%-dokee",


	["^[yY]+[eE]+[aA]+[hH]*(%A)"]		=	"Ya, %1",
	["^[yY]+[eE]+[aA]+[hH]*$"]		=	"Ya, mon",
	["^[yY]+([.!]?)$"]			=	"Ya%1",


	["^[sS]h?ure(%A)"]	=	"Mos' def%1",
	["^[sS]h?ure$"]		=	"Mos' def!",
	["^[pP]r[aoub]*l+y$"]			=	"Mi tink so",

	["^[iI]t'?s%s[oO]kay(%A)"]	=	"Fit aan frock%1",
	["(%A)[iI]t'?s%s[oO]kay$"]	=	"%1all fruits ripe, mon",
	["(%A)[iI]t'?s%s[oO]kay(%A)"]	=	"%1all fruits ripe%2",
	["^[iI]t'?s%s[oO]kay$"]		=	"Everything cook aan curry.",

	["^[sS]h?[oO]*[rR]+[yY]$"]			=	"Sari, mon",

	["(%A)(%A)[rR]eal%s?[fF]ast(%p*)$"]		=	"nil",
	["(%A)[rR]eal%s?[qQ]uickl?y?(%p*)$"]		=	"%1quick as dat%2",
	["(%A)in%s?a%s?hur+y"]		=	"%1in big haste",
	["^[pP]u+l+$"]			=	"Bring a wicked ting, ya%?",
	["^[pP]u+l+%p+$"]			=	"Bring!",
	["^[pP]u+l+[ie]+n+g+$"]	=	"It be killing time!",
	["^[pP]u+l+[ie]+n+%p*$"]		=	"we be fighting!",

--	Replace 'ya' with 'yes' or 'you' depending on context.
	["^[yY]es$"]		=	"Ya, mon.",
	["^[yY][ea]+h?$"]	=	"Ya, mon.",
	["^[yY][aA]+[hH]?(%p)"]		=	"Ya%1",
	["^[yY][aA]%s[iI]%s"]		=	"Ya, mi ",
	["(%A)[yY][aA]$"]	=	"nil",
	["^[yY][aA]%s[yY]ou"]		=	"Ya, mon. You ",
	["^[yY][aA]%s[wW]e"]		=	"Ya, mon. wi ",
	["^[yY][aA]%s[tT][hH](%a)"]		=	"Ya, mon. Th%1",
	["^[yY][aA]+[hH][%s,]"]		=	"Ya, ",
	["^[yY][aA]+[hH]?$"]			=	"Ya, mon",
	["^[yY][aA]+%s[iI]t%s"]			=	"Ya, mon. It ",
	["^[yY][aAeE]+[hH]?(%p)"] = "nil",

	["[sS]ee+%s?[yY]ah?"]		=	"nil",

	["^[sS]ee%syou$"]		=	"Catchu laytah",


	["^[fF]ollow$"]	=	"Follow my backside",
	["^[fF]ollowin['g]?$"]	=	"I'll follow back of you",

	["^[bB]ye[^%d%a?]*$"]		=	"Bye-bye now!",
	["^[tT]ake%s?[cC]are[^%d%a?]*$"]		=	"Stay away from the Voodoo",


	["^[gG][lL](%A*)$"]			=	"Mash up, rude bwoy%1",



--	["[cC]hee+a*p(%A)"]		=	"skettle%1",

--	Replace 'coo' and 'k00l' and 'coolz' and 'koools'
	["([^%a|])[cCkK][oO0][oO0]+[lL]?[sz]*(%A)"]	=	"%1cool%2",
	["([^%a|])[cCkK][oO0][oO0]+[lL]?[sz]*$"]		=	"%1cool",
	["^[cCkK][oO0][oO0]+[lL]?[sz]*(%A)"]		=	"cool%1",
	["^[cCkK][oO0][oO0]+[lL]?[sz]*$"]		=	"Cool, mon",

--	Change 'sexy' 'sexier' 'sexiest' etc.
	["[sS]exa-[iey]+(%A)"]	=	"nil",
	["[sS]exa-[iey]+$"]	=	"nil",
	["[sS]exi(%a)"]	=	"nil",

--	Replace 'pimp' in limited circumstances
	["^[pP]imp%s(%a)"]	=	"Stoosh %1",
	["[sS]o+%s[pP]imp"]	=	"stoosh",

	["^[nN]ice(%A)"]	=	"Irie%1",
	["(%A)[nN]ice$"]	=	"%1irie, mon",
	["(%A)[nN]ice(%A)"]	=	"%1irie%2",
	["^[nN]ice$"]		=	"Irie, mon",

	["(%A)[uU]+b[ea]r(%A)"]	=	"%1massive%2",
	["^[uU]+b[ea]r(%A)"]		=	"Massive%1",
	["(%A)[uU]+b[ea]r$"]		=	"%1massive",
	["^[uU]+b[ea]r$"]			=	"Massive",

--	["^[iI][\"/;:`o]?[lL][lL]?(%A)"]			=	"I%1",
--	["(%p)%s?[iI][\"/;:`o]?[lL][lL]?%s"]		=	"%1 I ",
--	["[aA]nd%s?[iI][\"/;:`o]?[lL][lL]?%s"]	=	"an' I ",

	["^[dD]u+de%A(%a)"]	=	"Bwoy, %1",
	["(%A)[dD]u+de"]	=	"%1bwoy",
	["^[dD]u+de[%s!,.]+(%a)"]		=	"Bwoy, %1",
	["^[dD]u+de$"]	=	"Yow!",


	["^[iI]%s?[bB]et%s(%a%a)"]	=	"nil",
	["^[iI]%s?swa?ea?r%A"]	=	"Mi tink ",

	["^[iI]%s?[gG]uess(%A[^sS])"]	=	"nil",
	["(%A)[iI]%s?[gG]uess$"]	=	"nil",
	["^[iI]?%s?[gG]uess%s?[sS]o$"]	=	"nil",
	["^[mM]a+y*b+e%s(%a)"]		=	"nil",
	["^[mM]a+y*b+e%s?(%d)"]	=	"nil",
	["(%A)[bB]uncha(%A)"]	=	"%1plenty%2",
	["^[bB]uncha(%A)"]		=	"plenty%1",

	["^[tT]o+%s?[bB]a+d+"]		=	"nil",

--	Replace 'sup' and 'ssssuuuuupppp' etc
	["(%A)[wW]hat's%sup(%A)"]	=	"%1wha be happenin%2",
	["[%s!,.]+[wW]hat's%sup$"]		=	", wha be happenin, mon%?",
	["[wW]hat's%sup(%p)"]		=	"'ow you doin, mon%1",
	["[wW]hat's%sup%s"]		=	"'ow you doin, ",
	["[wW]hat's%sup$"]		=	"Big up, mon%!",

	["^[wW]ould%syou%s"]		=	"Chu ",

	["(%A)[gG]anking(%A)"]		=	"%1killing%2",
	["(%A)[gG]anking$"]		=	"%1killing",

	["(%A)[gG]ank(%A)"]	=	"%1kill%2",
	["^[gG]ank(%A)"]	=	"Kill%1",
	["(%A)[gG]ank$"]	=	"%1kill",
	["^[gG]ank$"]		=	"Kill dem dead!",
	["%f[%a][gG]o%s?[gGo][gGo%s%p]+%f[%A]"]	=	"make haste!",


	["(%A)[sS]+h?[au]*w+e+t+([^|%a][^|]*)$"]		=	"nil",

	["(%a)s%s[lL]ike%s(%a-)ble"]		=	"nil",
	["(%a)s%s[lL]ike%s(%a-)ous"]		=	"nil",

--	["[tT]oo%s?buf+"]			=	"tallowah",

--	Change WTB and wtb
--	["(.%A)[wWuU][tT][bB](%A)"]	=	"%1want to buy%2",
	["^%A*[WUL]t%s?b%s+(%u)"]			=	"I want to buy %1",
	["^%A*[wul]t%s?b%s+(%l)"]			=	"Somebody sell me %1",

	["^[wWuUlL]+%s?[tT]+%s?[sS]+|c(%a)"]	=	"Mi sellin |c%1",

	["^[fF4]yi%A"]		=	"So you know ",
	["(%a)[%s!,.]+[fF4]yi"]		=	"%1, juss so you know",

	["^[iI]+[nN]+[cC]+(%A)"]		=	"nil",
	["^[iI]+[nN]+[cC]+([%s!,.]+%a%a)"]		=	"Incoming %1",
	["^[iI]+[nN]+[cC]+[%s!,.]+$"]		=	"Big bad things are coming!",
	["(%A)[iI]+[nN]+[cC]+$"]		=	"%1coming dis way",
	["^[iI]+[nN]+[cC]+$"]		=	"Bad thing is coming",

	["[nN]inja$"]					=	"bandulu",
	["[aA]%s?[nN]inja(%A?[^lL])"]	=	"a tief%1",
	["[tT]he%s?[nN]inja(%A?[^lL])"]	=	"di bandulu%1",
	["[nN]injas"]					=	"tiefs",

	["([^aA])%s[nN]inja%s([^tTlL])"]	=	"%1 tief %2",

	["([^aA])%s[nN]inja%s[tT]h"]	=	"%1 tief th",

	["[nN]inja['e]?d"]				=	"tief",
	["[nN]inja?in['g]?"]			=	"tiefin",
	["[nN]inja%s?lootin['g]?"]		=	"tiefin",
	["[nN]inja%s?looter"]			=	"pyaka%-mon",
	["[nN]inja%s?looted"]			=	"tief",

	["^[rR][oO0][tT]?[fF][lL]%a*%p*$"]	=	"You kill me, mon!",

	["^[wW]a?ia?t$"]		=	"Stay, mon",


	["^[lL][oO0][lLoO0]+%p*$"]	=	"Bwahaha!",

	["^[sS]h?pam+(%a*%A)"]	=	"nil",
	["(%A)[sS]h?pam+(%a*%A)"]	=	"nil",
	["(%A)[sS]h?pam+(%a*)$"]	=	"nil",

	["^[sS]h?pam+%a*(%A)"]	=	"Labbah%-labbah%1",
	["(%A)[sS]h?pam+%a*(%A)"]	=	"%1jibbah%-jabbah%2",
	["(%A)[sS]h?pam+%a*$"]	=	"%1chatty%-chatty",

	["^[kK]ind%sof$"]	=	"nil",
	["^[sS]h?ort%sof$"]	=	"nil",
	["^[mM]an%A?[iI]%s"]			=	"nil",
	["^[mM]an%A?[yY]ou%s"]			=	"nil",
	["^[mM]an%A?[wW]e%s"]			=	"nil",
	["^[lL]oo+k+s%slike"]		=	"nil",

	["^[wW][eo]rd%p*$"]			=	"Respect!",

	["^[sS]h?e+r[ie]+[ou]+sl+y$"]		=	"Fi real",
	["^[sS]h?e+r[ie]+[ou]+sl+y(%A)"]	=	"nil",

	["(%d)[%s%-]?ish"]					=	"nil",

},

[8]={
	["^[eE]n[ou]+ght?%s[wW]ith(%A)"]	=	"Ease up with%1",

	["^[wW]a+y+%s?to+%sma[ny]+"]			=	"too plenty",
	["^[wW]a+y+%s?to+%smu[ch]+%s"]			=	"too plenty ",
	["s[%s!,.]+[wW]a+y+%s(%a-)er%s"]	=	"nil",

	["(%A)[sS]h?o+%s(%a%a-)ed$"]		=	"nil",

	["([fFlLhHwWnN]ea?)ther([ewsz%s%p])"]			=	"%1ddah%2",

},
[9]={
	["^(.+)$"]	= jahgrammar,
},
[12]= {
	["^(.+)$"]	=	Elo.WipeGrammarTags,
},
[14]={
	["(%A)[uU]nlike(l?y?%A)"]			=	"%1no like%2",

	["(%A)[nN]ever%s[mM]ind(%A)"]			=	"%1don't worry yourself%2",

	["(%A)[dD]uring(%A)"]			=	"%1when%2",

	["(%A)[cC]elebration[sz]*(%A)"]			=	"%1bashment%2",
	["(%A)[fF]estival[sz]*(%A)"]			=	"%1party%2",

	["(%A)[nN]o%s?[mM]atter(%A)"]		=	"%1no care%2",

	["(%A)[bB]last!?(%A)"]		=	"%1rhaatid!%2",
	["(%A)[bB]last%sit(%A)"]		=	"%1rhaatid%2",

	["(%A)[cC]ome%s[oO]n(%A)"]	=	"%1come off it%2",

	["(%A)[nN]o%s?one(%A)"]		=	"%1nobody%2",
	["(%A)[sS]ome%s?one(%A)"]		=	"%1somebody%2",

	["(%A)[aA]nybody(%A)"]		=	"%1somebody%2",
	["(%A)[aA]nyone(%A)"]		=	"%1somebody%2",

	["(%a[ey])one(%A)"]		=	"%1body%2",

	["[pP]iss%soff"]		=	"gwaay",
	["[pP]iss%s(%a+.-)%soff"]		=	"vex %1",

	["(%a[aieuo])ther([sz]*%A)"]			=	"%1ddah%2",


	["(%A)[eE]ve?ry"]		=	"%1hebry",

	["(%A)[sS]ome%s?thing[sz]*(%A)"]		=	"%1sintin%2",
	["(%A)[nN]o%s?thing[sz]*(%A)"]		=	"%1nuhtin%2",


	["(%A)[fF]u?c?k%s?[oO]ff+(%A)"]		=	"%1gwaay%2",

--	["([lLwWhHfF])eather"]		=	"%1eddah",
	["(%A[bB])rother(%A)"]		=	"%1reddah%2",
	["(%A)[fF]ellow([sz]*%A)"]		=	"%1breddah%2",
	["(%A)[pP]eople[sz]*(%A)"]		=	"%1bredren%2",
	["(%A)[lL]ad([sz]*%A)"]	=	"%1bwoy%2",

	["(%A)[nN]ot?%sa(%A)"]	=	"%1naa%2",

	["(%A)[mM]any%s?[mM]ore(%A)"]	=	"%1plenty more%2",


	["(%A)[sS]+h?w+ee+t+(%A)"]	=	"%1wicked%2",

	["(%A)[gG]reat(%A)"]	=	"%1massive%2",

	["(%A)[aA]w+e?some?(%A)"]		=	"%1massive%2",

	["(%A)[tT][ue]+s?day([sz]*%A)"]		=	"%1Chewsday%2",
	["(%A)[sS]h?at[eu]rday([sz]*%A)"]		=	"%1Sachaday%2",
	["(%A)[oO]n%s?[tT]op%s?[oO]f(%A)"]		=	"%1'ponna%2",
	["(%A)[oO]n%s?[tT]op%s([^oO]%a%a)"]		=	"%1'pon%2",

	["(%A)[oO]n%sa%s(%a%a)"]		=	"%1'pon a %2",
	["(%A)[oO]n%sthe%s([%a%d])"]		=	"%1'pon the %2",
	["(%A)[uU]pon(%A)"]		=	"%1'pon%2",

	["(%A)[lL]et's(%A%a%a)"]		=	"%1make wi%2",
	["(%A)[lL]et%s[mM][ei](%A)"]		=	"%1mi%2",

	["(%A)[bB]etween(%s)"]		=	"%1betwix%2",

	["(%A)[sS]h?e+r[ie]+[ou]+sl+y(%A)"]	=	"%1fi real%2",

	["(%A)[lL]et'?s?%s?[gG]o(%A)"]	=	"%1leggo%2",

--	Replace rdy and RDY with various forms for variety
	["(%A[rR])eady(%A)"]	=	"%1ipe%2",

	["(%A)[pP]refer(%A)"]	=	"%1faybah%2",

	["(%A%a%a-[aeiou])mily(%A)"]			=	"%1mbly%2",

	["(%A)[cC]hill%sout(%A)"]			=	"%1relax%2",

	["(%A)[lL]i[ae]r(%A)"]			=	"%1liad%2",

	["(%a)tif[ai]ca(%a%a)"]			=	"%1fitika%2",

	["(%A)[gG][eui]rl+[sz](%A)"]		=	"%1sistren%2",

	["(%A[dD])ad+[iey]*([sz]*%A)"]		=	"%1adda%2",

	["(%A[mM])[ou]m+[iey]*([sz]*%A)"]		=	"%1adda%2",
	["(%A[mM])other([sz]*%A)"]		=	"%1adda%2",

	["(%A)[rR]eally%s[oO]ften(%A)"]			=	"%1all di while%2",
	["(%A)[pP]retty%s[oO]ften(%A)"]			=	"%1all di while%2",
	["(%A)[aA]l+%s[tT]he%s[tT]ime(%A)"]			=	"%1all di while%2",
	["(%A)[tT]he%s[wW]hole%s[tT]ime(%A)"]			=	"%1all di while%2",


	["(%A)[cC]ongratulations%s([oO]n)"]		= "%1big up yourself %2",

	["(%A)[eE]xcept%s?[fF][oi]r?(%A)"]	=	"%1puttin away%2",

	["(%A)[sS]hove?(.)"]	=	"%1shoob%2",


	["(%A)[aA]%s?[bB]it(%A)"]	=	"%1a lickle%2",
	["(%A)[aA]%s?[lL]ittle%s?[bB]it(%A)"]	=	"%1a lilly bit%2",

	["(%A)[eE]ach%s?[oO]ther(%A)"]				=	"%1a one another%2",


	["(%A)[tT][vV](%A)"]	=	"%1tellie%2",

	["(%A[gG])ive%s[mM][ie](%A)"]			=	"%1immi%2",

	["(%A[lL]ook[^!?.,]-%f[%a])[aA]t(%A)"]			=	"%1'pon%2",
	["(%A)[wW]orse(%A)"]			=	"%1badder%2",
	["(%A)[wW]orst(%A)"]			=	"%1baddess%2",
	["(%A[nN]?)either(%A)"]				=	"%1eedah%2",
	["(%A[mMyY])outh([sz]*%A)"]	=	"%1out'%2",

	["(%A)[fF]amous(%A)"]			=	"%1massive%2",
	["(%A)[pP]roperly(%A)"]			=	"%1right%2",

	["(%A)[iI]n%s[sS]earch%s[oO]f(%A)"]			=	"%1mi a look fi%2",

	["(%A)[fF]or%s[aA]%s"]			=	"%1fi ",
	["(%A[iI])n%s?[tT]he(%A)"]			=	"%1nna%2",

	["(%A)[rR]ight%s?[nN]ext%s?to(%A)"]			=	"%1deh 'bout%2",

	["(%A)[aA]ll%s[rR]ight(%A)"]			=	"%1awright%2",

	["(%A[fF][oi]r?%s[mM]e)(%A*)$"]			=	"%1 nuh%2",



	["(%A)[wW]ithin(%A)"]			=	"%1in%2",

},
[15]={

	["(%A)[sS]omebody[sz]*(%A)"]		=	"%1smaadi%2",
	["(%A)[sS]omeone[sz]*(%A)"]		=	"%1smaadi%2",



	["(%A)[cC]ongratulations(%A)"]		= "%1big up yourself, %2",


	["(%A[rR])e([sfp][pl]*[aeiou]%a%a+)"]		= "%1i%2",

	["([%s%pnN][oOeE])ver"]				=	"%1bah",
	["(%A)[bB]oth(%A)"]				=	"%1bwot%2",

	["(%A[bB]red)dah[sz](%A)"]		=	"%1ren%2",
	["(%A[sS]ist)ah[sz](%A)"]		=	"%1ren%2",

	["(%A)[nN]ot(%A)"]	=	"%1no%2",

	["(%A)[eE]ach(%A)"]				=	"%1a one%2",

	["([%s%pn])[oO]ther([sz]*%A)"]		=	"%1uddah%2",

	["(%A[hH])ave(%A)"]			=	"%1ab%2",
	["([gGsS])ive(%A)"]			=	"%1ib%2",

	["([fFrR])ive(%A)"]			=	"%1aib%2",

	["(%A)[aA]ll%s[oOa][f'](%s%a%a)"]		=	"%1di walla%2",
--	GRAMMAR
	["(%A[iI])n(%A)"]			=	"%1nna%2",
	["(%A[iI])nto(%A)"]			=	"%1nna%2",
	["(%A[iI])nside(%A%a)"]			=	"%1nna%2",
	["(%A[iI])nna%sa%s"]			=	"%1nna ",


	["(%A)[wW]hat?%s?[eE]v[ae][hr](%A)"]				=	"%1wha'ebah%2",
	["(%A)[wW]hen%s?[eE]v[ae][hr](%A)"]				=	"%1whenebah%-time%2",
	["(%A)[aA]ny%s?[tT]imes?(%A)"]				=	"%1whenebah%-time%2",

	["(%A)[oO]ften(%A)"]				=	"%1often%-time%2",


--	["(%a%a)th([aeou]r%a*%A)"]			=	"%1dd%2",


	["(%A[dD])o%s?it(%A)"]	=	"%1weet%2",

	["(%A[gGdD])oin[g']?([^t%d%a])"]	=	"%1ween%2",


	["(%A)[mM]any%s(%a%a-)[sz](%A)"]			=	"%1plenty %2%3",

--	["(%A)[tT]o%s?[dD]anc[ie](%A)"]		=	"%1to drop legs%2",
	["(%A)[mM]ess(%a*)%s[wW]ith?(%A)"]		=	"%1romp%2 wit%3",
	["(%A)[mM]aile?d?%sit(%A)"]		=	"%1post it%2",
	["(%A)[mM]aile?d?%s[tT]he(%A)"]		=	"%1post the%2",
	["(%A)[mM]ailbox(%A)"]		=	"%1possbox%2",

	["(%A)[vV]en?dn?[eoa]r(%a*%A)"]	=	"%1higglah%2",
	["(%A)[yY]+e+s+(%A)"]		=	"%1ya%2",

	["(%A[cC]heck%s[^iI%s%d%p].-)out(%A)"]			=	"%1deep%2",
	["(%A[cC]heck%s[iI]t.-)%sout?(%A)"]			=	"%1%2",

	["(%A)th?(r[uiae]%a+)"]			=	"%1ch%2",
	["(%A)Th?(r[uiae]%a+)"]			=	"%1Ch%2",

	["[tT]hough(%A)"]			=	"dough%1",
	["(%A)[wW]ith"]			=	"%1wid",


	["(%A)[eE]xcept%s?[fF]or(%A)"]	=	"%1puttin away%2",

	["(%A[wW])hat(%A)"]			=	"%1ha%2",


	["([kKbBrRgGdDsShHvV])ill(s?%A)"]			=	"%1eel%2",

	["(%A)[hH]ate([sz]*%A)"]			=	"%1dread%2",
	["(%A)[bB]ecause(%A)"]	=	"%1'caaz%2",


	["(%A)[tT]r[ou]+ble([sdz]*%A)"]			=	"%1chobble%2",
	["(%A)[sS]+h?tu+p+i+d+(%a*%A)"]			=	"%1chupid%2",

	["([^a][mM])an(%A)"]			=	"%1on%2",
--	["(%A)[sS]h?ince(%A)"]			=	"%1fram%2",
	["([lbmpcf][eyi])st([^s])"]			=	"%1ss%2",
	["([lbmpcf]a)([fs])t([^s])"]			=	"%1a%2%3",
	["([mMdgbjJ])ust(%A)"]			=	"%1uss%2",
	["(%A)[aA]%s?[lL]+ot(%A)"]	=	"%1whole heap%2",

	["(%A)[iI]([^%d%a'.])"]	=	"%1mi%2",
	["(%A[mMwW])e([%s%p])"]	=	"%1i%2",


	["(%A[aA])nd([%s%p])"]			=	"%1an%2",
	["(%A)[aA]bout(%A)"]			=	"%1'bout%2",

	["(%A)[aA]gainst(%A)"]			=	"%1'gainst%2",

	["(%A)[oO]f(%A)"]			=	"%1a'%2",
--	["(%a%a[mgylbfthdcnkr])ing([%s=.,!?/\"\\><])"]		=	"%1in'%2",
	["(%a%a[mgylbfthdcnkrw])ing([sz]*%A)"]		=	"%1in~%2",

	["(%A[yY]+)e+s+(%A)"]	=	"%1a%2",

	["(%A)[tT]his(%A)"]			=	"%1dis%2",
	["(%A)[tT]he([mn]%A)"]			=	"%1de%2",
	["(%A)the(%A)"]			=	"%1di%2",
	["(%A)The(%A)"]			=	"%1Di%2",
	["(%A)[tT]he[iy]r?(%A)"]			=	"%1dem%2",
	["(%A)[tT]h?eh?re+(%A)"]			=	"%1deh%2",
	["(%A)[tT]hese(%A)"]			=	"%1dis%2",
	["(%A)[tT]hose(%A)"]		=	"%1dem%2",
	["(%A)[tT]ha([tn]%A)"]			=	"%1da%2",
	["(%A)[tT]here?(%A)"]	=	"%1deh%2",
	["(%A[wW])here(%A)"]			=	"%1heh%2",

--	Some jah verbs come from English past tense
	["(%A)[bB]reak(%A)"]		=	"%1bruk%2",
	["(%A)[lL]ose(%A)"]		=	"%1loss%2",
	["(%A)[gG]o%s[aA]way(%A)"]		=	"%1gwey%2",
	["(%A)[gG]o%s[oO]n(%A)"]		=	"%1gwaan%2",
	["(%A)[mM]arry(%A)"]		=	"%1married%2",

--	Others come from noun forms
	["(%A)[cC]ompare(%A)"]		=	"%1camparison%2",
	["(%A)[cC]ompel(%A)"]		=	"%1compulsion%2",
	["(%A)[iI]ntend(%A)"]		=	"%1intention%2",
	["(%A)[tT]ake%s[aA]dvantage(%A)"]		=	"%1advantage%2",

	["(%A)[aA]ct%s[lL]ike(%A)"]		=	"%1gwaan like%2",
	["(%A)[aA]rrive(%A)"]		=	"%1reach%2",
	["(%A)[dD]epart(%A)"]		=	"%1leff%2",
	["(%A)[sS]tink%a*(%A)"]		=	"%1rank%2",

	["(%A)[cC]onsider(%A)"]		=	"%1look 'pon%2",
	["(%A)[mM]is%A?behave(%A)"]		=	"%1gwaan bad%2",

	["(%A)[lL]augh%s[aA]t(%A)"]		=	"%1laugh after%2",


	["(%A)[gG][eo]t%s?[hH]ere(%A)"]		=	"%1come here%2",
	["(%A)[gG][eo]t%s?[tT]here(%A)"]		=	"%1go there%2",


	["(%A)[fF]ail(%A)"]		=	"%1flop%2",
	["(%A)[fF]ailure(%A)"]		=	"%1flop%2",

	["(%A)[lL]eave(%A)"]		=	"%1leff%2",
	["(%A)[cC]over(%A)"]		=	"%1kibah%2",
	["(%A)[sS]ay(%A)"]		=	"%1seh%2",
	["(%A)[lL]is[ts]en%s[uU]p(%A)"]		=	"%1hear mi now%2",

	["(%A)[fF]or(%A)"]			=	"%1fi%2",
	["(%A)[bB]oy"]			=	"%1bwoy",

	["(%A)[aA]ll(%A%a)"]			=	"%1uol%2",
	["(%A[aA])l+([rtsm]%a+%A)"]		=	"%1w%2",

	["([^%d%p%st]%A)[rR]eally(%A%a%a%a)"]		=	"%1well%2",


	["(%a[aieounr])dle([sz]*%A)"]			=	"%1gle%2",
	["(%a[aieou])ddle([sz]*%A)"]			=	"%1ggle%2",

	["(%a[aieour])ttle"]			=	"%1ckle",

	["(%a%a)th([aeiulrfs][^%p%s%dr]%a*%A)"]			=	"%1t%2",

	["([lLbBsSrRtThHdD])ater(%A)"]			=	"%1aytah%2",
	["([mMvV])a([jp])[oe]r([sz]*%A)"]			=	"%1ay%2ah%3",

	["([hpbwdsgm])ire(%A)"]			=	"%1iyah~%2",
	["([fF])ire"]			=	"%1iyah",

	["(%A[rR])esurrector[sz]*(%A)"]	=	"%1ezzah%-mon%2",
	["(%A)[lL]eader[sz]*(%A)"]	=	"%1boss%-mon%2",

--	["(%A)[uU]ndead(%A)"]	=	"%1dead%-mon%2",

	["(%a[dt])['h]?%s[yY]our?(%A)"]			=	"%1 chu%2",
	["([wW]ha)t?%s?[dD]o%s?[yY]our?(%A)"]			=	"%1 chu%2",

	["([rfbpjmhgtdck][aou])([fs])t(%A)"]			=	"%1%2%2%3",

	["([^aeiou%d%s][ur])l[dt](%A)"]			=	"%1hl~%2",

	["([^aeiou%d%s])ol[dt](%A)"]			=	"%1uol~%2",

	["([^abeiou%d%s]i)l[dt]([^'%a])"]			=	"%1le~%2",

	["([rRlLgGbB])ong(%A)"]			=	"%1aang%2",

	["([^abeiou%d%s][ae])l[dt](%A)"]			=	"%1hl%2",

	["(%a%ap)th([sz]*%A)"]			=	"%1p%2",
	["(%a%as)p[sz]*(%A)"]			=	"%1s%2",

	["(%A[oO])nly%s*(%d)"]			=	"%1ngle %2",

	["([tT]e)chn([oi])"]			=	"%1km%2",

	["(%A)se(e[^r])"]			=	"%1ze%2",
	["(%A)Se(e[^r])"]			=	"%1Ze%2",

	["(%A[fF])riend"]			=	"%1ren'",

	["([aAeEiIoOuU])sk"]	=	"%1x",

	["(%A[fF])rom(%A)"]	=	"%1ram%2",

	["(%A)[sS]hr(%a+)"]	=	"%1sw%2",

	["(%A)[dD]efin%a*(%A)"]	=	"%1deff%2",

	["(%A)[dD]espera%a*(%A)"]	=	"%1dess%2",

	["(%A)[sS]he'?s+(%A)"]	=	"%1her%2",

	["(%A)[mM]y(%A)"]	=	"%1mi%2",

	["(%A)[yY]our?(%A)"]	=	"%1yu%2",

	["(%A)[hH]e(%A)"]	=	"%1him%2",
	["(%A)[hH]e'?s+(%A)"]	=	"%1him%2",

	["(%a[^hH%p%d%s])ere(%A)"]			=	"%1eh%2",


	["(%A)[tT]ogether(%A)"]		=	"%1tugeddah%2",

	["([mMfFbBhHwWsS])[ao]([rl])%2ow(%A)"]		=	"%1aa%2a%3",
	["(%A)[tT]oday(%A)"]		=	"%1today%-day%2",

	["[!?.]+%smon%f[%A]"]			=	", mon",

--	Occasionally drop the initial H
	["([%a.!,;:][^%a%d|'~])[hH]([aeiuo][^vfbha%p%s%d][^vfbha%p%s%d][^vfbha%p%s%d])"]		=	"%1'%2",

	["^%s[hH]([aeiuo][^vfbha%p%s%d][^vfbha%p%s%d][^vfbha%p%s%d])"]		=	"'%1",

	["(%A)[hH]ow(%A)"]		=	"%1'ow%2",

	["(%A)[eE]at(%A)"]		=	"%1heat%2",

	["(%A)[rR]eally(%A*)$"]		=	"%1fi real%2",
	["(%A)[rR]eally%?"]		=	"%1fi real%?",
	["(%A)[cC]an%s[nN]ot?(%A)"]	=	"%1can't%2",

	["(%A)[gG]ood%s[mM]easure(%A)"]	=	"%1good mixup%2",
	["(%A)[tT]hrough(%A)"]	=	"%1chru%2",

	["^(%A+)[wW]ill%s[dD]o(%A+)$"]		= "%1mi do dat%2",

	["(%a[rl])ves(%A)"]	=	"%1f%2",
	["(%A[sS])taves(%A)"]	=	"%1taff%2",


},
[16]={
	["(%A%a+)body[sz]*(%A)"]		=	"%1baadi%2",

	["(%a%A)[hH]ere(%A)"]	=	"%1yah%2",
	["(%A)[rR]oughly(%A)"]				=	"%1deh 'bout%2",

	["(%a%a%a-)ects?(%A)"]		= "%1ek~%2",

	["(%a%a%a)th([iy]?%A)"]			=	"%1t%2",
	["(%A%a%a)th(%A)"]			=	"%1t'%2",

	["(%a%a[^%d%s%paieouc])[aoe]r([sz]*%A)"]			=	"%1ah%2",

	["(%A)[nN]ot?(%A)"]			=	"%1nuh%2",

--	No plurals or possessives
	["(%a%a%a[^%d%s%psiyvx]e)s(%A)"]	=	"%1%2",
	["(%a%a%a[^%d%s%pkaeioupsy])s(%A)"]	=	"%1%2",
	["(%A[iI]t)s(%A)"]	=	"%1%2",

	["(%a%a)[%s%p]+[oO]?[kK]+%??$"]		=	"%1, ya%?",
	["(%a%a)[%s%p]+[aAwW]*[rR]+ight+%??$"]		=	"%1, ya%?",

	["(%s[cCgGkK])(a[rn])"]	=	"%1y%2",

--	Occasionally add an initial H to long words that start with 'e'
	["([^%a%d|'~])e([clnmstxcq]%a%a[^%s%p%dn][^%s%p%d]+)"]		=	"%1he%2",
	["([^%a%d|'~])E([clnmstxcq]%a%a[^%s%p%dn][^%s%p%d]+)"]		=	"%1He%2",

--	Occasionally drop ending 'd'
	["([^%a%d|'~]%a%a%a%a-n)d([^%a%d'?~])"]		=	"%1'%2",

	["%f[%ah]([tT])h([aeiou]%a%a+%A)"]			=	"%1%2",
	["(%s)T(hr%a%a%a+[^%a%d'?~])"]			=	"%1C%2",
	["(%s)t(hr%a%a%a+[^%a%d'?~])"]			=	"%1c%2",

--	["(%a%a%a%a-)ation"]			=	"%1ieshan",
	["([mMfFlLgGdDbBnN])ore(%A)"]			=	"%1uor%2",



	["(%s)[sS]t([aeiou]%a%a%a+[^%a%d'?~])"]			=	"%1't%2",

	["(%s[sS])t(r%a%a%a+[^%a%d'?~])"]			=	"%1ch%2",

	["(%s)[sS]p([aaeiou]%a%a%a+[^%a%d'?~])"]			=	"%1'p%2",


	["([wWpPnNkKtTgGfFbBhH])[ua][uaie]+r([sbdklmnt])"]			=	"%1aa%2",
	["([wWpPnNkKtTgGfFbBhH])rau([sbdklmnt])"]			=	"%1raa%2",
	["([wWpPnNtTkKgGfFbBhH])[aeui]r([tdkgpb])"]					=	"%1aa%2",
--	["([wWpPnNtTkKgGfFbBhH])or([tdkgpb])"]					=	"%1uo%2",

	["(%A[wWhHgGdDtT])au?nt(%A)"]			=	"%1aan%2",

	["(%a)[oae]rd(%A)"]			=	"%1aad%2",

	["^(%A%a+%s)[dD]o(%A+)$"]		= "%1do dat%2",
	["^(%A%a+%s)[wW]ill(%A+)$"]		= "%1go do dat%2",


	["(%a%a)'s(%A)"]			=	"%1%2",

--	["(%A)[bB]es[ts](%A)"]	=	"%1goodest%2",
--	["(%A)[bB]es[ts](%A)"]	=	"%1goodess%2",

	["^[aA]n(%A)"]		=	"One%1",

	["([mM])i%s[wW]ill%s(%a%a)"]		=	"%1i %2",
	[",*%s[yY]ou%s[kK]now[!?.]*$"]			=	", zeen?",

	["(%A)a('?)%sa'?(%A)"]			=	"%1a%2%3",

},
}


Elo.RaceFilter[4]={
[1]={
},
[2]={
	["(%A)[dD]'?o+h+%A"]	=	"%1bah! ",
	["(%A)[dD]'?u+h+%A"]	=	"%1it's clear as crystal! ",
	["(%A)[gG][ae]+h+%A"]		=	"%1ghastly! ",
	["(%A)[mM]y%s?[gG][ao]+w?d(%A)"]		=	"%1by the shadow! %2",
	["(%A)[tT]hank%s?[gG][ao]+w?d(%A)"]		=	"%1thank the shadow%2",
	["(%A)[rR]+a+w+r+(%A)"]		=	"%1hear my shriek! %2",

	["(%A)[lL]ow?b[iey]+([sz]*%A)"]		=	"%1lowlife%2",

	["(%A[gG][eo]t.-)%s[dD]runk(*%A)"]		=	"%1 blootered%2",


	["(%A)[sS]h?o+%sfucking(%A)"]	=	"%1so bloody%2",
	["(%A)[yY]ou%sfucking(%A)"]	=	"%1you bleedin'%2",
	["(%A)[iI]%sfucking(%A)"]		=	"%1I bloody%2",
	["(%A)[tT]hat%sfucking(%A)"]	=	"%1that maggot%-ridden%2",
	["(%A)[tT]h([ieo])se?%sfucking(%A)"]	=	"%1th%2 worm%-ridden%3",
	["(%A)[tT]hat'?s%sfucking(%A)"]	=	"%1that's bloody%2",
	["(%A)fucking%s(%a%a-ing%A)"]	=	"%1%2",

	["(%A)[iI]sn'?t%s?it(%A)"]	=	"%1innit%2",

	["(%A)[iI]sn'?t%s?he(%A)"]	=	"%1inne%2",

	["(%A)[hH]im%sself(%A)"]	=	"%1hisself%2",
	["(%A)[mM]y%s?self(%A)"]	=	"%1meself%2",

},
[3]={
	["(%A)[lL]ike%s[cC]raz+y+(%A)"]	=	"%1with a vengeance%2",

	["(%A)[nN]ice%s?[tT]ry(%A)"]	=	"%1impressive%2",
	["(%A)[nN]ice%s?1([%s%p])"]	=	"%1impressive%2",


	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1Priceless!%2",
	["(%A)[wW]hole%A*[fFmM]r?[aeiu]+[gck]?[gk]+[ie]n['g]*(%A%a)"]	=	"%1whole stinking%2",
},
[5]={
	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"At long last! Level %1 is mine!",
	["(%A)[mM]y%s[fF]r?[aeiu]+[gck]?[gk]+[ie]n['g]?%s?"]	=	"%1my worm%-ridden ",
	["(%A)[tT]h(%a%a?)%s[fF]r?[aeiu]+[gck]?[gk]+[ie]n['g]?%s?"]	=	"%1th%2 bleedin' ",
},
[6]={
	["(%a%a)[%s%p]-[>=]+[%-%s*]*%(%s*$"]		=	"%1, and my blood runs chill",
	["(%a%a)[%s%p]+[QtT][oO0%._]?[QtT]%s*$"]		=	"%1, if only I had tears to shed...",
	["(%a%a)[%s%p]-[._]%-[;,]*$"]			=	"%1. Wake me when it's over",

	["^[bB]i[yao]*t?[cs]h$"]		=	"Stupid git!",
	["^[bB]i[yao]*t?[cs]he?[sz]$"]	=	"Fools!",

	["(%A)[sS]hut%s[uU]p(%A)"]	=	"%1shut that festering gob%2",
	["^[sS]hut%s[uU]p[^%a%d|?]+"]		=	"Stow it ",
	["^[sS]hut%s[uU]p%s+"]		=	"Silence, ",
	["(%A)[sS]hut%s[uU]p?$"]	=	"%1stop that hideous tongue%-wagging",
	["^[sS]hut%s[uU]p$"]		=	"Shut your stinking trap!",

--	Replace ZOMG, omfg, gawd, jeez, wtf, with various archaic expressions
	["^omg%a*[^%a%d|?]+"]	=	"I'm aghast! ",
	["^omg%a*%s"]		=	"What? ",
	["^omg$"]	=	"I'm mortified!",
	["(%A)omg%a+"]	=	"%1!",
	["^omg%a+$"]	=	"Utterly mortifying!",
	["(%a)[%s!,.]+omg%f[%A]"]	=	"%1, by the shadow's veil!",
	["(%a)[%s!,.]+omg$"]	=	"%1%. Why, I'm aghast!",

	["^[gG]od%s([^dD])"]		=	"Alas! %1",
	["^[gG]od(%p)"]	=	"By the shadow's veil%1",
	["^[gG]od$"]		=	"For pity's sake!",
	["^[gGjJ]e+[szb]+e?u*s*[%s!,.]+(.*)"]	=	"By the twilight, %1",
	["^[gG]e+[szb]+e?u*s*$"]	=	"Oh, break my bones!",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"By my last tooth!",

	["^[cC]hrist(%A)"]	=	"Bah!%1",

	["^[wW]tf+%a*%s+"]	=	"Ghastly! ",
	["^[wW]t[fh]+%a*[^%a%d|]+"]	=	"Insufferable! ",
	["(%p)[wW]t[fh]+$"]		=	"%1 break my bones!",
	["([%a%d])[%s!,.]+[wW]t[fh]+$"]		=	"%1, the horror!",
	["(%A)[wW]t[fh]+(%A)"]	=	"%1what in Undeath%2",
	["^[wW]t[fh]+%a*$"]		=	"Madness!",

	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"May the Lich King take you!",
	["^[fF]uck+[%s%p]+[iI]%s"]		=	"Damn me for a fool! I ",


	["(%A)[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"nil",
	["^[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"nil",
	["(%A)[aA@][sz%$][sz%$]e?([sz]*)$"]	=	"nil",
	["^[aA@][sz%$][sz%$]e?([sz]*)$"]	=	"nil",

	["(%A)[aA@][sz%$][sz%$](e?[sz]*%A)"]	=	"%1carcass%2",
	["^[aA@][sz%$][sz%$](e?[sz]*%A)"]	=	"Carcass%1",
	["(%A)[aA@][sz%$][sz%$](e?[sz]*)$"]	=	"%1carcass%2",
	["^[aA@][sz%$][sz%$](e?[sz]*)$"]	=	"Carcass%1",

	["^[sS]hut%s[uU]p$"]		=	"Shut your festering hole!",

	["^[fF][aou]+c?k(%p)"]	=	"Flies and maggots%1",
--	["^[fFmM][aou]+c?k%s([^tT])"]	=	"Curses %1",
	["^[fFmM][aou]+c?k$"]		=	"Is there no end to this torment%?",
	["^[fFmM]ucking%s?(%a%a%a%a-)[sz]$"]		=	"Maggot%-infested %1s!",
	["^[fFmM]ucking%s?(%a%a%a%a-)[sz](%A)"]		=	"Worm%-ridden %1s%2",
	["^[dD]a+n?m+n*%s(%a%a%a%a-)[sz]$"]		=	"Such feculent, hideous %1s!",
	["^[dD]a+n?m+n*%s(%a%a%a%a-)[sz](%A)"]		=	"Putrid, worm%-ridden %1s%2",

	["[fF][aou]+w?c?ke?r"]		=	"blighter",

},
[7]={
	["^[bB]ye[^%d%a?]*$"]		=	"Happy entrails!",
	["^[tT]ake%s?[cC]are[^%d%a?]*$"]		=	"Embrace the shadow!",

	["^[gG]ood%s?[wW]ork%p*$"]		=	"Bloody brilliant!",
	["^[gG]ood%s?[jJ]ob%p*$"]		=	"Commendable work!",
	["^[gG]ood%s[gG]ame$"]		=	"A fine game it was.",

	["^[nN][jJ]$"]		=	"For Lordaeron!",
	["^[sS]ee%syou$"]	=	"Dark Lady watch over you",


	["^[gG][lL](%A*)$"]			=	"Remember! Patience...discipline%1",

	["^[tT][yY][tTyY]*(%A*)$"]	=	"Thanks a lot%1",
	["^[tT]ha?n?[zxc]s?$"]		=	"Much obliged",

	["^[sS]+h?[au]*w+e+t+$"]	=	"Wicked!",

	["^[iI]?[dDfF][ou]+n+o+$"]	=	"Who knows?",


--	Replace woot, WOOOOOOT, w00t and WOOHAA
	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1huzzah%2",
	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 wicked!",
	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"! For Sylvanas!",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]		=	"Victory for Sylvanas%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]			=	"Victory for Sylvanas! ",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"Power to the Forsaken! ",
	["^[bB][o0]+y+a+h*"]				=	"Death!",

	["^[lL][oO0][lLoO0]+%p*$"]	=	"Mwahaha!",



--	Replace 'coo' and 'k00l' and 'coolz' and 'koools'
--	["([^%a|])[cCkK][oO0][oO0]+[lL]?[sz]*(%A)"]	=	"%1chilling%2",
--	["([^%a|])[cCkK][oO0][oO0]+[lL]?[sz]*$"]		=	"%1chilling",
--	["^[cCkK][oO0][oO0]+[lL]?[sz]*(%A)"]		=	"chilling%1",
	["^[cCkK][oO0][oO0]+[lL]?[sz]*$"]		=	"How chilling",

	["^[dD]a+n?m+n*%s[tT]hat(%A%a%a-[^s]%A)"]		=	"That ghastly %1",
	["^[dD]a+n?m+n*%s[tT]hat(%A%a+[^s])$"]		=	"That nasty, despicable %1",

},
[8]={

},
[14]={
	["^.*$"]		= Elo.ContractHave,

	["^[iI]sn'?t(%A)"]	=	"ain't%1",



--	Replace 'guys' with 'blokes' and 'gents'
	["(%A)[fF]ellow([sz]*%A)"]	=	"%1bloke%2",

	["(%A)[lL]ads(%A)"]	=	"%1gents%2",

--	["(%A)[cC]ongratulations%s([oO]n%s)"]		= "%1congratulations %2",

--	Refer to self as the object in plural
--	["(%A)[mM]e(%A)"]	=	"%1us%2",
--	["(%A)[mM]y(%A)"]	=	"%1our%2",

--	Rampant hiss on the non-voiced 'S' when shouting
	["(%a%a[ptkchfs])s([^s].-!)"]	=	"%1sss%2",

	["(%A)[gG]ood%s?[nN]i[gh]*t+e?(%A)"]	=	"%1rest in peace%2",


	["^%s?[iI]t%swas%s(%a%a)"]	=	" 'Twas %1",
	["^%s?[iI]t%swasn't%s(%a%a)"]	=	" 'Twasn't %1",
	["^%s?[iI]ts%sthe%s(%a%a)"]	=	" 'Tis the %1",
	["^%s?[iI]ts%sa%s(%a%a)"]	=	" 'Tis a %1",

--	["(%A)[tT][vV](%A)"]	=	"%1television%2",

	["([^%d%s%pf]%A)[oO]nly(%s%d)"]	=	"%1a mere%2",

--	["(%A)[wW]ant%s[tT]o(%A)"]	=	"%1wish to%2",
	["(%A)[wW]ants%s[tT]o(%A)"]	=	"%1wishes to%2",
	["(%A)[aA]%s?[lL]ittle%s?[bB]it(%A)"]	=	"%1a touch%2",
	["(%A)[aA]%s?[lL]ittle%s?[wW]hile(%A)"]	=	"%1a spell%2",

	["(%A)[aA]%s?[lL]ittle(%A)"]	=	"%1a trifle%2",
	["(%A)[aA]%s?[bB]it(%A)"]	=	"%1a speck%2",

},
[15]={
	["(%A)[cC]ongratulations(%A)"]			= "%1impressive!%2",



	["(%A)[mM]on[ey]+(%A)"]	=	"%1coin%2",

	["(%A)[iI]'?m%s?not(%A.-)!$"]	=	"%1I ain't%2",
	["(%A)[iI]s%s?not(%A.-)!$"]	=	"%1ain't%2",
	["(%a%a)'?s%s?not(%A.-)!$"]	=	"%1 ain't%2",
	["(%a%a)'?re%s?not(%A.-)!$"]	=	"%1 ain't%2",

--	Light hiss on the non-voiced 'S' for the undead
	["^%s*[sS]([kwhau]%a%a%a%a+%A)"]	=	"Ss%1",
	["(.%A[sS])([ciopmt]%a%a+%A)"]	=	"%1s%2",
	["(%a%a[tpckh'])([sS][epth]?)$"]	=	"%1ss%2",

},
[18]={
	["^([sSwW][oe]%a*%A+%a+%A+%a.-%a%a[^%p%s%dn])?$"]	=	"%1, then%?",

},
[19]={
	["^[sS]hould%s[iI]%s(%a%a%a%a.-)%?$"]		=	"Ought I to %1",
	["^[sS]hould%s[wW]e%s(%a%a%a%a.-)%?$"]		=	"Ought we to %1",
},
}

--[[
Keep your wits about you
Sho rel aran
We will have justice
Hold your head high
Stay the course
Time is of the essence
Glory to the sindorei
we will perservere
Victory lies ahead
What business hav eyou?
Anaria shola
remember the sunwell
the reckoning is at hand
our enemies will fall
the dark times will pass
the eternal sun guides us
be ready for anything
death to all who oppose us



--]]

Elo.RaceFilter[5]={
[1]={
},
[2]={
},
[3]={
	["(%A)[wW]t[fh]+%s*[yY]ou(%s%a%a%a-ing?%A)"]	=	"%1what under the sun are you%2",
	["(%A)[wW]t[fh]+%s*[iI]s(%A)"]	=	"%1what in the sun's light is%2",
	["(%A)[wW]t[fh]+%s*[aA]?r?e(%A)"]	=	"%1what in magic's name are%2",
	["(%A)[wW]t[fh]+%s*[wW]a[sd]+(%A)"]	=	"%1what under the sun was%2",
	["(%A)[wW]t[fh]+%s*[wW]ere?(%A)"]	=	"%1what in Anasterian's name were%2",
	["(%A)[wW]t[fh]+%s*[wW]il+(%A)"]	=	"%1what under the sun's gaze will%2",
	["(%A)[wW]t[fh]+%s*([dD]o[es]*%A)"]	=	"%1what in the name of Kael'thas %2",
	["(%A)[wW]t[fh]+%s*[dD]id?(%A)"]	=	"%1what, pray tell, did%2",

	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1surely you jest!%2",

--	["(%A)[nN]ice%s?[tT]ry(%A)"]	=	"%1a noble effort%2",
--	["(%A)[nN]ice%s?1([%s%p])"]	=	"%1a fine display%2",

	["(%A)[lL]ike%s[cC]raz+y+(%A)"]	=	"%1with great zeal%2",

},
[4]={
},
[5]={
	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"Praise the sun! Level %1 is mine...",
},
[6]={
	["^[cC]hrist(%A)"]	=	"Bah!%1",

	["(%p)[wW]t[fh]+$"]		=	"%1 What madness!",
	["([%a%d])[%s!,.]+[wW]t[fh]+$"]		=	"%1, how can it be!",


	["^[wW]t[fh]+%a*[^%a%d|]+"]	=	"What under the sun! ",
	["(%A)[wW]t[fh]+(%A)"]	=	"%1what under the sun%2",
	["^[wW]t[fh]+%a*$"]		=	"By the light of the sun!",


--	["(%A)[sS]hut%s[uU]p(%A)"]	=	"%1shut your gaping maw%2",
	["^[sS]hut%s[uU]p[^%a%d|?]+"]		=	"Silence, ",
	["^[sS]hut%s[uU]p%s+"]		=	"Mind yourself, ",
--	["(%A)[sS]hut%s[uU]p?$"]	=	"%1shut ",
	["^[sS]hut%s[uU]p$"]		=	"Mind yourself!",

--	Replace ZOMG, omfg, gawd, jeez, wtf, with various archaic expressions
	["^omg$"]	=	"By the sunwell!",
	["^omg%a+"]	=	"By the blood!",
	["(%a)[%s!,.]+omg%f[%A]"]	=	"%1, by the light of the sun!",

	["(%a%a)[%s%p]-[>=]+[%-%s*]*%(%s*$"]		=	"%1, and my wrath grows!",
	["(%a%a)[%s%p]+[QtT][oO0%._]?[QtT]%s*$"]		=	"%1, as tears flow like rain",
	["(%a%a)[%s%p]-[._]%-[;,]*$"]			=	"%1, vacuous though that seems",

	["^[cC]ra+p+$"]		=	"Cruel fate!",


	["^[gG]od%s([^dD])"]		=	"Unthinkable! %1",

	["^[gG]od(%p)"]	=	"By the sunwell%1",
	["^[gG]od$"]		=	"By Kael'thas!",
	["^[gGjJ]e+[szb]+e?u*s*[%s!,.]+(.*)"]	=	"By the sun, %1",
	["^[gG]e+[szb]+e?u*s*$"]	=	"By the sword of Lor'themar!",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"Anar'alah belore!",

	["^[gGnN][jJwW]%s[oO]n%s"]		=	"Well done on ",
	["^[gGnN][jJwW]%s(%a%a%a-)ing%s"]		=	"Impressive work %1ing ",

	["^[fF][aou]+c?k(%p)"]	=	"Curse it%1",
--	["^[fFmM][aou]+c?k%s([^tT])"]	=	"Curses %1",
	["^[fFmM][aou]+c?k$"]		=	"Cruel fortune!",

	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"Run away, pest!",
	["^[fF]uck+[%s%p]+[iI]%s"]		=	"Curse my very blood! I ",

	["[fF][aou]+w?c?ke?r"]		=	"nuisance",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"By the light of the sun!",
	["^[gG]e+[szb]+e?u*s*$"]	=	"By the sun's glare!",

},
[7]={

	["^[gG]od+%A"]		=	"Anar'alah belore! ",
	["(%A)[gG]od+$"]		=	"%1! ",

	["^[oO]+[kK]+$"]			=	"Very well",
	["^[kK][kK]+$"]			=	"So be it",
--	["^[kK]([%s%p]*)$"]				=	"Alu'dora",


	["^[tT][yY][tTyY]*(%A*)$"]		=	"How kind%1",
	["^[tT]ha?n?[zxc]s?$"]		=	"Much obliged",

--	["^[yY]es$"]		=	"Ana'dona",
	["^[yY][ea]+h?$"]	=	"Truly",

	["^[nN][jJ][^%a%s%d|?]+"]		=	"Selama ashal'anore!",
	["^[gG]ood%s?[wW]ork%p*$"]		=	"Splendid work!",
	["^[gG]ood%s?[jJ]ob%p*$"]		=	"The sun smiles upon us!",


	["^[gG][lL](%A*)$"]			=	"Our enemies will fall%1",


--	Replace woot, WOOOOOOT, w00t and WOOHAA
	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1for the children of blood!%2",
	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 For the bloodline!",
	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	", ana'doreini tala!",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]		=	"Selama ashal'anore%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]			=	"Vengeance! ",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"Glory to the Sin'dorei!",
	["^[bB][o0]+y+a+h*"]				=	"Death to all who oppose us!",


	["%f[%a][gG]o%s?[gGo][gGo%s%p]+%f[%A]"]	=	"time is of the essence!",

	["^[hH]ello$"]				=	"Bal'a dash, malanore",
	["^[yY][oO][yYoO]*[^%a%d|?]+"]	=	"Sinu a'manore, ",
	["^[yY][oO][yYoO]*$"]	=	"Bal'a dash, malanore!",
	["[sS]+h?u+p+$"]			=	"Anaria shola",
	["^[sS]ee%syou$"]	=	"Shorel'aran",

	["^[bB]ye[^%d%a?]*$"]		=	"Hold your head high",
	["^[tT]ake%s?[cC]are[^%d%a?]*$"]		=	"Al diel shala",

	["^[iI]+[nN]+[cC]+$"]		=	"Prepare for battle!",

	["^[lL][oO0][lLoO0]+%p*$"]	=	"Hah!",

},
[8] = {
},


}

end

function Elo.AllianceDialect()

Elo.RaceFilter[1]={
[1]={
},
[2]={
	["(%A)[dD]'?o+h+%A"]	=	"%1bah! ",
	["(%A)[dD]'?u+h+%A"]	=	"%1it's obvious! ",
	["(%A)[gG][ae]+h+%A"]		=	"%1no! ",
	["(%A)[mM]y%s?[gG][ao]+w?d(%A)"]		=	"%1by the Light! %2",
	["(%A)[tT]hank%s?[gG][ao]+w?d(%A)"]		=	"%1thank heavens%2",
	["(%A)[rR]+a+w+r+(%A)"]		=	"%1rraahah! %2",



},
[3]={
	["(%A)[wW]t[fh]+%s*[iI]s(%A)"]	=	"%1what in the king's name is%2",
	["(%A)[wW]t[fh]+%s*[aA]?r?e(%A)"]	=	"%1what in the king's name are%2",
	["(%A)[wW]t[fh]+%s*([dD]o[es]*%A)"]	=	"%1what, pray tell, %2",

	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1Haha, now that's funny!%2",

	["(%A)[nN]ice%s?[tT]ry(%A)"]	=	"%1good effort%2",
	["(%A)[nN]ice%s?1([%s%p])"]	=	"%1one for the Alliance!%2",

},
[5]={
	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"For glory! I have attained Level %1!",
},
[6]={
	["^[wW]t[fh]+%a*$"]		=	"By the Light!",

--	["^[gGnN][jJwW]%s[oO]n%s"]		=	"Good job on ",
	["^[gGnN][jJwW]%s(%a%a%a-)ing%s"]		=	"You fought well %1ing ",

	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"You're beyond redemption!",

},
[7]={
	["[wW]hat's%sup$"]		=	"King's honor, friend",
	["[wW]hat's%sup%s"]		=	"Light be with you, ",

	["^no$"]			=	"Unfortunately not",

	["^[sS]ee%syou$"]				=	"May the light bless you",
	["^[bB]ye[^%d%a?]*$"]		=	"Go with honor, friend",
	["^[tT]ake%s?[cC]are[^%d%a?]*$"]		=	"May the Light shine upon you",

	["^[gG][lL](%A*)$"]			=	"May the Light guide you%1",

	["^[gG]ood%s[gG]ame$"] = "Every battle is glorious.",

	["^[gG]ood%s?[jJ]ob%p*$"]		=	"For glory!",
	["^[nN][jJ]$"]		=	"For honor!",
--	Replace woot, WOOOOOOT, w00t and WOOHAA
	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1hurray%2",
	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 For the Alliance!",
	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"! Justice and glory!",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]			=	"For the King%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]			=	"For Lothar! ",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"For the King!",
	["^[bB][o0]+y+a+h*"]				=	"Eat that, beast!",

	["^[iI]+[nN]+[cC]+$"]		=	"Get ready for action!",

	["^[tT][yY][tTyY]*(%A*)$"]	= "Very kind of you%1",
	["^[tT]ha?n?[zxc]s?$"]		=	"Thank you",

	["^[lL][oO0][lLoO0]+%p*$"]	=	"Ahaha!",
	["^[rR][oO0][tT]?[fF][lL]%a*%p*$"]	=	"Ahahaha!",


},
[14] = {
--	Replace 'guys' with 'people'
	["(%A)[fF]ellows(%A)"]	=	"%1people%2",
	["(%A)[lL]ads(%A)"]	=	"%1people%2",

	["(%A)[cC]ongratulations%s([oO]n%s)"]		= "%1good work %2",
},
[15] = {

	["(%A)[cC]ongratulations(%A)"]		= "%1Light be praised!%2",
},

}

--	Dwarves. Lowland Scots inspired by Wir Ain Leid. http://www.scots-online.org/sitemap.htm
Elo.RaceFilter[3]={
[1]={
	["^[%s~hHmM]*([,.!?]+)[%s~]*$"]	=	"Aye%1",

	["(%a%an[o']?t)%s[tT]oo%s(%a%a%a%a)"]		=	"%1 ower %2",
	["(%Aw?[ia']s)%s[tT]oo%s(%a%a%a%a)"]		=	"%1 ower %2",
	["(%A[iI]'?m)%s[tT]oo%s(%a%a%a%a)"]		=	"%1 ower %2",

	["(%A)[tT]oo%s[mM]uch(%A)"]		=	"%1over much%2",
	["(%A)[tT]oo%s[mM]any(%A)"]		=	"%1over many%2",

-- Occasional double negative
--	["([%s'!?%a])[nN](o?)t%s(.-)[aA]ny"]	=	"%1n%2t %3no",
--	["([%s'!?%a])[nN](o?)t%s(.-)[sS]ome"]	=	"%1n%2t %3no",


},
[2]={
	["(%A)[dD]'?o+h+%A"]	=	"%1och! ",
	["(%A)[dD]'?u+h+%A"]	=	"%1och, it's clear as whiskey! ",
	["(%A)[gG][ae]+h+%A"]		=	"%1och! ",
	["(%A)[mM]y%s?[gG][ao]+w?d(%A)"]		=	"%1mercy me! %2",
	["(%A)[tT]hank%s?[gG][ao]+w?d(%A)"]		=	"%1thank the Titans%2",
	["(%A)[rR]+a+w+r+(%A)"]		=	"%1hraahah! %2",

	["(%A)[sS]h?o+%sfucking(%A)"]	=	"%1awfie%2",
	["(%A)[iI]t'?s%sfucking(%A)"]	=	"%1its%2",
	["(%A)[sS]h?uch%sfucking(%A)"]	=	"%1such%2",
	["(%A)[jJ]ust%sfucking(%A)"]	=	"%1just%2",
	["(%A)[yY]ou%sfucking(%A)"]	=	"%1you%2",
	["(%A)[aA]%sfucking(%A%a)"]		=	"%1a%2",
	["(%A)[tT]he%sfucking(%A%a)"]		=	"%1the fousome%2",
	["(%A)[iI]%sfucking(%A)"]		=	"%1I%2",
	["(%A)[tT]hat%sfucking(%A)"]	=	"%1that foostie%2",
	["(%A)[tT]h([ieo]se?)%sfucking(%A)"]	=	"%1th%2 fousome%3",
	["(%A)[tT]hat'?s%sfucking(%A)"]	=	"%1that's awfie%2",
	["(%A)fucking%s(%a%a-ing%A)"]	=	"%1%2",

	["(%A)[bB]utt(%A%a)"]		=	"%1arse%2",

	["(%A[nN])[ou]pe(%A)"]				=	"%1ae%2",

	["(%A)[lL]otsa(%A)"]		=	"%1a muckle of%2",
	["(%A)[lL]+ot+s%s?[oO]f(%A)"]		=	"%1a muckle of%2",



	["(%A[gGdD])oin'?(%A)"]	=	"nil",
--	["(%A)[dD]ude([sz]*%A)"]		=	"%1laddie%2",

	["(%A[wW])oman(%A)"]		=	"%1umman%2",
	["(%A[wW])omen(%A)"]		=	"%1eemen%2",

	["[oO]ther([sz]*%A)"]		=	"ither%1",
	["(%A)[gG][eui]rl+([sz]*%A)"]		=	"%1lassie%2",
	["(%A)[cC]hi[ck]+([sz]*%A)"]		=	"%1lassie%2",

	["(%A)[sS]h?w[ear]+%s[tT][ao]%s[gG][oa]w?d(%A)"]	=	"%1swear oan Magni's beard%2",
--	["(%A)[gG]tfo(%A)"]		=	"%1get off%2",
--	["(%A)[pP]us+[yie]+([sz]*%A)"]		=	"nil",
	["(%A)[rR]?e?tard([sz]*%A)"]		=	"%1gowk%2",
	["(%A)[rR]etarde?d(%A)"]		=	"%1daftlike%2",
	["(%A)[fF]u[ck]+tard([sz]*%A)"]				=	"%1nyaff%2",
	["(%A)[mM][ou]th[ea]*[hr]*%A*[fF][aou]+w?c?k[ear][rh]?(%A)"]		=	"%1ramgunshoch%2",
	["(%A)[nN]ig+([sz]*)(%A)"]			=	"%1nyaff%2%3",
	["(%A)[nN]ig+[eaui][rh]*([sz]*%A)"]			=	"%1nyaff%2",
	["(%A)[aA@][sz%$][sz%$]%s?hat([sz]*%A)"]		=	"%1idiot%2",
	["(%A)[aA@][sz%$][sz%$]%s?load([sz]*%A)"]		=	"%1heap%2",
	["(%A)[aA@][sz%$][sz%$]%s?ton([sz]*%A)"]		=	"%1heap%2",
	["(%A)[sS]hite?%s?head([sz]*%A)"]	=	"%1mutton%-head%2",
	["(%A)[sS]hite?%s?to%s?do(%A)"]	=	"%1stuff to do%2",
	["(%A)[dD][ui][mpb]+%s?[sScC]h[1iy!*]+a?te?([sz]*%A)"]	=	"%1bampot%2",
	["(%A)[dD]um+b?[fFmM]u[c]?k([sz]*%A)"]	=	"%1bampot%2",
	["(%A)[dD]ic?k%s?he[a]?d([sz]*%A)"]		=	"%1fool%2",
	["(%A)[cC]lu[st]+er%s?fu?c?k([sz]*%A)"]	=	"%1munge%2",
	["(%A)[dD][ou]+che?[%p%s]?bag([sz]*%A)"]		=	"%1nyaff%2",
	["(%A)[dD][ou]+che?([sz]*%A)"]		=	"%1dung%-pile%2",
	["(%A)[aA@][sz%$][sz%$]+%s?hole?([sz]*%A)"]		=	"%1idiot%2",
	["(%A)[aA@][sz%$][sz%$]+%s?wipe?([sz]*%A)"]		=	"%1idiot%2",
	["(%A)[hH]oly%s?shit[^%a%d|?]+"]		=	"%1crivens! ",
	["(%A)[hH]oly%s?[cC]rap[^%a%d|?]+"]		=	"%1crivens! ",
	["(%A)[hH]oly%s?[fF]uc?k[^%a%d|?]+"]		=	"%1crivens! ",

	["(%A)[aA]%s*[dD]ick(%A)"]		=	"%1a bletherskite%2",
	["(%A)[dD]ick[sz](%A)"]		=	"%1carnaptious devils%2",


	["(%A)[sS]h?on([sz]*)%sof%sa?%s?[bB]i[yao]*t?[cs]he?[sz](%A)"]	=	"%1puddock%2%3",

--	["(%A)[tT]hi[sS%s]+h[1iIy!]+a?t(%A)"]		=	"%1this%2",
--	["(%A)[tT]hat%s?[sS]+h[1iIy!]+a?te?(%A)"]	=	"%1that%2",

--	["(%A)[tT][eh][eh]%s?[sS]+h[1iIy!]+a?te?(%A)"]	=	"%1the best%2",
--	["(%A)[tT][eh][eh]%s?[cC]+[rR][aA]+[pP](%A)"]	=	"%1the rubbish%2",

	["(%A)[bB]u+l+%s?shit(%A)"]	=	"%1haivers%2",

	["(%A)[lL]oad([sz]*)%s[oO]f%s[sS]hit(%A)"]		=	"%1load of mince%2%3",


	["(%A)[sS]hite?%s?load(%A)"]		=	"%1heap%2",
	["(%A)[fF][ou]+%s?c?k%s?load(%A)"]		=	"%1heap%2",
	["(%A)[cC]rap%s?load(%A)"]		=	"%1heap%2",
	["(%A)[sS]h?care?([ds]?)%s(%a+)%sshitles+(%A)"]	=	"nil",
	["(%A)[sS]h?care?d%s?shitles+(%A)"]				=	"%1feart%2",
	["(%A)[sS]h?care?d%s(%a+)%sshitles+(%A)"]	=	"%1feart %2%3",
	["(%A)[sS]h?care?(s?)%s(%a+)%sshitles+(%A)"]	=	"%1fear%2 %3%4",

--	["(%A)[gG]h?[ae]+y+(%A)"]		=	"%1feckless%2",
	["(%A)[fF]ag+[oieau]?t?([sz]*%A)"]		=	"%1puddock%2",
	["(%A)[fF]gt([sz]*%A)"]			=	"%1poltroon%2",
	["(%A)[pP]rick([sz]*%A)"]			=	"%1skite%2",
	["(%A)[pP]unk([sz]*%A)"]			=	"%1skite%2",
--	["(%A)[pP]e+n[ieua]s+(%A)"]		=	"%1pecker%2",
--	["(%A)[cC]o*c+k+(%A)"]		=	"%1shaft%2",

	["(%A)[sS]ol(%A)"]		=	"%1fair out of luck%2",
--	["(%A)[jJ]wf(%A)"]		=	"%1doomed%2",

	["(%A)[tT]h([aeio][st]?e?)%s?da[mn]+(%A)"]	=	"%1th%2 fousome%3",
--	Added more conditions for 'bs' now that it means 'blacksmith' in Arathi Basin.
	["(%a)t'?s%s[bB][sS](%A)"]	=	"%1s haivers%2",
	["(%A)such%s?[bB][sS](%A)"]	=	"%1such haivers%2",

--	["(%A)[dD]ic?k(%A)"]	=	"%1snake%2",

	["(%A)[fF]u+c?k%s?[nN]o+[^%a%d|?]+"]		=	"%1niver! ",

	["(%A)[fF]u?c?k?%s[iI]t(%A)"]		=	"%1forget about it%. %2",
	["(%A)[bB]ad[%s%-]?[aA@][sS%$][sS%$]([%s!,.]+%a)"]		=	"%1braw%2",
	["(%A)[bB]ad[%s%-]?[aA@][sS%$][sS%$]%s$"]		=	"%1braw",
	["(%A)[bB]ig+[%s%-]?[aA@][sS%$][sS%$]%s(%a+%A)"]		=	"%1muckle %2",
	["(%A)[hH]u+ge[%s%-]?[aA@][sS%$][sS%$]%s(%a+%A)"]	=	"%1muckle %2",
	["(%A)[lL]ong[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1lang%2",
	["(%A)[sS]h?low[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1slaw%2",
	["(%A)[wW]i[sz]e[%s%-]?[aA@][sz%$][sz%$](%A)"]		=	"%1bluntie%2",
	["(%A)[lL]ame[%s%-]?[aA@][sS%$][sS%$](%A)"]			=	"%1feckless%2",
	["(%A)[wW]eak[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1feckless%2",
	["(%A)[dD]um+b?[%s%-]?[aA@][sz%$][sz%$]e?([sz]*%A)"]		=	"%1numpty%2",
	["(%A)[sS]h?[tu]+p+id%A*[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"%1bumph%2",

	["(%A)[pP]ain%s?[iI][mn]%s?[tT]he%s?[aA@][sS%$][sS%$](%A)"]			=	"%1pain in mah arse%2",


	["(%A)fucking%s?[cC]razy(%A)"]	=	"%1daft%2",

	["(%A[sS]?[wWhH])e%sfucking(%A)"]	=	"%1e fairly%2",

	["(%A)([wWcCsS]h?)o?ul?d'?[av]e?(%A)"]		=	"%1%2ould've%3",

	["(%A)[gG][aou]+n+a(%A)"]	=	"%1gaunny%2",

	["(%A)[aA]sap(%A)"]	=	"%1with all haste%2",

},
[3]={
	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1Gaahahaha!%2",
	["(%A)[lL]ike%s[cC]raz+y+(%A)"]	=	"%1like the world's about to end%2",


},
[5]={
	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"I'm Level %1!%? Where's my drink%?",
},
[6]={
--	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"Away with you!",

	["^[gG]od%s([^dD])"]		=	"By Magni's beard! %1",

	["^[gG]od(%p)"]	=	"By the king's hammer%1",
	["^[gG]od$"]		=	"By the king's beard!",
	["^[gGjJ]e+[szb]+e?u*s*[%s!,.]+(.*)"]	=	"By Ironbeard, %1",
	["^[gG]e+[szb]+e?u*s*$"]	=	"Ironbeard save us!",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"By Muradin's hammer!",

	["^[jJ]e+[szb]+e?u*s*$"]	=	"Megstie me!",

	["[fF][aou]+w?c?ke?r"]		=	"fuil",

	["(%A)[sS]hut%s[uU]p(%A)"]	=	"%1hold your tongue%2",
	["^[sS]hut%s[uU]p[^%a%d|?]+"]		=	"Wheesht! ",
	["^[sS]hut%s[uU]p%s+"]		=	"Hold your tongue, ",
	["(%A)[sS]hut%s[uU]p?$"]	=	"%1wheesht!",
	["^[sS]hut%s[uU]p$"]		=	"Nae havers, now!",


--	Replace ZOMG, omfg, gawd, jeez, wtf, with various archaic expressions
	["^omg%a*[^%a%d|?]+"]	=	"Losh! ",
	["^omg%a*%s"]		=	"Whoa! ",
	["^omg$"]	=	"By crivens!",
	["(%A)omg%a+"]	=	"%1Och!",
	["^omg%a+$"]	=	"Jings!",
	["(%a)[%s!,.]+omg%f[%A]"]	=	"%1, megstie me!",
	["(%a)[%s!,.]+omg$"]	=	"%1, in the name of Khaz Modan!",

	["^[gG]od%s([^dD])"]		=	"By crivens! %1",
	["^[gG]od(%p)"]	=	"By my father's hammer%1",
	["^[gG]od$"]		=	"By crivens!",
	["^[gGjJ]e+[szb]+e?u*s*[%s!,.]+(.*)"]	=	"Upon my father's hammer, %1",
	["^[gG]e+[szb]+e?u*s*$"]	=	"By my father's hammer!",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"Upon my father's hammer!",

	["^[cC]hrist(%A)"]	=	"Och!%1",

	["^[wW]t[fh]+%a*$"]		=	"Och!",
	["^[wW]t[fh]+%a*[^%a%d|]+"]	=	"Och! ",
	["(%p)[wW]t[fh]+$"]		=	"%1 Och!",
	["([%a%d])[%s!,.]+[wW]t[fh]+$"]		=	"%1, och!",
	["(%A)[wW]t[fh]+(%A)"]	=	"%1what on Azeroth%2",
	["^[wW]t[fh]+%a*$"]		=	"Och!",


	["(%w)%s[hH]el+%sof%sa"]		=	"%1 remarkable",

	["(%a)d%sto%s?[hH]el+(%A)"]	=	"%1d beyond recognition%2",
	["all%sto%s?[hH]el+(%A)"]	=	"all to waste%1",
	["the%s[hH]el+%sout%sof(%A)"]	=	"some sense into%1",
	["the%sshit+%sout%sof(%A)"]	=	"some sense into%1",
	["the%s[fF]u+c*k+%sout%sof(%A)"]	=	"the snot out of %1",

	["(%A)[fFmM]uc?ks$"]		=	"%1gowks",

},
[7]={

--[[

	["(%A)[pP]u+l+%s([^%p%s%dsSaA])"]	=	"%1lure %2",
	["^[pP]u+l+(%A)"]		=	"Lure%1",
	["(%A)[pP]u+l+$"]		=	"%1lure",
	["^[pP]u+l+$"]			=	"Go grab them",
	["^[pP]u+l+%p+$"]			=	"Let battle be joined!",
	["^[pP]u+l+[ie]+n+g+$"]	=	"Now I'll cast the bait!",
	["^[pP]u+l+[ie]+n+%p*$"]		=	"Prepare for battle!",
--]]
	["^[gG]ood%s[gG]ame$"] = "good game!",

	["^[sS]h?pam+(%a*%A)"]	=	"Blether%1",
	["(%A)[sS]h?pam+(%a*%A)"]	=	"%1blether%2",
	["(%A)[sS]h?pam+$"]	=	"%1blether",
	["(%A)[sS]h?pam+(%a+)$"]	=	"%1blether%2",

	["^[bB]ye[^%d%a?]*$"]		=	"Watch your back",
	["^[tT]ake%s?[cC]are[^%d%a?]*$"]		=	"Off with ye",

	["^[sS]h?ure(%A)"]	=	"nil",
	["^[sS]h?ure$"]		=	"nil",


--	["(%A)[mM][tT]$"]		=	"%1slip of the tongue",
	["^[mM][tT](%p)"]		=	"Pay me no mind%1",

	["^[pP]r[aoub]*l+y$"]			=	"Likely so",

	["^[nN]+a+[wh]*%s"]		=	"Nae, ",
	["^[nN]+a+[wh]*(%p)"]	=	"Nae%1",
	["^[nN]+a+[wh]*$"]		=	"I don't think so",

--	Replace woot, WOOOOOOT, w00t and WOOHAA
	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1huzzah%2",
	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 For Khaz Modan!",
	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"! For Khaz Modan!",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]			=	"Huzzah%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]			=	"Huzzah! ",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"For Khaz Modan!",

	["^[bB][o0]+y+a+h*"]		=	"Put that in yer pipe and smoke it!",

	["^[tT][yY][tTyY]*(%A*)$"]	=	"Awfie kind o' ye%1",
	["^[tT]ha?n?[zxc]s?$"]		=	"Muckle thanks",

	["^[iI]t'?s%s[oO]kay$"]		=	"Dinnae fash yerself",

	["^[dD]on't%s[kK]now(%A)"]	=	"I don't know%1",
	["^[dD]on't%s[kK]now$"]	=	"I don't know",

	["^[iI]%s?[bB]et%s(%a%a)"]	=	"Shuirly %1",

	["(%A)[iI]%s?[gG]uess$"]	=	"%1, I'm thinkin'.",
	["^[iI]?%s?[gG]uess%s?[sS]o$"]	=	"Maybe so",
	["^[iI]%s?[gG]uess%s?$"]	=	"I guess so",

	["^[mM]a+y*b+e%s(%a)"]		=	"nil",
	["^[mM]a+y*b+e%s?(%d)"]	=	"nil",
	["(%A)[mM]a+y*b+e%s?(%d)"]	=	"nil",
	["^[lL]oo+k+s%slike"]		=	"nil",
	["[iI]m[jJ]ust(%A)"]		=	"I am just%1",

	["^[pP]r[aoub]*l+y$"]			=	"Maybe so",


	["^[nN]ice(%A)"]	=	"Bonnie%1",
--	["(%A)[nN]ice$"]	=	"%1good",
	["(%A)[nN]ice(%A)"]	=	"%1bonnie%2",
	["^[nN]ice$"]		=	"Bonnie",

	["^[sS]h?[oO]*[rR]+[yY]$"]			=	"Sorry about that",

	["^[yY]es$"]		=	"Aye",
	["^[yY][ea]+h?$"]	=	"Aye",
	["^[yY][aA]+[hH]?(%p)"]		=	"Aye%1",
	["^[yY][aA]%s[iI]%s"]		=	"Aye, I ",
	["^[yY][aA]%s([tTwW])[hH](%a)"]		=	"Aye, %1h%2",
	["^[yY][aA]+[hH][%s,]"]		=	"Aye, ",
--	["(%A)[yY][aA]$"]	=	"%1ye",
	["^[yY][aA]+%s[iI]t%s"]			=	"Aye, it ",

	["^[kK][kK]+$"]			=	"Awright",

	["^[sS]+h?[au]*w+e+t+$"]	=	"Brilliant!",

	["^[dD]u+de%A(%a)"]	=	"Lad, %1",
	["(%A)[dD]u+de"]	=	"%1laddie",
	["(%A)[dD]u+de"]		=	"%1laddie",
	["^[dD]u+de[%s!,.]+(%a)"]		=	"Lad, %1",
	["^[dD]u+de$"]	=	"Och!",
	["(%a)yig?n'?(%A)"]		=	"nil",

	["(%A)[lL]ots$"]		=	"%1heaps",
	["[aA]l+ot+a+(%A)"]		=	"a heap o'%1",
	["^[aA]lot+(%A)"]		=	"A heap%1",
	["(%A)[aA]l+ot+(%A)"]	=	"%1a heap%2",
	["(%A)[bB]uncha(%A)"]	=	"%1heap o'%2",
	["^[bB]uncha(%A)"]		=	"A heap o'%1",

	["[%s!,.]+[wW]hat's%sup$"]		=	", how are ye%?",
	["[wW]hat's%sup(%p)"]		=	"How's aw wi ye%1",
	["[wW]hat's%sup%s"]		=	"What are ye up to, ",
	["[wW]hat's%sup$"]		=	"How are ye%?",

	["%f[%a][gG]o%s?[gGo][gGo%s%p]+%f[%A]"]	=	"move yer arse!",

	["[eE]v+e?ry?%s?1(%A)"]	=	"everybodie%1",
	["[eE]v+e?ry?%s?1$"]	=	"everybodie",
	["[sS][ou]me?%s?1(%A)"]	=	"somebodie%1",
	["[sS][ou]me?%s?1$"]	=	"somebodie",
	["[sS][ou]?me?thi?n[gG']?"]	=	"nil",
	["[sS][ou]?me?thi?ng?"]	=	"somethin'",
	["[nN]o%s?1(%A)"]	=	"naebodie%1",
	["[nN]o%s?1$"]		=	"naebodie",

	["[nN]oone"]	=	"naebodie",
	["[nN]o%sone"]	=	"naebodie",

	["^[sS]h?e+r[ie]+[ou]+sl+y(%A)"]	=	"Aye%1",


	["^[rR][oO0][tT]?[fF][lL]%a*%p*$"]	=	"Gahahahaa!",

	["^[lL][oO0][lLoO0]+%p*$"]	=	"Gaahaha!",


	["^[nN]ice%s?[tT]ry$"]			=	"Awfie good try.",
	["^[nN]ice%s?[tT]ry%p+$"]			=	"Get it nixt tyme!",

	["^%A*[lL]+[fF4]+[gGdDpP]+%s"]		=	"I need a group for ",

--	["[nN]inja$"]					=	"rook",
--	["[aA]%s?[nN]inja(%A[^lL])"]	=	"a rook%1",
--	["[tT]he%s?[nN]inja(%A[^lL])"]	=	"the reiver %1",
--	["[nN]injas"]					=	"reives",

	["([^aA])%s[nN]inja%s([^tTlL])"]	=	"%1 rook %2",

	["([^aA])%s[nN]inja%s[tT]h"]	=	"%1 rook th",

	["[nN]inja['e]?d"]				=	"rooked",
	["[nN]inja?in['g]?"]			=	"rookin'",
	["[nN]inja%s?lootin['g]?"]		=	"reivin'",
	["[nN]inja%s?looter"]			=	"picky%-fingered reiver",
	["[nN]inja%s?looted"]			=	"rooked",

},

[8]={
--	["([fF])or[%s!,.]+[fF]or(%A)"]		=	"%1er%2",
--	["([fF])[uo]r?[%s!,.]+[fF][uo]r(%A)"]		=	"%1er%2",

	["^[nN]o%s*[wW]a[iy](%A*)$"]		=	"Away wi' ye%1",

	["^[aA]nyone%shave([^?]+)%?+"]		=	"nil",
	["^[aA]nyone%swant([^?]+)%?+"]		=	"nil",
	["^[aA]nyone%sseen?([^?]+)%?+"]		=	"nil",
	["^[aA]nyone%sneed([^?]+)%?+"]		=	"nil",

	["^[nN]eed%s(%a%a-s[^?]+)$"]		=	"Ah'm wantin %1",

	["(%A)[sS]earching%sfor(%A)"]		=	"%1wantin%2",

	["(%a%a[^%d%s%psz])%s[iI]s%s(%a%a)"]		=	"%1's %2",

	["(%a+%A%a+%A%a+%A%a%a%a%a%a-)ly(%A*)$"]		=	"%1%-like%2",

	["(%Ato%s%a+%s)([tT]he%s%a+%s)([oO]ff)(%p*)$"]	=	"%1%3%2%4",
	["(%Ato%s%a+%s)([tT]he%s%a+%s)([oO]n)(%p*)$"]	=	"%1%3%2%4",
	["(%Ato%s%a+%s)([tT]he%s%a+%s)([uU]p)(%p*)$"]	=	"%1%3%2%4",
	["(%Ato%s%a+%s)([tT]he%s%a+%s)([dD]own)(%p*)$"]	=	"%1%3%2%4",


	["[wW]ho%s[hH]as%s(%a%a)"]	=	"who's%1",

},
[13]={
--	In Scots, expand contractions in questions only
	["^.+$"]		=	expandquestion,
},
[14]={
--	But contract "have" often
	["^.-[hH]ave.*$"]		=	Elo.ContractHave,

--	Replace 'fellow' with 'lads'
	["(%A)[fF]ellow([sz]*%A)"]	=	"%1lad%2",

	["(%A)[cC]ongratulations%s([oO]n%s)"]		= "%1braw work %2",

	["([%s%p]I)%s?[tT]hink([%s%p]%a+%A+%a+)"]		=	"%1'm thinking%2",

	["([%s%p][fF]org[eo]t%a*%s)[tT]o(%s%a%a)"]	=	"%1and%2",
	["([%s%p])[rR]emember%a*%s[tT]o(%s%a%a)"]	=	"%1mind and%2",

	["([%s%p][tT])hat%s?[iI]s(%s%a)"]	=	"%1hat's%2",


	["(%A)[pP]eople(%A)"]	=	"%1lads%2",

	["(%A)[aA]nyone(%A)"]	=	"%1anybodie%2",
	["(%A)[eE]veryone(%A)"]	=	"%1iverybodie%2",
	["(%A)[sS]omeone(%A)"]	=	"%1somebodie%2",

	["(%A)[nN]othing(%A)"]	=	"%1naethin%2",
	["(%A)[nN]obody(%A)"]	=	"%1naebodie%2",
	["(%A)[nN]owhere(%A)"]	=	"%1naewhaur%2",

	["(%A[nN]eed[eds]*%s)to%sbe%s(%a%a-e[dn]%A)"]	=	"%1%2",
	["(%A[wW]ant[eds]*%s)to%sbe%s(%a%a-e[dn]%A)"]	=	"%1%2",

	["(%A[gG][ia]ven?%s)([%w%s]-)[tT]o%sme(%A)"]	=	"%1us %2 %3",
	["(%A[gG][ia]ven%s)me(%A)"]	=	"%1us%2",

	["([%s%p][gG])oin[ng']%A*[tT]o(%A)"]	=	"%1auny%2",

	["(%A)[qQ]uite(%A)"]	=	"%1fully%2",

	["(%A)[nN]o[t']%s[vV]ery%s(%a%a%a)"]	=	"%1no' mighty %2",

	["(%A)[aA]%s[vV]ery%s(%a%a%a)"]	=	"%1a muckle %2",
	["(%A)[aA]%s[lL]ittle(%A)"]	=	"%1a wee%2",
	["(%A)[aA]%s[bB]it(%A)"]	=	"%1a bittie%2",

	["(%A)[uU]sed?%s[tT]o(%A)"]	=	"%1uissed to%2",

	["(%A)[oO]n%stop%sof(%A)"]	=	"%1atop%2",
	["([tTsSgGbBlL])oo([tdpl])"]	=	"%1ui%2",
	["([bBlLtT])oo(k)"]	=	"%1eu%2",

	["([nNsS])oo(n)"]	=	"%1ui%2",

	["(%A[mM])yself(%A)"]	=	"%1asel%2",
	["(%A[yY])[eou]+rsel[fv]e?([sz]*%A)"]	=	"%1ersel%2",
	["(%A[hH]ersel)[fv]e?([sz]*%A)"]	=	"%1%2",
	["(%A[hH]imsel)f(%A)"]	=	"%1%2",
	["(%A[iI])tself(%A)"]	=	"%1tsel%2",
	["(%A[tT])hemsel[fv]e?([sz]*%A)"]	=	"%1hemsel%2",
	["(%A)[oO]ursel[fv]e?([sz]*%A)"]	=	"%1wirsel%2",

	["(%a%a%a+)%s[iI]sn't(%A%a%a+)"]	=	"%1's not%2",

	["(%A[aA])lways(%A)"]	=	"%1yeweys%2",
	["(%A[aA])lso+(%A)"]			=	"%1wsae%2",
	["(%A[aA])wa+y+(%A)"]			=	"%1wa%2",

	["([hHgGtT])and"]	=	"%1aund",
	["(%A)[hH]ope([sz]*%A)"]	=	"%1howp%2",
	["(%A)[hH]op(e?[ding']+%A)"]	=	"%1howp%2",
	["(%A[sStT])old(%A)"]	=	"%1elt%2",

	["([hH])e?ard(%A)"]	=	"%1aurd%2",

	["(%A)[bB]oth(%A)"]	=	"%1the both%2",
	["(%A)[mM]ost(%A)"]	=	"%1the most%2",


	["(%A[tT]h%a+%s)[oOiI]ther(s?%p*)$"]	=	"%1tither%2",


	["(%a%A)(%a%a%a%a-er)%sthan%s(%a%a%a+)"]	=	"%1mair %2 nor %3",

	["(%A[tT]he%A)(%a%a%a-est%s%a%a%a+)"]	=	"%1maist %2",

	["(%A[sS])moke?(%A)"]	=	"%1mook%2",
	["(%A[tT])o%s?[mM]orrow%s?[mM]orning?(%A)"]	=	"%1he morn%2",

	["(%A[yY]ou)%s?[wW]ill+(%A%a%a%a)"]	=	"%1'll%2",
	["(%A[iI])%s?[wW]ill+(%A%a%a%a)"]	=	"%1'll%2",
	["(%A[wW]e)%s?[wW]ill+(%A%a%a%a)"]	=	"%1'll%2",

	["(%a[ey])one(%A)"]		=	"%1body%2",
	["([oO])u([td])"]	=	"%1o%2",

},
[15]={
	["(%a%a%A)[mM]e(%A)"]	=	"%1us%2",


	["(%A)[cC]ongratulations(%A)"]		= "%1well done!%2",
	["([dDtTgGlL])ow([n])"]	=	"%1oo%2",
	["([sSfFhHdDpPbBtTcC])ou([tns])"]	=	"%1oo%2",
	["([mM])ou([tns]%a)"]	=	"%1oo%2",


	["(%A)[oO]ur(%A)"]	=	"%1oor%2",
	["(%A)[oO]wn(%A)"]	=	"%1ain%2",

	["(%A)[kK]now([sz]*%A)"]	=	"%1ken%2",
	["(%A)[kK]new(%A)"]	=	"%1kent%2",
	["(%A)[kK]nown(%A)"]	=	"%1kent%2",
	["(%A)[uU]nknown(%A)"]	=	"%1unbekent%2",


	["(%A[wWcCsS]h?)ould(%A)"]	=	"%1uid%2",

	["([tT]h%a+%A)[oO]ne(%A)"]	=	"%1yin%2",
	["([tT]h%a+%A%a+%A)[oO]ne(%A)"]	=	"%1yin%2",
	["(%A[aA]%A%a+%A)[oO]ne(%A)"]	=	"%1yin%2",
	["(%A)[oO]ne%s*[mM][aio]re?(%A)"]	=	"%1yin mair%2",

	["(%A)[tT]wo(%A)"]	=	"%1twae%2",
	["(%A)[wW]ho(%A)"]	=	"%1whae%2",

	["(%A[aA])ll%s[rR]ight(%A)"]			=	"%1wright%2",

	["(%Aa)l+([^%p%s%daeioulc]%a%a%a+)"]			=	"%1aw%2",
	["(%AA)l+([^%p%s%daeioulc]%a%a%a+)"]			=	"%1Aw%2",

	["([%s%pwl][tT])o%s*gether(%A)"]			=	"%1hegither%2",

	["(%A)[kKsS][oi][rn][td]%s[oO][f'](%A)"]	=	"%1sorta%2",

	["(%A%a-[dDtTghmc])ou(r?)se(s?%A)"]	=	"%1oo%2se%3",
	["(%A%a-[fhmrpz])ound(s?%A)"]	=	"%1oon%2",

	["([ctmgpkd][aA])r([mdtpglk])"]	=	"%1ir%2",

	["(%A)[mM]ov([ei])"]			=	"%1muiv%2",

	["(%A)[iI]magin(%a+)"]			=	"%1'magin%2",
	["(%A)[iI]mage(%A)"]			=	"%1eemage%2",

	["(%a)ength"]			=	"%1enth",
	["(%A)[gG]uy(%A)"]	=	"%1laddie%2",

	["(%A)[sS]tay(%A)"]	=	"%1bide%2",
	["(%A)[sS]tayed(%A)"]	=	"%1bode%2",
	["(%A)[sS]tayin[g'](%A)"]	=	"%1bidin%2",

	["(%A[uU])(s[iea]%a*%A)"]	=	"%1i%2",

	["(%a[iu])ght(%a*%A)"]	=	"%1cht%2",

	["([%s%d%p])[oO]ld"]			=	"%1auld",

	["([cChHmM])old(%A)"]			=	"%1auld%2",

	["([hHcC])alf"]			=	"%1auf%2",


	["(%A)[pP]erhaps(%A)"]			=	"%1mebbie%2",
	["(%A)[mM]aybe(%A)"]			=	"%1mebbie%2",
	["(%A)[vV]ery(%A)"]			=	"%1verra%2",
	["(%A)[aA][wl]ready(%A*)$"]			=	"%1awreadies%2",
	["(%A)[aA]wfu?l+y(%A)"]			=	"%1awfie%2",
	["(%A)[aA]nd(%A)"]			=	"%1an'%2",
	["(%A)[oO]f(%A)"]			=	"%1o'%2",
	["(%a[^a%d%p%s][mgylbfthdcnkrze])ing?([%s!?,])"]		=	"%1in%2",
	["(%a%a[^a%d%p%s][mgylbfthdcnkrze])ing'?(s?%A)"]		=	"%1in%2",

	["([%s%p])[iI]%s"]		=	"%1Ah ",
	["([%s%p])[iI]'([lmdv][le]?%A)"]	=	"%1Ah'%2",
--	["(%A[fF])or(%A)"]	=	"%1er%2",
	["(%A[nN])o+([^%a'])"]	=	"%1ae%2",

	["(%A[nN])early(%A%a)"]	=	"%1earhaun%2",

	["(%A[tT])o%s?[dD]ay+(%A)"]	=	"%1he day%2",
	["(%A[tT])o%s?[nN]i[cg]ht(%A)"]	=	"%1he nicht%2",
	["(%A[tT])o%s?[mM]orrow(%A)"]	=	"%1he morra%2",


	["(%A[dDwW])on't(%A)"]	=	"%1inna%2",
	["(%A[wW])eren't(%A)"]	=	"%1erena%2",
	["(%A[cCwW])ouldn't(%A)"]	=	"%1uidna%2",
	["(%A[dD])oesn't(%A)"]	=	"%1isna%2",
	["(%A[dD])idn't(%A)"]	=	"%1idna%2",
	["(%A[cC])an't(%A)"]	=	"%1anna%2",
	["(%A[cC])an%s?[nN]ot(%A)"]	=	"%1anna%2",
	["(%A[iI])sn't(%A)"]	=	"%1sna%2",
	["(%A[wW])asn't(%A)"]	=	"%1isna%2",
	["(%A[aA])ren't(%A)"]	=	"%1rena%2",
	["(%A[hH])aven't(%A)"]	=	"%1inna%2",
	["(%A[hH])asn't(%A)"]	=	"%1aesna%2",
	["(%A[mM])usn't(%A)"]	=	"%1aunna%2",

	["(%A[dD])[ao]e?%s[nN]o['t](%A)"]	=	"%1inna%2",
	["(%A[wW])[iu]ll%s[nN]o['t](%A)"]	=	"%1inna%2",
	["(%A[wW])ere%s[nN]o['t](%A)"]	=	"%1erena%2",
	["(%A[cCwWsS]h?)o?u[li]d%s[nN]o['t](%A)"]	=	"%1uidna%2",
	["(%A[dD])oes%s[nN]o['t](%A)"]	=	"%1isna%2",
	["(%A[dD])id%s[nN]['t](%A)"]	=	"%1idna%2",
	["(%A[cC])an%s?[nN]o['t](%A)"]	=	"%1annae%2",
	["(%A[iI])s%s[nN]o['t](%A)"]	=	"%1sna%2",
	["(%A[wW])as%s[nN]o['t](%A)"]	=	"%1isna%2",
	["(%A[aA])re%s[nN]o['t](%A)"]	=	"%1rena%2",

	["([hHdDlL])ead([sz]*%A)"]	=	"%1eid%2",
	["(%A[hH])a([ds]%A)"]	=	"%1ae%2",
	["(%A[hH])ave(%A)"]	=	"%1ae%2",

	["(%A)[bB]etween(%A)"]	=	"%1atween%2",
	["(%A)[bB]efore(%A)"]	=	"%1afore%2",
	["(%A)[bB]ehind(%A%a%a)"]	=	"%1ahint%2",
	["(%A)[bB]ecause(%A%a%a)"]	=	"%1acause%2",
	["(%A)[bB]eside(s?%A)"]	=	"%1aside%2",

	["[eE]ver"]	=	"iver",
	["[mM]ost"]	=	"maist",
	["(%A)[bB]oth"]	=	"%1baith",

	["(%A)[cC]razy(%A)"]	=	"%1daft%2",

	["(%A)[aA]bove(%A)"]	=	"%1abuin%2",
	["(%A)[bB]elow(%A)"]	=	"%1ablow%2",
	["(%A)[wW]ith(%s[^'])"]	=	"%1wi'%2",
	["(%A)[wW]ith(%s)$"]	=	"%1wi'%2",

	["(%A)[wW]ithout(%s)"]	=	"%1athoot%2",
	["(%A)[wW]ithin(%s)"]	=	"%1athin%2",

	["(%A)[tT]hirsty(%s%a)"]	=	"%1drouthie%2",
	["(%A)[hH]ungry(%s%a)"]	=	"%1hungert%2",

	["(%A)[sS]ure([liey]*%A)"]	=	"%1shuir%2",

	["(%A)[aA]fter"]	=	"%1efter",
	["(%A)[mM]odern(%A)"]	=	"%1modren%2",

	["(%A)[tT]hey(%A)"]	=	"%1thay%2",
	["(%A)[tT]hem(%A)"]	=	"%1thaim%2",

	["(%A)[wW]hat(%A)"]	=	"%1whit%2",
	["([%s%pey][wWtT])here(%A)"]	=	"%1haur%2",
	["(%A)[wW]hen(%A)"]	=	"%1whan%2",
	["(%A)[aA]%A?[wW]hile(%A)"]	=	"%1a wee%2",

	["(%A)[nN]ot(%A)"]	=	"%1no'%2",

	["(%A)[lL]et(s?%A)"]	=	"%1lat%2",
	["([^me][pP])ut"]	=	"%1it",
	["([gGyY])et"]	=	"%1it",

	["(%A)[sS][uo][io]ner%s[oO]r%s[lL]ater(%A)"]	=	"%1suin as syne%2",


	["(%A[sS])ilver"]	=	"%1iller",
	["(%A)[gG]old"]	=	"%1goud",

	["([wWpP])ay"]	=	"%1ey",
	["(%A[dD]r)op"]	=	"%1ap",

	["([vV])isi"]	=	"%1eesi",
	["(%A[lL])ib"]	=	"%1eeb",
	["(%A[sS])eri"]	=	"%1eeri",

	["([tT]hin)g([%s%ps])"]	=	"%1%2",

	["(%A[tT])hrow"]	=	"%1hraw",
	["(%A[sS])now"]	=	"%1naw",
	["(%A[lL])ow"]	=	"%1aw",
	["(%A[wW]r)ong"]	=	"%1ang",


	["(%A[eE])vening?"]	=	"%1'enin",
	["(%A[sS])econd"]	=	"%1eicont",
	["(%A[mM])inute"]	=	"%1eenit",
	["(%A)[hH]our"]	=	"%1oor",

	["(%A)[cC]ountr[iey]+([sz]*%A)"]	=	"%1kintra%2",
	["(%A)[cC]hurche?([sz]%A)"]	=	"%1kirk%2",

	["([hH])o(me[sz]*%A)"]	=	"%1a%2",
	["([nNbBgGtTbBlL])o(ne[sz]*%A)"]	=	"%1a%2",
	["([gGtTlL])oad([sz]*%A)"]	=	"%1ade%2",

--	["(%a)rea(%a)"]	=	"%1rae%2",
	["(%A[mMsS])ore([ly]*%A)"]	=	"%1air%2",

	["(%A[tTsS])o(%A)"]	=	"%1ae%2",
	["(%A[mM])y(%A)"]	=	"%1ah%2",

	["(%a%a)%s[mM]ight%s[aA]s%s[wW]ell(%A)"]	=	"%1'd be as well%2",


	["([^sS][wW])or([krd])"]	=	"%1ir%2",
	["([wW])or([sl][dte])"]	=	"%1ar%2",

	["([%sbBgGkKpPtT][rR])un([%s%pn])"]	=	"%1in%2",

	["(%A)[sS]uch(%A)"]	=	"%1sich%2",

	["([%s%ptT][rRhHjJ])ust(%A)"]	=	"%1uist%2",

	["(%A)[sS]lap+"]	=	"%1skelp",

	["(%a[hHrRlLmMtT])ance([sdt]*%A)"]	=	"%1aunce%2",

	["([bBdDtTcCgGhHpP%s][aA])(r[cpgkdtm])"]	=	"%1i%2",

	["(%A)[gG]ots?(%A)"]	=	"%1goat%2",
	["([gGrRfFtTdDhH])ather"]	=	"%1aither",
	["([lL])ather"]	=	"%1ether",

	["(%A)[nN]ext"]	=	"%1nixt",

	["(%A)[iI]n(%s?)to(%A)"]	=	"%1in%2til%3",

	["(%A)[wW]ent%sto(%A)"]	=	"%1gaed til%2",

	["(%A)[hH]ead(%a*)%sto(%A)"]	=	"%1heid%2 til%3",

	["(%A)[yY][eE]+[sS]+h?(%A)"]	=	"%1aye%2",

	["(%A)[tT]h(%a+)%s[hH]ill(%A)"]	=	"%1th%2 brae%3",
	["(%A)[aA]%s[hH]ill(%A)"]	=	"%1a brae%2",
	["(%A)[wW]hole(%A)"]	=	"%1hail%2",

	["(%A)[sS]eeks(%A)"]	=	"%1fauncies%2",

	["(%a)aund(%A)"]	=	"%1aun%2",

	["(%a%a[ktp])ed(%A)"]	=	"%1it%2",
	["(%a[ei])lled(%A)"]	=	"%1lt%2",

	["(%A%a)ime([dsz]*%A)"]	=	"%1yme%2",

	["(%a[tnlhm])ain"]	=	"%1een",

	["(%A[mM]?)[aA]ny(.)"]	=	"%1ony%2",

	["(%A[aA])ll+([%s%prmt])"]	=	"%1w%2",

	["(%A[cCfF]a)ll([e%s])"]	=	"%1w%2",


	["([cCjJrRh])oi([nl]e?)(.)"]	=	"%1y%2%3",

	["(%A[fF])rom(%A)"]	=	"%1rae%2",
	["(%A[dDgG])o(%A)"]	=	"%1ae%2",

	["(%A[gG])oes(%A)"]	=	"%1aes%2",
	["(%A[dD])one(%A)"]	=	"%1uin%2",

	["(%A[gG])oin[ng'](s?%A)"]	=	"%1aun%2",
	["(%A[dD])oin[ng'](s?%A)"]	=	"%1aein%2",

	["([pP])rov([ie])"]	=	"%1ruiv%2",

	["[oO]ver"]	=	"ower",

	["(%A)[mM]uch(%A)"]	=	"%1muckle%2",


	["(%A)[yY]ou(r?s?%A)"]	=	"%1ye%2",

	["(%a%a([bdptgd])%2l?)e?y(%A)"]		=	"%1ie%3",
	["(%a%a)ody(%A)"]		=	"%1odie%2",

	["(%A)[iI]t%s[iI]s(%A[^%s%pnN])"]	=	"%1it's%2",
	["(%A)[wW]ill+(%A)"]	=	"%1wull%2",
	["(%A)[wW]as(%A)"]	=	"%1wis%2",

	["([^%a%p%dsS])%s[aA]re(%A+%a)"]	=	"%1're%2",

--	["(%A)Ah%s[hH][ai]ve?(%A+%a)"]	=	"%1Ah've%2",
--	["(%A)Ah%sw[iu]ll(%A+%a)"]	=	"%1Ah'll%2",
--	["(%A)Ah%swo?ui?l?d(%A+%a)"]	=	"%1Ah'd%2",
--	["(%A)Ah%sam(%A+%a)"]	=	"%1Ah'm%2",

	["(%A)[gG]ive(n?%A)"]	=	"%1gie%2",
	["(%A)[gG]ave(%A)"]	=	"%1gaied%2",

	["(%A)[oO]n(%A)"]	=	"%1oan%2",
	["(%A[sSjJ]t?o)([bp])"]	=	"%1a%2",
	["(%A)[oO]ff(%A)"]	=	"%1aff%2",

	["(%a[rl])ves(%A)"]	=	"%1fs%2",
	["(%A[sS])taves(%A)"]	=	"%1taffs%2",
	["(%a[rl])ven(%A)"]	=	"%1fin%2",
	["(%a[rl])vish(%A)"]	=	"%1fish%2",

	["(%A[sS])word([sz]*%A)"]	=	"%1wuird%2",
	["(%A[cC])loth([sz]*%A)"]	=	"%1laith%2",
	["(%A[aA])x(e[sz]*%A)"]	=	"%1ix%2",
	["(%a[lr])ass"]	=	"%1ess",


},
}

Elo.RaceFilter[2]={
[1]={
	["^[%s~hHmM]*([,.!?]+)[%s~]*$"]	=	"Asur'thoraman%1",
},
[2]={
	["(%A)[dD]'?u+h+%A"]	=	"%1it is as clear as moonlight.",

	["(%A)[mM]y%s?[gG][ao]+w?d(%A)"]		=	"%1by Elune! %2",
	["(%A)[tT]hank%s?[gG][ao]+w?d(%A)"]		=	"%1thank the goddess%2",
	["(%A)[rR]+a+w+r+(%A)"]		=	"%1Tor ilisar'thera'nal!%2",

	["(%A)[aA]round(%A[tT])"]		=	"%1round%2",

	["(%A)[lL]ast%s?[nN]ight(%A)"]	=	"%1yestereve%2",
	["(%A)[hH]ead%s?bac?k(%A[tT]o)"]		=	"%1return%2",

},
[3]={
	["(%A)[wW]t[fh]+%s*[yY]ou(%s%a%a%a-ing?%A)"]	=	"%1what in Elune's name are you%2",
	["(%A)[wW]t[fh]+%s*[iI]s(%A)"]	=	"%1what in Elune's name is%2",
	["(%A)[wW]t[fh]+%s*[aA]?r?e(%A)"]	=	"%1what under the moon are%2",
	["(%A)[wW]t[fh]+%s*[wW]a[sd]+(%A)"]	=	"%1whatever was%2",
	["(%A)[wW]t[fh]+%s*[wW]ere?(%A)"]	=	"%1what in the name of Cenarius were%2",
	["(%A)[wW]t[fh]+%s*[wW]il+(%A)"]	=	"%1whatever will%2",
	["(%A)[wW]t[fh]+%s*([dD]o[es]*%A)"]	=	"%1what in the goddess's name %2",
	["(%A)[wW]t[fh]+%s*[dD]id?(%A)"]	=	"%1what under the moon's gaze did%2",

	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1How laughable!%2",

	["(%A)[lL]ike%s[cC]raz+y+(%A)"]	=	"%1with great fervor%2",

},
[5]={
	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"Ana'doreini tala! I have reached Level %1!",
},
[6]={
	["^[gG]od$"]		=	"Alas!",

	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"May the goddess forgive you!",

	["^[dD]a+[mn]+[%s%p]+[iI]%s"]		=	"Why, I ",
	["^[fF]uck+[%s%p]+[iI]%s"]		=	"Alas! I ",

	["[fF][aou]+w?c?ke?r"]		=	"defiler",
	["^[sS]hut%s[uU]p[^%a%d|?]+"]		=	"Eno therador mali! ",
	["^[sS]hut%s[uU]p$"]		=	"Eno therador mali!",
	["^[wW]t[fh]+%a*$"]		=	"Insufferable!",
	["^omg$"]	=	"In the name of Cenarius!",

--	"Its" is "It's" almost all the time when starting a line
	["^[iI]ts(%A)"]	=	"It is%1",

--	"its" followed by "the" two words later is usually "it's"
	["(%A[iI])ts%s(%a+)%s[tT]he(%A)"]	=	"%1t is %2 the%3",

--	Other common "it's" places
	["(%A[iI])ts%s[oO]nly(%A)"]	=	"%1t is only%2",
	["(%A[iI])ts%s[tT]oo(%A)"]	=	"%1t is too%2",
	["(%A[iI])ts%s[jJ]ust(%A)"]	=	"%1t is just%2",
	["(%A[iI])ts%s(%a%a-ing%A)"]	=	"%1t is %2",
	["(%A[iI])ts%s[nN]o([wtob%s])"]	=	"%1t is no%2",

	["(%A[iI])ts%s[tT]he(%A)"]	=	"%1t is the%2",
	["(%A[iI])ts%s[aA](n?%A)"]	=	"%1t is a%2",

	["^[gG]e+[szb]+e?u*s*$"]	=	"By the goddess!",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"By the grace of Elune!",
},
[7]={
	["^[gG]od+%A"]		=	"Elune save us! ",
	["(%A)[gG]od+$"]		=	"%1! ",

	["^[oO]+[kK]+$"]			=	"Alu'dora",
	["^[kK][kK]+$"]			=	"Alu'dora",
	["^[kK]([%s%p]*)$"]				=	"Alu'dora",


	["^[tT][yY][tTyY]*(%A*)$"]		=	"Very kind of you%1",
	["^[tT]ha?n?[zxc]s?$"]		=	"Thank you",

	["^[yY]es$"]		=	"Ana'dona",
	["^[yY][ea]+h?$"]	=	"Ana'dona",

	["^[nN][jJ][^%a%s%d|?]+"]		=	"For Elune!",
	["^[gG]ood%s?[wW]ork%p*$"]		=	"For Kalimdor!",
	["^[gG]ood%s?[jJ]ob%p*$"]		=	"Elune smiles upon us!",
	["^[gG]ood%s[gG]ame$"] = "At long last, the end is at hand.",

	["^[nN]ice%s?[tT]ry$"]	=	"A noble effort",
	["^[nN]ice%s?[tT]ry%p+$"]	=	"A fine display of valor!",


	["^[gG][lL](%A*)$"]			=	"Ana'duna thera%1",


--	Replace woot, WOOOOOOT, w00t and WOOHAA
	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1ana'doreini tala%2",
	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 For Kalimdor!",
	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	", ana'doreini tala!",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]		=	"Ana'doreini tala%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]			=	"For Kalimdor! ",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"Ana'doreini tala!",
	["^[bB][o0]+y+a+h*"]				=	"For the Kaldorei!",


	["%f[%a][gG]o%s?[gGo][gGo%s%p]+%f[%A]"]	=	"andu%-falah%-dor!",

	["^[hH]ello$"]				=	"Ishnu'alah",
	["^[yY][oO][yYoO]*[^%a%d|?]+"]	=	"Elune be with you, ",
	["^[yY][oO][yYoO]*$"]	=	"Ishnu'alah!",
	["[sS]+h?u+p+$"]			=	"Elune%-adore",
	["^[sS]ee%syou$"]	=	"Ande'thoras%-ethil",

	["^[iI]?[dDfF][ou]+n+o+(%A)"]	=	"I do not know%1",
	["^[iI]?[dDfF][ou]+n+o+$"]	=	"Alas, I know not",


	["^[bB]ye[^%d%a?]*$"]		=	"Asha'falah",
	["^[tT]ake%s?[cC]are[^%d%a?]*$"]		=	"En'shu falah%-nah",

	["^[iI]+[nN]+[cC]+$"]		=	"Prepare for battle!",

	["^[lL][oO0][lLoO0]+%p*$"]	=	"How amusing",



},
[8]={
	["^(%a+)'?s%salways%s"]		=	"Ever has %1 ",
	["^(%a%a-)'?ve%salways%s"]		=	"Ever have %1 ",

--	Experimental archaicisms. Might be too much...
	["([tT])here[%si']+s%snothin[g']%s(%a+)%sth[ae]n"]	=	"%1here is naught %2 than",
	["^[nN]othin[g']?s%s+(%a+)%sth[ae]n"]			=	"Naught is %1 than",
	["(%A)[nN]othin[g']?s%s+[tT]o%s(%a%a%a)"]			=	"%1naught to%2",
--	["[wW]hat%sfor"]			=	"for what",
--	["(%A)[oO]ver%s?[tT]here$"]	=	"%1out yonder",
--	["(%A)[oO]ver%s?[hH]ere$"]	=	"%1hither",
	["(%A)[rR]ight%sbefore%s"]		=	"%1just ere ",
	["^[sS]h?oo+n(%A+%a+%A+%a+%A+%a+)"]			=	"Before long%1",
	["(%a+%A+%a+%A+%a+%A)[sS]h?oo+n(%A*)$"]			=	"%1before long%2",

},
[13]={
--	Expand contractions for formal, archaic feel
	["^(.+)$"]		=	expandeverything,
},
[14]={
	["(%A)[cC]ongratulations%s([oO]n%s)"]		= "%1you are to be commended%2",

	["(%A)[wW]ant%s[tT]o(%A)"]	=	"%1wish to%2",
	["(%A)[wW]ants%s[tT]o(%A)"]	=	"%1wishes to%2",

	["(%A)[gG]et(%s%a%a%aer%A)"]	=	"%1wishes to%2",

	["(%A)[iI]'ll(%A)"]	=	"%1I shall%2",

	["(%A)[bB]ecause%s([^%p%s%doO]+%A+%a+%A+%a)"]		=	"%1for %2",

},
[15] = {

	["(%A)[cC]ongratulations(%A)"]			= "%1Elune smiles upon you%2",

	["^[sS]hould%s[iI]%s(%a%a%a%a.-)%?$"]		=	"Ought I to %1",
	["^[sS]hould%s[wW]e%s(%a%a%a%a.-)%?$"]		=	"Ought we to %1",

	["(%A)[iI]%s[rR]eally%s[wW]ish%s[tT]o(%A)"]	=	"%1I should dearly like to%2",
	["(%A)[rR]eally%s[wW]ishes%s[tT]o(%A)"]	=	"%1longs to%2",
	["(%A)[dD]oesn't%s[wW]ish%s[tT]o(%A)"]	=	"%1is loth to%2",

	["(%A%a+)'ve(%A)"]		=	"%1 have%2",
	["(%A%a+)'ll(%A)"]		=	"%1 will%2",
	["(%A%a+)'d(%A)"]		=	"%1 would%2",

},

}

Elo.RaceFilter[4]={
[1]={
},
[2]={
	["(%A)[dD]'?o+h+%A"]	=	"%1fiddlesticks! ",
	["(%A)[dD]'?u+h+%A"]	=	"%1how obvious! ",
	["(%A)[gG][ae]+h+%A"]		=	"%1fiddlesticks! ",
	["(%A)[mM]y%s?[gG][ao]+w?d(%A)"]		=	"%1goodness gracious me! %2",
	["(%A)[tT]hank%s?[gG][ao]+w?d(%A)"]		=	"%1thank the lucky stars%2",
	["(%A)[rR]+a+w+r+(%A)"]		=	"%1waahoo! %2",

	["(%A)[tT]ot[auo]l+e?y(%A)"]	 	=	"%1incontestibly%2",

	["(%A)[yY]+a+[yY]+(%A)"]		=	"%1magnificent!%2",

	["(%A)[hH]oly%s?shit[^%a%d|?]+"]		=	"%1I'm astounded! ",
	["(%A)[hH]oly%s?[cC]rap[^%a%d|?]+"]		=	"%1what an anomaly! ",
	["(%A)[hH]oly%s?[fF]uc?k[^%a%d|?]+"]		=	"%1it boggles the mind! ",

	["(%A)[sS]h?o+%sfucking(%A)"]	=	"%1unequivocally%2",
	["(%A)[iI]t'?s%sfucking(%A)"]	=	"%1its%2",
	["(%A)[sS]h?uch%sfucking(%A)"]	=	"%1such ignominious%2",
	["(%A)[jJ]ust%sfucking(%A)"]	=	"%1just%2",
	["(%A)[yY]ou%sfucking(%A)"]	=	"%1you%2",
	["(%A)[aA]%sfucking(%A%a)"]		=	"%1a dratted%2",
	["(%A)[tT]he%sfucking(%A%a)"]		=	"%1the wretched%2",
	["(%A)[iI]%sfucking(%A)"]		=	"%1indeed I%2",
	["(%A)[tT]hat%sfucking(%A)"]	=	"%1that abominable%2",
	["(%A)[tT]h([ieo]se?)%sfucking(%A)"]	=	"%1th%2 dratted%3",
	["(%A)[tT]hat'?s%sfucking(%A)"]	=	"%1that's positively%2",
	["(%A)fucking%s(%a%a-ing%A)"]	=	"%1%2",

--	["(%A)[bB]ad[%s%-]?[aA@][sS%$][sS%$]([%s!,.]+%a)"]		=	"%1formidable%2",
	["(%A)[bB]ad[%s%-]?[aA@][sS%$][sS%$]%s$"]		=	"%1state%-of%-the%-art",
	["(%A)[bB]ig+[%s%-]?[aA@][sS%$][sS%$]%s(%a+%A)"]		=	"%1humongous %2",
	["(%A)[hH]u+ge[%s%-]?[aA@][sS%$][sS%$]%s(%a+%A)"]	=	"%1stupendous %2",
	["(%A)[lL]ong[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1extraordinarily prolonged%2",
	["(%A)[sS]h?low[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1decelerated%2",
	["(%A)[wW]i[sz]e[%s%-]?[aA@][sz%$][sz%$](%A)"]		=	"%1wise%-cracker%2",
	["(%A)[lL]ame[%s%-]?[aA@][sS%$][sS%$](%A)"]			=	"%1ineffectual%2",
	["(%A)[wW]eak[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1insipid%2",
--	["(%A)[dD]um+b?[%s%-]?[aA@][sz%$][sz%$]e?([sz]*%A)"]		=	"%1nitwit%2",
--	["(%A)[sS]h?[tu]+p+id%A*[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"%1fool%2",

	["(%A)[bB][rR][tT](%A)"]	=	"%1be there post%-haste%2",


	["(%A)[bB][tT][wW](%A)"]	=	"%1, parenthetically speaking, %2",

	["(%A)[eE][tT][cC](%A)"]	=	"%1and so on and so forth%2",

	["(%A)[bB][rR][bB](%A)"]	=	"%1be back momentarily%2",
	["(%A)[aA]sap(%A)"]	=	"%1as soon as gnomishly possible%2",
	["(%A)[aA][tT][mM](%A)"]	=	"%1at this juncture in time%2",

	["(%A)[lL]otsa(%A)"]		=	"%1a veritable cornucopia of%2",
	["(%A)[lL]ots%s?of(%A)"]		=	"%1a significant quantity of%2",
	["(%A)[lL]ot+a(%A)"]	=	"%1unequivocal abundance of%2",


},
[3]={
	["(%A)[wW]t[fh]+%s*[iI]s(%A)"]	=	"%1what, precisely, is%2",
	["(%A)[wW]t[fh]+%s*[aA]?r?e(%A)"]	=	"%1just what are%2",
	["(%A)[wW]t[fh]+%s*[wW]a[sd]+(%A)"]	=	"%1what in all the universe was%2",
	["(%A)[wW]t[fh]+%s*[wW]ere?(%A)"]	=	"%1what precisely were%2",
	["(%A)[wW]t[fh]+%s*[wW]il+(%A)"]	=	"%1what exactly will%2",
	["(%A)[wW]t[fh]+%s*([dD]o[es]*%A)"]	=	"%1exactly what %2",
	["(%A)[wW]t[fh]+%s*[dD]id?(%A)"]	=	"%1precisely what did%2",

	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1Now that's a humdinger!%2",

	["(%A)[lL]ike%s[cC]raz+y+(%A)"]	=	"%1like nobody's business%2",


},
[5]={
	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"Hmm%? Sensors indicate I've attained level %1...",
},
[6]={
	["^[._%-%^%s]*[oO0@][._%-%^][oO0@]"]	=	"How anomalous. ",
	["([%p%a]%a)[%s%p]*[._%-%^%s]*[oO0@][._%-%^][oO0@]$"]	=	"%1%. Quite absurd!",

	["^[QtT][oO0%._]?[QtT]%s+"]		=	"Phooey! ",
	["^[QtT][oO0%._]?[QtT]$"]		=	"Tragedy rears its ugly head",
	["^[wW]+$"]		=	"Phwaaha!",
	["^[;:>%-=*]+%[%s*"]		=	"Fiddle%-faddle%. ",
	["^[;:>%-=*]+%(%s*"]		=	"Fiddle%-faddle%. ",
	["^[>=][_%-.o]?<"]		=	"Preposterous! ",
	["^[;:>=%-*]+/%s*"]			=	"Pity%. ",
	["^[;:>=xX%-%s]*[%)DdbBpP%s]+$"]		=	"haha!",
	["^[;:>=xX%-%s]*[%)DdbBpP]+%s(%a%a)"]		=	"Well! %1",
--	["^[;:>=xX%-*%s]+[oO]"]			=	"My word! ",
	["^[;:=xX]+$"]			=	"It boggles the mind!",
	["^%-[._]%-$"]			=	"Boredom leads to drowsiness, I've read",
--	["(%w)%s[wW]$"]			=	"%1",
	[";+$"]					=	"%.",
	[";_;"]					=	" Pity! ",
	["^[(;:]*^%p-[%^][);:/]*$"]	=	"Heheheh!",

	["^[(;:]*^%a*[%^][);:/]*$"]	=	"I am all smiles!",


	["^[dD]a+[mn]+[%s%p]+[iI]%s"]		=	"Goodness gracious, I ",
	["^[fF]uck+[%s%p]+[iI]%s"]		=	"Phooey! I ",

	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"Go confusticate yourself!",

	["^[jJ]/?[kK]$"]			=	"That's what they call a \"joke\".",


	["^[wW]tf+%a*%s+"]	=	"Unacceptable! ",
	["^[wW]t[fh]+%a*[^%a%d|]+"]	=	"Astonishing! ",
	["(%p)[wW]t[fh]+$"]		=	"%1 Unthinkable!",
	["([%a%d])[%s!,.]+[wW]t[fh]+$"]		=	"%1%. How anomalous!",
	["(%A)[wW]t[fh]+(%A)"]	=	"%1what in all the cosmos%2",
	["^[wW]t[fh]+%a*$"]		=	"Astounding!",


--	Replace ZOMG, omfg, gawd, jeez, wtf, with various archaic expressions
	["^omg%a*%s"]		=	"Zounds! ",
	["^omg$"]	=	"Inconceivable!",
	["^omg%a+"]	=	"Goodness gracious!",
	["(%a)[%s!,.]+omg%f[%A]"]	=	"%1, by Gnomeregan!",
	["(%A)omg%a+"]	=	"%1gee willickers!",

	["(%a)[%s!,.]+omg$"]	=	"%1%. Good heavens!",



	["^[gG]od%s([^dD])"]		=	"Ye gads! %1",

	["^[gG]od(%p)"]	=	"By Gnomeregan%1",
	["^[gG]od$"]		=	"Widgets and dingbats!",
	["^[gGjJ]e+[szb]+e?u*s*[%s!,.]+(.*)"]	=	"Jumping juggernauts, %1",

	["(%A)[sS]hut%s[uU]p(%A)"]	=	"%1unplug that chatterbox%2",
	["^[sS]hut%s[uU]p[^%a%d|?]+"]		=	"Muffle that racket, ",
	["^[sS]hut%s[uU]p%s+"]		=	"Shut that noise-valve off, ",
	["(%A)[sS]hut%s[uU]p?$"]	=	"%1turn it down",
	["^[sS]hut%s[uU]p$"]		=	"I tire of your cacophony",

	["(%A)[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"nil",
	["^[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"nil",
	["(%A)[aA@][sz%$][sz%$]e?([sz]*)$"]	=	"nil",
	["^[aA@][sz%$][sz%$]e?([sz]*)$"]	=	"nil",

	["(%A)[aA@][sz%$][sz%$](e?[sz]*%A)"]	=	"%1apparatus%2",
	["^[aA@][sz%$][sz%$](e?[sz]*%A)"]	=	"Apparatus%1",
	["(%A)[aA@][sz%$][sz%$](e?[sz]*)$"]	=	"%1apparatus%2",
	["^[aA@][sz%$][sz%$](e?[sz]*)$"]	=	"Apparatus%1",

	["^[bB]i[yao]*t?[cs]h$"]		=	"Useless heap of scrap!",
	["^[bB]i[yao]*t?[cs]he?[sz]$"]	=	"Malfunctioning dingbats!",

	["^[fF][aou]+c?k(%p)"]	=	"Drat%1",
	["^[fFmM][aou]+c?k$"]		=	"Oh, confusticate it!",
	["^[fFmM]ucking%s?(%a%a%a%a-)[sz]$"]		=	"Such incommodious %1s!",
	["^[fFmM]ucking%s?(%a%a%a%a-)[sz](%A)"]		=	"Irksome %1s%2",
	["^[dD]a+n?m+n*%s(%a%a%a%a-)[sz]$"]		=	"Despicable %1s!",
	["^[dD]a+n?m+n*%s(%a%a%a%a-)[sz](%A)"]		=	"Nettlesome %1s%2",

	["[fF][aou]+w?c?ke?r"]		=	"dingbat",

	["^shit$"]		=	"Oh, fiddlesticks!",
	["^[cC]ra+p+$"]		=	"Split my sprockets!",
	["^[dD]a+[mn]+$"]	=	"Inconceivable!",
	["^[gG]e+[szb]+e?u*s*$"]	=	"Jeepers creepers!",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"Gee willickers!",

},
[7]={
	["^[iI][\"/;:`o]?[lL][lL]?(%A)"]			=	"Indeed I'll%1",
	["^[sS]h?[oO]*[rR]+[yY]$"]			=	"Infinitesimally sorry",

	["^[yY]es$"]		=	"Yes indeed",
	["^[yY][ea]+h?$"]	=	"Affirmative",

	["^no$"]			=	"Negative",

	["^[aA]%s?[mM]in$"]		=	"Just a nanosecond",

	["^[tT][yY][tTyY]*(%A*)$"]	=	"Thanks a trillion%1",
	["^[tT]ha?n?[zxc]s?$"]		=	"Very magnanimous of you",

	["^[yY][oO][yYoO]*[^%a%d|?]+"]	=	"Greetings, ",

	["^[yY][oO][yYoO]*$"]	=	"Salutations!",

	["^[bB]ye[^%d%a?]*$"]		=	"Off and away!",
	["^[tT]ake%s?[cC]are[^%d%a?]*$"]		=	"May your gadgets never fail",

	["^[sS]ee%syou$"]	=	"May your sprockets never rust!",

	["^[wW]ait$"]		=	"Just one microsecond",

	["^[gG]ood%s?[wW]ork%p*$"]		=	"Monumental work!",
	["^[nN][jJ][^%a%s%d|?]+"]		=	"A first-rate effort%. Bravo!",
	["^[gG]ood%s?[jJ]ob%p*$"]			=	"Phenomenal work!",
	["^[gG]ood%s[gG]ame$"] = "Well, good game.",

	["^[sS]h?e+r[ie]+[ou]+sl+y(%A)"]	=	"Indubitably%1",
	["^[sS]h?e+r[ie]+[ou]+sl+y$"]		=	"I heartily concur",

--	Replace woot, WOOOOOOT, w00t and WOOHAA
	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1yippee%2",
	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 For Gnomeregan!",
	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"! For Gnomeregan!",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]		=	"Hip-hip hurray%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]		=	"Hurray! ",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"How fortuitous!",
	["^[bB][o0]+y+a+h*"]				=	"For Gnomeregan!",


	["^[lL][oO0][lLoO0]+%p*$"]	=	"Hohoh!",
	["^[lL][oO0][lLoO0]+[zZ]+%p*$"]	=	"Ooh! That tickles my funny bone!",
	["^[lL][oO0][lLoO0]+[sS]+%p*$"]	=	"Hahoo, precious comedy!",
	["^[rR][oO0][tT]?[fF][lL]%a*%p*$"]	=	"Hoohoh, that cracks me up!",

	["^[iI]+[nN]+[cC]+$"]		=	"We've got incoming",
	["%f[%a][gG]o%s?[gGo][gGo%s%p]+%f[%A]"]	=	"full speed ahead!",

	["^[rR]eady%?"]		=	"Are preparations complete%?",
	["^[rR]eady!+"]		=	"I'm ready, able, and willing!",
	["^[rR]eady$"]		=	"All systems are go",

	["^[dD]on't%s[kK]now(%A)"]	=	"I'm afraid I don't know%1",
	["^[dD]on't%s[kK]now$"]	=	"I haven't got an inkling",

	["^[nN]eat[%s%poO]*$"]	=	"Neat-o",

	["^[cCkK][oO0][oO0]+[lL]?[sz]*$"]		=	"Fascinating",

	["(%A)[iI]%s?[gG]uess$"]	=	"%1, I suppose",
	["^[iI]?%s?[gG]uess%s?[sS]o$"]	=	"Well, I would suppose so",
	["^[iI]%s?[gG]uess%s?$"]	=	"Well, I suppose",


	["^[wW][au]n[nt]?[au]h?%?*$"]	=	"Well, what's your inclination%?",
	["^[pP]rob?[ou]?b?l+y$"]	=	"I would posit a high probability",

	["^[nN]ice%s?[tT]ry$"]			=	"Well, back to the drawing board, eh?",
	["^[nN]ice%s?[tT]ry%p+$"]			=	"If at first you don't succeed...try, try again!",


	["^[sS]+h?[au]*w+e+t+$"]		=	"Splendid",
	["[sS]+h?[au]*w+e+t+(%A)"]	=	"splendid%1",
	["(%A)[sS]+h?[au]*w+e+t+([^|%a][^|]*)$"]		=	"%1stellar%2",
	["(%A)[aA]w+e?some?"]	=	"%1spectacular",
	["^[aA]w+e?some?(%A)"]		=	"Extraordinary%1",
	["^[aA]w+e?some?$"]		=	"Extraordinary",

	["^[pP][pP][lL][eE]?$"]			=	"My intrepid colleagues%.%.%.",


	["%s[fF]or%s[tT]he%s[wW]in[^%a%d|?]+"]	=	" for favorable results every time%. ",
	["%s[fF]or%s[tT]he%s[wW]in$"]	=	" will always yield positive results! ",
	["%s[fF4][tT][lL]%p*$"]		=	" would never survive academic scrutiny",

},
[14] = {
	["(%A)[fF]ucking(%A)"]	=	"%1heinous%2",

	["(%A)[aA]%s[lL]ittle(%A)"]	=	"%1a modicum%2",
	["(%A)[aA]%s[bB]it(%A)"]	=	"%1a tidbit%2",

	["(%a%s)[nN]eed(s?%s[aA]%s%a%a)"]	=	"%1require%2",
	["(%a%s)[nN]eed(s?%s[tT]he%s%a%a)"]	=	"%1require%2",

	["(%a%s)[kK]eep(s?%s%a%a-ing%A)"]	=	"%1continue%2",
	["(%a%s)[kK]ept(%s%a%a-ing%A)"]	=	"%1continued%2",


},
[15]={

	["(%A)[cC]ongratulations(%A)"]	=	"%1congratulations are in order!%2",

	["(%a%s)[tT]ry%s[tT]o(%A%a%a)"]	=	"%1attempt to%2",
	["(%a%s)[tT]r[iy]ed%s[tT]o(%A%a%a)"]	=	"%1attempted to%2",
	["(%a%s)[tT]ryin['g]?%s[tT]o(%A%a%a)"]	=	"%1attempting to%2",


	["(%A)[oO]ften(%A)"]	=	"%1frequently%2",

	["(%a%s)[aA]gree(s?%A)"]	=	"%1concur%2",
	["(%a%s)[aA]greed(%A)"]	=	"%1concurred%2",
	["(%a%s)[aA]greeing(%A)"]	=	"%1concurring%2",

	["(%a%s)[bB]uy(s?%A)"]	=	"%1purchase%2",
	["(%a%s)[bB]ought(%A)"]	=	"%1purchased%2",
	["(%a%s)[bB]uy(ing%A)"]	=	"%1purchas%2",

	["(%A)[oO]r%s?[sS]omething(%A*)$"]	=	"%1or something to that effect%2",

	["(%A[aA])bout%s(%d)"]	=	"%1pproximately %2",

	["(%A)[tT]he%s[sS]ame%s[aA]s(%A)"]	=	"%1equivalent to%2",


},
}
--[[

May the light embrace you
Arkenon poros
Good fortune
The naaru have not forgotten us
The legion's end draws near
Warm wishes to you
Eash day is a blessing
Open your heart to the light

Remember the lessons of the past
Do not lose faith
Krona kai kristor (hi)
Dionis akah (bye)
Be kind to those less fortunate
Favor the road travelled by few
Blessings upon your family
Good health, long life.
May your days be long, and your hardships few
Be well
Safe journey
Remain vigilant

--]]


Elo.RaceFilter[5]={
[1]={
--	["^[%s~hHmM]*([,.!?]+)[%s~]*$"]	=	"Asur'thoraman%1",
},
[2]={
--	["(%A)[dD]'?u+h+%A"]	=	"%1it is as clear as moonlight.",

	["(%A)[mM]y%s?[gG][ao]+w?d(%A)"]		=	"%1by the light! %2",
	["(%A)[tT]hank%s?[gG][ao]+w?d(%A)"]		=	"%1thank the light%2",
--	["(%A)[rR]+a+w+r+(%A)"]		=	"%1Tor ilisar'thera'nal!%2",


--	["(%A)[lL]ast%s?[nN]ight(%A)"]	=	"%1yestereve%2",
--	["(%A)[hH]ead%s?bac?k(%A[tT]o)"]		=	"%1return%2",

},
[3]={
--	["(%A)[wW]t[fh]+%s*[yY]ou(%s%a%a%a-ing?%A)"]	=	"%1what in Elune's name are you%2",
	["(%A)[wW]t[fh]+%s*[iI]s(%A)"]	=	"%1what in the name of the naaru is%2",
	["(%A)[wW]t[fh]+%s*[aA]?r?e(%A)"]	=	"%1what in the light are%2",
--	["(%A)[wW]t[fh]+%s*[wW]a[sd]+(%A)"]	=	"%1whatever was%2",
--	["(%A)[wW]t[fh]+%s*[wW]ere?(%A)"]	=	"%1what in the name of Cenarius were%2",
--	["(%A)[wW]t[fh]+%s*[wW]il+(%A)"]	=	"%1whatever will%2",
--	["(%A)[wW]t[fh]+%s*([dD]o[es]*%A)"]	=	"%1what in the goddess's name %2",
--	["(%A)[wW]t[fh]+%s*[dD]id?(%A)"]	=	"%1what under the moon's gaze did%2",

--	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1How laughable!%2",

},
[5]={
--	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"Ana'doreini tala! I have reached Level %1!",
},
[6]={
--	["^[gG]od$"]		=	"Alas!",

--	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"May the goddess forgive you!",

--	["^[dD]a+[mn]+[%s%p]+[iI]%s"]		=	"Why, I ",
--	["^[fF]uck+[%s%p]+[iI]%s"]		=	"Alas! I ",

	["[fF][aou]+w?c?ke?r"]		=	"heathen",
	["^[sS]hut%s[uU]p[^%a%d|?]+"]		=	"Be silent, ",
	["^[sS]hut%s[uU]p$"]		=	"Silence is golden, my friend",
	["^[wW]t[fh]+%a*$"]		=	"By the naaru!",
	["^omg$"]	=	"In the name of naaru!",

--	"Its" is "It's" almost all the time when starting a line
	["^[iI]ts(%A)"]	=	"It is%1",

--	"its" followed by "the" two words later is usually "it's"
	["(%A[iI])ts%s(%a+)%s[tT]he(%A)"]	=	"%1t is %2 the%3",

--	Other common "it's" places
	["(%A[iI])ts%s[oO]nly(%A)"]	=	"%1t is only%2",
	["(%A[iI])ts%s[tT]oo(%A)"]	=	"%1t is too%2",
	["(%A[iI])ts%s[jJ]ust(%A)"]	=	"%1t is just%2",
	["(%A[iI])ts%s(%a%a-ing%A)"]	=	"%1t is %2",
	["(%A[iI])ts%s[nN]o([wtob%s])"]	=	"%1t is no%2",

	["(%A[iI])ts%s[tT]he(%A)"]	=	"%1t is the%2",
	["(%A[iI])ts%s[aA](n?%A)"]	=	"%1t is a%2",

	["^[gG]e+[szb]+e?u*s*$"]	=	"By the light!",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"By the light's glory!",
},
[7]={
--	["^[gG]od+%A"]		=	"Elune save us! ",
--	["(%A)[gG]od+$"]		=	"%1! ",

--	["^[oO]+[kK]+$"]			=	"Alu'dora",
--	["^[kK][kK]+$"]			=	"Alu'dora",
--	["^[kK]([%s%p]*)$"]				=	"Alu'dora",


--	["^[tT][yY][tTyY]*(%A*)$"]		=	"Very kind of you%1",
--	["^[tT]ha?n?[zxc]s?$"]		=	"Thank you",

--	["^[yY]es$"]		=	"Ana'dona",
--	["^[yY][ea]+h?$"]	=	"Ana'dona",

--	["^[nN][jJ][^%a%s%d|?]+"]		=	"For Elune!",
--	["^[gG]ood%s?[wW]ork%p*$"]		=	"For Kalimdor!",
--	["^[gG]ood%s?[jJ]ob%p*$"]		=	"Elune smiles upon us!",
	["^[gG]ood%s[gG]ame$"] = "And so the battle draws to a close.",


--	["^[gG][lL](%A*)$"]			=	"Ana'duna thera%1",


--	Replace woot, WOOOOOOT, w00t and WOOHAA
--	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1ana'doreini tala%2",
--	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 For Kalimdor!",
--	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	", ana'doreini tala!",
--	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]		=	"Ana'doreini tala%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]			=	"For the Exiled! ",
--	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"Ana'doreini tala!",
	["^[bB][o0]+y+a+h*"]				=	"Embrace the light's glory!",


--	["%f[%a][gG]o%s?[gGo][gGo%s%p]+%f[%A]"]	=	"andu%-falah%-dor!",

	["^[hH]ello$"]				=	"Arkenon poros",
	["^[yY][oO][yYoO]*[^%a%d|?]+"]	=	"Krona kai kristor, ",
	["^[yY][oO][yYoO]*$"]	=	"Good fortune!",
	["[sS]+h?u+p+$"]			=	"Krona kai kristor",
	["^[sS]ee%syou$"]	=	"Good health, long life",

--	["^[iI]?[dDfF][ou]+n+o+(%A)"]	=	"I do not know%1",
--	["^[iI]?[dDfF][ou]+n+o+$"]	=	"Alas, I know not",


	["^[bB]ye[^%d%a?]*$"]		=	"Remain vigilant",
	["^[tT]ake%s?[cC]are[^%d%a?]*$"]		=	"Favor the road travelled by few",

--	["^[iI]+[nN]+[cC]+$"]		=	"Prepare for battle!",

--	["^[lL][oO0][lLoO0]+%p*$"]	=	"How amusing",



},
[8]={
--	["^(%a+)'?s%salways%s"]		=	"Ever has %1 ",
--	["^(%a%a-)'?ve%salways%s"]		=	"Ever have %1 ",

--	Experimental archaicisms. Might be too much...
--	["([tT])here[%si']+s%snothin[g']%s(%a+)%sth[ae]n"]	=	"%1here is naught %2 than",
--	["^[nN]othin[g']?s%s+(%a+)%sth[ae]n"]			=	"Naught is %1 than",
--	["(%A)[nN]othin[g']?s%s+[tT]o%s(%a%a%a)"]			=	"%1naught to%2",
	["[wW]hat%sfor"]			=	"for what",
--	["(%A)[oO]ver%s?[tT]here$"]	=	"%1out yonder",
--	["(%A)[oO]ver%s?[hH]ere$"]	=	"%1hither",
--	["(%A)[rR]ight%sbefore%s"]		=	"%1just ere ",
--	["^[sS]h?oo+n(%A+%a+%A+%a+%A+%a+)"]			=	"Before long%1",
--	["(%a+%A+%a+%A+%a+%A)[sS]h?oo+n(%A*)$"]			=	"%1before long%2",

},
[13]={
--	Expand contractions for formal, archaic feel
	["^(.+)$"]		=	expandeverything,
},
[14]={
--	["(%A)[cC]ongratulations%s([oO]n%s)"]		= "%1you are to be commended%2",

--	["(%A)[wW]ant%s[tT]o(%A)"]	=	"%1wish to%2",
--	["(%A)[wW]ants%s[tT]o(%A)"]	=	"%1wishes to%2",

--	["(%A)[gG]et%s(%a%a%aer%A)"]	=	"%1wishes to%2",

	["(%A)[iI]'ll(%A)"]	=	"%1I shall%2",

--	["(%A)[bB]ecause%s([^%p%s%doO]+%A+%a+%A+%a)"]		=	"%1for %2",

},
[15] = {

--	["(%A)[cC]ongratulations(%A)"]			= "%1Elune smiles upon you%2",

--	["^[sS]hould%s[iI]%s(%a%a%a%a.-)%?$"]		=	"Ought I to %1",
--	["^[sS]hould%s[wW]e%s(%a%a%a%a.-)%?$"]		=	"Ought we to %1",

--	["(%A)[iI]%s[rR]eally%s[wW]ish%s[tT]o(%A)"]	=	"%1I should dearly like to%2",
--	["(%A)[rR]eally%s[wW]ishes%s[tT]o(%A)"]	=	"%1longs to%2",
--	["(%A)[dD]oesn't%s[wW]ish%s[tT]o(%A)"]	=	"%1is loth to%2",

	["(%A%a+)'ve(%A)"]		=	"%1 have%2",
	["(%A%a+)'ll(%A)"]		=	"%1 will%2",
	["(%A%a+)'d(%A)"]		=	"%1 would%2",

},

}
end


