

Elo.Sanitizer={
[1]={


	["(%A)[hH]el+[sz%s]*[yY]e?ah?(%A)"]		=	"%1woot%2",
	["(%A)[fF][uo0*!@#$%^][ck]+%s?[yY]e?ah?(%A)"]	=	"%1woot%2",


	["(%A)[fF][fF][sS](%A)"]	=	"%1for crying out loud%2",
	["(%A)[dD]a[mn]+%s?[gG]ood(%A)"]			=	"%1superior%2",
	["(%A)[dD]a[mn]+%s?[rR]ight(%A)"]			=	"%1absolutely%2",
	["(%A)[dD]a[mn]+%s?[sS]traight(%A)"]			=	"%1that's right%2",
	["(%A)[zZ]*[oO]+[hHfF]*[mM]+[hHfF]*[gG]+(%A)"]	=	"%1omg%2",

--	["(%A)[fF]uc?ke?n(%A)"]	=	"%1fucking%2",
--	["(%A)[fF]ing(%A)"]	=	"%1fucking%2",
--	Standardise spelling
	["[fF]a+w+[ck]+"]			=	"fuck",
	["(%A)[fF][o0][o0]+[ck]+"]			=	"%1fuck",
	["(%A)[fF][!@#$%^&*][ck]+"]			=	"%1fuck",
	["(%A)[fF][uea*!@#$%^&*]c+k+"]			=	"%1fuck",
	["(%A)[fF][uea*!@#$%^&*]k+[ck]+"]			=	"%1fuck",
	["(%A)[fF][*!@#$%^'&*]+[kK]*[iI]?[gGnN]+(%A)"]			=	"%1fucking%2",
	["(%A)[sScC]h[1iy!*]+[ae]?te?(%A)"]	=	"%1shit%2",
	["(%A)[sScC]h[1iy!*]+[ae]?te?ing?(%A)"]	=	"%1shitting%2",
	["(%A)[fF]rea[ck]+[ie]n['g]*(%A)"]	=	"%1fucking%2",
	["(%A)[fF]kin['g]*(%A)"]	=	"%1fucking%2",
	["(%A)[fF]r?[eiu]+[gck]+[ie]n['g]*(%A)"]	=	"%1fucking%2",
	["(%A)[fF]r?[eiu]+[ck]+n['g]*(%A)"]	=	"%1fucking%2",
	["(%A)[eE]f+[ie]?n['g]?(%A)"]	=	"%1fucking%2",
	["(%A)[fF]'?[dD]'?%s?[uU]p(%A)"]	=	"%1fucked up%2",

	["(%A)[uU][fF]r?[eiu]+[gck]+[ie]n['g]*(%A)"]	=	"%1you fucking%2",


	["(%A)[mM][ou]th[ea]*[hr]*%A*[fF][aou]+w?c?k[eau]n[g']?(%A)"]		=	"%1fucking%2",
	["(%A)[mM][ou]th[ea]*[hr]*%A*[fF][aou]+w?c?k[eau]+[rh]?(%A)"]		=	"%1fucker%2",

	["(%A)[iI]%s?[sS]w[ear]+%s[tT][ao]%s[gG][oa]w?d(%A)"]	=	"%1I swear%2",

	["^[oOhH%s]*[fFmM]ucking%s+(%a%a%a-[^%d%s%ps])[^%a%d?]*$"]		=	" %1! ",

	["^%s*[pP]i[ss]+%s?of+(%A)"]		=	" Begone%1",

	["(%A)[gG][oO][dD]+%s*[fF]orbid(%A)"]	=	"%1heaven forbid%2",

	["(%A)[gG][oO]+%s*[sS]crew+%s(%a%a%a-)self"]	=	"%1fuck %2",
	["(%A)[gG][oO]+%s*[bB]low+%s(%a%a%a-)self"]	=	"%1fuck %2",

	["(%A)[gGjJ]e+[sz]+u+s+%s*[cC]h?rist(%A)"]	=	"%1geez%2",

},

[2]={
	["(%A)[wW]hat%s?[tT]he%s*fuck(%A)"]		=	"%1wtf%2",
	["(%A)[wW]hat%s?[tT]he%s*[hH]el+(%A)"]		=	"%1wth%2",
	["(%A)[gGjJ]e+[sz]+u+s+%s*[fF]ucking%s*[cC]h?rist(%A)"]	=	"%1geez%2",


	["(%A)[sS]h?w[ear]+%s[tT][ao]%s[gG][oa]w?d(%A)"]	=	"%1by the gods%2",
	["(%A)[gG]tfo(%A)"]		=	"%1get off%2",
	["(%A)[sS]h?ftu(%A)"]				=	"%1shut up%2",
--	["(%A)[pP]us+[yie]+([sz]*%A)"]		=	"nil",
	["(%A)[rR]?[e-]?tard([sz]*%A)"]		=	"%1fool%2",
	["(%A)[rR]etarde?d(%A)"]		=	"%1hare%-brained%2",
	["(%A)[fF]u[ck]+tard([sz]*%A)"]				=	"%1knave%2",
	["(%A)[mM][ou]th[ea]*[hr]*%A*[fF][aou]+w?c?k[ear][rh]?(%A)"]		=	"%1muck%-raker%2",
	["(%A)[nN]ig+([sz]*)(%A)"]			=	"%1ne'er%2%-do%-well%3",
	["(%A)[nN]ig+[eaui][rh]*([sz]*%A)"]			=	"%1rapscallion%2",
	["(%A)[aA@][sz%$][sz%$]%s?hat([sz]*%A)"]		=	"%1imbecile%2",
	["(%A)[aA@][sz%$][sz%$]%s?load([sz]*%A)"]		=	"%1vast load%2",
	["(%A)[aA@][sz%$][sz%$]%s?ton([sz]*%A)"]		=	"%1ton%2",
	["(%A)[sS]hite?%s?head([sz]*%A)"]	=	"%1mutton%-head%2",
	["(%A)[sS]hite?%s?to%s?do(%A)"]	=	"%1errands to run%2",
	["(%A)[dD][ui][mpb]+%s?[sScC]h[1iy!*]+a?te?([sz]*%A)"]	=	"%1dimwit%2",
	["(%A)[dD]um+b?[fFmM]u[c]?k([sz]*%A)"]	=	"%1nitwit%2",
	["(%A)[dD]ic?k%s?he[a]?d([sz]*%A)"]		=	"%1halfwit%2",
	["(%A)[cC]lu[st]+er%s?fu?c?k([sz]*%A)"]	=	"%1mishmash%2",
	["(%A)[dD][ou]+che?[%p%s]?bag([sz]*%A)"]		=	"%1dung%-heap%2",
	["(%A)[dD][ou]+che?([sz]*%A)"]		=	"%1dung%-pile%2",
	["(%A)[aA@][sz%$][sz%$]+%s?hole?([sz]*%A)"]		=	"%1idiot%2",
	["(%A)[aA@][sz%$][sz%$]+%s?wipe?([sz]*%A)"]		=	"%1dung%-eater%2",
	["(%A)[hH]oly%s?shit[^%a%d|?]+"]		=	"%1impossible! ",
	["(%A)[hH]oly%s?[cC]rap[^%a%d|?]+"]		=	"%1unthinkable! ",
	["(%A)[hH]oly%s?[fF]uc?k[^%a%d|?]+"]		=	"%1unbelievable! ",

	["(%A)[aA]%s*[dD]ick(%A)"]		=	"%1a stinking knave%2",
	["(%A)[dD]ick[sz](%A)"]		=	"%1crude scamps%2",


	["(%A)[sS]h?on([sz]*)%sof%sa?%s?[bB]i[yao]*t?[cs]he?[sz](%A)"]	=	"%1half%-breed%2%3",

	["(%A)[tT]hi[sS%s]+h[1iIy!]+a?t(%A)"]		=	"%1this%2",
	["(%A)[tT]hat%s?[sS]+h[1iIy!]+a?te?(%A)"]	=	"%1that%2",

	["the%sshit+%sout%sof(%A)"]	=	"some sense into%1",


	["(%A)[bB]u+l+%s?shit(%A)"]	=	"%1nonsense%2",
	["(%A)[bB]u+l+%s?[cC]rap(%A)"]	=	"%1rubbish%2",

	["(%A)[lL]oad([sz]*)%s[oO]f%s[sS]hit(%A)"]		=	"%1foul deception%2%3",

	["(%A)[sS]hite?%s?load(%A)"]		=	"%1lot%2",
	["(%A)[sS]hite?%s?load[sz](%A)"]		=	"%1huge numbers%2",
	["(%A)[fF][ou]+%s?c?k%s?load(%A)"]		=	"%1tremendous amount%2",
	["(%A)[cC]rap%s?load(%A)"]		=	"%1remarkable amount%2",
	["(%A)[sS]h?care?([ds]?)%s(%a+)%sshitles+(%A)"]	=	"%1scare%2 %3 stiff%4",
	["(%A)[sS]h?care?d%s?shitles+(%A)"]				=	"%1terror%-stricken%2",

	["(%A)[gG]h?[ae]+y+(%A)"]		=	"%1feckless%2",
	["(%A)[fF]ag+[oieau]?t?([sz]*%A)"]		=	"%1maggot%2",
	["(%A)[fF]gt([sz]*%A)"]			=	"%1moron%2",
	["(%A)[pP]rick([sz]*%A)"]			=	"%1arrogant fool%2",
	["(%A)[pP]unk([sz]*%A)"]			=	"%1scoundrel%2",
	["(%A)[pP]e+n[ieua]s+(%A)"]		=	"%1pecker%2",
	["(%A)[cC]o*c+k+(%A)"]		=	"%1shaft%2",

	["(%A)[sS]ol(%A)"]		=	"%1completely out of luck%2",
	["(%A)[jJ]wf(%A)"]		=	"%1doomed%2",

	["(%A)[tT]h([aeio][st]?e?)%s?da[mn]+(%A)"]	=	"%1th%2 rotten%3",
--	Added more conditions for 'bs' now that it means 'blacksmith' in Arathi Basin.
	["(%a)t'?s%s[bB][sS](%A)"]	=	"%1s rubbish%2",
	["(%A)such%s?[bB][sS](%A)"]	=	"%1such stupidity%2",

	["(%A)[dD]ic?k(%A)"]	=	"%1snake%2",

	["(%A)[fF]u+c?k%s?[nN]o+[^%a%d|?]+"]		=	"%1not while life is still in me! ",

	["(%A)[fF]u?c?k?%s[iI]t(%A)"]		=	"%1forget it%. %2",
	["(%A)[bB]ad[%s%-]?[aA@][sS%$][sS%$]([%s!,.]+%a)"]		=	"%1formidable%2",
	["(%A)[bB]ad[%s%-]?[aA@][sS%$][sS%$]%s$"]		=	"%1stalwart",
	["(%A)[bB]ig+[%s%-]?[aA@][sS%$][sS%$]%s(%a+%A)"]		=	"%1enormous %2",
	["(%A)[hH]u+ge[%s%-]?[aA@][sS%$][sS%$]%s(%a+%A)"]	=	"%1gigantic %2",
	["(%A)[lL]ong[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1lengthy%2",
	["(%A)[sS]h?low[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1slow%2",
	["(%A)[wW]i[sz]e[%s%-]?[aA@][sz%$][sz%$](%A)"]		=	"%1fool%2",
	["(%A)[cC]heap[%s%-]?[aA@][sS%$][sS%$](%A)"]			=	"%1cheap%2",
	["(%A)[lL]ame[%s%-]?[aA@][sS%$][sS%$](%A)"]			=	"%1feeble%2",
	["(%A)[wW]eak[%s%-]?[aA@][sz%$][sz%$](%A)"]			=	"%1feckless%2",
	["(%A)[dD]um+b?[%s%-]?[aA@][sz%$][sz%$]e?([sz]*%A)"]		=	"%1nitwit%2",
	["(%A)[sS]h?[tu]+p+id%A*[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"%1fool%2",

	["(%A)[pP]ain%s?[iI][mn]%s?[tT]he%s?[aA@][sS%$][sS%$](%A)"]			=	"%1headache%2",


	["(%A)fucking%s?[cC]razy(%A)"]	=	"%1mad%2",

	["(%A[sS]?[wWhH])e%sfucking(%A)"]	=	"%1e absolutely%2",

	["(%A)[sS]h?o+%sfucking(%A)"]	=	"%1incredibly%2",
	["(%A)[iI]t'?s%sfucking(%A)"]	=	"%1its%2",
	["(%A)[sS]h?uch%sfucking(%A)"]	=	"%1such%2",
	["(%A)[jJ]ust%sfucking(%A)"]	=	"%1just%2",
	["(%A)[yY]ou%sfucking(%A)"]	=	"%1you%2",
	["(%A)[aA]%sfucking(%A%a)"]		=	"%1a%2",
	["(%A)[tT]he%sfucking(%A%a)"]		=	"%1the blasted%2",
	["(%A)[iI]%sfucking(%A)"]		=	"%1I%2",
	["(%A)[tT]hat%sfucking(%A)"]	=	"%1that wretched%2",
	["(%A)[tT]h([ieo]se?)%sfucking(%A)"]	=	"%1th%2 vile%3",
	["(%A)[tT]hat'?s%sfucking(%A)"]	=	"%1that's terribly%2",
	["(%A)fucking%s(%a%a-ing%A)"]	=	"%1%2",



--	When given too much information...
	["(%A[tT][ao]+k%a+)%sa%s[dD]ump(%A)"]	=	"%1 a breather%2",
	["(%A[tT][ao]+k%a+)%sa%sshit(%A)"]	=	"%1 a break%2",
	["(%A[tT][ao]+k%a+)%sa%s[pP]is+(%A)"]	=	"%1 a brief rest%2",
	["(%A[tT][ao]+k%a+)%sa%s[pP][e3][e3]+(%A)"]	=	"%1 a short rest%2",
	["(%A[tTgG]o+)%s[pP][e3][e3]+(%A)"]	=	"%1 rest awhile%2",
	["(%A[tTgG]o+)%sshit(%A)"]	=	"%1 rest%2",

	["(%A)[fF]uck?([edings]*)%swith?(%A)"]	=	"%1toy%2 with%3",

	["(%A)[bB]it?[cs]h(%a+)%s[aA]t(%A%a%a)"]	=	"%1howl%2 at%3",


},

[3]={
	["(%A)[tT][eh][eh]%s?[sS]+h[1iIy!]+a?te?(%A)"]	=	"%1the best%2",
	["(%A)[tT][eh][eh]%s?[cC]+[rR][aA]+[pP](%A)"]	=	"%1the rubbish%2",

	["(%A)[gG]od%s?[dD]amned(%A)"]		=	"%1infernal%2",
	["(%A)[gG]od%s?[dD]amn(%A)"]			=	"%1blast%2",


	["(%A)[sS]crew+%s?[yY]ou"]	=	"%1fuck you",

	["(%A)[wW]t[fh]+%s*[yY]ou(%s[wW]ant%A)"]	=	"%1what do you%2",
	["(%A)[wW]t[fh]+%s*[yY]ou(%s%a%a%a-ing?%A)"]	=	"%1what in the world are you%2",
	["(%A)[wW]t[fh]+%s*[iI]s(%A)"]	=	"%1what in the blazes is%2",
	["(%A)[wW]t[fh]+%s*[aA]?r?e(%A)"]	=	"%1what in the world are%2",
	["(%A)[wW]t[fh]+%s*[wW]a[sd]+(%A)"]	=	"%1what in all creation was%2",
	["(%A)[wW]t[fh]+%s*[wW]ere?(%A)"]	=	"%1whatever were%2",
	["(%A)[wW]t[fh]+%s*[wW]il+(%A)"]	=	"%1what in the name of wonder will%2",
	["(%A)[wW]t[fh]+%s*([dD]o[es]*%A)"]	=	"%1whatever %2",
	["(%A)[wW]t[fh]+%s*[dD]id?(%A)"]	=	"%1what in Azeroth did%2",

	["(%A[gG]et)%s[yY]our%s[aA@][sz%$][sz%$](%A.-)%p*$"]	=	"%1%2 now!",
	["(%A[gG]et)%s[yY]our%s[bB]ut+(%A.-)%p*$"]	=	"%1%2 now!",

	["(%A)[cC]an't%s(%a+)%s[fF][euoi]r?%sshit(%A)"]			=	"%1can't %2 well at all%3",
	["(%A)[cC]ouldn't%s(%a+)%s[fF][euoi]+r?%sshit(%A)"]			=	"%1couldn't %2 if life depended on it%3",


	["(%A)[wW]t[bfh]bbq%a*(%A)"]	=	"%1mumbo%-jumbo%2",
	["(%A)[wW]t[bfh][po]wn[zx]*(%a*%A)"]	=	"%1trounce%2",

	["(%A)[tT](o+)%s?[fF]u[ck]+[ei]ng?(%A)"]		=	"%1t%2%3",

	["(%A)[yY]ou%A*[bB]i[yao]*t?[cs]he?([sz]*%A)"]	=	"%1you insect%2",

	["(%A)[bB]it?[cs]he?ing(%A)"]	=	"%1grumbling%2",
	["(%A)[oO]+h*%s?shit[^%d%a|]+"]	=	"%1oh, no! ",
	["(%A)[fF]r?[aeiu]+[gck]?[gk]+[ie]n['g]*%s(%a%a-ly%A)"]	=	"%1%2",
--	["(%A)[fFmM]r?[aeiu]+[gck]?[gk]+[ie]n['g]*(%a%a-in[g']?%A)"]	=	"%1%2",

	["(%A)[wW]hole%A*[fFmM]r?[aeiu]+[gck]?[gk]+[ie]n['g]*(%A%a)"]	=	"%1whole%2",

},

[5]={


--	Replace 'suck(s) ass' etc.
	["[sS][uU][cCkKxX]+([sSzZ]*)%s[aA@][sz%$][sz%$]"]			=	"sicken%1 me to the core",
	["([^nN]%s)[sS][uU][cCkKxX]+([sSzZ]*)%s[mM][yY]%s.*"]			=	"%1 disappoint%2 me",
	["[sS][uU][cCkKxX]+([sSzZ]*)%s[oO][nN]%s.*"]			=	"swallow%1 rusted nails",

	["[cC]an%s?[sSlL][iu][ck]+([sz]*)%s[mM]y.*"]	=	" can plunge%1 into a gaping chasm for all I care",
	["[sSlL][ui][ck]+([sz]*)%s[bB][aA][wWlL]+[sSzZ]"]			=	"disgust%1 me to the core",

	["[sSlL][ui][ck]+([sz]*)%ssnake"]			=	"make%1 me sick",
	["[sSlL][ui][ck]+([sz]*)%s[cC][o][cCkK]+"]			=	"make%1 me sick",

	["^[tT]he%s?[fF]uck[^%d%a?]*$"]		=	"What on earth%?",
	["^[tT]he%s?[fF]uck(%A+%a)"]		=	"What on earth%1",

--	["[^nN]%s[sSlL][ui][ck]+([sz]*)%s[mM]y%s.*"]			=	" leap from%1 a cliff for all I care",
	["[fF]uck?ing?%saru?oun[df]"]		=	"mucking about",

	["(%A)[mM]y%s[fF]r?[aeiu]+[gck]?[gk]+[ie]n['g]?%s?"]	=	"%1my blasted ",

	["(%A)[aA]%s[fF]r?[aeiu]+[gck]?[gk]+[ie]n['g]?%s?"]	=	"%1a ",
	["(%A)[tT]h(%a%a?)%s[fF]r?[aeiu]+[gck]?[gk]+[ie]n['g]?%s?"]	=	"%1th%2 infernal ",

	["^[dD]a+n?m+n*%s[tT]his(%A)"]		=	"Why, this%1",

	["^(%a+)[%s!,.]+[dD]a+[mn]+%s?[iI]t[%s%p]*$"]					=	"%1!",

	["(%a+%A+%a+%A+%a%a+)[%s%p]+[bB]i[yao]*t?[cs]h[^?%a]*$"]	=	"%1!",

--	["^[wW]t[fh]+%a*[^%a%d|]+(%a%a%a%a)"]	=	"What %1",

},

[6]={

--	Replace 'no shit'
	["^[nN][oO]%s?shit"]	=	"You don't say",
	["[gG]ive?([sz]*)%s?a%s?shit"]	=	"give%1 a whit",
	["[gG]ive?([sz]*)%s?a%s?[dD][aA][mMnN]+"]	=	"care%1",
	["[gG]ive?([sz]*)%s?a%s?fuck(%A)"]	=	"care%1 one bit%2",
	["[gG]ive?([sz]*)%s?a%s?fuck$"]	=	"care%1 one bit",


	["[mM]y%sshit"]		=	"my stuff",
	["[yY]our%sshit"]		=	"your stuff",
	["(%A)[fF]or%sshit(%p*)$"]		=	"%1at all%2",
	["(%A)[aA]nd%sshit(%p*)$"]		=	"%1and the rest%2",

	["[Gg][uo]+d%s?shit"]		=	"quality stuff",
	["(%A)[tT][oO]+%s?[dD][aA][mMnN]+%s(%a)"]		=	"%1far too %2",


--	For 'fuck this' etc
	["(%A)[fF]u?c?k?%s([tT][hH]%a)"]	=	"%1 forsake %2",
	["^[fF]u?c?k?%s([tT][hH]%a)"]	=	"I've had enough of %1",

	["^[bB]i[yao]*t?[cs]h(%A)"]	=	"That wretch%1",
	["^[bB]i[yao]*t?[cs]he?s+(%A)"]	=	"Wretches%1",
	["(%A)[bB]i[yao]*t?[cs]h$"]	=	"%1vermin",
	["(%A)[bB]i[yao]*t?[cs]he?([sz]*%A)"]	=	"%1grouse%2",
	["^[bB]i[yao]*t?[cs]h$"]		=	"That mongrel!",
	["^[bB]i[yao]*t?[cs]he?[sz]$"]	=	"Miserable wretches!",

	["^[dD]a+[mn]+%s[yY]ou(.*)!?$"]		=	"Curse you%1!",

	["^[dD]a+[mn]+%s([^tTIiyY])"]		=	"Blast, %1",

	["^[dD]a+n?m+n*%s([tT]h%a%a%a-)[sz]$"]		=	"Oh, %1s!",
	["^[dD]a+n?m+n*%s([tT]h%a%a%a-)[sz](%A)"]		=	"%1s%2",

	["^[dD]a+[mn]+[%s%p]+[iI]%s"]		=	"Why, I ",
	["^[fF]uck+[%s%p]+[iI]%s"]		=	"Blast! I ",



	["(%A)[sS]hut%s[uU]p(%A)"]	=	"%1shut your gob%2",
	["^[sS]hut%s[uU]p[^%a%d|?]+"]		=	"Silence, ",
	["^[sS]hut%s[uU]p%s+"]		=	"Quiet, ",
	["(%A)[sS]hut%s[uU]p$"]	=	"%1hold your tongue",
	["^[sS]hut%s[uU]p$"]		=	"I've heard enough!",


--	Replace ZOMG, omfg, gawd, jeez, wtf, with various archaic expressions
	["^omg%a*[^%a%d|?]+"]	=	"I'm shocked! ",
	["^omg%a*%s"]		=	"I don't believe it! ",
	["^omg$"]	=	"Words fail me!",
	["(%A)omg%a+"]	=	"%1by the gods!",
	["^omg%a+$"]	=	"Why, I'm speechless!",
	["(%a)[%s!,.]+omg%f[%A]"]	=	"%1, by the gods!",
	["(%a)[%s!,.]+omg$"]	=	"%1%. Amazing!",
	["[%s?]+omg"]	=	"%1? ",

	["^[gG]od%s([^dD])"]		=	"Alas! %1",
	["^[gG]od(%p)"]	=	"By the gods%1",
	["^[gG]od$"]		=	"Impossible!",
	["^[gGjJ]e+[szb]+e?u*s*[%s!,.]+(.*)"]	=	"By the gods, %1",
	["^[gG]e+[szb]+e?u*s*$"]	=	"Save us!",
	["^[jJ]e+[szb]+e?u*s*$"]	=	"Upon my soul!",

	["^[cC]hrist(%A)"]	=	"Bah!%1",

	["^[wW]tf+%a*%s+"]	=	"What? ",
	["^[wW]t[fh]+%a*[^%a%d|]+"]	=	"What the! ",
	["(%p)[wW]t[fh]+$"]		=	"%1 How awful!",
	["([%a%d])[%s!,.]+[wW]t[fh]+$"]		=	"%1, how can it be!",
	["(%A)[wW]t[fh]+(%A)"]	=	"%1what on Azeroth%2",
	["^[wW]t[fh]+%a*$"]		=	"Horrible!",



	["(%w)%s[hH]el+%sof%sa"]		=	"%1 remarkable",

	["(%a)d%sto%s?[hH]el+(%A)"]	=	"%1d beyond recognition%2",
	["all%sto%s?[hH]el+(%A)"]	=	"all to waste%1",
	["the%s[hH]el+%sout%sof(%A)"]	=	"some sense into%1",
	["the%s[fF]u+c*k+%sout%sof(%A)"]	=	"the snot out of %1",

	["(%A)[fFmM]uc?ks$"]		=	"%1dregs",




	["([%p%s])[fF][o0][o0]([%p%s])"]	=	"%1fool%2",
	["[fF][o0][o0]$"]				=	"fool",
	["^[fF][o0][o0]([%p%s])"]		=	"You fool%1",

	["^[fFmM]u+[ck]+%s?[yYou]+(%A)"]		=	"Away with you%1",
	["(%A)[fFmM]u+[ck]+%s?[yYou]+(%A)"]	=	"%1to hell with you%2",
	["(%A)[fFmM]u+[ck]+%s?[yYou]+$"]		=	"%1to hell with you!",
	["^[fFmM]u+[ck]+%s?[yYou]+$"]			=	"Away with you!",

	["^[fFmM]u+[ck]+%s?[mM]e+"]			=	"Oh, bother! ",

--	Replace 'mofo' and 'homo'
	["(%A)[hHmM][oO][mMfF][oO](%A)"]	=	"%1bastard%2",
	["^[hHmM][oO][mMfF][oO](%A)"]		=	"Bastard%1",
	["(%A)[hHmM][oO][mMfF][oO]$"]		=	"%1bastard",
	["^[hHmM][oO][mMfF][oO]$"]		=	"Vile wretch!",

	["^shit(%A)"]	=	"Blast!%1",
	["(%A)[sS]hit$"]	=	"%1filth",
	["(%A)[sS]hit(%A)"]	=	"%1filth%2",
	["^shit$"]		=	"Blast!",

	["^[cC]ra+p+(%A)"]	=	"Curses%1",
	["(%A)[cC]ra+p+$"]	=	"%1junk",
	["(%A)[cC]ra+p+(%A)"]	=	"%1garbage%2",
	["^[cC]ra+p+$"]		=	"Blast!",

	["[sScC]h[1iy!]+a?t+e?y+"]		=	"lousy",
	["[sScC]h[1iy!]+a?t+e?[iy]e?r"]	=	"fouler",
	["[sScC]h[1iy!]+a?t+e?ie?st"]	=	"foulest",

	["(%A)[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"%1arse%2",
	["^[aA@][sz%$][sz%$]e?([sz]*%A)"]	=	"Arse%1",
	["(%A)[aA@][sz%$][sz%$]e?([sz]*)$"]	=	"%1arse%2",
	["^[aA@][sz%$][sz%$]e?([sz]*)$"]	=	"Arse%1",

	["(%A)[dD]a+[mn]+%s?[iI]t(%A)"]			=	"%1blast it%2",
	["(%A)[dD]a+[mn]+%s?[iI]t$"]				=	"%1blast it",
	["^[dD]a+[mn]+%s?[iI]t$"]					=	"No!",



--	["(%A)[dD]a+[mn]+e?d(%A)"]	=	"%1accursed%2",

	["^[dD]a+[mn]+,+%s*"]		=	"Oh, ",
	["^[dD]a+[mn]+!+%s*"]		=	"Horrible! ",
	["^[dD]a+[mn]+%s(%a%a-[^sz])"]	=	"I don't believe it! %1",
	["^[dD]a+[mn]+$"]	=	"Unbelievable!",



	["^[fF][aou]+c?k(%p)"]	=	"Confound it%1",
--	["^[fFmM][aou]+c?k%s([^tT])"]	=	"Curses %1",
	["^[fFmM][aou]+c?k$"]		=	"Fate, I spit at you!",
	["^[fFmM]ucking%s?(%a%a%a%a-)[sz]$"]		=	"I detest such %1s!",
	["^[fFmM]ucking%s?(%a%a%a%a-)[sz](%A)"]		=	"Those infernal %1s%2",
	["^[dD]a+n?m+n*%s(%a%a%a%a-)[sz]$"]		=	"Those hideous %1s!",
	["^[dD]a+n?m+n*%s(%a%a%a%a-)[sz](%A)"]		=	"Those wretched %1s%2",

	["[fF][aou]+x+k?z?[o0]r"]	=	"ruin",
	["[fF][aou]+w?c?ke?r"]		=	"muck%-raker",

},

[7]={

	["(%A)[fF]u[cke]+d%s?(%a+)%sup"]	=	"%1ruined %2",
	["(%A)[fF]u[ck]+([ed]*)%s?up"]		=	"%1mess%2 up",
	["(%A)[fF]u[ck]+ing?%s?up"]		=	"%1messing up",
	["(%A)[sS]hitting%s?up"]		=	"%1messing up",
	["(%A)[fF]u[ck]+%A*ups"]		=	"%1indiscretions",
	["(%A)[fF]u[cke]+d(%p*)$"]		=	"%1doomed%2",

	["^[gG]od+%A"]		=	"By the gods! ",
	["(%A)[gG]od+$"]		=	"%1! ",

	["^[bB]i[yao]*t?[cs]h%p*$"]	=	"The swine!",
	["^[dD]a+n?m+n*%s[rRsS]t?ra?ight"]		=	"By all means",

	["[gG]a+wd+%A"]		=	"yegads! ",
	["(%A)[gG]a+wd+"]		=	"%1yegads! ",

	["^[dD]a+n?m+n*%s[tT]hat(%A%a%a-[^s]%A)"]		=	"That accursed %1",
	["^[dD]a+n?m+n*%s[tT]hat(%A%a+[^s])$"]		=	"That despicable %1",

--	["(%A)the%srotten(%A)"]	=	"%1the worst%2",

	["([wW]h%a+)%s[tT]he%s?[fFmM]uc?k%s([^?!]+)[?!]*"]	=	"%1 in the world %2%?",
	["([wW]h%a+)%s[tT]he%s?[hH]el+%s([^?!]+)[?!]*"]	=	"%1 in the blazes %2%?",
	["([hH]ow)%s[tT]he%s?[hH]el+%s([^?!]+)[?!]*"]	=	"%1 on Azeroth %2%?",
	["^[tT]he%s?[fFmM]uc?k%s(%a)"]		=	"What %1",
	["^[tT]he%s?[hH]el+%s(%a)"]		=	"What %1",
	["[fF]ul+%s?of%s?[fF]ilth"]		=	"insidious",
--	["[bB]lasted%swith"]	=	"toying with",

	["^[fF]ucking%s[aA]%A*$"]	=	"By the stars!",
},
[8]={
	["(%a%a%A)fucking(%A%a+%A*)"]		=	"%1%2",
},
[10]={
	["^(.+)$"]	=	Elo.AnalyzeProfanity,
},

[14]={
	["^%s[dD]a+n?m+n*%A*[iI]t%s"]		=	" Why, ",
	["^%s[dD]a+n?m+n*%s([^%s%p%dmM])"]		=	" Oh, %1",
	["(%A)[fF]u?c?k%s?[oO]ff+(%A)"]		=	"%1begone%2",
	["^(%A)[fF]ucking(%A)"]	=	"%1That%2",
	["(%A)[cC]an't%s(%a+)%sfilth(%A)"]			=	"%1can't %2 anything%3",
},
[15]={
	["(%A)[fF]ucking(%A)"]	=	"%1%2",

},
[18]={
	["^%s*[fFmM]uck%s+(%a+)"]		=	"A curse upon %1",
	["[fF][ou]+%s?c?k"]		=	"muck",
--	["[fF]ck"]		=	"muck",

},
};