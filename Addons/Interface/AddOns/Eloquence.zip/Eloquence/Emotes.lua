Elo.Emotes = {
[5] = {
--	Emotes
	["^[%s./]*[cC]heer%s*$"]	=	"woot",
	["^[%s./]*[gG]rin%s*$"]	=	"heheh",
	["^[%s./]*[lL]augh%s*$"]	=	"lol",
	["^[%s./]*[cC]lap%s*$"]	=	"good job",
	["^[%s./]*[aA]pplau[sd]+e?%s*$"]	=	"woot",
	["^[%s./]*[gG]olfclap%s*$"]	=	"I'm not impressed",
	["^[%s./]*[cC]ry%s*$"]	=	"T_T",
	["^[%s./]*[wW]eep%s*$"]	=	";_;",
	["^[%s./]*[wW]ave%s*$"]	=	"hi",
	["^[%s./]*[aA]gree%s*$"]	=	"seriously",
	["^[%s./]*[nN]ods?%s*$"]	=	"ditto",
	["^[%s./]*[aA]ngry%s*$"]	=	"grr",
--	["^[%s./]*[sS]pit%s*$"]	=	"fuck you",
	["^[%s./]*[fF]art%s*$"]	=	"I fart in your general direction!",
	["^[%s./]*[bB]lush%s*$"]	=	"You're making me blush",
	["^[%s./]*[bB]oggle%s*$"]	=	"wtf",
},
[6] = {
--	Translate ideogrammatic expressions as naturally as possible.
	["(%a.-)[.,!%s]+[;:>=x]+[%-%(%s]*[oODdbpPsS|%]%):]+%s*$"]		=	"%1!",
	["(%a.-)[.,!%s]+[%(;:]*%^[_%-.o%s]?[%^][%);:/]*$"]		=	"%1, if I may say so!",
	["(%a%a)[%s%p]-[;:>=8]+[%-%s*]*%(%s*$"]		=	"%1, alas...",
	["(%a%a)[%s%p]-[;:>=8]+[%-%s*]*[/\\]%s*$"]		=	"%1, unfortunately",
	["(%a%a)[%s%p]-[;:>=8]+[%-%s*]*%[%s*$"]		=	"%1, alas!",
	["(%a%a)[%s%p]-[>=]+[%-%s*]*%(%s*$"]		=	"%1, and I am truly saddened!",
	["(%a%a)[%s%p]+[QtT][oO0%._]?[QtT]%s*$"]		=	"%1, as bitter tears are shed",
	["(%a%a)[%s%p]-[._]%-[;,]*$"]			=	"%1, and my zeal is muted",
	["(%a%a)[%s%p]-[><][_%.%o][><]$"]		=	"%1!",

	["(%a%a)%s+[oO^`~0][%p%soO0]+$"]	=	"%1!",

	["^[._%-%^%s]*[oO0@][._%-%^][oO0@]"]	=	"How bizarre. ",
	["([%p%a]%a)[%s%p]*[._%-%^%s]*[oO0@][._%-%^][oO0@]$"]	=	"%1! Extraordinary!",

	["%s:[pPdD][%s%p]+"]		=	"! ",

	["(%a%s)[;:>%-=xX]+[DdbBpP%)%]]+%s"]	=	"%1! ",

	["^[QtT][oO0%._]?[QtT]%s+"]		=	"Alas! ",
	["^[QtT][oO0%._]?[QtT]$"]		=	"Alas!",
	["^[wW]+$"]		=	"Heheh!",
	["^[;:>%-=*]+%[%s*"]		=	"What a pity%. ",
	["^[;:>%-=*]+%(%s*"]		=	"How unfortunate%. ",
	["^[>=][_%-.o]?<"]		=	"Outrageous! ",
	["^[;:>=%-*]+/%s*"]			=	"Pity%. ",
	["^[;:>=xX%-%s]*[%)DdbBpP%s]+$"]		=	"haha!",
	["^[;:>=xX%-%s]*[%)DdbBpP]+%s(%a%a)"]		=	"Well! %1",
--	["^[;:>=xX%-*%s]+[oO]"]			=	"My word! ",
	["^[;:=xX]+$"]			=	"Baffling!",
	["^%-[._]%-;*$"]			=	"Zzz%.%.%.",
	["(%a[.%a!?%s]+);*%-[._]%-;*$"]			=	"%1",
--	["(%w)%s[wW]$"]			=	"%1",
	[";+$"]					=	"%.",
	[";_;"]					=	" Agony! ",
	["^[(;:]*^%p-[%^][);:/]*$"]	=	"Ah, joy!",

	["^[(;:]*^%a*[%^][);:/]*$"]	=	"I am all smiles!",

	["^=[%s=]+$"]			=	"One moment",

},
}