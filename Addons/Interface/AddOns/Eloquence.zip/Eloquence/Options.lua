local p = pairs
local checkBoxes = {
	{
		"Master",
		"EloOptions",
		"Elo_CheckButtonTemplate",
		"Enable"..Elo.Info.version,
		"EloOptions",
		6,
		-6,
		"Toggle the master switch.",
	},
	{
		"SelfOutgoing",
		"EloFilterSelfFrame",
		"Elo_CheckButtonTemplate",
		"Send Your Chat Filtered - Modifier Key:",
		"EloTextSelfWhisper",
		0,
		-24,
		"Apply filters to your messages "..Elo.Hue.white.."before|r you send them.",
	},
	{
		"SkipOOCSelf",
		"EloFilterSelfFrame",
		"Elo_CheckButtonTemplate",
		"Skip Self OOC",
		"Elo_Text_EscapeTag",
		128,
		6,
		"When your messages start with "..Elo.Hue.white.."OOC|r, don't apply filters."
	},
	{
		"Monster",
		"EloFilterOthersFrame",
		"Elo_CheckButtonTemplate",
		"Filter NPCs & Monsters",
		"EloTextOthersWhisper",
		0,
		-24,
		"Activate filters on chat from NPCs and monsters too.",
	},
	{
		"SkipOOCOthers",
		"EloFilterOthersFrame",
		"Elo_CheckButtonTemplate",
		"Skip Others' OOC",
		"Elo_checkbox_Monster",
		192,
		0,
		"When messages from others start with "..Elo.Hue.white.."OOC|r, don't apply filters."
	},

	{
		"MonsterLink",
		"EloLinksFrame",
		"Elo_CheckButtonTemplate",
		"Include NPCs & Monsters",
		"EloOptionsLinksButton",
		0,
		-32,
		"Enable chat links on chat from NPCs and monsters.",
	},

	{
		"CTRaidColors",
		"EloHeadersFrame",
		"Elo_CheckButtonTemplate",
		"Use CT Raid Colors",
		"Elo_Text_Colors",
		0,
		-48,
		"Use CT Raid-style class colors instead of the default Blizzard class colors.",
	},
	{
		"RandomColors",
		"EloHeadersFrame",
		"Elo_CheckButtonTemplate",
		"Random Color if Class is Unknown",
		"Elo_checkbox_CTRaidColors",
		0,
		-20,
		"Assign random colors to players until their classes are known. Otherwise they appear in grey.",
	},
	{
		"ColorInChat",
		"EloHeadersFrame",
		"Elo_CheckButtonTemplate",
		"Add Color to Chat",
		"Elo_checkbox_RandomColors",
		0,
		-20,
		"Colorize names of players classes when they appear inside chat messages.",
	},
	{
		"ChopRanks",
		"EloHeadersFrame",
		"Elo_CheckButtonTemplate",
		"Hide PvP Ranks in Headers",
		"EloOptionsHeaderButton",
		164,
		0,
		"Hide players' PvP ranks in the LocalDefense and WorldDefense channels.",
	},
	{
		"ChopServers",
		"EloHeadersFrame",
		"Elo_CheckButtonTemplate",
		"Shorten Server Names",
		"Elo_checkbox_ChopRanks",
		0,
		-20,
		"For headers of players from another server, replace the server name with a \""..Elo.Hue.white.."(*)|r\".",
	},
	{
		"AntiSpam",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"No Repeat Spam",
		"Elo_Text_Misc",
		0,
		-25,
		"If the same message from the same player appeared three lines ago or less, suppress it.",

	},
	{
		"NoBarrage",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"No Barrage Spam",
		"",
		0,
		-20,
		"When multiple messages come from the same player in the same second, suppress all messages after the first two.",
	},
	{
		"QuellDuel",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"No Drunk/Duel Messages",
		"",
		0,
		-20,
		"Supress announcements of player inebriation and duel results.",
	},
	{
		"StopJoin",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"No Channel Join Spam",
		"",
		0,
		-20,
		"Suppress announcements that appear when you or others join and leave channels.",
	},
	{
		"NoRaidSpam",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"No Raid Join Spam",
		"",
		0,
		-20,
		"Suppress announcements that appear when others join and leave raids.",
	},
	{
		"SquelchLoot",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"No Coin Spam",
		"",
		0,
		-20,
		"Supress coin messages whenever you're in a party or raid.",
	},
	{
		"DefeatChuck",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"No Chuck Norris Spam",
		"",
		0,
		-20,
		"Supress yells and default channel messages that mention popular action heroes, including \"your mom.\"",
	},

	{
		"BracketNuker",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"No Brackets",
		"",
		0,
		-20,
		"Suppress brackets for a cleaner chat display.",
	},

	{
		"HideSplash",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"Hide Splash Message",
		"",
		0,
		-40,
		"Hide Eloquence's load message on start-up.",
	},
	{
		"FeedbackMode",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"Force Tracking in Console",
		"",
		0,
		-20,
		"Show step-by-step filter results in the feedback console even when it's hidden."..Elo.Hue.grey.." (Leave this off unless debugging.)",
	},

	{
		"PriceCheck",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"Check Prices in Trade Chat",
		"Elo_checkbox_AntiSpam",
		176,
		0,
		"Suppress messages in the Trade channel that only mention prices higher than 125% of your current gold total."
	},
	{
		"SkipNonEnglish",
		"EloMiscFrame",
		"Elo_CheckButtonTemplate",
		"Skip Non-English Messages",
		"Elo_checkbox_PriceCheck",
		0,
		-40,
		"If a message contains European-language characters, don't apply filters to it."
	},
	{
		"NoEnemyTaunt",
		"EloFilterOthersFrame",
		"Elo_CheckButtonTemplate",
		"Replace Unknown Languages",
		"Elo_checkbox_Monster",
		0,
		-20,
		"Replace messages in languages you don't know with a simple description like\n"..Elo.Hue.white.."[Grimthor] says something in Demonic.",
	},
	{
		"NPCGather",
		"EloDataFrame",
		"Elo_CheckButtonTemplate",
		"Gather on Talking with NPCs",
		"EloOptionsExpireSlider",
		0,
		-40,
		"Occasionally gather player data after you talk to NPCs.",
	},
	{
		"ZoneGather",
		"EloDataFrame",
		"Elo_CheckButtonTemplate",
		"Gather on Zoning",
		"Elo_checkbox_NPCGather",
		0,
		-20,
		"Occasionally gather player data after you change zones.",
	},
	{
		"PlaceNames",
		"EloDataFrame",
		"Elo_CheckButtonTemplate",
		"Auto-Format Place Names",
		"EloOptionsExpireSlider",
		182,
		12,
		"Store the names of places you've visited so Eloquence can capitalize and format them.",
	},
}
local function colorbuttontext(v,button)
	if v == 0 then
		button:SetTextColor(1,0.8,0)
	else
		button:SetTextColor(0.9,0.9,0.9)
	end
end
Elo.RadioButtons = {
	[1] = {
		"Say",
		"Say and Emote",
	},
	[2] = {
		"Yell",
		"Yells",
	},
	[3] = {
		"Default",
		"Default Channels",
	},
	[4] = {
		"Custom",
		"Custom Channels",
	},
	[5] = {
		"Party",
		"Party Chat",
	},
	[6] = {
		"Raid",
		"Raid Chat",
	},
	[7] = {
		"Battleground",
		"BG Chat",
	},
	[8] = {
		"Guild",
		"Guild Chat",
	},
	[9] = {
		"Officer",
		"Officer Chat",
	},
	[10] = {
		"Whisper",
		"Whispers",
	},
}
local w = Elo.Hue.white
local radioicons = {
	[1] ={
	"Spell Book",
	"Corrects common spelling, grammatical, capitalization, and formatting errors.",
	"Interface\\Icons\\INV_Misc_Book_09",
--	"Interface\\Icons\\INV_Gauntlets_16",
	},
	[2] ={
	"Decompression Engine",
	"Expands many Warcraft and MMO acronyms.",
	"Interface\\Icons\\INV_Gizmo_02",
	},
	[3] ={
	"Emote Whiz",
	"Translates emotes and ideogrammatical expressions into plain English.",
	"Interface\\Icons\\INV_Mask_01",

--	"Interface\\Icons\\INV_Misc_PunchCards_White",



--	Spell_Shadow_PsychicScream
	},
	[4] ={
	"Mouthwash",
	"Replaces profanity and crude words with friendlier expressions.",
	"Interface\\Icons\\Ability_Creature_Poison_01",

--	"Interface\\Icons\\INV_Misc_Flower_02",
	},
	[5] ={
	"Fantasy Writer",
	"Rewrites many modern, out-of-character expressions with those found in fantasy literature.",
	"Interface\\Icons\\INV_Jewelry_Ring_03",
	},
--	INV_Staff_08
	[6] ={
	"Dialectician",
	false,
	false,
	},
}
--	Ability_Rogue_Disguise

Elo.Max = table.getn(radioicons)

	
function Elo.CreateRadioButtons(kind)
	if not radioicons[Elo.Max][2] then
		if Elo.Faction == "Horde" then
			radioicons[Elo.Max][2] =
			Elo.Hue.yellow.."Orc|r: Proud and strong with some Orcish words.\n"..
			Elo.Hue.yellow.."Tauren|r: Formal tone with some Taurahe words.\n"..
			Elo.Hue.yellow.."Troll|r: Thick Jamaican patois.\n"..
			Elo.Hue.yellow.."Undead|r: Slight hiss & Cockney.\n"..
			Elo.Hue.yellow.."Blood Elf|r: Some Thalassian words."
			radioicons[Elo.Max][3] = "Interface\\Icons\\INV_BannerPVP_01"

		else
			radioicons[Elo.Max][2] =
			Elo.Hue.yellow.."Human|r: No accent.\n"..
			Elo.Hue.yellow.."Night Elf|r: Formal tone with some Darnassian words.\n"..
			Elo.Hue.yellow.."Dwarf|r: Thick Lowland Scots.\n"..
			Elo.Hue.yellow.."Gnome|r: Brainy vocabulary.\n"..
			Elo.Hue.yellow.."Draenei|r: Proud with some Draenei words."
			radioicons[Elo.Max][3] = "Interface\\Icons\\INV_BannerPVP_02"

		end
	end
	for k = 1,table.getn(Elo.RadioButtons) do
		local v = Elo.RadioButtons[k]
		local name = "EloText"..kind..v[1]
		local t = getglobal("EloFilter"..kind.."Frame"):CreateFontString(name,"ARTWORK")
		t:SetFontObject("GameFontNormalSmall")
		t:SetText(v[2])
		if k == 1 then 
			t:SetPoint("TOPLEFT", getglobal("Elo_Text_"..kind.."Channels"), "BOTTOMLEFT", 0, -20);
		else
			t:SetPoint("TOPLEFT", getglobal("EloText"..kind..Elo.RadioButtons[k-1][1]), "BOTTOMLEFT", 0, -8);
		end
		
		local hl = "Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight"

		local l = CreateFrame( "Button", "Elo"..kind.."LeftButton"..v[1], getglobal("EloFilter"..kind.."Frame"), "Elo_LeftButtonTemplate" )
		l:SetID(k);
		l:SetPoint("LEFT", t, "LEFT", 110, -2);



		for num = 1,Elo.Max do
			local b = CreateFrame ( "CheckButton", "Elo"..kind..v[1]..num, getglobal("EloFilter"..kind.."Frame"), "Elo_RadioButtonTemplate" )
			if num == 1 then 
				b:SetPoint("LEFT", l, "RIGHT", 6, 0);
			else
				b:SetPoint("LEFT", getglobal("Elo"..kind..v[1]..num - 1), "RIGHT", 16, 0);
			end
			b.tooltipText = radioicons[num][1]
		end
		local r = CreateFrame ( "Button", "Elo"..kind.."RightButton"..v[1], getglobal("EloFilter"..kind.."Frame"), "Elo_RightButtonTemplate" )
		r:SetID(k);
		r:SetPoint("LEFT", getglobal("Elo"..kind..v[1]..Elo.Max), "RIGHT", 6, 0);
	end

	for i = 1,Elo.Max do

		local m = CreateFrame( "Frame", "EloRadioHelp"..kind..i, getglobal("EloFilter"..kind.."Frame"),"Elo_HelpTemplate")
		m:SetPoint("BOTTOM", getglobal("Elo"..kind.."Say"..i), "TOP", 0, 6 )
		m:SetHeight(30)
		m:SetWidth(30)
		m.tooltipText = w..radioicons[i][1].."\n|r"..radioicons[i][2]
		m:SetBackdrop({
			bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
			edgeFile = "Interface\\DialogFrame\\UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 28, 
			insets = { left = 5, right = 5, top = 5, bottom = 5 }
		});
		m:SetBackdropColor(.1,.1,.3)
		m:SetBackdropBorderColor(1,1,1)

		local texture = m:CreateTexture("EloHelpTexture"..i, "LOW", nil)
		texture:SetAllPoints(m)

--[[

		if i == Elo.Max and kind == "Self" then
			SetPortraitTexture(texture, "player");
			texture:SetTexCoordModifiesRect(1)
			texture:SetTexCoord(0.1, 0.9, 0.1, 0.9);

		else
--]]

			texture:SetTexture(radioicons[i][3])
--		end


	end

end
function Elo.CheckDialects()
	Elo.DialectsOn = nil
	for name,setting in p(EloConfig.Others) do
		if setting[Elo.Max] then Elo.DialectsOn = true end
	end
end
function Elo.ClickLeftButton(button)
	PlaySound("igSpellBookClose")
	local id = button:GetID()
	local name = button:GetName()
	for kind,chan in string.gmatch(name,"Elo(.-)LeftButton(.+)") do
		EloConfig[kind][chan] = nil
		--Elo.DebugMessage("Left clicked: "..kind..", "..chan)
		for i=1,Elo.Max do
			getglobal("Elo"..kind..chan..i):SetChecked(false)
		end
	end
end

function Elo.ClickRightButton(button)
	PlaySoundFile("Sound\\Interface\\igTextPopupPing02.wav");
	local id = button:GetID()
	local name = button:GetName()
	for kind,chan in string.gmatch(name,"Elo(.-)RightButton(.+)") do
		EloConfig[kind][chan] = { }
		for i=1,Elo.Max do
			getglobal("Elo"..kind..chan..i):SetChecked(true)
			EloConfig[kind][chan][i] = true
		end
	end
end


function Elo.RadioButtonOnClick(button)
	local name = button:GetName()
	for kind,chan,num in string.gmatch(name,"Elo(%u%l+)(%u%l+)(%d+)") do
		num = tonumber(num)
		local soundcheck
		if EloConfig[kind][chan] then
			if EloConfig[kind][chan][num] then
				EloConfig[kind][chan][num] = nil
				--Elo.DebugMessage("Deactivating "..num)
				if table.getn(EloConfig[kind][chan]) == 0 then
					EloConfig[kind][chan] = nil
					--Elo.DebugMessage("Removing table: "..chan)
				end

				PlaySoundFile("Sound\\Interface\\PickUp\\PickUpFoodGeneric.wav");

			else
				EloConfig[kind][chan][num] = true
				--Elo.DebugMessage("Activating "..num)
				PlaySoundFile("Sound\\Interface\\PickUp\\PutDownFoodGeneric.wav");
			end
		else
			EloConfig[kind][chan] = { [num] = true }
			--Elo.DebugMessage("Creating "..kind.." "..chan)
			PlaySoundFile("Sound\\Interface\\PickUp\\PutDownFoodGeneric.wav");
		end
	end
	Elo.CheckDialects()
end

local function createCheckBoxes()
	for k=1,table.getn(checkBoxes) do
		local v = checkBoxes[k]
		local framename = "Elo_checkbox_"..v[1]
		if not getglobal(framename) then
			local setpoint = v[5]
			if setpoint == "" then 
				setpoint = "Elo_checkbox_"..checkBoxes[k-1][1]
			end
			local f = CreateFrame("CheckButton",framename,getglobal(v[2]),v[3])
			if getglobal(setpoint) then
				f:SetPoint("TOPLEFT", setpoint, "TOPLEFT", v[6], v[7]);
			end
			f:SetID(k);
			f.tooltipText = v[8]
			colorbuttontext(EloConfig[v[1]],getglobal(framename.."Text"))
		end

		if v[1] == "FeedbackMode" then
			local fb = CreateFrame("Button", "EloFeedbackButton", getglobal(v[2]), "EloConfirmationButtonTemplate" )
			fb:SetText("Console")
			fb:SetPoint("TOPLEFT", Elo_checkbox_FeedbackMode, "BOTTOMLEFT" , 0 , 0)
			fb.tooltipText = "Show or hide the feedback console."
		end

	end

	local pv = CreateFrame("Button", "EloPreviewKey", EloFilterSelfFrame, "EloConfirmationButtonTemplate" )
	pv:SetText(Elo.PreviewKeyList[EloConfig.PreviewKey][1])
	pv:SetWidth(72)
	pv:SetPoint("TOPLEFT", Elo_checkbox_SelfOutgoing, "TOPLEFT" , 256 , 0)
	pv.tooltipText = "Press <Modifer + Enter> while typing in the chat box to toggle between a filtered preview and the original message."


	createCheckBoxes = nil
end
function Elo.CheckBoxOnClick(id)
	Elo.Cycle(checkBoxes[id][1],1)
	local cb = "Elo_checkbox_"..checkBoxes[id][1]
	if getglobal(cb):GetChecked() then
		PlaySoundFile("Sound\\Creature\\Rat\\Rat\\FootstepRat4A.wav");
	else
		PlaySoundFile("Sound\\Creature\\Rat\\Rat\\FootstepRat3A.wav");
	end

	colorbuttontext(EloConfig[checkBoxes[id][1]],getglobal(cb.."Text"))

	local name = checkBoxes[id][1]

	if name == "SelfOutgoing" then
		if EloConfig[name] == 1 then
			Elo_Text_SafeTag:Show() 
			EloOptionsSafeTagEditBox:Show() 
			Elo_Text_EscapeTag:Show() 
			EloOptionsEscapeTagEditBox:Show() 
--			Elo_checkbox_SkipOOCSelf:Show()
		else 
			Elo_Text_SafeTag:Hide() 
			EloOptionsSafeTagEditBox:Hide() 
			Elo_Text_EscapeTag:Hide() 
			EloOptionsEscapeTagEditBox:Hide() 
--			Elo_checkbox_SkipOOCSelf:Hide()
		end
	elseif name == "PlaceNames" then
		if EloConfig[name] == 1 then
			EloOptionsColor2:Show()
		else
			EloOptionsColor2:Hide()
		end
	end

end
Elo.PageButtons = {
	[1] = {
		"Filter Yourself",
		"EloFilterSelfFrame",
		"Handle filtering of your messages.",
	},
	[2] = {
		"Filter Others",
		"EloFilterOthersFrame",
		"Handle filtering of others' messages.",
	},
	[3] = {
		"Chat Links",
		"EloLinksFrame",
		"Configure clickable chat summaries.",
	},
	[4] = {
		"Headers",
		"EloHeadersFrame",
		"Select how you want channel headers to appear in the chat box.",
	},
	[5] = {
		"Misc",
		"EloMiscFrame",
		"Manage spam and configure miscellaneous settings.",
	},
	[6] = {
		"Data Gathering",
		"EloDataFrame",
		"Eloquence needs class and level data for headers, and race values for the Dialects. It will only collect data when these features are enabled.",
	},
	[7] = {
		"Commands",
		"EloHelpFrame",
		"Advanced commands for setting up custom filters, ignore lists, and designating channels or players you don't want filtered.",
	},
	[8] = {
		"Defaults",
		"",
		"Restore buttons to their default positions. (Won't delete gathered data or user-inputted info.)",
	},
}

local colorvalues = {{"SumRGB","SumColor",},{"CityRGB","CityColor",},{"InstanceRGB","InstanceColor",},{"PlaceRGB","PlaceColor",},{"SubzoneRGB","SubzoneColor",},}
function Elo.ColorPicker(id)
	CloseMenus();
	PlaySound("igMainMenuOptionCheckBoxOn");
	Elo.ColorTextureName = getglobal("EloOptionsColor"..id.."Swatch");
	Elo.RGBVal = colorvalues[id][1]
	Elo.ColorVal = colorvalues[id][2]
	
	ColorPickerFrame.previousValues = {r = EloConfig[Elo.RGBVal][1], g = EloConfig[Elo.RGBVal][2], b = EloConfig[Elo.RGBVal][3],};
	ColorPickerFrame.func = Elo.SetColor
	ColorPickerFrame:SetColorRGB(EloConfig[Elo.RGBVal][1],EloConfig[Elo.RGBVal][2],EloConfig[Elo.RGBVal][3]);
	ColorPickerFrame.cancelFunc = Elo.CancelColor
	ColorPickerFrame.hasOpacity = false;
	ColorPickerFrame:Show();
end


function Elo.SetColor()
	local r, g, b = ColorPickerFrame:GetColorRGB();
	local texture = Elo.ColorTextureName;
	texture:SetVertexColor(r, g, b);
	texture.r = r;
	texture.g = g;
	texture.b = b;
	EloConfig[Elo.RGBVal] = {r,g,b}
	EloConfig[Elo.ColorVal] = Elo.Color(r,g,b)
end
function Elo.CancelColor(prev)
	local texture = Elo.ColorTextureName;
	local r = prev.r;
	local g = prev.g;
	local b = prev.b;
	texture:SetVertexColor(r, g, b);
	texture.r = r;
	texture.g = g;
	texture.b = b;
	EloConfig[Elo.RGBVal] = {r,g,b}
	EloConfig[Elo.ColorVal] = Elo.Color(r,g,b)
end


function Elo.Color(r, g, b, a)
	if( not a ) then
		a = 1;
	end
	return string.format("|c%02x%02x%02x%02x", (a*255), (r*255), (g*255), (b*255));
end

local function createconfirm()
	if not EloConfirm then
		local f = CreateFrame("Frame", "EloConfirm", UIParent, nil )
		f:SetPoint("CENTER", UIParent, "CENTER" , 0 , 200)
		f:SetHeight(100)
		f:SetWidth(300)

		f:SetBackdrop( { 
			bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
			edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = false, tileSize = 0, edgeSize = 24, 
			insets = { left = 5, right = 5, top = 5, bottom = 5 }
		});
		f:SetBackdropColor(0, 0, 0, 1);
		f:SetBackdropBorderColor(0.5, 0.5, 0.8, 0.7);


		local t = f:CreateFontString("EloConfirmText","ARTWORK")
		t:SetFontObject("GameFontNormal")
		t:SetText("Restore all menu buttons to\ntheir default positions?")
		t:SetPoint("TOP", EloConfirm, "TOP", 0, -24 )

		local yes = CreateFrame("Button", "EloConfirmYes", f, "EloConfirmationButtonTemplate" )
		yes:SetText("Yes")
		yes:SetPoint("BOTTOMLEFT", EloConfirm, "BOTTOMLEFT" , 42 , 12)
		local no = CreateFrame("Button", "EloConfirmNo", f, "EloConfirmationButtonTemplate" )
		no:SetText("No")
		no:SetPoint("BOTTOMRIGHT", EloConfirm, "BOTTOMRIGHT", -42 , 12)
		createconfirm = nil
	end
end

local function clickdefaults()
	Elo.ToggleOptions()
	if createconfirm then createconfirm() end
	EloConfirm:Show()
end

function Elo.ConfirmationPageButton(this)
	if this == EloConfirmYes then
		EloConfirm:Hide()
		local c,s = Elo.Custom,Elo.SkipList
		Elo.RestoreDefaults()
		Elo.UpdateOptions()
		Elo.Custom,Elo.SkipList = c,s
		for i,j in p(checkBoxes) do
			colorbuttontext(EloConfig[j[1]],getglobal("Elo_checkbox_"..j[1].."Text"))
		end
		EloOptions:Show()
	elseif this == EloConfirmNo then
		EloConfirm:Hide()
		Elo.ToggleOptions()
	elseif this == EloPreviewKey then
		Elo.Cycle("PreviewKey",2)
		this:SetText(Elo.PreviewKeyList[EloConfig.PreviewKey][1])
		PlaySound("UChatScrollButton");
	else
		if EloOutputFrame:IsShown() then
			EloOutputFrame:Hide()
		else
			EloOutputFrame:Show()
		end
	end
end


function Elo.ClickPageButton(buttonname)
	if buttonname == EloPageButton8 then
		clickdefaults()
	else
		for i,j in p(Elo.PageButtons) do
			getglobal("EloPageButton"..i):SetButtonState("NORMAL")
			getglobal("EloPageButton"..i):UnlockHighlight()
		end
		local num = tonumber(string.sub(buttonname:GetName(),-1))
		PlaySound("igMainMenuOpen");
		getglobal(Elo.PageButtons[Elo.CurrentPage][2]):Hide()
		getglobal(Elo.PageButtons[num][2]):Show()
		getglobal("EloPageButton"..num):SetButtonState("PUSHED",1)
		getglobal("EloPageButton"..num):LockHighlight()
		Elo.CurrentPage = num
	end
end

Elo.LinkOptions={
	[0] = "Off",
	[1] = "Classic",
	[2] = "Debug",
}
Elo.ColorOptions={
	[0] = "Default",
	[1] = "Class Color Only",
	[2] = "Level, Class Color",
	[3] = "Class Color, Level",
}
Elo.HeaderOptions={
	[0] = "Default",
	[1] = "Hide",
	[2] = "First Letter",
	[3] = "Numbers Only",
	[4] = "No Numbers",
}
function Elo.ToggleOptions() 
	if (EloOptions:IsVisible()) then
		Elo.ClickCloseButton()
	else
		EloOptions:Show();
		if not Elo.CurrentPage then
			Elo.CurrentPage = 1
		end
		getglobal(Elo.PageButtons[Elo.CurrentPage][2]):Show()
		getglobal("EloPageButton"..Elo.CurrentPage):SetButtonState("PUSHED",1)
		getglobal("EloPageButton"..Elo.CurrentPage):LockHighlight()
		PlaySound("igBackPackOpen");
	end
end

tinsert(UISpecialFrames,"EloOptions")


function Elo.UpdateButtons(selfother)
	for k,v in p(Elo.RadioButtons) do
		for i=1,Elo.Max do
			if EloConfig[selfother][v[1]] and EloConfig[selfother][v[1]][i] then
				getglobal("Elo"..selfother..v[1]..i):SetChecked()
			else
				getglobal("Elo"..selfother..v[1]..i):SetChecked(0)
			end
		end
	end
end


Elo.StyleTip	=	"|cffffff00Lv.4|c00ffffff Characterized speech based on speaker's race.\n"..
				"|cffffff00Lv.3|c00ffffff Replace OOC expressions with RP equivalents.\n"..
				"|cffffff00Lv.2|c00ffffff Make profanity and crude words more pleasant.\n"..
				"|cffffff00Lv.1|c00ffffff Grammar, spelling, acronyms, and punctuation.\n"..
				"|cffffff00Off:|c00ffffff  Do not filter.|r  (Each layer includes lower ones.)"

Elo.HeaderTip = {
	{"Default:","|c00ffffff [1. General] and [Party]|r"},
	{"No Numbers:","|c00ffffff [General] and [Party]|r"},
	{"Numbers Only:","|c00ffffff [1.] and [P.]|c00ffffff|r"},
	{"First Letter:","|c00ffffff [G.] and [P.]|r"},
	{"Hide:","|c00ffffff Hide all chat headers."},
}

Elo.ColorTip = {
	{"Default:","|c00ffffff [Player]:|r"},
	{"Class Color Only:","|c00ffffff [|cffc69b6dPlayer|c00ffffff]:|r"},
	{"Level, Class Color:","|c00ffffff [(70)|cffc69b6d Player|c00ffffff]:|r"},
	{"Class Color, Level:","|c00ffffff [|cffc69b6dPlayer|c00ffffff (70)]:|r"},
}

Elo.LinkTip="|cffffff00Classic:|c00ffffff Click on long messages to view entire length.|cffffff00\nDebug:|c00ffffff Click on any chat to reveal pre-filtered text.\n|cffffff00Off:|c00ffffff Disable chat links.\n|r(Chat links are always disabled if linked items are present)"

function Elo.AddDouble(tablename)
	GameTooltip:SetOwner(this, "ANCHOR_RIGHT"); 
	for k,v in p(tablename) do
		GameTooltip:AddDoubleLine(v[1],v[2])
	end
	GameTooltip:Show()
end
function Elo.UpdateOptions()
	if EloConfig then
		if Elo.CreateRadioButtons then Elo.CreateRadioButtons("Self") end
		if Elo.CreateRadioButtons then Elo.CreateRadioButtons("Others") end
		radioicons = nil
		Elo.CreateRadioButtons = nil
		Elo.UpdateButtons("Self")
		Elo.UpdateButtons("Others")
		for k,v in p(Elo.PageButtons) do
			getglobal("EloPageButton"..k):SetText(v[1])
		end
	end
	if createCheckBoxes then createCheckBoxes() end
	Elo_Text_HelpText:SetText(Elo.Help[2])
	for i,j in p(Elo.PageButtons) do
		getglobal("EloPageButton"..i).tooltipText = j[3]
	end

	if type(Prat) == "table" and Prat.name == "Prat" then
		EloPageButton4.tooltipText = EloPageButton4.tooltipText.."\n"..Elo.Hue.white.."NOTE: Prat's headers are applied first, so these settings only apply if Prat's are disabled."
	end

	for k,v in p(checkBoxes) do
		local box = getglobal("Elo_checkbox_"..v[1])
		local txt = getglobal("Elo_checkbox_"..v[1].."Text")
		if not box then return end
		txt:SetText(v[4])
		box:SetChecked(EloConfig[v[1]])
	end
	local r, g, b = unpack(EloConfig["SumRGB"]);
	EloOptionsColor1Swatch:SetVertexColor(r, g, b);

	r, g, b = unpack(EloConfig["CityRGB"]);
	EloOptionsColor2Swatch:SetVertexColor(r, g, b);


	r, g, b = unpack(EloConfig["InstanceRGB"]);
	EloOptionsColor3Swatch:SetVertexColor(r, g, b);

	r, g, b = unpack(EloConfig["PlaceRGB"]);
	EloOptionsColor4Swatch:SetVertexColor(r, g, b);

	r, g, b = unpack(EloConfig["SubzoneRGB"]);
	EloOptionsColor5Swatch:SetVertexColor(r, g, b);


	EloOptionsSafeTagEditBox.tooltipText = "Start a message with this to let the entire message pass unfiltered."
	EloOptionsEscapeTagEditBox.tooltipText = "Put this in front of a word let it pass unfiltered."
	EloOptionsSumTagEditBox.tooltipText = "This tag will appear at the end of trimmed messages."
	EloOptionsClose.tooltipText = "Save settings and close."

-- |c00ffffff/elo|cffffff00 add (before) = (after)|c00ffffff

	Elo.CustomTip = "If other addons that use a custom\nchannel are having problems,\ntry turning this off."

	EloOptionsMaxLengthSlider.tooltipText = "Messages that exceed this length are trimmed.";
	EloOptionsSumDisplaySlider.tooltipText = "Trimmed messages appear in your chat window this long.";

	EloOptionsExpireSlider.tooltipText = "Entries for players gone unseen for this many days will be purged on startup.";

	Elo_HeaderButtonText = Elo.HeaderOptions[EloConfig.Header]
	EloOptionsHeaderButton:SetText(Elo_HeaderButtonText);
	Elo_ColorButtonText = Elo.ColorOptions[EloConfig.Colors]

--[[
	if EloConfig.Colors == 0 then
		Elo_checkbox_RandomColors:Hide()
		Elo_checkbox_ColorInChat:Hide()
	else
		Elo_checkbox_RandomColors:Show()
		Elo_checkbox_ColorInChat:Show()
	end

--]]

	EloOptionsColorButton:SetText(Elo_ColorButtonText);
	Elo_LinksButtonText = Elo.LinkOptions[EloConfig.Links]
	EloOptionsLinksButton:SetText(Elo_LinksButtonText);
	EloOptionsSumTagEditBox:SetText(EloConfig.SumTag)
	EloOptionsSafeTagEditBox:SetText(EloConfig.SafeTag)
	if EloConfig.Links == 0 then
		EloOptionsMaxLengthSlider:Hide()
		Elo_Text_MaxLength:Hide()
		EloOptionsSumDisplaySlider:Hide()
		Elo_Text_SumDisplay:Hide()
		Elo_Text_SumTag:Hide()
		EloOptionsSumTagEditBox:Hide()
		EloOptionsColor1:Hide()
	else
		EloOptionsMaxLengthSlider:Show()
		Elo_Text_MaxLength:Show()
		Elo_Text_SumDisplay:Show()
		Elo_Text_SumTag:Show()
		Elo_Text_SumTag:Show()
		EloOptionsSumTagEditBox:Show()
		EloOptionsColor1:Show()
	end
	if EloConfig.SelfOutgoing == 0 then
		Elo_Text_SafeTag:Hide()
		EloOptionsSafeTagEditBox:Hide()
		Elo_Text_EscapeTag:Hide()
		EloOptionsEscapeTagEditBox:Hide()
	else
		Elo_Text_SafeTag:Show()
		EloOptionsSafeTagEditBox:Show()
		Elo_Text_EscapeTag:Show()
		EloOptionsEscapeTagEditBox:Show()
	end
	Elo.InitMaxSlider()
	Elo.InitSumSlider()
	Elo.InitExpireSlider()
--	Elo.ShowHideData()
end


function Elo.InitMaxSlider()
	if EloConfig then
	EloOptionsMaxLengthSlider:SetValue(EloConfig.MaxLength)
	getglobal("EloOptionsMaxLengthSlider" .. "Low"):SetText("50");
	getglobal("EloOptionsMaxLengthSlider" .. "High"):SetText("300"); 
	getglobal("EloOptionsMaxLengthSlider" .. "Text"):SetText(EloConfig.MaxLength);
	end
end
function Elo.InitSumSlider()
	if EloConfig then
	EloOptionsSumDisplaySlider:SetValue(EloConfig.SumDisplay)
	getglobal("EloOptionsSumDisplaySlider" .. "Low"):SetText("10");
	getglobal("EloOptionsSumDisplaySlider" .. "High"):SetText("250"); 
	getglobal("EloOptionsSumDisplaySlider" .. "Text"):SetText(EloConfig.SumDisplay);
	end
end
function Elo.InitExpireSlider()
	if EloConfig then
	EloOptionsExpireSlider:SetValue(EloConfig.ExpireLimit)
	getglobal("EloOptionsExpireSlider" .. "Low"):SetText("1");
	getglobal("EloOptionsExpireSlider" .. "High"):SetText("120"); 
	getglobal("EloOptionsExpireSlider" .. "Text"):SetText(EloConfig.ExpireLimit);
	end
end
function Elo.MoveMaxSlider()
	if EloConfig then
		EloOptionsMaxLengthSliderText:SetText(EloOptionsMaxLengthSlider:GetValue())

		EloConfig.MaxLength = EloOptionsMaxLengthSlider:GetValue()

		if EloOptionsMaxLengthSlider:GetValue() <= EloOptionsSumDisplaySlider:GetValue() then
			EloOptionsSumDisplaySlider:SetValue(EloOptionsMaxLengthSlider:GetValue() - 10)
			EloConfig.SumDisplay = EloOptionsSumDisplaySlider:GetValue()
		end

		EloConfig.MaxLength = EloOptionsMaxLengthSlider:GetValue()
		PlaySoundFile("Sound\\Creature\\Rat\\Rat\\FootstepRat2A.wav"); 
		

	end
end
function Elo.MoveSumSlider()
	if EloConfig then
		EloOptionsSumDisplaySliderText:SetText(EloOptionsSumDisplaySlider:GetValue())

		EloConfig.SumDisplay = EloOptionsSumDisplaySlider:GetValue()

		if EloOptionsMaxLengthSlider:GetValue() <= EloOptionsSumDisplaySlider:GetValue() then
			EloOptionsMaxLengthSlider:SetValue(EloOptionsMaxLengthSlider:GetValue() + 10)
			EloConfig.MaxLength = EloOptionsMaxLengthSlider:GetValue()
		end
		EloConfig.SumDisplay = EloOptionsSumDisplaySlider:GetValue()
		PlaySoundFile("Sound\\Creature\\Rat\\Rat\\FootstepRat2A.wav"); 
	end
end
function Elo.MoveExpireSlider()
	if EloConfig then
		EloOptionsExpireSliderText:SetText(EloOptionsExpireSlider:GetValue())
		EloConfig.ExpireLimit = EloOptionsExpireSlider:GetValue()
		PlaySoundFile("Sound\\Creature\\Rat\\Rat\\FootstepRat2A.wav"); 
	end
end

function Elo.ClickLinksButton()
     Elo.Cycle("Links",2)
	Elo_LinksButtonText = Elo.LinkOptions[EloConfig.Links]
	if EloConfig.Links == 0 then
		EloOptionsMaxLengthSlider:Hide()
		Elo_Text_MaxLength:Hide()
		EloOptionsSumDisplaySlider:Hide()
		Elo_Text_SumDisplay:Hide()
		Elo_Text_SumTag:Hide()
		EloOptionsSumTagEditBox:Hide()
		EloOptionsColor1:Hide()
		Elo_checkbox_MonsterLink:Hide()
	else
		EloOptionsMaxLengthSlider:Show()
		Elo_Text_MaxLength:Show()
		EloOptionsSumDisplaySlider:Show()
		Elo_Text_SumDisplay:Show()
		Elo_Text_SumTag:Show()
		EloOptionsSumTagEditBox:Show()
		EloOptionsColor1:Show()
		Elo_checkbox_MonsterLink:Show()


	end
	EloOptionsLinksButton:SetText(Elo_LinksButtonText);
	PlaySound("UChatScrollButton");
end

function Elo.ClickHeaderButton()
	Elo.Cycle("Header",4)
	Elo_HeaderButtonText = Elo.HeaderOptions[EloConfig.Header]
	EloOptionsHeaderButton:SetText(Elo_HeaderButtonText);
	PlaySoundFile("Sound\\Interface\\uMiniMapZoom.wav");
end

function Elo.ClickColorButton()
	Elo.Cycle("Colors",3)
	Elo_ColorButtonText = Elo.ColorOptions[EloConfig.Colors]

--[[
	if EloConfig.Colors == 0 then
		Elo_checkbox_RandomColors:Hide()
		Elo_checkbox_ColorInChat:Hide()
	else
		Elo_checkbox_RandomColors:Show()
		Elo_checkbox_ColorInChat:Show()
	end
--]]

	EloOptionsColorButton:SetText(Elo_ColorButtonText);
	PlaySoundFile("Sound\\Interface\\uMiniMapZoom.wav");
--	Elo.ShowHideData()
end

function Elo.ClickCloseButton()
	Elo.UpdateFilters()
	PlaySound("igBackPackClose");
	EloOptions:Hide();
end
--[[
function Elo.ShowHideData()
	if not Elo.DialectsOn and EloConfig.Colors == 0 then
		Elo_Text_ExpireLimit:Hide()
		EloOptionsExpireSlider:Hide()
		Elo_checkbox_NPCGather:Hide()
		Elo_checkbox_ZoneGather:Hide()
	else
		Elo_Text_ExpireLimit:Show()
		EloOptionsExpireSlider:Show()
		Elo_checkbox_NPCGather:Show()
		Elo_checkbox_ZoneGather:Show()
	end
end
--]]
function Elo.Size(flag)
	local c,t = 1,0
	if not flag then Elo.AddMsg(" has gathered entries for") end
	for x,y in p(ElDat) do
		c = 0
		for k,v in p(y["Alliance"]) do
			c = c + 1
		end
		for k,v in p(y["Horde"]) do
			c = c + 1
		end
		if c > 0 then
			if not flag then DEFAULT_CHAT_FRAME:AddMessage(Elo.Hue.grey..c.."|r on "..x..".") end
		end
		t = t + c
	end
	if not flag then DEFAULT_CHAT_FRAME:AddMessage(Elo.Hue.yellow..t.." players total.") end
	return t
end


function Elo.FormatDataScrollFrame()
	if EloPlayerDataFrame:IsShown() then
		local t,c = 1
		Elo.DataReadout = { }
		Elo.DataReadout[1] = "Players gathered:"
		for x,y in p(ElDat) do
			c = 0
			for k,v in p(y["Alliance"]) do
				c = c + 1
			end
			for k,v in p(y["Horde"]) do
				c = c + 1
			end
			if c > 0 then
				table.insert(Elo.DataReadout,Elo.Hue.grey..c.." on "..Elo.Hue.yellow..x)
			end
			t = t + c
		end
		table.insert(Elo.DataReadout,t.." players total.")
		EloDataScrollBar:Show()
	end
end

function EloDataScrollBar_Update()
  local line
  local max = 8
  local entries = table.getn(Elo.DataReadout)
  local lineplusoffset; -- an index into our data calculated from the scroll offset
  FauxScrollFrame_Update(EloDataScrollBar,entries,max,12);
  for line=1,max do
    lineplusoffset = line + FauxScrollFrame_GetOffset(EloDataScrollBar);
    if lineplusoffset < entries + 1 then
      getglobal("EloDataEntry"..line.."_Text"):SetText(Elo.DataReadout[lineplusoffset]);
      getglobal("EloDataEntry"..line):Show();
    else
      getglobal("EloDataEntry"..line):Hide();
    end
  end
end
