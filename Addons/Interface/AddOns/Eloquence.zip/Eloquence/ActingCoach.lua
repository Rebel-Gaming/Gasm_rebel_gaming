--	Replace modern game-speak with more fantasylike phrases.

Elo.ActingCoach = {
[1]={


	["[Ll][fF]([^|]-)[tT]ank([%As])"]			=	"LF%1 guardian%2",
	["[Ll][fF](%d?[mM].-)[dD][pP][sS]"]			=	"LF%1damage%-dealer",
	["%s[lL]%s?[fFrR4](.-)[%s%p]+[rR][eE][nNdD][nNdD]+%s?[rR][uU][nN][sz]*[%s%p]+"]			=	" LF%1 to defeat Rend Blackhand, ",
	["%s[lL]%s?[fFrR4](.-)[%s%p]+[rR][eE][nNdD][nNdD]+(%A*)$"]			=	" LF%1 to vanquish Rend Blackhand%2",
	["%s[lL]%s?[fFrR4](.-%A)[aA][oO][eE](%s+%a%a)"]			=	" LF%1 area bombardment%2",

--	["(%A)[iI]%s?[gG]ot+a(%A)"]	=	"%1I'm afraid I must%2",

	["(%A)[wW][eoO0][oO0]+[tTrhH%swW]+[zZoO0]*[hHtT]*(%A)"]	=	"%1woot%2",


	["(%A)[fF][ao]h?%s?[sS]hoh?(%A)"]			=	"%1without a doubt%2",

	["(%A)[dD]a+n+g+(%A)"]			=	"%1omg%2",

	["(%A)[kK]i[ck]+([eds]*)%s[sS]ome%s[aA@][sz%$][sz%$](%A)"]		=	"%1conquer%2 all opposition%3",

	["(%A)[pP][sS][tT]%s+[tT]o(%A)"]	=	"%1ask%2",
	["(%A)[pP][sS][tT]%s+(%u%l%l%l%l)"]	=	"%1ask %2",

	["(%A)[pP][sS][tT]%s+[hH]im(%A)"]	=	"%1ask him%2",
	["(%A)[pP][sS][tT]%s+[hH]er(%A)"]	=	"%1ask her%2",
	["(%A)[pP][sS][tT]%s+[uU]s(%A)"]	=	"%1ask us%2",
	["(%A)[pP][sS][tT]%s+[mM]e(%A)"]	=	"%1whisper me%2",
	["(%A)[pP][sS][tT]%s+[tT]hem(%A)"]	=	"%1ask them%2",

	["(%A)[cC]rud(%A)"]			=	"%1crap%2",

	["(%A)[pP]h?ff+t+(%A)"]			=	"%1bah, %2",


	["(%A)[eE]l+%s*[oO]+[he]*%s?[eE]l+(%A)"]			=	"%1lol%2",

	["(%A)[fFrR]ul+[%s%p]?on(%A)"]			=	"%1have enough%2",

	["(%A)[kK]+%s[tT]hx%s?ba?[iy]e?(%A)"]		=	"%1I will say no more%2",
	["(%A)[kK]+thx(%A)"]		=	"%1Very good, thank you%2",
	["(%A[yY])o%s[yY]o(%A)"]	=	"%1o%2",

	["(%A[au]?re?)%s[nN][oe30][ow0]+b+(%A)"]	=	"%1inept%2",
	["(%A[cC])o+l+n+e+s+(%A)"]	=	"%1ool%2",

	["(%A)[sS]h?u+c?k+(%a*)%s?[sS]o%s?[bB]ad+(%A)"]		=	"%1suck%2%3",

	["(%A)[lL]et%A?[sS]%s?[kK]i[ck]+%A*[aA@][sz%$][sz%$](%A)"]		=	"%1death to the enemy%2",

	["(%A)[lL][e7][e7]t%A*[sS]auce(%A)"]		=	"%1leet%2",

	["([%p%s])[sS]h?end%s[pP]s[tT]%s[tT]o(%A)"]	=	"%1send word to%2",


},

[2]={
--	If last letter of a word is a z, then replace with an s.
	["(%a%a[lL])[zZ]+(%A)"]	=	"%1s%2",
--	["(%a[^aeiou%s%p%d])[sS][sS]+(%A)"]	=	"%1s%2",

	["(%A)[pP]s[tT]'?[sz](%A)"]		=	"%1whispers%2",
	["(%A)[pP]s[tT]%s[mM]e(%A)"]		=	"%1PST%2",
	["(%A)[pP][ms]%s[mM]e(%A)"]		=	"%1PST%2",
	["(%A)[sS]h?end%s[pP]s[tT](%A)"]		=	"%1PST%2",

	["(%A)[wW][tT][fF]%A*[pPoO0]+wn+"]	=	"%1pwn",

	["(%A)[hH]o+wdy(%A)"]			=	"%1hail%2",
	["(%A)[hH]i([%s,!.?;:])"]			=	"%1hello%2",
	["(%A)[hH][ie]ya[sz]*(%A)"]	=	"%1hello%2",



	["(%A)[dD]ang%s?[eEiI]t(%A)"]			=	"%1confound it!%2",


	["(%A)[hH]+e+y+%s?[hH]+e+y+(%A)"]	=	"%1hey%2",

	["(%A)[wW]u+ss+(%A)"]	=	"%1gutless wonder%2",
	["(%A)[wW]u+ss+[eiy]+[sz](%A)"]	=	"%1cowards%2",
	["(%A)[pP]an[sz][eiy]+[sz](%A)"]	=	"%1cowards%2",
	["(%A)[pP]uss+[eiy]+[sz](%A)"]	=	"%1cowards%2",

	["(%A)[wW]u+ss+[eiy]+(%A)"]	=	"%1weak%-kneed%2",

	["(%A)[oO]+h*%s?[nN]o+e*[sz]+(%A)"]	=	"%1Not good! %2",

	["(%A)[sS]h?u+k?ck?[iey]+(%A)"]	=	"%1shoddy%2",

	["(%A)[hH]el+[sz%s]*[nN]o+[^%a%d|?]+"]		=	"%1not while I still breathe! ",
	["(%A)[gG][oaw]+d%s?[nN]o+[^%a%d|?]+"]	=	"%1not while my heart beats! ",

	["(%A)[sS]h[au]t+%s?[tT]he%s%a+%s[uU]p+(%A)"]		=	"%1shut up, %2",

	["(%A)[lL]o+[sz]+er([sz]*%A)"]		=	"%1knave%2",
	["(%A)[lL]otsa(%A)"]		=	"%1a teeming throng of%2",
	["(%A)[lL]+ot+s%s?[oO]f(%A)"]		=	"%1great amounts of%2",
	["(%A)[cC]hi[ck]+([sz]*%A)"]		=	"%1maiden%2",
	["(%A[yY]+)e+a+h*(%A)"]	=	"%1es%2",

	["(%A)[dD]'?o+h+%A"]	=	"%1Alas! ",
	["(%A)[dD]'?u+h+%A"]	=	"%1Why, it's obvious! ",
	["(%A)[gG][ae]+h+%A"]		=	"%1Alas! ",
	["(%A)[mM]y%s?[gG][ao]+w?d(%A)"]		=	"%1my goodness! %2",
	["(%A)[tT]hank%s?[gG][ao]+w?d(%A)"]		=	"%1thank goodness%2",
	["(%A)[rR]+a+w+r+(%A)"]		=	"%1Rraahah! %2",
	["(%A)[wW][eo0][ow0]+[hH%szZsSoO0]*[hHwW][oO0]+[tTrhHzZoO0]*([%s%p])"]		=	"%1woot%2",
	["(%A)[oO]f%s?[sS]ho(%A)"]			=	"%1indeed%2",
	["(%A)[oO]ve?re?ly(%A)"]			=	"%1excessively%2",
	["(%A)[hH]a?rd?ld?y%s?[eE]v+[ae]r+(%A)"]			=	"%1seldom%2",
	["(%A[nN])[ou]pe(%A)"]				=	"%1ay%2",
	["(%A)[mM]ob[sz](%A)"]			=	"%1monsters%2",
	["(%A)[tT]oon([sz]*%A)"]			=	"%1character%2",
--	["(%A)[aA]lt([sz]*%s[^'])"]			=	"%1alternate%2",
	["(%A)[sS]h?oloable?(%A)"]			=	"%1doable alone%2",
	["(%A)[pP]r?ty(%a*%A)"]			=	"%1party%2",
--	["(%A)[lL]+a+g+e?d(%A)"]			=	"%1tired%2",
	["(%A)[rR]espec+(e?d?[sz]*)(%A)"]	=	"%1change%2 specialty%3",
	["(%A)[yY]our%sspec%a+(%A)"]		=	"%1your forte%2",
	["(%A)[hH]u?r+y%s?[uU]p(%A)"]		=	"%1make haste%2",
	["(%A)[fF]u+b+[4a]re?d?(%A)"]		=	"%1ruined%2",
	["(%A)[cC]rap+y(%A)"]		=	"%1lousy%2",
	["(%A)[bB]a+l+s+y+(%A)"]		=	"%1bold%2",

	["(%A)[eE]mo(%A)"]				=	"%1temperamental%2",

	["(%A)[iI]n?sn?ane(%A)"]			=	"%1mad%2",
	["(%A)[iI]nsane?le?y(%A)"]		=	"%1terribly%2",
	["(%A)[tT]ot[auo]l+e?y(%A)"]	 	=	"%1truly%2",
	["(%A)[rR]oyal+e?y(%A)"]			=	"%1remarkably%2",
	["(%A)[aA]p+[ea]r+[ae]ntly(%A)"]	=	"%1evidently%2",
	["(%A)[uU]n?god+l+y+(%A)"]	=	"%1outrageous%2",
	["(%A)[iI]ff+y(%A)"]			=	"%1dubious%2",
	["(%A)[bB]orke[dn](%A)"]			=	"%1unsound%2",
	["(%A)[lL][eE3][eE3][tT7](%A)"]	=	"%1stout%2",
	["(%A)[lL][eE30][wW0][tT7][sz]*(%A)"]	=	"%1plunder%2",
	["(%A)[pP]h[e3][ea3]+r([sz]*%A)"]		=	"%1fear%2",
	["(%A)[pP]h[a4][t7](%A)"]		=	"%1great%2",
	["(%A)l'?[it]'?l'?(%A)"]				=	"%1little%2",
	["(%A)[hH]om+[ie][ey]([sz]*%A)"]	=	"%1friend%2",
	["(%A)[bB]ro([sz]*%A)"]			=	"%1brother%2",
	["(%A)[hH][ea]+y+%s*[hH][ea]+y+(%A)"]	=	"%1hey%2",
	["(%A)[hH]i+%s*[hH]i+(%A)"]		=	"%1hi%2",
	["(%A)[wW]+e+w+t+(%A)"]				=	"%1woot%2",
	["(%A)[bB]u+d([sz]*%A)"]	=	"%1friend%2",
	["(%A)[bB]u+dd[iey*]([sz]*%A)"]	=	"%1friend%2",
	["(%A)[rR]gr(%A)"]		=	"%1understood%2",
	["(%A)[gG]uildi?[ey]([sz]*%A)"]		=	"%1guildmate%2",
	["(%A)[nN][pP][cC](%A)"]	=	"%1person%2",
	["(%A)[dD]%p?l(e?d?%A)"]		=	"%1acquire%2",
	["(%A)[fF]arm([ie]%a+[^'])"]			=	"%1harvest%2",
	["(%A)[tT]o%s[wW]ho(%A)"]			=	"%1to whom%2",
	["(%A)[tT]o%s[wW]ho%s?ever(%A)"]			=	"%1to whomever%2",
	["(%A)[lL]ow?b[iey]+([sz]*%A)"]			=	"%1novice%2",
	["(%A)[nN][eu]rf(%A)"]			=	"%1weaken%2",
	["(%A)[nN][eu]rf%s?stic?k(%A)"]	=	"%1hammer of fate%2",
	["(%A)[nN][eu]rf%s?bat(%A)"]	=	"%1bludgeon of balance%2",
	["(%A)[gG]impe?d(%A)"]			=	"%1weakened%2",
	["(%A)[gG]imp(%A)"]			=	"%1ineffectual%2",
	["(%A)[gG]anker([sz]*%A)"]			=	"%1assassin%2",
	["(%A)[gG]anked(%A)"]			=	"%1crushed%2",
	["(%A)[gG]anks(%A)"]		=	"%1kills%2",
	["(%A)[gG]ank%s?sq[ua]+d([sz]*%A)"]	=	"%1incursion%2",
	["(%A)[yY]+a+[yY]+(%A)"]		=	"%1yes!%2",
	["(%A)[yY]+a+[yY]+a(%A)"]		=	"%1yes, yes%.%.%.%2",


	["(%A)[mM]y%s?[gGbB]%A?[fF](%A)"]	=	"%1my beloved%2",
	["(%A)[yY]our%s?[gGbB]%A?[fF](%A)"]	=	"%1your beloved%2",

	["(%A)[iI]%s?[dD][ou]+n+o+%s?([wW]%a+)"]	=	"%1I cannot fathom %2",
	["(%A)[cCkK]an'?t%s?[sS]ta+nd(%A)"]	=	"%1cannot abide%2",
	["^%s[nN]o+%s?[rR]ush(%A)"]			=	" There is no need to hurry%1",

	["(%A)[sS]h?'?%s?[aA][lw]?rig?h?te?(%A)"]	=	"%1all is well%2",
	["(%A)[sS]h?'?%s?[aA]ig?h?te?(%A)"]		=	"%1don't trouble yourself%2",
	["(%A)[kK]i[ck]+%A*[aA@][sz%$][sz%$](%A)"]		=	"%1stout%2",
	["(%A)[kK]i[ck]+e?d[%s%-]?[aA@][sz%$][sz%$](%A)"]		=	"%1seized the reins of victory%2",
	["(%A)[kK]i[ck]+s[%s%-]?[aA@][sz%$][sz%$](%A)"]		=	"%1eclipses the competition%2",

	["(%A)[kK]i[ck]+([edsing]*)%s([iI][%a']+)%s[aA@][sz%$][sz%$]e?([sz]*%A)"]		=	"%1thwart%2 %3 plan%4",
	["(%A)[kK]i[ck]+([edsing]*)%s([^iI][%a']+)%s[aA@][sz%$][sz%$]e?([sz]*)(%A)"]		=	"%1rend%2 %3 head%4 from %3 shoulders%5",
	["(%A)[kK]i[ck]+([edsing]*)%s[sS]ome%s(%a+)%s[aA@][sz%$][sz%$](%A)"]		=	"%1destroy%2 the %3 %4",

	["(%A)[aA@][sS%$][sS%$]e?([sz]*)%s[kK]i[ck]+ed(%A)"]		=	"%1head%2 lopped off%3",

--	["(%A)[aA]lways%s*(%a%a-)ing(%A)"]		=	"%1ever %2ing%3",

	["(%A)[hH]ella(%A)"]		=	"%1very%2",
	["(%A)(%a+)%s[aA]s%s?[hH]ell(%A)"]		=	"%1unbelievably %2%3",

	["(%A)[nN][oe30][ow0]+b+([sz]*%A)"]	=	"%1amateur%2",
	["(%A)[nN][oe30][ow0]+b+[eiy]+([sz]*%A)"]	=	"%1novice%2",
	["(%A)[nN][oe30]?[uow0]+b+l[ie]+t([sz]*%A)"]				=	"%1novice%2",
	["(%A)[nN][oe30]?[uow0]+b+[eiy]+sh(%A)"]		=	"%1callow%2",
	["(%A)[nN][oe30]?[uow0]+b+[cC]ake(%A)"]		=	"%1clumsy fool%2",
	["(%A)[nN][oe30]?[uow0]+b+[ei]f[iey]+([dsz]%A)"]		=	"%1undermine%2",
	["(%A)[nN][oe30]?[uow0]+b+age(%A)"]			=	"%1ineptitude%2",

	["(%A[rR])e[zs]+er([sz]*%A)"]	=	"%1esurrector%2",

	["(%A)[hH]eal[ai]din([sz]*%A)"]	=	"%1healing Paladin%2",
	["(%A)[aA]%s[nN]ub+(%A)"]	=	"%1a child%2",


--	["(%A)[pP]i[ss]+e?([ds]*)%s(%a%a+)%sof+(%A)"]		=	"%1irritate%2 %3%4",
	["(%A)[pP]i[ss]+ed?(s?)%s?of+(%A)"]		=	"%1upset%2%3",
	["(%A)[vV]er+y%s?[nN]ice(%A)"]	=	"%1excellent%2",

	["(%A)[lLrR][oO0][fF]?[lL][sz]*%s*(|%a)"]				=	"%1%2",

	["(%A)[sS]h?uc?k(%a*)%s*[uU]p%s[tT]o(%A)"]				=	"%1%2flatter%3",
	["(%A)[sS]h?uc?k(%a*)%s*[uU]p%s([^tT])"]				=	"%1%2flatter%3",

	["(%A)[wW]ea[%s%p]*k[%s%p]*[sS][%s%p]*auce?(%A)"]				=	"%1mediocre%2",
	["(%A)[eE]mo(%A)"]				=	"%1temperamental%2",
	["(%A)[eE]mo[sz](%A)"]				=	"%1buffoons%2",

	["(%A[iI]f%A.-%A)[pP][sS][tT](%A)"]	=	"%1please tell%2",

	["(%A)[gG]ot%s?[wW]a+y+%s?to+(%A)"]	=	"%1got much too%2",
	["(%A)[wW]+aa+y+%s?to+(%A)"]	=	"%1far too%2",
	["(%A)[pP][sS][tT]%sto(%A)"]	=	"%1send word to%2",
	["(%A)[pP][sS][tT]%swith?(%A)"]	=	"%1, please submit%2",
	["(%A)[pP][sS][tT]%s[oO]f+er[sz]*(%A)"]	=	"%1, accepting offers%2",
	["(%A)[pP][sS][tT]%s[pP]rice([sz]*%A)"]	=	"%1, tell me your price%2",

	["(%A)[cC]?o?n?[gG]ra?[td][sz]+(%A)"]	=	"%1congratulations%2",

	["(%A)[nN]%s?[pP][sz]*(%A)"]	=	"%1no trouble at all%2",

	["(%A)[bB][rR][tT](%A)"]	=	"%1be right there%2",
	["(%A)[bB][rR][bB](%A)"]	=	"%1be right back%2",
	["(%A)[aA]sap(%A)"]	=	"%1at once%2",

--	Replace 'yup' and 'yep'
	["(%A)[yY][uUeE]+[pP]+(%A)"]	=	"%1yes%2",

--	Replace 'guys' with 'lads'
	["(%A)[gG]u+y[sz](%A)"]	=	"%1lads%2",
	["(%A)[gG][uU]+[yY](%A)"]	=	"%1fellow%2",

	["(%A)[lL]+a+m+e(%A)"]		=	"%1awful%2",
	["(%A)[lL]amest(%A)"]		=	"%1most wretched%2",
},

[3]={
	["(%A)[aA][tT][mM](%A)"]	=	"%1right now%2",
	["(%A)[lL]ike%s[cC]raz+y+(%A)"]	=	"%1like mad%2",

--	Replace k, kk, OK, and okay
	["(%A)[oO][kK]+[aA][yY](%A)"]			=	"%1all right%2",

	["[lL]evel%s*(~?[%d?][%d?]~?)%s*Druid([sz]*)(%A)"]			=	"Druid%2 of %1 Seasons%3",
	["[lL]evel%s*(~?[%d?][%d?]~?)%s*Rogue([sz]*)(%A)"]		=	"Rogue%2 of %1 Tricks%3",
	["[lL]evel%s*(~?[%d?][%d?]~?)%s*[sS]ha*m+[aeiuo]*n?([sz]*)(%A)"]	=	"Shaman%2 of %1 Omens%3",
	["[lL]evel%s*(~?[%d?][%d?]~?)%s*Paladin([sz]*)(%A)"]	=	"Paladin%2 of %1 Glories%3",
	["[lL]evel%s*(~?[%d?][%d?]~?)%s*[mM]age([sz]*)[%s.]+([^wW])"]			=	"Mage%2 of %1 Storms %3",
	["[lL]evel%s*(~?[%d?][%d?]~?)%s*[mM]age([sz]*)([%s%p]*)$"]			=	"Mage%2 of %1 Storms%3",
	["[lL]evel%s*(~?[%d?][%d?]~?)%s*[hH]unte?r?([sz]*)(%A)"]			=	"Hunter%2 of %1 Trails%3",
	["[lL]evel%s*(~?[%d?][%d?]~?)%s*[wW]a[ior]+([sz]*)(%A)"]		=	"Warrior%2 of %1 Ranks%3",
	["[lL]evel%s*(~?[%d?][%d?]~?)%s*[wW]?a?r?[lL]oc?k([sz]*)(%A)"]	=	"Warlock%2 of %1 Curses%3",
	["[lL]evel%s*(~?[%d?][%d?]~?)%s*Priest([sz]*)(%A)"]		=	"Priest%2 of %1 Rites%3",

	["(%A)[nN]ice%s?1([%s%p])"]	=	"%1a bold move%2",


	["(.)[%p%s]+[pP][gs]*[tw]+%s?[mM]?e?%s?[fF]or(%A)"]	=	"%1%. Please inquire for %2",
	["(%A[sS])end%s?/t(%A)"]	=	"%1end word%2",

	["(%A)[gG]oo+d%s[tT2][o%s]*[gG]o(%A)"]		=	"%1ready to go%2",

	["(%A)leet([sSzZ]*%A)"]	=	"%1elite%2",
	["(%A)[lL]+[aA]?[mM]+[fFaA]+[oO0]([^%a@]+)"]		=	"%1too funny!%2",

	["([%s%p])[pPoO0]+w+n+[szx]*[o0]?r?z+(%A)"]	=	"%1dominates%2",
	["([%s%p])[pPoO0]+w+n+[szx]*[o0]re?d+(%A)"]	=	"%1conquered%2",
	["([%s%p])[pPo0]+w+n+a+g+e(%A)"]			=	"%1triumph%2",
	["(%A)[tT][he]+%s?[p0oO]+w+n+a+ge(%A)"]	=	"%1mighty indeed%2",

	["(%A)[wW]tf+%a-[pPoO0]+w+n+(%A)"]		=	"%1destroy%2",
	["(%A)[tT]h[ei]+r%s[bB]ase(%A)"]	=	"%1the enemy fortress%2",
	["(%A)[oO]ur%s[bB]ase(%A)"]		=	"%1our fortress%2",
	["(%A)[zZ]e+r+[kg]+(%A)"]			=	"%1storm%2",
	["(%A)[sS]h?is([sz]*%A)"]			=	"%1sister%2",


--	["(%A)[pP][gGsS]*[tTwW]+%s([^%d%p%soO]%a%a%a%a+%A)"]	=	"%1Please ask %2",
	["(%A)[pP][gGsS]*[tTwW]+%s(|c%w+[%s%p])"]	=	"%1Please ask %2",

	["(%A)[iI][%s%p]*[sS]h?u+c?k+(%A)"]		=	"%1I'm pathetic%2",
	["(%A)[wW][ei][%s%p]*[sS]h?u+c?k+(%A)"]		=	"%1we're pathetic%2",

	["(%A)[tT]he%s[rR]ox+(%A)"]			=	"%1the best%2",
	["(%A)[tT]he%s[sS]ucks(%A)"]			=	"%1the worst%2",
	["(%A)[aA]%s?[cCkK][eoO0][woO0]+[lL](%A%a+)"]		=	"%1a fine%2",
	["(%A)[nN]ot%s?[cCkK][eoO0][woO0]+[lL](%A%a+)"]		=	"%1not acceptable%2",

	["(%A)[jJ]ust%ssuck(%A)"]		=	"%1just can't compete%2",
	["(%A)[mM]ust%ssuck(%A)"]		=	"%1must be awful%2",
	["(%A)[gG]ot%sto%ssuck(%A)"]		=	"%1got to be awful%2",
	["(%A[wWcCsS]h?)ould%ssuck(%A)"]		=	"%1ould prove ill%2",
	["([so]n[o']?t%s)suck(%A)"]		=	"%1fail%2",


},
[5]={

	["^%s*[dD]+i+n+g+[%p%s]*(%d%d?)%D*$"]	=	"At last! Level %1!",

	["[tT][hHeE][hHeE]%s?[sS][uU][cCkKxX]+(%w+)"]	=	"pathetic%1",
	["^([tTdD]h?is)%s?[sS][uU][cCkK]+[xXsSzZ]+(%A*.*)"]	=	"%1 is madness! %2",
	["^([tT][hH][aA][tT])%s?[sS][uU][cCkK]+[eE]?[dD](%A*)$"]	=	"%1 was a disaster%2",
	["^([tT][hH][eE]+[yY])%s?[sS][uU][cCkK]+(%A*)$"]	=	"%1 are terrible%2",
	["[tT][hH][eE]+[yY]+%s?[sS][uU][cCkK]+[eE]?[dD](.*)"]	=	"they were awful%1",
	["[fF]or%s[cC]rap%p*$"]	=	"at all",

	["^[wW]e%s[sS]u+c?k+$"]			=	"Fortune does not smile upon us",
	["^[sS]h?u+c?k+s%sto%s"]		=	"How awful it is to ",
	["^[sS]h?u+c?k+s%sfor%s?"]	=	"Fate does not smile upon ",
	["[sS]u+c?k+[sz]%s?at"]		=	"is poor at",
	["[sS]u+c?k+%s?at"]		=	"are bad at",

	["^[lL]ike%somg"]	=	"omg",

	["(%A)[jJ]ust%s*[pP][gGsSmM]*[tTwW]%s*[mM]?[eE]?[%s%p]*"]	=	"%1 just let me know ",

},

[6]={
	["(%A)suck(%A)"]		=	"%1sicken me%2",
	["(%A)suck$"]			=	"%1sicken me",

	["^sucks(%A)"]			=	"It's just awful%1",
	["(%A)sucks$"]			=	"%1is awful",
	["(%A)sucks(%A)"]		=	"%1sickens me%2",
	["^sucks$"]				=	"How awful!",

	["(%A)[sS]ucked$"]		=	"%1failed to impress",
	["(%A)[sS]ucked(%A)"]		=	"%1dismayed me%2",

--	["(%A)[bB]low[sSzZ](%A)"]	=	"%1sickens me%2",
	["([^gGnN%d%s%p]%A)[bB]low[sSzZ](%A*)$"]		=	"%1sickens me%2",

--	Replace 'yall'
	["^[yY]'?[aA]'?[lL]+(%A)"]			=	"All of you%1",
	["(%A)[yY]'?[aA]'?[lL]+(%A)"]			=	"%1you%2",
	["(%A)[yY]'?[aA]'?[lL]+$"]	=	"%1all of you",
	["^[yY]'?[aA]'?[lL]+$"]			=	"All of you",

	["^(~?[%d?][%d?]~?)%s*Druid([sz]*)(%A)"]	=	"A Druid%2 of %1 Seasons%3",
	["^(~?[%d?][%d?]~?)%s*[rR]?ogue([sz]*)(%A)"]			=	"A Rogue%2 of %1 Tricks%3",
	["^(~?[%d?][%d?]~?)%s*[sS][hH][aA]*[mM]+[aAeEiIuOoU]*[nN]?([sz]*)(%A)"]		=	"A Shaman%2 of %1 Omens%3",
	["^(~?[%d?][%d?]~?)%s*Paladin([sz]*)(%A)"]		=	"A Paladin%2 of %1 Glories%3",
	["^(~?[%d?][%d?]~?)%s*[mM]age([sz]*)[%s.]([^wW])"]			=	"A Mage%2 of %1 Storms %3",
	["^(~?[%d?][%d?]~?)%s*[mM]age([sz]*)(%p*)$"]			=	"A Mage%2 of %1 Storms%3",
	["^(~?[%d?][%d?]~?)%s*[hH]unte?r?([sz]*)(%A)"]				=	"A Hunter%2 of %1 Trails%3",
	["^(~?[%d?][%d?]~?)%s*[wW]arrior([sz]*)(%A)"]			=	"A Warrior%2 of %1 Ranks%3",
	["^(~?[%d?][%d?]~?)%s*[wW]?a?r?[lL]oc?k([sz]*)(%A)"]		=	"A Warlock%2 of %1 Pacts%3",
	["^(~?[%d?][%d?]~?)%s*Priest([sz]*)(%A)"]			=	"A Priest%2 of %1 Rites%3",





--	Chop 'pst' if it's superfluous
	["|r%s*[pP][gGsSmM]*[tTwW]%s*[mM]?[eE]?[%s%p]*$"]	=	"|r",
	["|r%s*[pP][gGsSmM]*[tTwW]%s*[mM]?[eE]?(%p+[%s%a]+)"]	=	"|r%1",

	["(%A)[pP][gGsSmM]*[tTwW]%s*[mM]?[eE]?[%s%p]*([fF]ree[%s%p])"]	=	"%1%2",

	["(%A%a%a%a%a+)%s[pP][gGsSmM]*[tTwW]%s*[mM]?[eE]?[%s%p]*$"]	=	"%1",
	["([gG!?.,%-)])%s[pP][gGsSmM]*[tTwW]%s*[mM]?[eE]?[%s%p]*$"]	=	"%1",
	["(...)[pP][sS]*[tT]%s*[mM]?[eE]?[%s%p]*(%d+)[%s%p]*[mM][oa]n(%A*)"]	=	"%1 %2%-man%3",
	["(..)[%s!,.]+[pP][sS]*[tT]%s*[mM]?[eE]?[%s%p]*[nN]eed%s"]	=	"%1; I need ",
	["(..)[%s!,.]+[pP][sS]*[tT]%s*[mM]?[eE]?[%s%p]*[hH]ave%s"]	=	"%1; I have ",




	["^[lL]oo+k+s%slike%s?it$"]		=	"It seems so",
	["[tT][eh][eh]%s?[rR][o0]x+z?[o0]r[sz]*"]	=	"the greatest",
	["^[jJ]/?[kK]$"]			=	"Merely a joke",
--	["(%A)[bB][aA]+[dD]%s?[pP][uU]+[lL]+"]	=	"%1dangerous situation",
	["^[bB][aA]+[dD]%s?[pP][uU]+[lL]+(%A*)"]	=	"Too many!%1",
--	["^[gG]ood%s?[pP][uU]+[lL]+(%p*)"]	=	"Divide and conquer%1",
	["^[aA][gG]+[rR]+[oO]+(%p*)$"]	=	"Watch out!%1",
	["^[aA][dD][dD]+[sS]-(%p*)$"]	=	"More enemies are upon us%1",
	["^[sS]h?ure%s[tT]h?ing?%p*"]	=	"Beyond all doubt",
	["^[aA]?[bB]out%s?[tT][oa]"]			=	"I soon will ",



},
[7] = {
	["([%s%p])(~?[%d?][%d?][~+]?)%s*Druid([sz]*)"]	=	"%1Druid%3 of %2 Seasons ",
	["([%s%p])(~?[%d?][%d?][~+]?)%s*[rR]?ogue([sz]*)"]			=	"%1Rogue%3 of %2 Tricks ",
	["([%s%p])(~?[%d?][%d?][~+]?)%s*[sS][hH][aA]*[mM]+[aAeEiIuOoU]*[nN]?([sz]*)"]		=	"%1Shaman%3 of %2 Omens ",
	["([%s%p])(~?[%d?][%d?][~+]?)%s*Paladin([sz]*)"]		=	"%1Paladin%3 of %2 Glories ",
	["([%s%p])(~?[%d?][%d?][~+]?)%s*[mM]age([sz]*)%s([^wW])"]			=	"%1Mage%3 of %2 Storms %4",
	["([%s%p])(~?[%d?][%d?][~+]?)%s*[mM]age([sz]*)(%p*)$"]			=	"%1Mage%3 of %2 Storms%4",
	["([%s%p])(~?[%d?][%d?][~+]?)%s*[hH]unte?r?([sz]*)"]				=	"%1Hunter%3 of %2 Trails ",
	["([%s%p])(~?[%d?][%d?][~+]?)%s*[wW]ar+[io]+r?([sz]*)"]			=	"%1Warrior%3 of %2 Ranks ",
	["([%s%p])(~?[%d?][%d?][~+]?)%s*[wW]?a?r?[lL]oc?k([sz]*)"]		=	"%1Warlock%3 of %2 Pacts ",
	["([%s%p])(~?[%d?][%d?][~+]?)%s*Priest([sz]*)"]			=	"%1Priest%3 of %2 Rites ",

	["^[tT]he%sUndercity$"]	=	"Beneath the ruins of Lordaeron where Sylvanas reigns",
	["^[tT]hunder%sBluff$"]	=	"Atop the majestic spires of Thunder Bluff",
	["^[oO]rg?rimmar$"]		=	"Orgrimmar, mighty fortress of the Horde",
	["^[I][ro]+nf[or]+ge?$"]		=	"Ironforge, Dwarf%-city under the mountain",
	["^[dD]arnas+us+$"]		=	"Darnassus, secluded haven of the Night Elves",
	["^[sS]h?t[or]+mwi?ni?[dfg]$"]		=	"Stormwind, last bastion of a once%-proud kingdom",

	["^[sS]hat+rath$"]		=	"Shattrath, mystic dwelling of light and the naaru",

	["^[sS]ilver%s?[mM]oon$"]		=	"Within the gates of Silvermoon, or all that remains of it",
	["^[eE]x+[oe]dar$"]		=	"The Exodar, life-vessel of the otherworldly Draenei",

	["^[dD]itt[op][^%d%a?]*$"]	=	"That goes for me too",
	["^[sS]h?e+r[ie]+[ou]+sl+y(%A)"]	=	"Indeed%1",
	["^[sS]h?e+r[ie]+[ou]+sl+y$"]		=	"I could hardly agree more",

--	Replace 'sup' and 'ssssuuuuupppp' etc
	["(%A)[wW]hat's%sup(%A)"]	=	"%1what is happening%2",
	["[%s!,.]+[wW]hat's%sup$"]		=	", what is the news%?",
	["^[wW]hat's%sup(%p)"]		=	"How are you%1",
	["[wW]hat's%sup%s"]		=	"Well met, ",

--	Replace whassup, wuzzup, etc.
	["[wW]+[hH]*[aAuUoO]+[hH]*[sSzZ]+[uU]+[pP]+$"]	=	"what is the news%?",
	["[wW]+[hH]*[aAuUoO]+[hH]*[tT]+%s?[uU]+[pP]+$"]	=	"what is the news%?",

	["[wW]+[hH]*[aAuUoO]+[hH]*[sSzZ]+[uU]+[pP]+(%A)"]	=	"what is the news, %1",
	["[wW]+[hH]*[aAuUoO]+[hH]*[tT]+%s?[uU]+[pP]+(%A)"]	=	"what is the news, %1",

	["^[wW]hat%s[uU]p%s?y?o?$"]		=	"How fare you%?",
	["(%A)[wW]hat%s[uU]p%s?y?o?$"]	=	"%1how fare you%?",

	["(%A)[lL]ots$"]		=	"%1a good amount",
	["[aA]l+ot+a+(%A)"]		=	"a considerable mass of%1",
	["^[aA]l+ot+(%A)"]		=	"A prodigious amount%1",
	["(%A)[aA]lot+(%A)"]	=	"%1a great lot%2",
	["(%A)[bB]uncha(%A)"]	=	"%1host of%2",
	["^[bB]uncha(%A)"]		=	"A mob of%1",

	["^[tT]o+%s?[bB]a+d+"]		=	"It is a pity",

	["%s[wW]ant[sz]*%s(%a+)%s[bB]ad+l?y?"]	=	" could really use %1 ",
	["%s[nN]eed([sz]*)%s(%a+)%s[bB]ad+l?y?"]	=	" greatly desire%1 %2 ",
	["^[bB]rb$"]			=	"Just a moment%. I'll be not long",
	["^[aA][fF][kK]$"]			=	"Resting for a moment",
	["[gG]o%s?[aA][fF][kK]"]		=	"take a brief rest",
	["[wW]ent%s?[aA][fF][kK]"]		=	"paused for a rest",

	["^[wW]a?ia?t$"]		=	"Just a moment!",

	["[cC]hinese%s?harvester"]		=	"treasure%-hunter",

	["^[fF4]yi%A"]		=	"Let this be known: ",

	["[bB]liz[sz]*(%A)"]		=	"the Maker%1",


	["^[mM]an%A?[iI]%s"]			=	"Oh, I ",
	["^[mM]an%A?[yY]ou%s"]			=	"Why, you ",
	["^[mM]an%A?[wW]e%s"]			=	"Why, we ",

	["^[bB]asic?l+y%A"]			=	"In essence, ",
	["^[bB]asic?l+y$"]			=	"That is it, more or less",




	["^[dD]u+de%A(%a)"]	=	"Why, %1",
	["(%A)[dD]u+de"]	=	"%1lad",
	["[dD]u+des"]			=	"fellows",
	["(%A)[dD]u+de"]		=	"%1lad",
	["^[dD]u+de[%s!,.]+(%a)"]		=	"Why, %1",
	["^[dD]u+de$"]	=	"I say!",

	["[bB]r[uo][td]+h?ah?([sz]*)"]		=	"brother%1",
	["[sS]istah([sz]*)"]		=	"sisters%1",
	["[sS]uc?kah?([sz]*)"]		=	"sucker%1",

	["^[lL]ater$"]			=	"Farewell",


	["[cC]he+a*[zs]+[iy][eiy]?(%A)"]		=	"unfair%1",
	["[cC]hee+a*p(%A)"]		=	"cheap%1",

	["(%A)[wW]ipe%sout$"]	=	"%1perish",
	["(%A)[wW]iped%sout$"]	=	"%1perished",
--	["(%A)[wW]ipe(%A)"]		=	"%1fall%2",
	["(%A)[wW]ipe$"]		=	"%1fall to ruin",
--	["(%A)[wW]iped(%A)"]	=	"%1fell%2",
	["(%A)[wW]iped(%A*)$"]		=	"%1fell to utter ruin",

	["[nN]uker([sz]*)"]		=	"spellbinder%1",
	["[nN]uke([sz]*%A)"]	=	"blast%1",
	["[nN]uking?(%A)"]		=	"bombarding%1",
	["[nN]uked(%A)"]		=	"bombarded%1",

	["[pP]retty%smuch"]			=	"more or less",
	["[pP]retty%sdamn"]			=	"quite",
	["[dD]o%s?[yY]ou got%??$"]	=	"have you%?",
	["([^o])%s[yY]ou got%?$"]	=	"%1 do you have%?",

	["^[iI]+[nN]+[cC]+$"]				=	"We've got incoming!",

--	["(%d%d?)%s?[hH]o+a*rde?s?"]			=	"%1 of our brethren",

	["^[bB]uf+(%A)"]			=	"Bless%1",
	["[tT]he%s(%a*%s?)buff"]		=	"the %1 blessing",
	["[bB]uf+%sme"]			=	"bless me",
	["a(%s?%a*)%s[bB]uf+$"]		=	"a %1 blessing",
	["[bB]uf+e?d"]				=	"blessed",
	["^[bB]uf+[sz]*[^%d%a?]*$"]		=	"May the blessings pour forth!",
	["(%A)[rR]e+%A?buf+"]			=	"%1re%-anoint",
	["[iI]?%s?[nN]eed%srebuf+s?"]	=	"Reinvoke my blessings",
	["[tT]oo%s?buf+"]			=	"too mighty",


	["[gG]ot%s[dD]/?[cC]%a*"]		=	"drifted off",
	["[gG]et([sz]*)%s[dD]/?[cC]%a*"]	=	"drift%1 off",
	["^[dD]/?[cC]%a*$"]			=	"A short trance, maybe",

	["^[dD]on't%s[kK]now(%A)"]	=	"I don't know%1",
	["^[dD]on't%s[kK]now$"]	=	"I'm afraid I do not know",

	["^[wW][au]n[nt]?[au]h?%?*$"]	=	"Well, what say you%?",
	["^[gG]im+e+$"]		=	"Well, let me have it",
	["^[gG]oing%sto$"]		=	"All in good time",
	["^[pP]rob?[ou]?b?l+y$"]	=	"I would not be surprised",

	["^[cC]%s?[yu][ao]?u?$"]		=	"I bid you farewell",

	["(%A)[iI]n?%s?[rR]l(%A)"]	=	"%1in the world beyond%2",
	["(%A)[iI]n?%s?[rR]l$"]		=	"%1in the world beyond",
	["^[iI]n?%s?[rR]l%A"]		=	"In another world, ",
	["^[iI]n?%s?[rR]l$"]		=	"In the world beyond",

	["^[aA][fF][kK]%sfor%s?(%d+)$"]	=	"Allow me to rest for %1 minutes",
	["^[aA][fF][kK]%sin%s?(%d+)$"]	=	"I must take rest in %1 minutes",

	["^[aA][fF][kK]$"]				=	"Resting for a brief moment",



	["^[tT]ha?n?[zxc]s?(%A)"]		=	"Thanks%1",
	["^[tT][yY][tTyY]*(%A*)$"]	=	"Many thanks%1",
	["^[tT]ha?n?[zxc]s?$"]		=	"Much thanks",
	["^[tT][hn]+a[hnks]+$"]		=	"Thanks",

	["s%s[gG]ood%s[gG]ame(%A*)$"]	=	"s over%1",
	["^[gG]ood%s[gG]ame$"]		=	"We fought well",
	["^[gG]ood%s[gG]ame(%A)"]	=	"A memorable battle%1",
--	["^[nNgG][fF]"]	=	"You fought valiantly",
--	["(%A)[nN][fF]$"]	=	"%1captivating fight",

--	["(%A)[mM][tT]$"]		=	"%1did I say that out loud%?",
	["^[mM][tT](%p)"]		=	"Pay that no mind%1",
	["^[mM][tT]$"]			=	"Sorry, I'm afraid I've misspoken",

	["(%A)[pP]l+[zs]+(%A)"]	=	"%1please%2",
	["%s+[pP]l+[zs]+$"]		=	", please",
	["(%p)[pP]l+[zs]+$"]	=	"%1 please",
	["^[pP]l+[zs]+(%p)"]	=	"I beg you%1",
	["^[pP]l+[zs]+%s"]		=	"Please ",
	["^[pP]l+[zs]+$"]		=	"If it would please you%.%.%.",

--	["^[aA]sk%s(%a%a+)%sfor"]			=	"May you beseech %1 for",

--	Replace 'ill' and 'il' in limited circumstances
	["^[iI][\"/;:]?[lL][lL]?(%A)"]			=	"I'll%1",
	["(%p)%s?[iI][\"/;:]?[lL][lL]?%s"]		=	"%1 I will ",
	["[aA]nd%s?[iI][\"/;:]?[lL][lL]?%s"]	=	"and I will ",

--	Replace 'cu' and 'c u'
	["^[cC]%s?[yu][ao]?u?(%A)"]		=	"May we meet again%1",
	["^[cC]%s?[yu][ao]?u?$"]		=	"Go with honor!",

--	Replace woot, WOOOOOOT, w00t and WOOHAA
	["(%A)[wW][eoO0][oO0]+[tTrhH]*[zZoO0]*[hH]*(%A)"]	=	"%1hurray%2",
	["([^%d%a%s!,.])[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"%1 Fantastic!",
	["[%s!,.]+[wW][eoO0][oO0]+[tTrhH]*[oO0]*[hH]*$"]	=	"! May this deed be remembered!",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*(%p)"]		=	"Fantastic%1",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*%s"]			=	"Victory! ",
	["^[wW][eoO0][oO0]+[%stTrRhH]*[o0]*h*$"]			=	"Huzzah!",
	["^[bB][o0]+y+a+h*"]				=	"Eat that!",


--	Replace k, kk, OK, and okay

	["^[oO]+k+[iey]+%A*[dD]ok%a+"]	=	"Agreed%. ",
	["^[mM]+[kK]+[aA]*[yY]*"]				=	"If you say so%. ",

	["^[sS]h?ure(%A)"]	=	"Certainly%1",
	["^[sS]h?ure$"]		=	"Of course",

	["^[yY][aA]%s([bBiI])"]		=	"Yes, %1",
	["^[yY][aA]%s([tTwW])[hH](%a)"]		=	"Yes, %1h%2",
	["^[yY][aAeE]+[hH]%s"]		=	"Indeed, ",
--	["(%A)[yY][aA]$"]	=	"%1you, my friend",

	["^[gG]ot%s?it$"]		=	"I've got it",
	["^[gG]ot%s?it%?$"]		=	"Have you got it%?",
	["^[gG]ot?cha$"]		=	"I've got you",
	["^[iI]%s?[gG]ot?cha$"]	=	"I follow",

	["^[fF]ollow$"]	=	"Follow my lead",

	["^[gG][lL](%A*)$"]			=	"May fortune favor you%1",


	["^[nN]ice%s?[tT]ry$"]			=	"A valiant effort",
	["^[nN]ice%s?[tT]ry%p+$"]			=	"A glorious effort!",

--	Replace rdy and RDY with various forms for variety
	["^[rR]eady%?"]		=	"Are we ready%?",
	["^[rR]eady!+"]		=	"I'm ready for anything!",
	["^[rR]eady$"]			=	"I am ready",

	["(%A)[rR]eal%s?[fF]ast(%p*)$"]		=	"%1as soon as may be%2",
	["(%A)[rR]eal%s?[qQ]uickl?y?(%p*)$"]		=	"%1with haste%2",
	["(%A)in%s?a%s?hur+y"]		=	"%1in haste",

	["(%A)[pP]u+l+%s([^%p%s%dsSaA])"]	=	"%1lure %2",
	["^[pP]u+l+(%A)"]		=	"Lure%1",
	["(%A)[pP]u+l+$"]		=	"%1lure",
	["^[pP]u+l+$"]			=	"Go and make our presence known",
	["^[pP]u+l+%p+$"]			=	"Let battle be joined!",
	["^[pP]u+l+[ie]+n+g+$"]	=	"Now I'll cast the bait!",
	["^[pP]u+l+[ie]+n+%p*$"]		=	"Prepare for battle!",

	["^[sS]h?pam+(%a*%A)"]	=	"Chatter%1",
	["(%A)[sS]h?pam+(%a*%A)"]	=	"%1blather%2",
	["(%A)[sS]h?pam+$"]	=	"%1babble",
	["(%A)[sS]h?pam+(%a+)$"]	=	"%1gibber%2",

	["^[nN]+a+[wh]*%s"]		=	"No, ",
	["^[nN]+a+[wh]*(%p)"]	=	"No%1",
	["^[nN]+a+[wh]*$"]		=	"I think not",

	["^[bB]ye[^%d%a?]*$"]	=	"Safe travels, friend!",




--	["[oO]n%s(%a+)%s[sS]erver"]		=	"in %1 realm",

	["(%A)[gG]anking(%A)"]		=	"%1murdering%2",
	["(%A)[gG]anking$"]		=	"%1hunting lesser foes",

	["(%A)[gG]ankfest(%A)"]	=	"%1bloodbath%2",
	["([%s%p])[gG]ank([%s%p])"]	=	"%1butcher%2",
	["^[gG]ank(%A)"]	=	"Kill%1",
	["(%A)[gG]ank$"]	=	"%1slay",
	["^[gG]ank$"]		=	"Let none survive!",
	["%f[%a][gG]o%s?[gGo][gGo%s%p]+%f[%A]"]	=	"forward!",



	["^[dD]i+n+g+%p*$"]			=	"My powers have grown!",
	["(%A)[dD]ing(e?d)%p*$"]		=	"%1gain%2 a level",
	["(%A)[dD]+i+n+g+(%p)"]		=	"%1gain a level%2",
	["(%A)[dD]ing(e?d?)%s?(%d+)"]	=	"%1reach%2 level %3",
	["^[dD]ing(e?d?)[%s%p]*(%d+)"]	=	"Attain%1 level %2",

	["(%A)[bB]um+er(%A)"]	=	"%1pity%2",

	["(%A)[pP0]+[wW]+[nN]+(%A)"]	=	"%1destroy%2",
	["(%A)[pPoO0]+wn+[sz]+(%A)"]	=	"%1dominates%2",

	["(%A)[pPoO0]+w+n+e?[dt]+"]	=	"%1trounced",
	["^[pPoO0]+wn+e?[dt]+(%A)"]	=	"Trampled%1",
	["^[pPoO0]+wn+e?[dt]+$"]	=	"Victory!",

	["(%A)[pPoO0]+w+n+ing?"]	=	"%1dominating",
	["^[pPoO0]+w+n+ing?"]		=	"Dominating",

	["(%A)[uU]+b[ea]r(%A)"]	=	"%1mighty%2",
	["^[uU]+b[ea]r(%A)"]		=	"Mighty%1",
	["(%A)[uU]+b[ea]r$"]		=	"%1formidable",
	["^[uU]+b[ea]r$"]			=	"Such strength!",

--	Replace 'my bad'
	["(%A)[mM]y%s?[bB]ad(%A)"]	=	"%1my fault%2",
	["^[mM]y%s?[bB]ad(%A)"]		=	"I am to blame%1",
	["^[mM]y%s?[bB]ad$"]		=	"That was my fault",

	["^[eE]l+o$"]			=	"Well met",
--	["^[eE]l+o(%A+%a+%A*)$"]		=	"Why, hello%1",

	["^[yY][oO][yYoO]*[^%a%d|?]+"]	=	"Hello, ",
	["^[yY][oO][yYoO]*$"]	=	"Well met!",

	["(%a%a)[%s%p]+[yY][oO](%A*)$"]	=	"%1%2",

	["^[nN]oo+%A"]		=	"No!! ",
	["%sso%s?not(.*)$"]		=	" surely not%1",
	["(%a)s%ssoo+%s(%a%a%a%a%a+)"]	=	"%1s quite %2",
	["^[sS]oo+(%A)"]		=	"So%1",

	["^[iI]%s?[bB]et%s(%a%a)"]	=	"Doubtless %1",

	["^[iI]%s?swa?ea?r%A"]	=	"Mark my words, ",

	["^[iI]%s?[gG]uess(%A[^sS])"]	=	"I suppose%1",
	["(%A)[iI]%s?[gG]uess$"]	=	"%1, should I venture to guess",
	["^[iI]?%s?[gG]uess%s?[sS]o$"]	=	"I would suppose so",
	["^[iI]%s?[gG]uess%s?$"]	=	"So it seems",

	["^[mM]a+y*b+e%s(%a)"]		=	"Perhaps %1",
	["^[mM]a+y*b+e%s?(%d)"]	=	"I would estimate %1",
	["(%A)[mM]a+y*b+e%s?(%d)"]	=	"%1about %2",
	["^[lL]oo+k+s%slike"]		=	"It looks like",
	["[iI]m[jJ]ust(%A)"]		=	"I am just%1",

	["^[pP]r[aoub]*l+y$"]			=	"Perhaps it is so",

	["[nN]inja$"]					=	"snitch",
--	["[aA]%s?[nN]inja(%A[^lL])"]	=	"a burglar %1",
--	["[tT]he%s?[nN]inja(%A[^lL])"]	=	"the thief %1",
--	["[nN]injas"]					=	"snitches",

	["([^aA])%s[nN]inja%s([^tTlL])"]	=	"%1 snitch %2",

	["([^aA])%s[nN]inja%s[tT]h"]	=	"%1 pilfer th",

	["[nN]inja['e]?d"]				=	"stole",
	["[nN]inja?in['g]?"]			=	"stealing",
	["[nN]inja%s?lootin['g]?"]		=	"swiping",
	["[nN]inja%s?looter"]			=	"swindling scoundrel",
	["[nN]inja%s?looted"]			=	"snitched",


	["[hH]ad%s?[mM]e(%A*)$"]	=	"had me beaten%1",

--	["^[sS]+h?[au]*w+e+t+$"]		=	"Fantastic!",
--	["[sS]+h?[au]*w+e+t+(%A)"]	=	"Fantastic%1",
--	["(%A)[sS]+h?[au]*w+e+t+([^|%a][^|]*)$"]		=	"%1wonderful%2",
--	["(%A)[aA]w+e?some?"]	=	"%1amazing",
--	["^[aA]w+e?some?(%A)"]		=	"Amazing%1",
--	["^[aA]w+e?some?$"]		=	"Magnificent",

	["^[pP][pP][lL][eE]?$"]			=	"My brethren%.%.%.",
	["%s[fF]or%s[tT]he%s[wW]in[^%a%d|?]+"]	=	" for triumph and glory! ",
	["%s[fF]or%s[tT]he%s[wW]in$"]	=	" for certain victory! ",
	["%s[fF4][tT][lL]%p*$"]		=	" will never earn much respect",
	["^[fF]or%s[tT]he%s[wW]in$"]		=	"Victory!",


--	Replace 'coo' and 'k00l' and 'coolz' and 'koools'
	["([^%a|])[cCkK][oO0][oO0]+[lL]?[sz]*(%A)"]	=	"%1good%2",
	["([^%a|])[cCkK][oO0][oO0]+[lL]?[sz]*$"]		=	"%1great",
	["^[cCkK][oO0][oO0]+[lL]?[sz]*(%A)"]		=	"Great%1",
	["^[cCkK][oO0][oO0]+[lL]?[sz]*$"]		=	"Very good",

	["[pP]iss[e']?d(%A-)$"]		=	"upset%1",

	["(%A)[nN]ub([sz]*%A)"]		=	"%1novice%2",
	["^[nN]ub([sz]*%A)"]		=	"Amateur%1",
	["(%A)[nN]ub([sz])$"]		=	"%1novice%2",

	["(%a%a%a%A)[nN]ub(%A*)$"]		=	"%1, you fool%2",

	["^[nN]ub[sz]*$"]			=	"How amateurish!",

	["^[wW][eo][rt]d%p*$"]			=	"Truth be told!",

	["(%A)[lL]am[ea]r(%A)"]			=	"%1cretin%2",
	["(%A)[lL]lam+a+(%A)"]				=	"%1charlatan%2",


	["^[rR]ox+(%A)"]			=	"Truly excels%1",
	["(%A)[rR]ox+$"]			=	"%1reigns supreme",
	["(%A)[rR]ox+(%A)"]			=	"%1excels%2",

	["[hH]a+xk?z?[o0]r"]	=	"cheat",
	["[rR][o0]x+z?[o0]r[sz]*"]	=	"dominates",

--	["^[rR]ule?[sz]+(%A)"]		=	"Truly superior%1",
	["(%A)[iI]t%s[rR]ule?[sz]+$"]		=	"%1it trounces the competition",
--	["(%A)[rR]ule?[sz]+(%A)"]	=	"%1reigns over%2",

--	Replace the kissing <3
	["^I?%s?<3+%s?([%d%a])"]		=	"Thank goodness for %1",
	["^<3+$"]				=	"Kisses",
	["(%w)%s?<3+%s?(%w)"]	=	"%1 will always adore %2",
	["(%a.-)<3+$"]		=	"%1",

--	Change 'sexy' 'sexier' 'sexiest' etc.
	["[sS]exa-[iey]+(%A)"]	=	"adorable%1",
	["[sS]exa-[iey]+$"]	=	"lovely",
	["[sS]exi(%a)"]	=	"loveli%1",

--	Replace 'pimp' in limited circumstances
	["^[pP]imp%s(%a)"]	=	"Stunning %1",
	["[sS]o+%s[pP]imp"]	=	"quite stunning",

	["^[nN]ice(%A)"]	=	"Fantastic%1",
--	["(%A)[nN]ice$"]	=	"%1good",
--	["(%A)[nN]ice(%A)"]	=	"%1fine%2",
	["^[nN]ice$"]		=	"Splendid",

	["^(%d)%s?[hH]o+a*rde?s?"]		=	"%1 Hordlings",
--	["^(%d)%s?[aA]l+iance?"]			=	"%1 Allies",

	["'s%s[uU]p%s?[fF]or(%A)"]		=	"'s ready for%1",
	["one%s[uU]p%s?[fF]or(%A)"]		=	"one ready for%1",

	["'s%s[dD]own%s?[fF]or(%A)"]		=	"'s interested in%1",
	["one%s[dD]own%s?[fF]or(%A)"]		=	"one interested in%1",

	["(%d)%s?[vV]s?%s?(%d)"]	=	"%1 vs %2",
	["(%d)%s?[oO]n%s?(%d)"]	=	"%1 against %2",

--	Replace LOL, lolol, rofl, and ROFL
	["^[%s%p]+[lLrR][oO0][fF]?[lL]%p*$"]	=	"Hah!",

	["(%a[.!?]+)%s*[lLrR][oO0][fF]?[lL]%p*$"]	=	"%1",
	["(%a)[%s!,.]+[lLrR][oO0][fF]?[lL]%s"]	=	"%1, haha, ",
	["(%a)[%s!,.]+[rR][oO0][fF][lL][^%a%d%s|?]+"]	=	"%1, heheh!",
	["(%a)[%s!,.]+[lL][oO0][lLoO0]+[^%a%d|?]+"]		=	"%1! ",
	["(%d)[%s,;@`.\\|/!?]+[rR][oO0][fF][lL]?%p*$"]	=	"%1%? You can't be serious!",
	["(%d)[%s,;@`.\\|/!?]+[lL][oO0][lL]*%p*$"]	=	"%1!",

	["(%a)[%s!,.]+[lL][oO0][lL]+%p*$"]	=	"%1, hah!",
	["(%a)[%s!,.]+[rR][oO0][fF][lL]+%p*$"]	=	"%1, haha!",

	["^[lL][oO0][lL]+[sz]*[^@%d%a|]+"]				=	"Hah! ",
	["^[rR][oO0][fF][lL]+[sz]*[^@%d%a|]+"]				=	"Ahaha! ",

	["^[lL][oO0][lL]+[sz]*%s*@+%s*(%a+)[!1`~]*$"]				=	"Funny, %1",
	["^[rR][oO0][fF][lL]+[sz]*%s*@+%s*(%a+)[!1`~]$"]				=	"I can't help but laugh at %1",
	["^[lL]+[aA]?[mM]+[fFaA]+[oO0]%s*@+%s*(%a+)[!1`~]*$"]				=	"%1 is too funny!",


	["^[rR][oO0][tT]?[fF][lL]%a*%p*$"]	=	"That's hilarious!",
	["^[lL][oO0][lLoO0]+%p*$"]	=	"Ahaha!",
	["^[lL][oO0][lLoO0]+[zZ]+%p*$"]	=	"That's quite funny!",
	["^[lL][oO0][lLoO0]+[sS]+%p*$"]	=	"Now that's a laugh!",

	["^[kK]ind%sof$"]	=	"Yes, to some extent",
	["^[sS]h?ort%sof$"]	=	"To a certain extent",

--	Supplement truncated grammar
	["(%a)s%s[lL]ike%s(%a-)ble"]		=	"%1s nigh %2ble",
	["(%a)s%s[lL]ike%s(%a-)ous"]		=	"%1s all but %2ous",

--	["^[lL]ast%s?time%s(%a)"]		=	"When last %1",

	["^[lL]ike%s?(%d)"]				=	"roughly %1",
	["([^sd])%s[lL]ike%s?(%d)"]				=	"%1 around %2",
	["(%d)[%s%-]?ish"]					=	"%1 or so",
	["^[yY]ou%s?[sS]o+%s(%a%a+)"]		=	"Indeed you %1",
	["^[wW]e%s?[sS]o+%s(%a%a+)"]		=	"None can deny that we %1",

	["[mM]s+g%s?me"]			=	"contact me",

--	Change PST, pst, pgt etc.
	["(%d+)[pP][gGsS]*[tTwW]+%s?[mM]?[eE]?!*(%A)"]	=	"%1, ask me %2",
	["[%p%s]+[pP][gGsS]*[tTwW]+%s?[mM]?[eE]?!*(%A)"]	=	"%. ask me %1",
	["|r[pP][gGsS]*[tTwW]+%s?[mM]?[eE]?!*(%A)"]	=	"|r%. Send word %1",
	["^[pP][gGsS]*[tTwW]+%s?[mM]?[eE]?(%A)"]		=	"Send word %1",
	["(%A)[pP][gGsS]*[tTwW]+%s?[mM]?[eE]?$"]		=	"%1, ask me",
	["^[pP][gGsS]*[tTwW]+%s?[mM]?[eE]?$"]			=	"Please let me know",

},

[8] = {

	["[mM]ore%s?roughly%s(%d)"]				=	"closer to %1",
	["[tT]hin['g]?%s?roughly%s(%d)"]				=	"thing like %1",

--	Re-filter high-level '??' to 'untold' so that it reads "A Druid of Untold Seasons".
	["(%a)%sof%s~%?%?~%s(%a)"]	=	"%1 of Untold %2",
	["~%?%?~%s[tT]o%s[mM]e"]	=	"beyond my reckoning",

	["([wW])hat%sis%sthe%snews%swith%s"]	=	"%1hat is the matter with",

--	["([gG][eo])t([sz]*)%sal+%s([^tT%s%d%p][^hH%s%d%p]%a%a-[^sz%s%d%p])"]	=	"%1t%2 so %3",

--	["^[yY][oua]+%sbet+er"]			=	"I would advise you to",
--	["[yY]ou%s?[gG]ot%sto(%A)"]	=	"you ought to%1",
--	["[wW]e%s?[gG]ot%sto(%A)"]	=	"we must%1",
--	["^[gG]ot%sto(%A[^?]+)$"]	=	"I must%1",
	["^[eE]n[ou]+ght?%s[wW]ith(%A)"]	=	"I have heard enough of%1",
	["^[nN]eed%s([^tT][%a%s]*)%?$"]		=	"Could you use %1%?",
	["^[nN]eed%s[aA]%s([^?]+)$"]		=	"I need a %1",
--	["^[nN]eed%s(%a%a-s[^?]+)$"]		=	"I am in need of %1",
--	["^[nN]eed%s[tT]o%s([^?]+)$"]	=	"I must %1",
	["^[wW]ant%s([^tT][%a%s]*)%?$"]		=	"Would you like %1%?",
	["^[wW]ant%s[tT]o%s([%a%s]*)%?$"]		=	"Would you like to %1%?",
--	["^[wW]ant%s[tT]o%s([^?]+)$"]	=	"I would like to %1",
--	["^[fF]orgot%s([^?]+)$"]	=	"I am afraid that I forgot %1",
	["^[wW]anted%s[tT]o%s([^?]+)$"]	=	"I had sought to %1",

--	["^[cC]an%sI%shave%s([%a%s]*)%p*$"]		=	"Could I have %1%?",
--	["^[cC]an%sI%sget%s([%a%s]*)%p*$"]		=	"Could I possibly have %1%?",
--	["^[cC]an%syou%give%sme%s([%a%s]+)%p*$"]		=	"Could I trouble you for %1%?",

	["^[sS]h?ee%sth(.-)%?$"]		=	"can you see th%1%?",

	["^[wW]a+y+%s?to+%sma[ny]+"]			=	"I find far too many",
	["^[wW]a+y+%s?to+%smu[ch]+%s"]			=	"I find an excessive amount of",
	["s[%s!,.]+[wW]a+y+%s(%a-)er%s"]	=	"s much %1er",
	["(|r[%s!,.]+)[wW]a+y+%s(%a-)er%s"]	=	"%1 far %2er ",
	["I%s[gG]ot%s(%a%a%a-)ed$"]		=	"I was %1ed",
	["I%s[gG]ot%s(%a%a%a-)ed([%s%p])"]		=	"I was %1ed%2",

	["(%A)[sS]h?o+%s(%a%a-)ed$"]		=	"%1utterly %2ed",

	["([wW])e%s[gG]ot%s(%a+)ed"]	=	"%1e were %2ed",
	["[sS]ho?ul?da"]			=	"ought to have",

},





[14]={
	["(%A)[jJ]us([ts])%s[iI]s%s(%a%a+%A)"]		=	"%1is jus%2 %3",

	["(%A)[mM]ount%s[uU]p(%A)"]		=	"%1saddle up%2",
	["(%A[wW]ould.-%s[bB]e%s)[nN]ice(%A)"]		=	"%1fitting%2",


	["[pP]iss?%s(.-)off"]		=	"make %1 angry",
	["[pP]isses%s(.-)off"]		=	"irritates %1",
	["[pP]isse?d%s(.-)off"]		=	"infuriated %1",
	["[pP]issing?%s(.-)off"]		=	"annoying %1",



},
[15]={
	["([?!]+)[^%a~\")]+$"]	=	"%1 ",
},
[18]={

	["^Haha,%s(...-haha%A*)$"]	=	"%1",

},
}

