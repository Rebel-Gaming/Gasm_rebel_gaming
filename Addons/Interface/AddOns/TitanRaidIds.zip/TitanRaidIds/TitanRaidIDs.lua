local RAIDIDS_ID = "RaidIDs";
GRAY_FONT_COLOR_CODE = "|cff808080";
WHITE_FONT_COLOR_CODE = "|cffFFFFFF";
TITAN_RAIDIDS_ARTWORK_PATH = "Interface\\AddOns\\TitanRaidIDs\\"

local debugTitanRaidIDs = 0;

local numSavedInstances = 0;
local currentPlayer = UnitName('player') --the name of the current player that's logged on
local currentRealm = GetRealmName() --what currentRealm we're on

function TitanPanelRaidIDsButton_OnLoad()
	this.registry = { 
		id = "RaidIDs",
		menuText = TITAN_RAIDIDS_MENU_TEXT, 
		buttonTextFunction = "TitanPanelRaidIDsButton_GetButtonText", 
		tooltipTitle = TITAN_RAIDIDS_TOOLTIP,
		tooltipCustomFunction = TitanPanelRaidIDsButton_SetTooltipText,
		iconWidth = 16,
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = 1,
		}
	};
	
	this:RegisterEvent("PLAYER_ENTERING_WORLD");
    this:RegisterEvent("UPDATE_INSTANCE_INFO");
    this:RegisterEvent("PLAYER_LEAVING_WORLD");
    this:RegisterEvent("RAID_INSTANCE_WELCOME");
    
    TitanPanelRaidIDs_UpdateInfo();
end

function TitanPanelRaidIDsButton_OnEvent(self, event, ...)
	
	if event == "UPDATE_INSTANCE_INFO" then
		numSavedInstances = GetNumSavedInstances();
		TitanPanelRaidIDs_NumIDs();
		TitanPanelRaidIDs_SaveRaids(); 
	else	
    	TitanPanelRaidIDs_UpdateInfo();	   	
	end		
	
	TitanPanelButton_UpdateButton("RaidIDs");	
	TitanPanelButton_UpdateTooltip();
	    
end

function TitanPanelRaidIDs_NumIDs()
	local numIDs = 0;
	
	for i=1, numSavedInstances do
		local name, id, remain, difficulty = GetSavedInstanceInfo(i);
		if (remain > 0) then
			numIDs = numIDs + 1;
		end	
	end
	
	numSavedInstances = numIDs;
	
end

function TitanPanelRaidIDs_SaveRaids()

	if debugTitanRaidIDs == 1 then print("Saving Raid-IDs..."); end

	if TitanPanelRaidIDs_Storage == nil then
		TitanPanelRaidIDs_Storage = {};
	end
	
	if numSavedInstances > 0 then
	
		if TitanPanelRaidIDs_Storage[currentRealm] == nil then
			TitanPanelRaidIDs_Storage[currentRealm] = {};
		end
		
		TitanPanelRaidIDs_Storage[currentRealm][currentPlayer] = {};
		
		TitanPanelRaidIDs_Storage[currentRealm][currentPlayer].savingTime = time();
		
		for i=1, numSavedInstances do
			local name, id, remain, difficulty, locked, extended, instanceIDMostSig, isRaid, maxPlayers, difficultyName   = GetSavedInstanceInfo(i);
			local instStr = name;
			
			if difficulty > 1 then
				instStr = instStr .. " - " .. difficultyName .. " ";
			end
					
			if TitanPanelRaidIDs_Storage[currentRealm][currentPlayer][id] == nil then
				TitanPanelRaidIDs_Storage[currentRealm][currentPlayer][id] = {};
			end 
			
			TitanPanelRaidIDs_Storage[currentRealm][currentPlayer][id].name = instStr;
			TitanPanelRaidIDs_Storage[currentRealm][currentPlayer][id].remaining = remain;		
			        
		end
	end
end

function TitanPanelRaidIDs_UpdateInfo()
    -- refresh the list of Raid-IDs
	RequestRaidInfo();    
end

function TitanPanelRaidIDsButton_OnEnter()
	TitanPanelRaidIDs_UpdateInfo();
end

function TitanPanelRaidIDsButton_GetButtonText(id)
	local id = TitanUtils_GetButton(id, true);

	return TITAN_RAIDIDS_BUTTON_LABEL, TitanUtils_GetGreenText(numSavedInstances);
end

function TitanPanelRaidIDsButton_SetTooltipText()

    -- Tooltip title
	GameTooltip:SetText(TITAN_RAIDIDS_TOOLTIP, HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
	GameTooltip:AddLine(" ");

	
	for i=1, numSavedInstances do
		local name, id, remain, difficulty, locked, extended, instanceIDMostSig, isRaid, maxPlayers, difficultyName   = GetSavedInstanceInfo(i);
		local instStr = name;
			
		if difficulty > 1 then
			instStr = instStr .. " - " .. difficultyName .. " ";
		end
		
		if remain > 0 then		
			GameTooltip:AddDoubleLine(instStr,"" .. GRAY_FONT_COLOR_CODE .. id .. FONT_COLOR_CODE_CLOSE);
			GameTooltip:AddLine(WHITE_FONT_COLOR_CODE .. TitanPanelRaidIDsButton_GetRemainingInstanceTimeText(remain) .. FONT_COLOR_CODE_CLOSE);
			GameTooltip:AddLine(" ");
		end
		        
	end
	
	if TitanPanelRaidIDsButton_tcount(TitanPanelRaidIDs_Storage[currentRealm]) > 1 then		
		TitanPanelRaidIDsButton_LoadAltsIDs()
	end
	
end

function TitanPanelRaidIDsButton_LoadAltsIDs()
	for name, raids in pairs(TitanPanelRaidIDs_Storage[currentRealm]) do
		if name ~= currentPlayer then
			TitanPanelRaidIDsButton_ShowAltRaids(name, raids);
		end
	end
end

function TitanPanelRaidIDsButton_ShowAltRaids(name, raids)
	GameTooltip:AddLine("--------------------------"); 
	GameTooltip:AddLine(name);
	GameTooltip:AddLine("--------------------------");
	for id, raid in pairs(raids) do
		if tonumber(id) and (raids.savingTime + raid.remaining) > time() then
			local endTime = raids.savingTime + raid.remaining;
			local remain = endTime - time();
			
			GameTooltip:AddDoubleLine(raid.name,WHITE_FONT_COLOR_CODE .. TitanPanelRaidIDsButton_GetRemainingInstanceTimeText(remain) .. FONT_COLOR_CODE_CLOSE);
		end
	end
end

function TitanPanelRaidIDsButton_GetRemainingInstanceTimeText(seconds)

	local days = floor(seconds / 86400);
	seconds = seconds - days * 86400;
	
	local hours = floor(seconds / 3600);
	seconds = seconds - hours * 3600;
	
	local minutes = floor(seconds / 60);
	
	seconds = seconds - minutes * 60;
	
	local timeStr = TITAN_RAIDIDS_COOLDOWN_INFO[1] .. " ";
	
	if days > 0 then
		timeStr = timeStr .. days .. " " .. TITAN_RAIDIDS_COOLDOWN_INFO[2] .. " ";
	end
	
	if hours > 0 then
		timeStr = timeStr .. hours .. " " .. TITAN_RAIDIDS_COOLDOWN_INFO[3] .. " ";
	end
	
	if minutes then 
		timeStr = timeStr .. minutes .. " " .. TITAN_RAIDIDS_COOLDOWN_INFO[4] .. " ";
	end
	
	if seconds > 0 then
		timeStr = timeStr .. seconds .. " " .. TITAN_RAIDIDS_COOLDOWN_INFO[5];
	end

	return timeStr;
end

-- tcount: count table members even if they're not indexed by numbers
function TitanPanelRaidIDsButton_tcount(tab)
	local n=0;
	if not tab then
		return 0 
	end
	for _ in pairs(tab) do
		n=n+1;
	end
	return n;
end 

