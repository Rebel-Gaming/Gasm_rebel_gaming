DBM:RegisterMapSize("PitofSaron", 0, 1533.333, 1022.917) -- Pit of Saron
