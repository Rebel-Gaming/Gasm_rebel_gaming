DBM:RegisterMapSize("UtgardeKeep",
	1, 734.580993652, 489.7215003964,	-- Norndir Preperation
	2, 481.081008911, 320.7202930448,	-- Dragonflayer Ascent
	3, 736.581008911, 491.0545120241	-- Tyr's Terrace
)
