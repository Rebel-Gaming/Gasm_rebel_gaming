DBM:RegisterMapSize("DrakTharonKeep",
	1, 619.93917093835, 413.29113734848,	-- The Vestibules of Drak'Tharon
	2, 619.93877606243, 413.29435426682		-- Drak'Tharon Overlook
)
