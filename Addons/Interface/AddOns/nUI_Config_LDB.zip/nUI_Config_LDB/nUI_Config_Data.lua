
------------------------------------------------------------------------
-- [v2.01.00] New Config File for Slash Command Data and Menu Setup
------------------------------------------------------------------------

------------------------------------------------------------------------
-- [v2.01.00] Make sure Tables exist
------------------------------------------------------------------------
if not nUI_Config_Options then nUI_Config_Options = {}; end
if not nUI_Config_Menu then nUI_Config_Menu = {}; end

-------------------------------------------------------------
-- [v2.01.00] Local Tables and functions
-------------------------------------------------------------
local _L                        = nUI_Config_LDB_L;

------------------------------------------------------------------------
-- [v2.01.00] Get Range Function to generate a range of numbers
------------------------------------------------------------------------
local function GetRange(min,max,smallstep,bigstep,firstblock)
	local t = {};
	local range = max - min;
	local counter = range / smallstep;
	if ( counter > 30 ) then
		for i = min, min + firstblock - 1, smallstep do
			table.insert(t,i);
		end
		for i = min + firstblock , max, bigstep do
			table.insert(t,i);
		end
	else
		for i = min,max,smallstep do
			table.insert(t,i);
		end
	end
	return t;
end

------------------------------------------------------------------------
-- [v2.01.00] Menu Initialisation Data
------------------------------------------------------------------------
local function InitMenuHeaders()

	nUI_Config_Menu["main"] = nUI_Config_Menu["main"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["main"].arrow = true;
	nUI_Config_Menu["main"].menus = { "console", "dashboard", "hud", "display", "tooltip" };

	nUI_Config_Menu["console"] = nUI_Config_Menu["console"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["console"].arrow = true;
	nUI_Config_Menu["console"].options = { "console", "framerate" } ;
	nUI_Config_Menu["console"].display = _L["CONSOLE_MENU"];
	
	nUI_Config_Menu["dashboard"] = nUI_Config_Menu["dashboard"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["dashboard"].arrow = true;
	nUI_Config_Menu["dashboard"].menus = { "bagbar", "buttonbar", "feedback", "location", "minimap", "raid" };
	nUI_Config_Menu["dashboard"].display = _L["DASHBOARD_MENU"];
	
	nUI_Config_Menu["bagbar"] = nUI_Config_Menu["bagbar"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["bagbar"].arrow = true;
	nUI_Config_Menu["bagbar"].parent = "dashboard";
	nUI_Config_Menu["bagbar"].options = { "bagbar", "onebag", "bag_scale" };
	nUI_Config_Menu["bagbar"].display = _L["BAGBAR_MENU"];

	nUI_Config_Menu["feedback"] = nUI_Config_Menu["feedback"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["feedback"].arrow = true;
	nUI_Config_Menu["feedback"].parent = "dashboard";
	nUI_Config_Menu["feedback"].options = { "feedback_curse", "feedback_magic", "feedback_poison", "feedback_disease", "show_hits", "show_anim", "hplost" };
	nUI_Config_Menu["feedback"].display = _L["FEEDBACK_MENU"];

	nUI_Config_Menu["location"] = nUI_Config_Menu["location"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["location"].arrow = true;
	nUI_Config_Menu["location"].parent = "dashboard";
	nUI_Config_Menu["location"].options = { "clock" };
	nUI_Config_Menu["location"].display = _L["LOCATION_MENU"];

	nUI_Config_Menu["minimap"] = nUI_Config_Menu["minimap"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["minimap"].arrow = true;
	nUI_Config_Menu["minimap"].parent = "dashboard";
	nUI_Config_Menu["minimap"].options = { "minimap", "round_map", "calendar" };
	nUI_Config_Menu["minimap"].display = _L["MINIMAP_MENU"];
	
	nUI_Config_Menu["display"] = nUI_Config_Menu["display"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["display"].arrow = true;
	nUI_Config_Menu["display"].options = { "map_coords", "movers", "mount_scale", "max_auras" };
	nUI_Config_Menu["display"].display = _L["DISPLAY_MENU"];	
	
	nUI_Config_Menu["raid"] = nUI_Config_Menu["raid"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["raid"].arrow = true;
	nUI_Config_Menu["raid"].parent = "dashboard";
	nUI_Config_Menu["raid"].options = { "auto_group", "raid_sort" };
	nUI_Config_Menu["raid"].display = _L["RAID_MENU"];

	nUI_Config_Menu["hud"] = nUI_Config_Menu["HUD"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["hud"].arrow = true;
	nUI_Config_Menu["hud"].menus = { "alpha", "cooldowns", "visuals" };
	nUI_Config_Menu["hud"].display = _L["HUD_MENU"];
	
	nUI_Config_Menu["visuals"] = nUI_Config_Menu["visuals"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["visuals"].arrow = true;
	nUI_Config_Menu["visuals"].parent = "hud";
	nUI_Config_Menu["visuals"].options = { "healthrace", "scale", "show_npc", "hgap", "vofs", "show_focus" };
	nUI_Config_Menu["visuals"].display = _L["HUD_VISUALS_MENU"];
	
	nUI_Config_Menu["tooltip"] = nUI_Config_Menu["tooltip"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["tooltip"].arrow = true;
	nUI_Config_Menu["tooltip"].options = { "tooltips", "combat_tooltips" };
	nUI_Config_Menu["tooltip"].display = _L["TOOLTIP_MENU"];
		
	nUI_Config_Menu["alpha"] = nUI_Config_Menu["alpha"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["alpha"].arrow = true;
	nUI_Config_Menu["alpha"].parent = "hud";
	nUI_Config_Menu["alpha"].options = { "hud_alpha_idle", "hud_alpha_regen", "hud_alpha_target", "hud_alpha_combat" };
	nUI_Config_Menu["alpha"].display = _L["HUD_ALPHA_LEVELS_MENU"];
	
	nUI_Config_Menu["cooldowns"] = nUI_Config_Menu["cooldowns"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["cooldowns"].arrow = true;
	nUI_Config_Menu["cooldowns"].parent = "hud";
	nUI_Config_Menu["cooldowns"].options = { "hud_cooldown", "mincooldown", "hud_cdalert", "hud_cdsound" } ;
	nUI_Config_Menu["cooldowns"].display = _L["HUD_COOLDOWNS_MENU"];
	
	nUI_Config_Menu["buttonbar"] = nUI_Config_Menu["buttonbar"] or { check = false, arrow = false, menus = nil, options = nil, parent = nil, display = nil };
	nUI_Config_Menu["buttonbar"].arrow = true;
	nUI_Config_Menu["buttonbar"].parent = "dashboard";
	nUI_Config_Menu["buttonbar"].options = { "barcooldowns", "bardurations", "barmacronames", "barstackcounts", "barkeybindings", "bardimming", "barmouseover", "dimmingalpha" , "bartotems"} ;
	nUI_Config_Menu["buttonbar"].display = _L["BUTTON_BAR_MENU"];
end

------------------------------------------------------------------------
-- [v2.01.00] nUI's Hud Visual Slash Commands and Variables
------------------------------------------------------------------------
local function InitHudOptions()

	nUI_Config_Options["healthrace"] = nUI_Config_Options["healthrace"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["healthrace"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["healthrace"].slash2 = nUI_SLASHCMD_HUD_HEALTHRACE;
	nUI_Config_Options["healthrace"].toggle = true;
	nUI_Config_Options["healthrace"].get = function() return nUI_Options.hud_healthrace; end
	nUI_Config_Options["healthrace"].display = _L["HEALTHRACE_DISPLAY"];

	-- Threat Bar currently not available in nUI so disabling until it is
	--[[
	nUI_Config_Options["threatbar"] = nUI_Config_Options["threatbar"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["threatbar"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["threatbar"].slash2 = nUI_SLASHCMD_HUD_THREATBAR;
	nUI_Config_Options["threatbar"].toggle = true;
	nUI_Config_Options["threatbar"].get = function() return nUI_Options.hud_threatbar; end
	nUI_Config_Options["threatbar"].display = _L["THREATBAR_DISPLAY"];
	--]]

	nUI_Config_Options["scale"] = nUI_Config_Options["scale"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["scale"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["scale"].slash2 = nUI_SLASHCMD_HUD_SCALE;
	nUI_Config_Options["scale"].percentage = true;
	nUI_Config_Options["scale"].get = function() return nUI_Options.hud_scale; end
	nUI_Config_Options["scale"].values = GetRange(25,175,5,10,10);
	nUI_Config_Options["scale"].display = _L["HUD_SCALE_DISPLAY"];

	nUI_Config_Options["show_npc"] = nUI_Config_Options["show_npc"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["show_npc"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["show_npc"].slash2 = nUI_SLASHCMD_HUD_SHOWNPC;
	nUI_Config_Options["show_npc"].toggle = true;
	nUI_Config_Options["show_npc"].get = function() return nUI_Options.show_npc; end
	nUI_Config_Options["show_npc"].display = _L["HUD_SHOWNPC_DISPLAY"];

	nUI_Config_Options["hgap"] = nUI_Config_Options["hgap"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["hgap"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["hgap"].slash2 = nUI_SLASHCMD_HUD_HGAP;
	nUI_Config_Options["hgap"].get = function() return nUI_Options.hud_hGap; end
	nUI_Config_Options["hgap"].values = GetRange(0,1200,50,100,10); 
	nUI_Config_Options["hgap"].display = _L["HUD_HGAP_DISPLAY"];

	nUI_Config_Options["vofs"] = nUI_Config_Options["vofs"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["vofs"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["vofs"].slash2 = nUI_SLASHCMD_HUD_VOFS;
	nUI_Config_Options["vofs"].get = function() return nUI_Options.hud_vOfs; end
	nUI_Config_Options["vofs"].values = GetRange(-300,300,25,100,10); 
	nUI_Config_Options["vofs"].display = _L["HUD_VOFS_DISPLAY"];

	nUI_Config_Options["show_focus"] = nUI_Config_Options["show_focus"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["show_focus"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["show_focus"].slash2 = nUI_SLASHCMD_HUD_FOCUS;
	nUI_Config_Options["show_focus"].toggle = true;
	nUI_Config_Options["show_focus"].get = function() return nUI_Options.hud_focus; end
	nUI_Config_Options["show_focus"].display = _L["HUD_FOCUS_DISPLAY"];
end

------------------------------------------------------------------------
-- [v2.01.00] nUI's Button Bar Slash Commands and Variables
-- [v2.01.02] Added /nui bar totems
------------------------------------------------------------------------
local function InitButtonBarOptions()

	nUI_Config_Options["barcooldowns"] = nUI_Config_Options["barcooldowns"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["barcooldowns"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAR];
	nUI_Config_Options["barcooldowns"].slash2 = nUI_SLASHCMD_BAR_COOLDOWN;
	nUI_Config_Options["barcooldowns"].toggle = true;
	nUI_Config_Options["barcooldowns"].get = function() return nUI_Options.barCooldowns; end
	nUI_Config_Options["barcooldowns"].display = _L["BAR_COOLDOWNS_DISPLAY"];
		
	nUI_Config_Options["bardurations"] = nUI_Config_Options["bardurations"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["bardurations"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAR];
	nUI_Config_Options["bardurations"].slash2 = nUI_SLASHCMD_BAR_DURATION;
	nUI_Config_Options["bardurations"].toggle = true;
	nUI_Config_Options["bardurations"].get = function() return nUI_Options.barDurations; end
	nUI_Config_Options["bardurations"].display = _L["BAR_DURATIONS_DISPLAY"];
		
	nUI_Config_Options["barmacronames"] = nUI_Config_Options["barmacronames"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["barmacronames"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAR];
	nUI_Config_Options["barmacronames"].slash2 = nUI_SLASHCMD_BAR_MACRO;
	nUI_Config_Options["barmacronames"].toggle = true;
	nUI_Config_Options["barmacronames"].get = function() return nUI_Options.barMacroNames; end
	nUI_Config_Options["barmacronames"].display = _L["BAR_MACRONAMES_DISPLAY"];
		
	nUI_Config_Options["barstackcounts"] = nUI_Config_Options["barstackcounts"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["barstackcounts"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAR];
	nUI_Config_Options["barstackcounts"].slash2 = nUI_SLASHCMD_BAR_STACKCOUNT;
	nUI_Config_Options["barstackcounts"].toggle = true;
	nUI_Config_Options["barstackcounts"].get = function() return nUI_Options.barStackCounts; end
	nUI_Config_Options["barstackcounts"].display = _L["BAR_STACKCOUNTS_DISPLAY"];
		
	nUI_Config_Options["barkeybindings"] = nUI_Config_Options["barkeybindings"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["barkeybindings"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAR];
	nUI_Config_Options["barkeybindings"].slash2 = nUI_SLASHCMD_BAR_KEYBIND;
	nUI_Config_Options["barkeybindings"].toggle = true;
	nUI_Config_Options["barkeybindings"].get = function() return nUI_Options.barKeyBindings; end
	nUI_Config_Options["barkeybindings"].display = _L["BAR_KEYBIND_DISPLAY"];
		
	nUI_Config_Options["bardimming"] = nUI_Config_Options["bardimming"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["bardimming"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAR];
	nUI_Config_Options["bardimming"].slash2 = nUI_SLASHCMD_BAR_DIMMING;
	nUI_Config_Options["bardimming"].toggle = true;
	nUI_Config_Options["bardimming"].get = function() return nUI_Options.barDimming; end
	nUI_Config_Options["bardimming"].display = _L["BAR_DIMMING_DISPLAY"];
		
	nUI_Config_Options["barmouseover"] = nUI_Config_Options["barmouseover"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["barmouseover"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAR];
	nUI_Config_Options["barmouseover"].slash2 = nUI_SLASHCMD_BAR_MOUSEOVER;
	nUI_Config_Options["barmouseover"].toggle = true;
	nUI_Config_Options["barmouseover"].get = function() return nUI_Options.barMouseover; end
	nUI_Config_Options["barmouseover"].display = _L["BAR_MOUSEOVER_DISPLAY"];
		
	nUI_Config_Options["dimmingalpha"] = nUI_Config_Options["dimmingalpha"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["dimmingalpha"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAR];
	nUI_Config_Options["dimmingalpha"].slash2 = nUI_SLASHCMD_BAR_DIMALPHA;
	nUI_Config_Options["dimmingalpha"].percentage = true;
	nUI_Config_Options["dimmingalpha"].get = function() return nUI_Options.dimmingAlpha; end
	nUI_Config_Options["dimmingalpha"].values = GetRange(0,100,10,10,10);
	nUI_Config_Options["dimmingalpha"].display = _L["BAR_DIMALPHA_DISPLAY"];

	nUI_Config_Options["bartotems"] = nUI_Config_Options["bartotems"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["bartotems"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAR];
	nUI_Config_Options["bartotems"].slash2 = nUI_SLASHCMD_BAR_TOTEMS;
	nUI_Config_Options["bartotems"].toggle = true;
	nUI_Config_Options["bartotems"].get = function() return nUI_Options.noTotemBar; end
	nUI_Config_Options["bartotems"].display = _L["BAR_TOTEMS_DISPLAY"];
end

------------------------------------------------------------------------
-- [v2.01.00] nUI's Miscellaneous Other Slash Commands and Variables
------------------------------------------------------------------------
local function InitOtherOptions()

	nUI_Config_Options["map_coords"] = nUI_Config_Options["map_coords"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["map_coords"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_MAPCOORDS];
	nUI_Config_Options["map_coords"].toggle = true;
	nUI_Config_Options["map_coords"].get = function() return nUI_Options.map_coords; end
	nUI_Config_Options["map_coords"].display = _L["MAP_COORDS_DISPLAY"];

	nUI_Config_Options["movers"] = nUI_Config_Options["movers"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["movers"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_MOVERS];
	nUI_Config_Options["movers"].toggle = true;
	nUI_Config_Options["movers"].get = function() return nUI_Movers.enabled; end
	nUI_Config_Options["movers"].display = _L["MOVERS_DISPLAY"];

	nUI_Config_Options["mount_scale"] = nUI_Config_Options["mount_scale"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["mount_scale"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_MOUNTSCALE];
	nUI_Config_Options["mount_scale"].percentage = true;
	nUI_Config_Options["mount_scale"].get = function() return nUI_Options.mountScale or 1; end
	nUI_Config_Options["mount_scale"].values = GetRange(50,150,5,10,10);
	nUI_Config_Options["mount_scale"].display = _L["MOUNT_SCALE_DISPLAY"];

	nUI_Config_Options["max_auras"] = nUI_Config_Options["max_auras"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["max_auras"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_MAXAURAS];
	nUI_Config_Options["max_auras"].get = function() return nUI_Options.max_auras or 40; end
	nUI_Config_Options["max_auras"].values = GetRange(0,40,5,10,5); 
	nUI_Config_Options["max_auras"].display = _L["MAX_AURAS_DISPLAY"];
end

------------------------------------------------------------------------
-- [v2.01.00] nUI's Raid Windows Slash Commands and Variables
------------------------------------------------------------------------
local function InitRaidOptions()

	nUI_Config_Options["auto_group"] = nUI_Config_Options["auto_group"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["auto_group"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_AUTOGROUP];
	nUI_Config_Options["auto_group"].toggle = true;
	nUI_Config_Options["auto_group"].get = function() return nUI_Options.auto_group; end
	nUI_Config_Options["auto_group"].display = _L["AUTO_GROUP_DISPLAY"];

	nUI_Config_Options["raid_sort"] = nUI_Config_Options["raid_sort"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["raid_sort"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_RAIDSORT];
	nUI_Config_Options["raid_sort"].get = function() return nUI_Options.raidSort; end
	nUI_Config_Options["raid_sort"].values = { 
			string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_RAIDSORT, "group" )]),
			string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_RAIDSORT, "unit" )]), 
			string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_RAIDSORT, "class" )]),
			string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_RAIDSORT, "name" )]) 
			};
	nUI_Config_Options["raid_sort"].display = _L["RAID_SORT_DISPLAY"];
end

------------------------------------------------------------------------
-- [v2.01.00] nUI's Console Slash Commands and Variables
------------------------------------------------------------------------
local function InitConsoleOptions()

	nUI_Config_Options["framerate"] = nUI_Config_Options["framerate"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["framerate"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_FRAMERATE];
	nUI_Config_Options["framerate"].get = function() return nUI_Options.frame_rate or 30; end
	nUI_Config_Options["framerate"].values = GetRange(10,120,10,10,10);
	nUI_Config_Options["framerate"].display = _L["FRAMERATE_DISPLAY"];

	nUI_Config_Options["console"] = nUI_Config_Options["console"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["console"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_CONSOLE];
	nUI_Config_Options["console"].get = function() return nUI_Options.console; end
	nUI_Config_Options["console"].values =   {
			string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CONSOLE, "on" )]),
			string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CONSOLE, "off" )]),
			string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CONSOLE, "mouseover" )])
			};
	nUI_Config_Options["console"].display = _L["CONSOLE_DISPLAY"];
end


------------------------------------------------------------------------
-- [v2.01.00] nUI's Cooldown Bar Slash Commands and Variables
------------------------------------------------------------------------
local function InitCooldownBarOptions()

	nUI_Config_Options["hud_cooldown"] = nUI_Config_Options["hud_cooldown"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["hud_cooldown"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["hud_cooldown"].slash2 = nUI_SLASHCMD_HUD_COOLDOWN;
	nUI_Config_Options["hud_cooldown"].toggle = true;
	nUI_Config_Options["hud_cooldown"].get = function() return nUI_Options.hud_cooldown; end
	nUI_Config_Options["hud_cooldown"].display = _L["HUD_COOLDOWN_DISPLAY"];

	nUI_Config_Options["mincooldown"] = nUI_Config_Options["mincooldown"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["mincooldown"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["mincooldown"].slash2 = nUI_SLASHCMD_HUD_CDMIN;
	nUI_Config_Options["mincooldown"].get = function() return nUI_Options.minCooldown; end
	nUI_Config_Options["mincooldown"].values = GetRange(0,60,1,5,10);
	nUI_Config_Options["mincooldown"].display = _L["HUD_CDMIN_DISPLAY"];

	nUI_Config_Options["hud_cdalert"] = nUI_Config_Options["hud_cdalert"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["hud_cdalert"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["hud_cdalert"].slash2 = nUI_SLASHCMD_HUD_CDALERT;
	nUI_Config_Options["hud_cdalert"].toggle = true;
	nUI_Config_Options["hud_cdalert"].get = function() return nUI_Options.hud_cdalert; end
	nUI_Config_Options["hud_cdalert"].display = _L["HUD_CDALERT_DISPLAY"];

	nUI_Config_Options["hud_cdsound"] = nUI_Config_Options["hud_cdsound"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["hud_cdsound"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["hud_cdsound"].slash2 = nUI_SLASHCMD_HUD_CDSOUND;
	nUI_Config_Options["hud_cdsound"].toggle = true;
	nUI_Config_Options["hud_cdsound"].get = function() return nUI_Options.hud_cdsound; end
	nUI_Config_Options["hud_cdsound"].display = _L["HUD_CDSOUND_DISPLAY"];
end

------------------------------------------------------------------------
-- [v2.01.00] nUI's Hud's Alpha Slash Commands and Variables
------------------------------------------------------------------------
local function InitHudAlphaOptions()

	nUI_Config_Options["hud_alpha_idle"] = { slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil };
	nUI_Config_Options["hud_alpha_idle"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["hud_alpha_idle"].slash2 = nUI_SLASHCMD_HUD_IDLEALPHA;
	nUI_Config_Options["hud_alpha_idle"].percentage = true;
	nUI_Config_Options["hud_alpha_idle"].get = function() return nUI_Options.hud_alpha.idle; end
	nUI_Config_Options["hud_alpha_idle"].values = GetRange(0,100,5,10,10);
	nUI_Config_Options["hud_alpha_idle"].display = _L["HUD_ALPHAIDLE_DISPLAY"];

	nUI_Config_Options["hud_alpha_regen"] = {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["hud_alpha_regen"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["hud_alpha_regen"].slash2 = nUI_SLASHCMD_HUD_REGENALPHA;
	nUI_Config_Options["hud_alpha_regen"].percentage = true;
	nUI_Config_Options["hud_alpha_regen"].get = function() return nUI_Options.hud_alpha.regen; end
	nUI_Config_Options["hud_alpha_regen"].values = GetRange(0,100,5,10,10);
	nUI_Config_Options["hud_alpha_regen"].display = _L["HUD_ALPHAREGEN_DISPLAY"];

	nUI_Config_Options["hud_alpha_target"] = {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["hud_alpha_target"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["hud_alpha_target"].slash2 = nUI_SLASHCMD_HUD_TARGETALPHA;
	nUI_Config_Options["hud_alpha_target"].percentage = true;
	nUI_Config_Options["hud_alpha_target"].get = function() return nUI_Options.hud_alpha.target; end
	nUI_Config_Options["hud_alpha_target"].values = GetRange(0,100,5,10,10);
	nUI_Config_Options["hud_alpha_target"].display = _L["HUD_ALPHATARGET_DISPLAY"];

	nUI_Config_Options["hud_alpha_combat"] = {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["hud_alpha_combat"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HUD];
	nUI_Config_Options["hud_alpha_combat"].slash2 = nUI_SLASHCMD_HUD_COMBATALPHA;
	nUI_Config_Options["hud_alpha_combat"].percentage = true;
	nUI_Config_Options["hud_alpha_combat"].get = function() return nUI_Options.hud_alpha.combat; end
	nUI_Config_Options["hud_alpha_combat"].values = GetRange(0,100,5,10,10);
	nUI_Config_Options["hud_alpha_combat"].display = _L["HUD_ALPHACOMBAT_DISPLAY"];
end

------------------------------------------------------------------------
-- [v2.01.00] nUI's Tooltip Slash Commands and Variables
------------------------------------------------------------------------
local function InitTooltipsOptions()

	nUI_Config_Options["tooltips"] = nUI_Config_Options["tooltips"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["tooltips"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_TOOLTIPS];
	nUI_Config_Options["tooltips"].get = function() return nUI_Options.tooltips; end
	nUI_Config_Options["tooltips"].values = {
				string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "owner" )]), 
				string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "mouse" )]), 
				string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "default" )]), 
				string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "fixed" )]), 
				};
	nUI_Config_Options["tooltips"].display = _L["TOOLTIPS_DISPLAY"];

	nUI_Config_Options["combat_tooltips"] = nUI_Config_Options["combat_tooltips"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["combat_tooltips"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_COMBATTIPS];
	nUI_Config_Options["combat_tooltips"].toggle = true;
	nUI_Config_Options["combat_tooltips"].get = function() return nUI_Options.combat_tooltips; end
	nUI_Config_Options["combat_tooltips"].display = _L["COMBAT_TOOLTIPS_DISPLAY"];
end


------------------------------------------------------------------------
-- [v2.01.00] nUI's Minimap Slash Commands and Variables
------------------------------------------------------------------------
local function InitMinimapOptions()

	nUI_Config_Options["minimap"] = nUI_Config_Options["minimap"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["minimap"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_MINIMAP];
	nUI_Config_Options["minimap"].toggle = true;
	nUI_Config_Options["minimap"].get = function() return nUI_Options.minimap; end
	nUI_Config_Options["minimap"].display = _L["MINIMAP_DISPLAY"];

	nUI_Config_Options["round_map"] = nUI_Config_Options["round_map"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["round_map"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_ROUNDMAP];
	nUI_Config_Options["round_map"].toggle = true;
	nUI_Config_Options["round_map"].get = function() return nUI_Options.round_map; end
	nUI_Config_Options["round_map"].display = _L["ROUND_MAP_DISPLAY"];

	nUI_Config_Options["calendar"] = nUI_Config_Options["calendar"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["calendar"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_CALENDAR];
	nUI_Config_Options["calendar"].toggle = true;
	nUI_Config_Options["calendar"].get = function() return nUI_Options.showCalendar; end
	nUI_Config_Options["calendar"].display = _L["CALENDAR_DISPLAY"];
end

------------------------------------------------------------------------
-- [v2.01.00] nUI's Location Slash Commands and Variables
------------------------------------------------------------------------
local function InitClockOptions()

	nUI_Config_Options["clock"] = nUI_Config_Options["clock"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["clock"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_CLOCK];
	nUI_Config_Options["clock"].get = function() return nUI_Options.clock; end
	nUI_Config_Options["clock"].values = { 
				string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CLOCK, "local" )]), 
				string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CLOCK, "server" )]), 
				string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CLOCK, "both" )]) 
				};
	nUI_Config_Options["clock"].display = _L["CLOCK_DISPLAY"];

end

------------------------------------------------------------------------
-- [v2.01.00] nUI's Feedback Slash Commands and Variables
------------------------------------------------------------------------
local function InitFeedbackOptions()

	nUI_Config_Options["feedback_curse"] = nUI_Config_Options["feedback_curse"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["feedback_curse"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_FEEDBACK];
	nUI_Config_Options["feedback_curse"].slash2 = string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_FEEDBACK, "curse" )]);
	nUI_Config_Options["feedback_curse"].toggle = true;
	nUI_Config_Options["feedback_curse"].get = function() return nUI_Options.feedback_curse; end
	nUI_Config_Options["feedback_curse"].display = _L["CURSE_DISPLAY"];

	nUI_Config_Options["feedback_magic"] = nUI_Config_Options["feedback_magic"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["feedback_magic"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_FEEDBACK];
	nUI_Config_Options["feedback_magic"].slash2 = string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_FEEDBACK, "magic" )]);
	nUI_Config_Options["feedback_magic"].toggle = true;
	nUI_Config_Options["feedback_magic"].get = function() return nUI_Options.feedback_magic; end
	nUI_Config_Options["feedback_magic"].display = _L["MAGIC_DISPLAY"];

	nUI_Config_Options["feedback_poison"] = nUI_Config_Options["feedback_poison"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["feedback_poison"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_FEEDBACK];
	nUI_Config_Options["feedback_poison"].slash2 = string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_FEEDBACK, "poison" )]);
	nUI_Config_Options["feedback_poison"].toggle = true;
	nUI_Config_Options["feedback_poison"].get = function() return nUI_Options.feedback_poison; end
	nUI_Config_Options["feedback_poison"].display = _L["POISON_DISPLAY"];

	nUI_Config_Options["feedback_disease"] = nUI_Config_Options["feedback_disease"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["feedback_disease"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_FEEDBACK];
	nUI_Config_Options["feedback_disease"].slash2 = string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_FEEDBACK, "disease" )]);
	nUI_Config_Options["feedback_disease"].toggle = true;
	nUI_Config_Options["feedback_disease"].get = function() return nUI_Options.feedback_disease; end
	nUI_Config_Options["feedback_disease"].display = _L["DISEASE_DISPLAY"];

	nUI_Config_Options["show_hits"] = nUI_Config_Options["show_hits"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["show_hits"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_SHOWHITS];
	nUI_Config_Options["show_hits"].toggle = true;
	nUI_Config_Options["show_hits"].get = function() return nUI_Options.show_hits; end
	nUI_Config_Options["show_hits"].display = _L["SHOW_HITS_DISPLAY"];
	
	nUI_Config_Options["show_anim"] = nUI_Config_Options["show_anim"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["show_anim"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_SHOWANIM];
	nUI_Config_Options["show_anim"].toggle = true;
	nUI_Config_Options["show_anim"].get = function() return nUI_Options.show_anim; end
	nUI_Config_Options["show_anim"].display = _L["SHOW_ANIM_DISPLAY"];
	
	nUI_Config_Options["hplost"] = nUI_Config_Options["hplost"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["hplost"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_HPLOST];
	nUI_Config_Options["hplost"].toggle = true;
	nUI_Config_Options["hplost"].get = function() return nUI_Options.hplost; end
	nUI_Config_Options["hplost"].display = _L["HPLOST_DISPLAY"];
	
end

------------------------------------------------------------------------
-- [v2.01.00] nUI's Bagbar Slash Commands and Variables
------------------------------------------------------------------------
local function InitBagBarOptions()

	nUI_Config_Options["bagbar"] = nUI_Config_Options["bagbar"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["bagbar"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAGBAR];
	nUI_Config_Options["bagbar"].get = function() return nUI_Options.bagbar; end
	nUI_Config_Options["bagbar"].values =   {
				string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_BAGBAR, "on" )]),
				string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_BAGBAR, "off" )]),
				string.lower(nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_BAGBAR, "mouseover" )])
				};
	nUI_Config_Options["bagbar"].display = _L["BAGBAR_DISPLAY"];
	
	nUI_Config_Options["onebag"] = nUI_Config_Options["onebag"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["onebag"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_ONEBAG];
	nUI_Config_Options["onebag"].toggle = true;
	nUI_Config_Options["onebag"].get = function() return nUI_Options.onebag; end
	nUI_Config_Options["onebag"].display = _L["ONEBAG_DISPLAY"];

	nUI_Config_Options["bag_scale"] = nUI_Config_Options["bag_scale"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["bag_scale"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BAGSCALE];
	nUI_Config_Options["bag_scale"].percentage = true;
	nUI_Config_Options["bag_scale"].get = function() return nUI_Options.bag_scale; end
	nUI_Config_Options["bag_scale"].values = GetRange(50,150,5,10,10);
	nUI_Config_Options["bag_scale"].display = _L["BAGSCALE_DISPLAY"];
	
	nUI_Config_Options["button_bag"] = nUI_Config_Options["button_bag"] or {slash1 = nil, slash2 = nil, toggle = false, percentage = false, get = nil, values = nil, display = nil};
	nUI_Config_Options["button_bag"].slash1 = nUI_SlashCommands[nUI_SLASHCMD_BUTTONBAG];
	nUI_Config_Options["button_bag"].percentage = true;
	nUI_Config_Options["button_bag"].get = function() return nUI_Options.button_bag; end
	nUI_Config_Options["button_bag"].values = GetRange(0,100,5,5,5);
	nUI_Config_Options["button_bag"].display = _L["BUTTON_BAG_DISPLAY"];
		
end



------------------------------------------------------------------------
-- [v2.01.00] Public Function to initialise Menu and Config Data
------------------------------------------------------------------------
function nUI_Config_Init()
	InitMenuHeaders();
	InitRaidOptions();
	InitCooldownBarOptions();
	InitHudAlphaOptions();
	InitTooltipsOptions();
	InitMinimapOptions();
	InitClockOptions();
	InitFeedbackOptions();
	InitBagBarOptions();
	InitConsoleOptions();
	InitOtherOptions();
	InitButtonBarOptions();
	InitHudOptions();
	return nUI_Config_Menu, nUI_Config_Options;
end


