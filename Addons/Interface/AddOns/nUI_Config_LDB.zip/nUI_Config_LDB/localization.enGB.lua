
if (nUI_Config_LDB_Locale == "enGB") then

nUI_Config_LDB_L["LibStub Assert"]                          = "nUI_Config_LDB requires LibStub";
nUI_Config_LDB_L["LibBroker Assert"]                        = "nUI_Config_LDB requires LibDataBroker-1.1";

nUI_Config_LDB_L["INITIALISE_MESSAGE"]						= "nUI_Config_LDB: Initialising Config Menus and Data";

nUI_Config_LDB_L["CONSOLE_MENU"]							= "Console";
nUI_Config_LDB_L["DASHBOARD_MENU"]							= "Dashboard";
nUI_Config_LDB_L["BAGBAR_MENU"]								= "Bag Bar";
nUI_Config_LDB_L["FEEDBACK_MENU"]							= "Feedback";
nUI_Config_LDB_L["LOCATION_MENU"]							= "Location";
nUI_Config_LDB_L["MINIMAP_MENU"]							= "MiniMap";
nUI_Config_LDB_L["DISPLAY_MENU"]							= "Display";
nUI_Config_LDB_L["RAID_MENU"]								= "Raid";
nUI_Config_LDB_L["HUD_MENU"]								= "HUD";
nUI_Config_LDB_L["HUD_VISUALS_MENU"]						= "HUD Visuals";
nUI_Config_LDB_L["TOOLTIP_MENU"]							= "Tooltip";
nUI_Config_LDB_L["HUD_ALPHA_LEVELS_MENU"]					= "Hud Alpha Levels";
nUI_Config_LDB_L["HUD_COOLDOWNS_MENU"]						= "Hud Cooldowns";
nUI_Config_LDB_L["BUTTON_BAR_MENU"]							= "Button Bar";

nUI_Config_LDB_L["HEALTHRACE_DISPLAY"]						= "Toggle Health Race Display";
nUI_Config_LDB_L["THREATBAR_DISPLAY"]						= "Toggle Threat Bar Display";
nUI_Config_LDB_L["HUD_SCALE_DISPLAY"]						= "Set Hud Scale %";
nUI_Config_LDB_L["HUD_SHOWNPC_DISPLAY"]						= "Toggle NPC Showing";
nUI_Config_LDB_L["HUD_HGAP_DISPLAY"]						= "Set Horizontal Gap Value";
nUI_Config_LDB_L["HUD_VOFS_DISPLAY"]						= "Set Vertical Offset Value";
nUI_Config_LDB_L["HUD_FOCUS_DISPLAY"]						= "Toggle Focus Display instead of Target";

nUI_Config_LDB_L["BAR_COOLDOWNS_DISPLAY"]					= "Toggle Cooldowns Display";
nUI_Config_LDB_L["BAR_DURATIONS_DISPLAY"]					= "Toggle Durations Display";
nUI_Config_LDB_L["BAR_MACRONAMES_DISPLAY"]					= "Toggle Macro Names Display";
nUI_Config_LDB_L["BAR_STACKCOUNTS_DISPLAY"]					= "Toggle Stack Count Display";
nUI_Config_LDB_L["BAR_KEYBIND_DISPLAY"]						= "Toggle Key Bindings Display";
nUI_Config_LDB_L["BAR_DIMMING_DISPLAY"]						= "Toggle Bar Dimming Display";
nUI_Config_LDB_L["BAR_MOUSEOVER_DISPLAY"]					= "Toggle Mouseover Display";
nUI_Config_LDB_L["BAR_DIMALPHA_DISPLAY"]					= "Button Dimming Alpha %";
nUI_Config_LDB_L["BAR_TOTEMS_DISPLAY"]					= "Toggle Blizzard Totem Bar Display";

nUI_Config_LDB_L["MAP_COORDS_DISPLAY"]						= "Toggle World Map Coords Display";
nUI_Config_LDB_L["MOVERS_DISPLAY"]							= "Toggle Movers Windows Visibility";
nUI_Config_LDB_L["MOUNT_SCALE_DISPLAY"]						= "Set Vehicle Seat Indicator Display Scale %";
nUI_Config_LDB_L["MAX_AURAS_DISPLAY"]						= "Set Maximum Number of Auras to Display";

nUI_Config_LDB_L["AUTO_GROUP_DISPLAY"]						= "Toggle Auto Group";
nUI_Config_LDB_L["RAID_SORT_DISPLAY"]						= "Set Raid Sort Order";

nUI_Config_LDB_L["FRAMERATE_DISPLAY"]						= "Set Frame Rate Value";
nUI_Config_LDB_L["CONSOLE_DISPLAY"]							= "Set Console Visibility";

nUI_Config_LDB_L["HUD_COOLDOWN_DISPLAY"]					= "Toggle Cooldown Display";
nUI_Config_LDB_L["HUD_CDMIN_DISPLAY"]						= "Minimum Cooldown Time to Display";
nUI_Config_LDB_L["HUD_CDALERT_DISPLAY"]						= "Toggle Cooldown Alert";
nUI_Config_LDB_L["HUD_CDSOUND_DISPLAY"]						= "Toggle Cooldown Sound";

nUI_Config_LDB_L["HUD_ALPHAIDLE_DISPLAY"]					= "Set Idle Alpha %";
nUI_Config_LDB_L["HUD_ALPHAREGEN_DISPLAY"]					= "Set Regeneration Alpha %";
nUI_Config_LDB_L["HUD_ALPHATARGET_DISPLAY"]					= "Set Target Alpha %";
nUI_Config_LDB_L["HUD_ALPHACOMBAT_DISPLAY"]					= "Set Combat Alpha %";

nUI_Config_LDB_L["TOOLTIPS_DISPLAY"]						= "Set Tooltip Anchor";
nUI_Config_LDB_L["COMBAT_TOOLTIPS_DISPLAY"]					= "Toggle Tooltip Display during Combat";

nUI_Config_LDB_L["MINIMAP_DISPLAY"]							= "Toggle Minimap Control";
nUI_Config_LDB_L["ROUND_MAP_DISPLAY"]						= "Toggle Round Map";
nUI_Config_LDB_L["CALENDAR_DISPLAY"]						= "Toggle Calendar Button Display on Minimap";

nUI_Config_LDB_L["CLOCK_DISPLAY"]							= "Set Clock Display";

nUI_Config_LDB_L["CURSE_DISPLAY"]							= "Toggle Curse Feedback";
nUI_Config_LDB_L["MAGIC_DISPLAY"]							= "Toggle Magic Feedback";
nUI_Config_LDB_L["POISON_DISPLAY"]							= "Toggle Poison Feedback";
nUI_Config_LDB_L["DISEASE_DISPLAY"]							= "Toggle Disease Feedback";
nUI_Config_LDB_L["SHOW_HITS_DISPLAY"]						= "Toggle Hits Display";
nUI_Config_LDB_L["SHOW_ANIM_DISPLAY"]						= "Toggle Animation";
nUI_Config_LDB_L["HPLOST_DISPLAY"]							= "Toggle HP Lost Display";

nUI_Config_LDB_L["BAGBAR_DISPLAY"]							= "Set Bag Bar Visibility";
nUI_Config_LDB_L["ONEBAG_DISPLAY"]							= "Toggle One Bag Display";
nUI_Config_LDB_L["BAGSCALE_DISPLAY"]						= "Set Bag Scale %";
nUI_Config_LDB_L["BUTTON_BAG_DISPLAY"]						= "Set Button Bag Visibility %";

end