
-------------------------------------------------------------
-- [v1.01.00] Initial Code
-- [v2.01.00] Code Rewrite
-------------------------------------------------------------

-------------------------------------------------------------
-- [v2.01.00] Local Tables and functions
-------------------------------------------------------------
local _L                        = nUI_Config_LDB_L;
local _InitConfig				= nUI_Config_Init;
-------------------------------------------------------------

------------------------------------------------------------------------
-- [v1.01.00] Make sure the libraries exist somewhere
------------------------------------------------------------------------
assert(LibStub, _L["LibStub Assert"]);
assert(LibStub:GetLibrary("LibDataBroker-1.1"), _L["LibBroker Assert"]);
------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- [v1.01.00] Create Objects
-----------------------------------------------------------------------------
local ldb                       = LibStub:GetLibrary("LibDataBroker-1.1");
local nUI_SlashCmdHandler       = SlashCmdList["NUI"];
-----------------------------------------------------------------------------

--------------------------------------------------------------
-- [v1.01.00] Set Paths
--------------------------------------------------------------
local nUI_Path          = "Interface\\AddOns\\nUI";
local nUI_LDB_Path      = "Interface\\AddOns\\nUI_Config_LDB"; 
--------------------------------------------------------------

------------------------------------------------------
-- [v1.01.00] Objects Created during addon process
-- [v2.01.00] Refined Code
------------------------------------------------------
local Frame;
local Menu;
local Init_Menu;
local LDB_Object;
local menu_cfg;
local options_cfg;
local nUI_Loaded = false;
local LDB_Loaded = false;
------------------------------------------------------

-------------------------------------------
-- [v1.01.00] Execute the addons command
-- [v2.01.00] Code Rewrite
-------------------------------------------
local function OnClick(s1,s2,v)
	local command = nil;
	local subcmd = nil;
	local value = nil;
	if ( s1 ) then command = s1.command; end
	if ( v ) then
		if ( s2 ) then subcmd = s1.sub_menu[s2].command; end
	else
		if ( s2 ) then subcmd = s2; end
	end
	local cmd = command;
	if ( subcmd ) then cmd = cmd .. " " .. subcmd; end
	if ( v ) then cmd = cmd .. " " .. v; end
	if ( cmd ) then nUI_SlashCmdHandler(cmd); end
end
-----------------------------------------------------------------------------

-------------------------------------------
-- [v1.01.00] Create Sub Menus
-- [v2.01.00] Code Rewrite
-------------------------------------------
local function Init_SubMenu(level,parent)

	-- If no parent then no more menus to process
	if ( not parent ) then return; end	

	-- If there are values then this is an option to click 	
	if ( parent.values ) then
		for a,b in pairs(parent.values) do
			local optionitem = options_cfg[b];
			local info;
			info = UIDropDownMenu_CreateInfo();
			info.text = b;
			info.value = 0; 
			info.notCheckable = false;			
			if ( parent.percentage ) then
				info.checked = ( parent.get() == ( b / 100 or 0 ) );
			else
				info.checked = ( parent.get() == ( b or 0 ) );
			end
			info.hasArrow = false;
			info.menuList = nil;
			info.func = function() 
				if ( parent.percentage ) then 
					OnClick(parent.slash1,parent.slash2, ( b / 100 ) or 0 ); 
				else 
					OnClick(parent.slash1,parent.slash2,b); 
				end 
			end
			UIDropDownMenu_AddButton(info, level);			
		end		
	elseif ( menu_cfg[parent] ) then
		local info;
		info = UIDropDownMenu_CreateInfo();
		info.text = menu_cfg[parent].display;
		info.isTitle = true;
		UIDropDownMenu_AddButton(info, level);
		-- If there are menus then display them
		if ( menu_cfg[parent].menus ) then
			for a,b in pairs(menu_cfg[parent].menus) do
				local menuitem = menu_cfg[b];
				local info;
				info = UIDropDownMenu_CreateInfo();
				info.text = menuitem.display;
				info.value = 0; 
				info.notCheckable = not menuitem.check;
				info.hasArrow = menuitem.arrow;
				info.menuList = b;
				UIDropDownMenu_AddButton(info, level);
			end
		elseif ( menu_cfg[parent].options ) then
			-- For Each Option in the menu display and set up click action or menus
			for a,b in pairs(menu_cfg[parent].options) do
				local optionitem = options_cfg[b];
				-- If this is a toggle item then set actions accordingly
				-- Otherwise it is a set of values to list
				if ( optionitem.toggle ) then
					local info;
					info = UIDropDownMenu_CreateInfo();
					info.text = optionitem.display;
					info.value = 0; 
					info.notCheckable = false;
					info.checked = optionitem.get();
					info.hasArrow = false;
					info.menuList = nil;
					if ( optionitem.slash1.sub_menu ) then
						info.func = function() OnClick(optionitem.slash1,optionitem.slash1.sub_menu[optionitem.slash2].command,nil); end
					else
						info.func = function() OnClick(optionitem.slash1,optionitem.slash2,nil); end
					end
					UIDropDownMenu_AddButton(info, level);			
				else
					local info;
					info = UIDropDownMenu_CreateInfo();
					info.text = optionitem.display;
					info.value = 0; 
					info.notCheckable = false;
					info.hasArrow = true;
					info.menuList = optionitem;
					UIDropDownMenu_AddButton(info, level);			
				end
			end
		end
	end
end

-------------------------------------------
-- [v1.01.00] Set up First Level Menu
-- [v2.01.00] Code Rewrite
-------------------------------------------
local function Init_MainMenu()
	local mainmenu = menu_cfg["main"];
	if ( not mainmenu ) then return; end
	local info;
    info = UIDropDownMenu_CreateInfo();
    info.text = nUI_Package .. "(" .. nUI_Version .. ")";
    info.isTitle = true;
    UIDropDownMenu_AddButton(info, 1);
    if ( mainmenu.menus ) then
		for i, v in pairs(mainmenu.menus) do
			local menuitem = menu_cfg[v];
			info = UIDropDownMenu_CreateInfo();
			info.text = menuitem.display;
			info.value = 0; 
			info.notCheckable = not menuitem.check;
			info.hasArrow = menuitem.arrow;
			info.menuList = v;
			UIDropDownMenu_AddButton(info, 1);
		end
	end
end
-----------------------------------------------------------------------------

-----------------------------------------------------------
-- [v1.01.00] Menu Initialization - Menu System needs this
-- [v2.01.00] Code Rewrite - Should allow as many sub menus as this menu type allows
-----------------------------------------------------------
function Init_Menu(self, level, menuList)
	if (level == 1) then
		Init_MainMenu();
	else
		Init_SubMenu(level,menuList);
	end        
end
-----------------------------------------------------------------------------

-------------------------------------------
-- [v1.01.00] Initialise the Objects
-- [v2.01.00] Function Names Changed
-------------------------------------------
local function InitialiseObject(self)
        LDB_Object = ldb:NewDataObject("nUI_Config_LDB", 
        { 
                type = "launcher",
                text = nUI_Package .. "(" .. nUI_Version ..")",  
                label = nUI_Package .. "(" .. nUI_Version ..")", 
                icon = nUI_LDB_Path .. "\\nUI",
                 
                OnTooltipShow = 
                function()
                        GameTooltip:ClearLines();
                        GameTooltip:AddLine(nUI_Package,HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
                        GameTooltip:AddLine(nUI_Version,NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
                        GameTooltip:AddLine(nUI_CurrentSkin,NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);                                
                        GameTooltip:Show();                
                end,
                
                OnClick = 
                function(self,button) 
                        if (button == "LeftButton") then
                                UIDropDownMenu_Initialize(Menu,Init_Menu,"MENU");
                                ToggleDropDownMenu(1,nil,Menu,"cursor",5, -10);
                        elseif (button == "RightButton") then
                                UIDropDownMenu_Initialize(Menu,Init_Menu,"MENU");
                                ToggleDropDownMenu(1,nil,Menu,"cursor",5, -10);
                        end
                end,
        });
                
end
-----------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- [v1.01.00] Carry Out Event Checks
-- [v2.01.00] Code Rewrite
-------------------------------------------------------------------------------
local function OnEvent(self,event,...)
        if (event == "PLAYER_LOGIN") then
			if ( nUI_L ) then
                DEFAULT_CHAT_FRAME:AddMessage(_L["INITIALISE_MESSAGE"]);
                menu_cfg, options_cfg = _InitConfig();
                InitialiseObject(self);
				Menu  = CreateFrame("Frame", "Menu", Frame, "UIDropDownMenuTemplate");
			end
        end
end
--------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
-- [v1.01.00] Initialise the Frame
-- [v2.01.00] Refined Code
----------------------------------------------------------------------------------------------------
Frame = CreateFrame("Frame");
Frame:RegisterEvent("PLAYER_LOGIN")
Frame:SetScript("OnEvent",OnEvent);
-----------------------------------------------------------------------------------------------------
