--[[local WowBuild = select(2, GetBuildInfo())
if tonumber(WowBuild) < 13165 then return end

DBM:RegisterMapSize("ZulGurub",
	1, 1877.08325195312, 1252.0830078125
)--]]