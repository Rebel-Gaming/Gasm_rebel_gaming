-- frFR localization

local L = AceLibrary("AceLocale-2.2"):new("Fubar_WintergrasperFu")

L:RegisterTranslations("frFR", function () return {
	-- L["Announce time"] = "Announce time"
	-- L["Announce to"] = "Announce to"
	["Battle"] = "Bataille",
	-- L["Choose when to announce the upcoming battle."] = "Choose when to announce the upcoming battle."
	["Choose whom to announce when battle will start."] = "S�lectionner qui pr�venir lorsque la bataille commence.",
	["Defensive battle in"] = "Bataille d�fensive en", -- Needs review
	["Guild"] = "Guilde",
	[" minutes."] = " minutes.",
	-- L[" minutes before battle."] = " minutes before battle."
	["Next battle in"] = "Bataille suivante dans",
	["Offensive battle in"] = "Bataille offensive en", -- Needs review
	["Party"] = "Groupe",
	["Raid"] = "Raid",
	["Self"] = "Soi-m�me",
	["Shift-hint"] = "|cffeda55fShift-Click|r pour ins�rer l'information dans la zone de chat",
	["Show seconds"] = "Montrer les secondes",
	-- L["Start"] = "Start"
	["The battle for Wintergrasp has begun."] = "La bataille pour le Joug-d'hiver a commenc�.",
	["The battle for Wintergrasp is underway."] = "La bataille pour le Joug d'hiver a commenc�.", -- Needs review
	["Toggle to show seconds."] = "Bascule pour montrer les secondes.",
	["Unknown"] = "Inconnu",
	-- L["Warn "] = "Warn "
	-- L["Warn at battle start."] = "Warn at battle start."
	["Warn guild on upcoming battle."] = "Alerter la guilde lorsqu'une bataille commence.",
	["Warn party on upcoming battle."] = "Alerter le groupe lorsqu'une bataille commence.",
	["Warn raid on upcoming battle."] = "Alerter le raid lorsqu'une bataille commence.",
	-- L["Warn self on upcoming battle."] = "Warn self on upcoming battle."
	["Wintergrasp"] = "Joug-d'hiver",
} end)
