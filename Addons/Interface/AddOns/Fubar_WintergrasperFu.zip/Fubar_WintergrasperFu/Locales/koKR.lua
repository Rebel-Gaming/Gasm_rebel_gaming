-- koKR localization

local L = AceLibrary("AceLocale-2.2"):new("Fubar_WintergrasperFu")

L:RegisterTranslations("koKR", function () return {
	-- L["Announce time"] = "Announce time"
	-- L["Announce to"] = "Announce to"
	["Battle"] = "전투", -- Needs review
	-- L["Choose when to announce the upcoming battle."] = "Choose when to announce the upcoming battle."
	-- L["Choose whom to announce when battle will start."] = "Choose whom to announce when battle will start."
	["Defensive battle in"] = "방어전투중", -- Needs review
	-- L["Guild"] = "Guild"
	-- L[" minutes."] = " minutes."
	-- L[" minutes before battle."] = " minutes before battle."
	["Next battle in"] = "다음전투", -- Needs review
	["Offensive battle in"] = "공격전투중", -- Needs review
	-- L["Party"] = "Party"
	-- L["Raid"] = "Raid"
	-- L["Self"] = "Self"
	["Shift-hint"] = "|cffeda55fShift-Click|r 채팅박스에 정보 삽입", -- Needs review
	["Show seconds"] = "시간 보기", -- Needs review
	-- L["Start"] = "Start"
	-- L["The battle for Wintergrasp has begun."] = "The battle for Wintergrasp has begun."
	["The battle for Wintergrasp is underway."] = "겨울손아귀 전투 진행중", -- Needs review
	["Toggle to show seconds."] = "시간 보기 활성화", -- Needs review
	["Unknown"] = "알수 없슴", -- Needs review
	-- L["Warn "] = "Warn "
	-- L["Warn at battle start."] = "Warn at battle start."
	-- L["Warn guild on upcoming battle."] = "Warn guild on upcoming battle."
	-- L["Warn party on upcoming battle."] = "Warn party on upcoming battle."
	-- L["Warn raid on upcoming battle."] = "Warn raid on upcoming battle."
	-- L["Warn self on upcoming battle."] = "Warn self on upcoming battle."
	["Wintergrasp"] = "겨울손아귀", -- Needs review
} end)
