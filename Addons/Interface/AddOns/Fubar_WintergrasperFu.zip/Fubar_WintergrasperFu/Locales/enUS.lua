-- default

local L = AceLibrary("AceLocale-2.2"):new("Fubar_WintergrasperFu")

L:RegisterTranslations("enUS", function () return {
	["Battle"] = true,
	["Unknown"] = true,
	["Show seconds"] = true,
	["Toggle to show seconds."] = true,
	["Wintergrasp"] = true,
	["Defensive battle in"] = true,
	["Offensive battle in"] = true,
	["The battle for Wintergrasp is underway."] = true,
	["Next battle in"] = true,
	["Shift-hint"] = "|cffeda55fShift-Click|r to insert information into chat edit box.",
	["Announce to"] = true,
	["Announce time"] = true,
	["Choose whom to announce when battle will start."] = true,
	["Choose when to announce the upcoming battle."] = true,
	["Self"] = true,
	["Guild"] = true,
	["Party"] = true,
	["Raid"] = true,
	["Warn self on upcoming battle."] = true,
	["Warn guild on upcoming battle."] = true,
	["Warn party on upcoming battle."] = true,
	["Warn raid on upcoming battle."] = true,
	["The battle for Wintergrasp has begun."] = true,
	[" minutes."] = true,
	["Start"] = true,
	["Warn at battle start."] = true,
	["Warn "] = true,
	[" minutes before battle."] = true,
} end)
