-- Spanish localization

local L = AceLibrary("AceLocale-2.2"):new("Fubar_WintergrasperFu")

L:RegisterTranslations("esMX", function () return {
	-- L["Announce time"] = "Announce time"
	-- L["Announce to"] = "Announce to"
	["Battle"] = "Batalla", -- Needs review
	-- L["Choose when to announce the upcoming battle."] = "Choose when to announce the upcoming battle."
	-- L["Choose whom to announce when battle will start."] = "Choose whom to announce when battle will start."
	["Defensive battle in"] = "Batalla defensiva en", -- Needs review
	-- L["Guild"] = "Guild"
	-- L[" minutes."] = " minutes."
	-- L[" minutes before battle."] = " minutes before battle."
	["Next battle in"] = "Siguiente batalla en", -- Needs review
	["Offensive battle in"] = "Batalla ofensiva en", -- Needs review
	-- L["Party"] = "Party"
	-- L["Raid"] = "Raid"
	-- L["Self"] = "Self"
	["Shift-hint"] = "|cffeda55fShift-Click|r para insertar informaci�n en la caja de edici�n del chat.", -- Needs review
	["Show seconds"] = "Mostrar segundo", -- Needs review
	-- L["Start"] = "Start"
	-- L["The battle for Wintergrasp has begun."] = "The battle for Wintergrasp has begun."
	["The battle for Wintergrasp is underway."] = "La batalla por Conquista del Invierno ya ha comenzado.", -- Needs review
	["Toggle to show seconds."] = "Activar para mostrar el segundo.", -- Needs review
	["Unknown"] = "Desconocido", -- Needs review
	-- L["Warn "] = "Warn "
	-- L["Warn at battle start."] = "Warn at battle start."
	-- L["Warn guild on upcoming battle."] = "Warn guild on upcoming battle."
	-- L["Warn party on upcoming battle."] = "Warn party on upcoming battle."
	-- L["Warn raid on upcoming battle."] = "Warn raid on upcoming battle."
	-- L["Warn self on upcoming battle."] = "Warn self on upcoming battle."
	["Wintergrasp"] = "Conquista del Invierno", -- Needs review
} end)
