-- ruRU localization

local L = AceLibrary("AceLocale-2.2"):new("Fubar_WintergrasperFu")

L:RegisterTranslations("ruRU", function () return {
	["Announce time"] = "Объявлять время",
	["Announce to"] = "Обьявлять в",
	["Battle"] = "Битва",
	["Choose when to announce the upcoming battle."] = "Выбрать за сколько объявлять о приближающейся битве.",
	["Choose whom to announce when battle will start."] = "Выберите кому объявлять о начале битвы.",
	["Defensive battle in"] = "Оборона через",
	["Guild"] = "Гильдии",
	[" minutes."] = " минут.",
	[" minutes before battle."] = " минут до битвы.",
	["Next battle in"] = "Следующая битва через",
	["Offensive battle in"] = "Атака через",
	["Party"] = "Группе",
	["Raid"] = "Рейду",
	["Self"] = "Себе",
	["Shift-hint"] = "|cffeda55fShift-клик|r для копирования информации в чат",
	["Show seconds"] = "Показать секунды",
	["Start"] = "Начало",
	["The battle for Wintergrasp has begun."] = "Битва за Озеро Ледяных Оков началась.",
	["The battle for Wintergrasp is underway."] = "Битва за Озеро Ледяных Оков уже идёт", -- Needs review
	["Toggle to show seconds."] = "Включить, чтобы показать секунды.",
	["Unknown"] = "Неизвестно",
	["Warn "] = "Предупреждать ",
	["Warn at battle start."] = "Предупреждать при начале битвы.",
	["Warn guild on upcoming battle."] = "Предупреждать гильдию о приближающейся битве.",
	["Warn party on upcoming battle."] = "Предупреждать группу о приближающейся битве.",
	["Warn raid on upcoming battle."] = "Предупреждать рейд о приближающейся битве.",
	["Warn self on upcoming battle."] = "Предупреждать о приближающейся битве.",
	["Wintergrasp"] = "Озеро Ледяных Оков", -- Needs review
} end)
