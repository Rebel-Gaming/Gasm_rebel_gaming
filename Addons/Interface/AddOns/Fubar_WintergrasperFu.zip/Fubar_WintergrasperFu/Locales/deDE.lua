-- deDE localization

local L = AceLibrary("AceLocale-2.2"):new("Fubar_WintergrasperFu")

L:RegisterTranslations("deDE", function () return {
	["Announce time"] =  "Zeit melden",
	["Announce to"] = "Mitteilung an",
	["Battle"] = "Schlacht",
	["Choose when to announce the upcoming battle."] = "W�hle, wann die bevorstehende Schlacht gemeldet werden soll.",
	["Choose whom to announce when battle will start."] = "W�hle, wem mitgeteilt werden soll, wann die Schlacht beginnt.",
	["Defensive battle in"] = "Verteidigungsschlacht in",
	["Guild"] = "Gilde",
	[" minutes."] = " Minuten.",
	[" minutes before battle."] = " Minuten bis zur Schlacht.",
	["Next battle in"] = "N�chster Kampf in",
	["Offensive battle in"] = "Angriffsschlacht in",
	["Party"] = "Gruppe",
	["Raid"] = "Schlachtzug",
	["Self"] = "Mich selbst",
	["Shift-hint"] = "|cffeda55fShift-Click|r um Informationen in das Chatfenster einzutragen.",
	["Show seconds"] = "Sekunden anzeigen",
	["Start"] = "Beginn",
	["The battle for Wintergrasp has begun."] = "Die Schlacht um Tausendwinter hat begonnen.",
	["The battle for Wintergrasp is underway."] = "Die Schlacht um Tausendwinter l�uft gerade.",
	["Toggle to show seconds."] = "Umschalten, um die Sekunden anzuzeigen.",
	["Unknown"] = "Unbekannt",
	["Warn "] = "Warne ",
	["Warn at battle start."] = "Warne bei Schlachtbeginn.",
	["Warn guild on upcoming battle."] = "Gilde bei bevorstehender Schlacht warnen.",
	["Warn party on upcoming battle."] = "Gruppe bei bevorstehender Schlacht warnen.",
	["Warn raid on upcoming battle."] = "Schlachtzug bei bevorstehender Schlacht warnen.",
	["Warn self on upcoming battle."] = "Mich selbst bei bevorstehender Schlacht warnen.",
	["Wintergrasp"] = "Tausendwinter",
} end)
