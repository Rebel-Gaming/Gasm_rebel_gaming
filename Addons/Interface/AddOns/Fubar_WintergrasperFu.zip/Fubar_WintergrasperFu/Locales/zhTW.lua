-- zhTW localization

local L = AceLibrary("AceLocale-2.2"):new("Fubar_WintergrasperFu")

L:RegisterTranslations("zhTW", function () return {
	["Announce time"] = "公佈時間",
	["Announce to"] = "公佈到",
	["Battle"] = "戰役",
	["Choose when to announce the upcoming battle."] = "選擇何時通知戰役即將開打",
	["Choose whom to announce when battle will start."] = "選擇戰役即將開打時要通知的對象",
	["Defensive battle in"] = "冬握湖防禦戰役開始時間尚餘",
	["Guild"] = "公會",
	[" minutes."] = " 分鐘.",
	[" minutes before battle."] = " 分鐘後戰役開打.",
	["Next battle in"] = "下一場冬握湖戰役開始時間尚餘",
	["Offensive battle in"] = "冬握湖進攻戰役開始時間尚餘",
	["Party"] = "小隊",
	["Raid"] = "團隊",
	["Self"] = "自己",
	["Shift-hint"] = "|cffeda55f按住shift鍵單擊|r插入資訊至對話編輯框",
	["Show seconds"] = "顯示秒數",
	["Start"] = "開始",
	["The battle for Wintergrasp has begun."] = "冬握湖戰役已經開始",
	["The battle for Wintergrasp is underway."] = "冬握湖戰役正在進行中",
	["Toggle to show seconds."] = "啟用顯示秒數",
	["Unknown"] = "未知",
	["Warn "] = "警告",
	["Warn at battle start."] = "戰役開打時警告",
	["Warn guild on upcoming battle."] = "戰役即將到來時警告公會",
	["Warn party on upcoming battle."] = "戰役即將到來時警告小隊",
	["Warn raid on upcoming battle."] = "戰役即將到來時警告團隊",
	["Warn self on upcoming battle."] = "戰役即將到來時警告自己",
	["Wintergrasp"] = "冬握湖",
} end)
