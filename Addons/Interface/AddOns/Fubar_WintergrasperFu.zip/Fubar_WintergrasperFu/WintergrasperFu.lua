﻿WintergrasperFu = AceLibrary("AceAddon-2.0"):new("FuBarPlugin-2.0", "AceDB-2.0", "AceEvent-2.0")

WintergrasperFu.title = "WintergrasperFu "..GetAddOnMetadata("Fubar_WintergrasperFu", "Version") 
WintergrasperFu.hasIcon = "Interface\\Icons\\INV_Jewelry_Ring_66"
WintergrasperFu.defaultPosition = "LEFT"
WintergrasperFu.cannotDetachTooltip = true
WintergrasperFu.cannotAttachToMinimap = true

local status = nil
local faction = nil
local nextBattle = nil

WintergrasperFu:RegisterDB("WintergrasperFuDB");
WintergrasperFu:RegisterDefaults('profile', {
	showSeconds = false,
	tellSelf = true,
	tellGuild = true,
	tellParty = false,
	tellRaid = false,
	timeNow = false,
	timeFive = true,
	timeFifteen = true,
	timeThirty = true,
})

local Tablet = AceLibrary("Tablet-2.0")
local L = AceLibrary("AceLocale-2.2"):new("Fubar_WintergrasperFu")

--------------------------------------------------------------------------------------------------------
--                                        Fubar options pannel                                        --
--------------------------------------------------------------------------------------------------------
function WintergrasperFu:IsTellSelf()
	return self.db.profile.tellSelf
end

function WintergrasperFu:ToggleTellSelf()
	self.db.profile.tellSelf = not self.db.profile.tellSelf
end

function WintergrasperFu:IsTellGuild()
	return self.db.profile.tellGuild
end

function WintergrasperFu:ToggleTellGuild()
	self.db.profile.tellGuild = not self.db.profile.tellGuild
end

function WintergrasperFu:IsTellParty()
	return self.db.profile.tellParty
end

function WintergrasperFu:ToggleTellParty()
	self.db.profile.tellParty = not self.db.profile.tellParty
end

function WintergrasperFu:IsTellRaid()
	return self.db.profile.tellRaid
end

function WintergrasperFu:ToggleTellRaid()
	self.db.profile.tellRaid = not self.db.profile.tellRaid
end

function WintergrasperFu:IsShowingSeconds()
	return self.db.profile.showSeconds
end

function WintergrasperFu:ToggleShowingSeconds()
	self.db.profile.showSeconds = not self.db.profile.showSeconds
	self:UpdateText()
end

function WintergrasperFu:IsTimeNow()
	return self.db.profile.timeNow
end

function WintergrasperFu:ToggleTimeNow()
	self.db.profile.timeNow = not self.db.profile.timeNow
end

function WintergrasperFu:IsTimeFive()
	return self.db.profile.timeFive
end

function WintergrasperFu:ToggleTimeFive()
	self.db.profile.timeFive = not self.db.profile.timeFive
end

function WintergrasperFu:IsTimeFifteen()
	return self.db.profile.timeFifteen
end

function WintergrasperFu:ToggleTimeFifteen()
	self.db.profile.timeFifteen = not self.db.profile.timeFifteen
end

function WintergrasperFu:IsTimeThirty()
	return self.db.profile.timeThirty
end

function WintergrasperFu:ToggleTimeThirty()
	self.db.profile.timeThirty = not self.db.profile.timeThirty
end

local options = {
	type = 'group',
	args = {
		seconds = {
			type = 'toggle',
			order = 1,
			name = L["Show seconds"],
			desc = L["Toggle to show seconds."],
			get = "IsShowingSeconds",
			set = "ToggleShowingSeconds",
		},
		announceTo = {
			type = 'group',
			order = 2,
			name = L["Announce to"],
			desc = L["Choose whom to announce when battle will start."],
			args = {
				self = {
					type = 'toggle',
					order = 1,
					name = L["Self"],
					desc = L["Warn self on upcoming battle."],
					get = "IsTellSelf",
					set = "ToggleTellSelf",
				},
				guild = {
					type = 'toggle',
					order = 2,
					name = L["Guild"],
					desc = L["Warn guild on upcoming battle."],
					get = "IsTellGuild",
					set = "ToggleTellGuild",
				},
				party = {
					type = 'toggle',
					order = 3,
					name = L["Party"],
					desc = L["Warn party on upcoming battle."],
					get = "IsTellParty",
					set = "ToggleTellParty",
				},
				raid = {
					type = 'toggle',
					order = 4,
					name = L["Raid"],
					desc = L["Warn raid on upcoming battle."],
					get = "IsTellRaid",
					set = "ToggleTellRaid",
				},
			},
		},
		announceTime = {
			type = 'group',
			order = 3,
			name = L["Announce time"],
			desc = L["Choose when to announce the upcoming battle."],
			args = {
				now= {
					type = 'toggle',
					order = 1,
					name = L["Start"],
					desc = L["Warn at battle start."],
					get = "IsTimeNow",
					set = "ToggleTimeNow",
				},
				five= {
					type = 'toggle',
					order = 2,
					name = "5" .. L[" minutes."],
					desc = L["Warn "] .. "5" .. L[" minutes before battle."],
					get = "IsTimeFive",
					set = "ToggleTimeFive",
				},
				fifteen= {
					type = 'toggle',
					order = 3,
					name = "15" .. L[" minutes."],
					desc = L["Warn "] .. "15" .. L[" minutes before battle."],
					get = "IsTimeFifteen",
					set = "ToggleTimeFifteen",
				},
				thirty = {
					type = 'toggle',
					order = 4,
					name = "30" .. L[" minutes."],
					desc = L["Warn "] .. "30" .. L[" minutes before battle."],
					get = "IsTimeThirty",
					set = "ToggleTimeThirty",
				},
			},
		},
	},
	handler = WintergrasperFu
}

WintergrasperFu.OnMenuRequest = options

function WintergrasperFu:OnClick()
	if IsShiftKeyDown() then
		if ChatFrameEditBox:IsVisible() then
			local message = self:GetAnnounceText()
			ChatFrameEditBox:Insert(message)
		end
	end
end

function WintergrasperFu:OnTooltipUpdate()
	Tablet:SetHint(L["Shift-hint"])
end

--------------------------------------------------------------------------------------------------------
--                                       Fubar_WintergrasperFu core                                   --
--------------------------------------------------------------------------------------------------------

-- Startup, enabling and disabling
function WintergrasperFu:OnEnable() -- AceAddon-2.0 event
	self:ScheduleRepeatingEvent(self.UpdateText, 1, self)
end

-- Periodic updates of text
function WintergrasperFu:EverySecond() -- AceEvent-2.0 event
	self:UpdateText()
end

-- Main update function
function WintergrasperFu:OnTextUpdate() -- FuBarPlugin-2.0 event
	if (faction == nil or faction == "unknown" or faction == "battle") then
		self:UpdateIcon()
	end
	if (nextBattle == nil or status == nil) then
		self:UpdateTime()
	end
	local timeText
	if (faction == "battle") then
		timeText = L["Battle"]
	elseif (status == "unknown" and not nextBattle) then
		timeText = L["Unknown"]
	elseif nextBattle then
		local seconds = nextBattle - time()
		if (seconds > 0) then
			timeText = self:GetTimeText(seconds)
			if (seconds > 8990) then
				faction = nil
			end
			if seconds == 1800 and self:IsTimeThirty() then
				self:Warn(30)
			elseif seconds == 900 and self:IsTimeFifteen() then
				self:Warn(15)
			elseif seconds == 300 and self:IsTimeFive() then
				self:Warn(5)
			end
		elseif (seconds == 0 ) then
			if self:IsTimeNow() then
				self:Warn(0)
			end
			faction = nil
			nextBattle = nextBattle + 9000
			timeText = self:GetTimeText(seconds)
		else
			faction = nil
			nextBattle = nil
			timeText = L["Unknown"]
		end
	end
	if timeText then
		self:SetText("|cffffff00" .. timeText .. "|r")
	end
end

--------------------------------------------------------------------------------------------------------
--                                   Fubar_WintergrasperFu functions                                  --
--------------------------------------------------------------------------------------------------------

-- Update time and status.
function WintergrasperFu:UpdateTime()
	local seconds = GetWintergraspWaitTime()
	if seconds then 
		nextBattle = time() + GetWintergraspWaitTime()
		status = nil
	else
		status = "unknown"
	end
end

-- Search for WG status. Update faction and icon if needed.
function WintergrasperFu:UpdateIcon()
	local aux = 1
	if faction == "battle" then
		aux = GetWintergraspWaitTime()
	end
	if not WorldMapFrame:IsVisible() and aux then
		local continentIndex = GetCurrentMapContinent()
		if not IsInInstance() and continentIndex == 4 then
			local zoneIndex = GetCurrentMapZone()
			SetMapZoom(4)
			local n = GetNumMapLandmarks()
			if n > 0 then
				for i = 1, n do
					local name, _, nr = GetMapLandmarkInfo(i)
					if name == L["Wintergrasp"] then
						if nr == 46 then
							self:SetIcon("Interface\\Addons\\Fubar_WintergrasperFu\\alliance")
							faction = "Alliance"
							self:UpdateTime()
							return
						elseif nr == 48 then
							self:SetIcon("Interface\\Addons\\Fubar_WintergrasperFu\\horde")
							faction = "Horde"
							self:UpdateTime()
							return
						elseif nr == 101 then
							self:SetIcon("Interface\\Icons\\Ability_DualWield")
							faction = "battle"
							return
						end
					end
				end			
			end
			SetMapZoom(continentIndex, zoneIndex, 1)
		end
		self:SetIcon("Interface\\Icons\\INV_Jewelry_Ring_66")
		faction = "unknown"	
	end
end

-- Return Wintergasp wait time in "h:m:s", or "Battle" if match in progress
function WintergrasperFu:GetTimeText(seconds)
	local timeText = ""
	local h = math.floor(seconds / 3600)
	local m = math.floor((seconds % 3600) / 60)
	local s = seconds % 60
	if self:IsShowingSeconds() then
		if h > 9 then
			timeText = h .. ":"
		elseif h > 0 then
			timeText = "0" .. h .. ":"
		else
			timeText = "00" .. ":"
		end
		if m > 9 then
			timeText = timeText .. m .. ":"
		elseif m > 0 then
			timeText = timeText .. "0" .. m .. ":"
		else
			timeText = timeText .. "00" .. ":"
		end
		if s > 9 then
			timeText = timeText .. s
		elseif s > 0 then
			timeText = timeText .. "0" .. s
		else
			timeText = timeText .. "00"
		end
	elseif seconds > 59 then
		if h > 9 then
			timeText = h .. ":"
		elseif h > 0 then
			timeText = "0" .. h .. ":"
		else
			timeText = "00" .. ":"
		end
		if m > 9 then
			timeText = timeText .. m
		elseif m > 0 then
			timeText = timeText .. "0" .. m
		else
			timeText = timeText .. "00"
		end
	else
		if m > 9 then
			timeText = timeText .. m .. ":"
		elseif m > 0 then
			timeText = timeText .. "0" .. m .. ":"
		else
			timeText = timeText .. "00" .. ":"
		end
		if s > 9 then
			timeText = timeText .. s
		elseif s > 0 then
			timeText = timeText .. "0" .. s
		else
			timeText = timeText .. "00"
		end
	end
	return timeText
end

function WintergrasperFu:GetAnnounceText()
	local message = "[FuBar_WintergrasperFu]"
	if faction == "Horde" or faction == "Alliance" then
		if faction == UnitFactionGroup("player") then
			message = message .. " " .. L["Defensive battle in"]
		else
			message = message .. " " .. L["Offensive battle in"]
		end
	elseif faction == "battle" then
		message = message .. " " .. L["The battle for Wintergrasp is underway."]
	else
		message = message .. " " .. L["Next battle in"]
	end
	if not (faction == "battle") then
		if nextBattle then
			local seconds = nextBattle - time()
			local timeText = self:GetTimeText(seconds)
			message = message .. " " .. timeText
		else
			message = message .. " " .. L["Unknown"]
		end
	end
	return message
end

function WintergrasperFu:Warn(seconds)
	local numGuild, numParty, numRaid = GetNumGuildMembers(), GetNumPartyMembers(), GetNumRaidMembers()
	local msg = "[FuBar_WintergrasperFu] "
	
	if seconds == 0 then
		msg = msg .. L["The battle for Wintergrasp has begun."]
	else
		if faction == "Horde" or faction == "Alliance" then
			if faction == UnitFactionGroup("player") then
				msg = msg .. L["Defensive battle in"] .. " "
			else
				msg = msg .. L["Offensive battle in"] .. " "
			end
		else
			msg = msg .. " " .. L["Next battle in"] .. " "
		end
		msg = msg .. seconds .. L[" minutes."]
	end
	
	if self:IsTellSelf() then
		DEFAULT_CHAT_FRAME:AddMessage("|cffff0000" .. msg .. "|r")
	end
	if self:IsTellGuild() and (numGuild > 0) then
		SendChatMessage(msg,"GUILD",nil,nil)
	end
	if self:IsTellParty() and (numParty > 0) then
		SendChatMessage(msg,"PARTY",nil,nil)
	end
	if self:IsTellRaid() and (numRaid > 0) then
		SendChatMessage(msg,"RAID",nil,nil)
	end
end
