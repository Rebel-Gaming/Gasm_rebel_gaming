if( GetLocale() == "ruRU") then
	--thanks to  Compeccator for the translations

	MyLocalization = setmetatable(
	  {}, -- empty table
	  {
		__index = function(self, key) -- line 8
		  rawset(self, key, key)
		  return key
		end
	  }
	)

	MyLocalization["+100 Chips"] = "+100 \209\132\208\184\209\136\208\181\208\186"
MyLocalization["2 of a Kind"] = "\208\191\208\176\209\128\208\176"
MyLocalization["2 Pair"] = "2 \208\191\208\176\209\128\209\139"
MyLocalization["3 of a Kind"] = "\209\130\209\128\208\190\208\185\208\186\208\176"
MyLocalization["4 of a Kind"] = "\208\186\208\176\209\128\209\141"
MyLocalization["Ace"] = "\209\130\209\131\208\183"
MyLocalization["Aces"] = "\209\130\209\131\208\183\209\139"
MyLocalization["a Fork of AnzacHoldem"] = "a Fork of AnzacHoldem" -- Requires localization
MyLocalization["Alliance"] = "\208\144\208\187\208\184\208\176\208\189\209\129"
MyLocalization["All In"] = "\208\178\208\176-\208\177\208\176\208\189\208\186"
MyLocalization["Artwork"] = "Artwork" -- Requires localization
MyLocalization["AutoDealing"] = "\208\176\208\178\209\130\208\190\209\129\208\180\208\176\209\135\208\176"
MyLocalization["Big Blind"] = "\208\145\208\190\208\187\209\140\209\136\208\190\208\185 \208\145\208\187\208\176\208\185\208\189\208\180"
MyLocalization["Blind increase percent per round"] = "\208\191\209\128\208\190\209\134\208\181\208\189\209\130 \209\131\208\178\208\181\208\187\208\184\209\135\208\181\208\189\208\184\209\143 \208\145\208\187\208\176\208\185\208\189\208\180\208\190\208\178 \208\183\208\176 \209\128\208\176\209\131\208\189\208\180"
MyLocalization["Blinds"] = "\208\145\208\187\208\176\208\185\208\189\208\180\209\139"
MyLocalization["Boot"] = "Boot" -- Requires localization
MyLocalization["Call"] = "\208\154\208\190\208\187"
MyLocalization["Call any"] = "Call any" -- Requires localization
MyLocalization["Called"] = "\208\154\208\190\208\187\209\140\208\189\209\131\208\187"
MyLocalization["Cancel"] = "\208\158\209\130\208\188\208\181\208\189\208\176"
MyLocalization["Cannot boot the dealer."] = "Cannot boot the dealer." -- Requires localization
MyLocalization["Check"] = "\208\167\208\181\208\186"
MyLocalization["Checked"] = "\208\167\208\181\208\186\208\189\209\131\208\187"
MyLocalization["Chips"] = "\208\164\208\184\209\136\208\186\208\184"
MyLocalization["Clear Chips"] = "\208\158\209\135\208\184\209\129\209\130\208\184\209\130\209\140 \208\164\208\184\209\136\208\186\208\184"
MyLocalization["Current Blind Increment per round"] = "Current Blind Increment per round" -- Requires localization
MyLocalization["Default"] = "Default" -- Requires localization
MyLocalization["Do you wish to start Dealing?"] = "\208\150\208\181\208\187\208\176\208\181\209\130\208\181 \208\189\208\176\209\135\208\176\209\130\209\140 \209\129\208\180\208\176\208\178\208\176\209\130\209\140?"
MyLocalization["Eight"] = "\208\146\208\190\209\129\208\181\208\188\209\140"
MyLocalization["Eights"] = "\208\146\208\190\209\129\209\140\208\188\208\181\209\128\208\186\208\184"
MyLocalization["Error case"] = "\208\158\209\136\208\184\208\177\208\186\208\176"
MyLocalization["Feedback: www.FreeHoldemStrategy.com/forum/"] = "Feedback: www.FreeHoldemStrategy.com/forum/" -- Requires localization
MyLocalization["Five"] = "\208\159\209\143\209\130\209\140"
MyLocalization["Fives"] = "\208\159\209\143\209\130\208\181\209\128\208\186\208\184"
MyLocalization["Flush"] = "\208\164\208\187\209\141\209\136"
MyLocalization["Flush: %s high"] = "\208\164\208\187\209\141\209\136: %s \209\129\209\130\208\176\209\128\209\136\208\186\208\176\209\143"
MyLocalization["Flush Straight"] = "\208\161\209\130\209\128\208\184\209\130 \208\164\208\187\209\141\209\136"
MyLocalization["Fold"] = "\208\164\208\190\208\187\208\180"
MyLocalization["Folded"] = "\208\164\208\190\208\187\208\180\208\189\209\131\208\187"
MyLocalization["Four"] = "\208\167\208\181\209\130\209\139\209\128\208\181"
MyLocalization["Fours"] = "\208\167\208\181\209\130\208\178\208\181\209\128\208\186\208\184"
MyLocalization["Full House"] = "\208\164\209\131\208\187-\208\165\208\176\209\131\209\129"
MyLocalization["has left the table."] = "\208\191\208\190\208\186\208\184\208\189\209\131\208\187 \209\129\209\130\208\190\208\187."
MyLocalization["has quit. GG."] = "\208\178\209\139\209\136\208\181\208\187. \208\161\208\186\208\176\209\130\208\181\209\128\209\130\209\140\209\142 \208\180\208\190\209\128\208\190\208\182\208\186\208\176."
MyLocalization["High Card"] = "\208\161\209\130\208\176\209\128\209\136\208\186\208\176\209\143 \208\154\208\176\209\128\209\130\208\176"
MyLocalization["Horde"] = "\208\158\209\128\208\180\208\176"
MyLocalization["I'm Back"] = "\208\175 \208\146\208\181\209\128\208\189\209\131\208\187\209\129\209\143"
MyLocalization["Jack"] = "\208\146\208\176\208\187\208\181\209\130"
MyLocalization["Jacks"] = "\208\146\208\176\208\187\209\140\209\130\209\139"
MyLocalization["King"] = "\208\154\208\190\209\128\208\190\208\187\209\140"
MyLocalization["Kings"] = "\208\154\208\190\209\128\208\190\208\187\208\184"
MyLocalization["Learn How to Play Texas Holdem"] = "Learn How to Play Texas Holdem" -- Requires localization
MyLocalization["Looking for clients"] = "\208\152\209\137\208\181\209\130 \208\186\208\187\208\184\208\181\208\189\209\130\208\190\208\178"
MyLocalization["Looking for dealers"] = "\208\152\209\137\208\181\209\130 \209\129\208\180\208\176\209\142\209\137\208\184\209\133"
MyLocalization["Minimap Icon"] = "\208\152\208\186\208\190\208\189\208\186\208\176 \208\189\208\176 \208\188\208\184\208\189\208\184\208\186\208\176\209\128\209\130\208\181"
MyLocalization["Neutral"] = "Neutral" -- Requires localization
MyLocalization["Next Round's Big Blind"] = "Next Round's Big Blind" -- Requires localization
MyLocalization["Nine"] = "Nine" -- Requires localization
MyLocalization["Nines"] = "Nines" -- Requires localization
MyLocalization["No such player"] = "No such player" -- Requires localization
MyLocalization["No Winners. Game Seed = "] = "No Winners. Game Seed = " -- Requires localization
MyLocalization["Ok"] = "Ok" -- Requires localization
MyLocalization["Options"] = "Options" -- Requires localization
MyLocalization["Original"] = "Original" -- Requires localization
MyLocalization["Play"] = "\208\152\208\179\209\128\208\176\208\185"
MyLocalization["Player Invalid Action"] = "\208\157\208\181\208\178\208\190\208\183\208\188\208\190\208\182\208\189\208\190\208\181 \208\180\208\181\208\185\209\129\209\130\208\178\208\184\208\181"
MyLocalization["Playing"] = "\208\152\208\179\209\128\208\176\209\142"
MyLocalization["Queen"] = "\208\148\208\176\208\188\208\176"
MyLocalization["Queens"] = "\208\148\208\176\208\188\209\139"
MyLocalization["Quit"] = "\208\146\209\139\208\185\209\130\208\184"
MyLocalization["Raise"] = "\208\159\208\190\208\180\208\189\209\143\209\130\209\140"
MyLocalization["Raised"] = "\208\159\208\190\208\180\208\189\209\143\208\187"
MyLocalization["Royal Flush"] = "\208\159\208\190\209\143\208\187\209\140 \208\164\208\187\209\141\209\136"
MyLocalization["Select card back artwork"] = "\208\146\209\139\208\177\209\128\208\176\209\130\209\140 \209\128\209\131\208\177\208\176\209\136\208\186\209\131"
MyLocalization["Set the by what percent the Blind increases each round"] = "\208\163\209\129\209\130\208\176\208\189\208\190\208\178\208\184\209\130\208\181 \208\189\208\176 \209\129\208\186\208\190\208\187\209\140\208\186\208\190 \208\191\209\128\208\190\209\134\208\181\208\189\209\130\208\190\208\178 \209\131\208\178\208\181\208\187\208\184\209\135\208\184\208\178\208\176\209\142\209\130\209\129\209\143 \208\145\208\187\208\176\208\185\208\189\208\180\209\139 \208\186\208\176\208\182\208\180\209\139\208\185 \209\128\208\176\209\131\208\189\208\180"
MyLocalization["Set the starting Blind"] = "\208\163\209\129\209\130\208\176\208\189\208\190\208\178\208\184\209\130\208\181 \208\189\208\176\209\135\208\176\208\187\209\140\208\189\209\139\208\185 \208\145\208\187\208\176\208\185\208\189\208\180"
MyLocalization["Set the starting Chips"] = "\208\163\209\129\209\130\208\176\208\189\208\190\208\178\208\184\209\130\208\181 \208\189\208\176\209\135\208\176\208\187\209\140\208\189\208\190\208\181 \208\186\208\190\208\187\208\184\209\135\208\181\209\129\209\130\208\178\208\190 \208\164\208\184\209\136\208\181\208\186"
MyLocalization["Seven"] = "\208\161\208\181\208\188\209\140"
MyLocalization["Sevens"] = "\208\161\208\181\208\188\208\181\209\128\208\186\208\184"
MyLocalization["%s full of %s"] = "%s \208\191\208\190\208\187\208\190\208\189 %s"
MyLocalization["%s has client version %s"] = "%s \208\184\208\188\208\181\208\181\209\130 \208\186\208\187\208\184\208\181\208\189\209\130\209\129\208\186\209\131\209\142 \208\178\208\181\209\128\209\129\208\184\209\142 %s"
MyLocalization["%s has no seat available for you"] = "%s \208\189\208\181 \208\184\208\188\208\181\208\181\209\130 \208\180\208\187\209\143 \208\146\208\176\209\129 \208\188\208\181\209\129\209\130\208\176"
MyLocalization["%s has seated you in Seat %d"] = "%s \208\191\208\190\209\129\208\176\208\180\208\184\208\187  %d"
MyLocalization["Show Cards"] = "\208\159\208\190\208\186\208\176\208\182\208\183\208\176\209\130\209\140 \208\186\208\176\209\128\209\130\209\139"
MyLocalization["Showdown"] = "Showdown" -- Requires localization
MyLocalization["Showing"] = "\208\159\208\190\208\186\208\176\208\183\209\139\208\178\208\176\208\181\209\130"
MyLocalization["%s is a dealer and has %s seats available"] = "%s \209\129\208\180\208\176\209\142\209\137\208\184\208\185 \208\184 \208\184\208\188\208\181\208\181\209\130 %s \209\129\208\178\208\190\208\177\208\190\208\180\208\189\209\139\209\133 \208\188\208\181\209\129\209\130"
MyLocalization["Sit Out"] = "\208\158\209\130\209\129\208\184\208\180\208\181\209\130\209\140\209\129\209\143"
MyLocalization["Sitting Out"] = "\208\158\209\130\209\129\208\184\208\182\208\184\209\139\208\178\208\176\208\181\209\130\209\129\209\143"
MyLocalization["Six"] = "\208\168\208\181\209\129\209\130\209\140"
MyLocalization["Sixes"] = "\208\168\208\181\209\129\209\130\208\181\209\128\208\186\208\184"
MyLocalization["Small Blind"] = "\208\156\208\176\208\187\209\139\208\185 \208\145\208\187\208\176\208\185\208\189\208\180"
MyLocalization["Sorry the dealer can not sit out.  Set your chips to Zero to enable auto deal."] = "\208\152\208\178\208\183\208\184\208\189\208\184\209\130\208\181, \208\180\208\184\208\187\208\181\209\128 \208\189\208\181 \208\188\208\190\208\182\208\181\209\130 \208\189\208\181 \208\184\208\179\209\128\208\176\209\130\209\140. \208\163\208\188\208\181\208\189\209\140\209\136\208\184\209\130\208\181 \208\146\208\176\209\136\208\184 \209\132\208\184\209\136\208\186\208\184 \208\180\208\190 \208\157\209\131\208\187\209\143, \209\135\209\130\208\190\208\177\209\139 \208\178\208\186\208\187\209\142\209\135\208\184\209\130\209\140 \208\176\208\178\209\130\208\190-\209\129\208\180\208\176\209\135\209\131."
MyLocalization["%s over %s"] = "%s over %s" -- Requires localization
MyLocalization["Split"] = "\208\161\208\191\208\187\208\184\209\130"
MyLocalization["%s sits %s in Seat %d"] = "%s \209\129\208\176\208\180\208\184\209\130\209\129\209\143 %s \208\183\208\176 \209\129\209\130\208\190\208\187 %d"
MyLocalization["Start Dealing"] = "\208\161\208\180\208\176\208\178\208\176\208\185\209\130\208\181"
MyLocalization["Starting Blind"] = "\208\157\208\176\209\135\208\176\208\187\209\140\208\189\209\139\208\185 \208\145\208\187\208\176\208\185\208\189\208\180"
MyLocalization["Starting Chips"] = "\208\157\208\176\209\135\208\176\208\187\209\140\208\189\209\139\208\181 \208\164\208\184\209\136\208\186\208\184"
MyLocalization["Sticky"] = "Sticky" -- Requires localization
MyLocalization["Straight"] = "\208\161\209\130\209\128\208\184\209\130"
MyLocalization["Straight Flush to the %s"] = "\208\161\209\130\209\128\208\184\209\130 \208\164\208\187\209\141\209\136 \208\180\208\190 %s"
MyLocalization["Straight to the %s"] = "\208\161\209\130\209\128\208\184\209\130 \208\180\208\190 %s"
MyLocalization["Ten"] = "\208\148\208\181\209\129\209\143\209\130\209\140"
MyLocalization["Tens"] = "\208\148\208\181\209\129\209\143\209\130\208\186\208\184"
MyLocalization["The dealer booted you."] = "The dealer booted you." -- Requires localization
MyLocalization["These options are saved between sessions"] = "These options are saved between sessions" -- Requires localization
MyLocalization["Three"] = "\208\162\209\128\208\184"
MyLocalization["Threes"] = "\208\162\209\128\208\190\208\185\208\186\208\184"
MyLocalization["Tick to act automatically"] = "Tick to act automatically" -- Requires localization
MyLocalization["To join a game use '/holdem dealer <playername>'"] = "To join a game use '/holdem dealer <playername>'" -- Requires localization
MyLocalization["Total Pot"] = "\208\145\208\176\208\189\208\186"
MyLocalization["Turn minimap icon on/off"] = "\208\146\208\186\208\187/\208\146\209\139\208\186\208\187 \208\184\208\186\208\190\208\189\208\186\209\131 \208\189\208\176 \208\188\208\184\208\189\208\184\208\186\208\176\209\128\209\130\208\181"
MyLocalization["Two"] = "\208\148\208\178\208\176"
MyLocalization["Twos"] = "\208\148\208\178\208\190\208\185\208\186\208\184"
MyLocalization["Use '/holdem artwork <number>' to set artwork."] = "Use '/holdem artwork <number>' to set artwork." -- Requires localization
MyLocalization["Use '/holdem blind <number>' to set starting blind."] = "Use '/holdem blind <number>' to set starting blind." -- Requires localization
MyLocalization["Use '/holdem clients' to find clients in your guild/party/raid."] = "Use '/holdem clients' to find clients in your guild/party/raid." -- Requires localization
MyLocalization["Use '/holdem dealer <playername>' to join someone elses table."] = "Use '/holdem dealer <playername>' to join someone elses table." -- Requires localization
MyLocalization["Use '/holdem dealers' to find dealers in your guild/party/raid."] = "Use '/holdem dealers' to find dealers in your guild/party/raid." -- Requires localization
MyLocalization["Use '/holdem help' for slash command options"] = "Use '/holdem help' for slash command options" -- Requires localization
MyLocalization["Use '/holdem increase <percent>' to set blind increment percent."] = "Use '/holdem increase <percent>' to set blind increment percent." -- Requires localization
MyLocalization["Use '/holdem options' for options panel"] = "Use '/holdem options' for options panel" -- Requires localization
MyLocalization["Use '/holdem' to start a table as the dealer."] = "Use '/holdem' to start a table as the dealer." -- Requires localization
MyLocalization["Use just /holdem instead"] = "Use just /holdem instead" -- Requires localization
MyLocalization["Winner!"] = "\208\159\208\190\208\177\208\181\208\180\208\184\209\130\208\181\208\187\209\140!"
MyLocalization["wins"] = "\208\178\209\139\208\184\208\179\209\128\209\139\208\178\208\176\208\181\209\130"
MyLocalization["WoW Texas Hold'em"] = "\208\146\208\190\208\146 \208\159\208\190\208\186\208\181\209\128 \208\162\208\181\209\133\208\176\209\129 "
MyLocalization["WoW Texas Hold'em Options"] = "\208\146\208\190\208\146 \208\159\208\190\208\186\208\181\209\128 \208\162\208\181\209\133\208\176\209\129 \208\158\208\191\209\134\208\184\208\184"
MyLocalization["You are now a dealer."] = "\208\146\209\139 - \209\129\208\180\208\176\209\142\209\137\208\184\208\185."
MyLocalization["You cannot show your cards until the hand is over"] = "You cannot show your cards until the hand is over" -- Requires localization
MyLocalization["You did not act in time. Press I'm Back to continue playing."] = "You did not act in time. Press I'm Back to continue playing." -- Requires localization
MyLocalization["Your turn"] = "\208\146\208\176\209\136\208\176 \208\190\209\135\208\181\209\128\208\181\208\180\209\140"


end