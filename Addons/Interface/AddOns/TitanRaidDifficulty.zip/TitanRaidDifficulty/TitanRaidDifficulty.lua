------------------------------------------------------------
-- Plugin:					Raid Difficulty
-- Author:					Qery
-- Version:					1.0a
-- Website:					http://www.qery.net/
------------------------------------------------------------

-- definitions --
local RDifficultyDung = "unknown";
local RDifficultyRaid = "unknown";
local RDifficultyDungShort = "?";
local RDifficultyRaidShort = "?";
local RDifficultyList = "";
local RDifficultyListNum = 0;

function TitanPanelRaidDifficultyButton_OnLoad()
	this.registry = { 
		id = "RaidDifficulty",
		menuText = "Raid Difficulty", 
		buttonTextFunction = "TitanPanelRaidDifficultyButton_GetButtonText", 
		tooltipTitle = "Raid difficulty:",
		tooltipTextFunction = "TitanPanelRaidDifficultyButton_GetTooltipText",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = 1,
		}
	};

  this:RegisterEvent("PARTY_MEMBERS_CHANGED");
  this:RegisterEvent("RAID_ROSTER_UPDATE");
	this:RegisterEvent("PLAYER_ENTERING_WORLD");
	this:RegisterEvent("UPDATE_INSTANCE_INFO");
	this:RegisterEvent("PLAYER_LEAVING_WORLD");
	this:RegisterEvent("RAID_INSTANCE_WELCOME");
	this:RegisterEvent("CHAT_MSG_SYSTEM");

	local icon = TitanPanelRaidDifficultyButtonIcon;
	icon:SetTexture("Interface\\GROUPFRAME\\UI-GROUP-MAINASSISTICON");

  TitanPanelRaidDifficulty_UpdateInfo();
end

function TitanPanelRaidDifficultyButton_OnClick(self, button)
	if (button=="LeftButton") then ToggleFriendsFrame(5); end
end

function TitanPanelRaidDifficultyButton_OnEvent(self, event, ...)
 	TitanPanelRaidDifficulty_UpdateInfo();	   	
	TitanPanelButton_UpdateTooltip();
	TitanPanelButton_UpdateButton("RaidDifficulty");	
end

function TitanPanelRaidDifficultyButton_OnEnter()
	TitanPanelRaidDifficulty_UpdateInfo();
end

function TitanPanelRaidDifficultyButton_GetButtonText(id)
	local id = TitanUtils_GetButton(id, true);

	return "Difficulty: ", TitanUtils_GetHighlightText("D:").." "..TitanUtils_GetGreenText(RDifficultyDungShort).." "..
												 TitanUtils_GetHighlightText("R:").." "..TitanUtils_GetGreenText(RDifficultyRaidShort);
end

function TitanPanelRaidDifficulty_UpdateInfo()
	-- difficulty strings
	dd=GetDungeonDifficulty();
	rd=GetRaidDifficulty();
	if (dd==1) then
		RDifficultyDung="Normal";
		RDifficultyDungShort="N";
	else
		RDifficultyDung="Heroic";
		RDifficultyDungShort="HC";
	end
	if (rd==1) then
		RDifficultyRaid="10 Player";
		RDifficultyRaidShort="10";
	elseif (rd==2) then
		RDifficultyRaid="25 Player";
		RDifficultyRaidShort="25";
	elseif (rd==3) then
		RDifficultyRaid="10 Player heroic";
		RDifficultyRaidShort="10HC";
	elseif (rd==4) then
		RDifficultyRaid="25 Player heroic";
		RDifficultyRaidShort="25HC";
	end
	
	-- instance list
	RDifficultyList="";
	RDifficultyListNum=0;
	for i=1, GetNumSavedInstances() do
		local name,_,remaining,difficulty = GetSavedInstanceInfo(i);
		if (remaining>0 and difficulty==1) then
			RDifficultyList=RDifficultyList..name;
			if (difficulty==2) then RDifficultyList=RDifficultyList.." (Heroic)"; end
			RDifficultyList=RDifficultyList.."\t"..TitanUtils_GetHighlightText(TitanPanelRaidDifficulty_Calculate(remaining)).."\n";
			RDifficultyListNum=RDifficultyListNum+1;
		end
	end
	for i=1, GetNumSavedInstances() do
		local name,_,remaining,difficulty = GetSavedInstanceInfo(i);
		if (remaining>0 and difficulty==2) then
			RDifficultyList=RDifficultyList..name;
			if (difficulty==2) then RDifficultyList=RDifficultyList.." (Heroic)"; end
			RDifficultyList=RDifficultyList.."\t"..TitanUtils_GetHighlightText(TitanPanelRaidDifficulty_Calculate(remaining)).."\n";
			RDifficultyListNum=RDifficultyListNum+1;
		end
	end
end

function TitanPanelRaidDifficulty_Calculate(sec)
	-- do the math
	local days=floor(sec/86400); sec=sec-days*86400;
	local hrs=floor(sec/3600); sec=sec-hrs*3600;
	local mins=floor(sec/60);
	
	-- make string
	str="";
	if (days>0) then str=str..days.."d "; end
	if (hrs>0) then str=str..hrs.."h "; end
	if (mins>0) then str=str..mins.."m "; end

	return str;
end

-- make tooltip --
function TitanPanelRaidDifficultyButton_GetTooltipText()
	local tiptext="\n";
	-- settings
	tiptext=tiptext..TitanUtils_GetHighlightText("Settings:\n")..
									 "Dungeon:\t"..TitanUtils_GetHighlightText(RDifficultyDung).."\n"..
									 "Raid:\t"..TitanUtils_GetHighlightText(RDifficultyRaid).."\n";

	-- saves
	if (RDifficultyListNum>0) then
		tiptext=tiptext.."\n"..TitanUtils_GetHighlightText("Saved in:\n")..
										 RDifficultyList;
	end

	return tiptext;
end

-- difficulty setting --
function TitanPanelRaidDifficultyButton_SetDungNormal()
	SetDungeonDifficulty(1);
end
function TitanPanelRaidDifficultyButton_SetDungHeroic()
	SetDungeonDifficulty(2);
end
function TitanPanelRaidDifficultyButton_SetRaid10Normal()
	SetRaidDifficulty(1);
end
function TitanPanelRaidDifficultyButton_SetDung10Heroic()
	SetRaidDifficulty(3);
end
function TitanPanelRaidDifficultyButton_SetRaid25Normal()
	SetRaidDifficulty(2);
end
function TitanPanelRaidDifficultyButton_SetDung25Heroic()
	SetRaidDifficulty(4);
end
function TitanPanelRaidDifficultyButton_Readycheck()
	DoReadyCheck();
end

-- menu --
function TitanPanelRightClickMenu_PrepareRaidDifficultyMenu()
	local info;

	TitanPanelRightClickMenu_AddTitle("Dungeon Difficulty");
	
	info = {};
	info.text = "Normal";
	info.func = TitanPanelRaidDifficultyButton_SetDungNormal;
	UIDropDownMenu_AddButton(info); 
	
	info = {};
	info.text = "Heroic";
	info.func = TitanPanelRaidDifficultyButton_SetDungHeroic;
	UIDropDownMenu_AddButton(info); 

	TitanPanelRightClickMenu_AddSpacer();

	TitanPanelRightClickMenu_AddTitle("Raid Difficulty");
	
	info = {};
	info.text = "10 player - Normal";
	info.func = TitanPanelRaidDifficultyButton_SetRaid10Normal;
	UIDropDownMenu_AddButton(info); 
	
	info = {};
	info.text = "10 player - Heroic";
	info.func = TitanPanelRaidDifficultyButton_SetDung10Heroic;
	UIDropDownMenu_AddButton(info); 

	info = {};
	info.text = "25 player - Normal";
	info.func = TitanPanelRaidDifficultyButton_SetRaid25Normal;
	UIDropDownMenu_AddButton(info); 
	
	info = {};
	info.text = "25 player - Heroic";
	info.func = TitanPanelRaidDifficultyButton_SetDung25Heroic;
	UIDropDownMenu_AddButton(info); 

	TitanPanelRightClickMenu_AddSpacer();

	TitanPanelRightClickMenu_AddTitle("Other");

	info = {};
	info.text = "Readycheck";
	info.func = TitanPanelRaidDifficultyButton_Readycheck;
	UIDropDownMenu_AddButton(info); 
end
