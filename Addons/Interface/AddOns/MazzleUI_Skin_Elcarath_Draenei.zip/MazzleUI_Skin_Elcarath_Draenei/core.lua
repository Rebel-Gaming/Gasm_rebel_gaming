function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Draenei\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Draenei\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Draenei\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Draenei\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Draenei\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Draenei\\MazzleUICastingBarBorder",
            chatborder = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Draenei\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Draenei\\MazzleUIMinimapBorder",
        },
    }
end