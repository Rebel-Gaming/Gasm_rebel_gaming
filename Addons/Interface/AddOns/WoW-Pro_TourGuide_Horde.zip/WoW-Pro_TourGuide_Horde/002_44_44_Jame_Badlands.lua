TourGuide:RegisterGuide("[WoW-Pro | Jame's 41-51] Badlands (44)", "[WoW-Pro | Jame's 41-51] Stranglethorn Vale (44-45)", "Horde", function()
return [[
F Kargath |N|Fly to Kargath in the Badlands. |
C Study of the Elements: Rock |N|Ride south to around (13,85) to find Greater Rock Elementals.  Kill then until you've found 5 bracers.  There are more to the west around (7,80). | |L|4628 5| |QID|712|
T Study of the Elements: Rock |QID|712|
A Coolant Heads Prevail |QID|713|
T Coolant Heads Prevail |QID|713|
A Gyro... What? |QID|714|
T Gyro... What? |QID|714|
A This Is Going to Be Hard |QID|734|
A Stone Is Better than Cloth |QID|716|
T Stone Is Better than Cloth |QID|716|
C This Is Going to Be Hard |N|Be sure you're ready to fight: healthy, buffed, not in cooldown. | |L|4847 1| |QID|734|
T This Is Going to Be Hard |N|Congrats on your first trinket! | |QID|734|
R Kargath |N|We're heading out! Ride back to Kargath (4.3,46.4). |
]]
end)
