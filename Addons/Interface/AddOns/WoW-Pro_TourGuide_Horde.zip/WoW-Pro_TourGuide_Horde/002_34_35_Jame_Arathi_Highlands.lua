TourGuide:RegisterGuide("[WoW-Pro | Jame's 31-41] Arathi Highlands (34-35)", "[WoW-Pro | Jame's 31-41] Alterac Valley (35-36)", "Horde", function()

--> Original guides written/designed by [Jame]
-->
--> Last modified by [Jiyambi] 7/12/2009

return [[
C The Hammer May Fall|QID|676|N|Stay on the road for a while until the location (30,50), north of that point you should see a mound with some ogres, this area is called Boulder' gor. Boulderfist Enforcers can only be found inside the cave, which can be entered from the east side of the mound.|
R Hammerfall|N|Get back on the road, follow it eastwards until you reach a crossroads, follow the smaller trail going northeast.|
T Trollbane|QID|638|N|Further inside the village, go up the stairs.|
T The Hammer May Fall|QID|676|
A Call to Arms (Part 1)|QID|677|
f Hammerfall
N Repair, restock and vendor junk
A Crystal in the Mountains|QID|635|U|4614|
C Call to Arms (Part 1)|QID|677|N|Head out, go south until you find Witherbark Village (69,60).|

H Tarren Mill
T Elixir of Agony (Part 4)|QID|517|
A Elixir of Agony (Part 5)|QID|524|
T Battle of Hillsbrad (Part 6)|QID|541|
A Battle of Hillsbrad (Part 7)|QID|550|
T Humbert's Sword|QID|547|
T Elixir of Agony (Part 5)|QID|524|N|Go to the inn, on the 2nd floor there's a room with Captured Farmers inside, and a "Dusty Rug" on the floor. |
N Repair, restock and vendor junk
]]
end)