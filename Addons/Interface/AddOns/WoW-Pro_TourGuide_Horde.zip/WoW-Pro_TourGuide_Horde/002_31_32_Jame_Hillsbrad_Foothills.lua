TourGuide:RegisterGuide("[WoW-Pro | Jame's 31-41] Hillsbrad Foothills (31-32)", "[WoW-Pro | Jame's 31-41] Thousand Needles (32-33)", "Horde", function()

--> Original guides written/designed by [Jame]
-->
--> Last modified by [Jiyambi] 7/12/2009

return [[
R Undercity|N|Take the Zeppelin to the Undercity|
A To Steal from Thieves|QID|1164|N|In the Undercity, next to the Bat Handler.|
T Elixir of Agony (Part 2)|QID|513|N|Then go to the Apothecarium, find Master Apothecary Farell.|
A Elixir of Agony (Part 3)|QID|515|
F Tarren Mill
A Helcular's Revenge (Part 1)|QID|552|N|From Novice Thaivand.|

N Torn Fin Eyes|N|Head southwest until you hit the Western Strand (36,66) with the Murloc Camps. Kill murlocs until you get 5 Torn Fin Eyes.|Q|Elixir of Agony|QO|Torn Fin Eye: 5/5|
C Elixir of Agony (Part 3)|QID|515|N|Go east and across the river, until you find nagas at (58,64). Kill them until you have 5 Daggerspine Scales.|
C Helcular's Revenge (Part 1)|QID|552|N|Go northwest to the Yeti Cave (46,30). Kill yetis until you get Helcular's Rod, which is kinda rare, so just kill a lot of yetis. It might take a long time, so be patient. If it really takes more than 20 minute, try to log out and then back in. For some reason this worked for me a couple of times and the rod dropped on the first few kills after I logged back in, after a 20 minute yeti slaughter with no success.|
T Elixir of Agony (Part 3)|QID|515|N|Go back to Tarren Mill.|
A Elixir of Agony (Part 4)|QID|517|
T Helcular's Revenge (Part 1)|QID|552|
A Helcular's Revenge (Part 2)|QID|553|
H Orgrimmar

N Train, Repair, restock and vendor junk


]]
end)