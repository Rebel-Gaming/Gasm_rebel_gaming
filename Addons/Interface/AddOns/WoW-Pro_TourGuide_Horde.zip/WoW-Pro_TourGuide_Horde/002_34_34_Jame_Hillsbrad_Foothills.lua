TourGuide:RegisterGuide("[WoW-Pro | Jame's 31-41] Hillsbrad Foothills (34-34)", "[WoW-Pro | Jame's 31-41] Arathi Highlands (34-35)", "Horde", function()

--> Original guides written/designed by [Jame]
-->
--> Last modified by [Jiyambi] 7/12/2009

return [[
R Undercity|N|Take the Zeppelin to the Undercity.|
F Tarren Mill
A Humbert's Sword|QID|547|
A Stone Tokens|QID|556|
A The Hammer may fall|QID|676|
A Infiltration|QID|533|
A Prison break in|QID|544|

A Soothing Turtle Bisque|QID|7321|
B Soothing Spices
T Soothing Turtle Bisque|QID|7321|
h Tarren Mill
C Elixir of Agony (Part 4)|QID|517|N|Go southeast to the Dwarven Fortress of Dun Garok (69,73). Your first task will be to make yourself a way inside the fortress and find a Keg of Shindigger Stout, they can mostly be found on the side rooms down the stairs.|
K Captain Ironhill|N|He can spawn a various locations: * On the top floors, which is good because he can easily be pulled solo there. * On the big middle room down the stairs.|Q|Battle of Hillsbrad|QO|Captain Ironhill slain: 1/1|
C Humbert's Sword|QID|547|N|Keep killing dwarves in the fortress until you've completed the kill list of [30]Battle of Hillsbrad and gotten Humbert's Sword.|
C Battle of Hillsbrad (Part 6)|QID|541|
R Arathi Highlands|N|Get out of the Dwarven Fortress, get back on the path going northeast and then east into Arathi Highlands.|
]]
end)