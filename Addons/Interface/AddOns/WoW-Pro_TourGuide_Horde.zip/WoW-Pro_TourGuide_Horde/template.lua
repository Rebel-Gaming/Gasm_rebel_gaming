
TourGuide:RegisterGuide("[WoW-Pro | Guide Name] Zone Name (Level Range)", "[WoW-Pro | Next Guide Name] Next Zone Name (Next Level Range)", "Horde", function()
return [[
]]
end)

