local L = AceLibrary("AceLocale-2.2"):new("SCT_Cooldowns");

	L:RegisterTranslations("enUS", function() return {
		-- Slash Commands
		["/sctcooldowns"] = true,
		["/sctc"] = true,
		-- name
		["format"] = true,
		["warning"] = true,
		["wformat"] = true,
		["disable"] = true,
		["list"] = true,
		["color"] = true,
		["crit"] = true,
		["frame"] = true,
		["icon"] = true,
		-- desc
		["Change the format string, or reset (%s is replaced by the spell name)."] = true,
		["Show a warning x seconds before cooldown finishes (0 to disable)."] = true,
		["Change the format string of the warning message, or reset (%s is replaced by the spell name)."] = true,
		["Disable the message for that spell. Run it again to enable."] = true,
		["Spells currently disabled."] = true,
		["Change the color of the cooldown messages."] = true,
		["Show message like a crit."] = true,
		["Change the frame cooldowns are displayed in."] = true,
		["Display cooldown Icon in SCT."] = true,
		-- usage
		["[string/reset]"] = true,
		["[seconds]"] = true,
		["[spell name]"] = true,
		["[1/2/msg]"] = true,
		-- Variables
		["[%s Ready]"] = true,
		["[%s Ready in %d]"] = true,
		
		-- SCTC Groups
		["Traps"] = true,
		["Freezing Trap"] = true,
		["Immolation Trap"] = true,
		["Explosive Trap"] = true,
		["Frost Trap"] = true,
		["Snake Trap"] = true,
		
		["Reta/SW/Reck"] = true,
		["Retaliation"] = true,
		["Shield Wall"] = true,
		["Recklessness"] = true,
		
		["Shocks"] = true,
		["Earth Shock"] = true,
		["Flame Shock"] = true,
		["Frost Shock"] = true,
		
		["Wards"] = true,
		["Frost Ward"] = true,
		["Fire Ward"] = true,
		
		["Ranged"] = true,
		["Shoot"] = true,
		["Throw"] = true,
		
		["Bubble"] = true,
		["Divine Shield"] = true,
		["Divine Protection"] = true,
		};
	end
);