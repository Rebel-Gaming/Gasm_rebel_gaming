﻿local L = AceLibrary("AceLocale-2.2"):new("SCT_Cooldowns");

	L:RegisterTranslations("koKR", function() return {
		-- Slash Commands
		["/sctcooldowns"] = "/sctcooldowns",
		["/sctc"] = "/sctc",
		-- name
		["format"] = "형식",
		["warning"] = "경고",
		["wformat"] = "경고형식",
		["disable"] = "표시안함",
		["list"] = "목록",
		["color"] = "색상",
		["crit"] = "강조",
		["frame"] = "프레임",
		["icon"] = "아이콘",
		-- desc
		["Change the format string, or reset (%s is replaced by the spell name)."] = "형식 문자열을 바꾸거나 초기화 (%s는 주문이름을 대신합니다)합니다.",
		["Show a warning x seconds before cooldown finishes (0 to disable)."] = "재사용 끝나기 x초전에 경고를 보여줍니다. (0은 표시안함).",
		["Change the format string of the warning message, or reset (%s is replaced by the spell name)."] = "경고 메시지의 형식 문자열을 바꾸거나, 또는 초기화 (%s는 주문이름을 대신)합니다.",
		["Disable the message for that spell. Run it again to enable."] = "그 주문을 위한 메시지를 표시하지 않습니다. 가능하게 하기 위하여 다시 실행 해야합니다.",
		["Spells currently disabled."] = "주문은 지금 표시하지 않습니다.",
		["Change the color of the cooldown messages."] = "재사용 메시지의 색상을 바꿉니다.",
		["Show message like a crit."] = "메시지를 강조하여 보여줍니다.",
		["Change the frame cooldowns are displayed in."] = "재사용 표시의 프레임을 바꿉니다.",
		["Display cooldown Icon in SCT."] = "SCT의 재사용 아이콘 표시.",
		-- usage
		["[string/reset]"] = "[문자열/초기화]",
		["[seconds]"] = "[초]",
		["[spell name]"] = "[주문 이름]",
		["[1/2/msg]"] = "[1/2/메세지]",
		-- Variables
		["[%s Ready]"] = "[%s Ready]",
		["[%s Ready in %d]"] = "[%s Ready in %d]",

		-- SCTC Groups
		["Traps"] = "덫",
		["Freezing Trap"] = "얼음의 덫",
		["Immolation Trap"] = "제물의 덫",
		["Explosive Trap"] = "폭발의 덫",
		["Frost Trap"] = "냉기의 덫",
		["Snake Trap"] = "뱀 덫",
		
		["Reta/SW/Reck"] = "보복/방벽/무희",
		["Retaliation"] = "보복",
		["Shield Wall"] = "방패의 벽",
		["Recklessness"] = "무모한 희생",
		
		["Shocks"] = "충격",
		["Earth Shock"] = "대지 충격",
		["Flame Shock"] = "화염 충격",
		["Frost Shock"] = "냉기 충격",
		
		["Wards"] = "수호",
		["Frost Ward"] = "냉기계 수호",
		["Fire Ward"] = "화염계 수호",
		
		["Ranged"] = "원거리",
		["Shoot"] = "사격",
		["Throw"] = "투척",
		
		["Bubble"] = "무적",
		["Divine Shield"] = "천상의 보호막",
		["Divine Protection"] = "신의 가호",
		};
	end
);