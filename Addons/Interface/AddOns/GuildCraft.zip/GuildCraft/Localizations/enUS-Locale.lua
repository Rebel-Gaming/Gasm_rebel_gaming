--[[
	Guild Craft - Locale file for enUS
	Written By: Apollo Shockman
	Last Modified by OrionShock on 2010-01-19T07:18:06Z

]]--

local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale("GuildCraft", "enUS", true, debug)



--Core File
L["Add Player to Blacklist"] = true
L["Alternate Update"] = true
L["Auto Import from Guild Members"] = true
L["Auto Import from Non-Guild Players"] = true
L["Can be crafted by:"] = true
L["Cannot load browser UI reason: %s"] = true
L["Click|r to toggle the Browser"] = true
L["Enabling this requires the cache to be loaded at startup, this can cause startup lag"] = true
L["General Options"] = true
L["Guild Craft"] = true
L["Guild Craft - Browser"] = true
L["Import %s Tradeskill data?"] = true
L["Maintenance Options"] = true
L["Not In Guild"] = true
L["No Tradeskill Data Available"] = true
L["Open Guild Craft Viewer to see who can make this."] = true
L["Pull Links From"] = true
L["Pull Links from Quick List"] = true
L["Purge Player"] = true
L["Push Links To"] = true
L["Push Links to Quick List"] = true
L["Refresh"] = true
L["Remove Blacklisted Player"] = true
L["Right-click|r to open the options menu"] = true
L["Search"] = true
L["Searchbox can take several arguments. IE: searching Jewlcrafting for 'epic simple red' returns all gems that fit a red socket"] = true
L["Select a Trade Skill from the List above and the craftables from the left"] = true
L["Share Tradeskills with Guild / Others"] = true
L["Show Crafters in tooltips"] = true
L["Show Extended LDB Tooltip"] = true
L["Synch Guild Info"] = true
L["Toggle Mini-Map Button"] = true
L["Version & Revision: %s, %s"] = true




--Locale Counter --change to generate a new zip due to locale changes :) == 13
