--[[
	Guild Craft - Locale file for deDE
	Written By: Apollo Shockman
	Last Modified by OrionShock on 2009-12-17T10:59:19Z

]]--






local L = LibStub("AceLocale-3.0"):NewLocale("GuildCraft", "deDE")

if not L then return end

--Core File
L["Add Player to Blacklist"] = "Spieler ignorieren"
L["Alternate Update"] = "Alternatives Update"
L["Auto Import from Guild Members"] = "Daten von Gildenmitgliedern automatisch importieren"
L["Auto Import from Non-Guild Players"] = "Daten von gildenexternen Charakteren automatisch importieren"
L["Can be crafted by:"] = "Kann hergestellt werden von:"
L["Cannot load browser UI reason: %s"] = "Browser UI kann aus folgendem Grund nicht geladen werden: %s"
L["Click|r to toggle the Browser"] = "Klicken|r um das Browserfenster zu öffnen"
L["Enabling this requires the cache to be loaded at startup, this can cause startup lag"] = "Diese Option muss den Cache beim Start laden, das kann Lag beim Start verursachen."
L["General Options"] = "Allgemeine Optionen"
L["Guild Craft"] = "Guild Craft"
L["Guild Craft - Browser"] = "Guild Craft - Browser"
L["Import %s Tradeskill data?"] = "Berufsdaten von %s importieren?"
L["Maintenance Options"] = "Wartungsoptionen"
L["Not In Guild"] = "Nicht in der Gilde"
L["No Tradeskill Data Available"] = "Keine Berufsdaten verfügbar"
L["Open Guild Craft Viewer to see who can make this."] = "Öffne den Guild Craft Browser um zu sehen, wer das herstellen kann."
L["Pull Links From"] = "Hole Links von"
L["Pull Links from Quick List"] = "Hole Links von Schnellliste"
L["Purge Player"] = "Spieler löschen"
L["Push Links To"] = "Sende Links zu"
L["Push Links to Quick List"] = "Sende Links zu Schnellliste"
L["Refresh"] = "Aktualisieren"
L["Remove Blacklisted Player"] = "Spieler nicht mehr ignorieren"
L["Right-click|r to open the options menu"] = "Rechtsklicken|r um das Optionsmenü zu öffnen"
L["Search"] = "Suche"
L["Searchbox can take several arguments. IE: searching Jewlcrafting for 'epic simple red' returns all gems that fit a red socket"] = "Die Suchbox akzeptiert mehrere Argumente. Z.B.: Eine Suche in Juwelenschleifen nach 'ausweich rot' liefert alle Sockelsteine mit Ausweichwertung, die in einen roten Sockel passen."
L["Select a Trade Skill from the List above and the craftables from the left"] = "Wähle einen Beruf von der oberen Liste und das Erzeugnis von der linken Liste"
L["Share Tradeskills with Guild / Others"] = "Teile Berufe mit Gilde / Anderen"
L["Show Crafters in tooltips"] = "Zeige Hersteller-Namen in Tooltips"
L["Show Extended LDB Tooltip"] = "Zeige erweiterten LDB Tooltip"
L["Synch Guild Info"] = "Gilde synchronisieren"
L["Toggle Mini-Map Button"] = "Zeige Minimap Button"
L["Version & Revision: %s, %s"] = "Version & Revision: %s, %s"

