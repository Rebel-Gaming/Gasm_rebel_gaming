--[[
	Guild Craft - Locale file for TEMP
	Written By: Apollo Shockman
	Last Modified by OrionShock on 2009-12-17T10:59:19Z

]]--






local L = LibStub("AceLocale-3.0"):NewLocale("GuildCraft", "TEMP")

if not L then return end

--Core File
--@localization(locale="TEMP", format="lua_additive_table", handle-subnamespaces="none" )@
