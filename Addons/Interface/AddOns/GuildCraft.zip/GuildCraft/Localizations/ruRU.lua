--[[
	Guild Craft - Locale file for ruRU
	Written By: Apollo Shockman
	Last Modified by OrionShock on 2009-12-17T10:59:19Z

]]--






local L = LibStub("AceLocale-3.0"):NewLocale("GuildCraft", "ruRU")

if not L then return end

--Core File
L["Add Player to Blacklist"] = "Добавить Игрока в Черный список"
L["Alternate Update"] = "Использовать Альтернативный способ обновления информации"
L["Auto Import from Guild Members"] = "Авто Импорт информации из Гильдии"
L["Auto Import from Non-Guild Players"] = "Авто Импорт информации от Игроков не из Гильдии"
L["Can be crafted by:"] = "Может быть изготовлено:"
L["Cannot load browser UI reason: %s"] = "Невозможно загрузить Интерфейс просмотра: %s"
L["Click|r to toggle the Browser"] = "Клик|r переключает окно просмотра"
L["Enabling this requires the cache to be loaded at startup, this can cause startup lag"] = "Включение этого параметра потребует загрузку кэша при входе в игровой мир, это может привести к задержке запуска"
L["General Options"] = "Основные настройки"
L["Guild Craft"] = "Guild Craft"
L["Guild Craft - Browser"] = "Guild Craft - Окно просмотра"
L["Import %s Tradeskill data?"] = "Импортировать данные о профессии %s?"
L["Maintenance Options"] = "Настройки обслуживания"
L["Not In Guild"] = "Вы не состоите в Гильдии"
L["No Tradeskill Data Available"] = "Данные о Профессиях не доступны"
L["Open Guild Craft Viewer to see who can make this."] = "Откройте окно просмотра Guild Craft чтобы посмотреть кто может изготовить этот предмет."
L["Pull Links From"] = "Загружать Ссылки на Профессии из"
L["Pull Links from Quick List"] = "Загружать Ссылки на Профессии из Списка быстрого просмотра"
L["Purge Player"] = "Удалить информацию о Игроке"
L["Push Links To"] = "Отправлять Ссылки на профессии в"
L["Push Links to Quick List"] = "Отправлять Ссылки на Профессии в Список быстрого просмотра"
L["Refresh"] = "Обновить"
L["Remove Blacklisted Player"] = "Удалить Игрока из Черного списка"
L["Right-click|r to open the options menu"] = "Правый-Клик|r открывает меню настроек"
L["Search"] = "Поиск"
L["Searchbox can take several arguments. IE: searching Jewlcrafting for 'epic simple red' returns all gems that fit a red socket"] = "Окно поиска может принимать несколько аргументов. IE: поиск в Ювелирном деле 'эпический простой красное гнездо' покажет все драгоценные камни для красного гнезда"
L["Select a Trade Skill from the List above and the craftables from the left"] = "Выберите профессию из списка вверху и вещь из списка слева"
L["Share Tradeskills with Guild / Others"] = "Предоставить доступ к Профессиям членам Гильдии / Другими игрокам"
L["Show Crafters in tooltips"] = "Отображать в Подсказках кто может изготовить"
L["Show Extended LDB Tooltip"] = "Отображать Расширенные Подсказки LDB"
L["Synch Guild Info"] = "Синхронизировать Информацию о Гильдии"
L["Toggle Mini-Map Button"] = "Кнопка у Мини-Карты"
L["Version & Revision: %s, %s"] = "Версия и Ревизия: %s, %s"

