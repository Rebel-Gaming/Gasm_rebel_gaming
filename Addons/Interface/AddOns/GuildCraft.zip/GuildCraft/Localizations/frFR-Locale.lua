--[[
	Guild Craft - Locale file for frFR
	Written By: Apollo Shockman
	Last Modified by OrionShock on 2009-12-17T10:59:19Z

]]--






local L = LibStub("AceLocale-3.0"):NewLocale("GuildCraft", "frFR")

if not L then return end

--Core File
-- L["Add Player to Blacklist"] = ""
-- L["Alternate Update"] = ""
-- L["Auto Import from Guild Members"] = ""
-- L["Auto Import from Non-Guild Players"] = ""
-- L["Can be crafted by:"] = ""
-- L["Cannot load browser UI reason: %s"] = ""
L["Click|r to toggle the Browser"] = "Cliquer|r pour lancer le navigateur"
-- L["Enabling this requires the cache to be loaded at startup, this can cause startup lag"] = ""
L["General Options"] = "Options Générales"
L["Guild Craft"] = "Guild Craft"
L["Guild Craft - Browser"] = "Guild Craft - Navigateur"
-- L["Import %s Tradeskill data?"] = ""
L["Maintenance Options"] = "Options de maintenance"
-- L["Not In Guild"] = ""
-- L["No Tradeskill Data Available"] = ""
L["Open Guild Craft Viewer to see who can make this."] = "Ouvrir Guild Craft Visionneur pour voir qui peut faire ça"
-- L["Pull Links From"] = ""
-- L["Pull Links from Quick List"] = ""
-- L["Purge Player"] = ""
-- L["Push Links To"] = ""
-- L["Push Links to Quick List"] = ""
L["Refresh"] = "Rafraichir"
-- L["Remove Blacklisted Player"] = ""
L["Right-click|r to open the options menu"] = "Cliquer droit|r pour ouvrir le menu des options"
L["Search"] = "Rechercher"
-- L["Searchbox can take several arguments. IE: searching Jewlcrafting for 'epic simple red' returns all gems that fit a red socket"] = ""
L["Select a Trade Skill from the List above and the craftables from the left"] = "Sélectionnez un artisanat dans la liste ci-dessus, et les confections sur la gauche"
L["Share Tradeskills with Guild / Others"] = "Partagez vos confections d'artisanat avec la guilde/les autres"
-- L["Show Crafters in tooltips"] = ""
-- L["Show Extended LDB Tooltip"] = ""
-- L["Synch Guild Info"] = ""
-- L["Toggle Mini-Map Button"] = ""
L["Version & Revision: %s, %s"] = "Version & Révision: %s, %s"

