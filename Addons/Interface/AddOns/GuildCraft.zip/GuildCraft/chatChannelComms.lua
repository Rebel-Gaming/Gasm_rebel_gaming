local projectVersion = "v3.5.4-release"
local projectRevision = "@project-revision@"
local fileRevision = "@file-revision@"

local AddonParent = LibStub("AceAddon-3.0"):GetAddon("GuildCraft")
local module = AddonParent:NewModule("ChatChannelComms", "AceSerializer-3.0", "AceEvent-3.0")
local CommsIO = AddonParent:GetModule("CommsIO")
module.rev = fileRevision
local CTL = assert(ChatThrottleLib, "Many things in GuildCraft will require ChatThrottleLib, if it's not there you installed this wrong, very wrong!")

local channelName, channelPass, channelNumber

local function CheckChatChannel()
	local self = module
	if not channelName then 
		--self:Debug("CCC - No Channel Name") 
		return false 
	end
	--self:Debug("CCC", GetChannelName(channelName))	
	if GetChannelName(channelName) == 0 then
		local sucsess, a, b, c, d, e = JoinChannelByName(channelName, channelPass)
		--self:Debug("JoinChannelByName() return:", sucsess, a, b, c, d, e)
		if not sucsess then
			message("GuildCraft -- Unable to Join ChatChannel, too many chat channels in use. Please Leave one or disable Chat Comms" )
			return false
		end
	end
	channelNumber = GetChannelName(channelName)
	return true
end


local dbDefaults = {
	profile = {
		channel = "GuildCraftGlobal",
		password = "",
		enabled = false,
		},
	}
function module:OnInitialize()
	self.db = AddonParent.db:RegisterNamespace("ChatChannel", dbDefaults)
	self:RegisterMessage("GuildCraft_RosterUpdate")
	self:RegisterMessage("GUILD_CRAFT_SHARE_STATE")
	self:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE")
	self:SetEnabledState( ( (AddonParent.db.profile.shareToGuild) and (self.db.profile.enabled) ) )
	if not fileRevision:find("file") then
		ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL", module.ChatFilter)
	end
	self:Debug("Loaded, OnInit. Module is:",  ( (AddonParent.db.profile.shareToGuild) and (self.db.profile.enabled) ))
end

function module:OnEnable()
	if (AddonParent.db.profile.shareToGuild) and (self.db.profile.enabled) then 
		--self:Debug("Enabled")
		self.frame:RegisterEvent("CHAT_MSG_CHANNEL")
		self:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE")
		self:JoinChannel()
	end
	self:RegisterMessage("GUILD_CRAFT_SHARE_STATE")
end

function module:OnDisable()
	--self:Debug("Disabled")
	self.frame:UnregisterAllEvents()
	self:LeaveChannel()
	self.db.profile.iLeft = date()
end	

function module:GUILD_CRAFT_SHARE_STATE(event, state)
	--self:Debug(event, state)
	if state then
		if self.db.profile.enabled then
			--self:Debug(event, "enabling")
			self:Enable()
			self:JoinChannel()
		end
	else
		--self:Debug(event, "disabling")
		self:Disable()
	end
end

function module:GuildCraft_RosterUpdate(event)
	--self:Debug(event)
	self.isReady = true
	self:JoinChannel()
end

function module:JoinChannel()
	if not self.isReady then return end
	--self:Debug("Enabled State in JoinChannel:", self:IsEnabled())
	if not self:IsEnabled() then
		self:LeaveChannel(self.db.profile.channel)
		return
	end
	channelName = self.db.profile.channel
	channelPass = self.db.profile.password

	--self:Debug("JoinChannel", channelName, channelPass)
	if channelName then
		JoinChannelByName( channelName, channelPassword)
		self:InitChatChannelGreeting()
	end		
end

function module:LeaveChannel(le)
	if channelName or le then
		LeaveChannelByName(channelName or le)
	end
end

function module:CHAT_MSG_CHANNEL_NOTICE(event, ...)
	--self:Debug(event, ...)
	if not self:IsEnabled() then return end
	if not CheckChatChannel() then
		self:InitChatChannelGreeting()
	end
end

function module.ChatFilter(frame, event, incMsg, ...)
	local chl = select(8, ...)
	if chl and chl:lower() == (channelName or ""):lower() then
		return true
	end
	if incMsg:find("^[\001-\003]") then
		return true
	end
	return false, incMsg, ...
end


function module:InitChatChannelGreeting()
	self:SendChatMessage("Call_For_Update")
end


do
	---Based on AceComms-3.0 & Adapted to use ChatChannels instead.
	local MSG_MULTI_FIRST, MSG_MULTI_NEXT, MSG_MULTI_LAST, prio, prefix = "\001", "\002", "\003", "BULK", "GuildCraft-CCC"
	local maxtextlen = 254 --255 is the max for chat messages, but 254 works also, multipart section accounts for header bit.
	local type, strfind, strsub = _G.type, _G.strfind, _G.strsub

	function module:SendChatMessage(...)
		if not CheckChatChannel() then return end
		--self:Debug("Send to Chat:", ...)
		local text = self:Serialize(...):gsub("|", "\005")
		if not type(text)=="string" then
			error('GuildCraft-ChatComms --Usage: SendCommMessage(...) --where ... is a serilizeable value')
		end
		if strfind(text, "[\001-\003]") then
			error("GuildCraft-ChatComms \\001 - \\003 bits are reserved for protocol use, try again")
		end

		local textlen = #text

		if textlen <= maxtextlen then
		-- fits all in one message
			CTL:SendChatMessage(prio, prefix, text, "CHANNEL", nil, channelNumber )
		else
			maxtextlen = maxtextlen - 1 -- 1 extra byte for part indicator in prefix
		-- First Part
			local pos = 1
			local chunk = strsub(text, pos, maxtextlen)
--			if strsub(chunk, -1) == "|" then
--				chunk = strsub(chunk, 1, -2)
--				pos = pos + maxtextlen - 1
--			end
			CTL:SendChatMessage(prio, prefix, MSG_MULTI_FIRST..chunk, "CHANNEL", nil, channelNumber, channelName )
		-- Middle Parts
			pos = pos + maxtextlen
			while pos+maxtextlen <= textlen do
				chunk = strsub(text, pos, pos+maxtextlen-1)
--				if strsub(chunk, -1) == "|" then
--				    chunk = strsub(chunk, 1, -2)
--				    pos = pos - 1
--				end
				CTL:SendChatMessage(prio, prefix, MSG_MULTI_NEXT..chunk, "CHANNEL", nil, channelNumber, channelName )
				pos = pos + maxtextlen
			end
		-- Last
			chunk = strsub(text, pos)
			CTL:SendChatMessage(prio, prefix, MSG_MULTI_LAST..chunk, "CHANNEL", nil, channelNumber, channelName )
		end
	end
end

do
	local cache = setmetatable({},{__mode = "kv"})
	local function newtable()
		local t = next(cache)
		if t then
			cache[t] = nil
		else
			t = {}
		end
		return t
	end
	local function delTable(t)
		if type(t) == "table" then
			wipe(t)
			cache[t] = true
			return nil
		end
		return nil
	end

	local incMsgHold = {}
	module.incMsgHold = incMsgHold
	local function OnCommsEvent(msg, author, lang, fullName, target, status, zoneID, chlNumber, chlName)
		if strfind(msg, "^[\001-\003]") then -- this is multi part
			if strfind(msg, "^\001") then -- this is first part
				incMsgHold[author] = newtable()
				msg = msg:gsub("^\001","")
				tinsert(incMsgHold[author], msg)
			elseif strfind(msg, "^\002") and (incMsgHold[author] and incMsgHold[author][1]) then -- this is 2nd part
				msg = msg:gsub("^\002","")
				tinsert(incMsgHold[author], msg)
			elseif strfind(msg, "^\003") and (incMsgHold[author] and incMsgHold[author][1]) then -- this is Last part
				msg = msg:gsub("^\003","")
				tinsert(incMsgHold[author], msg)
				CommsIO.DispatchComms( author, module:Deserialize( table.concat(incMsgHold[author],""):gsub("\005", "|") ) )
				incMsgHold[author] = delTable(t)
			end
		else
			module:Debug("OnCommsEvent", module:Deserialize(msg:gsub("\005", "|")))
			CommsIO.DispatchComms( author, module:Deserialize(msg:gsub("\005", "|")) )
		end
	end

	local frame = CreateFrame("Frame")
	frame:UnregisterAllEvents()
	--frame:RegisterEvent("CHAT_MSG_CHANNEL")
	frame:SetScript("OnEvent", function(frame, event, ...)
			if not AddonParent.hasUpdateRoster then return end
			if not channelName then return end
			if (select(9, ...)):lower() == channelName:lower() then
				--local author = select(2, ...)
				--if AddonParent.online[author] then 
				--	--self:Debug(event, author, " // sender in guild, ignoring")
				--	return
				--end	--Guild Traffic is sent over guild addon channel, we do not proccess messages from guild in the chat channel.
				OnCommsEvent(...)
				return 
			end
		end)
	module.frame = frame

	frame.module = module
end



local L = LibStub("AceLocale-3.0"):GetLocale("GuildCraft")

function module:EnabledStatus(info, state)
	if state ~= nil then
		self.db.profile.enabled = state
		if state then
			self:Enable()
		else
			self:Disable()
		end
	else
		return self.db.profile.enabled
	end
end

function module:IsParentDisabled()
	if AddonParent.db.profile.shareToGuild then
		return false
	else
		return true
	end
end

function module:NegIsEnabled()
	return not self:IsEnabled()
end


function module:GetAceOptions()
	local t = {
		type = "group",
		name = L["Chat Channel Sharing"],
		handler = module,
		order = 20,
		args = {
			isEnabled = { type = "toggle", name = L["Enable Chat Channel Sharing"], get = "EnabledStatus", set = "EnabledStatus", width = "full", disabled = "IsParentDisabled", order = 1 },
			channel = { type = "input", name = CHANNEL_CHANNEL_NAME , order = 2, get = "ChatOptionsGet", set = "ChatOptionsSet", disabled = "NegIsEnabled" },
			pass = { type = "input", name = PASSWORD, order = 3, get = "ChatOptionsGet", set = "ChatOptionsSet", disabled = "NegIsEnabled"	},
			push = { type = "execute", name = JOIN, order = 4, func = "ChangeOverToNewChannel", disabled = "NegIsEnabled" },
			},
		}

	if AddonParent.blizz_Frame:IsShown() then
		t.hidden = true
	end
	return t
end

function module:ChatOptionsGet(info)
	local i = info[#info]
	if i == "channel" then
		
		return self.newChannel or self.db.profile.channel
		
	elseif i == "pass" then
		return self.db.profile.password
	end
end

function module:ChatOptionsSet(info, value)
	local i = info[#info]
	if i == "channel" then
		if value:trim() == "" then
			return
		else
			self.newChannel = value:trim()
		end
	elseif i == "pass" then
		self.newPassword = value:trim()
	end
end

function module:ChangeOverToNewChannel()
	if (channelName == self.newChannel) and (channelPass == self.newPassword) then
		return
	else
		self:LeaveChannel()
		channelName = self.newChannel
		channelPass = self.newPassword
		self:JoinChannel()
	end
end
		

