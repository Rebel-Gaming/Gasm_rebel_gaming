----------------------
--Options File
--	Maintains the "Core" Addon options and colates other module options togeather.
----------------------

local projectVersion = "v3.5.4-release"
local projectRevision = "41fe740"
if projectVersion:find("project") then
	projectVersion = "git"
	projectRevision = "dev"
end

local L = LibStub("AceLocale-3.0"):GetLocale("GuildCraft")
local core = LibStub("AceAddon-3.0"):GetAddon("GuildCraft")
local module = core:NewModule("Options")
local db
local API = core.API
local ACD = LibStub("AceConfigDialog-3.0")
local AC = LibStub("AceConfig-3.0")
local ACR = LibStub("AceConfigRegistry-3.0")
local LDBI = LibStub("LibDBIcon-1.0", true)
---------------------------------
-- Options Table Stuff, how we loath thee.
---------------------------------

function module:OnEnable()
	LDBI = LibStub("LibDBIcon-1.0", true)
	AC:RegisterOptionsTable("Guild Craft", self.MainLoadAllOptions)
	self.blizz_Frame = ACD:AddToBlizOptions("Guild Craft")
	db = core.db
--	self:Debug("Enabled")
end
local function nilFunc() end


function module:MainLoadAllOptions()
	local self = module
	local t = {
		type = "group", name = "GuildCraft", handler = module,
		get = "GetProfileOption", set = "SetProfileOption",
		childGroups = "tab",
		args = {
			mainOpts = { type = "group", name = L["General Options"], order = 1,
				args = {
					publish = { type = "execute", name = L["Synch Guild Info"], handler = API, func = "CallGuildForProfessionUpdate", order = 1,  }, 
					version = { type = "description", name = "    "..L["Version & Revision: %s, %s"]:format(projectVersion, projectRevision), 
						width = "full", order = 5 },
					general = { type = "group", name = L["General Options"], order = 20, inline = true,
						args = {
							enableSharing = {type = "toggle",  name = L["Share Tradeskills with Guild / Others"],
								width = 'full', arg = "shareDataToGuild" },
							import_guild = {type = "toggle", name = L["Auto Import from Guild Members"], width = "full", arg = "AutoImportGuild"},
							import_other = {type = "toggle", name = L["Auto Import from Non-Guild Players"], 
								width = "full", arg = "AutoImportNonGuild"},
							tooltiphooks = {type = "toggle", name = L["Show Crafters in tooltips"], width = "full", arg = "enableTooltipHooks",
		--						desc = L["Enabling this requires the cache to be loaded at startup, this can cause startup lag"],
							},
							extendedtooltip = {type = "toggle", name = L["Show Extended LDB Tooltip"], width = "full", arg = "extendedtooltip"},
							showMMIcon = {type = "toggle", name = L["Toggle Mini-Map Button"], width = "full",
								get = "ShouldShowLDBI", set = "SetShowDBI",
		--						hide = function(info) return not LibStub("LibDBIcon-1.0", true) end,
							},
						},
					},
					maint = module:GetMaintanceOptions(),
					altUpdate = module:GetAltUpdateOptions(),
				},
			},
			debug = module:GetDebugStuff(),
		},
	}
	return t
end

function module:GetProfileOption(info, opt, ...)
	local o = info.arg
--	self:Debug("GetProfileOpt", o, db.profile[o] )
	return db.profile[o]
end

function module:SetProfileOption(info, val, ...)
	local o = info.arg
--	self:Debug("SetProfileOpt", o, db.profile[o] )
	db.profile[o] = val
end

function module:ShouldShowLDBI(info)
--	self:Debug("ShouldShowLDBI", not db.profile.ldbIcon.hide) 
	return not db.profile.ldbIcon.hide
end

function module:SetShowDBI(info, val)
	db.profile.ldbIcon.hide = not val
--	self:Debug("SetShowDBI, new value", not val)
	if db.profile.ldbIcon.hide then
--		self:Debug("hiding ldb icon")
		LDBI:Hide("GuildCraft_DBI")
	else
--		self:Debug("showing ldb icon")
		LDBI:Show("GuildCraft_DBI")
	end
--	self:Debug("refresh ldb icon")
	LDBI:Refresh("GuildCraft_DBI")
end

--[[
	Maintance Options
		-Purge and Blacklist here
]]--

function module:GetMaintanceOptions()
	local t = { type = "group", name = L["Maintenance Options"], order = 30, inline = true,
		args = {
			purge = { type = "select", name = L["Purge Player"], set = "PurgePlayer", values = "GetPurgeablePlayersList", get = nilFunc, 
				order = 10, --width = "full",
			},
			addblacklist = { type = "input", name = L["Add Player to Blacklist"], set = "AddBlacklistPlayer", get = nilFunc, order = 20,},
			removeBlacklist = { type = "select", name = L["Remove Blacklisted Player"], set = "RemoveBlacklistedPlayer", 
				get = nilFunc, values = "GetBlacklistedPlayers", order = 30,},
		},
	}

	return t
end
do
	local purgeList = {}
	function module:PurgePlayer(info, value)
		self:Debug("Purging Player (Blacklist & Un)", purgeList[value])
		API:AddToBlackList( purgeList[value] )
		API:RemoveBlacklist( purgeList[value] )
		--Blacklist & then remove player
	end

	function module:GetPurgeablePlayersList(info, value)
		for i = 1, #purgeList do purgeList[i] = nil end
		for k,v in pairs(db.factionrealm.allLinks) do
			tinsert(purgeList, k)
		end
		return purgeList
	end
end
function module:AddBlacklistPlayer(info, value)
	API:AddToBlackList( value )
end
function module:RemoveBlacklistedPlayer(info, value)
	API:RemoveBlacklist( value )
end
function module:GetBlacklistedPlayers()
	return db.factionrealm.blacklist
end

function module:GetAltUpdateOptions()
	local t = { type = "group", name = L["Alternate Update"], order = 40, get = nullFunc, set = "PushPullExe", inline = true,
		args = {
			pull_from = { type = "input", name = L["Pull Links From"], get = nullFunc, order = 10,},
			recent_pull = { type = "select", name = L["Pull Links from Quick List"], values = "GetQuickList", },
			push_to = { type = "input", name = L["Push Links To"], get = nullFunc, order = 20, },
			recent_push = { type = "select", name = L["Push Links to Quick List"], values = "GetQuickList", },
--			thrdpull = { },
		}	
	}
	return t
end

function module:PushPullExe(info, value)
--	self:Debug("Command", info[#info], value)
	local method = info[#info]
	if (method == "pull_from") or (method == "recent_pull") then
--		self:Debug(method, value)
		API:RequestLinkFromPlayer(value)
	elseif (method == "push_to") or (method == "recent_push") then
--		self:Debug(method, value)
		API:Alt_SendTSLinksToPlayer(value)
	end
end

function module:GetQuickList(info)
	return db.factionrealm.quickList
end


--[[
	To Do:
		is 3rd party pull really needed?
]]--
------------------------------------------------------
---	General Debuging , real options above this section.
------------------------------------------------------

function module:GetDebugStuff()
	local t = nil
	--[===[@alpha@
	t = { type = "group", name = "Debug Utils", order = -1, get = "GetDebug", set = "SetDebug", handler = module, 
		args = {
			debugMulti = { type = "multiselect", name = "Module Debug Messages", order = 1,
				values = {"Core", "BrokerModule", "ViewerUI", "CommsIO","ChatChannelComms", "DBO", "Options", "TSScan", "TooltipHooks", "phpExporter" },
				},
			debugOff = { type = "execute", name = "All Messages Off", func = "DebugOff", order = 3},
			debugOn = { type = "execute", name = "All Messages On", func = "DebugOn", order = 2 },
			verCheck = { type = "group", name = "Version Checks", order = 10, inline = true,
				args = {
					askVersion = { type = "execute", name = "Refresh Versions", func = "DoVersionCheck", order = 1},
					verDisplay = {type = "multiselect", name = "Versions", order = 2, get = noop, set = "DumpTrades",
						values = "GetVersions", width = "full"},
				},
			},
		},
	}

	--@end-alpha@]===]
	return t
end

--[===[@alpha@
function module:GetDebug(info, value )
	local i = info.option.values[value]
	return db.global.debug[i]

end

function module:SetDebug(info, set, value)
	local i = info.option.values[set]
	db.global.debug[i] = value
end

function module:DebugOn(info)
	local debug = db.global.debug
	for k in pairs(debug) do
		debug[k] = true
	end
end

function module:DebugOff(info)
	local debug = db.global.debug
	for k in pairs(debug) do
		debug[k] = false
	end
end

function module:DoVersionCheck(info)
	API:CallGuildForVersionQuery()
end

local verVals = {}
function module:GetVersions(info)
	wipe(verVals)
	local data = core.db.global.playerVersions
	local list = db.factionrealm.allLinks
	for player, version in pairs(data) do
		if list[player] then
			verVals[player] = player.." -> "..version
		end
	end
	return verVals
end

local template = "|cff33FF66"..L["Guild Craft"]..":|r"
function module:DumpTrades(info, key, value, ...)
	if db.factionrealm.allLinks[key] then
		print(template,"Trade Data for", key)
		local str = ""
		for k,v in pairs(db.factionrealm.allLinks[key]) do
			str = str.." "..v
		end
		print(template, str)
	end
end
--@end-alpha@]===]
