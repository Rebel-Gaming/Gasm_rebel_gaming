--[[
	Broker Plugin basics
]]--
local projectVersion = "v3.5.4-release"
local projectRevision = "41fe740"
if projectVersion:find("project") then
	projectVersion = "git"
	projectRevision = "dev"
end

local AddonParent = LibStub("AceAddon-3.0"):GetAddon("GuildCraft")
local module = AddonParent:NewModule("LDB")
local API = AddonParent.API
local L = LibStub("AceLocale-3.0"):GetLocale("GuildCraft")
local LDBI = LibStub("LibDBIcon-1.0", true)
local BTS = LibStub("Mini-Bable-TradeSkill")
local db

function module:OnInit()
	if not LibStub("LibDataBroker-1.1", true) then
		self:Print("LibDatabroker Not found, you will need to use slash commands")
		self:SetEnabledState(false)
	end
end
function module:OnEnable()
	db = AddonParent.db
--Register LDB Stuff
	self.ldb = LibStub("LibDataBroker-1.1"):NewDataObject("GuildCraft", {
		type = "launcher",
		label = "GuildCraft",
		text = "GuildCraft",
		icon = "Interface\\Icons\\Ability_Repair",
		OnClick = function(frame, msg)
			if msg == "RightButton" then
				if LibStub("AceConfigDialog-3.0").OpenFrames["Guild Craft"] then
					LibStub("AceConfigDialog-3.0"):Close("Guild Craft")
				else
					LibStub("AceConfigDialog-3.0"):Open("Guild Craft")
				end
			else
				local error, msg = pcall(AddonParent.ToggleViewer)
				if not error then
					module:Print("LDB On Click: Cannot Open Browser. Reason: %s", msg)
				end
			end
		end,
		OnTooltipShow = module.OnTooltip,
		hasAce3Options = "Guild Craft",	--Application name

	})
	if LDBI then
		self.ldbiName = "GuildCraft_DBI"
		LDBI:Register(self.ldbiName, self.ldb, db.profile.ldbIcon)

	end
--	self:Debug("Loaded")
end


do	--Basic Tooltip

	local trashTable = {}
	module.trashTable = trashTable
	local dbo = AddonParent:GetModule("DBO", true)
	local OnOffOOG = ("|cff1eff00%s|r, |cff9d9d9d%s|r, |cffff7f3f%s|r"):format(GUILD_ONLINE_LABEL, PLAYER_OFFLINE, L["Not In Guild"])
	function module.OnTooltip(tooltip)
		tooltip = tooltip or GameTooltip
		if not tooltip or not tooltip.AddLine then return end
		tooltip:AddLine(L["Guild Craft"])
		tooltip:AddLine("|cffffff00" .. L["Click|r to toggle the Browser"])
		tooltip:AddLine("|cffffff00" .. L["Right-click|r to open the options menu"])

		if db.profile.extendedtooltip and next(API.profCache) then
			tooltip:AddLine(" ")
--			wipe(trashTable)
			for i = 1, #trashTable do trashTable[i] = nil end
			local gTrade = API:GetGuildWideProfessions()
			for trade, names in pairs(gTrade) do
				if trade ~= BTS("Cooking") then			
					tinsert(trashTable, trade)
				end
			end
			table.sort(trashTable)
			for i,v in pairs(trashTable) do
				tooltip:AddDoubleLine(BTS(v), nil)
				tooltip:AddLine( "     "..API:AlphaSortAddMainCSV( gTrade[v] ), nil, nil, nil, true)
			end
			tooltip:AddLine(".                                                                                                                                       .")
			tooltip:AddLine(OnOffOOG)
			tooltip:Show()
		end
	end
end
