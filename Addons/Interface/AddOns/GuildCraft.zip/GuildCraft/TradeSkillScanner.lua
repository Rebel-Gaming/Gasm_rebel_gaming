--TradeSkillScanner
local projectVersion = "v3.5.4-release"
local projectRevision = "41fe740"
if projectVersion:find("project") then
	projectVersion = "git"
	projectRevision = "dev"
end
--Table functions...
local clearTable
do
	function clearTable(t)
		for k, _ in pairs(t) do
			t[k] = nil
		end
		return t
	end
end
local L = LibStub("AceLocale-3.0"):GetLocale("GuildCraft", true)
local AddonParent = LibStub("AceAddon-3.0"):GetAddon("GuildCraft")
local module = AddonParent:NewModule("TSScan", "AceEvent-3.0")
local API = AddonParent.API



function module:OnEnable()
--	self:ScanTradeSkills()
	
--	self:Debug("Loaded")
end

local tsName = {
	2259,	--Alchemy
	3100,	--Blacksmithing
	2550,	--Cooking
	7411,	--Enchanting
	4036,	--Engineering
	25229,	--Jewelcrafting
	2108,	--Leatherworking
	3908,	--Tailoring
	45357,	--Inscription

}

local links = {}
local function clearNilTS(a) 
	if a == "A" then
		return ""  
	end
end

function module:GetLocalTSLinks()
--	self:Debug("Scaning Trade Skills")
	clearTable(links)
	for i,v in pairs(tsName) do
		local link = select(2, GetSpellLink(v))
--		self:Debug("Link", link)
		local val = link and link:match("Htrade:%d+:%d+:%d+:%x+:(A+)")
		val = val and val:gsub(".", clearNilTS ) == ""
--		self:Debug("Scrubed Link &", val and "BlankLink" or "Valid Link")
		if link and not val then
--			self:Debug("Adding to table")
			tinsert(links, link)
		end
	end
--	self:Debug("End of TSScan", unpack(links) )
	return unpack(links)
end

function GuildCraftAPI:GetLocalTSLinks()
	return module:GetLocalTSLinks()
end


StaticPopupDialogs["GUILD_CRAFT_TSImport"] = {
	text = L["Import %s Tradeskill data?"],
	button1 = YES,
	button2 = NO,
	OnAccept = function(self, ...)
--		module:Debug("Static_Popup_OnAccept", module.name, module.savedLink)
		if module.name and module.savedLink then
--			module:Debug("Sending off to dbo for import")
			API:UpdateLiveDataOutside("TSOpen", module.name, module.savedLink)
		end
		module.name = nil
		module.savedLink = nil
	end,
	OnCancel = function(self, ...)
--		module:Debug("Static_Popup_Cancel, clearing data")
		module.name = nil
		module.savedLink = nil		
	end,
	timeout = 0,
	hideOnEscape = 1,
}

-- GetTradeSkillListLink()
function module:TRADE_SKILL_SHOW(event, ...)
--	self:Debug(event, "IsTradeSkillLinked?", IsTradeSkillLinked())
	if IsTradeSkillLinked() then
--		self:Debug("Trade is linked")
		local _, name =  IsTradeSkillLinked()
		if self.savedLink then
--			self:Debug(name, self.savedLink)
			if AddonParent.online[name] or AddonParent.offline[name] then	--If player is in the guild then
--				self:Debug("Player in guild", AddonParent.online[name] or AddonParent.offline[name])
				if AddonParent.db.profile.AutoImportGuild then	--if auto import is on
--					self:Debug("Importing", name, self.savedLink, "to DBO")
					API:UpdateLiveDataOutside("TSOpen", name, self.savedLink)
					self.savedLink = nil
				else
--					self:Debug(name, "is in guild but auto import is off, dispatch for popup")
					self.name = name
					StaticPopup_Show("GUILD_CRAFT_TSImport", name)
				end
				return
			end
			if AddonParent.db.profile.AutoImportNonGuild then
--				self:Debug(name, "is not in guild, and auto import is on, dispatch to dbo:", self.savedLink)
				API:UpdateLiveDataOutside("TSOpen", name, self.savedLink)
				self.savedLink = nil
			else
--				self:Debug(name, "is not in our guild, and auto import is off, dispatch for popup")
				self.name = name
				StaticPopup_Show("GUILD_CRAFT_TSImport", name)
			end
		end
	end
end

local old_SetItemRef = SetItemRef

function SetItemRef(link, ...)
	if link:find("trade:") then
		module:RegisterEvent("TRADE_SKILL_SHOW")
		module.savedLink = link
	end
	return old_SetItemRef(link, ...)
end


--@debug--
do
local spellID = {
	--Alchemy
	2259,	--Apprentice
	3101,	--Journeyman
	3464,	--Expert
	11611,	--Artisan
	28596,	--Master
	51304,	--Grand Master

	--Blacksmithing
	2018,	--Apprentice
	3100,	--Journeyman
	3538,	--Expert
	9785,	--Artisan
	29844,	--Master
	51300,	--Grand Master

	--Cooking
	2550,	--Apprentice
	3102,	--Journeyman
	3413,	--Expert
	18260,	--Artisan
	33359,	--Master
	51296,	--Grand Master

	--Enchanting
	7411,	--Apprentice
	7412,	--Journeyman
	7413,	--Expert
	13920,	--Artisan
	28029,	--Master
	51313,	--Grand Master

	--Engineering
	4036,	--Apprentice
	4037,	--Journeyman
	4038,	--Expert
	12656,	--Artisan
	30350,	--Master
	51306,	--Grand Master

	--Inscription
	45357,	--Apprentice
	45358,	--Journeyman
	45359,	--Expert
	45360,	--Artisan
	45361,	--Master
	45363,	--Grand Master

	--Jewelcrafting
	25229,	--Apprentice
	25230,	--Journeyman
	28894,	--Expert
	28895,	--Artisan
	28897,	--Master
	51311,	--Grand Master

	--Leatherworking
	2108,	--Apprentice
	3104,	--Journeyman
	3811,	--Expert
	10662,	--Artisan
	32549,	--Master
	51302,	--Grand Master

	--Tailoring
	3908,	--Apprentice
	3909,	--Journeyman
	3910,	--Expert
	12180,	--Artisan
	26790,	--Master
	51309,	--Grand Master
}

	function module:TestLinks()
		local test = {}
		for i = 1, #spellID do
			local spell, link = GetSpellLink(spellID[i])
			local val = link and link:match("Htrade:%d+:%d+:%d+:%x+:(A+)")
			val = val and val:gsub(".", clearNilTS) == ""
			local sName, sRank = GetSpellInfo(spellID[i])
			self:Debug("Testing", sName, sRank, " // Scrubed Link =", val and "Blank" or "Valid")
		end
	end
end
--@end-debug@--
