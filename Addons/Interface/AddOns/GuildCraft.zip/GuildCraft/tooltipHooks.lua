--Tooltip Hooks
local projectVersion = "v3.5.4-release"
local projectRevision = "41fe740"
if projectVersion:find("project") then
	projectVersion = "git"
	projectRevision = "dev"
end


local AddonParent = LibStub("AceAddon-3.0"):GetAddon("GuildCraft")
local module = AddonParent:NewModule("TooltipHooks")

local L = LibStub("AceLocale-3.0"):GetLocale("GuildCraft")
local BTS = LibStub("Mini-Bable-TradeSkill")
local db
local API = AddonParent.API

function module:OnEnable()
	db = AddonParent.db
	self:HookTooltip(ItemRefTooltip)
	self:HookTooltip(GameTooltip)
--	self:Debug("Enabled")
end


local hookedTips = {}
module.hookedTips = hookedTips

local function OnTooltipSetSpell_Hook(tooltip)
--	module:Debug("Proccessing", tooltip.GetName and tooltip:GetName() ~= "" and tooltip:GetName() or tostring(tooltip), "  Hook")
	if not db.profile.enableTooltipHooks then
--		module:Debug("Tooltip Disabled")
		return
	end
	local name, _, id = tooltip:GetSpell()
	local tName = (_G[tooltip:GetName().."TextLeft1"]:GetText() or "" ):match("^([^:]+)")	--this provides the localized trade name,
	tName = BTS:ReverseTranslate(tName)	--reverse translate it
	if not tName then
		--[===[@debug@
		tooltip:AddLine(" ")
		tooltip:AddLine("Spell ID: "..id)
		--@end-debug@]===]
--		module:Debug("No professin name on tooltip line one left")
		return
	end

	local data = API.profCache[tName] and API.profCache[tName][id]		--the Reason we don't use the API here is because Init the db of links is very heavy proccess.
	if data then
		tooltip:AddLine(" ")
		tooltip:AddLine(L["Can be crafted by:"])
		tooltip:AddLine( "     "..API:AlphaSortCSV( data ), nil, nil, nil, true)
	elseif not next(API.profCache) then
		tooltip:AddLine(" ")
		tooltip:AddLine(L["Open Guild Craft Viewer to see who can make this."], nil, nil,nil, true)
	end
	--[===[@debug@
	tooltip:AddLine(" ")
	tooltip:AddLine("Spell ID: "..id)
	--@end-debug@]===]
end

function module:HookTooltip(tooltip)
	local displayName = tooltip.GetName and tooltip:GetName() ~= "" and tooltip:GetName() or tostring(tooltip)
--	self:Debug("hooking tip", displayName)
	if (not tooltip.GetObjectType) or ( tooltip:GetObjectType() ~= "GameTooltip" ) then
--		self:Debug("Cannot hook a frame that is not a game tooltip", displayName)
		return
	end
	
	if hookedTips[tooltip] then
--		self:Debug("allready hooked:", displayName)
		return
	end
	tooltip:HookScript("OnTooltipSetSpell", OnTooltipSetSpell_Hook)
end
