local projectVersion = "v3.5.4-release"
local projectRevision = "41fe740"
if projectVersion:find("project") then
	projectVersion = "git"
	projectRevision = "dev"
end

--[[  HOUSEKEEPING  ]]--
local AddonParent = LibStub("AceAddon-3.0"):GetAddon("GuildCraft")
local module = AddonParent:NewModule("CommsIO", "AceComm-3.0", "AceSerializer-3.0")

local self_player = UnitName("player")
local Addon_Prefix = "GuildCraft35"
module.cbh = LibStub("CallbackHandler-1.0"):New(module, "RegCommsEvent", "UnRegCommsEvent")

function module:OnEnable()
	self:RegisterComm(Addon_Prefix)
	self:Debug("Loaded")
end

local function DispatchComms(sender, result, command, ...)
	if not result then return end
	module:Debug("Dispatching Command:", command, "From:", sender)
	module.cbh:Fire(command, sender, ...)
end
module.DispatchComms = DispatchComms

function module:OnCommReceived(prefix, message, distribution, sender)
	if prefix ~= Addon_Prefix then return end
	DispatchComms(sender, self:Deserialize(message))
end

local function Cerial(...)
	return module:Serialize(...)
end

function module:SendToGuild(...)
	if IsInGuild() then
		module:Debug("Sending To Guild:", ... )
		module:SendCommMessage(Addon_Prefix, Cerial(...), "GUILD", nil, "BULK")
	else
		self:Debug("Send to Guild: Not In Guild; whisper to self")
		module:SendWhisper(self_player, ...)
	end
end

function module:SendWhisper(player, ...)
	module:Debug("Sending Whisper to:", player, "Command:", ... )
	module:SendCommMessage(Addon_Prefix, Cerial(...), "WHISPER", player, "BULK")
end

local embeds = {
	"SendToGuild",
	"SendWhisper",
	"RegCommsEvent", 
	"UnRegCommsEvent"
}

function module:SoftEmbed(target)
	self:Debug("Embeding into:", target.GetName and target:GetName() or target)
	for i,v in ipairs(embeds) do
		target[v] = module[v]
	end
end
