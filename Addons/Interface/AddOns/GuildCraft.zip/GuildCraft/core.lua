--[[

Core file for Guild Craft, handles the basics

Copyright (c) 2007 by Orionshock

	see included "LICENSE.txt" file for details on copyright.

]]--

-----------------------------
--- DB Structure..
-----------------------------
local masterDB_Defaults = {
	char = {

	},
	profile = {
		shareDataToGuild = true,	-- share your stuff to guild
		AutoImportGuild = true,		--Auto Import guild members when vieing tradeskills
		AutoImportNonGuild = false,	--Auto Import from Non guild players when vieing tradeskills
		enableTooltipHooks = false,	--Crafters Tooltip Hook
		extendedtooltip = false,	--Extended LDB Tooltip
		ldbIcon = {
			hide = true
		},
	},
	factionrealm = {
		allLinks = {
			--["playName"] = {{eName] = "link"},
		},
		quickList = {
			--[===[@alpha@
			[ (UnitName("player")) ] = UnitName('player'),
			--@end-alpha@]===]
		},
		blacklist = {
			--[===[@alpha@
			["TriangleMan"] = "TriangleMan",
			--@end-alpha@]===]
		},
	},
	global = {
		debug = {
			Core = false,
			BrokerModule = false,
			ViewerUI = false,
			CommsIO = false,
			ChatChannelComms = false,
			DBO = false,
			Options = false,
			TSScan = false,
			TooltipHooks = false,
			phpExporter = false,
			["Non-Guild-Comms"] = false,
		},
		playerVersions = {
		},
	},
}

--[[ -----------------------------
Core:
	Handles Core Addon & Slash Commands.
	Handles AceDB Object.
	Handles Guild Roster.
	Handels Debug and Print Functions.
 ]] -----------------------------

local projectVersion = "v3.5.4-release"
local projectRevision = "41fe740"
if projectVersion:find("project") then
	projectVersion = "git"
	projectRevision = "dev"
end

GuildCraft = LibStub("AceAddon-3.0"):NewAddon("GuildCraft", "AceConsole-3.0", "AceEvent-3.0")
GuildCraftAPI = {}	--for intra module interactions n' such.
--GuildCraftAPI.core = GuildCraft
GuildCraft.API = GuildCraftAPI

GuildCraft.Version = projectRevision
GuildCraft.distro = projectVersion

local LibAlts = LibStub("LibAlts-1.0", true)


local core = GuildCraft
local L = LibStub("AceLocale-3.0"):GetLocale("GuildCraft")

function core:OnEnable()
	self.db = LibStub("AceDB-3.0"):New("GuildCraft35" , masterDB_Defaults )
	LibAlts = LibStub("LibAlts-1.0", true)
	--Slash commands
	self:RegisterChatCommand("guildcraft", function()
		LibStub("AceConfigDialog-3.0"):Open("Guild Craft")
	end )

	self:RegisterChatCommand("gcb", self.ToggleViewer )
	self:RegisterChatCommand("resetltldata", function()
		LIB_TRADE_LINKS_PATCH_DATA = {}
		ReloadUI()
	end )

	--Call guild roster incase
	GuildRoster()
	self:Debug("Loaded")
end


do
	local viewer
	function core.ToggleViewer()
		if not viewer then
			viewer = core:GetModule("ViewerUI", true)
		end

		if viewer then
			viewer:ToggleViewer()
		else
			EnableAddOn("GuildCraft_Viewer")
			local loaded, reason = LoadAddOn("GuildCraft_Viewer")
			if not loaded then
				core:Print(L["Cannot load browser UI reason: %s"], reason)
			else
				viewer = core:GetModule("ViewerUI", true)
				if viewer then
					viewer:ToggleViewer()
				elseif not viewer then
					core:Print("Browser Didn't Load, Check Error Log")
				end
			end
		end
	end
end

-----------------------------
--- Module Prototype
--	Print( [regex], ...)	--Used for Important things
--	Debug( [regex], ...)	--Used for Unimportant Debug stuff
-----------------------------
do
	local prefix = "|cff33FF66"..L["Guild Craft"]..":|r "
	local proto = {}

	function proto.Print(self, match, ...)
		if string.find(match, "%%") then
			print(prefix..string.join(", ", match:format(...) ) )
		else
			print(prefix..string.join(", ", tostringall(match, ...) ) )
		end
	end

	function proto.Debug(self, ...)
		self = self.GetName and self:GetName() or tostring(self)
		if self == "GuildCraft" then self = "Core" end
		local str = string.join(", ", tostringall(...))
		str = str:gsub("([:=%[%]]),", "%1")

		if (not GuildCraft.db ) or (not GuildCraft.db.global.debug[self]) then
			return str
		end

		print("|cff33FF66GuildCraft-Debug-"..self..":|r "..str)
		return str
	end
	core.Debug = proto.Debug
	core.Print = proto.Print
	core:SetDefaultModulePrototype(proto)
end

-----------------------------
--- Guild Roster Scanner
-----------------------------
do
local online, offline = {},{}
core.online, core.offline = online, offline

	local delay, interval = 50, 60
	local function onUpdateFunc(frame, elapsed)
		delay = delay + elapsed
		if delay > interval then
			if IsInGuild() then
				for i = 1, GetNumGuildMembers(true) do
					local name, _, _, _, _, _, _, _, oline = GetGuildRosterInfo(i);
					if name then
						online[name] = oline and true or nil
						offline[name] = not oline and true or nil
					end
				end
			end
			if not core.hasUpdateRoster then
				core.hasUpdateRoster = true
				core:Debug("GuildCraft_FirstRosterUpdate")
--				core:SendMessage("GuildCraft_FirstRosterUpdate")
			end
			delay = 0
		end

	end
	local frame = CreateFrame("Frame")
	frame:SetScript("OnUpdate", onUpdateFunc)
	core.frame = frame
	frame:Show()
end

do
	local online, offline = core.online, core.offline
	local function color(name)
		if type(name) ~= "string" or name == "" then return v end
		if online[name] then
			return ("|cff1eff00%s|r"):format(name)
		elseif offline[name] then
			return ("|cff9d9d9d%s|r"):format(name)
		else
			return ("|cffff7f3f%s|r"):format(name)
		end
	end

	local t = {}
	local tinsert, tsort, tconcat, select, ssplit = table.insert, table.sort, table.concat, select, string.split
	local strUpper = string.upper

	function core.API:AlphaSortCSV(...)
		local first = tostring(select(1, ...))
		if first:find(",") then	--this is one list in first arg.
			return core.API:AlphaSortCSV(ssplit(",", first))
		end
		for i = 1, #t do t[i] = nil end
		for i = 1, select("#", ...) do
			local e = (select(i, ...) or ""):trim()
			tinsert(t,color(e))
		end
		tsort(t)
		return tconcat(t, ", "):trim()
	end

	function core.API:AlphaSortAddMainCSV(...)
		local first = tostring(select(1, ...))
		if first:find(",") then	--this is one list in first arg.
			return core.API:AlphaSortAddMainCSV(ssplit(",", first))
		end
		for i = 1, #t do t[i] = nil end
		for i = 1, select("#", ...) do
			local e = tostring(select(i, ...)):trim()
			tinsert(t, e)
		end
		if LibAlts then
			for i,v in ipairs(t) do
				local m = LibAlts:GetMain(v)
				m = m and m:gsub("^([\192-\255]?%a?[\128-\191]*)", strUpper)
				t[i] = m and ("%s (%s)"):format( color(v), color(m) ) or color(v)
			end
		else
			for i,v in ipairs(t) do
				t[i] = color(v)
			end
		end
		tsort(t)	--sort here, due to the color codes naturally sorting by online/offline/non-guild
		return tconcat(t, ", ")
	end
end
