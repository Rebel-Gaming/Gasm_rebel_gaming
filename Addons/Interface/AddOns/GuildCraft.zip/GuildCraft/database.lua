local projectVersion = "v3.5.4-release"
local projectRevision = "41fe740"
if projectVersion:find("project") then
	projectVersion = "git"
	projectRevision = "dev"
end


local AddonParent = LibStub("AceAddon-3.0"):GetAddon("GuildCraft")
local module = AddonParent:NewModule("DBO")
local API = AddonParent.API
local player_name = UnitName("player")
local db

local strUpper = string.upper

local BTS = LibStub("Mini-Bable-TradeSkill")
local LTL = LibStub("TradeLinkDecoder-1.0", true) or LibStub("LibTradeLinks-1.0")


function module:OnEnable()

	db = AddonParent.db

	AddonParent:GetModule("CommsIO"):SoftEmbed(self)	--Soft Embed Comms Module to this one.

--Comms Stuff
	--Versioning Crap
	self:RegCommsEvent("SendVersion")
	self:RegCommsEvent("RecordVersion")

	--Std sharing tradeskill links management
	self:RegCommsEvent("SendTSLinks")
	self:RegCommsEvent("UpdateLiveData")

	--Alternate Update
	self:RegCommsEvent("Alt_SendTSLinksToPlayer")
	self:RegCommsEvent("Alt_UpdateLiveData")


--Init Section
	self:CallVersionQuery()
	self:CallForUpdate()
	self:Debug("Loaded")
end

--[[
	--Comms Embeds = {"SendToGuild", "SendWhisper","RegCommsEvent","UnRegCommsEvent"}
		--SendToGuild Handles the IsInGuild() check

	While we never really use this, first thing to take care of is the Version Check
	-Step 1: Broadcast Version Quiry
	-Step 2: Send Our Version
	-Step 3: Record other peoples response to it.

]]--


function module:CallVersionQuery()	--Step 1
	self:Debug("CallVersionQuery to guild")
	self:SendToGuild("SendVersion")
end
function API:CallGuildForVersionQuery()
	return module:CallVersionQuery()
end

function module:SendVersion(event, sender, ...)		--Step 2, we talk to ourselves.
	self:Debug("Sending Versions to guild. Requested by", sender)
	self:SendToGuild("RecordVersion", projectVersion, projectRevision )	--Tag, hash
end

function module:RecordVersion(event, sender, ver, rev)
	db.global.playerVersions[sender] = ver.."-"..rev
	self:Debug("Received Ver from:", sender, db.global.playerVersions[sender])
end


--[[
	Generic Player Update model.
	Next we handel sending out our tradeskills and receiving them from others.

	Step 1: Ask Guild for Links
	Step 2: receve command from 1 & send our links out
	Step 3: compare what's on file w/ what's received & update if different.
		--we don't bother actually checking if anythign has really changed.
		--this is because stuff changes patch to patch and the lcoal < forign check dosn't work well w/o decoding it.
		-- we don't care that much..
]]--



function module:CallForUpdate()
	self:Debug("CallForUpdate to Guild")
	self:SendToGuild("SendTSLinks")
end

function module:SendTSLinks(event, sender, ...)
	if db.profile.shareDataToGuild then
		self:Debug("Sending to Guild our links spam, requested by:", sender)
		self:SendToGuild("UpdateLiveData", API:GetLocalTSLinks() )
	end
end
--
local function disasembleLink(link)
	local id = link:match("trade:(%d+):")

	if not id then return end

	local name = BTS:ReverseTranslate( GetSpellInfo(id) )	--Get the English name from the local name

	if not name then return end

	return name, id
end


local cache_is_ready = false

function module:UpdateLiveData(event, sender, ...)
	self:Debug( (event == "UpdateLiveData" and "UpdateLiveData") or "ULD-"..event, sender, ...)
	if db.factionrealm.blacklist[sender] then
--		self:Debug("player", sender, "is blacklisted, don't udpate")
		return
	end
	local t = db.factionrealm.allLinks[sender] or {}		--Get table or make new one
	local changed = false
	local profStr = ""
	for i = 1, select("#", ...) do					--itterate though ...
		local link = select(i, ...)
		local profession = disasembleLink(link)			--translate link to english our "non-localized"
--		self:Debug("working with link", profession, link)
		if not profession then					--invalid link
--			self:Debug(event, "received invalid link?", link, "from", sender)
			break
		end
		profStr = profStr..profession
		if t[profession] and t[profession] ~= link then		--Lazy upgrade, if what we have dosn't match what's sent then update.
			self:Debug("data on file, not matching, updating. set cache_is_ready = false")
			cache_is_ready = false
			changed = true
			t[profession] = link
		elseif not t[profession] then
			self:Debug("Data not on file, adding. cache_is_ready = false")
			changed = true
			cache_is_ready = false
			t[profession] = link
		else
			self:Debug("Cache Matching, doing nothing really")
		end
	end
	for k in pairs(t) do
		if (not profStr:find(k)) and (event ~= "TSOpen") then	--Flag!
--			self:Debug("professions changed for", sender, "Clear and readd")
			wipe(t)
			return self:UpdateLiveData("ReloadPlayer", sender, ...)
		end
	end
	db.factionrealm.allLinks[sender] = t
--	self:InitCache()
	if changed then
		self:Print("Updated %s's Tradeskill's", sender)
	end
end
function API:UpdateLiveDataOutside(event,sender, ...)
	module:UpdateLiveData(event, sender, ...)
end

local cache_by_profession, cache_guild = {}, {}
API.profCache = cache_by_profession
API.guild = cache_guild

local function addByLinkData(name, profession, link)
--	module:Debug("Adding by Link Data", name, profession, link)
	local _, spellList = pcall(LTL.Decode, LTL, link, true, true)
	if spellList and type(spellList) == "table" and next(spellList) then
--		module:Debug("Pairing Spell List")
		local cache = cache_by_profession[profession] or {}
		for id in pairs(spellList) do
--			module:Debug("Scan:", GetSpellInfo(id), "in")
			if cache[id] and  (not cache[id]:find(name)) then
				cache[id] = cache[id]..","..name
--				module:Debug("Adding to ^^", cache[id])
			else
				cache[id] = name
--				module:Debug("First Of ^^", cache[id])
			end
		end
		cache_by_profession[profession] = cache
		if cache_guild[profession] and (not cache_guild[profession]:find(name)) then
			cache_guild[profession] = cache_guild[profession]..","..name
--			module:Debug("Adding to guild consolidated list", cache_guild[profession])
		else
			cache_guild[profession] = name
--			module:Debug("First of Guild List", cache_guild[profession])
		end
	else
--		module:Debug("Link didn't decode??\n", spellList)
		db.factionrealm.allLinks[name][profession] = nil
	end
end


function module:InitCache(clearCacheFirst)
--	self:Debug("InitCache, clearFirst=", clearCahceFirst, "cache_is_ready=", cache_is_ready)
	if clearCacheFirst then
		wipe(cache_by_profession)
		wipe(cache_guild)
	end
--	self:Debug("Init Cache, this takes a while")
	for player, professionData in pairs(db.factionrealm.allLinks) do	--
--		self:Debug("Inputing in", player, "professions")
		for profession_name, link in pairs(professionData) do
			addByLinkData(player, profession_name, link)
		end
	end
	cache_is_ready = true
--	self:Debug("cache_is_ready", cache_is_ready)
end

function API:InitCache(clear)
	module:InitCache(clear)
end

--[[
	A One to One push or pull in and out of guild:
		Step 1: Ask for Link
		step 2: send link
		step 3: proccess link though normal channels
]]--

function module:RequestLinkFromPlayer(source)
	if (type(source) ~= "string") or tostring(source):trim() == "" then
		self:Debug("RequestLinkFromPlayer, invalid player arg. Got", source)
		return
	end
	source = source:trim():gsub("^([\192-\255]?%a?[\128-\191]*)", strUpper)
	self:Debug("Requesting Link from", source)
	self:SendWhisper(source, "Alt_SendTSLinksToPlayer")
end

function module:Alt_SendTSLinksToPlayer(event, sender, ...)
	if (type(sender) ~= "string") or tostring(sender):trim() == "" then
		self:Debug("Alt_SendTSLinksToPlayer, invalid sender arg. Got", sender)
		return
	end
	if db.profile.shareDataToGuild then
		sender = sender:trim():gsub("^([\192-\255]?%a?[\128-\191]*)", strUpper)
		self:Debug(event, "sending our link spam to:", sender)
		self:SendWhisper(sender, "Alt_UpdateLiveData", API:GetLocalTSLinks() )	--slight hijack
	end
end

function module:Alt_UpdateLiveData(event, source, ...)
	self:Debug("Recived links from", source, "via alt update", ...)
	db.factionrealm.quickList[source] = source
	self:UpdateLiveData(event, source, ...)
end


function module:AddToBlackList(player)
	if (type(player) ~= "string") or (tostring(player):trim() == "") then
--		self:Debug("Add Blacklist -- Invalid Player Arg. Got", player)
		return false	--if you don't pass a string, then this fails.
	end
	player = player:trim():gsub("^([\192-\255]?%a?[\128-\191]*)", strUpper)	--Fix name
--	self:Debug("Blacklisting Player", player)
	db.factionrealm.blacklist[player] = player	--Add to blacklist
	db.factionrealm.allLinks[player] = nil		--remove data from db
	if cache_is_ready then				--if the db is online, then reinit it.
		self:InitCache(true)
	end
	return true
end

function module:RemoveBlacklist(player)
	if type(player) ~= "string" then 
--		self:Debug("Remove Blacklist -- Invalid Player Arg. Got", player)
		return false	--if you don't pass a string, then this fails.
	end
	player = player:trim():gsub("^([\192-\255]?%a?[\128-\191]*)", strUpper)	--Fix name
	db.factionrealm.blacklist[player] = nil	--Add to blacklist
--	self:Debug("Removed", player, "from blacklist")
	return true
end

--[[------------------------------------------------
---	Public API

------------------------------------------------]]--

--[[
	API: CallGuildForProfessionUpdate()
		used to initate a synch
]]--
function API:CallGuildForProfessionUpdate()
	return module:CallForUpdate()
end

--[[
	API:Get Guild Wide Professions()
		simple API to get the current list of what is in the index
		and who can make it.
		returns { ["profession Name"] = "List,Of,Crafters" }
]]--

function module:GetGuildWideProfessions()
	if not cache_is_ready then
		module:InitCache()
	end
	return cache_guild		--You should not be modifiying this table, other wise u'll get CopyTable(cache_guild) instead.
end

function API:GetGuildWideProfessions()
	return module:GetGuildWideProfessions()
end
-----------
--[[
	API: Get Profession Table (profession)
		used to get the list of spell id to crafters list
		returns { ["spellID"] = "List,Of,Crafters", }
]]--

function module:GetProfessionTable(prof)
	if not cache_is_ready then
		module:InitCache()
	end

	local r = cache_by_profession[prof] or cache_by_profession[ BTS:ReverseTranslate(prof) ]
		-- if the english name isn't there try the localized one
	if r then
		return r
	end
end

function API:GetProfessionTable(...)
	return module:GetProfessionTable(...)
end

---------------
--[[
	API: Get Crafters By Specific ( profession, id )
	This is for when you already know the profession and ID you can get a list of people
		that can make it. Don't honestly see this being used in Guild craft, but might be nice for
		an AH mod that shows you who can make stuff instead of wasting gold on the AH
]]--
function module:GetCraftersBySpecific(prof, id)
	local t = cache_by_profession[prof]
	if t then
		if t[id] then
			return t[id]
		end
	end
end
function API:GetCraftersBySpecific(...)
	return module:GetCraftersBySpecific(...)
end

--[[
	API:RequestLinkFromPlayer(player)
	--Internal API, used to request link spam from another user

	API: Alt_SendTSLinkToPlayer(player)
	--Internal API, used to blindly send someone our links

]]--
function API:RequestLinkFromPlayer(...)
	return module:RequestLinkFromPlayer(...)
end

function API:Alt_SendTSLinksToPlayer(...)
	--We fake the event here because this function is also used to receive the data from someone elses request.
	return module:Alt_SendTSLinksToPlayer("InsidePush", ...)
end

--[[
	API: AddToBlackList(player)
		-used to not only remove someone from the db but never update again
	API: RemoveBlacklist(player)
		-used to remove somoene on the blacklist
]]--
function API:AddToBlackList(...)
	return module:AddToBlackList(...)
end

function API:RemoveBlacklist(...)
	return module:RemoveBlacklist(...)
end

