﻿--[[ Translators Please don't touch this file, Unless you absolutely have to ....
	--Why this file Looks weird:
		in various locales it was discovored that blizzard used different names for each rank with in a tradeskill.
		while in english this means very little (we're unimaginitve you could say) this causes LOTS of problems between locales for some reason.
		This was suposedly fixed in 3.0.8a, but will remain for sanity sake.

]]--

local MAJOR, MINOR = "Mini-Bable-TradeSkill", tonumber("15")
local L = LibStub:NewLibrary(MAJOR, MINOR)
if not L then return end

local function GSI(val)
	return (GetSpellInfo(tonumber(val or 0 )))
end

local RL = {
	--['localized name'] = 'english name',
	}
L.RL = RL

local M = {
	--['english name'] = 'localized name',
	}
L.M = M

M["Alchemy"] = GSI(51304)
RL[GSI(2259)] = "Alchemy"		--Apprentice
RL[GSI(3101)] = "Alchemy"		--Journeyman
RL[GSI(3464)] = "Alchemy"		--Expert
RL[GSI(11611)] = "Alchemy"		--Artisan
RL[GSI(28596)] = "Alchemy"		--Master
RL[GSI(51304)] = "Alchemy"		--Grand Master
RL[GSI(28677)] = "Alchemy"		--Elixir Master
RL[GSI(28675)] = "Alchemy"		--Potion Master
RL[GSI(28672)] = "Alchemy"		--Transmutation Master

M["Blacksmithing"] = GSI(51300)
RL[GSI(2018)] = "Blacksmithing"		--Apprentice
RL[GSI(3100)] = "Blacksmithing"		--Journeyman
RL[GSI(3538)] = "Blacksmithing"		--Expert
RL[GSI(9785)] = "Blacksmithing"		--Artisan
RL[GSI(29844)] = "Blacksmithing"	--Master
RL[GSI(51300)] = "Blacksmithing"	--Grand Master
RL[GSI(9788)] = "Blacksmithing"		--Armorsmith
RL[GSI(9787)] = "Blacksmithing"		--Weaponsmith
RL[GSI(17041)] = "Blacksmithing"	--Master Axesmith
RL[GSI(17040)] = "Blacksmithing"	--Master Hammersmith
RL[GSI(17039)] = "Blacksmithing"	--Master Swordsmith

M["Cooking"] = GSI(51296)
RL[GSI(2550)] = "Cooking"		--Apprentice
RL[GSI(3102)] = "Cooking"		--Journeyman
RL[GSI(3413)] = "Cooking"		--Expert
RL[GSI(18260)] = "Cooking"		--Artisan
RL[GSI(33359)] = "Cooking"		--Master
RL[GSI(51296)] = "Cooking"		--Grand Master

M["Enchanting"] = GSI(51313)
RL[GSI(7411)] = "Enchanting"		--Apprentice
RL[GSI(7412)] = "Enchanting"		--Journeyman
RL[GSI(7413)] = "Enchanting"		--Expert
RL[GSI(13920)] = "Enchanting"		--Artisan
RL[GSI(28029)] = "Enchanting"		--Master
RL[GSI(51313)] = "Enchanting"		--Grand Master

M["Engineering"] = GSI(51306)
RL[GSI(4036)] = "Engineering"		--Apprentice
RL[GSI(4037)] = "Engineering"		--Journeyman
RL[GSI(4038)] = "Engineering"		--Expert
RL[GSI(12656)] = "Engineering"		--Artisan
RL[GSI(30350)] = "Engineering"		--Master
RL[GSI(51306)] = "Engineering"		--Grand Master
RL[GSI(20219)] = "Engineering"		--Gnomish Engineer
RL[GSI(20222)] = "Engineering"		--Goblin Engineer

M["Inscription"] = GSI(45363)
RL[GSI(45357)] = "Inscription"		--Apprentice
RL[GSI(45358)] = "Inscription"		--Journeyman
RL[GSI(45359)] = "Inscription"		--Expert
RL[GSI(45360)] = "Inscription"		--Artisan
RL[GSI(45361)] = "Inscription"		--Master
RL[GSI(45363)] = "Inscription"		--Grand Master

M["Jewelcrafting"] = GSI(51311)
RL[GSI(25229)] = "Jewelcrafting"	--Apprentice
RL[GSI(25230)] = "Jewelcrafting"	--Journeyman
RL[GSI(28894)] = "Jewelcrafting"	--Expert
RL[GSI(28895)] = "Jewelcrafting"	--Artisan
RL[GSI(28897)] = "Jewelcrafting"	--Master
RL[GSI(51311)] = "Jewelcrafting"	--Grand Master

M["Leatherworking"] = GSI(51302)
RL[GSI(2108)] = "Leatherworking"	--Apprentice
RL[GSI(3104)] = "Leatherworking"	--Journeyman
RL[GSI(3811)] = "Leatherworking"	--Expert
RL[GSI(10662)] = "Leatherworking"	--Artisan
RL[GSI(32549)] = "Leatherworking"	--Master
RL[GSI(51302)] = "Leatherworking"	--Grand Master
RL[GSI(10656)] = "Leatherworking"	--Dragonscale Leatherworking
RL[GSI(10658)] = "Leatherworking"	--Elemental Leatherworking
RL[GSI(10660)] = "Leatherworking"	--Tribal Leatherworking

M["Tailoring"] = GSI(51309)
RL[GSI(3908)] = "Tailoring"		--Apprentice
RL[GSI(3909)] = "Tailoring"		--Journeyman
RL[GSI(3910)] = "Tailoring"		--Expert
RL[GSI(12180)] = "Tailoring"		--Artisan
RL[GSI(26790)] = "Tailoring"		--Master
RL[GSI(51309)] = "Tailoring"		--Grand Master
RL[GSI(26798)] = "Tailoring"		--Mooncloth Tailoring
RL[GSI(26801)] = "Tailoring"		--Shadoweave Tailoring
RL[GSI(26797)] = "Tailoring"		--Spellfire Tailoring

function L:ReverseTranslate(var)	--Provide Localized String for an English one
	--assert(var)
	if RL[var] then
		return RL[var]
	end
	--[===[@alpha@
	if not M[k] then
--		print("|cff33FF66GuildCraft-BTSMini:|r No Reverse Translation for", k)
	end
	--@end-alpha@]===]
end

function L.Translate(self, k)		--Provide English String for a Localized String
	if M[k] then
		return M[k]
	end
	--[===[@alpha@
	if not M[k] then
		print("|cff33FF66GuildCraft-BTSMini:|r No Translation for", k)
	end
	--@end-alpha@]===]
end

L = setmetatable(L, {__call = L.Translate })
--[===[@debug@
do

	function L:DumpLocale()
		local count = 0
		print("|cffffcc00-----Dumping Locale 'M' (Main Table)-----|r")
		for k,v in pairs(M) do
			count = count + 1
			print("|cff33ff99E:|r",k," |cff33ff99L:|r",v)
		end
		print("|cffffcc00----Count = |r", count,"|cffffcc00----|r")
		print("|cffffcc00----There should be 9 entrys here----|r")
		print("|cffffcc00----Dumping Reverse Translation Table----|r")
		count = 0
		for k,v in pairs(RL) do
			count = count + 1
			print("|cff33ff99L:|R", k, " |cff33ff99E:|r",v, " |cff33ff99M:|r", M[v])
		end
		print("|cffffcc00----Count =|r", count, "|cffffcc00----|r")
		print("|cffffcc00----There should be 25 entrys here----|r")
		print("|cffffcc00-----That is all-----|r")
	end
end
--/dump LibStub("Mini-Bable-TradeSkill"):DumpLocale()
--@end-debug@]===]
