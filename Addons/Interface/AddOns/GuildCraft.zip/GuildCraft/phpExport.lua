--phpForum Export Module
local projectVersion = "v3.5.4-release"
local projectRevision = "@project-revision@"
local fileRevision = "@file-revision@"

local AddonParent = LibStub("AceAddon-3.0"):GetAddon("GuildCraft")
local module = AddonParent:NewModule("phpExporter")
module.rev = fileRevision
local L = LibStub("AceLocale-3.0"):GetLocale("GuildCraft")
local BTS = LibStub("Mini-Bable-TradeSkill")
local AddonParent_DB, DBO, cache
local exportFunc = {}
module.exportFunc = exportFunc
module.exportQue = {}

function module:OnInitialize()
	AddonParent_DB = AddonParent.db
	DBO = AddonParent:GetModule("DBO", true)
	if not DBO then
		error("No DBO for phpExporter")
		return
	end
	cache = AddonParent.Cache
end


function module:OnEnable()
	self:Debug("Enable")
end

--AceOptions

function module:GetAceOptions()
	local t = {
		name = "phpExporter", handler = module, order = 70, type = "group",
		args = {
			helpText = { type = "description", name = L["exportHelpText"], order = 10},
			breakInText = { type = "header", name = "", order = 15},
			exportAllHelp = { type = "description", name = L["exportAll_Help"], order = 20},
			exportAll = { name = "Export All", type = "execute", func = "ExportAll", order = 30},
			break2 = {type = "header", name = "", order = 50},
			dropDown = {type = "select", name = "Segement", get = "GetSegement", set = "SetSegementList", order = 51, values = "GetSegmentList" },
			exportBox = { type = "input", multiline = 13, name = "Segment", get = "ExportBoxGet", set = function() end, order = 52, width = "full",  },
		},
	}

	if AddonParent.blizz_Frame:IsShown() then
		t.hidden = true
	end
	return t
end
module.currentSegment = 1

function module:GetSegement(info)
--	print("GetSegmentInfo", self.currentSegment)
	return self.currentSegment
end

local segmentList = {}

function module:GetSegmentList(info)
--	print("GetSegmentList")
	wipe(segmentList)
	for i = 1, #module.outCache do
		tinsert(segmentList, ("Segment %d"):format(i) )
	end
--	print("Filled segment list with", #module.outCache, "Entries")
	return segmentList
end
function module:SetSegementList(info, value)
--	print("SetSegmentList, current Value:", self.currentSegment, ", new Value:", value)
	self.currentSegment = value
end

function module:ExportBoxGet(info)
--	print("ExportBoxGet", self.currentSegment )
	return self.outCache[ self.currentSegment ] or ""
end

--[[
	Format Styles...

**		All Data & or Guild::
	[b]Profession[/b]
	[list]
	[*][item]ItemName[/item] -- Player1, Player2, ..
	[*][item]ItemName[/item] -- Player1, Player2, ..
	[*][item]ItemName[/item] -- Player1, Player2, ..
	[/list]

	[b]Profession[/b]
	[list]
	[*][item]ItemName[/item] -- Player1, Player2, ..
	[*][item]ItemName[/item] -- Player1, Player2, ..
	[*][item]ItemName[/item] -- Player1, Player2, ..
	[/list]

	[b]Profession[/b]
	[list]
	[*][item]ItemName[/item] -- Player1, Player2, ..
	[*][item]ItemName[/item] -- Player1, Player2, ..
	[*][item]ItemName[/item] -- Player1, Player2, ..
	[/list]
**

**		Player::
	[b]Player[/b]
	[u]Profession[u]
	[list]
	[*][item]ItemName[/item]
	[*][item]ItemName[/item]
	[*][item]ItemName[/item]
	[/list]

	[u]Profession[u]
	[list]
	[*][item]ItemName[/item]
	[*][item]ItemName[/item]
	[*][item]ItemName[/item]
	[/list]
**
]]--

local function specialWipe(t)
	for i = 1, #t do
		tremove(t, i)
	end
	return t
end

local phpExportCache = {}
local outCache = {}
local segmentCacheSort = {}
local function AddNewLine(t, arg, ...)
	if tostring(arg or ""):find("%%") then
		arg = arg:format(...)
	else
		arg = string.join("", tostringall(arg, ...) )
	end
	tinsert(t, arg)
end

phpExportCache.AddNewLine = AddNewLine
segmentCacheSort.AddNewLine = AddNewLine

module.phpExportCache = phpExportCache		--Temp Cache
module.outCache = outCache			--Output
module.segmentCacheSort = segmentCacheSort	--Yet another table...

function module:ExportAll()
	specialWipe(phpExportCache)
	specialWipe(outCache)
	phpExportCache:AddNewLine("Export All")
	for trade , _ in pairs( DBO:GetGuildTradesList() ) do
		local list = DBO:GetGuildTrade(trade)
		phpExportCache:AddNewLine("\n\nProfession: %s", trade)
		specialWipe(segmentCacheSort)
		for id, crafters in pairs(list) do
			segmentCacheSort:AddNewLine("[item]%s[/item]:\t%s", (GetSpellInfo(id)), (crafters:gsub("," , ", ")) )
		end
		table.sort(segmentCacheSort)
		for i = 1, #segmentCacheSort do
			phpExportCache:AddNewLine(segmentCacheSort[i])
		end
	end
	for i = 1, #phpExportCache do
		if type(phpExportCache[i]) ~= "string" then
			local s = self:Debug("phpExportCache", i, "Is not a string, got:", type(phpExportCache[i]))
			geterrorhandler()("GuildCraft\n"..s)
			phpExportCache[i] = tostring(phpExportCache[i]) or ""
		end
	end
	self:Debug("ExportAll, Cache->Out; total number of entries:", #phpExportCache)
	local l, last, large = 0, 1
	local numIndex = #phpExportCache
	for i = 1, numIndex do
		l = l + phpExportCache[i]:len()
		self:Debug("idx", i, "len", l)
		if l > 48000 then
			self:Debug("length is longer than 48000chars, segmenting")
			tinsert(phpExportCache, i+1, "\n\n ---Post Break Here--- \n\n")		--27chars long
			local s = table.concat(phpExportCache, "\n", last , i+1)
			tinsert(outCache, s)
			self:Debug( "adding to out cache ", s:sub(1, 15))
			last = i + 2
			l = 0
			large = true
		end
		if i == numIndex then
			print( "Eval i = last")
			local s = table.concat(phpExportCache, "\n", last , i+1)
			tinsert(outCache, s)
			self:Debug( "adding last to out cache ", s:sub(1, 15))
			last = i + 2
			l = 0
			large = true
		end	
	end
--	if l <= 48000 and not large then
--		local s = table.concat(phpExportCache, "\n")
--		tinsert(outCache, s)
--	end
end

