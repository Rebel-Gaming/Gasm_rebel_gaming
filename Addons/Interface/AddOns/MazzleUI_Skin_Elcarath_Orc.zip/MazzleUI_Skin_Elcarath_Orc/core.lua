function MazzleUI:InitializeSkin()
    MazzleUI_Status.skin = {
        art = {
            l = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Orc\\Bottom1",
            ml = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Orc\\Bottom2",
            mr = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Orc\\Bottom3",
            r = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Orc\\Bottom4",
            cave = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Orc\\FloatingCave",
            castborder = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Orc\\MazzleUICastingBarBorder",
            chatborder = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Orc\\MazzleUIChatBoxBorder",
            mapborder = "Interface\\AddOns\\MazzleUI_Skin_Elcarath_Orc\\MazzleUIMinimapBorder",
        },
    }
end