Automaton_Invite = Automaton:NewModule("Invite", "AceEvent-2.0", "AceConsole-2.0", "AceDebug-2.0")
local module = Automaton_Invite

local L
local locale = GetLocale()
L = setmetatable(L or {}, { __index = function(self, key) rawset(self, key, key) return key end })

module.description = "Options for sending out party invites."
module.options = {
	keyword = {
		order = 3,
		type = 'text',
		name = "Invite text",
		desc = "The text users send to trigger an invite.",
		usage = "keyword invite",
		get = function() return module.db.profile.inviteString end,
		set = function(v) module.db.profile.inviteString = v end,
	},
	case = {
		order = 2,
		type = 'toggle',
		name = 'Ignore case',
		desc = "Disable case sensitivity for the invite text",
		get = function() return module.db.profile.ignoreCase end,
		set = function(v) module.db.profile.ignoreCase = v end,
	},
	accept = {
		order = 4,
		type  = "group",
		name  = "Accept from",
		desc  = "Accept invites from these people",
		args  = {
			friends = {
				order = 2,
				type = 'toggle',
				name = 'Friends',
				desc = "Allow invite requests from players on your friends list",
				get = function() return module.db.profile.friends end,
				set = function(v) module.db.profile.friends = v end,
				disabled = function() if module.db.profile.anyone then return true end end,
			},
			guild = {
				order = 3,
				type = 'toggle',
				name = 'Guildmates',
				desc = "Allow invite requests from guildmates",
				get = function() return module.db.profile.guild end,
				set = function(v) module.db.profile.guild = v end,
				disabled = function() if module.db.profile.anyone then return true end end,
			},
			custom = {
				order = 20,
				type = "group",
				name = "Custom list",
				desc = "Specify a custom list to accept from",
				disabled = function() if module.db.profile.anyone then return true end end,
				args = {
					list = {
						type = "execute",
						name = "List",
						desc = "Print all names in the custom list.",
						func = function() module:ListCustom() end
					},
					add = {
						type  = "text",
						name  = "Add Player",
						desc  = "Add a player to the custom list.",
						usage = "<player name>",
						get   = false,
						set   = function(v) module:AddCustomName(v) end,
						order = 1,
					},
					remove = {
						type  = "text",
						name  = "Remove Player",
						desc  = "Removes a player from the custom list.",
						usage = "<player name>",
						get   = false,
						set   = function(v) module:RemoveCustomName(v) end,
						order = 2,
					},
					purge = {
						type = "execute",
						name = "Purge",
						desc = "Remove all names from the custom list.",
						func = function() module:PurgeCustomList() end
					}
				}
			},
			anyone = {
				order = 1,
				type = 'toggle',
				name = 'Everyone',
				desc = "Allow invite requests from everyone",
				get = function() return module.db.profile.anyone end,
				set = function(v)
					module.db.profile.anyone = v
					module.options.accept.args.friends.disabled = v
					module.options.accept.args.guild.disabled = v
					module.options.accept.args.custom.disabled = v
				end,
			}
		}
	}
}

function module:OnInitialize()
	self.db = Automaton:AcquireDBNamespace("Invite")
	Automaton:RegisterDefaults('Invite', 'profile', {
		inviteString = "invite",
		ignoreCase = true,
		friends = true,
		guild = true,
		custom = {}
	})
	self:RegisterOptions(self.options)
end

function module:OnEnable()
	self:RegisterEvent("CHAT_MSG_WHISPER")
end

function module:CHAT_MSG_WHISPER(text,from)
	local keyword,msg
	local player = from
	local keyword = module.db.profile.inviteString
	local msg = text
	if module.db.profile.ignoreCase then
		keyword = string.lower(keyword)
		msg = string.lower(msg)
	end
	if string.find(msg,format("^%s$",keyword)) then
		if not self.db.profile.anyone then
			local acceptFrom = {}		
			if self.db.profile.guild then
				GuildRoster()
				for i=1,GetNumGuildMembers() do
					local name = GetGuildRosterInfo(i)
					tinsert(acceptFrom,name)
				end
			end
			if self.db.profile.friends then
				for i=1,GetNumFriends() do
					local name = GetFriendInfo(i)
					tinsert(acceptFrom,name)
				end
			end
			if not (#self.db.profile.custom == 0) then
				for k,v in pairs(self.db.profile.custom) do
					tinsert(acceptFrom,v)
				end
			end
			
			if foreachi(acceptFrom, function(i,v) if v==player then return true end end) then
				InviteUnit(player)
			end
		else
			InviteUnit(player)
		end
	end
end
	


function module:AddCustomName(name)
	tinsert(self.db.profile.custom,string.lower(name))
end

function module:RemoveCustomName(name)
	for k,v in pairs(self.db.profile.custom) do
		if v == string.lower(name) then
			self.db.profile.custom[k] = nil
		end
	end
end

function module:ListCustom()
	if #self.db.profile.custom == 0 then
		self:Print("No players in custom list.")
	else
		self:Print("Accepting invites from these players:")
		for k,v in pairs(self.db.profile.custom) do
			self:Print(v)
		end
	end
end

function module:PurgeCustomList()
	self:Print(#self.db.profile.custom .. " names purged.")
	self.db.profile.custom = {}
end