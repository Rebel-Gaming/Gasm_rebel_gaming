Automaton_Filter = Automaton:NewModule("Filter", "AceEvent-2.0", "AceConsole-2.0", "AceDebug-2.0")
local module = Automaton_Filter

local L
local locale = GetLocale()
if locale == "koKR" then
	L = {
	    ["Filter"] = "필터",
		["Show only available skills at trainers by default."] = "상급자에게 스킬을 배울시 사용 가능한 기술만 표시합니다.",
	}
elseif locale == "esES" then
	L = {
	    ["Filter"] = "Filtrar",
		["Show only available skills at trainers by default."] = "Mostrar \195\186nicamente las habilidades disponibles de los entrenadores",
	}
elseif locale == "zhTW" then
	L = {
		["Filter"] = "過濾技能",
		["Show only available skills at trainers by default."] = "只顯示可學習的技能",
	}
elseif locale == "zhCN" then
	L = {
		["Show only available skills at trainers by default."] = "在跟导师学习技能时默认只显示可学技能",
	}
end
L = setmetatable(L or {}, { __index = function(self, key) rawset(self, key, key) return key end })

module.description = L["Show only available skills at trainers by default."]
module.options = {
}

function module:OnInitialize()
	self:RegisterOptions(module.options)
end

function module:OnEnable()
	self:RegisterEvent("TRAINER_SHOW")
end

function module:TRAINER_SHOW()
	SetTrainerServiceTypeFilter("unavailable", 0)
end