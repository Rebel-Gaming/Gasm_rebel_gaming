local L = AceLibrary("AceLocale-2.2"):new("Automaton_Gossip")

L:RegisterTranslations("enUS", function() return {
	["Gossip"] = true,
	["Automatically complete quests and skip gossip text"] = true,

	--------------
	-- Gossip Text
	--------------

	["<Place my hand on the orb.>"] = true,
	["<Touch the unstable rift crystal.>"] = true,
	["Grant me your mark, mighty ancient."] = true,
	["Grant me your mark, wise ancient."] = true,
	["I need a pack of incendiary bombs."] = true,
	["I require a chrono-beacon, Sa'at."] = true,
	["I would be grateful for any aid you can provide, Priestess."] = true,
	["I'm ready to go to Durholde Keep."] = true,
	["Naturalist, please grant me your boon."] = true,
	["Please take me to the master's lair."] = true,
	["Thank you, Stable Master. Please take the animal."] = true,
	["Transport me to the Molten Core, Lothos."] = true,
	["Trick or Treat!"] = true,
	["With pleasure. These things stink!"] = true,
}
end)