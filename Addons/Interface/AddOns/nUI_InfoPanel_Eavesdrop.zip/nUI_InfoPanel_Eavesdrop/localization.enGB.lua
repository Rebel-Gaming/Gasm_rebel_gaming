if (nUI_InfoPanel_Eavesdrop_Locale == "enGB") then
	
nUI_InfoPanel_Eavesdrop_L["Info Panel Text"]            = "Info Panel: Eavesdrop Mode";
nUI_InfoPanel_Eavesdrop_L["Info Panel Label"]           = "Eavesdrop";
	
end
