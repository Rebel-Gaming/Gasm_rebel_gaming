
nUI_InfoPanel_Eavesdrop_L = {};
nUI_InfoPanel_Eavesdrop_Locale = GetLocale();

nUI_InfoPanel_Eavesdrop_L["Info Panel Text"]            = "Info Panel: Eavesdrop Mode";
nUI_InfoPanel_Eavesdrop_L["Info Panel Label"]           = "Eavesdrop";
