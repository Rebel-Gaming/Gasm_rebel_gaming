---------------------------------------------------
-- [v1.01.00] Make sure we have nUI tables
---------------------------------------------------
if not nUI_InfoPanels then nUI_InfoPanels = {}; end

----------------------------------------------------------------
-- [v1.01.00] Localized Functions and Tables to speed things up
----------------------------------------------------------------
local _L = nUI_InfoPanel_Eavesdrop_L;

---------------------------------------------------
-- [v1.01.00] Allocation of the Window ID (unique)
---------------------------------------------------
nUI_INFOMODE_EAVESDROP  = 17;
nUI_INFOPANEL_EAVESDROP = "nUI_InfoPanel_Eavesdrop";

---------------------------------------------------
-- [v1.01.00] Set the Default values for the Infopanel
---------------------------------------------------
nUI_InfoPanels[nUI_INFOPANEL_EAVESDROP ] =
{	
	enabled   = true,
	desc      = _L["Info Panel Text"],             -- player friendly name/description of the panel
	label     = _L["Info Panel Label"],	       -- label to use on the panel selection button face
	rotation  = nUI_INFOMODE_EAVESDROP,            -- index or position this panel appears on/in when clicking the selector button
	full_size = true;                              -- this plugin requires the entire info panel port without the button bag
	
	options  =
	{
		enabled  = true,
	},
};

---------------------------------------------------
-- [v1.01.00] Set Plugin Values
---------------------------------------------------
local plugin    = CreateFrame( "Frame", nUI_INFOPANEL_EAVESDROP, nUI_Dashboard.Anchor );
plugin.active   = true;

---------------------------------------------------
-- [v1.01.00] Validate Addon is loaded
---------------------------------------------------
local function onEavesdropEvent()
	if event == "VARIABLES_LOADED" then
		if not IsAddOnLoaded( "Eavesdrop" ) then 
			LoadAddOn( "Eavesdrop" );
		end
		plugin.active = IsAddOnLoaded( "Eavesdrop" );
	end	
end
plugin:SetScript( "OnEvent", onEavesdropEvent );
plugin:RegisterEvent( "VARIABLES_LOADED" );

---------------------------------------------------
-- [v1.01.00] initPanel routine
---------------------------------------------------
plugin.initPanel = function( container, options )
	plugin.container = container;
	plugin.options   = options;
	if options and options.enabled then
		plugin.setEnabled( true );
	end
end

---------------------------------------------------
-- [v1.01.00] sizeChanged routine
---------------------------------------------------
plugin.sizeChanged = function( scale, height, width )
	local options  = plugin.options;
	local Eavesdrop   = plugin.Eavesdrop;
	plugin.scale = scale;
	nUI_Movers:lockFrame( Eavesdrop, false, nil );
	Eavesdrop:SetWidth( width ); 
	Eavesdrop:SetHeight( height ); 
	nUI_Movers:lockFrame( Eavesdrop, true, nil );
end	

---------------------------------------------------
-- [v1.01.00] Validate Enable Status
-- [v1.01.01] Made Border Transparent
-- [v1.01.01] Set some EavesDrop options to fit in panel
---------------------------------------------------
plugin.setEnabled = function( enabled )
	if plugin.enabled ~= enabled then
		plugin.enabled = enabled;
		if not enabled then
			local Eavesdrop = plugin.Eavesdrop;
			if Eavesdrop.saved_parent then
				nUI_Movers:lockFrame( Eavesdrop, false, nil );
				Eavesdrop:SetParent( Eavesdrop.saved_parent );
				Eavesdrop:SetBackdropBorderColor( Eavesdrop.border_color );
				Eavesdrop:SetBackdropColor( Eavesdrop.backdrop_color );
			end
		else
			local Eavesdrop = EavesDropFrame;
			plugin.Eavesdrop = Eavesdrop;
			if not Eavesdrop.saved_parent then
				Eavesdrop.saved_parent   = Eavesdrop:GetParent();
				Eavesdrop.border_color   = Eavesdrop:GetBackdropBorderColor();
				Eavesdrop.backdrop_color = Eavesdrop:GetBackdropColor();
			end
			Eavesdrop:SetParent( plugin.container );
			Eavesdrop:SetPoint( "TOPLEFT", plugin.container, "TOPLEFT", 10, 10 );
			Eavesdrop:SetPoint( "BOTTOMRIGHT", plugin.container, "BOTTOMRIGHT", 0, 0 );
			Eavesdrop:SetFrameStrata( plugin.container:GetFrameStrata() );
			Eavesdrop:SetFrameLevel( plugin.container:GetFrameLevel()+1 );
			Eavesdrop:SetBackdropBorderColor( 0, 0, 0, 0 );
			Eavesdrop:SetBackdropColor( 0, 0, 0, 0 );
			
			local EavesDropOptions = EavesDrop.db.profile;
			EavesDropOptions["NUMLINES"] = 10;
			EavesDropOptions["LINEHEIGHT"] = 10;
			EavesDropOptions["LOCKED"] = true;
			
			nUI_Movers:lockFrame( Eavesdrop, true, nil );
		end				
	end			
end

---------------------------------------------------
-- [v1.01.00] setSelected routine
---------------------------------------------------
plugin.setSelected = function( selected )
	if selected ~= plugin.selected then
		plugin.selected = selected;
		if selected then
		else
		end
	end
end
