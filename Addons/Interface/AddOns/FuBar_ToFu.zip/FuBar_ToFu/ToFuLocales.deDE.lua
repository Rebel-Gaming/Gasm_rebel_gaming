local L = AceLibrary("AceLocale-2.2"):new("FuBar_ToFu")

L:RegisterTranslations("deDE", function() return {
	["Current Flight"] = "Momentaner Flug",
	["Previous Flight"] = "Vorheriger Flug",

	["From"] = "Von",
	["To"] = "Nach",
	["Cost"] = "Kosten",
	["Time Taken"] = "Gebrauchte Zeit",
	["Average Time"] = "Durchschnittliche Zeit",

	["Not in flight"] = "Nicht im Flug",
	["No previous flight"] = "Kein vorheriger Flug",

	["Click to copy the time remaining in flight to the chatbox."] = "Klicken, um die verbleibende Zeit in den Chat zu kopieren.",

	["Takes"] = "Zeit",
	["Flown %s times"] = "%s Mal geflogen",

	["Data"] = "Daten",
	["Various options to do with saved flight data"] = "Verschiedene Optionen f\195\188r die gespeicherten Flugdaten",

	['Default Data'] = "Vorgabe-Daten",
	["Load the default flight-time dataset."] = "Lade die vorgegebenen Flugzeit-Daten.",

	["Delete *ALL* saved flight path data for your faction."] = "L\195\182sche *ALLE* gespeicherten Flugpfad-Daten f\195\188r deine Fraktion.",
	["Clear Data"] = "L\195\182sche Daten",

	["Hooks"] = "Anzeige",
	["Other addons to hook into"] = "Andere Addons zur Anzeige",

	--["Shapeshift"] = true,
	--["Shift out of forms when talking to a flight master"] = true,

	["estimated"] = "(ca.)",
	["reversed"] = "(inv)",
	["So Far"] = "Bisher",

	["Flight master"] = "Greifenmeister",
} end)