--Chinese Local : CWDG Translation Team feilang999
--$Rev$
--$Date$

local L = AceLibrary("AceLocale-2.2"):new("FuBar_ToFu")

L:RegisterTranslations("zhCN", function() return {
    ["Current Flight"] = "本次飞行",
	["Previous Flight"] = "上次飞行",

	["From"] = "从",
	["To"] = "到",
	["Cost"] = "花费",
	["Time Taken"] = "当前飞行时间",
	["Average Time"] = "平均时间",

	["Not in flight"] = "未在飞行中",
	["No previous flight"] = "无上次飞行数据",
	
	["Click to copy the time remaining in flight to the chatbox."] = "点击复制剩余飞行时间到聊天输入窗口。",
	
	["Takes"] = "需时",
	["Flown %s times"] = "飞行 %s 次",
	
	["Data"] = "数据",
	["Various options to do with saved flight data"] = "保存飞行数据的相关选项",

	['Default Data'] = "默认数据",
	["Load the default flight-time dataset."] = "读取默认飞行时间数据。",

	["Delete *ALL* saved flight path data for your faction."] = "删除你阵营的 *所有* 已保存的飞行路线数据。",
	["Clear Data"] = "清除数据",
	
	["Hooks"] = "插件关联",
	["Other addons to hook into"] = "与其他插件关联",
	
	--["Shapeshift"] = true,
	--["Shift out of forms when talking to a flight master"] = true,
	
	["estimated"] = "(预估)",
	["reversed"] = "(逆向)",
	["So Far"] = "到目前为止",
	
	["Flight master"] = "飞行管理员",
} end)
