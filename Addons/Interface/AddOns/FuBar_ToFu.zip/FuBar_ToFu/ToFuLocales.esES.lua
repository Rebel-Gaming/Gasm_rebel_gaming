﻿local L = AceLibrary("AceLocale-2.2"):new("FuBar_ToFu")

L:RegisterTranslations("esES", function() return {
	["Current Flight"] = "Vuelo Actual",
	["Previous Flight"] = "Vuelo Anterior",

	["From"] = "Desde",
	["To"] = "Hacia",
	["Cost"] = "Coste",
	["Time Taken"] = "Duración",
	["Average Time"] = "Estimado",

	["Not in flight"] = "Sin vuelo actual",
	["No previous flight"] = "Sin vuelo anterior",

	["Click to copy the time remaining in flight to the chatbox."] = "Click para copiar el tiempo restante del vuelo a la caja de edición del chat.",

	["Takes"] = "Duración",
	["Flown %s times"] = "Usado %s veces",

	["Data"] = "Datos",
	["Various options to do with saved flight data"] = "Diversas opciones para ver con los datos de vuelo salvados",

	['Default Data'] = "Datos Predeterminados",
	["Load the default flight-time dataset."] = "Cargar el valor predeterminado de los datos de tiempo de vuelo.",

	["Delete *ALL* saved flight path data for your faction."] = "Eliminar *TODOS* los datos guardados de la rutas de vuelo para tu facción",
	["Clear Data"] = "Limpiar Datos",

	["Hooks"] = "Ganchos",
	["Other addons to hook into"] = "Otros addons para enganchar",

	["Shapeshift"] = "Cambio de Forma",
	["Shift out of forms when talking to a flight master"] = "Quitar Cambio de Forma al hablar con el Maestro de Vuelo",

	["estimated"] = "(est)",
	["reversed"] = "(inv)",
	["So Far"] = "Muy Lejos",

	["Flight master"] = "Maestro de Vuelo",
} end)
