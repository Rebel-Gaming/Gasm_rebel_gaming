--
-- MI3_Health.lua
--
-- Mob health callculation module of MobInfo-2 AddOn
--
-- Mob health is calculated from the damage that a mob receives
-- in relation to the changes in mob health percentage. Damage
-- is observed through the WoW "UnitCombat" event, Health is
-- observed through the WoW "UnitHealth" event.
--
-- This module now implements a totally new health calculation
-- algorithm with an inctredible acuracy.
--


-- remember previous font type and font size
local lOldFontId = 0
local lOldFontSize = 0

local MI3_HpPctList, MI3_HpDmg, MI3_HpData


-----------------------------------------------------------------------------
-- MI3_HpDecode()
--
function MI3_HpDecode( hpData )
	local _,_, pts, pct = string.find(hpData, "^(%d+)/(%d+)$")
	pts = tonumber( pts )
	pct = tonumber( pct )
	return pts, pct
end  -- MI3_HpDecode()


-----------------------------------------------------------------------------
-- external	functions for macros / scripts
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- MobHealth_GetTargetCurHP()
--
-- Return current health points	value for the current target as	an integer
-- value. Return nil if	there is no	current	target.
--
-- Example:
--	 local targetCurrentHealth = MobHealth_GetTargetCurHP()
--	 if	 targetCurrentHealth  then
--		.......
--	 end
--
function MobHealth_GetTargetCurHP()
	return MI3_Target.curHealth
end	 --	of MobHealth_GetTargetCurHP()


-----------------------------------------------------------------------------
-- MobHealth_GetTargetMaxHP()
--
-- Return maximum health points	value for the current target as	an integer
-- value. Return nil if	there is no	current	target.
--
-- Example:
--	 local targetMaxHealth = MobHealth_GetTargetMaxHP()
--	 if	 targetMaxHealth  then
--		.......
--	 end
--
function MobHealth_GetTargetMaxHP()
	return MI3_Target.maxHealth
end	 --	of MobHealth_GetTargetMaxHP()


-----------------------------------------------------------------------------
-- MobHealth_PPP( index	)
--
-- Return the Points-Per-Percent (PPP) value for a Mob identified by its index.
-- The index is	the	concatination of the Mob name and the Mob level	(see
-- example below). 0 is	returned if	the	PPP	value is not available for
-- the given index.	The	example	also shows how to calculate	the	actual
-- health points from the health percentage	and	the	PPP	value
--
-- Example:
--	  local	name  =	UnitName("target")
--	  local	level =	UnitLevel("target")
--	  local	index =	name..":"..level
--	  local	ppp	= MobHealth_PPP( index )
--	  local	healthPercent =	UnitHealth("target")
--	  local	curHealth =	floor(	healthPercent *	ppp	+ 0.5)
--	  local	maxHealth =	floor(	100	* ppp +	0.5)
--
function MobHealth_PPP( index )
	if	index and MobHealthDB[index]  then
		local pts, pct = MI3_HpDecode( MobHealthDB[index] )
		if pts and pct and pct ~= 0 then
			return pts / pct
		end
	end
	return 0
end

function MI3_GetHealth_PPP( index )
	if	index then
		local pts, pct
		if MobHealthDB[index]  then
			pts, pct = MI3_HpDecode( MobHealthDB[index] )
		elseif MobHealthPlayerDB[index]  then
			pts, pct = MI3_HpDecode( MobHealthPlayerDB[index] )
		end
		if pts and pct and pct ~= 0 then
			return pts / pct
		end
	end
	return 0
end


-----------------------------------------------------------------------------
-- end of external functions for macros / scripts
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- MI3_HpGet()
--
local function MI3_HpGet( database, index )
	if not database[index] then return nil,0 end

	local pts, pct = MI3_HpDecode( database[index] )

	local quality
	if pct == 200 then
	    quality = 3
	    pts = pts / 2
	elseif pct == 100 then
	    quality = 2
	elseif pct and pts then
	    quality = 1
	    pts = floor(pts * 100 / pct + 0.5)
	else
		return nil,0
	end

	return pts, quality
end  -- MI3_HpGet()


-----------------------------------------------------------------------------
-- MI3_HpSet()
--
local function MI3_HpSet( database, index, hpMax, quality )
	local pct, pts
	hpMax = floor(hpMax + 0.51)
	if quality == 3 then
		pct = 200
		pts = hpMax * 2
	elseif quality == 2 then
		pct = 100
		pts = hpMax
	else
		pct = 50
		pts = floor(hpMax / 2 + 0.51)
	end
--midebug( "writing HP to DB: new=["..pts.."/"..pct.."], old=["..(database[index] or "nil").."], hpm="..hpMax..", q="..quality, 1 )
	database[index] = pts.."/"..pct
end  -- MI3_HpSet()


-----------------------------------------------------------------------------
-- MI3_HpSetNewTarget()
--
-- Update the health/mana display for the target frame because the target
-- has changed.
--
function MI3_HpSetNewTarget()
	MI3_Target.unitHealth = UnitHealth("target")
	MI3_HpData = { totalDmg=0, newQuality=0 }
	if MI3_Target.unitHealth > 0 and MI3_Target.healthDB then
		MI3_HpDmg = {}
		MI3_HpPctList = {}

		-- read max hp from database
		MI3_HpData.dbMax, MI3_HpData.dbQuality = MI3_HpGet( MI3_Target.healthDB, MI3_Target.index )

		-- initialise health calculation and show health in target frame
		MI3_Target.showHealth = 1
		if MI3_Target.unitHealth == 100 then
			tinsert( MI3_HpPctList, {100,0} )
			MI3_HpData.newQuality = 2
		else
			MI3_HpData.newQuality = 1
		end
		MI3_RecordTargetHealth( MI3_Target.unitHealth )
	else
		MobHealth_Display()
	end
end -- MI3_HpSetNewTarget()


-----------------------------------------------------------------------------
-- MobHealth_Display()
--
-- display the values and percentage for health	/ mana in target frame
--
function MobHealth_Display( )
	-- nothing to do if showing is disabled
	if MobInfoConfig.ShowTargetInfo ~= 1 then return end

	-- create health and percent text if showing is enabled
	local healthText, manaText
	if  MobInfoConfig.TargetHealth == 1 and MI3_Target.maxHealth then
	    if MI3_HpData.dbQuality == 3 then
			healthText = string.format("%d // %d", MI3_Target.curHealth, MI3_Target.maxHealth )
		else
			healthText = string.format("%d / %d", MI3_Target.curHealth, MI3_Target.maxHealth )
		end
	end

	local health = MI3_Target.unitHealth or 0
	if	MobInfoConfig.HealthPercent	== 1 and health > 0 then
		if healthText then
			healthText = healthText..string.format(" (%d%%)", health )
		else
			healthText = string.format("%d%%", health )
		end
	end

	-- create mana text based on mana show flags
	local maxmana =	UnitManaMax("target")
	if maxmana > 0 then
		local mana = UnitMana("target")
		if MobInfoConfig.TargetMana == 1 then
			manaText = string.format("%d / %d", mana, maxmana )
		end
		if MobInfoConfig.ManaPercent == 1 then
			if manaText then
				manaText = manaText..string.format(" (%d%%)", floor(100.0 * mana / maxmana))
			else
				manaText = string.format("%d%%", floor(100.0 * mana / maxmana))
			end
		end
	end

	MI3_MobHealthText:SetText( healthText or "" )
	MI3_MobManaText:SetText( manaText or "" )
end	 --	MobHealth_Display()


-----------------------------------------------------------------------------
-- MI3_MobHealth_SetFont()
--
-- set new font	for	display	of health /	mana in	target frame
--
local function MI3_MobHealth_SetFont( fontId, fontSize )
	local fontName

	if fontId ~= lOldFontId or fontSize ~= lOldFontSize then
		lOldFontId = fontId
		lOldFontSize = fontSize

		-- select font name	to use
		if	fontId == 1	 then
			fontName = "Fonts\\ARIALN.TTF"  -- NumberFontNormal
		elseif	fontId == 2	 then
			fontName = "Fonts\\FRIZQT__.TTF"	 --	GameFontNormal
		else
			fontName = "Fonts\\MORPHEUS.TTF"	 --	ItemTextFontNormal
		end

		-- set font	for	health and mana	text
		MI3_MobHealthText:SetFont( fontName, fontSize )
		MI3_MobManaText:SetFont( fontName, fontSize )
	end

end	 --	of MI3_MobHealth_SetFont()


-----------------------------------------------------------------------------
-- MI3_MobHealth_SetPos()
--
-- set position	and	font for mob health/mana texts
--
function MI3_MobHealth_SetPos( )
	local font

	-- set poition for health	and	mana text
	MI3_MobHealthText:SetPoint( "TOP", "TargetFrameHealthBar", "BOTTOM", MobInfoConfig.HealthPosX, MobInfoConfig.HealthPosY )
	MI3_MobManaText:SetPoint( "TOP", "TargetFrameManaBar", "BOTTOM", MobInfoConfig.ManaPosX, MobInfoConfig.ManaPosY )

	-- update	font ID	and	font size
	MI3_MobHealth_SetFont( MobInfoConfig.TargetFont, MobInfoConfig.TargetFontSize )

	-- update visibility of target frame info
	if MobInfoConfig.ShowTargetInfo == 1 and MobInfoConfig.DisableHealth ~= 2 then
		MI3_MobHealthFrame:Show()
	else
		MI3_MobHealthFrame:Hide()
	end

	-- redisplay health / mana values
	MobHealth_Display()
end	 --	of MI3_MobHealth_SetPos()


-----------------------------------------------------------------------------
-- MI3_MobHealth_Reset()
--
function MI3_MobHealth_Reset()
	MI3_MobHealth_ClearTargetData()
	MobHealthDB	= {}
	MobHealthPlayerDB =	{}
end


-----------------------------------------------------------------------------
-- MI3_SaveTargetHealthData()
--
-- Save health data for current target in health database
--
function MI3_SaveTargetHealthData( updateOnly )
	-- nothing to do if there is no health data
	if MI3_HpData == nil then return end
	
    local newHpMax = MI3_HpData.newMax
    local newQuality = MI3_HpData.newQuality

	if newHpMax and newQuality and newQuality >= MI3_HpData.dbQuality then
	    if MI3_HpData.pct and MI3_HpData.pct < 10 then newQuality = 1 end
		if newQuality == MI3_HpData.dbQuality and newQuality < 3 then
		    local delta = newHpMax / 100 + 1
		    if MI3_HpData.dbQuality == 1 or abs(MI3_HpData.dbMax - newHpMax) > delta then
				newHpMax = (MI3_HpData.dbMax + newHpMax) / 2
			else
   			    newHpMax = max(MI3_HpData.dbMax, newHpMax)
			end
		end
		MI3_HpSet( MI3_Target.healthDB, MI3_Target.index, newHpMax, newQuality )
	end
end -- MI3_SaveTargetHealthData()


-----------------------------------------------------------------------------
-- MI3_MobHealth_ClearTargetData()
--
-- Clear mob health data for current target
--
function MI3_MobHealth_ClearTargetData()
	if MI3_Target.index then
		MI3_Target.healthDB[MI3_Target.index] = nil
		MI3_Target = {}
		MobHealth_Display()
		MI3_HpData = nil
	end
end  -- MI3_MobHealth_ClearTargetData()


-----------------------------------------------------------------------------
-- MI3_CalculateHp()
--
-- This function implements the new algorithm for calculating
-- a Mobs maximum health points.
--
local function MI3_CalculateHp()
	local numDmg = getn( MI3_HpDmg )
	local numPct = getn( MI3_HpPctList )
	if numPct < 2 or numDmg < 2 then return end

	local firstPct = MI3_HpPctList[1][1]
	local lastPct = MI3_HpPctList[numPct][1]
	local deltaPct = firstPct - lastPct
	local dmg1 = MI3_HpDmg[MI3_HpPctList[numPct][2]]
	local dmg2 = (MI3_HpDmg[MI3_HpPctList[numPct][2]+1] or dmg1)
	local hpm1 = dmg1 * 100 / deltaPct
	local hpm2 = dmg2 * 100 / deltaPct
	MI3_HpData.pct = deltaPct

	local hpm1Count = 0
	local hpm2Count = 0
	local hpm1Delta = (hpm1 / 50) + 1
	local hpm2Delta = (hpm2 / 50) + 1
	for i=2,(numPct-1) do
		local dmg = MI3_HpDmg[MI3_HpPctList[i][2]]
		if dmg then
			local pct = MI3_HpPctList[i][1]
			local hpm = dmg * 100 / (firstPct - pct)
			if abs(hpm-hpm1) < hpm1Delta then hpm1Count = hpm1Count + 1 end
			if abs(hpm-hpm2) < hpm2Delta then hpm2Count = hpm2Count + 1 end
		end
	end

	local hpm, hpmCount, hpmDelta
	if hpm2Count > hpm1Count then
		hpm = hpm2
		hpmCount = hpm2Count
		hpmDelta = hpm2Delta
 	else
		hpm = hpm1
		hpmCount = hpm1Count
		hpmDelta = hpm1Delta
    end

    if not MI3_HpData.maxCount or hpmCount >= MI3_HpData.maxCount then
        MI3_HpData.maxCount = hpmCount
		if MI3_HpData.newMax and abs(hpm-MI3_HpData.newMax) < hpmDelta then
			MI3_HpData.newMax = max( hpm, MI3_HpData.newMax )
		else
			MI3_HpData.newMax = hpm
		end
	end
end --MI3_CalculateHp()


-----------------------------------------------------------------------------
-- MI3_RecordTargetCombat()
--
function MI3_RecordTargetCombat( damage, isHeal )
	if isHeal then
		MI3_HpData.totalDmg = max( (MI3_HpData.totalDmg-damage), 0 )
	else
		MI3_HpData.totalDmg = MI3_HpData.totalDmg + damage
	end
	if MI3_HpData.totalDmg > 0 then
		tinsert( MI3_HpDmg, MI3_HpData.totalDmg )
		if MI3_HpData.pctAdded then
			MI3_CalculateHp()
			MI3_HpData.pctAdded = nil
		end
	end
end


-----------------------------------------------------------------------------
-- MI3_RecordTargetHealth()
--
function MI3_RecordTargetHealth( health )
	if not MI3_HpData.dbQuality then return end -- can happen when there is no healthDB

	MI3_Target.unitHealth = UnitHealth("target")

	-- check if BeastLore effect is active or not
	local unitHpMax = UnitHealthMax("target")
	if unitHpMax ~= 100 then
		MI3_HpData.newMax = unitHpMax
		MI3_HpData.newQuality = 3
		MI3_HpData.pctAdded = nil
		MI3_Target.unitHealth = floor(100.0 * health / MI3_HpData.newMax + 0.5)
		MI3_Target.curHealth = health
		MI3_Target.maxHealth = unitHpMax
	else
		if MI3_HpData.newQuality < 3 and health > 1 and health < 100 then
			tinsert( MI3_HpPctList, {health,getn(MI3_HpDmg)} )
			MI3_HpData.pctAdded = true
		end
		local hpMax = (MI3_HpData.newMax or MI3_HpData.dbMax)
		if hpMax then
			if MI3_HpData.dbQuality < 2 or not MI3_Target.maxHealth then
				MI3_Target.maxHealth = floor(hpMax + 0.5)
				if MI3_HpData.dbQuality < 1 then
				    MI3_SaveTargetHealthData( true )
				end
			end
			MI3_Target.curHealth = floor((MI3_Target.maxHealth * health) / 100 + 0.5)
		end
	end

	MobHealth_Display()
end
