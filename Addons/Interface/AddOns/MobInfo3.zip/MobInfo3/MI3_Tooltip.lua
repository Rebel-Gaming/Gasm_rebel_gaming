--
-- MI3_Tooltip.lua
--
-- Tooltip handling functions for the MobInfo AddOn.
--

local MI3_FontHeight, MI3_MaxTextWidth, MI3_MaxValWidth, MI3_OffsetX, MI3_OffsetY, MI3_Anchor, MI3_CowFade
local MI3_TooltipOptions = {}
local MI3_MaxNumLines = 20
local MI3_MaxNumItems = 20
local MI3_IsMoving = 0
local MI3_HideTimer, MI3_Tick, MI3_Skip = 0, 0, 0


-----------------------------------------------------------------------------
-- MI3_InitializeTooltip()
--
-- One time initialization of tooltip, will be called from event "VARIABLES_LOADED"
--
function MI3_InitializeTooltip()
	MI3_TooltipFrame:SetBackdrop( { bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
									edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
									tile = true, tileSize = 24, edgeSize = 12, 
									insets = { left=4, right=4, top=4, bottom=4 } } )
	MI3_TooltipFrame:SetBackdropColor( 0, 0, 0, 0.8 )
	MI3_TooltipFrame:SetBackdropBorderColor( 0.5, 0, 0, 1 )

	MI3_TooltipFrame:SetClampedToScreen( true )

	for idx=1,MI3_MaxNumLines do
		local text = getglobal( "MI3TT_Text"..idx )
		local val = getglobal( "MI3TT_Val"..idx )
		text.val = val
	end
	MI3_UpdateAnchor()
end


-----------------------------------------------------------------------------
-- MI3_UpdateAnchor()
--
-- Update visibility of tooltip anchor based on whether optiosn window is
-- open and how the show anchor flag is set.
--
function MI3_UpdateAnchor()
	local showAnchor = MI3_OptionsFrame:IsVisible() == 1 or (MobInfoConfig.HideAnchor == 0 and MobInfoConfig.UseGameTT == 0) 
	if showAnchor then
		MI3_TooltipAnchor:Show()
	else
		MI3_TooltipAnchor:Hide()
	end

	-- set tooltip anchoring position
	MI3_TooltipFrame:ClearAllPoints()
	if MobInfoConfig.TooltipMode == 1 then
		MI3_TooltipFrame:SetPoint( "BOTTOMLEFT", MI3_TooltipAnchor, "TOPLEFT" )
	elseif MobInfoConfig.TooltipMode == 2 then
		MI3_TooltipFrame:SetPoint( "TOPLEFT", MI3_TooltipAnchor, "BOTTOMLEFT" )
	elseif MobInfoConfig.TooltipMode == 3 then
		MI3_TooltipFrame:SetPoint( "BOTTOMRIGHT", MI3_TooltipAnchor, "TOPRIGHT" )
	elseif MobInfoConfig.TooltipMode == 5 then
		MI3_TooltipFrame:SetPoint( "BOTTOM", MI3_TooltipAnchor, "TOP" )
	elseif MobInfoConfig.TooltipMode == 6 then
		MI3_TooltipFrame:SetPoint( "TOP", MI3_TooltipAnchor, "BOTTOM" )
	else
		MI3_TooltipFrame:SetPoint( "TOPRIGHT", MI3_TooltipAnchor, "BOTTOMRIGHT" )
	end
end -- MI3_UpdateAnchor


-----------------------------------------------------------------------------
-- MI3_TooltipAnchorOnEnter()
--
function MI3_TooltipAnchorOnEnter()
	if MI3_MouseoverIndex and MobInfoConfig.UseGameTT == 0 then
		MI3_IsMoving = 0
		MI3_HideTimer = 9
		MI3_UpdateAnchor()
		MI3_TooltipFrame:SetAlpha(1)
		MI3_TooltipFrame:Show()
	end
end -- MI3_TooltipAnchorOnEnter


-----------------------------------------------------------------------------
-- MI3_TooltipAnchorOnLeave()
--
function MI3_TooltipAnchorOnLeave()
	MI3_HideTimer = 1.4
end -- MI3_TooltipAnchorOnLeave


-----------------------------------------------------------------------------
-- MI3_SetupTooltip()
--
-- Basic setup of tooltip after changing a tooltip configuration option.
--
function MI3_SetupTooltip()
	MI3_TooltipFrame:Hide()
	MI3_MouseoverIndex = nil

	-- initialise the extra tooltip entries
	MI3_OptShowDps:SetChecked( MI3_OptShowDamage:GetChecked() )
	MI3_OptShowImmuns:SetChecked( MI3_OptShowResists:GetChecked() )

	-- build list of tooltip options to be displayed in the tooltip	
	MI3_TooltipOptions = {}
	local children = { MI3_FrmTooltipContent:GetChildren() }
	for idx, child in pairs(children) do
	    local opt = MI3_OPTIONS[child:GetName()]
		if child.GetChecked and child:GetChecked() and opt.data then
			table.insert( MI3_TooltipOptions, opt )
		end
	end

	-- set tooltip font size
	ttfont = GameFontNormal
	if MobInfoConfig.SmallFont == 1 then
		ttfont = GameFontNormalSmall
	end
	for idx=1,MI3_MaxNumLines do
		getglobal("MI3TT_Text"..idx):SetFontObject(ttfont)
		getglobal("MI3TT_Val"..idx):SetFontObject(ttfont)
	end
	for idx=1,MI3_MaxNumItems do
		getglobal("MI3TT_Item"..idx):SetFontObject(ttfont)
	end

	-- calculate font height and columns width limitations based on font
	local fontName, fontHeight, fontFlags = MI3TT_Text1:GetFont()
	MI3_FontHeight = fontHeight
	MI3TT_Text1:SetText( "AAAAAA" )
	MI3_MaxTextWidth = MI3TT_Text1:GetWidth()
	MI3_MaxValWidth = MI3_MaxTextWidth * 1.3

	if TipTac_Config then
		TipTac_Config.showTip = (MobInfoConfig.OtherTooltip == 0)
	end
end -- MI3_SetupTooltip


-----------------------------------------------------------------------------
-- MI3_StartTooltipMouseMove()
--
-- Initiate moving the mobinfo tooltip together with mouse movement. The
-- trick it to set the anchor correctly so that when "StartMoving()" is
-- called in "OnUpdate()" the tooltip is at exactly the right position.
--
local function MI3_StartTooltipMouseMove()
	MI3_TooltipFrame:ClearAllPoints()
	if MobInfoConfig.TooltipMode == 1 then
		MI3_Anchor = "BOTTOMLEFT"
		MI3_OffsetX, MI3_OffsetY = 10, 5
	elseif MobInfoConfig.TooltipMode == 2 then
		MI3_Anchor = "TOPLEFT"
		MI3_OffsetX, MI3_OffsetY = 20, -15
	elseif MobInfoConfig.TooltipMode == 3 then
		MI3_Anchor = "BOTTOMRIGHT"
		MI3_OffsetX, MI3_OffsetY = -10, 5
	elseif MobInfoConfig.TooltipMode == 4 then
		MI3_Anchor = "TOPRIGHT"
		MI3_OffsetX, MI3_OffsetY = -5, -15
	elseif MobInfoConfig.TooltipMode == 5 then
		MI3_Anchor = "BOTTOM"
		MI3_OffsetX, MI3_OffsetY = 5, 20
	elseif MobInfoConfig.TooltipMode == 6 then
		MI3_Anchor = "TOP"
		MI3_OffsetX, MI3_OffsetY = 5, -25
	end
	MI3_IsMoving = 1
end -- MI3_StartTooltipMouseMove


-----------------------------------------------------------------------------
-- MI3_UpdateTooltipHealth()
--
-- set position of MobInfo tooltip based on mouse position
--
local function MI3_MouseMove()
	-- calculate position and take into account UI scaling
	local scale = UIParent:GetEffectiveScale()
	local x,y = GetCursorPosition()
	x = (x + MI3_OffsetX) / scale
	y = (y + MI3_OffsetY) / scale
--midebug("ox="..MI3_OffsetX..", oy="..MI3_OffsetY..", a="..MI3_Anchor..", s="..scale)
	MI3_TooltipFrame:SetPoint( MI3_Anchor, UIParent, "BOTTOMLEFT", x, y )
end -- MI3_MouseMove

-----------------------------------------------------------------------------
-- MI3_UpdateTooltipHealth()
--
-- update health/mana shown within MobInfo tooltip while tooltip is shown
-- for the "mouseover" unit
--
local function MI3_UpdateTooltipHealth()
	if not UnitExists("mouseover") then return end
	local mobData = {}
	MI3_GetUnitBasedMobData( MI3_MouseoverIndex, mobData, "mouseover" )
	if MI3TT_Text1:GetText() == MI_TXT_HEALTH then
		MI3TT_Text1.val:SetText(mobData.healthText)
	end
	if MI3TT_Text3:GetText() == MI_TXT_MANA then
		MI3TT_Text1.val:SetText(mobData.healthText)
	end
end -- MI3_UpdateTooltipHealth


-----------------------------------------------------------------------------
-- MI3_TooltipOnUpdate()
--
-- OnUpdate is called periodically (about 20 times per second) by the WoW
-- client. This handler starts and stope moving the tooltip along with the
-- mouse, and also handles tooltip fadeout.
--
function MI3_TooltipOnUpdate( time )
	-- half second action ticker : use it to update health/mana in tooltip
	MI3_Tick = MI3_Tick + time
	if MI3_Tick > 0.5 then
		MI3_Tick = 0
		MI3_UpdateTooltipHealth()
		if MI3_IsMoving == 2 then
			MI3_HideTooltip()
		end
	end

	if MI3_IsMoving > 0 then
		MI3_MouseMove()
		if MI3_IsMoving == 1 and not UnitExists("mouseover") then
			MI3_Tick = 0.35
			MI3_IsMoving = 2
		end
	elseif  MI3_HideTimer < 4.0 then
		MI3_HideTimer = MI3_HideTimer - time
		if  MI3_HideTimer < 1.0 then
			MI3_TooltipFrame:SetAlpha( MI3_HideTimer )
			if MI3_HideTimer < 0.1 then
				MI3_HideTooltip()
			end
		end
	elseif not UnitExists("mouseover") and MI3_HideTimer < 6.0 then
		MI3_HideTimer = 1.4
	end
end -- MI3_TooltipOnUpdate


-----------------------------------------------------------------------------
-- MI3_TooltipMouseoverUnit()
--
function MI3_TooltipMouseoverUnit()
	if MobInfoConfig.ShowMobInfo == 0 then  return  end
	if MobInfoConfig.KeypressMode == 1 and not IsAltKeyDown() then  return  end
	--if  UnitIsPlayer("mouseover") or UnitIsFriend("player","mouseover") or not UnitCanAttack("player","mouseover") then  return  end
	if  UnitIsPlayer("mouseover") then  return  end
	local isMob = not(UnitIsPlayer("mouseover") or UnitIsFriend("player","mouseover") or not UnitCanAttack("player","mouseover"))
	MI3_CreateTooltip( UnitName("mouseover"), UnitLevel("mouseover"), "mouseover", isMob )
	MI3_HideTimer = 5
end


-----------------------------------------------------------------------------
-- MI3_EntryToString()
--
-- return the correct textual representation for a mob data item
-- conversions are performed depending on the type code of the data item
--
local function MI3_EntryToString( type, data, mobData, unit )
	local value = mobData[data]
	if type == 1 and value then
		return copper2text( value )
	elseif type == 2 and (mobData.minDamage or mobData.maxDamage) then
		return (mobData.minDamage or 0).."-"..(mobData.maxDamage or 0)
	elseif type == 3 and mobData.location then
		local loc = mobData.location
		if unit then
			return MI3_ZoneTable[loc.z]
		else
			local x = floor((loc.x1 + loc.x2)/2)
			local y = floor((loc.y1 + loc.y2)/2)
			return MI3_ZoneTable[loc.z].." ("..x.."/"..y..")"
		end
	elseif type == 4 then
		return mobData.ttItems[data]
	else
		return value
	end
end -- MI3_EntryToString


-----------------------------------------------------------------------------
-- MI3_UpdateGameTooltip()
--
-- Add info about Mob to the standard game tooltip
--
local function MI3_UpdateGameTooltip( mobData, mobName, unit )
	if not unit then
		GameTooltip_SetDefaultAnchor( GameTooltip, UIParent )
		GameTooltip:ClearLines()
		GameTooltip:AddLine( mobData.levelInfo..mobName )
		GameTooltip:AddLine( " " )
	end

	if mobData.class then
		local txt = GameTooltipTextLeft2:GetText()
		if txt then
			GameTooltipTextLeft2:SetText( txt.." "..mobData.class )
		end
	end

	local opt, value, itemText
	for idx = 1, MI3_MaxNumLines do
		opt = MI3_TooltipOptions[idx]
		if opt then
			value = MI3_EntryToString( opt.t, opt.data, mobData, unit )
			if value then
				if opt.data == "qualityStr" or opt.data == "loc" then
					GameTooltip:AddLine( opt.text..": "..MI_White..value )
				else
					GameTooltip:AddDoubleLine( opt.text, MI_White..value )
				end
			end
		end
	end
	for idx = 1, MI3_MaxNumItems do
		itemText = MI3_EntryToString( 4, idx, mobData )
		if itemText then
			GameTooltip:AddLine( itemText )
		end
	end
	if GameTooltip:NumLines() > 1 and mobData.lowHpAction then
		GameTooltipTextLeft2:SetText( GameTooltipTextLeft2:GetText().." "..MI_LightRed..MI3_TXT_MOBRUNS )
	end
	GameTooltip:Show()
end -- MI3_UpdateGameTooltip


-----------------------------------------------------------------------------
-- MI3_FillTooltipWithData()
--
local function MI3_FillTooltipWithData( mobData, unit )
	local opt, value, entry, itemText

	-- fill in the extra tooltip info
	MI3TT_ExtraInfo1:SetText( mobData.extraInfo[1] or "" )
	MI3TT_ExtraInfo2:SetText( mobData.extraInfo[2] or "" )
	MI3TT_ExtraInfo3:SetText( mobData.extraInfo[3] or "" )
	MI3TT_ExtraInfo4:SetText( mobData.extraInfo[4] or "" )

	-- fill the columns
	local numEntries=0
	for idx = 1, MI3_MaxNumLines do
		opt = MI3_TooltipOptions[idx]
		if opt then
			value = MI3_EntryToString( opt.t, opt.data, mobData, unit )
			if value then
				numEntries = numEntries + 1
				entry = getglobal( "MI3TT_Text"..numEntries )
				entry:SetText( opt.text )
				entry.val:SetText( value )
				entry:Show()
				entry.val:Show()
			end
		end
	end

	-- hide all the unused tooltip columns
	for idx = numEntries+1, MI3_MaxNumLines do
		entry = getglobal( "MI3TT_Text"..idx )
		entry:Hide()
		entry.val:Hide()
	end

	-- fill the loot items lines
	for idx = 1, MI3_MaxNumItems do
		entry = getglobal( "MI3TT_Item"..idx )
		itemText = MI3_EntryToString( 4, idx, mobData )
		if itemText then
			entry:SetText( itemText )
			entry:Show()
		else
			entry:Hide()
		end
	end
	
	return numEntries
end -- MI3_FillTooltipWithData


-----------------------------------------------------------------------------
-- MI3_UpdateTooltip()
--
-- This will update the contents of the MobInfo Tooltip with the data for
-- a specific given Mob. It includes tooltip content layouting based on
-- the size of the entries
--
local function MI3_UpdateTooltip( mobData, mobName, unit )
	if MobInfoConfig.UseGameTT == 1 then return end

	-- set mob name/level/type/class
	MI3TT_MobLevel:SetText( mobData.levelInfo )
	MI3TT_MobName:SetText( mobName )
	MI3TT_MobName:SetTextColor( GameTooltip_UnitColor("mouseover") )
	MI3TT_ClassInfo:SetText( mobData.classInfo )
	local nameWidth = MI3TT_MobLevel:GetStringWidth() + MI3TT_MobName:GetStringWidth()
	local classWidth = MI3TT_ClassInfo:GetStringWidth()
	MI3_TooltipFrame:SetBackdropBorderColor( GameTooltip_UnitColor("mouseover") )

	numEntries = MI3_FillTooltipWithData( mobData, unit )

	-- arrange tooltip layout 
	local colWidth = {0,0,0,0,0,0}
	local ttHeight = MI3_FontHeight
	local right = false
	for idx = 1, numEntries do
		entry = getglobal( "MI3TT_Text"..idx )
		txtWidth = entry:GetStringWidth() 
		valWidth = entry.val:GetStringWidth()
		if right and valWidth < MI3_MaxValWidth then
			entry:SetPoint( "TOPLEFT", MI3TT_Col3, "TOPLEFT", 0, ttHeight )
			entry.val:SetPoint( "TOPLEFT", MI3TT_Col4, "TOPLEFT", 0, ttHeight )
			if txtWidth > colWidth[3] then colWidth[3] = txtWidth end
			if valWidth > colWidth[4] then colWidth[4] = valWidth end
			right = false
		else
			ttHeight = ttHeight - MI3_FontHeight
			entry:SetPoint( "TOPLEFT", MI3TT_Col1, "TOPLEFT", 0, ttHeight )
			entry.val:SetPoint( "TOPLEFT", MI3TT_Col2, "TOPLEFT", 0, ttHeight )
			right = valWidth < MI3_MaxValWidth and MobInfoConfig.CompactMode == 1
			if txtWidth > colWidth[1] then colWidth[1] = txtWidth end
			if right then
				if valWidth > colWidth[2] then colWidth[2] = valWidth end
			else
				if valWidth > colWidth[5] then colWidth[5] = valWidth end
			end
		end
	end

	-- align the tooltip columns
	-- use last extra info line for anchoring the mob data columns
	local numExtraLines = #mobData.extraInfo
	if numExtraLines > 0 then
		local above = getglobal("MI3TT_ExtraInfo"..numExtraLines)
		MI3TT_Col1:SetPoint( "TOPLEFT", above, "BOTTOMLEFT", 0, -2 )
	else
		MI3TT_Col1:SetPoint( "TOPLEFT", MI3TT_ClassInfo, "BOTTOMLEFT", 0, -2 )
	end
	MI3TT_Col2:SetPoint( "TOPLEFT", MI3TT_Col1, "TOPLEFT", colWidth[1], 0 )
	MI3TT_Col3:SetPoint( "TOPLEFT", MI3TT_Col2, "TOPLEFT", colWidth[2] + 4, 0 )
	MI3TT_Col4:SetPoint( "TOPLEFT", MI3TT_Col3, "TOPLEFT", colWidth[3], 0 )

	-- arrange loot items layout
	MI3TT_Item1:SetPoint( "TOPLEFT", MI3TT_Col1, "BOTTOMLEFT", 0, ttHeight - MI3_FontHeight )
	for idx = 1, MI3_MaxNumItems do
		entry = getglobal( "MI3TT_Item"..idx )
		if entry:IsShown() then
			ttHeight = ttHeight - MI3_FontHeight
			txtWidth = entry:GetStringWidth() 
			if txtWidth > colWidth[6] then colWidth[6] = txtWidth end
		end
	end

	-- set tooltip width and height
	ttHeight = -ttHeight + 26 + MI3_FontHeight + (numExtraLines * MI3_FontHeight)
	if mobData.classInfo then
		ttHeight = ttHeight + MI3_FontHeight
	end
	local ttWidth = colWidth[2] + colWidth[3] + colWidth[4]
	if colWidth[5] > ttWidth then ttWidth = colWidth[5] end
	ttWidth = ttWidth + colWidth[1]
	if colWidth[6] > ttWidth then ttWidth = colWidth[6] end
	if nameWidth > ttWidth then ttWidth = nameWidth end
	if classWidth > ttWidth then ttWidth = classWidth end
	ttWidth = ttWidth + 12

	MI3_TooltipFrame:SetWidth( ttWidth )
	MI3_TooltipFrame:SetHeight( ttHeight )
	MI3_TooltipFrame:SetAlpha(1)
	MI3_TooltipFrame:Show()
end -- MI3_UpdateTooltip


-----------------------------------------------------------------------------
-- MI3_CreateTooltip()
--
function MI3_CreateTooltip( name, level, unit, isMob )
	local mobIndex = name..":"..level
	local mobData = MI3_BuildTooltipMob( name, level, unit, isMob )
	if unit and isMob then
		MI3_RecordLocationAndType( mobIndex, mobData )
	end
	MI3_MouseoverIndex = mobIndex -- must be set after calling MI3_RecordLocationAndType

	MI3_HideTimer = 9.0
	if MobInfoConfig.UseGameTT == 1 then
		MI3_UpdateGameTooltip( mobData, name, unit )
	else
		--MI3_CowText = CowTip:IsModuleActive("Text")
		--CowTip:ToggleModuleActive("Text", false)

		-- hide other tooltip if requested
		if MobInfoConfig.OtherTooltip == 1 then
			-- special CowTip support
			if CowTip and unit then
				MI3_CowFade = CowTip.options.args.CowTip_Fade.child_get("units")
				CowTip.options.args.CowTip_Fade.child_set("units", "hide")
			end
			GameTooltip:Hide()
		end
		-- anchor MobInfo tooltip either at mouse or at anchor frame
		if MobInfoConfig.MouseTooltip == 1 and unit then
			MI3_StartTooltipMouseMove()
		else
			MI3_UpdateAnchor()
		end
		MI3_UpdateTooltip( mobData, name, unit )
	end
end -- MI3_CreateTooltip


-----------------------------------------------------------------------------
-- MI3_HideTooltip()
--
function MI3_HideTooltip()
	MI3_TooltipFrame:Hide()
	MI3_IsMoving = 0 
	GameTooltip:Hide()
	if MI3_CowFade then
		CowTip.options.args.CowTip_Fade.child_set("units", MI3_CowFade)
		MI3_CowFade = nil
	end
end -- MI3_HideTooltip()

