--
-- MI3_Config.lua
--
-- Configuration dialog related module of the MobInfo AddOn
--

MI3_OPTIONS["MI3_OptShowClass"] 	= { text=MI_TXT_CLASS; help=MI_HLP_CLASS }
MI3_OPTIONS["MI3_OptShowHealth"]	= { data="healthText"; text=MI_TXT_HEALTH; help=MI_HLP_HEALTH }
MI3_OPTIONS["MI3_OptShowMana"] 		= { data="manaText"; text=MI_TXT_MANA; help=MI_HLP_MANA }
MI3_OPTIONS["MI3_OptShowKills"]		= { data="kills"; text=MI_TXT_KILLS; help=MI_HLP_KILLS }
MI3_OPTIONS["MI3_OptShowLoots"] 	= { data="loots"; text=MI_TXT_LOOTS; help=MI_HLP_LOOTS }
MI3_OPTIONS["MI3_OptShowCoin"] 		= { data="avgCV"; t=1; text=MI_TXT_COINS; help=MI_HLP_COINS }
MI3_OPTIONS["MI3_OptShowIV"] 		= { data="avgIV"; t=1; text=MI_TXT_ITEMVAL; help=MI_HLP_ITEMVAL }
MI3_OPTIONS["MI3_OptShowTotal"] 	= { data="avgTV"; t=1; text=MI_TXT_MOBVAL; help=MI_HLP_MOBVAL }
MI3_OPTIONS["MI3_OptShowXp"] 		= { data="xp"; text=MI_TXT_XP; help=MI_HLP_XP }
MI3_OPTIONS["MI3_OptShowNo2lev"] 	= { data="mob2Level"; text=MI_TXT_TO_LEVEL; help=MI_HLP_TO_LEVEL }
MI3_OPTIONS["MI3_OptShowEmpty"] 	= { data="emptyLoots"; text=MI_TXT_EMPTY_LOOTS; help=MI_HLP_EMPTY_LOOTS }
MI3_OPTIONS["MI3_OptShowCloth"] 	= { data="clothCount"; text=MI_TXT_CLOTH_DROP; help=MI_HLP_CLOTH_DROP }
MI3_OPTIONS["MI3_OptShowDamage"] 	= { data="dmgText"; t=2; text=MI_TXT_DAMAGE; help=MI_HLP_DAMAGE }
MI3_OPTIONS["MI3_OptShowDps"] 		= { data="dps"; text="DPS"; help=MI_HLP_DPS }
MI3_OPTIONS["MI3_OptShowLocation"]	= { data="loc"; t=3; text=MI_TXT_LOCATION; help=MI_HELP_LOCATION }
MI3_OPTIONS["MI3_OptShowQuality"]	= { data="qualityStr"; opt=MI_OPT_QUALITY; text=MI_TXT_QUALITY; help=MI_HLP_QUALITY }
MI3_OPTIONS["MI3_OptShowLowHpAction"] = { text=MI_TXT_LOWHEALTH; help=MI_HELP_LOWHEALTH }
MI3_OPTIONS["MI3_OptShowResists"]	= { data="resStr"; opt=MI_OPT_RESISTS; text=MI_TXT_RESISTS; help=MI_HELP_RESISTS }
MI3_OPTIONS["MI3_OptShowImmuns"]	= { data="immStr"; text=MI_TXT_IMMUN; help="" }
MI3_OPTIONS["MI3_OptShowItems"]		= { text=MI_TXT_ITEMLIST; help=MI_HELP_ITEMLIST } 
MI3_OPTIONS["MI3_OptShowClothSkin"]	= { text=MI_TXT_CLOTHSKIN; help=MI_HELP_CLOTHSKIN }


-----------------------------------------------------------------------------
-- MI3_OptionsFrameOnLoad()
--
-- This "OnLoad" event handler for the options dialog installs the
-- ESC key handler.
--
function MI3_OptionsFrameOnLoad()
	tinsert(UISpecialFrames, "MI3_OptionsFrame") -- Esc Closes Options Frame
	UIPanelWindows["MI3_OptionsFrame"] = {area = "center", pushable = 0}

	PanelTemplates_SetNumTabs( MI3_OptionsTabFrame, 5 )
	MI3_OptionsTabFrame.selectedTab = 5
	PanelTemplates_UpdateTabs( MI3_OptionsTabFrame )

	MI3_TxtOptionsTitle:SetText( "MobInfo "..miVersionNo )
	
--	MI3_OptShowCombined:Disable()
--	MI3_OptShowCombinedText:SetTextColor( 0.5,0.5,0.5 )

	MI3_MainOptionsFrame = MI3_OptionsTabFrame
end  -- MI3_OptionsFrameOnLoad()


-----------------------------------------------------------------------------
-- MI3_UpdateOptions()
--
-- Update state of all options in options dialog with correct values from
-- data structure "MobInfoConfig".
--
function MI3_UpdateOptions()
	if MobInfoConfig.ShowMobInfo == 1 then
		MI3_OptUseGameTT:Enable()
		MI3_OptUseGameTTText:SetTextColor( 1.0,0.8,0.0 )
	else
		MI3_OptUseGameTT:Disable()
		MI3_OptUseGameTTText:SetTextColor( 0.5,0.5,0.5 )
	end

	local index, value
	for index, value in pairs(MI3_OPTIONS) do
		local option = string.sub(index,8)
		local control = getglobal(index)
		if  control and MobInfoConfig[option] then
			if value.dd then
				-- do nothing for dropdowns
			elseif value.val then
				control:SetValue( MobInfoConfig[option] )
			elseif value.txt then
				control:SetText( MobInfoConfig[option] )
			elseif control.SetChecked then
				control:SetChecked( MobInfoConfig[option] )
			end
		end
	end
end  -- MI3_UpdateOptions()


-----------------------------------------------------------------------------
-- MI3_ShowOptionHelpTooltip()
--
-- Show help text for current hovered option in options dialog
-- in the game tooltip window.
--
function MI3_ShowOptionHelpTooltip()
	GameTooltip_SetDefaultAnchor( GameTooltip, UIParent )
	GameTooltip:SetText( MI_White..MI3_OPTIONS[this:GetName()].text )
	  
	GameTooltip:AddLine(MI_Gold..MI3_OPTIONS[this:GetName()].help)
	if MI3_OPTIONS[this:GetName()].info then
		GameTooltip:AddLine(MI_Gold..MI3_OPTIONS[this:GetName()].info)
	end
	GameTooltip:Show()
end -- of MI3_ShowOptionHelpTooltip()


-----------------------------------------------------------------------------
-- MI3_OptionsFrameOnShow()
--
-- Show help text for current hovered option in options dialog
-- in the game tooltip window.
--
function MI3_OptionsFrameOnShow()
	MI3_UpdateOptions()
	MI3_TooltipAnchor:SetFrameStrata( "HIGH" )
	MI3_UpdateAnchor()
end  -- MI3_OptionsFrameOnShow()


function miConfig_OnMouseDown()
	if arg1 == "LeftButton" then
		this:StartMoving()
	end
end


function miConfig_OnMouseUp()
	if arg1 == "LeftButton" then
		this:StopMovingOrSizing()
	end
end


function MI3_DoneButton_OnClick()
	HideUIPanel(MI3_OptionsFrame)
	if MYADDONS_ACTIVE_OPTIONSFRAME then
		if (MYADDONS_ACTIVE_OPTIONSFRAME == this) then
			ShowUIPanel(myAddOnsFrame)
		end
	end
end

-----------------------------------------------------------------------------
-- MI3_TabButton_OnClick()
--
-- Event handler: one of the options dialog TABs has been clicked.
-- Show the corresponding options frame and hide all other option frames.
--
function MI3_TabButton_OnClick( self )
	PanelTemplates_Tab_OnClick( self, MI3_OptionsTabFrame )
	local selected = MI3_OptionsTabFrame.selectedTab

	-- choose special information frame if mob health has been disabled
	local healthFrame = MI3_TargetOptionsFrame
	if  MobInfoConfig.DisableHealth == 2  then
		healthFrame = MI3_FrmHealthDisabledInfo
	end

	if  selected == 1  then
		MI3_TooltipOptionsFrame:Show()
	else
		MI3_TooltipOptionsFrame:Hide()
	end
	if  selected == 2  then
		healthFrame:Show()
	else
		healthFrame:Hide()
	end
	if  selected == 3  then
		MI3_DatabaseOptionsFrame:Show()
	else
		MI3_DatabaseOptionsFrame:Hide()
	end
	if  selected == 4  then
		MI3_SearchOptionsFrame:Show()
	else
		MI3_SearchOptionsFrame:Hide()
	end
	if  selected == 5  then
		MI3_GeneralOptionsFrame:Show()
	else
		MI3_GeneralOptionsFrame:Hide()
	end
end


-----------------------------------------------------------------------------
-- MI3_OptTargetFont_OnClick()
--
-- Event handler: one of the choices in the font selection box has been
-- clicked. Store it as a config option.
--
function MI3_OptTargetFont_OnClick()
	local oldID = UIDropDownMenu_GetSelectedID( MI3_OptTargetFont )
	UIDropDownMenu_SetSelectedID( MI3_OptTargetFont, this:GetID())
	if  oldID ~= this:GetID()  then
		MobInfoConfig.TargetFont = this:GetID()
		MI3_MobHealth_SetPos()
	end
end  -- MI3_OptTargetFont_OnClick()


-----------------------------------------------------------------------------
-- MI3_OptItemsQuality_OnClick()
--
-- Event handler: one of the choices in the items quality dropdown has been
-- clicked. Store it as a config option.
--
function MI3_OptItemsQuality_OnClick()
	local oldID = UIDropDownMenu_GetSelectedID( MI3_OptItemsQuality )
	UIDropDownMenu_SetSelectedID( MI3_OptItemsQuality, this:GetID())
	if  oldID ~= this:GetID()  then
		MobInfoConfig.ItemsQuality = this:GetID()
	end
end  -- MI3_OptItemsQuality_OnClick()


-----------------------------------------------------------------------------
-- MI3_OptTooltipMode_OnClick()
--
-- Event handler: one of the choices in the tooltip mode dropdown has been
-- clicked. Store it as a config option.
--
function MI3_OptTooltipMode_OnClick()
	local oldID = UIDropDownMenu_GetSelectedID( MI3_OptTooltipMode )
	UIDropDownMenu_SetSelectedID( MI3_OptTooltipMode, this:GetID())
	if  oldID ~= this:GetID()  then
		MobInfoConfig.TooltipMode = this:GetID()
	end
	MI3_SetupTooltip()
end  -- MI3_OptTooltipMode_OnClick()


-----------------------------------------------------------------------------
-- MI3_DropDown_Initialize()
--
-- Initialize a dropdown list with entries that are retrieved from the
-- localization info.
--
function MI3_DropDown_Initialize()
	if string.sub(this:GetName(),-6) ~= "Button" then return end
	
	local dropDownName = string.sub(this:GetName(),1,-7)
	local choice = MI3_OPTIONS[dropDownName].choice1
	local count = 1

	while choice do
		local info = { text = choice, value = count, func = getglobal(dropDownName.."_OnClick") }
		UIDropDownMenu_AddButton( info )
		count = count + 1
		choice = MI3_OPTIONS[dropDownName]["choice"..count] 
	end
end  -- MI3_DropDown_Initialize()


-----------------------------------------------------------------------------
-- MI3_DropDown_OnShow()
--
-- Event handler: show a drop down list
-- Ensure that current selection is shown correctly.
--
function MI3_DropDown_OnShow(self)
	local frameName = self:GetName()
	local itemName = string.sub(frameName, 8)
	local text=MI3_OPTIONS[frameName]["choice"..MobInfoConfig[itemName]]

	UIDropDownMenu_SetSelectedID( self, MobInfoConfig[itemName] )
	UIDropDownMenu_SetText( self, text ) 
end  -- MI3_DropDown_OnShow()


-----------------------------------------------------------------------------
-- MI3_DbOptionsFrameOnShow()
--
--
function MI3_DbOptionsFrameOnShow()
	local mobDbSize, healthDbSize, playerDbSize, itemDbSize = 0, 0, 0, 0

	-- count and diplay size of MobInfo database
	for index in pairs(MobInfoDB) do  mobDbSize = mobDbSize + 1  end
	MI3_TxtMobDbSize:SetText( MI_TXT_MOB_DB_SIZE..MI_White..(mobDbSize-1) )

	-- count and diplay size of MobHealth database
	for index in pairs(MobHealthDB) do  healthDbSize = healthDbSize + 1  end
	MI3_TxtHealthDbSize:SetText( MI_TXT_HEALTH_DB_SIZE..MI_White..healthDbSize )

	-- count and diplay size of MobHealthPlayer database
	for index in pairs(MobHealthPlayerDB) do  playerDbSize = playerDbSize + 1  end
	MI3_TxtPlayerDbSize:SetText( MI_TXT_PLAYER_DB_SIZE..MI_White..playerDbSize )

	-- count and diplay size of MI3_ItemNameTable database
--	for  index in MI3_ItemNameTable  do  itemDbSize = itemDbSize + 1  end
--	MI3_TxtItemDbSize:SetText( MI_TXT_ITEM_DB_SIZE..MI_White..itemDbSize )

	-- update mob index display and state of "clear mob" button
	if MI3_Target.mobIndex and MobInfoDB[MI3_Target.mobIndex] then
		MI3_OptClearTarget:Enable()
		MI3_TxtTargetIndex:SetText( MI_TXT_CUR_TARGET..MI_White..MI3_Target.mobIndex )
	else
		MI3_OptClearTarget:Disable()
		MI3_TxtTargetIndex:SetText( MI_TXT_CUR_TARGET..MI_White.."---" )
	end

	-- update import status
	if MI3_Import_Status then
		if MobInfoConfig.ImportSignature == MI3_Import_Signature then
			MI3_OptImportMobData:Disable()
			MI3_TxtImportStatus:SetText( "Status: <data already imported ("..MI3_Import_Status..")>" )
		elseif MI3_Import_Status == "BADVER" then
			MI3_OptImportMobData:Disable()
			MI3_TxtImportStatus:SetText( "Status: <import database too old for import>" )
		elseif MI3_Import_Status == "BADLOC" then
			MI3_OptImportMobData:Disable()
			MI3_TxtImportStatus:SetText( "Status: <import database has wrong language (locale)>" )
		else
			MI3_OptImportMobData:Enable()
			MI3_TxtImportStatus:SetText( "Status: "..MI3_Import_Status.." available for import" )
		end
	else
		MI3_OptImportMobData:Disable()
		MI3_TxtImportStatus:SetText( "Status: <no import data>" )
	end
end  -- MI3_DbOptionsFrameOnShow()

