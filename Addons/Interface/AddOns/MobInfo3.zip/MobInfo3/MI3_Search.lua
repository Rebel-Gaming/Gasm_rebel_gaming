--
-- MI3_Search.lua
--
-- MobInfo module to control the Mob database search feature.
-- Search option settings and actual search algorithm are located in here.
--

--
-- start up defaults for search options settings
MI3_SearchOptions = {}
MI3_SearchOptions.MinLevel = 1
MI3_SearchOptions.MaxLevel = 85
MI3_SearchOptions.Normal = 1
MI3_SearchOptions.Elite = 0
MI3_SearchOptions.Boss = 0
MI3_SearchOptions.MinLoots = 0
MI3_SearchOptions.MaxLoots = 9999
MI3_SearchOptions.MobName = ""
MI3_SearchOptions.ItemName = ""
MI3_SearchOptions.CompactResult = 1
MI3_SearchOptions.ListMode = "Mobs"
MI3_SearchOptions.SortMode = "profit"

local MI3_SearchResultList = {}
MI3_ItemsIdxList = {}
MI3_SearchMode = 0
MI3_SearchCount = 0
MI3_NumMobsFound = 0


-----------------------------------------------------------------------------
-- MI3_SearchForItems()
--
-- Search for all items matching the item name entered in the search dialog.
-- Display the list of items in the result list control (if requested).
--
local function MI3_SearchForItems( itemName, enterItemsIntoList )
	MI3_ItemsIdxList = {}
	MI3_NumMobsFound = 0
	if enterItemsIntoList then
		MI3_SearchResultList = {}
	end
	
	if itemName ~= "" or enterItemsIntoList then
		local itemFound, itemText, itemColor
		itemName = string.lower(itemName)
		MI3_ItemsIdxList[0] = 1
		for idx in pairs(MI3_ItemNameTable) do
			itemFound = true
			itemText, itemColor = MI3_GetLootItem( idx )
			--local itemText = MI3_ItemNameTable[idx]
			if itemName ~= "*" then
				itemFound = string.find( string.lower(itemText), itemName ) ~= nil
			end
			if itemFound then
				if enterItemsIntoList then
					MI3_NumMobsFound = MI3_NumMobsFound + 1
					MI3_SearchResultList[MI3_NumMobsFound] = { idx = itemText, val = "", col = itemColor }
				else
					MI3_ItemsIdxList[idx] = 1
				end
			end
		end
	end
	
	MI3_DisplaySearchResult( "Items" )
end -- MI3_SearchForItems()


-----------------------------------------------------------------------------
-- MI3_UpdateSearchResultList()
--
-- Update contents of search result list according to current search options
-- settings. This includes starting a new search run, sorting the result and
-- displaying the result in the scrollable result list.
--
local function MI3_UpdateSearchResultList( updateItems )
	if updateItems then
		local enterItemsIntoList = MI3_SearchOptions.ListMode == "Items"
		MI3_SearchForItems( MI3_SearchOptions.ItemName, enterItemsIntoList )
	end
	if MI3_SearchOptions.ListMode == "Mobs" then
		-- (re)start search for entire mob database
		MI3_SearchCount = 0
		MI3_SearchMode = 1
		for mobIndex, mobInfo in pairs(MobInfoDB) do
			mobInfo.sf = true
		end
	
		-- initialise search result list  
		MI3_SearchResultList = {}
		MI3_NumMobsFound = 0

		-- search first 500 database recors right away
		MI3_SearchForMobs( 500 )
	end

	MI3_DisplaySearchResult( MI3_SearchOptions.ListMode )
end -- MI3_UpdateSearchResultList()


-----------------------------------------------------------------------------
-- MI3_SearchOptionsOnShow()
--
-- OnShow event handler for search options page
-- Write current search option settings into the search option controls.
-- Validate all values and update colors accordingly.
-- Allow Search only if all search options are valid.
--
function MI3_SearchOptionsOnShow()
	MI3_OptSearchMinLoots:SetMaxLetters( 4 )
	MI3_OptSearchMaxLoots:SetMaxLetters( 4 )
	MI3_OptSearchMinLoots:SetWidth( 36 )
	MI3_OptSearchMaxLoots:SetWidth( 36 )

	MI3_OptSearchMinLevel:SetText( tostring(MI3_SearchOptions.MinLevel) )
	MI3_OptSearchMaxLevel:SetText( tostring(MI3_SearchOptions.MaxLevel) )
	MI3_OptSearchMinLoots:SetText( tostring(MI3_SearchOptions.MinLoots) )
	MI3_OptSearchMaxLoots:SetText( tostring(MI3_SearchOptions.MaxLoots) )
	MI3_OptSearchMobName:SetText( MI3_SearchOptions.MobName )
	MI3_OptSearchItemName:SetText( MI3_SearchOptions.ItemName )

	MI3_OptSearchNormal:SetChecked( MI3_SearchOptions.Normal )
	MI3_OptSearchElite:SetChecked( MI3_SearchOptions.Elite )
	MI3_OptSearchBoss:SetChecked( MI3_SearchOptions.Boss )

	MI3_UpdateSearchResultList()
end -- MI3_SearchOptionsOnShow()


-----------------------------------------------------------------------------
-- MI3_ValidateSearchOptions()
--
-- Validate all values and update colors accordingly.
-- Allow Search only if all search options are valid.
--
local function MI3_ValidateSearchOptions()
	if MI3_SearchOptions.MinLevel < 1 then
		MI3_SearchOptions.MinLevel = 1
		if this:GetText() == "0" then
			this:SetText( "1" )
		end
	end
	if MI3_SearchOptions.MaxLevel < 1 then
		MI3_SearchOptions.MaxLevel = 1
		if this:GetText() == "0" then
			this:SetText( "1" )
		end
	end
end -- MI3_ValidateSearchOptions()


-----------------------------------------------------------------------------
-- MI3_SearchCheckboxClicked()
--
-- OnClicked event handler for checkboxes on search options page
-- Store the checkbox state in the corresponding search options variable.
--
function MI3_SearchCheckboxClicked()
	local checkboxName = this:GetName()
	local optionName = string.sub( checkboxName, 14 )
	local optionValue = this:GetChecked() or 0

	MI3_SearchOptions[optionName] = optionValue
	MI3_UpdateSearchResultList()
end -- MI3_SearchCheckboxClicked()


-----------------------------------------------------------------------------
-- MI3_SearchValueChanged()
--
-- OnChar event handler for editbox controls on search options page
-- This handler is called whenever the contents of an EditBox control changes.
-- It gets the new value and stores it in the corresponding search options
-- variable
--
function MI3_SearchValueChanged()
	local editboxName = this:GetName()
	local optionName = string.sub( editboxName, 14 )
	local optionValue = tonumber(this:GetText()) or 0

	if MI3_SearchOptions[optionName] ~= optionValue then
		MI3_SearchOptions[optionName] = optionValue
		MI3_ValidateSearchOptions()
		MI3_UpdateSearchResultList()
	end
end -- MI3_SearchValueChanged()


-----------------------------------------------------------------------------
-- MI3_SearchTextChanged()
--
-- OnChar event handler for textual editbox controls on search options page
-- This handler is called whenever the contents of an EditBox control changes.
-- It gets the new value and stores it in the corresponding search options
-- variable
--
function MI3_SearchTextChanged()
	local editboxName = this:GetName()
	local optionName = string.sub( editboxName, 14 )

	if MI3_SearchOptions[optionName] ~= this:GetText() then
		MI3_SearchOptions[optionName] = this:GetText()
		MI3_UpdateSearchResultList( true )
	end
end -- MI3_SearchTextChanged()


-----------------------------------------------------------------------------
-- MI3_CalculateRank()
--
-- Calculate ranking and corresponding actual value for a given mob.
-- Ranking depends on search mode. For search mode "profit" ranking is
-- based on the mobs total profit value plus bonus points for rare loot
-- items. For search mode "itemCount" ranking is identical to the overall
-- items count for the loot items being searched for (in this mode
-- rank and value are identical).
--
local function MI3_CalculateRank( mobData, mobLevel, sortMode )
	local rank, value = 0, 0

	if sortMode == "profit" then
		-- calculate rank based on mob level and loot items quality
		local bonusFactor = mobLevel / 20
		if mobData.loots > 0 then
			value = (mobData.copper or 0) + (mobData.itemValue or 0)
			rank = value + ((mobData.r3 or 0) * 200 * bonusFactor) + ((mobData.r4 or 0) * 1000 * bonusFactor) + ((mobData.r5 or 0) * 2000 * bonusFactor)
			rank = ceil( rank / mobData.loots )
			value = copper2text( ceil(value / mobData.loots) )
		end
	elseif sortMode == "item" and mobData.itemList then
		for idx, val in pairs(mobData.itemList) do
			--local itemFound = string.find( MI3_ItemsIdxList, idx ) ~= nil
			--if itemFound then  rank = rank + val  end
			rank = rank + val
		end
		value = rank.."  "
	end

	return rank, value
end -- MI3_CalculateRank()


-----------------------------------------------------------------------------
-- MI3_CheckMob()
--
-- Check a given Mob against the current search criteria. Return the
-- mob data if the mob matches the criteria, or return nil if the Mob
-- does not match.
--
local function MI3_CheckMob( mobInfo, mobName, mobLevel )
	local levelOk, lootsOk, typeOk, itemsOK, mobData
	local nameOk = true

	-- check name and level of Mob
	if MI3_SearchOptions.MobName ~= "" then
		nameOk = string.find(string.lower(mobName),string.lower(MI3_SearchOptions.MobName),1,true) ~= nil
	end
	if nameOk and mobName ~= "" then
		levelOk = mobLevel >= MI3_SearchOptions.MinLevel and mobLevel <= MI3_SearchOptions.MaxLevel
		levelOk = levelOk or (mobLevel == -1)
	end

	-- check mob data related search conditions	
	if levelOk then
		mobData = {}
		MI3_DecodeBasicMobData( mobInfo, mobData )
		mobData.loots = mobData.loots or 0
		lootsOk = (mobData.loots >= MI3_SearchOptions.MinLoots) and (mobData.loots <= MI3_SearchOptions.MaxLoots)
		typeOk = (MI3_SearchOptions.Normal == 1 and (mobData.mobType == 1 or not mobData.mobType)) or (MI3_SearchOptions.Elite == 1 and mobData.mobType == 2) or (MI3_SearchOptions.Boss == 1 and mobData.mobType == 3)
		if lootsOk and typeOk then
			MI3_DecodeItemList( mobInfo, mobData )
			if MI3_ItemsIdxList[0] then
				if mobData.itemList then
					for idx, val in pairs(mobData.itemList) do
						itemsOK = MI3_ItemsIdxList[idx] ~= nil
						if itemsOK then break end
					end
				end
				if not itemsOK then mobData = nil end
			end
		else
			mobData = nil
		end
	end

	return mobData
end -- MI3_CheckMob()


-----------------------------------------------------------------------------
-- MI3_DisplaySearchResult()
--
-- Display the result of a search in the search results scrollable list.
-- The mobs to be displayed depend on the current list scroll position.
--
function MI3_DisplaySearchResult( resultType )
	-- update slider and get slider position
	FauxScrollFrame_Update( MI3_SearchResultSlider, MI3_NumMobsFound, 15, 14 );
	local sliderPos = FauxScrollFrame_GetOffset(MI3_SearchResultSlider)

	if resultType then
		MI3_TxtSearchCount:SetText( MI_SubWhite.."("..MI3_NumMobsFound.." "..resultType..")" )
	end

	-- update 15 search result lines with correct search result data
	local resultLine
	for i = 1, 15 do
		if 	(i + sliderPos) <= MI3_NumMobsFound then
			resultLine = getglobal( "MI3_SearchResult"..i.."Index" )
			resultLine:SetText( i + sliderPos )
			resultLine = getglobal( "MI3_SearchResult"..i.."Value" )
			resultLine:SetText( MI3_SearchResultList[i + sliderPos].val )
			resultLine = getglobal( "MI3_SearchResult"..i.."Name" )
			local mobName = MI3_SearchResultList[i + sliderPos].idx
			if MI3_SearchResultList[i + sliderPos].type then
				mobName = mobName.."+"
			elseif MI3_SearchResultList[i + sliderPos].col then
				mobName = MI3_SearchResultList[i + sliderPos].col..mobName
			end
			resultLine:SetText( mobName )
		else
			resultLine = getglobal( "MI3_SearchResult"..i.."Index" )
			resultLine:SetText( "" )
			resultLine = getglobal( "MI3_SearchResult"..i.."Value" )
			resultLine:SetText( "" )
			resultLine = getglobal( "MI3_SearchResult"..i.."Name" )
			resultLine:SetText( "" )
		end
	end
end  -- MI3_DisplaySearchResult()


-----------------------------------------------------------------------------
-- MI3_SlashAction_SortByValue()
--
-- Sort the search result list by mob profit
--
function MI3_SlashAction_SortByValue()
	MI3_SearchOptions.SortMode = "profit"
	MI3_UpdateSearchResultList()
end -- end of MI3_SlashAction_SortByValue()


-----------------------------------------------------------------------------
-- MI3_SlashAction_SortByItem()
--
-- Sort the search result list by mob item count
--
function MI3_SlashAction_SortByItem()
	MI3_SearchOptions.SortMode = "item"
	MI3_UpdateSearchResultList()
end -- end of MI3_SlashAction_SortByItem()


-----------------------------------------------------------------------------
-- MI3_SearchResult_Update()
--
-- Update contents of search results list based on current scroll bar
-- position. Update tooltip for selected mob if tooltip is visible.
--
function MI3_SearchResult_Update()
	FauxScrollFrame_Update( MI3_SearchResultSlider, MI3_NumMobsFound, 15, 14 );
	MI3_DisplaySearchResult()
end -- end of MI3_SearchResult_Update()


-----------------------------------------------------------------------------
-- MI3_ShowSearchResultTooltip()
--
-- Show mob tooltip for search result mob currently under mouse cursor.
--
function MI3_ShowSearchResultTooltip()
	local sliderPos = FauxScrollFrame_GetOffset(MI3_SearchResultSlider)
	local selection = tonumber(string.sub(this:GetName(), 17)) + sliderPos
	  
	if selection <= MI3_NumMobsFound then
		if MI3_SearchOptions.ListMode == "Mobs" then
			local index = MI3_SearchResultList[selection].idx
			local mobName, mobLevel = MI3_GetIndexComponents( index )
			-- create Mob data tooltip with full location info
			MI3_CreateTooltip( mobName, mobLevel, nil, true )
		elseif MI3_SearchOptions.ListMode == "Items" then
			GameTooltip_SetDefaultAnchor( GameTooltip, UIParent )
			local itemName = MI3_SearchResultList[selection].idx
			GameTooltip:SetText( MI3_SearchResultList[selection].col..itemName )
			MI3_BuildItemDataTooltip( itemName )
			GameTooltip:Show()
		end
	end
end  -- end of MI3_ShowSearchResultTooltip()


-----------------------------------------------------------------------------
-- MI3_HideSearchResultTooltip()
--
function MI3_HideSearchResultTooltip()
	MI3_HideTooltip()
end -- MI3_HideSearchResultTooltip()


-----------------------------------------------------------------------------
-- MI3_SearchTab_OnClick()
--
-- The "OnClick" event handler for the TAB buttons on the search result list.
-- These TAB buttons switch the list content between two modes: mob list
-- and item list
--
function MI3_SearchTab_OnClick(self)
	PanelTemplates_Tab_OnClick( self, MI3_SearchResultFrame )
	local selected = MI3_SearchResultFrame.selectedTab
	if selected == 1 then
		MI3_OptSortByValue:Enable()
		MI3_OptSortByItem:Enable()
		if MI3_NumMobsFound > 0 then
			MI3_OptDeleteSearch:Enable()
		else
			MI3_OptDeleteSearch:Disable()
		end
		MI3_SearchOptions.ListMode = "Mobs"
		MI3_UpdateSearchResultList( true )
	elseif selected == 2 then
		MI3_OptSortByValue:Disable()
		MI3_OptSortByItem:Disable()
		MI3_OptDeleteSearch:Disable()
		MI3_SearchOptions.ListMode = "Items"
		MI3_UpdateSearchResultList( true )
	end
end -- MI3_SearchTab_OnClick()


-----------------------------------------------------------------------------
-- MI3_SearchForMobs()
--
-- Search through a limited number of Mobs. Think function is meant to be
-- called repeatedly (in the background) to incrementally build the overall
-- search result list.
--
function MI3_SearchForMobs( searchLimit )
	local searchCount = 0
	for mobIndex, mobInfo in pairs(MobInfoDB) do
		if mobInfo.sf then
			searchCount = searchCount + 1
MI3_SearchCount = MI3_SearchCount + 1
			mobInfo.sf = nil 
			mobName, mobLevel = MI3_GetIndexComponents( mobIndex )
			mobData = MI3_CheckMob( mobInfo, mobName, mobLevel )
			-- if mob is identified as belonging into the search result its
			-- search result sorting position is calculated based on a ranking
			-- value which in turn is based on the search mode
			if mobData then
				rank, value = MI3_CalculateRank( mobData, mobLevel, MI3_SearchOptions.SortMode )
				MI3_NumMobsFound = MI3_NumMobsFound + 1
				-- insert mob at correct sorted position and store all info we need for printing the result list
				MI3_SearchResultList[MI3_NumMobsFound] = { idx=mobIndex, val=value, rank=rank }
				if mobData.mobType and mobData.mobType > 1 then
					MI3_SearchResultList[MI3_NumMobsFound].type = mobData.mobType
				end
			end
		end
		if searchCount > searchLimit then
			return false
		end
	end
	return true
end -- MI3_SearchForMobs()


-----------------------------------------------------------------------------
-- MI3_SearchOnUpdate()
--
-- OnUpdate is called periodically (about 45 times per second) by the WoW
-- client.
--
function MI3_SearchOnUpdate( time )
	if MI3_SearchMode == 1 then
		local finished = MI3_SearchForMobs( 400 )
		if ( finished ) then
			MI3_SearchMode = 0
			if MI3_NumMobsFound > 1 then
				table.sort( MI3_SearchResultList, function(a,b) return (a.rank > b.rank) end  )
			end
			MI3_DisplaySearchResult( MI3_SearchOptions.ListMode )
		else
			MI3_TxtSearchCount:SetText( MI_SubWhite.."(searching..."..MI3_SearchCount..")" )
		end
	end
end

-----------------------------------------------------------------------------
-- MI3_DeleteSearchResultMobs()
--
-- Delete all Mobs in the search result list from the MobInfo database.
-- This function is called when the user confirms the delete.
--
function MI3_DeleteSearchResultMobs()
	for idx, val in pairs(MI3_SearchResultList) do
		local mobIndex = val.idx
		MI3_DeleteMobData( mobIndex, true )
	end
	chattext( "search result deleted : "..MI3_NumMobsFound.." Mobs" )
	MI3_UpdateSearchResultList()
end -- MI3_DeleteSearchResultMobs()


