﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Skills", "esMX" )

if not L then return end

L["Professions"] = "Profesiones"
L["Secondary Skills"] = "Habilidades secundarias"
L["Riding"] = "Equitación"
