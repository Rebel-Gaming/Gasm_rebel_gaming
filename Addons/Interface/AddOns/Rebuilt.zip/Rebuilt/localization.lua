﻿------------
-- Locale --
------------

if (GetLocale() == "fr") then

	-- Buffs --
	REBUILT_HORNOFWINTER = "Cor de l'hiver"    
	REBUILT_STRENGTHOFEARTH = "Force de la Terre" 
	REBUILT_FREEZINGFOG = "Brouillard givrant"
	REBUILT_DEATHTRANCE = "Transe mortelle" 

	-- Chat --
	REBUILT_LOADED = " Chargé!"
	REBUILT_FORCOMMANDS = " for commands."
	REBUILT_RESETDISPLAY = " to reset display"
	REBUILT_OPENOPTIONS = " to open Options"
	REBUILT_HIDEMINIMAP = " to hide the mini map icon"
	REBUILT_SHOWMINIMAP = " to show the mini map icon"
	REBUILT_DEATHGRIP = "Poigne de la mort"
	
	-- Talents --
	REBUILT_RUNICPOWERMASTERY = "Maîtrise de la puissance runique"
	REBUILT_BLOODYSTRIKES = "Frappes sanglantes"
	REBUILT_SUBVERSION = "Subversion"	
	REBUILT_OUTBREAK = "Poussée de fièvre"
	REBUILT_KILLINGMACHINE = "Machine à tuer"
	REBUILT_DEATHCHILL = "Froid de la mort"
	REBUILT_VICIOUSSTRIKES = "Attaques vicieuses"
	REBUILT_DEATHCOIL = "Voile mortel"
	REBUILT_MORBIDITY = "Morbidité"
	REBUILT_MIGHTOFMOGRAINE = "Puissance de Mograine"
	REBUILT_ANNIHILATION = "Annihilation"
	REBUILT_RIME = "Frimas"
	REBUILT_GUILEOFGOREFIEND = "Ruse de Fielsang"
	REBUILT_GLACIERROT = "Pourriture des glaciers"
	REBUILT_MERCILESSCOMBAT = "Combat impitoyable"
	REBUILT_BLACKICE = "Glace noire"
	REBUILT_IMPURITY = "Impureté"
	REBUILT_BLOODGORGED = "Gorgé de sang"

	-- Abilities --
	REBUILT_ICYTOUCH = "Toucher de glace"
	REBUILT_PLAGUESTRIKE = "Frappe de peste"
	REBUILT_BLOODSTRIKE = "Frappe de sang"
	REBUILT_BLOODPLAGUE = "Peste de sang"
	REBUILT_FROSTFEVER = "Fièvre de givre"
	REBUILT_OBLITERATE = "Anéantissement"
	REBUILT_HEARSTRIKE = "Frappe au coeur"
	REBUILT_DANCINGRUNEWEAPON = "Arme runique dansante"
	REBUILT_HOWLINGBLAST = "Rafale hurlante"
	REBUILT_BONESHIELD = "Bouclier d'os"
	REBUILT_UNBREAKABLEARMOR = "Armure incassable"
	REBUILT_FROSTSTRIKE = "Frappe de givre"
	REBUILT_UNHOLYBLIGHT = "Chancre impie"
	REBUILT_SCOURGESTRIKE = "Frappe du Fléau"
	REBUILT_SUMMONGARGOYLE = "Invocation d'une gargouille"
	REBUILT_ELEMENTAL = "Élémentaire"
	REBUILT_HYSTERIA = "Hystérie"

	-- v1.2 locals
	REBUILT_MINDFREEZE = "Mind Freeze"
	REBUILT_STRANGLUATE = "Strangulate"
	REBUILT_ANTIMAGICZONE = "Anti-Magic Zone"
	REBUILT_RUNESTRIKE = "Rune Strike"
	REBUILT_DEATHSTRIKE = "Death Strike"
	
else
-- US English
	-- Buffs --
	REBUILT_HORNOFWINTER = "Horn of Winter"
	REBUILT_STRENGTHOFEARTH = "Strength of Earth"
	REBUILT_FREEZINGFOG = "Freezing Fog"
	REBUILT_DEATHTRANCE = "Death Trance"

	-- Chat --
	REBUILT_LOADED = " Loaded!"
	REBUILT_FORCOMMANDS = " for commands."
	REBUILT_RESETDISPLAY = " to reset display"
	REBUILT_OPENOPTIONS = " to open Options"
	REBUILT_HIDEMINIMAP = " to hide the mini map icon"
	REBUILT_SHOWMINIMAP = " to show the mini map icon"
	REBUILT_DEATHGRIP = "Death Grip"
	
	-- Talents --
	REBUILT_RUNICPOWERMASTERY = "Runic Power Mastery"
	REBUILT_BLOODYSTRIKES = "Bloody Strikes"
	REBUILT_SUBVERSION = "Subversion"	
	REBUILT_OUTBREAK = "Outbreak"
	REBUILT_KILLINGMACHINE = "Killing Machine"
	REBUILT_DEATHCHILL = "Deathchill"
	REBUILT_VICIOUSSTRIKES = "Vicious Strikes"
	REBUILT_DEATHCOIL = "Death Coil"
	REBUILT_MORBIDITY = "Morbidity"
	REBUILT_MIGHTOFMOGRAINE = "Might of Mograine"
	REBUILT_ANNIHILATION = "Annihilation"
	REBUILT_RIME = "Rime"
	REBUILT_GUILEOFGOREFIEND = "Guile of Gorefiend"
	REBUILT_GLACIERROT = "Glacier Rot"
	REBUILT_MERCILESSCOMBAT = "Merciless Combat"
	REBUILT_BLACKICE = "Black Ice"
	REBUILT_IMPURITY = "Impurity"
	REBUILT_BLOODGORGED = "Blood Gorged"

	-- Abilities --
	REBUILT_ICYTOUCH = "Icy Touch"
	REBUILT_PLAGUESTRIKE = "Plague Strike"
	REBUILT_BLOODSTRIKE = "Blood Strike"
	REBUILT_BLOODPLAGUE = "Blood Plague"
	REBUILT_FROSTFEVER = "Frost Fever"
	REBUILT_OBLITERATE = "Obliterate"
	REBUILT_HEARSTRIKE = "Heart Strike"
	REBUILT_DANCINGRUNEWEAPON = "Dancing Rune Weapon"
	REBUILT_HOWLINGBLAST = "Howling Blast"
	REBUILT_BONESHIELD = "Bone Shield"
	REBUILT_UNBREAKABLEARMOR = "Unbreakable Armor"
	REBUILT_FROSTSTRIKE = "Frost Strike"
	REBUILT_UNHOLYBLIGHT = "Unholy Blight"
	REBUILT_SCOURGESTRIKE = "Scourge Strike"
	REBUILT_SUMMONGARGOYLE = "Summon Gargoyle"
	REBUILT_ELEMENTAL = "Elemental"
	REBUILT_HYSTERIA = "Hysteria"

	-- v1.2 locals
	REBUILT_MINDFREEZE = "Mind Freeze"
	REBUILT_STRANGLUATE = "Strangulate"
	REBUILT_ANTIMAGICZONE = "Anti-Magic Zone"
	REBUILT_RUNESTRIKE = "Rune Strike"
	REBUILT_DEATHSTRIKE = "Death Strike"

end