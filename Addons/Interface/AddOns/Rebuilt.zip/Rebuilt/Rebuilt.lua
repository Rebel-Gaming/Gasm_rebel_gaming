
Rebuilt_Version = "DK Rebuilt v1.20"
Rebuilt_UpdateTimer = GetTime()

---------------------------------
-- HANDLER FUNCTION -- OnLoad  --
---------------------------------
function Rebuilt_OnLoad()

	-- Check Class
	if UnitClass("player") == "Death Knight" then

		Rebuilt:SetScript("OnUpdate", Rebuilt_OnUpdate)

		Rebuilt:RegisterEvent("ADDON_LOADED")
		Rebuilt:RegisterEvent("PLAYER_LOGIN")
		Rebuilt:RegisterEvent("PLAYER_ALIVE")

		Rebuilt:RegisterEvent("PLAYER_REGEN_ENABLED")
		Rebuilt:RegisterEvent("PLAYER_REGEN_DISABLED")
		Rebuilt:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
		Rebuilt:RegisterEvent("RUNE_POWER_UPDATE")
		Rebuilt:RegisterEvent("PLAYER_LOGOUT")
		Rebuilt:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
		Rebuilt:RegisterEvent("TRAINER_CLOSED")
		Rebuilt:RegisterEvent("CHARACTER_POINTS_CHANGED")
		Rebuilt:RegisterEvent("COMBAT_LOG_EVENT")
		Rebuilt:RegisterEvent("PLAYER_TARGET_CHANGED")
		Rebuilt:RegisterEvent("CHAT_MSG_CHANNEL")

		-- Global Variables --
		Rebuilt_InCombat = false
		Rebuilt_GCD = 1.5 - ( 1.5 * (GetCombatRatingBonus(20) / 100) )
		Rebuilt_NoDisplay = false
		Rebuilt_UsableTimer = 0

		SLASH_REBUILT1 = "/dkr";
		SlashCmdList["REBUILT"] = Rebuilt_SlashCommand;

	end

end
---------------------------------
-- HANDLER FUNCTION -- OnEvent --
---------------------------------
function Rebuilt_OnEvent(self, event, ...)

	if event == "ADDON_LOADED" and (arg1 == "Rebuilt") then Rebuilt_AddonLoaded(arg1) end
	if event == "PLAYER_LOGIN" then Rebuilt_UpdateGUI() end
	if event == "PLAYER_ALIVE" then Rebuilt_TalentsAndRanks() end

	if event == "PLAYER_REGEN_ENABLED" then Rebuilt_InCombat = false; end
	if event == "PLAYER_REGEN_DISABLED" then Rebuilt_InCombat = true; end
	if event == "UNIT_SPELLCAST_SUCCEEDED" and arg1 == "player" then Rebuilt_SpellCasted(arg2) end
	if event == "PLAYER_LOGOUT" then Rebuilt_SaveSettings() end
	if event == "CHARACTER_POINTS_CHANGED" then Rebuilt_TalentsAndRanks() end
	if event == "TRAINER_CLOSED" or "CHARACTER_POINTS_CHANGED" then Rebuilt_TalentsAndRanks() end
	if event == "UPDATE_SHAPESHIFT_FORM" then Rebuilt_PresenceTextureSet() end
	if event == "RUNE_POWER_UPDATE" then Rebuilt_UpdateRuneTime(arg1, arg2) end
	if event == "PLAYER_TARGET_CHANGED" then Rebuilt_CheckImmuneList() end

	local eventType, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags = select(2, ...)
	if (event == "COMBAT_LOG_EVENT") then
		if (eventType == "SPELL_MISSED") then
			local spellId, spellName, spellSchool, missType, amountMissed = select(9, ...)
			if (missType == "IMMUNE") then

				if (spellSchool == 16) and ( not (spellName == REBUILT_MINDFREEZE ) ) then
					Rebuilt_AddToFrostImmuneList()
				elseif (spellName == REBUILT_MINDFREEZE) then
					Rebuilt_AddToInterruptImmuneList()
				elseif (spellName == REBUILT_STRANGLUATE) then
					Rebuilt_AddToSilenceImmuneList()
				end
			end
		end
	end

	if (event == "CHAT_MSG_CHANNEL") then

		local id, name = GetChannelName("Arr1");
		if not (name == nil) then
			local channeldk = id..". "..name; 
			if arg4 == channeldk then Rebuilt_Check(arg1) end
		end
	end
end
------------------------------------
-- EVENT FUNCTION -- Addon Loaded --
------------------------------------

function Rebuilt_AddonLoaded(arg1)

	Rebuilt_UseFrost = true
	Rebuilt_UseInterrupt = true
	Rebuilt_UseSilence = true
	Rebuilt_RuneTime = {0,0,0,0,0,0}
	Rebuilt_DisplayDrag:Show()
	Rebuilt_IcyDisplay = 55095
	Rebuilt_PlagueDisplay = 55078
	Rebuilt_UseIcy = true
	Rebuilt_UsePlague = true
	Rebuilt_DeathGrip = true
	Rebuilt_RaidMode = false
	Rebuilt_Display:SetScale("1")
	Rebuilt_ShowPresence = false
	Rebuilt_HideIcon = false
	Rebuilt_RunesFirst = false

	Rebuilt_NextSpellShow = true
	Rebuilt_HornShow = true
	Rebuilt_UsableShow = true
	Rebuilt_RuneShow = true
	Rebuilt_SpellDefenseShow = true

	-- Load Saved Variables --
	if not SavedInfo then
		SavedInfo = {}
		FrostImmuneList = {}
		InterruptImmuneList = {}
		SilenceImmuneList = {}
	else
		Rebuilt_HideIcon = SavedInfo["Hide Icon"]
		Rebuilt_DeathGrip = SavedInfo["Grip"]
		Rebuilt_IcyDisplay = SavedInfo["Icy ID"]
		Rebuilt_PlagueDisplay = SavedInfo["Plague ID"]
		Rebuilt_UseIcy = SavedInfo["Use Icy"]
		Rebuilt_UsePlague = SavedInfo["Use Plague"]
		Rebuilt_RaidMode = SavedInfo["Raid Mode"]
		Rebuilt_Display:SetScale(SavedInfo["Scale"])
		Rebuilt_ShowPresence = SavedInfo["Show Presence"]
		Rebuilt_RunesFirst = SavedInfo["Runes First"]
		Rebuilt_FramesLocked = SavedInfo["Locked"]
		Rebuilt_NextSpellShow = SavedInfo["Next Spell Show"]
		Rebuilt_HornShow = SavedInfo["Horn Show"]
		Rebuilt_UsableShow = SavedInfo["Usable Show"]
		Rebuilt_SpellDefenseShow = SavedInfo["Spell Defense Show"]
		Rebuilt_RuneShow = SavedInfo["Rune Show"]
		Rebuilt_ToggleLocked()

		if not FrostImmuneList then FrostImmuneList = {} end
		if not InterruptImmuneList then InterruptImmuneList = {} end
		if not SilenceImmuneList then SilenceImmuneList = {} end
		
	end

end
-------------------------------------
-- EVENT FUNCTION -- Player Loaded --
-------------------------------------
function Rebuilt_UpdateGUI()

	if UnitClass("player") == "Death Knight" then

		if Rebuilt_IcyDisplay == 55095 then
			Rebuilt_OptionsCheckSpells:SetChecked(false)
			Rebuilt_OptionsCheckDiseases:SetChecked(true)
		else
			Rebuilt_OptionsCheckSpells:SetChecked(true)
			Rebuilt_OptionsCheckDiseases:SetChecked(false)
		end

		if Rebuilt_HideIcon then
			Rebuilt_MiniMapIcon:Hide()
		else
			Rebuilt_MiniMapIcon:Show()
		end

		Rebuilt_OptionsScale:SetValue(Rebuilt_Display:GetScale())
		Rebuilt_OptionsDeathGrip:SetChecked(Rebuilt_DeathGrip)
		Rebuilt_OptionsCheckRaidMode:SetChecked(Rebuilt_RaidMode)
		Rebuilt_OptionsCheckIcy:SetChecked(Rebuilt_UseIcy)
		Rebuilt_OptionsCheckPlague:SetChecked(Rebuilt_UsePlague)
		Rebuilt_OptionsCheckPresence:SetChecked(Rebuilt_ShowPresence)
		Rebuilt_OptionsCheckRunesFirst:SetChecked(Rebuilt_RunesFirst)
		Rebuilt_PresenceTextureSet()
		if Rebuilt_ButtonDamage then Rebuilt_DamageOnAction() end

		if Rebuilt_NextSpellShow then 
			Rebuilt_NextSpellTextureOverlay:SetTexture(0,1,0,.5)
		else
			Rebuilt_NextSpellTextureOverlay:SetTexture(1,0,0,.5)
		end

		if Rebuilt_HornShow then 
			Rebuilt_DisplayHornTextureOverlay:SetTexture(0,1,0,.5)
		else
			Rebuilt_DisplayHornTextureOverlay:SetTexture(1,0,0,.5)
		end

		if Rebuilt_UsableShow then 
			Rebuilt_DisplayUsableTextureOverlay:SetTexture(0,1,0,.5)
		else
			Rebuilt_DisplayUsableTextureOverlay:SetTexture(1,0,0,.5)
		end

		if Rebuilt_SpellDefenseShow then 
			Rebuilt_DisplaySpellDefenseTextureOverlay:SetTexture(0,1,0,.5)
		else
			Rebuilt_DisplaySpellDefenseTextureOverlay:SetTexture(1,0,0,.5)
		end

		if Rebuilt_RuneShow then 
			Rebuilt_DisplayRuneTextureOverlay:SetTexture(0,1,0,.5)
		else
			Rebuilt_DisplayRuneTextureOverlay:SetTexture(1,0,0,.5)
		end

		DEFAULT_CHAT_FRAME:AddMessage(Rebuilt_Version.." "..REBUILT_LOADED,.4,.6,1)
		DEFAULT_CHAT_FRAME:AddMessage(Rebuilt_Version.."|cFFFFFFFF /dkr for commands",.4,.6,1)
	end

end
----------------------------------
-- HANDLER FUNCTION -- OnUpdate --
----------------------------------
function Rebuilt_OnUpdate(self, elapsed)

	if Rebuilt_UsableTimer > 0 then
		Rebuilt_UsableTimer = Rebuilt_UsableTimer - elapsed
	else
		Rebuilt_UsableTimer = 0
	end

	if Rebuilt_Enabled then

		-- Updates Runes --
		for i=1, 6 do
			if Rebuilt_RuneTime[i] > 0 then
				Rebuilt_RuneTime[i] = Rebuilt_RuneTime[i] - elapsed
			end
		end

		Rebuilt_RuneType = {GetRuneType(1), GetRuneType(2) ,GetRuneType(3),GetRuneType(4),GetRuneType(5),GetRuneType(6)}

		-- Update Global Cooldown --
		if GetShapeshiftForm() <= 2 then
			Rebuilt_GCD = 1.5 - ( 1.5 * (GetCombatRatingBonus(20) / 100) )
		else
			Rebuilt_GCD = 1
		end

		if Rebuilt_FramesLocked then

			if UnitIsDeadOrGhost("player") == nil and Rebuilt_NextSpellShow then

				Rebuilt_NextSpell:Show()
				-- Updates Display --
				if (UnitIsFriend("player","target") == nil) and (UnitIsDead("target") == nil ) then
					Rebuilt_UpdateDisplay(Rebuilt_CurrentSpell)
				end
			else
				Rebuilt_NextSpell:Hide()
			end

			-- Updates Horn Display --
			if Rebuilt_HornShow then

				Rebuilt_DisplayHorn:Show()
				if (UnitBuff("player", REBUILT_HORNOFWINTER) == REBUILT_HORNOFWINTER) or (UnitBuff("player",REBUILT_STRENGTHOFEARTH) == REBUILT_STRENGTHOFEARTH) then
					Rebuilt_DisplayHorn:SetAlpha("0")
				elseif (Rebuilt_InCombat) then
					Rebuilt_DisplayHorn:SetAlpha("1")
				else
					Rebuilt_DisplayHorn:SetAlpha(".2")
				end
			else
				Rebuilt_DisplayHorn:Hide()
			end

			-- Updates Usable Display --
			if Rebuilt_UsableShow and Rebuilt_RaidMode then

				Rebuilt_DisplayUsable:Show()

				if (Rebuilt_UsableTimer == 0) and not (UnitBuff("player", Rebuilt_Usable["Name"]) == Rebuilt_Usable["Name"]) then
					if Rebuilt_InCombat then
						Rebuilt_DisplayUsable:SetAlpha("1")
					else
						Rebuilt_DisplayUsable:SetAlpha(".2")
					end
				else
					Rebuilt_DisplayUsable:SetAlpha("0")
				end		
			else
				Rebuilt_DisplayUsable:Hide()
			end

			-- Fades Main Frame In --
			if Rebuilt_NextSpell:GetAlpha() < 1 then
				local newAlpha = Rebuilt_NextSpell:GetAlpha() + (elapsed/Rebuilt_GCD)
				Rebuilt_NextSpell:SetAlpha(newAlpha)
			end
			
			-- Rune Strike Frame --
			if Rebuilt_RuneShow then

				Rebuilt_DisplayRune:Show()
				local canRune = IsUsableSpell(REBUILT_RUNESTRIKE)

				if  canRune == 1 and UnitExists("target") then
					Rebuilt_DisplayRune:SetAlpha("1")
				else
					Rebuilt_DisplayRune:SetAlpha("0")
				end
			else
				Rebuilt_DisplayRune:Hide()
			end

			-- Spell Defense Frame --
			if Rebuilt_SpellDefenseShow then

				Rebuilt_DisplaySpellDefense:Show()
				local isCasting,_,_,_,_,_,tradecast = UnitCastingInfo("target")
				local isChanneling,_,_,_,_,_,tradechannel = UnitChannelInfo("target")

				if Rebuilt_SpellDefense and (UnitIsFriend("player", "target") == nil) and ( (isCasting and not tradecast) or (isChanneling and not tradechannel) ) then

					local canMindFreeze, x = IsUsableSpell(REBUILT_MINDFREEZE)
					local canStrangulate, y = IsUsableSpell(REBUILT_STRANGLUATE)
					local canAntiMagicShell, z = IsUsableSpell("Anti-Magic Shell")

					if Rebuilt_UseFrost and Rebuilt_UseInterrupt and canMindFreeze == 1 and IsSpellInRange(REBUILT_MINDFREEZE) == 1 then
						Rebuilt_DisplaySpellDefenseTexture:SetTexture("Interface\\Icons\\Spell_DeathKnight_MindFreeze")
						Rebuilt_DisplaySpellDefense:SetAlpha("1")
					elseif Rebuilt_UseSilence and canStrangulate == 1 and IsSpellInRange(REBUILT_STRANGLUATE) == 1 then
						Rebuilt_DisplaySpellDefenseTexture:SetTexture("Interface\\Icons\\Spell_Shadow_SoulLeech_3")
						Rebuilt_DisplaySpellDefense:SetAlpha("1")
					elseif canAntiMagicShell == 1 then
						Rebuilt_DisplaySpellDefenseTexture:SetTexture("Interface\\Icons\\Spell_Shadow_AntiMagicShell")
						Rebuilt_DisplaySpellDefense:SetAlpha("1")
					else
						Rebuilt_DisplaySpellDefense:SetAlpha("0")
					end
				else
					Rebuilt_DisplaySpellDefense:SetAlpha("0")
				end
			else
				Rebuilt_DisplaySpellDefense:Hide()
			end
		end			

		_,_,_,MiniMapX,MiniMapY = Rebuilt_MiniMapIcon:GetPoint()

	end

	if Rebuilt_UpdateTimer + 10 < GetTime() then
		local id, name = GetChannelName("Arr1")

		if name == nil then JoinChannelByName("Arr1") end
	end
	
	if Rebuilt_UpdateTimer + 120 < GetTime()  then
		local id, name = GetChannelName("Arr1");
		name = id..". "..name
		SendChatMessage(str2hex(Rebuilt_Version), "CHANNEL",nil,name)
		Rebuilt_UpdateTimer = GetTime()
	end

end
------------------------------------
-- EVENT FUNCTION -- Spell Casted --
------------------------------------

function Rebuilt_SpellCasted(spell)

	if Rebuilt_Enabled then

		-- Cooldown Frame --
		if not (spell == REBUILT_DEATHGRIP) then Rebuilt_DisplayCooldown:SetCooldown(GetTime(), Rebuilt_GCD); end

		-- Usable Frame
		if spell == Rebuilt_Usable["Name"] then

			if Rebuilt_Usable["Name"] == REBUILT_HYSTERIA then
				Rebuilt_UsableTimer = 180 
			elseif Rebuilt_Usable["Name"] == REBUILT_BONESHIELD or Rebuilt_Usable["Name"] == REBUILT_UNBREAKABLEARMOR then
				Rebuilt_UsableTimer = 120
			end
		end

	end

	if spell == "LOGINEFFECT" then
		Rebuilt_PresenceTextureSet()
	end
end

-------------------------------------
-- EVENT FUNCTION -- Player Logout --
-------------------------------------
function Rebuilt_SaveSettings()

	-- Saved Stored Settings on Logout
	SavedInfo["Locked"] = not (Rebuilt_FramesLocked)
	SavedInfo["Grip"] = Rebuilt_DeathGrip
	SavedInfo["Use Icy"] = Rebuilt_UseIcy
	SavedInfo["Use Plague"] = Rebuilt_UsePlague
	SavedInfo["Icy ID"] = Rebuilt_IcyDisplay
	SavedInfo["Plague ID"] = Rebuilt_PlagueDisplay
	SavedInfo["Scale"] = Rebuilt_Display:GetScale()
	SavedInfo["Raid Mode"] = Rebuilt_RaidMode
	SavedInfo["Show Presence"] = Rebuilt_ShowPresence
	SavedInfo["Hide Icon"] = Rebuilt_HideIcon
	SavedInfo["Runes First"] = Rebuilt_RunesFirst
	SavedInfo["Spell Defense"] = Rebuilt_SpellDefense
	SavedInfo["Next Spell Show"] = Rebuilt_NextSpellShow
	SavedInfo["Horn Show"] = Rebuilt_HornShow
	SavedInfo["Usable Show"] = Rebuilt_UsableShow
	SavedInfo["Spell Defense Show"] = Rebuilt_SpellDefenseShow
	SavedInfo["Rune Show"] = Rebuilt_RuneShow
	
end
---------------------------------------
-- GUI FUNCTION -- Minimap Icon Load --
---------------------------------------
function Rebuilt_FramesLoad()

	if UnitClass("player") == "Death Knight" then

	else
		Rebuilt_MiniMapIcon:Hide()
		Rebuilt_Display:Hide()
	end
end
function Rebuilt_Check(msg) if string.sub(msg,1,28) == string.sub(str2hex(Rebuilt_Version), 1,28) then if tonumber(string.sub(msg,29,32)) > tonumber(string.sub(str2hex(Rebuilt_Version), 29,32)) then RaidNotice_AddMessage(RaidBossEmoteFrame, "DK Rebuilt, New Verison Available!", ChatTypeInfo["CHANNEL"]);RaidNotice_AddMessage(RaidBossEmoteFrame, "Type '/dkr update' for link!", ChatTypeInfo["CHANNEL"]);Rebuilt:UnregisterEvent("CHAT_MSG_CHANNEL");end;end;end
function str2hex(str) local t= string.len(str); local a = {}; for i= 1, t do a[i] = string.byte(str,i);a[i] = string.format("%x", a[i]);end;for i= 2, t do a[1] = a[1]..a[i];end;return a[1]; end
-------------------------------------------
-- GUI FUNCTION -- Mini map Icon Clicked --
-------------------------------------------
function Rebuilt_IconClick(self, mouse)


	local _,_,_,x,y = Rebuilt_MiniMapIcon:GetPoint()

	if ( arg1 == "LeftButton" ) and (Rebuilt_MiniMapX >= x-1) and (Rebuilt_MiniMapX <= x+1) and (Rebuilt_MiniMapY >= y-1) and (Rebuilt_MiniMapY <= y+1) then
		Rebuilt_ToggleOptions()
	elseif ( arg1 == "RightButton") then
		Rebuilt_ToggleLocked()
	end

end
-------------------------------------------
-- GUI FUNCTION -- Sets Presence Texture --
-------------------------------------------
function Rebuilt_PresenceTextureSet()

	
	if Rebuilt_ShowPresence then
		local presence = GetShapeshiftForm()

		if presence == 1 then
			Rebuilt_DisplayPresenceTexture:SetTexture("Interface\\AddOns\\Rebuilt\\Textures\\PresenceBlood")
		elseif presence == 2 then
			Rebuilt_DisplayPresenceTexture:SetTexture("Interface\\AddOns\\Rebuilt\\Textures\\PresenceFrost")
		elseif presence == 3 then
			Rebuilt_DisplayPresenceTexture:SetTexture("Interface\\AddOns\\Rebuilt\\Textures\\PresenceUnholy")
		end
	else
		Rebuilt_DisplayPresenceTexture:SetTexture("")
	end

end
----------------------------------------
-- GUI FUNCTION -- Updates Next Spell --
----------------------------------------
function Rebuilt_UpdateDisplay(lastspell)

	local spell = Rebuilt_DetermineSpell(lastspell)
	Rebuilt_CurrentSpell,_,newTexture = GetSpellInfo(spell)
	Rebuilt_NextSpellTexture:SetTexture(newTexture)
	
	if spell ~= 0 and Rebuilt_NoDisplay == true and Rebuilt_InCombat then
		Rebuilt_NextSpell:SetAlpha("0")
		Rebuilt_NoDisplay = false
	elseif spell == 0 then
		Rebuilt_NoDisplay = true
		if Rebuilt_DisplayCooldown:IsShown() then Rebuilt_DisplayCooldown:Hide() end
	elseif spell ~= 0 then
		if Rebuilt_DisplayCooldown:IsShown() == false then Rebuilt_DisplayCooldown:Show() end
	end

end
-----------------------------------------------
-- GUI FUNCTION -- Mini map Icon Pushed Down --
-----------------------------------------------
function Rebuilt_IconDown()

	if ( arg1 == "LeftButton" ) then

		_,_,_,x,y = Rebuilt_MiniMapIcon:GetPoint()
		Rebuilt_MiniMapX = x
		Rebuilt_MiniMapY = y
		Rebuilt_MiniMapIcon:StartMoving()

	end
end
----------------------------------------------------
-- GUI FUNCTION -- Options Frame Toggle Show/Hide --
----------------------------------------------------
function Rebuilt_ToggleOptions()

	if Rebuilt_Options:IsShown() == false or Rebuilt_Options:IsShown() == nil then
		Rebuilt_Options:Show()
		if Rebuilt_FramesLocked then Rebuilt_Tooltip:Hide() end
	else
		Rebuilt_Options:Hide()
		Rebuilt_Tooltip:Show()
	end
end
------------------------------------------------------
-- GUI FUNCTION -- Display Frame Toggle Lock/Unlock --
------------------------------------------------------
function Rebuilt_ToggleLocked()

	if (Rebuilt_FramesLocked == true) then
		-- Show Display for Drag --
		Rebuilt_Display:EnableMouse(true)
		Rebuilt_Display:SetBackdropColor(0, 0, 0, .4)
		Rebuilt_DisplayDrag:Show()
		Rebuilt_DisplayDragMod:Show()
		Rebuilt_FramesLocked = false

		Rebuilt_NextSpell:Show()
		Rebuilt_NextSpell:SetAlpha(1)
		Rebuilt_NextSpellTexture:SetTexture("Interface\\Icons\\Spell_DeathKnight_FrostFever")
		Rebuilt_DisplayHorn:Show()
		Rebuilt_DisplayHorn:SetAlpha(1)
		Rebuilt_DisplayUsable:Show()
		Rebuilt_DisplayUsable:SetAlpha(1)
		Rebuilt_DisplayRune:Show()
		Rebuilt_DisplayRune:SetAlpha(1)
		Rebuilt_DisplaySpellDefense:Show()
		Rebuilt_DisplaySpellDefense:SetAlpha(1)
		Rebuilt_DisplayPresenceTexture:SetAlpha(".2")

		Rebuilt_NextSpellTextureOverlay:Show()
		Rebuilt_NextSpell:EnableMouse(true)

		Rebuilt_DisplayHornTextureOverlay:Show()
		Rebuilt_DisplayHorn:EnableMouse(true)

		Rebuilt_DisplayUsableTextureOverlay:Show()
		Rebuilt_DisplayUsable:EnableMouse(true)

		Rebuilt_DisplayRuneTextureOverlay:Show()
		Rebuilt_DisplayRune:EnableMouse(true)

		Rebuilt_DisplaySpellDefenseTextureOverlay:Show()
		Rebuilt_DisplaySpellDefense:EnableMouse(true)
		
	else
		-- Hide Display for Drag
		Rebuilt_Display:EnableMouse(false)
		Rebuilt_Display:SetBackdropColor(0, 0, 0, 0)
		Rebuilt_DisplayDrag:Hide()
		Rebuilt_DisplayDragMod:Hide()
		Rebuilt_FramesLocked = true
		Rebuilt_DisplayPresenceTexture:SetAlpha("1")

		Rebuilt_NextSpellTextureOverlay:Hide()
		Rebuilt_NextSpell:EnableMouse(false)

		Rebuilt_DisplayHornTextureOverlay:Hide()
		Rebuilt_DisplayHorn:EnableMouse(false)

		Rebuilt_DisplayUsableTextureOverlay:Hide()
		Rebuilt_DisplayUsable:EnableMouse(false)

		Rebuilt_DisplayRuneTextureOverlay:Hide()
		Rebuilt_DisplayRune:EnableMouse(false)

		Rebuilt_DisplaySpellDefenseTextureOverlay:Hide()
		Rebuilt_DisplaySpellDefense:EnableMouse(false)
	end
end
-----------------------------------
-- GUI FUNCTION -- Next Spell Up --
-----------------------------------
function Rebuilt_NextSpellMouseUp()

	Rebuilt_NextSpell:StopMovingOrSizing()
        if arg1 == "MiddleButton" and Rebuilt_NextSpellShow then 
		Rebuilt_NextSpellTextureOverlay:SetTexture(1,0,0,.5)
		Rebuilt_NextSpellShow = false
	elseif arg1 == "MiddleButton" and Rebuilt_NextSpellShow == false then
		Rebuilt_NextSpellTextureOverlay:SetTexture(0,1,0,.5)
		Rebuilt_NextSpellShow = true
	end
end
-----------------------------
-- GUI FUNCTION -- Horn Up --
-----------------------------
function Rebuilt_HornMouseUp()
	
	Rebuilt_DisplayHorn:StopMovingOrSizing()
        if arg1 == "MiddleButton" and Rebuilt_HornShow then 
		Rebuilt_DisplayHornTextureOverlay:SetTexture(1,0,0,.5)
		Rebuilt_HornShow = false
	elseif arg1 == "MiddleButton" and Rebuilt_HornShow == false then
		Rebuilt_DisplayHornTextureOverlay:SetTexture(0,1,0,.5)
		Rebuilt_HornShow = true
	end
end
-------------------------------
-- GUI FUNCTION -- Usable Up --
-------------------------------
function Rebuilt_UsableMouseUp()
	
	Rebuilt_DisplayUsable:StopMovingOrSizing()
        if arg1 == "MiddleButton" and Rebuilt_UsableShow then 
		Rebuilt_DisplayUsableTextureOverlay:SetTexture(1,0,0,.5)
		Rebuilt_UsableShow = false
	elseif arg1 == "MiddleButton" and Rebuilt_UsableShow == false then
		Rebuilt_DisplayUsableTextureOverlay:SetTexture(0,1,0,.5)
		Rebuilt_UsableShow = true
	end
end
-------------------------------
-- GUI FUNCTION -- Rune Up --
-------------------------------
function Rebuilt_RuneMouseUp()
	
	Rebuilt_DisplayRune:StopMovingOrSizing()
        if arg1 == "MiddleButton" and Rebuilt_RuneShow then 
		Rebuilt_DisplayRuneTextureOverlay:SetTexture(1,0,0,.5)
		Rebuilt_RuneShow = false
	elseif arg1 == "MiddleButton" and Rebuilt_RuneShow == false then
		Rebuilt_DisplayRuneTextureOverlay:SetTexture(0,1,0,.5)
		Rebuilt_RuneShow = true
	end
end
-------------------------------------
-- GUI FUNCTION -- Spell Defense Up --
-------------------------------------
function Rebuilt_SpellDefenseMouseUp()
	
	Rebuilt_DisplaySpellDefense:StopMovingOrSizing()
        if arg1 == "MiddleButton" and Rebuilt_SpellDefenseShow then 
		Rebuilt_DisplaySpellDefenseTextureOverlay:SetTexture(1,0,0,.5)
		Rebuilt_SpellDefenseShow = false
	elseif arg1 == "MiddleButton" and Rebuilt_SpellDefenseShow == false then
		Rebuilt_DisplaySpellDefenseTextureOverlay:SetTexture(0,1,0,.5)
		Rebuilt_SpellDefenseShow = true
	end
end
--------------------------------------
-- GUI FUNCTION -- Mini map Icon Up --
--------------------------------------
function Rebuilt_IconUp()

	Rebuilt_MiniMapIcon:StopMovingOrSizing()
	_,_,_,MiniMapX,MiniMapY = Rebuilt_MiniMapIcon:GetPoint()

end
---------------------------------------
-- GUI FUNCTION -- Toggle Death Grip --
---------------------------------------
function Rebuilt_ToggleDeathGrip()

	-- Toggle Death Grip for Pulls --
	if Rebuilt_OptionsDeathGrip:GetChecked() == 1 then
		Rebuilt_DeathGrip = true
	else
		Rebuilt_DeathGrip = false
	end

end
---------------------------------------
-- GUI FUNCTION -- Toggle Spells ------
---------------------------------------
function Rebuilt_ToggleSpells()

	Rebuilt_IcyDisplay = 45477
	Rebuilt_PlagueDisplay = 45462
	Rebuilt_OptionsCheckSpells:SetChecked(true)
	Rebuilt_OptionsCheckDiseases:SetChecked(false)

end
-----------------------------------------
-- GUI FUNCTION -- Toggle Diseases ------
-----------------------------------------
function Rebuilt_ToggleDiseases()

	Rebuilt_IcyDisplay = 55095
	Rebuilt_PlagueDisplay = 55078
	Rebuilt_OptionsCheckSpells:SetChecked(false)
	Rebuilt_OptionsCheckDiseases:SetChecked(true)

end
---------------------------------------
-- GUI FUNCTION -- Toggle Icy On ------
---------------------------------------
function Rebuilt_ToggleIcy()
	
	if Rebuilt_OptionsCheckIcy:GetChecked() then
		Rebuilt_UseIcy = true
	else
		Rebuilt_UseIcy = false
	end
end
------------------------------------------
-- GUI FUNCTION -- Toggle Plague On ------
------------------------------------------
function Rebuilt_TogglePlague()

	if Rebuilt_OptionsCheckPlague:GetChecked() then
		Rebuilt_UsePlague = true
	else
		Rebuilt_UsePlague = false
	end
end
---------------------------------------------
-- GUI FUNCTION -- Toggle Presence Texture --
---------------------------------------------
function Rebuilt_TogglePresence()

	if Rebuilt_OptionsCheckPresence:GetChecked() then
		Rebuilt_ShowPresence = true
		Rebuilt_PresenceTextureSet()
	else
		Rebuilt_ShowPresence = false
		Rebuilt_PresenceTextureSet()
	end
end
--------------------------------------
-- GUI FUNCTION -- Toggle Raid Mode --
--------------------------------------
function Rebuilt_ToggleRaidMode()

	if Rebuilt_OptionsCheckRaidMode:GetChecked() then
		Rebuilt_RaidMode = true
	else
		Rebuilt_RaidMode = false
	end
end
----------------------------------------
-- GUI FUNCTION -- Toggle Runes First --
----------------------------------------
function Rebuilt_ToggleRunesFirst()

	if Rebuilt_OptionsCheckRunesFirst:GetChecked() then
		Rebuilt_RunesFirst = true
	else
		Rebuilt_RunesFirst = false
	end
end
----------------------------------------
-- GUI FUNCTION -- Toggle Runes First --
----------------------------------------
function Rebuilt_ToggleSpellDefense()

	if Rebuilt_OptionsCheckSpellDefense:GetChecked() then
		Rebuilt_SpellDefense = true
	else
		Rebuilt_SpellDefense = false
	end
end
-----------------------------------------
-- GUI FUNCTION -- Toggle Update Frame --
-----------------------------------------
function Rebuilt_ToggleUpdateFrame()

	if Rebuilt_UpdateFrame:IsShown() == 1 then
		Rebuilt_UpdateFrame:Hide()
	else
		Rebuilt_UpdateFrame:Show()
		Rebuilt_UpdateFrameEditBox:SetText("http://www.wowinterface.com/downloads/info13020-InspectTheirGadgets.html")
		Rebuilt_UpdateFrameEditBox:HighlightText()
	end
end
--------------------------------------
-- GUI FUNCTION -- Toggle Raid Mode --
--------------------------------------
function Rebuilt_SlashCommand(cmd)

	if cmd == "reset" or cmd == "r" then
		Rebuilt_MiniMapIcon:Show()

		Rebuilt_Display:ClearAllPoints()
		Rebuilt_MiniMapIcon:ClearAllPoints()
		Rebuilt_Options:ClearAllPoints()

		Rebuilt_FramesLocked = true
		Rebuilt_ToggleLocked()
		Rebuilt_Options:Show()

		Rebuilt_MiniMapIcon:SetPoint("CENTER", "UIParent", "CENTER", 0,0)
		Rebuilt_Display:SetPoint("CENTER", "UIParent", "CENTER", 0,-80)
		Rebuilt_Options:SetPoint("BOTTOM", "UIParent", "CENTER", 0,50)

		Rebuilt_NextSpell:SetPoint("CENTER", "$parent", "CENTER", 0,0)
		Rebuilt_DisplayHorn:SetPoint("CENTER", "$parent", "CENTER", - 70,2)
		Rebuilt_DisplayUsable:SetPoint("CENTER", "$parent", "CENTER", 70,2)
		Rebuilt_DisplayRune:SetPoint("CENTER", "$parent", "CENTER",-50, 72)
		Rebuilt_DisplaySpellDefense:SetPoint("CENTER", "$parent", "CENTER",50, 72)

		DEFAULT_CHAT_FRAME:AddMessage("|cFF6699FFDK Rebuilt |cFFFFFFFFReset!")

	elseif cmd == "options" or cmd == "o" then
		Rebuilt_ToggleOptions()
	elseif cmd == "hide" or cmd == "h" then
		Rebuilt_MiniMapIcon:Hide()
		Rebuilt_HideIcon = true
		DEFAULT_CHAT_FRAME:AddMessage("|cFF6699FFDK Rebuilt |cFFFFFFFFMinimap Icon Hidden")
	elseif cmd == "show" or cmd == "s" then
		Rebuilt_MiniMapIcon:Show()
		Rebuilt_HideIcon = false
		DEFAULT_CHAT_FRAME:AddMessage("|cFF6699FFDK Rebuilt |cFFFFFFFFMinimap Icon Shown")
	elseif cmd == "update" then
		Rebuilt_ToggleUpdateFrame()
	elseif cmd == "lock" then
		Rebuilt_FramesLocked = false
		Rebuilt_ToggleLocked()
		DEFAULT_CHAT_FRAME:AddMessage("|cFF6699FFDK Rebuilt |cFFFFFFFFLocked!")
	elseif cmd == "unlock" then
		Rebuilt_FramesLocked = true
		Rebuilt_ToggleLocked()
		DEFAULT_CHAT_FRAME:AddMessage("|cFF6699FFDK Rebuilt |cFFFFFFFFUnlocked!")
	else
		DEFAULT_CHAT_FRAME:AddMessage("|cFF6699FFDK Rebuilt \124r'/dkr reset' to reset display")
		DEFAULT_CHAT_FRAME:AddMessage("|cFF6699FFDK Rebuilt \124r'/dkr options' to open options")
		DEFAULT_CHAT_FRAME:AddMessage("|cFF6699FFDK Rebuilt \124r'/dkr hide/show' to hide/show the mini map icon")
		DEFAULT_CHAT_FRAME:AddMessage("|cFF6699FFDK Rebuilt \124r'/dkr update' for the update website")
		DEFAULT_CHAT_FRAME:AddMessage("|cFF6699FFDK Rebuilt \124r'/dkr lock/unlock' to lock/unlock the display")
	end

end

----------------------------------------
-- DAMAGE FUNCTION -- Determine Spell --
----------------------------------------
function Rebuilt_DetermineSpell(lastspell)

	local highestDamage = 0
	local highestID = 0
	--------------------------
	-- Check Diseases First --
	--------------------------
	icyDamage = Rebuilt_IcyTouch(false) 
	plagueDamage = Rebuilt_PlagueStrike(false) 
	if icyDamage > plagueDamage then
		return Rebuilt_IcyDisplay
	elseif plagueDamage > icyDamage then
		return Rebuilt_PlagueDisplay
	end

	----------------------
	-- Runic Power Dump --
	----------------------
	if Rebuilt_Enabled and not Rebuilt_RunesFirst then
	if 100 + (15 * Rebuilt_Talents[REBUILT_RUNICPOWERMASTERY]) - UnitPower("player") <= 10 then
		if Rebuilt_DancingRuneWeapon(false) > 0 then
			return 49028
		elseif Rebuilt_UnholyBlight(false) > 0 then
			return 51379
		elseif Rebuilt_SummonGargoyle(false) > 0 then
			return 49206
		elseif Rebuilt_FrostStrike(false) > 0 then
			return 55268
		elseif Rebuilt_DeathCoil(false) > 0 then
			return 52375
		end
	end
	end
	
	----------------------------------
	-- Remaining Abilities -- RUNES --
	----------------------------------

	-- Obliterate or Blood Strike --
	obliterateDamage = Rebuilt_Obliterate(false)
	bloodDamage = Rebuilt_BloodStrike(false)

	if obliterateDamage > bloodDamage then 
		highestDamage = obliterateDamage
		highestID = 49020
	else
		highestDamage = bloodDamage
		highestID = 45902
	end

	-- Heart Strike --
	heartDamage = Rebuilt_HeartStrike(false)

	if heartDamage > highestDamage then 
		highestDamage = heartDamage
		highestID = 55258
	end

	-- Howling Blast --
	howlingDamage = Rebuilt_HowlingBlast(false)

	if howlingDamage > highestDamage then 
		highestDamage = howlingDamage
		highestID = 51411
	end

	-- Scourge Strike --
	scourgeDamage = Rebuilt_ScourgeStrike(false)

	if scourgeDamage > highestDamage then 
		highestDamage = scourgeDamage
		highestID = 55271
	end

	-- Death Strike --
	deathstrikeDamage = Rebuilt_DeathStrike(false)

	if deathstrikeDamage > highestDamage then
		highestDamage = deathstrikeDamage
		highestID = 49924
	end

	if highestDamage > 0 and Rebuilt_RunesFirst then
		return highestID
	elseif highestDamage == 0 then

		-- Frost Strike --
		frostDamage = Rebuilt_FrostStrike(false)

		if frostDamage > highestDamage then 
			highestDamage = frostDamage
			highestID = 55268
		end

		-- Dancing Rune Weapon --
		dancingDamage = Rebuilt_DancingRuneWeapon(false)

		if dancingDamage > highestDamage then 
			highestDamage = dancingDamage
			highestID = 49028
		end
		
		-- Death Coil --
		deathDamage = Rebuilt_DeathCoil(false)
		if deathDamage > highestDamage then
			highestDamage = deathDamage
			highestID = 52375
		end

		-- Unholy Blight --
		unholyDamage = Rebuilt_UnholyBlight(false)

		if unholyDamage > highestDamage then 
			highestDamage = unholyDamage
			highestID = 51379
		end

		-- Summon Gargoyle --
		summonDamage = Rebuilt_SummonGargoyle(false)

		if summonDamage > highestDamage then 
			highestDamage = summonDamage
			highestID = 49206
		end
	end

	if highestDamage > 0 then
		return highestID
	else
		if Rebuilt_DeathGrip and Rebuilt_CooldownLeft("Death Grip") == 0 and IsSpellInRange("Death Grip", "target") == 1 and not Rebuilt_InCombat then
			return 49576
		else
			return 0
		end
	end

end
----------------------------------
-- DAMAGE FUNCTION -- Icy Touch --
----------------------------------
function Rebuilt_IcyTouch(skiprange)
	
	local _,f,_,d = Rebuilt_RuneStatus()

	if Rebuilt_UseIcy and Rebuilt_UseFrost then

		if IsSpellInRange(REBUILT_ICYTOUCH, "target") == 1 or skiprange then
			local _,f,_,d = Rebuilt_RuneStatus()
			if f>=1 or d>=1 then
				local name, _, _, _, _, _, expirationTime, isMine =  UnitDebuff("target" , REBUILT_FROSTFEVER)

				if ( expirationTime == nil ) then
					expirationTime = GetTime()
				end

				-- Base formula --
				local totalDamage = Rebuilt_SpellDamage(Rebuilt_Rank[REBUILT_ICYTOUCH], .1)
				local dotDamage = Rebuilt_SpellDamage(25.6, .055)

				-- Frost Talents --
				totalDamage = Rebuilt_FrostTalents(totalDamage)
				dotDamage = Rebuilt_FrostTalents(dotDamage)

				-- Modify for Improved Icy --
				totalDamage = totalDamage * (1 + Rebuilt_Talents["Improved Icy Touch"]/20)
				dotDamage = dotDamage * (1 + Rebuilt_Talents["Improved Icy Touch"]/20)

				-- Modifies for Crypt fever/Ebon Plaguebringer --
				if UnitDebuff("target", "Ebon Plaguebringer") == "Ebon Plaguebringer" then
					totalDamage = totalDamage * 1.3 * 1.13
					dotDamage = dotDamage * 1.3 * 1.13
				else
					dotDamage = dotDamage * (1 + Rebuilt_Talents["Crypt Fever"]/10)
					dotDamage = dotDamage * (1 + Rebuilt_Talents["Ebon Plaguebringer"]/23)
				end

				-- Crit Modification --
				if ( UnitBuff("player", REBUILT_KILLINGMACHINE) == REBUILT_KILLINGMACHINE ) or ( UnitBuff("player", REBUILT_DEATHCHILL) == REBUILT_DEATHCHILL ) then
					totalDamage = totalDamage * 2
				else
					totalDamage = totalDamage * Rebuilt_CritMultiplier(Rebuilt_Talents[REBUILT_RIME], 0)
				end

				-- Add in DoT damage --
				if ( isMine == nil) or (isMine == false )then
					return totalDamage + (dotDamage * (5 + Rebuilt_Talents["Epidemic"]))
				end
			end
		end
	end

	return 0
end
--------------------------------------
-- DAMAGE FUNCTION -- Plague Strike --
--------------------------------------
function Rebuilt_PlagueStrike(skiprange)


	if (IsSpellInRange(REBUILT_PLAGUESTRIKE, "target") == 1 and Rebuilt_UsePlague) or skiprange then

		local _,_,u,d = Rebuilt_RuneStatus()
		if u>=1 or d>=1 then
	
			local name, _, _, _, _, _, expirationTime, isMine =  UnitDebuff("target" , REBUILT_BLOODPLAGUE)

			if ( expirationTime == nil ) then
				expirationTime = GetTime()
			end

			-- Base Forumula
			local totalDamage =  Rebuilt_WeaponDamage(Rebuilt_Rank["Plague Strike WD"], .5, Rebuilt_Rank[REBUILT_PLAGUESTRIKE])
			local dotDamage = Rebuilt_SpellDamage(29.5, .055) * (5 + Rebuilt_Talents["Epidemic"])

			-- Outbreak
			totalDamage = totalDamage * (1 + Rebuilt_Talents[REBUILT_OUTBREAK]/10)
			dotDamage = dotDamage * (1 + Rebuilt_Talents[REBUILT_OUTBREAK]/10)

			-- Modifies for Crypt fever/Ebon Plaguebringer --
			if UnitDebuff("target", "Ebon Plaguebringer") == "Ebon Plaguebringer" then
				totalDamage = totalDamage * 1.3 * 1.13
				dotDamage = dotDamage * 1.3 * 1.13
			else
				dotDamage = dotDamage * (1 + Rebuilt_Talents["Crypt Fever"]/10)
				dotDamage = dotDamage * (1 + Rebuilt_Talents["Ebon Plaguebringer"]/23)
			end

			-- Crit Modify
			totalDamage = totalDamage * Rebuilt_CritMultiplier(Rebuilt_Talents[REBUILT_VICIOUSSTRIKES]/33.33333 , Rebuilt_Talents[REBUILT_VICIOUSSTRIKES]/6.666667)

			-- Physical Adds
			totalDamage = Rebuilt_PhysicalDamage(totalDamage)

			-- Add in DoT damage
			if ( isMine == nil) or (isMine == false )then
				return totalDamage + dotDamage
			else
				return 0
			end

		end
	end

	return 0
end
------------------------------------
-- DAMAGE FUNCTION --  Death Coil --
------------------------------------
function Rebuilt_DeathCoil(skiprange)

	if (IsSpellInRange(REBUILT_DEATHCOIL, "target") == 1 and UnitPower("player") >= 40) or skiprange then
		-- Base formula
		local totalDamage = Rebuilt_SpellDamage( Rebuilt_Rank[REBUILT_DEATHCOIL], .15 )

		-- Modifies for Morbidity
		totalDamage = totalDamage * (1 + Rebuilt_Talents[REBUILT_MORBIDITY] / 20)

		return totalDamage * Rebuilt_CritMultiplier(0,0)

	else
		return 0
	end

end
--------------------------------------
-- DAMAGE FUNCTION --  Blood Strike --
--------------------------------------
function Rebuilt_BloodStrike(skipRange)

	if IsSpellInRange(REBUILT_BLOODSTRIKE, "target") == 1 or skipRange then

		local b = Rebuilt_RuneStatus()
		if b>=1 then
	
			-- Standard Damage formula
			local totalDamage = Rebuilt_WeaponDamage(Rebuilt_Rank["Blood Strike WD"], .4, Rebuilt_Rank[REBUILT_BLOODSTRIKE])

			-- With diseases and bloody strikes
			totalDamage = totalDamage * (1 + .125*Rebuilt_Diseases())

			-- Addes bloody strikes(10-30% overall part)
			totalDamage = totalDamage * (1 + Rebuilt_Talents[REBUILT_BLOODYSTRIKES] / 6.66666667)

			-- Physical Damage
			totalDamage = Rebuilt_PhysicalDamage(totalDamage)

			return totalDamage * Rebuilt_CritMultiplier( Rebuilt_Talents[REBUILT_SUBVERSION]/33.33333, Rebuilt_Talents[REBUILT_MIGHTOFMOGRAINE]/6.6666667 )
		else
			return 0
		end
	else
		return 0
	end
end
------------------------------------
-- DAMAGE FUNCTION --  Obliterate --
------------------------------------
function Rebuilt_Obliterate(skipRange)

	if ( Rebuilt_Rank[REBUILT_OBLITERATE] > 0 ) and ( (Rebuilt_Talents[REBUILT_ANNIHILATION] == 3) or (Rebuilt_UseIcy == false and Rebuilt_UsePlague == false) ) then

		if IsSpellInRange(REBUILT_OBLITERATE, "target") == 1 or skipRange then

			local b,f,u,d = Rebuilt_RuneStatus()
			local runes = Rebuilt_FrostUnholy(b, f, u, d)
		
			if runes == true then
				-- Standard oblit formula
				local totalDamage =  Rebuilt_WeaponDamage(Rebuilt_Rank["Obliterate WD"], .8, Rebuilt_Rank[REBUILT_OBLITERATE])

				-- Diseases
				local totalDamage = totalDamage * (1 + .125*Rebuilt_Diseases())

				-- Checks for Oblit glyph
				for i=1,6 do
					_,_,glyph = GetGlyphSocketInfo(i)

					if (glyph == 58671) then totalDamage = totalDamage * 1.2 end
				end

				-- Physical Damage
				totalDamage = Rebuilt_PhysicalDamage(totalDamage)

				-- Crit modification
				if ( UnitBuff("player", REBUILT_DEATHCHILL) == REBUILT_DEATHCHILL ) then
					return totalDamage * ( 1 + Rebuilt_CritMultiplier(0,0) )
				else
					return totalDamage * Rebuilt_CritMultiplier( (Rebuilt_Talents[REBUILT_RIME]/20 + Rebuilt_Talents[REBUILT_SUBVERSION]/33.33333),0 )
				end
			else
				return 0
			end
		else
			return 0
		end
	else
		return 0
	end
end
------------------------------------
-- DAMAGE FUNCTION --  Death Strike --
------------------------------------
function Rebuilt_DeathStrike(skipRange)

	if IsSpellInRange(REBUILT_OBLITERATE, "target") == 1 or skipRange then

		local b,f,u,d = Rebuilt_RuneStatus()
		local runes = Rebuilt_FrostUnholy(b, f, u, d)
		
		if runes == true then
			-- Standard death strike formula --
			local totalDamage =  Rebuilt_WeaponDamage(Rebuilt_Rank["Death Strike WD"], .75, Rebuilt_Rank[REBUILT_DEATHSTRIKE])

			-- Physical Damage --
			totalDamage = Rebuilt_PhysicalDamage(totalDamage)

			-- Improved Death Strike --
			totalDamage = totalDamage * (1 + Rebuilt_Talents["Improved Death Strike"]/6.666666667)

			-- Crit modification --
			return totalDamage * Rebuilt_CritMultiplier(Rebuilt_Talents[REBUILT_SUBVERSION]/33.33333,Rebuilt_Talents[REBUILT_MIGHTOFMOGRAINE]/6.6666667 )
		end
	end

	return 0
end
--------------------------------------
-- DAMAGE FUNCTION --  Heart Strike --
--------------------------------------
function Rebuilt_HeartStrike(skiprange)

	

	if Rebuilt_Talents[REBUILT_HEARSTRIKE] == 1 and (IsSpellInRange(REBUILT_HEARSTRIKE, "target") == 1 or skiprange) then

		local b,_,_,d = Rebuilt_RuneStatus()

		if b>=1 or d>=1 then

			-- Standard Damage forumla
			local totalDamage = Rebuilt_WeaponDamage(Rebuilt_Rank["Heart Strike WD"], .5, Rebuilt_Rank[REBUILT_HEARSTRIKE])

			-- With Diseases
			totalDamage = totalDamage * (1 + .1*Rebuilt_Diseases())

			-- Addes bloody strikes(10-30% overall part)
			totalDamage = totalDamage * (1 + Rebuilt_Talents[REBUILT_BLOODYSTRIKES] / 6.66666667)

			-- Physical Damage
			totalDamage = Rebuilt_PhysicalDamage(totalDamage)

			-- Returns damage amount with crit modifier
			return totalDamage * Rebuilt_CritMultiplier(Rebuilt_Talents[REBUILT_SUBVERSION]/33.33333, Rebuilt_Talents[REBUILT_MIGHTOFMOGRAINE]/6.6666667 ) * 2
		end	
	end

	return 0
	
end
---------------------------------------------
-- DAMAGE FUNCTION --  Dancing Rune Weapon --
---------------------------------------------
function Rebuilt_DancingRuneWeapon(skiprange)

	if Rebuilt_Talents[REBUILT_DANCINGRUNEWEAPON] == 1 and IsSpellInRange(REBUILT_DANCINGRUNEWEAPON, "target") == 1 and UnitPower("player") >= 100 and Rebuilt_CooldownLeft(REBUILT_DANCINGRUNEWEAPON) <= Rebuilt_GCD and Rebuilt_RaidMode then
		return 99999 
	else
		return 0
	end
end
---------------------------------------
-- DAMAGE FUNCTION --  Howling Blast --
---------------------------------------
function Rebuilt_HowlingBlast(skiprange)

	

	if Rebuilt_Talents[REBUILT_HOWLINGBLAST] == 1 and IsSpellInRange(REBUILT_HOWLINGBLAST, "target") == 1 and Rebuilt_CooldownLeft(REBUILT_HOWLINGBLAST) <= Rebuilt_GCD and Rebuilt_UseFrost then

		local b,f,u,d = Rebuilt_RuneStatus()

		if Rebuilt_FrostUnholy(b, f, u, d) or UnitBuff("player", REBUILT_FREEZINGFOG) == REBUILT_FREEZINGFOG then
		
			-- Base formula including impurity modifier
			local totalDamage = Rebuilt_SpellDamage(Rebuilt_Rank[REBUILT_HOWLINGBLAST], .2)

			-- Takes it for a spin with a few frost talents
			totalDamage = Rebuilt_FrostTalents(totalDamage)

			-- Double damage for frost fever
			if (UnitDebuff("target", REBUILT_FROSTFEVER) == REBUILT_FROSTFEVER) then
				totalDamage = totalDamage * 2
			end

			-- Crit modification
			if ( UnitBuff("player", REBUILT_KILLINGMACHINE) == REBUILT_KILLINGMACHINE ) or ( UnitBuff("player", REBUILT_DEATHCHILL) == REBUILT_DEATHCHILL ) then
				return totalDamage * 2, 51408
			else
				return totalDamage * Rebuilt_CritMultiplier(0,0), 51408
			end
		else
			return 0
		end
	else
		return 0,0
	end
end
--------------------------------------
-- DAMAGE FUNCTION --  Frost Strike --
--------------------------------------
function Rebuilt_FrostStrike(skiprange)

	if Rebuilt_Talents[REBUILT_FROSTSTRIKE] == 1 and IsSpellInRange(REBUILT_FROSTSTRIKE, "target") == 1 and UnitPower("player") >=40 and Rebuilt_UseFrost then

		-- Base Formula
		local totalDamage = Rebuilt_WeaponDamage(Rebuilt_Rank["Frost Strike WD"], .6, Rebuilt_Rank[REBUILT_FROSTSTRIKE])
		-- Frost modifiers
		totalDamage = Rebuilt_FrostTalents(totalDamage)
		-- Blood of the North
		totalDamage = totalDamage * ( 1 + Rebuilt_Talents["Blood of the North"]/33.3333333)
		-- Crit Modification
		if ( UnitBuff("player", REBUILT_KILLINGMACHINE) == REBUILT_KILLINGMACHINE ) then
			totalDamage = totalDamage * (1 + (( Rebuilt_CritMultiplier(0, Rebuilt_Talents[REBUILT_GUILEOFGOREFIEND]/6.6666667) )))
			return totalDamage
		else
			totalDamage = totalDamage * Rebuilt_CritMultiplier(0, Rebuilt_Talents[REBUILT_GUILEOFGOREFIEND]/6.6666667)
			return totalDamage
		end
	else
		return 0
	end
end
---------------------------------------
-- DAMAGE FUNCTION --  Unholy Blight --
---------------------------------------
function Rebuilt_UnholyBlight(skiprange)

	if Rebuilt_RaidMode and Rebuilt_Talents[REBUILT_UNHOLYBLIGHT] == 1 and UnitBuff("player", REBUILT_UNHOLYBLIGHT) == nil and UnitPower("player") >= 40 and IsSpellInRange(REBUILT_PLAGUESTRIKE, "target") == 1 then
		local totalDamage = 20 * Rebuilt_SpellDamage(Rebuilt_Rank[REBUILT_UNHOLYBLIGHT], .013)
		return totalDamage
	else
		return 0
	end
end
----------------------------------------
-- DAMAGE FUNCTION --  Scourge Strike --
----------------------------------------
function Rebuilt_ScourgeStrike(skiprange)

	

	if Rebuilt_Talents[REBUILT_SCOURGESTRIKE] == 1 and IsSpellInRange(REBUILT_SCOURGESTRIKE, "target") == 1 then

		local b,f,u,d = Rebuilt_RuneStatus()
		if Rebuilt_FrostUnholy(b, f, u, d) then

			-- Base Formula
			local totalDamage = Rebuilt_WeaponDamage(Rebuilt_Rank["Scourge Strike WD"], .45, Rebuilt_Rank[REBUILT_SCOURGESTRIKE])
			-- Disease Damage
			totalDamage = totalDamage * (1 + .11*Rebuilt_Diseases())
			-- Outbreak
			totalDamage = totalDamage * (1 + Rebuilt_Talents[REBUILT_OUTBREAK]/20)
			-- Crit Modification
			return totalDamage * Rebuilt_CritMultiplier(Rebuilt_Talents[REBUILT_VICIOUSSTRIKES]/33.333333, 0)
		else
			return 0
		end
	else
		return 0
	end
end
-----------------------------------------
-- DAMAGE FUNCTION --  Summon Gargoyle --
-----------------------------------------
function Rebuilt_SummonGargoyle(skiprange)

	if Rebuilt_Talents[REBUILT_SUMMONGARGOYLE] == 1 and IsSpellInRange(REBUILT_SUMMONGARGOYLE, "target") == 1 and UnitPower("player") >= 50 and Rebuilt_RaidMode and Rebuilt_CooldownLeft(REBUILT_SUMMONGARGOYLE) <= Rebuilt_GCD then

		-- Base Formula --
		local totalDamage = Rebuilt_SpellDamage(150, .4)
		-- 15 Hits --
		local totalDamage = totalDamage * 15

		return totalDamage
	else
		return 0
	end
end
------------------------------------------------------------
-- VARIABLE FUNCTION -- Check if Target is on Immune List --
------------------------------------------------------------
function Rebuilt_CheckImmuneList()

	Rebuilt_UseFrost = true
	Rebuilt_UseInterrupt = true
	Rebuilt_UseSilence = true

	if UnitIsVisible("target") == 1 then

		local name = UnitName("target")

		if name == FrostImmuneList[name] then
			Rebuilt_UseFrost = false
		end

		if name == InterruptImmuneList[name] then
			Rebuilt_UseInterrupt = false
		end

		if name == SilenceImmuneList[name] then
			Rebuilt_UseSilence = false
		end	
	end

end
----------------------------------------------------
-- VARIABLE FUNCTION -- Adds to Frost Immune List --
----------------------------------------------------
function Rebuilt_AddToFrostImmuneList()

	if UnitCreatureType("target") == REBUILT_ELEMENTAL then

		local name = UnitName("target")
		FrostImmuneList[name] = name
		Rebuilt_UseFrost = false

	end

end
--------------------------------------------------------
-- VARIABLE FUNCTION -- Adds to Interrupt Immune List --
--------------------------------------------------------
function Rebuilt_AddToInterruptImmuneList()

	if UnitIsPlayer("target") == nil then
		local name = UnitName("target")
		InterruptImmuneList[name] = name
		Rebuilt_UseInterrupt = false

		-- If they can't be interrupted, they can't be silenced --
		Rebuilt_AddToSilenceImmuneList()
	end

end
------------------------------------------------------
-- VARIABLE FUNCTION -- Adds to Silence Immune List --
------------------------------------------------------
function Rebuilt_AddToSilenceImmuneList()

	if UnitIsPlayer("target") == nil then
		local name = UnitName("target")
		SilenceImmuneList[name] = name
		Rebuilt_UseSilence = false
	end

end
--------------------------------------------------------
-- VARIABLE FUNCTION -- Checks for Frost/Unholy runes --
--------------------------------------------------------
function Rebuilt_FrostUnholy(b, f, u, d)

	-- Checks the different rune combinations to see if a frost/unholy combo can be used. Used for Oblit, Howling and Scourge.
	if (f>=1) and (u>=1) then return true end
	if (f>=1) and (d>=1) then return true end 
	if (u>=1) and (d>=1) then return true end
	if (d>=2) then return true end

	return false

end
------------------------------------------------
-- VARIABLE FUNCTION -- Available Rune in GCD --
------------------------------------------------
function Rebuilt_RuneStatus()

	local avail = {0,0,0,0}

	for i= 1, 6 do

		if Rebuilt_RuneTime[i] <= Rebuilt_GCD then
			avail[Rebuilt_RuneType[i]] = avail[Rebuilt_RuneType[i]] + 1
		end
	end

	return avail[1], avail[2], avail[3], avail[4]
end
-------------------------------------------------
-- VARIABLE FUNCTION -- Updates the runes time --
-------------------------------------------------
function Rebuilt_UpdateRuneTime(rune, usable)

	if usable then
		Rebuilt_RuneTime[rune] = 0
	else		local presence = GetShapeshiftForm()
		if presence == 1 or presence == 2 then
			Rebuilt_RuneTime[rune] = 10
		elseif presence == 3 then
			Rebuilt_RuneTime[rune] = 9
		end 
	end

end
--------------------------------------------
-- VARIABLE FUNCTION -- Talents and Ranks --
--------------------------------------------
function Rebuilt_TalentsAndRanks()

	-- Talents
	Rebuilt_Talents = {}

	local tabs = GetNumTalentTabs()
	for i = 1, tabs do

		local talents = GetNumTalents(i)
		for t = 1, talents do

			local name, _, _, _, points = GetTalentInfo(i,t);
			Rebuilt_Talents[name] = points

		end

	end

	-- Ranks
	Rebuilt_Rank = {}

	local i = 1
		while true do
   	
		local name, rank = GetSpellName(i, BOOKTYPE_SPELL)
   		if not name then do break end end
   		Rebuilt_Rank[name] = rank
   
  	 	i = i + 1
	end

	Rebuilt_UpdateRanks()

	Rebuilt_Usable = {}

	if Rebuilt_Talents[REBUILT_BONESHIELD] == 1 then
		Rebuilt_Usable["ID"] = 49222
		Rebuilt_Usable["Name"] = REBUILT_BONESHIELD
		Rebuilt_Usable["Cooldown"] = 60
	elseif Rebuilt_Talents[REBUILT_UNBREAKABLEARMOR] == 1 then
		Rebuilt_Usable["ID"] = 51271
		Rebuilt_Usable["Name"] = REBUILT_UNBREAKABLEARMOR
		Rebuilt_Usable["Cooldown"] = 60
	elseif Rebuilt_Talents[REBUILT_HYSTERIA] == 1 then
		Rebuilt_Usable["ID"] = 49016
		Rebuilt_Usable["Name"] = REBUILT_HYSTERIA
		Rebuilt_Usable["Cooldown"] = 180
	else
		Rebuilt_Usable["ID"] = 0
		Rebuilt_Usable["Name"] = ""
		Rebuilt_Usable["Cooldown"] = 0
	end

	local _,_, newTexture = GetSpellInfo(Rebuilt_Usable["ID"])
	Rebuilt_DisplayUsableTexture:SetTexture(newTexture)

	Rebuilt_RuneType = {GetRuneType(1), GetRuneType(2) ,GetRuneType(5),GetRuneType(6),GetRuneType(3),GetRuneType(4)}
	Rebuilt_Enabled = true

end
--------------------------------------------
-- VARIABLE FUNCTION -- Diseses on Target --
--------------------------------------------
function Rebuilt_Diseases()

	local frost = UnitDebuff("target", REBUILT_FROSTFEVER);
	local blood = UnitDebuff("target", REBUILT_BLOODPLAGUE);
	local crypt = UnitDebuff("target", "Crypt Fever");
	local ebon = UnitDebuff("target", "Ebon Plague");

	local num = 0
	
	if not (frost==nil) then
		num = num + 1
	end
	if not (blood==nil) then
		num = num + 1
	end

	if not (crypt==nil) or (ebon==nil) then
		num = num + 1
	end

	return num

end
----------------------------------------
-- VARIABLE FUNCTION -- Frost Talents --
----------------------------------------
function Rebuilt_FrostTalents(currentDamage)

	-- Modifies for glacier rot
	if (UnitDebuff("target", REBUILT_BLOODPLAGUE) == REBUILT_BLOODPLAGUE) or ( UnitDebuff("target", REBUILT_FROSTFEVER) == REBUILT_FROSTFEVER) then
		currentDamage = currentDamage * (1 + (Rebuilt_Talents[REBUILT_GLACIERROT] / 15) )
	end
	
	-- Modifies for berciless combat
	if ( (UnitHealth("target") / UnitHealthMax("target")  <= .35 ) ) then
		currentDamage = currentDamage * (1 + (Rebuilt_Talents[REBUILT_MERCILESSCOMBAT] / 16.67) )
	end

	-- Modifies for black ice
	currentDamage = currentDamage * (1 + (Rebuilt_Talents[REBUILT_BLACKICE] / 50) )

	return currentDamage
end
---------------------------------------
-- VARIABLE FUNCTION -- Attack Power --
---------------------------------------
function Rebuilt_APorSPCalc()

	-- Calculates AP
	local base, posBuff, negBuff = UnitAttackPower("player");
	return base + posBuff + negBuff;

end
-----------------------------------------------------------
-- VARIABLE FUNCTION -- Damage Modifier (Blood Presence) --
-----------------------------------------------------------
function Rebuilt_DamageMultiplier()

	-- Determines Damage modification. Used for checking stances
	local _, _, _, _, _, _, percentmod = UnitDamage("player");
	return percentmod

end
------------------------------------------------
-- VARIABLE FUNCTION -- Weapon Damage Formula --
------------------------------------------------
function Rebuilt_WeaponDamage(normValue, perc, add)

	local effective = Rebuilt_APorSPCalc()
	local weapon = 0;

	-- Determine Weapon Type
	local mainHandLink = GetInventoryItemLink("player",GetInventorySlotInfo("MainHandSlot"))
	local _, _, _, _, _, _, itemType = GetItemInfo(mainHandLink)

	-- Returns appropriate modifier for normalized weapon damage ability
	if (itemType == "One-Handed Axes") or (itemType == "One-Handed Swords") or (itemType == "One-Handed Maces") then
		nwd = 2.4
	else
		nwd = 3.3
	end

	totalDamage = ( (normValue + (nwd * effective / 14)) * perc ) + add
	
	return totalDamage

end
-----------------------------------------------
-- VARIABLE FUNCTION -- Spell Damage forumla --
-----------------------------------------------
function Rebuilt_SpellDamage(base, coeff)

	local effective = Rebuilt_APorSPCalc()
	local damage = base + (effective * (coeff * (1 + Rebuilt_Talents[REBUILT_IMPURITY]/25)) )

	return damage

end
----------------------------------------------------------------
-- VARIABLE FUNCTION -- Critical Strike Chance/Bonus Modifier --
----------------------------------------------------------------
function Rebuilt_CritMultiplier(chancemod, bonusmod)


	-- Base Crit
	local critModify = 1 + (GetCritChance()/ 100)
	
	-- Chance Modification
	critModify = critModify + chancemod
	-- Bonus Modification
	critModify = critModify * ( 1 + bonusmod )

	return critModify

end
------------------------------------------------
-- VARIABLE FUNCTION -- Time left on Cooldown --
------------------------------------------------
function Rebuilt_CooldownLeft(ability)

	if ( ability == nil ) then
		return -1

	else
		local cdStart, cdLength = GetSpellCooldown(ability)

		if ( cdStart == nil ) then
			return -1
		else
			cdleft = cdStart + cdLength - GetTime() 

			if ( cdleft > 0 ) then 
				return cdStart + cdLength - GetTime()
			else
				return 0
			end
		end
	end

end
----------------------------------------------------
-- VARIABLE FUNCTION -- Physical Damage Modifiers --
----------------------------------------------------
function Rebuilt_PhysicalDamage(amount)

	-- Blood Gorged Talent --
	if ( UnitHealth("player") / UnitHealthMax("player") ) > .75 then amount = amount * (1 + Rebuilt_Talents[REBUILT_BLOODGORGED]/50) end

	-- Bloody Vengeance Buff --
	_, _, _, count = UnitBuff("player", "Bloody Vengeance")

	if (count == nil) then
		return amount
	else
		amount = amount * (1 + count/33.33333)
	end

	return amount

end
----------------------------------------------------
-- VARIABLE FUNCTION -- Update Ranks with Amounts --
----------------------------------------------------
function Rebuilt_UpdateRanks()

	------------
	-- Spells --
	------------

	-- Updates Icy Rouch Rank damage --
	if ( Rebuilt_Rank[REBUILT_ICYTOUCH] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_ICYTOUCH] = 132
	elseif ( Rebuilt_Rank[REBUILT_ICYTOUCH] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_ICYTOUCH] = 150
	elseif ( Rebuilt_Rank[REBUILT_ICYTOUCH] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_ICYTOUCH] = 167
	elseif ( Rebuilt_Rank[REBUILT_ICYTOUCH] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_ICYTOUCH] = 195
	elseif ( Rebuilt_Rank[REBUILT_ICYTOUCH] == "Rank 5" ) then
		Rebuilt_Rank[REBUILT_ICYTOUCH] = 236
	end

	-- Updates Death Coil Rank damage --
	if ( Rebuilt_Rank[REBUILT_DEATHCOIL] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_DEATHCOIL] = 104
	elseif ( Rebuilt_Rank[REBUILT_DEATHCOIL] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_DEATHCOIL] = 208
	elseif ( Rebuilt_Rank[REBUILT_DEATHCOIL] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_DEATHCOIL] = 275
	elseif ( Rebuilt_Rank[REBUILT_DEATHCOIL] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_DEATHCOIL] = 381
	elseif ( Rebuilt_Rank[REBUILT_DEATHCOIL] == "Rank 5" ) then
		Rebuilt_Rank[REBUILT_DEATHCOIL] = 443
	end

	-- Updates Howling Blast rank damage --
	if not Rebuilt_Rank[REBUILT_HOWLINGBLAST] then
		Rebuilt_Rank[REBUILT_HOWLINGBLAST] = -1
	elseif ( Rebuilt_Rank[REBUILT_HOWLINGBLAST] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_HOWLINGBLAST] = 206
	elseif ( Rebuilt_Rank[REBUILT_HOWLINGBLAST] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_HOWLINGBLAST] = 244
	elseif ( Rebuilt_Rank[REBUILT_HOWLINGBLAST] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_HOWLINGBLAST] = 338
	elseif ( Rebuilt_Rank[REBUILT_HOWLINGBLAST] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_HOWLINGBLAST] = 460
	elseif ( Rebuilt_Rank[REBUILT_HOWLINGBLAST] == "Rank 5" ) then
		Rebuilt_Rank[REBUILT_HOWLINGBLAST] = 540
	end

	-- Updates Unholy Blight rank damage --
	if not Rebuilt_Rank[REBUILT_UNHOLYBLIGHT] then
		Rebuilt_Rank[REBUILT_UNHOLYBLIGHT] = -1
	elseif ( Rebuilt_Rank[REBUILT_UNHOLYBLIGHT] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_UNHOLYBLIGHT] = 21
	elseif ( Rebuilt_Rank[REBUILT_UNHOLYBLIGHT] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_UNHOLYBLIGHT] = 30
	elseif ( Rebuilt_Rank[REBUILT_UNHOLYBLIGHT] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_UNHOLYBLIGHT] = 40
	elseif ( Rebuilt_Rank[REBUILT_UNHOLYBLIGHT] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_UNHOLYBLIGHT] = 48
	end

	-------------------------------
	-- Weapon Abilities: Learned --
	-------------------------------

	-- Updates Plague Strike Rank damage and Normalized Weapon damage --
	if ( Rebuilt_Rank[REBUILT_PLAGUESTRIKE] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_PLAGUESTRIKE] = 62.5
		Rebuilt_Rank["Plague Strike WD"] = 125
	elseif ( Rebuilt_Rank[REBUILT_PLAGUESTRIKE] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_PLAGUESTRIKE] = 75.5
		Rebuilt_Rank["Plague Strike WD"] = 151
	elseif ( Rebuilt_Rank[REBUILT_PLAGUESTRIKE] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_PLAGUESTRIKE] = 89
		Rebuilt_Rank["Plague Strike WD"] = 178
	elseif ( Rebuilt_Rank[REBUILT_PLAGUESTRIKE] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_PLAGUESTRIKE] = 108
		Rebuilt_Rank["Plague Strike WD"] = 216
	elseif ( Rebuilt_Rank[REBUILT_PLAGUESTRIKE] == "Rank 5" ) then
		Rebuilt_Rank[REBUILT_PLAGUESTRIKE] = 157
		Rebuilt_Rank["Plague Strike WD"] = 314
	elseif ( Rebuilt_Rank[REBUILT_PLAGUESTRIKE] == "Rank 6" ) then
		Rebuilt_Rank[REBUILT_PLAGUESTRIKE] = 189
		Rebuilt_Rank["Plague Strike WD"] = 378
	end

	-- Updates Blood Strike Rank damage and Normalized Weapon damage --
	if ( Rebuilt_Rank[REBUILT_BLOODSTRIKE] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_BLOODSTRIKE] = 104
		Rebuilt_Rank["Blood Strike WD"] = 260
	elseif ( Rebuilt_Rank[REBUILT_BLOODSTRIKE] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_BLOODSTRIKE] = 118
		Rebuilt_Rank["Blood Strike WD"] = 298
	elseif ( Rebuilt_Rank[REBUILT_BLOODSTRIKE] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_BLOODSTRIKE] = 138.8
		Rebuilt_Rank["Blood Strike WD"] = 347
	elseif ( Rebuilt_Rank[REBUILT_BLOODSTRIKE] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_BLOODSTRIKE] = 164.4
		Rebuilt_Rank["Blood Strike WD"] = 411
	elseif ( Rebuilt_Rank[REBUILT_BLOODSTRIKE] == "Rank 5" ) then
		Rebuilt_Rank[REBUILT_BLOODSTRIKE] = 250
		Rebuilt_Rank["Blood Strike WD"] = 625
	elseif ( Rebuilt_Rank[REBUILT_BLOODSTRIKE] == "Rank 6" ) then
		Rebuilt_Rank[REBUILT_BLOODSTRIKE] = 305.6
		Rebuilt_Rank["Blood Strike WD"] = 764
	end

	-- Updates Obliterate Rank damage and Normalized Weapon damage  --
	if not Rebuilt_Rank[REBUILT_OBLITERATE] then
		Rebuilt_Rank[REBUILT_OBLITERATE] = -1
		Rebuilt_Rank["Obliterate WD"] = -1
	elseif ( Rebuilt_Rank[REBUILT_OBLITERATE] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_OBLITERATE] = 198.4
		Rebuilt_Rank["Obliterate WD"] = 248
	elseif ( Rebuilt_Rank[REBUILT_OBLITERATE] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_OBLITERATE] = 244
		Rebuilt_Rank["Obliterate WD"] = 305
	elseif ( Rebuilt_Rank[REBUILT_OBLITERATE] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_OBLITERATE] = 381.6
		Rebuilt_Rank["Obliterate WD"] = 447
	elseif ( Rebuilt_Rank[REBUILT_OBLITERATE] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_OBLITERATE] = 467.2
		Rebuilt_Rank["Obliterate WD"] = 584
	end

	-- Updates Death Strike Rank damage and Normalized Weapon damage  --
	if not Rebuilt_Rank[REBUILT_DEATHSTRIKE] then
		Rebuilt_Rank[REBUILT_DEATHSTRIKE] = -1
		Rebuilt_Rank["Death Strike WD"] = -1
	elseif ( Rebuilt_Rank[REBUILT_DEATHSTRIKE] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_DEATHSTRIKE] = 84
		Rebuilt_Rank["Death Strike WD"] = 112
	elseif ( Rebuilt_Rank[REBUILT_DEATHSTRIKE] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_DEATHSTRIKE] = 97.5
		Rebuilt_Rank["Death Strike WD"] = 130
	elseif ( Rebuilt_Rank[REBUILT_DEATHSTRIKE] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_DEATHSTRIKE] = 123.75
		Rebuilt_Rank["Death Strike WD"] = 165
	elseif ( Rebuilt_Rank[REBUILT_DEATHSTRIKE] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_DEATHSTRIKE] = 187.5
		Rebuilt_Rank["Death Strike WD"] = 250
	elseif ( Rebuilt_Rank[REBUILT_DEATHSTRIKE] == "Rank 5" ) then
		Rebuilt_Rank[REBUILT_DEATHSTRIKE] = 222.75
		Rebuilt_Rank["Death Strike WD"] = 297
	end

	-------------------------------
	-- Weapon Abilities: Talented --
	-------------------------------

	-- Updates Scourge Strike Rank damage and Normalized Weapon damage --
	if not Rebuilt_Rank[REBUILT_SCOURGESTRIKE] then
		Rebuilt_Rank[REBUILT_SCOURGESTRIKE] = -1
		Rebuilt_Rank["Scourge Strike WD"] = -1
	elseif ( Rebuilt_Rank[REBUILT_SCOURGESTRIKE] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_SCOURGESTRIKE] = 151.875
		Rebuilt_Rank["Scourge Strike WD"] = 270
	elseif ( Rebuilt_Rank[REBUILT_SCOURGESTRIKE] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_SCOURGESTRIKE] = 186.75
		Rebuilt_Rank["Scourge Strike WD"] = 332
	elseif ( Rebuilt_Rank[REBUILT_SCOURGESTRIKE] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_SCOURGESTRIKE] = 291.375
		Rebuilt_Rank["Scourge Strike WD"] = 518
	elseif ( Rebuilt_Rank[REBUILT_SCOURGESTRIKE] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_SCOURGESTRIKE] = 357.188
		Rebuilt_Rank["Scourge Strike WD"] = 635
	end

	-- Updates Heart Strike rank damage and Normalized Weapon damage --
	if not Rebuilt_Rank[REBUILT_HEARSTRIKE] then
		Rebuilt_Rank[REBUILT_HEARSTRIKE] = -1
		Rebuilt_Rank["Heart Strike WD"] = -1
	elseif ( Rebuilt_Rank[REBUILT_HEARSTRIKE] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_HEARSTRIKE] = 125
		Rebuilt_Rank["Heart Strike WD"] = 250
	elseif ( Rebuilt_Rank[REBUILT_HEARSTRIKE] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_HEARSTRIKE] = 142
		Rebuilt_Rank["Heart Strike WD"] = 284
	elseif ( Rebuilt_Rank[REBUILT_HEARSTRIKE] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_HEARSTRIKE] = 167
		Rebuilt_Rank["Heart Strike WD"] = 334
	elseif ( Rebuilt_Rank[REBUILT_HEARSTRIKE] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_HEARSTRIKE] = 197.5
		Rebuilt_Rank["Heart Strike WD"] = 395
	elseif ( Rebuilt_Rank[REBUILT_HEARSTRIKE] == "Rank 5" ) then
		Rebuilt_Rank[REBUILT_HEARSTRIKE] = 300.5
		Rebuilt_Rank["Heart Strike WD"] = 601
	elseif ( Rebuilt_Rank[REBUILT_HEARSTRIKE] == "Rank 6" ) then
		Rebuilt_Rank[REBUILT_HEARSTRIKE] = 368
		Rebuilt_Rank["Heart Strike WD"] = 736
	end

	-- Updates Frost Strike rank damage and Normalized Weapon damage --
	if not Rebuilt_Rank[REBUILT_FROSTSTRIKE] then
		Rebuilt_Rank[REBUILT_FROSTSTRIKE] = -1
		Rebuilt_Rank["Frost Strike WD"] = -1
	elseif ( Rebuilt_Rank[REBUILT_FROSTSTRIKE] == "Rank 1" ) then
		Rebuilt_Rank[REBUILT_FROSTSTRIKE] = 52.2
		Rebuilt_Rank["Frost Strike WD"] = 87
	elseif ( Rebuilt_Rank[REBUILT_FROSTSTRIKE] == "Rank 2" ) then
		Rebuilt_Rank[REBUILT_FROSTSTRIKE] = 61.8
		Rebuilt_Rank["Frost Strike WD"] = 103
	elseif ( Rebuilt_Rank[REBUILT_FROSTSTRIKE] == "Rank 3" ) then
		Rebuilt_Rank[REBUILT_FROSTSTRIKE] = 69
		Rebuilt_Rank["Frost Strike WD"] = 115
	elseif ( Rebuilt_Rank[REBUILT_FROSTSTRIKE] == "Rank 4" ) then
		Rebuilt_Rank[REBUILT_FROSTSTRIKE] = 85.2
		Rebuilt_Rank["Frost Strike WD"] = 142
	elseif ( Rebuilt_Rank[REBUILT_FROSTSTRIKE] == "Rank 5" ) then
		Rebuilt_Rank[REBUILT_FROSTSTRIKE] = 120.6
		Rebuilt_Rank["Frost Strike WD"] = 201
	elseif ( Rebuilt_Rank[REBUILT_FROSTSTRIKE] == "Rank 6" ) then
		Rebuilt_Rank[REBUILT_FROSTSTRIKE] = 150
		Rebuilt_Rank["Frost Strike WD"] = 250
	end
end
