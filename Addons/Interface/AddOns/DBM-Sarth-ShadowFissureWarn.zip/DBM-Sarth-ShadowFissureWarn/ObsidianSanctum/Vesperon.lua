-------------------
--  Load Module  --
-------------------
local mod = DBM:NewMod("Vesperon-ShadowFissureWarn", "DBM-Sarth-ShadowFissureWarn")
local L = mod:GetLocalizedStrings()


-------------------
--  Initialize   --
-------------------
mod:SetRevision("1.0.2")
mod:SetCreatureID(30449)
mod:SetZone()
mod:RegisterCombat("combat")

mod:RegisterEvents(
    "SPELL_CAST_SUCCESS"
)

local shadowFissureTimer = mod:NewTimer(5, "Vesperon_ShadowFissureTimer")
local warnShadowFissure = mod:NewSpecialWarning("Vesperon_WarningShadowFissure", nil, nil, true)
local isInCombatWithVesperon = false

-------------------
--  Options      --
-------------------
mod:AddBoolOption("Vesperon_ShadowFissureAlarm", true)
mod.Options.HealthFrame = nil

-------------------
--  Event Funcs  --
-------------------
function mod:OnCombatStart(delay)
    isInCombatWithVesperon = true
end

function mod:OnCombatEnd()
    isInCombatWithVesperon = false
end

function mod:SPELL_CAST_SUCCESS(args)
    if (isInCombatWithVesperon) then
        if (args.spellId == 57579 or args.spellId == 59127) then
            self:SendSync("Vesperon_ShadowFissureAlarm")
        end
    end
end

function mod:OnSync(event, arg)
    if event == "Vesperon_ShadowFissureAlarm" then
        if (self.Options.Vesperon_ShadowFissureAlarm) then
            PlaySoundFile("Sound\\Doodad\\BoatDockedWarning.wav")
            PlaySoundFile("Sound\\Creature\\MobileAlertBot\\MobileAlertBotLoop.wav")
        end
        shadowFissureTimer:Start()
        warnShadowFissure:Show()
    end
end

-------------------
--  Other Funcs  --
-------------------
