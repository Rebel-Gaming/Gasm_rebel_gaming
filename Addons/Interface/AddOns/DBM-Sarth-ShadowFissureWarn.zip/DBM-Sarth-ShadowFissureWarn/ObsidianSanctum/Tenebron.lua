-------------------
--  Load Module  --
-------------------
local mod = DBM:NewMod("Tenebron-ShadowFissureWarn", "DBM-Sarth-ShadowFissureWarn")
local L = mod:GetLocalizedStrings()


-------------------
--  Initialize   --
-------------------
mod:SetRevision("1.0.2")
mod:SetCreatureID(30452)
mod:SetZone()
mod:RegisterCombat("combat")

mod:RegisterEvents(
    "SPELL_CAST_SUCCESS"
)

local shadowFissureTimer = mod:NewTimer(5, "Tenebron_ShadowFissureTimer")
local warnShadowFissure = mod:NewSpecialWarning("Tenebron_WarningShadowFissure", nil, nil, true)
local isInCombatWithTenebron = false

-------------------
--  Options      --
-------------------
mod:AddBoolOption("Tenebron_ShadowFissureAlarm", true)
mod.Options.HealthFrame = nil

-------------------
--  Event Funcs  --
-------------------
function mod:OnCombatStart(delay)
    isInCombatWithTenebron = true
end

function mod:OnCombatEnd()
    isInCombatWithTenebron = false
end

function mod:SPELL_CAST_SUCCESS(args)
    if (isInCombatWithTenebron) then
        if (args.spellId == 57579 or args.spellId == 59127) then
            self:SendSync("Tenebron_ShadowFissureAlarm")
        end
    end
end

function mod:OnSync(event, arg)
    if event == "Tenebron_ShadowFissureAlarm" then
        if (self.Options.Tenebron_ShadowFissureAlarm) then
            PlaySoundFile("Sound\\Doodad\\BoatDockedWarning.wav")
            PlaySoundFile("Sound\\Creature\\MobileAlertBot\\MobileAlertBotLoop.wav")
        end
        shadowFissureTimer:Start()
        warnShadowFissure:Show()
    end
end

-------------------
--  Other Funcs  --
-------------------
