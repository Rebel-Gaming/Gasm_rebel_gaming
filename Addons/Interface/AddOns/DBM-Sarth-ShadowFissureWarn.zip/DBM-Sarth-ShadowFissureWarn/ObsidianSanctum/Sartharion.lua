-------------------
--  Load Module  --
-------------------
local mod = DBM:NewMod("Sartharion-ShadowFissureWarn", "DBM-Sarth-ShadowFissureWarn")
local L = mod:GetLocalizedStrings()


-------------------
--  Initialize   --
-------------------
mod:SetRevision("1.0.2")
mod:SetCreatureID(28860)
mod:SetZone()
mod:RegisterCombat("combat")

mod:RegisterEvents(
    "SPELL_CAST_SUCCESS"
)

local shadowFissureTimer = mod:NewTimer(5, "Sartharion_ShadowFissureTimer")
local warnShadowFissure = mod:NewSpecialWarning("Sartharion_WarningShadowFissure", nil, nil, true)
local isInCombatWithSartharion = false

-------------------
--  Options      --
-------------------
mod:AddBoolOption("Sartharion_ShadowFissureAlarm", true)
mod.Options.HealthFrame = nil

-------------------
--  Event Funcs  --
-------------------
function mod:OnCombatStart(delay)
    isInCombatWithSartharion = true;
end

function mod:OnCombatEnd()
    isInCombatWithSartharion = false;
end

function mod:SPELL_CAST_SUCCESS(args)
    if (isInCombatWithSartharion) then
        if (args.spellId == 57579 or args.spellId == 59127) then
            self:SendSync("Sartharion_ShadowFissureAlarm")
        end
    end
end

function mod:OnSync(event, arg)
    if event == "Sartharion_ShadowFissureAlarm" then
        if (self.Options.Sartharion_ShadowFissureAlarm) then
            PlaySoundFile("Sound\\Doodad\\BoatDockedWarning.wav")
            PlaySoundFile("Sound\\Creature\\MobileAlertBot\\MobileAlertBotLoop.wav")
        end
        shadowFissureTimer:Start()
        warnShadowFissure:Show()
    end
end

-------------------
--  Other Funcs  --
-------------------
