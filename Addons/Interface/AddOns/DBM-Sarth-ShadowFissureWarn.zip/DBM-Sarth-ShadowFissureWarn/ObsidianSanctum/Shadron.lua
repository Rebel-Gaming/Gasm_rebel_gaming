-------------------
--  Load Module  --
-------------------
local mod = DBM:NewMod("Shadron-ShadowFissureWarn", "DBM-Sarth-ShadowFissureWarn")
local L = mod:GetLocalizedStrings()


-------------------
--  Initialize   --
-------------------
mod:SetRevision("1.0.2")
mod:SetCreatureID(30451)
mod:SetZone()
mod:RegisterCombat("combat")

mod:RegisterEvents(
    "SPELL_CAST_SUCCESS"
)

local shadowFissureTimer = mod:NewTimer(5, "Shadron_ShadowFissureTimer")
local warnShadowFissure = mod:NewSpecialWarning("Shadron_WarningShadowFissure", nil, nil, true)
local isInCombatWithShadron = false

-------------------
--  Options      --
-------------------
mod:AddBoolOption("Shadron_ShadowFissureAlarm", true)
mod.Options.HealthFrame = nil

-------------------
--  Event Funcs  --
-------------------
function mod:OnCombatStart(delay)
    isInCombatWithShadron = true
end

function mod:OnCombatEnd()
    isInCombatWithShadron = false
end

function mod:SPELL_CAST_SUCCESS(args)
    if (isInCombatWithShadron) then
        if (args.spellId == 57579 or args.spellId == 59127) then
            self:SendSync("Shadron_ShadowFissureAlarm")
        end
    end
end

function mod:OnSync(event, arg)
    if event == "Shadron_ShadowFissureAlarm" then
        if (self.Options.Shadron_ShadowFissureAlarm) then
            PlaySoundFile("Sound\\Doodad\\BoatDockedWarning.wav")
            PlaySoundFile("Sound\\Creature\\MobileAlertBot\\MobileAlertBotLoop.wav")
        end
        shadowFissureTimer:Start()
        warnShadowFissure:Show()
    end
end

-------------------
--  Other Funcs  --
-------------------
