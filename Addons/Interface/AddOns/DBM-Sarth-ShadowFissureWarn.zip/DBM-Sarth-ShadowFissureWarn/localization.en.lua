local L

---------------
--  Tenebron  --
---------------
L = DBM:GetModLocalization("Tenebron-ShadowFissureWarn")

L:SetGeneralLocalization({
	name = "Tenebron-ShadowFissureWarn"
})

L:SetWarningLocalization({
    Tenebron_WarningShadowFissure         = "Shadow Fissure!",
})

L:SetTimerLocalization({
	Tenebron_ShadowFissureTimer		= "SHADOW FISSURE!"
})

L:SetOptionLocalization({
	Tenebron_ShadowFissureTimer		= "Show the 5 second countdown-till-nuke timer bar for Tenebron's Shadow Fissure",
	Tenebron_ShadowFissureAlarm		= "Play the siren sound when Tenebron's Shadow Fissure is cast",
	Tenebron_WarningShadowFissure   = "Show the onscreen warning when Tenebron's Shadow Fissure is cast",
})

L:SetMiscLocalization({
})

---------------
--  Shadron  --
---------------
L = DBM:GetModLocalization("Shadron-ShadowFissureWarn")

L:SetGeneralLocalization({
    name = "Shadron-ShadowFissureWarn"
})

L:SetWarningLocalization({
    Shadron_WarningShadowFissure         = "Shadow Fissure!",
})

L:SetTimerLocalization({
    Shadron_ShadowFissureTimer      = "SHADOW FISSURE!"
})

L:SetOptionLocalization({
    Shadron_ShadowFissureTimer     = "Show the 5 second countdown-till-nuke timer bar for Shadron's Shadow Fissure",
    Shadron_ShadowFissureAlarm     = "Play the siren sound when Shadron's Shadow Fissure is cast",
    Shadron_WarningShadowFissure   = "Show the onscreen warning when Shadron's Shadow Fissure is cast",
})

L:SetMiscLocalization({
})

---------------
--  Vesperon  --
---------------
L = DBM:GetModLocalization("Vesperon-ShadowFissureWarn")

L:SetGeneralLocalization({
    name = "Vesperon-ShadowFissureWarn"
})

L:SetWarningLocalization({
    Vesperon_WarningShadowFissure         = "Shadow Fissure!",
})

L:SetTimerLocalization({
    Vesperon_ShadowFissureTimer      = "SHADOW FISSURE!"
})

L:SetOptionLocalization({
    Vesperon_ShadowFissureTimer     = "Show the 5 second countdown-till-nuke timer bar for Vesperon's Shadow Fissure",
    Vesperon_ShadowFissureAlarm     = "Play the siren sound when Vesperon's Shadow Fissure is cast",
    Vesperon_WarningShadowFissure   = "Show the onscreen warning when Vesperon's Shadow Fissure is cast",
})

L:SetMiscLocalization({
})

---------------
--  Sartharion  --
---------------
L = DBM:GetModLocalization("Sartharion-ShadowFissureWarn")

L:SetGeneralLocalization({
    name = "Sartharion-ShadowFissureWarn"
})

L:SetWarningLocalization({
    Sartharion_WarningShadowFissure         = "Shadow Fissure!",
})

L:SetTimerLocalization({
    Sartharion_ShadowFissureTimer     = "SHADOW FISSURE!"
})

L:SetOptionLocalization({
    Sartharion_ShadowFissureTimer     = "Show the 5 second countdown-till-nuke timer bar for any Shadow Fissure while fighting Sartharion",
    Sartharion_ShadowFissureAlarm     = "Play the siren sound when any Shadow Fissure is cast while fighting Sartharion",
    Sartharion_WarningShadowFissure   = "Show the onscreen warning when any Shadow Fissure is cast while fighting Sartharion",
})

L:SetMiscLocalization({
})