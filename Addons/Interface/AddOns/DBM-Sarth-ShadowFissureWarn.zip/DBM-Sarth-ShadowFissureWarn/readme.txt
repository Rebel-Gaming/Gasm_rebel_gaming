-- OVERVIEW --
DBM-Sarth-ShadowFissureWarn gives you visual and audio warning when a shadow fissure (a.k.a. void zone) is cast by any of the drakes in The Obsidian Sanctum. This is mainly helpful in Sarth +drakes fights when there's a ton of visual spam everywhere and it's hard to see the ground. It's especially easy to get tunnel vision as a healer watching your raid frames, and if you do that for a few seconds and end up standing in a shadow fissure you may wipe the raid. This DBM mod should help prevent that.

-- REQUIREMENTS --
You must have the latest Deadly Boss Mods addon installed.

-- INSTALLATION --
To install DBM-Sarth-ShadowFissureWarn simply move or copy the DBM-Sarth-ShadowFissureWarn folder into your World of Warcraft/Interface/AddOns folder.

-- SETTINGS --
You can set a few options by typing /dbm, selecting DBM-Sarth-ShadowFissureWarn, loading the addon, and clicking around. This lets you turn off any of the audio, warning text, or timer bars for any of the drakes.