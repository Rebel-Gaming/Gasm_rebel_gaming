local frame = CreateFrame( "Frame", nUI_Carbon_Tribal_2, UIParent );

local function onEvent()

	nUI_TopBars1:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_2_Console" );
	nUI_TopBars2:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_2_Console" );
	nUI_TopBars3:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_2_Console" );
	nUI_TopBars4:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_2_Console" );
	nUI_TopBars5:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_2_Console" );

	nUI_BottomBars1:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_21" );
	nUI_BottomBars2:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_22" );
	nUI_BottomBars3:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_23" );
	nUI_BottomBars4:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_24" );
	nUI_BottomBars5:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_25" );
	
	nUI_Dashboard_Panel1:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_21" );
	nUI_Dashboard_Panel2:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_22" );
	nUI_Dashboard_Panel3:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_23" );
	nUI_Dashboard_Panel4:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_24" );
	nUI_Dashboard_Panel5:SetTexture( "Interface\\AddOns\\nUI_Carbon_Tribal_2\\nUI_Carbon_Tribal_25" );

	frame:UnregisterEvent( "PLAYER_ENTERING_WORLD" );
	
end

frame:SetScript( "OnEvent", onEvent );
frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
