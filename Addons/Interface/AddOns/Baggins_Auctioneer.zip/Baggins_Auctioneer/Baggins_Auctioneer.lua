--[[
Baggins_Auctioneer, Adds Auctioneer BeanCounter/BottomScanner bought-for filters to Baggins ("disenchant", "vendor", etc)

Author: Mikk of Bloodhoof-EU <dpsgnome@mail.com>

This addon is placed in the public domain.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

]]

local strlower=string.lower
local strmatch=string.match
local GetContainerItemLink, GetContainerItemInfo = GetContainerItemLink, GetContainerItemInfo
local BeanCounter = BeanCounter
local BtmScan = BtmScan
local Baggins = Baggins
local _G = _G

local addon = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0","AceEvent-2.0")

local dewdrop = AceLibrary:HasInstance("Dewdrop-2.0") and AceLibrary("Dewdrop-2.0")

local function Rule_Matches(bag,slot,rule)

	local link = GetContainerItemLink(bag, slot)
	if(not link) then return; end
	local _,itemCount = GetContainerItemInfo(bag,slot)

	local reason = BeanCounter and BeanCounter.API.getBidReason(link, itemCount)
	if not reason or reason=="" or reason=="0" then
		-- try BtmScan
		if BtmScan then 
			local bidlist = BtmScan.Settings.GetSetting("bid.list") 
			if not bidlist then
				return false
			end

			local id, suffix, enchant, seed = BtmScan.BreakLink(link)
			local sig = ("%d:%d:%d"):format(id, suffix, enchant) 
			local bids = bidlist[sig..":"..seed.."x"..itemCount] 

			reason = bids and bids[1]
		end
	end

	if not reason or reason=="" then
		return false
	end

	reason=strlower(reason)
	
	local test = rule.test
	
	if reason==test then
		return true
	end

	if test=="convert" or test=="ematsconvert" then	-- old rule name "ematsconvert" will still be around in old configs
		return strmatch(reason, "conver") and true	-- "conver" matches both "convert" and "conversion"
	end
	
	if test=="anyresale" then
		return reason=="resale" or reason=="appraiser" or reason=="comparable"
	end
	
	if test=="any" then
		return true
	end
	
	return false
end

local function Rule_GetName(rule)
	return "Auctioneer:"..(rule.test or "???")
end


local function Rule_Clean(rule)
	rule.test = "any";
end

local function Rule_DewDropOptions(rule, level, value)
	if(level == 1) then
		dewdrop:AddLine("text", "Auctioneer Options", "isTitle", true);

		dewdrop:AddLine("text", "Bought for Vendor", "checked", rule.test == "vendor",
			"func",function(k) rule.test = "vendor"; Baggins:OnRuleChanged() end);

		dewdrop:AddLine("text", "Bought for Disenchant", "checked", rule.test == "disenchant",
			"func",function(k) rule.test = "disenchant"; Baggins:OnRuleChanged() end);
			
		dewdrop:AddLine("text", "Bought for Prospecting", "checked", rule.test == "prospect",
			"func",function(k) rule.test = "prospect"; Baggins:OnRuleChanged() end);
			
		dewdrop:AddLine("text", "Bought for Milling", "checked", rule.test == "milling",
			"func",function(k) rule.test = "milling"; Baggins:OnRuleChanged() end);
			
		dewdrop:AddLine("text", "Bought for Conversion", "checked", rule.test == "ematsconvert" or rule.test=="convert",	-- old rule name: "ematsconvert" will still be around in old configs
			"func",function(k) rule.test = "convert"; Baggins:OnRuleChanged() end);
			
		dewdrop:AddLine("text", "Bought for Snatch", "checked", rule.test == "snatch",
			"func",function(k) rule.test = "snatch"; Baggins:OnRuleChanged() end);
		
		dewdrop:AddLine("text", "Bought for Resale (any)", "checked", rule.test == "anyresale",
			"func",function(k) rule.test = "anyresale"; Baggins:OnRuleChanged() end);
			
		dewdrop:AddLine("text", "Bought for any reason", "checked", rule.test == "any",
			"func",function(k) rule.test = "any"; Baggins:OnRuleChanged() end);
	end
end

function addon:ADDON_LOADED()
	if not BeanCounter then
		BeanCounter = _G.BeanCounter
		if BeanCounter then
			Baggins:ForceFullRefresh()
		end
	end
	
	if not BtmScan then
		BtmScan = _G.BtmScan
		if BtmScan then
			Baggins:ForceFullRefresh()
		end
	end
end


function addon:OnEnable()
	Baggins:AddCustomRule("Auctioneer", {
		DisplayName = "Auctioneer",
		Description = "Filter according to Auctioneer \"bought for\"",
		Matches = Rule_Matches,
		GetName = Rule_GetName,
		CleanRule = Rule_Clean,
		DewDropOptions = Rule_DewDropOptions
	});
	
	Baggins:ForceFullRefresh()
	self:RegisterEvent("ADDON_LOADED")
end

